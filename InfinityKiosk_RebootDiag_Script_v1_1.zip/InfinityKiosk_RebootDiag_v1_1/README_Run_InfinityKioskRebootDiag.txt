Infinity Kiosk Reboot Diagnostic Collector v1.1
==============================================

Files:
- Collect-InfinityKioskRebootDiag.ps1
- Run_InfinityKiosk_RebootDiag.bat

Use:
1. Put both files in the same folder on the kiosk PC, for example Desktop\INF_troubleshoot.
2. Right-click Run_InfinityKiosk_RebootDiag.bat and choose Run as administrator if possible.
3. If admin is not possible, double-click still works, but some logs/policies may be incomplete.
4. Output is created on Desktop:
   InfinityKiosk_RebootDiag_<COMPUTERNAME>_<timestamp>
   InfinityKiosk_RebootDiag_<COMPUTERNAME>_<timestamp>.zip

Manual command:
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\Collect-InfinityKioskRebootDiag.ps1 -DaysBack 90 -IncludeEvtxExport

Notes:
- Script is read-only.
- It does not disable updates, services or scheduled tasks.
- v1.1 fixes PowerShell 5.1 return/export robustness problems seen as:
  "Argument types do not match" and Export-Csv null InputObject errors.
