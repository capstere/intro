<#
.SYNOPSIS
  Collects reboot / restart diagnostics from an Infinity kiosk PC without changing system settings.

.DESCRIPTION
  PowerShell 5.1 compatible evidence collector for kiosk PCs that restart while GeneXpert Infinity tests may be running.
  The script is read-only. It gathers Windows event logs, Windows Update / Update Orchestrator traces,
  pending reboot indicators, scheduled tasks, services, update policy registry keys, startup items, power settings,
  installed hotfixes, and reliability records.

.OUTPUT
  Creates a timestamped folder on the current user's Desktop containing CSV/JSON/TXT/HTML files and a ZIP package.

.EXAMPLE
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Collect-InfinityKioskRebootDiag.ps1

.EXAMPLE
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Collect-InfinityKioskRebootDiag.ps1 -DaysBack 90 -IncludeEvtxExport

.NOTES
  Safe/read-only. Does not disable updates, services, scheduled tasks, or restart behavior.
  Version: 1.1 - hardens empty/null exports and PowerShell 5.1 collection returns.
#>

[CmdletBinding()]
param(
    [int]$DaysBack = 60,
    [int]$MaxEventsPerLog = 5000,
    [switch]$IncludeEvtxExport,
    [switch]$SkipWindowsUpdateLog
)

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'

# -----------------------------
# Basic setup
# -----------------------------
$ScriptStart = Get-Date
$StartTime = (Get-Date).AddDays(-1 * [Math]::Abs($DaysBack))
$EndTime = Get-Date
$ComputerName = $env:COMPUTERNAME
$SafeComputerName = ($ComputerName -replace '[^A-Za-z0-9_.-]', '_')

function Get-DesktopPath {
    try {
        $p = [Environment]::GetFolderPath('Desktop')
        if ([string]::IsNullOrWhiteSpace($p) -or -not (Test-Path -LiteralPath $p)) {
            $p = Join-Path $env:USERPROFILE 'Desktop'
        }
        if (-not (Test-Path -LiteralPath $p)) { New-Item -Path $p -ItemType Directory -Force | Out-Null }
        return $p
    } catch {
        return $env:TEMP
    }
}

$Desktop = Get-DesktopPath
$Stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$OutRoot = Join-Path $Desktop ("InfinityKiosk_RebootDiag_{0}_{1}" -f $SafeComputerName, $Stamp)
New-Item -Path $OutRoot -ItemType Directory -Force | Out-Null
$RawDir = Join-Path $OutRoot 'Raw'
$CsvDir = Join-Path $OutRoot 'CSV'
$JsonDir = Join-Path $OutRoot 'JSON'
$TxtDir = Join-Path $OutRoot 'TXT'
$HtmlDir = Join-Path $OutRoot 'HTML'
New-Item -Path $RawDir,$CsvDir,$JsonDir,$TxtDir,$HtmlDir -ItemType Directory -Force | Out-Null

$TranscriptPath = Join-Path $TxtDir 'transcript.txt'
try { Start-Transcript -Path $TranscriptPath -Force | Out-Null } catch {}

$script:Findings = New-Object System.Collections.Generic.List[object]
$script:Errors = New-Object System.Collections.Generic.List[object]
$script:AllEvents = New-Object System.Collections.Generic.List[object]

function Add-Finding {
    param(
        [string]$Severity,
        [string]$Area,
        [string]$Message,
        [string]$Evidence = ''
    )
    try {
        $script:Findings.Add([PSCustomObject]@{
            TimeCollected = (Get-Date)
            Severity      = $Severity
            Area          = $Area
            Message       = $Message
            Evidence      = $Evidence
        }) | Out-Null
    } catch {}
}

function Add-ErrorRecord {
    param([string]$Area,[string]$Message)
    try {
        $script:Errors.Add([PSCustomObject]@{
            TimeCollected = (Get-Date)
            Area          = $Area
            Error         = $Message
        }) | Out-Null
    } catch {}
}

function Invoke-Safe {
    param(
        [string]$Name,
        [scriptblock]$ScriptBlock,
        $Default = $null
    )
    try {
        return & $ScriptBlock
    } catch {
        Add-ErrorRecord -Area $Name -Message $_.Exception.Message
        Add-Finding -Severity 'WARN' -Area $Name -Message 'Collection step failed, script continued.' -Evidence $_.Exception.Message
        return $Default
    }
}

function Test-IsAdmin {
    try {
        $currentIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($currentIdentity)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

$IsAdmin = Test-IsAdmin
if (-not $IsAdmin) {
    Add-Finding -Severity 'WARN' -Area 'Privilege' -Message 'Script is not running elevated. Some event logs, policy results, or registry keys may be incomplete.' -Evidence 'Run PowerShell as Administrator if possible.'
}

function ConvertTo-SafeObjectArray {
    param($Data)

    $list = New-Object System.Collections.ArrayList

    if ($null -eq $Data) {
        return @()
    }

    # Treat strings and dictionaries as one object; enumerate normal arrays/lists/collections.
    if (($Data -is [string]) -or ($Data -is [System.Collections.IDictionary])) {
        [void]$list.Add($Data)
    }
    elseif ($Data -is [System.Collections.IEnumerable]) {
        foreach ($item in $Data) {
            if ($null -ne $item) { [void]$list.Add($item) }
        }
    }
    else {
        [void]$list.Add($Data)
    }

    return $list.ToArray()
}

function New-NoRowsObject {
    param([string]$Reason = 'NO_ROWS_COLLECTED')
    return [PSCustomObject]@{
        ComputerName  = $env:COMPUTERNAME
        TimeCollected = (Get-Date)
        Info          = $Reason
    }
}

function Export-CsvSafe {
    param($Data,[string]$Path)
    Invoke-Safe -Name ("Export CSV: {0}" -f $Path) -ScriptBlock {
        $arr = @(ConvertTo-SafeObjectArray -Data $Data)
        if ($arr.Count -eq 0) {
            New-NoRowsObject | Export-Csv -Path $Path -NoTypeInformation -Encoding UTF8 -Force
        } else {
            $arr | Where-Object { $null -ne $_ } | Export-Csv -Path $Path -NoTypeInformation -Encoding UTF8 -Force
        }
    } | Out-Null
}

function Export-JsonSafe {
    param($Data,[string]$Path,[int]$Depth = 6)
    Invoke-Safe -Name ("Export JSON: {0}" -f $Path) -ScriptBlock {
        if ($null -eq $Data) { @() | ConvertTo-Json -Depth $Depth | Out-File -FilePath $Path -Encoding UTF8 -Force }
        else { $Data | ConvertTo-Json -Depth $Depth | Out-File -FilePath $Path -Encoding UTF8 -Force }
    } | Out-Null
}

function Out-TextSafe {
    param([string]$Text,[string]$Path)
    Invoke-Safe -Name ("Write text: {0}" -f $Path) -ScriptBlock {
        $Text | Out-File -FilePath $Path -Encoding UTF8 -Force
    } | Out-Null
}

function Run-NativeCommand {
    param(
        [string]$Name,
        [string]$CommandLine,
        [string]$OutputFile
    )
    Invoke-Safe -Name $Name -ScriptBlock {
        $header = @()
        $header += "COMMAND: $CommandLine"
        $header += "TIME:    $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
        $header += "COMPUTER:$env:COMPUTERNAME"
        $header += ('-' * 80)
        $result = cmd.exe /c $CommandLine 2>&1
        $header + $result | Out-File -FilePath $OutputFile -Encoding UTF8 -Force
    } | Out-Null
}

function Get-CimOrWmi {
    param([string]$ClassName,[string]$Namespace = 'root\cimv2')
    $r = Invoke-Safe -Name "Get-CimInstance $ClassName" -ScriptBlock { Get-CimInstance -ClassName $ClassName -Namespace $Namespace -ErrorAction Stop } -Default $null
    if ($null -eq $r) {
        $r = Invoke-Safe -Name "Get-WmiObject $ClassName" -ScriptBlock { Get-WmiObject -Class $ClassName -Namespace $Namespace -ErrorAction Stop } -Default $null
    }
    return $r
}

function Convert-WmiDateSafe {
    param($WmiDate)
    try {
        if ($null -eq $WmiDate) { return $null }
        return [System.Management.ManagementDateTimeConverter]::ToDateTime([string]$WmiDate)
    } catch { return $null }
}

# -----------------------------
# Event helpers
# -----------------------------
function Get-EventHint {
    param($EventObject)
    $provider = [string]$EventObject.ProviderName
    $id = [int]$EventObject.Id
    $msg = [string]$EventObject.Message

    if ($provider -eq 'User32' -and $id -eq 1074) { return 'Planned restart/shutdown was initiated. Message usually contains process, user, reason code, shutdown type and comment.' }
    if ($id -eq 6008) { return 'Previous shutdown was unexpected. Look for power loss, forced reboot, crash, or abrupt restart around this time.' }
    if ($provider -eq 'Microsoft-Windows-Kernel-Power' -and $id -eq 41) { return 'System rebooted without clean shutdown. Often power loss, hard reset, crash, or forced power transition.' }
    if ($provider -eq 'Microsoft-Windows-Kernel-General' -and $id -eq 12) { return 'Operating system started.' }
    if ($provider -eq 'Microsoft-Windows-Kernel-General' -and $id -eq 13) { return 'Operating system is shutting down.' }
    if ($provider -eq 'EventLog' -and $id -eq 6005) { return 'Event Log service started. Usually near boot.' }
    if ($provider -eq 'EventLog' -and $id -eq 6006) { return 'Event Log service stopped. Usually clean shutdown.' }
    if ($id -eq 1001 -and $msg -match 'BugCheck|BlueScreen|crash') { return 'Possible bugcheck / blue screen / crash record.' }
    if ($provider -like '*WindowsUpdateClient*') { return 'Windows Update event. Check update install/reboot timing.' }
    if ($provider -like '*UpdateOrchestrator*') { return 'Update Orchestrator event. Check if reboot was scheduled or requested after updates.' }
    if ($provider -like '*TaskScheduler*' -and $msg -match 'Update|Reboot|Restart|Uso|MoUso|WaaS|MusNotification') { return 'Scheduled task activity related to update/reboot keywords.' }
    if ($provider -eq 'Service Control Manager' -and $id -eq 7045) { return 'New service installed. Useful for endpoint/security/update agents that may force restart.' }
    if ($provider -eq 'Service Control Manager' -and $msg -match 'wuauserv|UsoSvc|WaaSMedic|TrustedInstaller|BITS|Delivery Optimization|DoSvc') { return 'Service state change for Windows Update / servicing related service.' }
    if ($msg -match 'restart now|reboot|restart|shutdown|Windows Update|Update Orchestrator|MusNotification|MoUso|USO') { return 'Message contains reboot/update keyword.' }
    return ''
}

function Convert-EventRecord {
    param($EventRecord)
    $message = ''
    try { $message = [string]$EventRecord.Message } catch { $message = '' }
    $messageOneLine = $message -replace "`r`n", ' | ' -replace "`n", ' | '
    if ($messageOneLine.Length -gt 32000) { $messageOneLine = $messageOneLine.Substring(0,32000) }

    $obj = [PSCustomObject]@{
        ComputerName         = $env:COMPUTERNAME
        TimeCreated          = $EventRecord.TimeCreated
        LogName              = $EventRecord.LogName
        ProviderName         = $EventRecord.ProviderName
        Id                   = $EventRecord.Id
        LevelDisplayName     = $EventRecord.LevelDisplayName
        TaskDisplayName      = $EventRecord.TaskDisplayName
        OpcodeDisplayName    = $EventRecord.OpcodeDisplayName
        RecordId             = $EventRecord.RecordId
        UserId               = $EventRecord.UserId
        MachineName          = $EventRecord.MachineName
        KeywordsDisplayNames = (($EventRecord.KeywordsDisplayNames) -join '; ')
        Hint                 = ''
        Message              = $messageOneLine
    }
    $obj.Hint = Get-EventHint -EventObject $obj
    return $obj
}

function Get-WinEventSafe {
    param(
        [string]$LogName,
        [int[]]$Id,
        [string]$ProviderName,
        [datetime]$Since = $StartTime,
        [datetime]$Until = $EndTime,
        [int]$MaxEvents = $MaxEventsPerLog
    )

    $exists = Invoke-Safe -Name "Check event log $LogName" -ScriptBlock { Get-WinEvent -ListLog $LogName -ErrorAction Stop } -Default $null
    if ($null -eq $exists) { return @() }

    $filter = @{ LogName = $LogName; StartTime = $Since; EndTime = $Until }
    if ($Id -and $Id.Count -gt 0) { $filter.Id = $Id }
    if (-not [string]::IsNullOrWhiteSpace($ProviderName)) { $filter.ProviderName = $ProviderName }

    $events = Invoke-Safe -Name "Read event log $LogName" -ScriptBlock {
        Get-WinEvent -FilterHashtable $filter -MaxEvents $MaxEvents -ErrorAction Stop
    } -Default @()

    $converted = @()
    foreach ($e in @($events)) {
        $converted += (Convert-EventRecord -EventRecord $e)
    }
    return $converted
}

function Add-EventsToGlobal {
    param($Events)
    foreach ($e in @($Events)) {
        try { $script:AllEvents.Add($e) | Out-Null } catch {}
    }
}

# -----------------------------
# System info
# -----------------------------
Write-Host "Collecting Infinity kiosk reboot diagnostics..."
Write-Host "Output folder: $OutRoot"

$OS = Get-CimOrWmi -ClassName Win32_OperatingSystem
$CS = Get-CimOrWmi -ClassName Win32_ComputerSystem
$BIOS = Get-CimOrWmi -ClassName Win32_BIOS
$BaseBoard = Get-CimOrWmi -ClassName Win32_BaseBoard
$LastBoot = $null
try { $LastBoot = Convert-WmiDateSafe $OS.LastBootUpTime } catch {}
$Uptime = $null
if ($LastBoot) { $Uptime = New-TimeSpan -Start $LastBoot -End (Get-Date) }

$Summary = [PSCustomObject]@{
    ComputerName         = $env:COMPUTERNAME
    Domain               = $env:USERDOMAIN
    User                 = $env:USERNAME
    IsAdmin              = $IsAdmin
    ScriptStart          = $ScriptStart
    DaysBack             = $DaysBack
    EventStartTime       = $StartTime
    EventEndTime         = $EndTime
    LastBootUpTime       = $LastBoot
    UptimeDays           = if ($Uptime) { [Math]::Round($Uptime.TotalDays,2) } else { $null }
    OSName               = $OS.Caption
    OSVersion            = $OS.Version
    OSBuildNumber        = $OS.BuildNumber
    OSArchitecture       = $OS.OSArchitecture
    InstallDate          = Convert-WmiDateSafe $OS.InstallDate
    Manufacturer         = $CS.Manufacturer
    Model                = $CS.Model
    SystemType           = $CS.SystemType
    TotalPhysicalMemoryGB= if ($CS.TotalPhysicalMemory) { [Math]::Round(($CS.TotalPhysicalMemory / 1GB),2) } else { $null }
    BIOSSerialNumber     = $BIOS.SerialNumber
    BIOSVersion          = (($BIOS.SMBIOSBIOSVersion, $BIOS.Version) -join ' | ')
    TimeZone             = ([TimeZoneInfo]::Local).Id
    OutputFolder         = $OutRoot
}
Export-JsonSafe -Data $Summary -Path (Join-Path $JsonDir '00_summary.json') -Depth 5
Export-CsvSafe -Data $Summary -Path (Join-Path $CsvDir '00_summary.csv')

# Basic system tables
$ComputerInfoLite = [PSCustomObject]@{
    OS                  = $OS
    ComputerSystem      = $CS
    BIOS                = $BIOS
    BaseBoard           = $BaseBoard
}
Export-JsonSafe -Data $ComputerInfoLite -Path (Join-Path $JsonDir '01_system_info_raw.json') -Depth 5

# Network and local users info
$IPConfig = Invoke-Safe -Name 'Get network adapters' -ScriptBlock {
    Get-CimInstance Win32_NetworkAdapterConfiguration -Filter "IPEnabled = True" -ErrorAction Stop |
        Select-Object Description,MACAddress,IPAddress,IPSubnet,DefaultIPGateway,DNSServerSearchOrder,DHCPEnabled,DHCPServer,DNSDomain
} -Default @()
Export-CsvSafe -Data $IPConfig -Path (Join-Path $CsvDir '02_network_ipconfig.csv')

Run-NativeCommand -Name 'ipconfig all' -CommandLine 'ipconfig /all' -OutputFile (Join-Path $TxtDir 'ipconfig_all.txt')
Run-NativeCommand -Name 'systeminfo' -CommandLine 'systeminfo' -OutputFile (Join-Path $TxtDir 'systeminfo.txt')
Run-NativeCommand -Name 'whoami all' -CommandLine 'whoami /all' -OutputFile (Join-Path $TxtDir 'whoami_all.txt')

# -----------------------------
# Pending reboot indicators
# -----------------------------
function Test-RegPathExists {
    param([string]$Path)
    try { return (Test-Path -LiteralPath $Path) } catch { return $false }
}

function Get-RegValueSafe {
    param([string]$Path,[string]$Name)
    try {
        $item = Get-ItemProperty -LiteralPath $Path -ErrorAction Stop
        return $item.$Name
    } catch { return $null }
}

$PendingRebootChecks = @(
    [PSCustomObject]@{ Indicator='CBS_RebootPending'; Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending'; Exists=(Test-RegPathExists 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending'); Value='' },
    [PSCustomObject]@{ Indicator='CBS_RebootInProgress'; Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootInProgress'; Exists=(Test-RegPathExists 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootInProgress'); Value='' },
    [PSCustomObject]@{ Indicator='CBS_PackagesPending'; Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackagesPending'; Exists=(Test-RegPathExists 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackagesPending'); Value='' },
    [PSCustomObject]@{ Indicator='WindowsUpdate_RebootRequired'; Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'; Exists=(Test-RegPathExists 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'); Value='' },
    [PSCustomObject]@{ Indicator='WindowsUpdate_PostRebootReporting'; Path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\PostRebootReporting'; Exists=(Test-RegPathExists 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\PostRebootReporting'); Value='' },
    [PSCustomObject]@{ Indicator='SessionManager_PendingFileRenameOperations'; Path='HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager'; Exists=$true; Value=((Get-RegValueSafe 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' 'PendingFileRenameOperations') -join ' | ') },
    [PSCustomObject]@{ Indicator='UpdateExeVolatile'; Path='HKLM:\SOFTWARE\Microsoft\Updates'; Exists=$true; Value=(Get-RegValueSafe 'HKLM:\SOFTWARE\Microsoft\Updates' 'UpdateExeVolatile') },
    [PSCustomObject]@{ Indicator='ComputerRename_Pending'; Path='HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName'; Exists=$true; Value=("{0} / {1}" -f (Get-RegValueSafe 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName' 'ComputerName'), (Get-RegValueSafe 'HKLM:\SYSTEM\CurrentControlSet\Control\ComputerName\ActiveComputerName' 'ComputerName')) }
)
Export-CsvSafe -Data $PendingRebootChecks -Path (Join-Path $CsvDir '10_pending_reboot_indicators.csv')
foreach ($p in $PendingRebootChecks) {
    if ($p.Exists -eq $true -and ($p.Indicator -notlike '*ComputerRename*')) {
        Add-Finding -Severity 'INFO' -Area 'Pending reboot' -Message ("Pending reboot indicator present: {0}" -f $p.Indicator) -Evidence $p.Path
    }
    if (($p.Indicator -eq 'SessionManager_PendingFileRenameOperations') -and -not [string]::IsNullOrWhiteSpace([string]$p.Value)) {
        Add-Finding -Severity 'INFO' -Area 'Pending reboot' -Message 'Pending file rename operations found.' -Evidence $p.Value
    }
}

# -----------------------------
# Registry policies and Windows Update configuration
# -----------------------------
function Export-RegistryTree {
    param([string]$RootPath,[string]$Name)
    $rows = New-Object System.Collections.Generic.List[object]
    Invoke-Safe -Name "Registry export $RootPath" -ScriptBlock {
        if (Test-Path -LiteralPath $RootPath) {
            $keys = @(Get-Item -LiteralPath $RootPath -ErrorAction SilentlyContinue) + @(Get-ChildItem -LiteralPath $RootPath -Recurse -ErrorAction SilentlyContinue)
            foreach ($k in $keys) {
                $props = Get-ItemProperty -LiteralPath $k.PSPath -ErrorAction SilentlyContinue
                foreach ($prop in $props.PSObject.Properties) {
                    if ($prop.Name -in @('PSPath','PSParentPath','PSChildName','PSDrive','PSProvider')) { continue }
                    $val = $prop.Value
                    if ($val -is [array]) { $val = $val -join ' | ' }
                    $rows.Add([PSCustomObject]@{
                        Root       = $RootPath
                        KeyPath    = $k.Name
                        Name       = $prop.Name
                        Value      = [string]$val
                        Type       = if ($null -ne $prop.Value) { $prop.Value.GetType().Name } else { '' }
                    }) | Out-Null
                }
            }
        } else {
            $rows.Add([PSCustomObject]@{Root=$RootPath;KeyPath='';Name='';Value='PATH NOT FOUND';Type=''}) | Out-Null
        }
    } | Out-Null
    Export-CsvSafe -Data $rows -Path (Join-Path $CsvDir ("registry_{0}.csv" -f $Name))
    return $rows.ToArray()
}

$RegPolicyRows = @()
$RegPolicyRows += Export-RegistryTree -RootPath 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' -Name 'windows_update_policies'
$RegPolicyRows += Export-RegistryTree -RootPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update' -Name 'windows_update_auto_update'
$RegPolicyRows += Export-RegistryTree -RootPath 'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings' -Name 'windows_update_ux_settings'
$RegPolicyRows += Export-RegistryTree -RootPath 'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\Update' -Name 'mdm_policy_update'
$RegPolicyRows += Export-RegistryTree -RootPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Config' -Name 'delivery_optimization_config'
$RegPolicyRows += Export-RegistryTree -RootPath 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -Name 'session_manager_power'
Export-CsvSafe -Data $RegPolicyRows -Path (Join-Path $CsvDir '11_all_registry_update_policy_rows.csv')

# Specific policy interpretation hints
$NoAutoReboot = ($RegPolicyRows | Where-Object { $_.Name -eq 'NoAutoRebootWithLoggedOnUsers' } | Select-Object -First 1)
$AUOptions = ($RegPolicyRows | Where-Object { $_.Name -eq 'AUOptions' } | Select-Object -First 1)
$AlwaysAutoReboot = ($RegPolicyRows | Where-Object { $_.Name -eq 'AlwaysAutoRebootAtScheduledTime' } | Select-Object -First 1)
$ActiveHoursStart = ($RegPolicyRows | Where-Object { $_.Name -eq 'ActiveHoursStart' } | Select-Object -First 1)
$ActiveHoursEnd = ($RegPolicyRows | Where-Object { $_.Name -eq 'ActiveHoursEnd' } | Select-Object -First 1)

if ($NoAutoReboot) { Add-Finding -Severity 'INFO' -Area 'Windows Update policy' -Message 'NoAutoRebootWithLoggedOnUsers was found in registry policy.' -Evidence ("Value={0}; Key={1}" -f $NoAutoReboot.Value,$NoAutoReboot.KeyPath) }
else { Add-Finding -Severity 'WARN' -Area 'Windows Update policy' -Message 'NoAutoRebootWithLoggedOnUsers was not found in collected policy keys.' -Evidence 'This does not prove it is disabled; verify GPO/MDM output.' }
if ($AUOptions) { Add-Finding -Severity 'INFO' -Area 'Windows Update policy' -Message 'AUOptions was found.' -Evidence ("Value={0}; Key={1}" -f $AUOptions.Value,$AUOptions.KeyPath) }
if ($AlwaysAutoReboot) { Add-Finding -Severity 'WARN' -Area 'Windows Update policy' -Message 'AlwaysAutoRebootAtScheduledTime was found. Review whether it can trigger automatic restart.' -Evidence ("Value={0}; Key={1}" -f $AlwaysAutoReboot.Value,$AlwaysAutoReboot.KeyPath) }
if ($ActiveHoursStart -or $ActiveHoursEnd) { Add-Finding -Severity 'INFO' -Area 'Windows Update UX' -Message 'Active Hours values were found.' -Evidence ("Start={0}; End={1}" -f $ActiveHoursStart.Value,$ActiveHoursEnd.Value) }

# Group Policy report
Run-NativeCommand -Name 'gpresult computer text' -CommandLine 'gpresult /scope computer /r' -OutputFile (Join-Path $TxtDir 'gpresult_computer_r.txt')
Run-NativeCommand -Name 'gpresult user text' -CommandLine 'gpresult /scope user /r' -OutputFile (Join-Path $TxtDir 'gpresult_user_r.txt')
Run-NativeCommand -Name 'gpresult html' -CommandLine ('gpresult /h "{0}" /f' -f (Join-Path $HtmlDir 'gpresult.html')) -OutputFile (Join-Path $TxtDir 'gpresult_html_command_output.txt')

# -----------------------------
# Services, processes, startup items, suspicious auth/GateKeeper clues
# -----------------------------
$ServiceRows = Invoke-Safe -Name 'Collect services' -ScriptBlock {
    $svcWmi = Get-CimOrWmi -ClassName Win32_Service
    $svcWmi | Select-Object Name,DisplayName,State,StartMode,StartName,PathName,ServiceType,ProcessId,Description
} -Default @()
Export-CsvSafe -Data $ServiceRows -Path (Join-Path $CsvDir '20_services.csv')

$InterestingServiceRows = @($ServiceRows | Where-Object { $_.Name -match 'wuauserv|UsoSvc|WaaSMedic|BITS|DoSvc|TrustedInstaller|InstallService|uhssvc|edgeupdate|gupdate|Gate|Keeper|Token|Credential|Smart|Card|Auth|Sentinel|Crowd|Defender|SCCM|CCM|ConfigMgr|Intune|Management|Ivanti|Landesk|BigFix|Tanium|Carbon|Qualys|Nessus' -or $_.DisplayName -match 'Windows Update|Update Orchestrator|Medic|Delivery Optimization|Gate|Keeper|Token|Credential|Smart|Card|Auth|Sentinel|Crowd|Defender|Configuration Manager|Intune|Ivanti|BigFix|Tanium|Carbon|Qualys|Nessus' })
Export-CsvSafe -Data $InterestingServiceRows -Path (Join-Path $CsvDir '21_interesting_services_update_auth_security.csv')

$ProcessRows = Invoke-Safe -Name 'Collect processes with command line' -ScriptBlock {
    Get-CimOrWmi -ClassName Win32_Process |
        Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine,CreationDate
} -Default @()
Export-CsvSafe -Data $ProcessRows -Path (Join-Path $CsvDir '22_processes_with_commandline.csv')

$InterestingProcessRows = @($ProcessRows | Where-Object { $_.Name -match 'MusNotification|MoUso|UsoClient|TiWorker|TrustedInstaller|WaaSMedic|wuauclt|svchost|shutdown|restart|Gate|Keeper|Token|Credential|Smart|Card|Auth|GeneXpert|Infinity' -or $_.CommandLine -match 'MusNotification|MoUso|UsoClient|TiWorker|TrustedInstaller|WaaSMedic|WindowsUpdate|shutdown|restart|reboot|Gate|Keeper|Token|Credential|Smart|Card|Auth|GeneXpert|Infinity' })
Export-CsvSafe -Data $InterestingProcessRows -Path (Join-Path $CsvDir '23_interesting_processes_update_auth_infinity.csv')

$StartupRows = Invoke-Safe -Name 'Collect startup commands' -ScriptBlock {
    Get-CimOrWmi -ClassName Win32_StartupCommand | Select-Object Name,Command,Location,User,Caption,Description
} -Default @()
Export-CsvSafe -Data $StartupRows -Path (Join-Path $CsvDir '24_startup_commands.csv')

# Installed programs. This does NOT use Win32_Product because that can trigger MSI repair actions.
function Get-InstalledProgramsFromRegistry {
    $paths = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall'
    )
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($path in $paths) {
        Invoke-Safe -Name "Installed programs $path" -ScriptBlock {
            if (Test-Path -LiteralPath $path) {
                Get-ChildItem -LiteralPath $path -ErrorAction SilentlyContinue | ForEach-Object {
                    $p = Get-ItemProperty -LiteralPath $_.PSPath -ErrorAction SilentlyContinue
                    if ($p.DisplayName) {
                        $rows.Add([PSCustomObject]@{
                            RegistryPath     = $_.Name
                            DisplayName      = $p.DisplayName
                            DisplayVersion   = $p.DisplayVersion
                            Publisher        = $p.Publisher
                            InstallDate      = $p.InstallDate
                            InstallLocation  = $p.InstallLocation
                            UninstallString  = $p.UninstallString
                        }) | Out-Null
                    }
                }
            }
        } | Out-Null
    }
    return $rows.ToArray()
}
$InstalledPrograms = Get-InstalledProgramsFromRegistry
Export-CsvSafe -Data $InstalledPrograms -Path (Join-Path $CsvDir '25_installed_programs_registry.csv')
$InterestingPrograms = @($InstalledPrograms | Where-Object { $_.DisplayName -match 'Gate|Keeper|Token|Credential|Smart|Card|Auth|GeneXpert|Infinity|Cepheid|Windows Update|Update|Defender|Sentinel|Crowd|Configuration Manager|SCCM|Intune|Ivanti|BigFix|Tanium|Qualys|Nessus|Carbon' -or $_.Publisher -match 'Cepheid|Danaher|Microsoft|Sentinel|Crowd|Ivanti|Tanium|Qualys|BigFix|Carbon' })
Export-CsvSafe -Data $InterestingPrograms -Path (Join-Path $CsvDir '26_interesting_installed_programs.csv')

# -----------------------------
# Scheduled tasks
# -----------------------------
$TaskRows = New-Object System.Collections.Generic.List[object]
$script:GetScheduledTaskAvailable = $false
Invoke-Safe -Name 'Check Get-ScheduledTask' -ScriptBlock {
    if (Get-Command Get-ScheduledTask -ErrorAction SilentlyContinue) { $script:GetScheduledTaskAvailable = $true }
} | Out-Null

if ($script:GetScheduledTaskAvailable) {
    Invoke-Safe -Name 'Collect scheduled tasks using Get-ScheduledTask' -ScriptBlock {
        $tasks = Get-ScheduledTask -ErrorAction Stop
        foreach ($t in $tasks) {
            $info = $null
            try { $info = Get-ScheduledTaskInfo -TaskName $t.TaskName -TaskPath $t.TaskPath -ErrorAction Stop } catch {}
            $actions = @()
            foreach ($a in @($t.Actions)) {
                $actions += (([string]$a.Execute) + ' ' + ([string]$a.Arguments)).Trim()
            }
            $triggers = @()
            foreach ($tr in @($t.Triggers)) { $triggers += ($tr | Out-String).Trim() }
            $TaskRows.Add([PSCustomObject]@{
                TaskPath      = $t.TaskPath
                TaskName      = $t.TaskName
                State         = $t.State
                LastRunTime   = if ($info) { $info.LastRunTime } else { $null }
                LastTaskResult= if ($info) { $info.LastTaskResult } else { $null }
                NextRunTime   = if ($info) { $info.NextRunTime } else { $null }
                NumberOfMissedRuns = if ($info) { $info.NumberOfMissedRuns } else { $null }
                Author        = $t.Author
                URI           = $t.URI
                Actions       = ($actions -join ' | ')
                Triggers      = ($triggers -join ' | ')
                Description   = $t.Description
            }) | Out-Null
        }
    } | Out-Null
}

# Fallback/extra raw schtasks output
Run-NativeCommand -Name 'schtasks query csv verbose' -CommandLine 'schtasks /Query /V /FO CSV' -OutputFile (Join-Path $TxtDir 'schtasks_query_verbose.csv.txt')
Export-CsvSafe -Data $TaskRows -Path (Join-Path $CsvDir '30_scheduled_tasks.csv')

$InterestingTaskRows = @($TaskRows | Where-Object {
    ($_.TaskPath + $_.TaskName + $_.Actions + $_.Description) -match 'Update|Orchestrator|Reboot|Restart|USO|MoUso|MusNotification|WaaS|WindowsUpdate|Install|Servicing|Maintenance|Gate|Keeper|Token|Credential|Auth|Cepheid|GeneXpert|Infinity'
})
Export-CsvSafe -Data $InterestingTaskRows -Path (Join-Path $CsvDir '31_interesting_scheduled_tasks_update_reboot_auth.csv')

foreach ($t in $InterestingTaskRows) {
    if (($t.TaskPath + $t.TaskName) -match 'UpdateOrchestrator' -and ($t.TaskName -match 'Reboot|Restart|Schedule|USO|Mus')) {
        Add-Finding -Severity 'INFO' -Area 'Scheduled Tasks' -Message ('Update/reboot-related scheduled task found: {0}{1}' -f $t.TaskPath,$t.TaskName) -Evidence ("State={0}; LastRun={1}; NextRun={2}; Result={3}; Actions={4}" -f $t.State,$t.LastRunTime,$t.NextRunTime,$t.LastTaskResult,$t.Actions)
    }
}

# -----------------------------
# Power, crash dump, update history
# -----------------------------
Run-NativeCommand -Name 'powercfg lastwake' -CommandLine 'powercfg /lastwake' -OutputFile (Join-Path $TxtDir 'powercfg_lastwake.txt')
Run-NativeCommand -Name 'powercfg waketimers' -CommandLine 'powercfg /waketimers' -OutputFile (Join-Path $TxtDir 'powercfg_waketimers.txt')
Run-NativeCommand -Name 'powercfg requests' -CommandLine 'powercfg /requests' -OutputFile (Join-Path $TxtDir 'powercfg_requests.txt')
Run-NativeCommand -Name 'powercfg active scheme' -CommandLine 'powercfg /getactivescheme' -OutputFile (Join-Path $TxtDir 'powercfg_active_scheme.txt')
Run-NativeCommand -Name 'powercfg available sleep states' -CommandLine 'powercfg /a' -OutputFile (Join-Path $TxtDir 'powercfg_available_sleep_states.txt')
Run-NativeCommand -Name 'powercfg q' -CommandLine 'powercfg /q' -OutputFile (Join-Path $TxtDir 'powercfg_full_q.txt')

$CrashControl = Export-RegistryTree -RootPath 'HKLM:\SYSTEM\CurrentControlSet\Control\CrashControl' -Name 'crashcontrol'
$DumpFiles = Invoke-Safe -Name 'Collect dump file list' -ScriptBlock {
    $dumpCandidates = @('C:\Windows\MEMORY.DMP','C:\Windows\Minidump')
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($d in $dumpCandidates) {
        if (Test-Path -LiteralPath $d) {
            Get-ChildItem -LiteralPath $d -ErrorAction SilentlyContinue | ForEach-Object {
                $rows.Add([PSCustomObject]@{
                    FullName      = $_.FullName
                    Name          = $_.Name
                    LengthMB      = [Math]::Round(($_.Length / 1MB),2)
                    CreationTime  = $_.CreationTime
                    LastWriteTime = $_.LastWriteTime
                }) | Out-Null
            }
            if ((Get-Item -LiteralPath $d -ErrorAction SilentlyContinue).PSIsContainer -eq $false) {
                $f = Get-Item -LiteralPath $d -ErrorAction SilentlyContinue
                if ($f) {
                    $rows.Add([PSCustomObject]@{FullName=$f.FullName;Name=$f.Name;LengthMB=[Math]::Round(($f.Length / 1MB),2);CreationTime=$f.CreationTime;LastWriteTime=$f.LastWriteTime}) | Out-Null
                }
            }
        }
    }
    return $rows.ToArray()
} -Default @()
Export-CsvSafe -Data $DumpFiles -Path (Join-Path $CsvDir '40_crash_dump_files.csv')
if (@($DumpFiles).Count -gt 0) { Add-Finding -Severity 'INFO' -Area 'Crash dumps' -Message 'Crash dump files were found. Review timestamps against reboot timeline.' -Evidence ((@($DumpFiles | Select-Object -First 5 | ForEach-Object { $_.FullName + ' ' + $_.LastWriteTime }) -join ' | ')) }

$HotFixes = Invoke-Safe -Name 'Get-HotFix' -ScriptBlock {
    Get-HotFix -ErrorAction Stop | Sort-Object InstalledOn -Descending | Select-Object HotFixID,Description,InstalledBy,InstalledOn,Caption,CSName
} -Default @()
Export-CsvSafe -Data $HotFixes -Path (Join-Path $CsvDir '41_hotfixes.csv')
Run-NativeCommand -Name 'DISM packages' -CommandLine 'dism /online /get-packages /format:table' -OutputFile (Join-Path $TxtDir 'dism_online_get_packages.txt')
Run-NativeCommand -Name 'WMIC QFE' -CommandLine 'wmic qfe list full /format:list' -OutputFile (Join-Path $TxtDir 'wmic_qfe_list_full.txt')

if (-not $SkipWindowsUpdateLog) {
    Invoke-Safe -Name 'Get-WindowsUpdateLog' -ScriptBlock {
        if (Get-Command Get-WindowsUpdateLog -ErrorAction SilentlyContinue) {
            $wuLog = Join-Path $TxtDir 'WindowsUpdate_converted.log'
            Get-WindowsUpdateLog -LogPath $wuLog -ErrorAction Stop | Out-Null
        } else {
            Add-Finding -Severity 'INFO' -Area 'Windows Update log' -Message 'Get-WindowsUpdateLog command was not available.' -Evidence ''
        }
    } | Out-Null
}

# Copy common update/setup text logs if present, no failure if absent
$LogCopyList = @(
    'C:\Windows\WindowsUpdate.log',
    'C:\Windows\Logs\CBS\CBS.log',
    'C:\Windows\Logs\DISM\dism.log',
    'C:\Windows\Panther\setupact.log',
    'C:\Windows\Panther\setuperr.log'
)
foreach ($src in $LogCopyList) {
    Invoke-Safe -Name "Copy log $src" -ScriptBlock {
        if (Test-Path -LiteralPath $src) {
            $dest = Join-Path $RawDir ((Split-Path $src -Leaf) -replace '[^A-Za-z0-9_.-]', '_')
            Copy-Item -LiteralPath $src -Destination $dest -Force -ErrorAction Stop
        }
    } | Out-Null
}

# -----------------------------
# Reliability records
# -----------------------------
$ReliabilityRecords = Invoke-Safe -Name 'Win32_ReliabilityRecords' -ScriptBlock {
    $all = Get-WmiObject -Namespace 'root\cimv2' -Class Win32_ReliabilityRecords -ErrorAction Stop
    $rows = foreach ($r in $all) {
        $t = Convert-WmiDateSafe $r.TimeGenerated
        if ($t -ge $StartTime -and $t -le $EndTime) {
            [PSCustomObject]@{
                TimeGenerated = $t
                SourceName    = $r.SourceName
                ProductName   = $r.ProductName
                EventIdentifier = $r.EventIdentifier
                Message       = (($r.Message) -replace "`r`n", ' | ' -replace "`n", ' | ')
                InsertionStrings = (($r.InsertionStrings) -join ' | ')
            }
        }
    }
    $rows | Sort-Object TimeGenerated -Descending
} -Default @()
Export-CsvSafe -Data $ReliabilityRecords -Path (Join-Path $CsvDir '50_reliability_records.csv')

# -----------------------------
# Event log collection
# -----------------------------
Write-Host "Collecting event logs from $StartTime to $EndTime ..."

# Core System reboot/shutdown/update events
$SystemCoreIds = @(1,12,13,19,20,21,22,25,27,31,41,42,43,44,55,1001,1074,109,6005,6006,6008,7040,7045,7031,7034,7036)
$SystemEvents = Get-WinEventSafe -LogName 'System' -Id $SystemCoreIds -Since $StartTime -Until $EndTime -MaxEvents $MaxEventsPerLog
Add-EventsToGlobal $SystemEvents
Export-CsvSafe -Data ($SystemEvents | Sort-Object TimeCreated -Descending) -Path (Join-Path $CsvDir '60_events_system_core_reboot_shutdown_update.csv')

# Full System keyword scan around update/reboot terms. Get broad events then filter in PowerShell.
$SystemBroad = Get-WinEventSafe -LogName 'System' -Since $StartTime -Until $EndTime -MaxEvents $MaxEventsPerLog
$SystemKeyword = @($SystemBroad | Where-Object { $_.Message -match 'restart|reboot|shutdown|Windows Update|Update Orchestrator|MusNotification|MoUso|USO|WaaS|wuauserv|UsoSvc|WaaSMedic|TrustedInstaller|BITS|power|bugcheck|crash|unexpected' -or $_.ProviderName -match 'WindowsUpdate|Kernel-Power|User32|EventLog|Kernel-General' })
Add-EventsToGlobal $SystemKeyword
Export-CsvSafe -Data ($SystemKeyword | Sort-Object TimeCreated -Descending) -Path (Join-Path $CsvDir '61_events_system_keyword_reboot_update_power.csv')

# Dedicated operational logs
$OperationalLogNames = @(
    'Microsoft-Windows-WindowsUpdateClient/Operational',
    'Microsoft-Windows-UpdateOrchestrator/Operational',
    'Microsoft-Windows-TaskScheduler/Operational',
    'Microsoft-Windows-Servicing/Operational',
    'Microsoft-Windows-Diagnostics-Performance/Operational',
    'Microsoft-Windows-Bits-Client/Operational',
    'Microsoft-Windows-User Device Registration/Admin',
    'Setup',
    'Application'
)

foreach ($log in $OperationalLogNames) {
    $events = Get-WinEventSafe -LogName $log -Since $StartTime -Until $EndTime -MaxEvents $MaxEventsPerLog
    if ($log -eq 'Microsoft-Windows-TaskScheduler/Operational') {
        $events = @($events | Where-Object { $_.Message -match 'Update|Orchestrator|Reboot|Restart|USO|MoUso|MusNotification|WaaS|WindowsUpdate|shutdown|Gate|Keeper|Token|Credential|Auth|Cepheid|GeneXpert|Infinity' -or $_.ProviderName -match 'TaskScheduler' })
    }
    if ($log -eq 'Application') {
        $events = @($events | Where-Object { $_.Message -match 'restart|reboot|shutdown|Windows Update|bugcheck|crash|fault|GeneXpert|Infinity|Cepheid|Gate|Keeper|Token|Credential|Auth' -or $_.ProviderName -match 'Windows Error Reporting|Application Error|RestartManager|MsiInstaller' })
    }
    Add-EventsToGlobal $events
    $safeName = ($log -replace '[\\/ :]', '_' -replace '[^A-Za-z0-9_.-]', '_')
    Export-CsvSafe -Data ($events | Sort-Object TimeCreated -Descending) -Path (Join-Path $CsvDir ("62_events_{0}.csv" -f $safeName))
}

# Extract likely restart prompt / update UI events
$PromptClues = @($script:AllEvents | Where-Object {
    $_.Message -match 'restart now|restart required|reboot required|restart your device|restart your PC|needs to restart|active hours|scheduled restart|deadline|notification|MusNotification|MoUso|USO|Update Orchestrator'
} | Sort-Object TimeCreated -Descending)
Export-CsvSafe -Data $PromptClues -Path (Join-Path $CsvDir '63_events_restart_prompt_clues.csv')
if (@($PromptClues).Count -gt 0) {
    Add-Finding -Severity 'INFO' -Area 'Restart prompt clues' -Message ('Found {0} event(s) containing restart prompt / notification keywords.' -f @($PromptClues).Count) -Evidence 'See CSV\63_events_restart_prompt_clues.csv'
}

# De-duplicate global event timeline
$Timeline = @($script:AllEvents | Sort-Object TimeCreated,LogName,ProviderName,Id,RecordId -Unique | Sort-Object TimeCreated -Descending)
Export-CsvSafe -Data $Timeline -Path (Join-Path $CsvDir '64_events_combined_timeline.csv')
Export-JsonSafe -Data ($Timeline | Select-Object -First 1000) -Path (Join-Path $JsonDir '64_events_combined_timeline_first1000.json') -Depth 5

# Create focused reboot marker timeline +/- 6 hours around shutdown/start markers
$Markers = @($Timeline | Where-Object {
    ($_.ProviderName -eq 'User32' -and $_.Id -eq 1074) -or
    ($_.ProviderName -eq 'EventLog' -and ($_.Id -in @(6005,6006,6008))) -or
    ($_.ProviderName -eq 'Microsoft-Windows-Kernel-Power' -and $_.Id -eq 41) -or
    ($_.ProviderName -eq 'Microsoft-Windows-Kernel-General' -and ($_.Id -in @(12,13))) -or
    ($_.Id -eq 1001 -and $_.Message -match 'BugCheck|BlueScreen|crash')
} | Sort-Object TimeCreated -Descending)
Export-CsvSafe -Data $Markers -Path (Join-Path $CsvDir '65_reboot_shutdown_markers.csv')

$WindowRows = New-Object System.Collections.Generic.List[object]
foreach ($m in $Markers | Select-Object -First 25) {
    $from = ([datetime]$m.TimeCreated).AddHours(-6)
    $to = ([datetime]$m.TimeCreated).AddHours(6)
    $nearby = @($Timeline | Where-Object { $_.TimeCreated -ge $from -and $_.TimeCreated -le $to } | Sort-Object TimeCreated)
    foreach ($n in $nearby) {
        $WindowRows.Add([PSCustomObject]@{
            MarkerTime     = $m.TimeCreated
            MarkerProvider = $m.ProviderName
            MarkerId       = $m.Id
            MarkerMessage  = $m.Message
            EventTime      = $n.TimeCreated
            MinutesFromMarker = [Math]::Round((New-TimeSpan -Start ([datetime]$m.TimeCreated) -End ([datetime]$n.TimeCreated)).TotalMinutes,1)
            LogName        = $n.LogName
            ProviderName   = $n.ProviderName
            Id             = $n.Id
            Hint           = $n.Hint
            Message        = $n.Message
        }) | Out-Null
    }
}
Export-CsvSafe -Data $WindowRows -Path (Join-Path $CsvDir '66_timeline_windows_around_reboot_markers.csv')

# Add findings based on markers
foreach ($e in $Markers | Select-Object -First 20) {
    if ($e.ProviderName -eq 'User32' -and $e.Id -eq 1074) {
        Add-Finding -Severity 'HIGH' -Area 'Reboot marker' -Message ('Planned restart/shutdown event 1074 found at {0}.' -f $e.TimeCreated) -Evidence $e.Message
    } elseif ($e.Id -eq 6008) {
        Add-Finding -Severity 'HIGH' -Area 'Reboot marker' -Message ('Unexpected shutdown event 6008 found at {0}.' -f $e.TimeCreated) -Evidence $e.Message
    } elseif ($e.ProviderName -eq 'Microsoft-Windows-Kernel-Power' -and $e.Id -eq 41) {
        Add-Finding -Severity 'HIGH' -Area 'Reboot marker' -Message ('Kernel-Power 41 found at {0}.' -f $e.TimeCreated) -Evidence $e.Message
    } elseif ($e.Id -eq 1001 -and $e.Message -match 'BugCheck|BlueScreen|crash') {
        Add-Finding -Severity 'HIGH' -Area 'Crash marker' -Message ('Possible bugcheck/crash record found at {0}.' -f $e.TimeCreated) -Evidence $e.Message
    }
}

# Optional EVTX exports. Raw event logs can be big but useful for IT.
if ($IncludeEvtxExport) {
    $EvtxDir = Join-Path $OutRoot 'EVTX'
    New-Item -Path $EvtxDir -ItemType Directory -Force | Out-Null
    $EvtxLogs = @('System','Application','Setup','Microsoft-Windows-WindowsUpdateClient/Operational','Microsoft-Windows-UpdateOrchestrator/Operational','Microsoft-Windows-TaskScheduler/Operational','Microsoft-Windows-Servicing/Operational')
    foreach ($log in $EvtxLogs) {
        $safe = ($log -replace '[\\/ :]', '_' -replace '[^A-Za-z0-9_.-]', '_')
        $dest = Join-Path $EvtxDir ("{0}.evtx" -f $safe)
        Run-NativeCommand -Name "wevtutil export $log" -CommandLine ('wevtutil epl "{0}" "{1}" /ow:true' -f $log,$dest) -OutputFile (Join-Path $TxtDir ("wevtutil_export_{0}.txt" -f $safe))
    }
}

# -----------------------------
# HTML report
# -----------------------------
function Convert-DataToHtmlFragment {
    param($Data,[string]$Title,[int]$First = 200)
    $arr = @(ConvertTo-SafeObjectArray -Data $Data | Select-Object -First $First)
    if ($arr.Count -eq 0) { return "<h2>$Title</h2><p>No rows collected.</p>" }
    return ($arr | ConvertTo-Html -Fragment -PreContent "<h2>$Title</h2>")
}

# Export findings and errors before HTML
Export-CsvSafe -Data $script:Findings -Path (Join-Path $CsvDir '00_FINDINGS_read_this_first.csv')
Export-CsvSafe -Data $script:Errors -Path (Join-Path $CsvDir '00_collection_errors.csv')
Export-JsonSafe -Data $script:Findings -Path (Join-Path $JsonDir '00_FINDINGS_read_this_first.json') -Depth 5

$Readme = @"
Infinity kiosk reboot diagnostics
=================================
Computer: $ComputerName
Collected: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
Script: Collect-InfinityKioskRebootDiag.ps1
Version: 1.1
DaysBack: $DaysBack
Admin: $IsAdmin

What to review first
--------------------
1. HTML\InfinityKiosk_RebootDiag_Report.html
2. CSV\00_FINDINGS_read_this_first.csv
3. CSV\65_reboot_shutdown_markers.csv
4. CSV\66_timeline_windows_around_reboot_markers.csv
5. CSV\63_events_restart_prompt_clues.csv
6. CSV\10_pending_reboot_indicators.csv
7. CSV\11_all_registry_update_policy_rows.csv
8. CSV\31_interesting_scheduled_tasks_update_reboot_auth.csv
9. CSV\21_interesting_services_update_auth_security.csv
10. TXT\gpresult_computer_r.txt and HTML\gpresult.html

Important interpretation notes
------------------------------
- Event ID 1074 / Provider User32 is often the best clue for a planned restart because the message can name the process and user.
- Event ID 6008 and Kernel-Power 41 point to unclean/abrupt shutdown but do not by themselves prove root cause.
- Windows Update reboot prompts may appear even if some automatic update settings are restricted; policy, MDM, active hours, deadlines, Update Orchestrator and pending reboot state all need to be reviewed together.
- This script is read-only. It does not disable updates or change scheduled tasks.
- If this was not run as Administrator, some data may be missing.

Upload/share the ZIP file if you want someone else to review the evidence.
"@
Out-TextSafe -Text $Readme -Path (Join-Path $OutRoot 'README_FIRST.txt')

$css = @"
<style>
body { font-family: Segoe UI, Arial, sans-serif; margin: 20px; }
h1 { color: #1f2937; }
h2 { margin-top: 28px; color: #374151; border-bottom: 1px solid #ddd; padding-bottom: 4px; }
table { border-collapse: collapse; width: 100%; font-size: 12px; }
th, td { border: 1px solid #ddd; padding: 5px; vertical-align: top; }
th { background: #f3f4f6; }
tr:nth-child(even) { background: #fafafa; }
.warn { padding: 10px; background: #fff7ed; border: 1px solid #fdba74; }
.small { color: #666; font-size: 12px; }
</style>
"@

$htmlParts = @()
$htmlParts += "<html><head><meta charset='utf-8'><title>Infinity Kiosk Reboot Diagnostics</title>$css</head><body>"
$htmlParts += "<h1>Infinity Kiosk Reboot Diagnostics</h1>"
$htmlParts += "<p class='small'>Computer: <b>$ComputerName</b> | Collected: <b>$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</b> | DaysBack: <b>$DaysBack</b> | Admin: <b>$IsAdmin</b></p>"
if (-not $IsAdmin) { $htmlParts += "<div class='warn'><b>Warning:</b> Script was not run elevated. Some logs, policy and registry data may be incomplete.</div>" }
$htmlParts += Convert-DataToHtmlFragment -Data $Summary -Title 'Summary' -First 10
$htmlParts += Convert-DataToHtmlFragment -Data $script:Findings -Title 'Findings / flags to review first' -First 300
$htmlParts += Convert-DataToHtmlFragment -Data ($Markers | Select-Object -First 100) -Title 'Reboot / shutdown markers' -First 100
$htmlParts += Convert-DataToHtmlFragment -Data ($PromptClues | Select-Object -First 100) -Title 'Restart prompt / notification clues' -First 100
$htmlParts += Convert-DataToHtmlFragment -Data $PendingRebootChecks -Title 'Pending reboot indicators' -First 100
$htmlParts += Convert-DataToHtmlFragment -Data $InterestingTaskRows -Title 'Interesting scheduled tasks: update/reboot/auth/instrument keywords' -First 200
$htmlParts += Convert-DataToHtmlFragment -Data $InterestingServiceRows -Title 'Interesting services: update/auth/security keywords' -First 200
$htmlParts += Convert-DataToHtmlFragment -Data $InterestingPrograms -Title 'Interesting installed programs' -First 200
$htmlParts += Convert-DataToHtmlFragment -Data ($Timeline | Select-Object -First 300) -Title 'Combined event timeline, newest first' -First 300
$htmlParts += Convert-DataToHtmlFragment -Data $script:Errors -Title 'Collection errors, if any' -First 300
$htmlParts += "</body></html>"
$htmlReport = Join-Path $HtmlDir 'InfinityKiosk_RebootDiag_Report.html'
Out-TextSafe -Text ($htmlParts -join "`r`n") -Path $htmlReport

# -----------------------------
# Final packaging
# -----------------------------
try { Stop-Transcript | Out-Null } catch {}

$ZipPath = Join-Path $Desktop ("InfinityKiosk_RebootDiag_{0}_{1}.zip" -f $SafeComputerName,$Stamp)
Invoke-Safe -Name 'Create ZIP package' -ScriptBlock {
    if (Get-Command Compress-Archive -ErrorAction SilentlyContinue) {
        Compress-Archive -Path (Join-Path $OutRoot '*') -DestinationPath $ZipPath -Force -ErrorAction Stop
    } else {
        Add-Finding -Severity 'WARN' -Area 'ZIP' -Message 'Compress-Archive not available. Output folder was created but ZIP was not created.' -Evidence $OutRoot
    }
} | Out-Null

Write-Host ''
Write-Host 'DONE.' -ForegroundColor Green
Write-Host "Output folder: $OutRoot"
Write-Host "ZIP package:   $ZipPath"
Write-Host ''
Write-Host 'Open first:'
Write-Host "  $htmlReport"
Write-Host "  $(Join-Path $CsvDir '00_FINDINGS_read_this_first.csv')"
Write-Host ''
Write-Host 'Run command example:'
Write-Host '  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Collect-InfinityKioskRebootDiag.ps1 -DaysBack 90'
