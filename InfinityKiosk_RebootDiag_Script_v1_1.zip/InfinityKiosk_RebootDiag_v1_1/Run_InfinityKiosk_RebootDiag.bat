@echo off
setlocal EnableExtensions

title Infinity Kiosk Reboot Diagnostic

echo ============================================================
echo  Infinity Kiosk Reboot Diagnostic Launcher
echo ============================================================
echo.

REM Keep this BAT/CMD file in the same folder as Collect-InfinityKioskRebootDiag.ps1
set "SCRIPT_DIR=%~dp0"
set "PS_SCRIPT=%SCRIPT_DIR%Collect-InfinityKioskRebootDiag.ps1"
set "DAYS_BACK=90"
set "INCLUDE_EVTX=1"
set "LAUNCH_LOG=%USERPROFILE%\Desktop\InfinityKiosk_RebootDiag_Launcher.log"

if not exist "%PS_SCRIPT%" (
    echo ERROR: Could not find the PowerShell script:
    echo "%PS_SCRIPT%"
    echo.
    echo Put this launcher in the SAME folder as:
    echo Collect-InfinityKioskRebootDiag.ps1
    echo.
    pause
    exit /b 1
)

REM Prefer real 64-bit PowerShell. Sysnative works when this launcher is started from a 32-bit process.
if exist "%WINDIR%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" (
    set "PSEXE=%WINDIR%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
) else (
    set "PSEXE=%WINDIR%\System32\WindowsPowerShell\v1.0\powershell.exe"
)

if not exist "%PSEXE%" (
    echo ERROR: Could not find powershell.exe
    pause
    exit /b 1
)

(
    echo ============================================================
    echo Infinity Kiosk Reboot Diagnostic Launcher
    echo Started: %DATE% %TIME%
    echo Computer: %COMPUTERNAME%
    echo User: %USERDOMAIN%\%USERNAME%
    echo PowerShell: %PSEXE%
    echo Script: %PS_SCRIPT%
    echo ============================================================
) > "%LAUNCH_LOG%"

echo PowerShell:
echo %PSEXE%
echo.
echo Script:
echo %PS_SCRIPT%
echo.
echo Launcher log:
echo %LAUNCH_LOG%
echo.

net session >nul 2>&1
if "%ERRORLEVEL%"=="0" (
    echo Admin check: running elevated.
    echo Admin check: running elevated. >> "%LAUNCH_LOG%"
) else (
    echo WARNING: Not running as administrator. Script will continue, but some data may be missing.
    echo WARNING: Not running as administrator. >> "%LAUNCH_LOG%"
)

echo.
echo Running collection. Do not close this window until it says DONE.
echo.

if "%INCLUDE_EVTX%"=="1" (
    "%PSEXE%" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%" -DaysBack %DAYS_BACK% -IncludeEvtxExport >> "%LAUNCH_LOG%" 2>&1
) else (
    "%PSEXE%" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%" -DaysBack %DAYS_BACK% >> "%LAUNCH_LOG%" 2>&1
)

set "EXITCODE=%ERRORLEVEL%"

echo. >> "%LAUNCH_LOG%"
echo Finished: %DATE% %TIME% >> "%LAUNCH_LOG%"
echo Exit code: %EXITCODE% >> "%LAUNCH_LOG%"

echo.
echo ============================================================
echo  DONE
echo ============================================================
echo Exit code: %EXITCODE%
echo.
echo Check Desktop for the InfinityKiosk_RebootDiag folder/zip.
echo Launcher log: %LAUNCH_LOG%
echo.
pause
exit /b %EXITCODE%
