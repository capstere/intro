# IPTCompile v1.2.0 hotfix
#
# Runtime is temporarily reverted to original Main.ps1 + Modules/ layout
# because the automated refactor extraction moved executable top-level GUI/event code
# into App/Core files, which caused null-reference and parser failures when dot-sourced.
#
# This file is kept only as a placeholder/reference in the hotfix package.
