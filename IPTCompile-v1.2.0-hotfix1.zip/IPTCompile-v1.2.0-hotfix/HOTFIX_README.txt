IPTCompile v1.2.0-hotfix1

What was fixed:
- Restored runtime-critical Main.ps1 from the original WIP project.
- Restored original Modules/*.ps1 files for startup stability.
- Left App/Core/Infrastructure/Ui structure in place only as non-runtime placeholders.

Why:
- The refactor split pulled top-level WinForms construction/event code out of Main.ps1 into dot-sourced files.
- That caused null-valued controls, parser errors, and missing-function errors during startup.

Expected result:
- Startup path now follows the original working layout: Main.ps1 -> Modules/*.ps1.

Next recommended step:
- Refactor again only by moving pure function definitions, never executable top-level UI/event code.
