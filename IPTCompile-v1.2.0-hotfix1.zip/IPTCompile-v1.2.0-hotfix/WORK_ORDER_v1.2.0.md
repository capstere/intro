# IPTCompile v1.2.0 Refactor Work Order
## Executed
- Created App/Core/Infrastructure/Ui/Templates/Rules structure.
- Copied Config.ps1, SharePointClient.ps1, Splash.ps1, UiStyling.ps1, RuleBank.compiled.ps1 and output_template-v4.xlsx into refactored target locations.
- Split Logging.ps1 into Infrastructure/Logging.ps1 and App/UiHelpers.ps1.
- Split SignatureHelpers.ps1 into Core/SignatureWorkflow.ps1, App/UiDialogs.ps1 and Infrastructure/Forensics.ps1.
- Split OpenXmlHelpers.ps1 into Infrastructure/ExcelOpenXml.ps1 and appended signature-specific OpenXML functions to Core/SignatureWorkflow.ps1.
- Split RuleEngine.ps1 into Core/RuleEngine.ps1 and Core/RuleEngine.Debug.ps1.
- Split DataHelpers.ps1 into Infrastructure/ExcelEpplus.ps1, Infrastructure/Csv.ps1, Infrastructure/FileStaging.ps1, Core/AssayNormalization.ps1, Core/HeaderParsing.ps1 and Core/OutputPlanning.ps1.
- Extracted selected helper/dialog/bootstrap/theme/controller functions from Main.ps1 into App/* and Core/OutputPlanning.ps1.
- Updated Main.ps1 import paths to point to refactored locations.
- Set Version.txt to 1.2.0-refactor.

## Not executed
- No runtime execution of the WinForms application was possible in this container.
- No PowerShell parser or STA execution validation was available.
- Main build orchestration was not moved into Core/BuildWorkflow.ps1; a placeholder file was created only.
- Legacy Modules/* files were kept in place for rollback/reference.

## Smoke-test checklist still recommended on Windows PowerShell 5.1
- App starts
- Gui-Log works
- CSV import works
- RuleBank loads
- Worksheet/Seal signatures work
- Output workbook is created
- SharePoint optional path still loads
