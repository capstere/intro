<#
.SYNOPSIS
  Read-only risk scan for IPT worksheet files before enabling OpenXML signing.
.DESCRIPTION
  Scans .xlsx files as ZIP/XML. No Excel, no EPPlus, no OpenXML SDK required.
  Flags bloated worksheet XML, especially Seal Test Failure Count.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true, Position=0)]
    [string]$Path,

    [int]$CellNodeThreshold = 50000,
    [int]$XmlSizeKbThreshold = 2048,
    [string]$SheetNamePattern = 'Seal Test Failure Count',
    [string]$OutCsv
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.IO.Compression | Out-Null
Add-Type -AssemblyName System.IO.Compression.FileSystem | Out-Null

function Read-ZipEntryText {
    param(
        [Parameter(Mandatory=$true)] [System.IO.Compression.ZipArchive]$Zip,
        [Parameter(Mandatory=$true)] [string]$EntryName
    )
    $entry = $Zip.GetEntry($EntryName)
    if (-not $entry) { return $null }
    $sr = $null
    try {
        $sr = New-Object System.IO.StreamReader($entry.Open(), [System.Text.Encoding]::UTF8, $true)
        return $sr.ReadToEnd()
    } finally {
        if ($sr) { $sr.Dispose() }
    }
}

function Convert-ColumnLettersToNumber {
    param([string]$Letters)
    $s = 0
    foreach ($ch in (($Letters + '').ToUpperInvariant()).ToCharArray()) {
        if ($ch -lt 'A' -or $ch -gt 'Z') { return 0 }
        $s = ($s * 26) + ([int][char]$ch - [int][char]'A' + 1)
    }
    return $s
}

function Get-MaxColFromDimension {
    param([string]$Dimension)
    if (-not $Dimension) { return 0 }
    $last = (($Dimension -split ':')[-1] + '')
    if ($last -match '^([A-Z]+)\d+$') { return Convert-ColumnLettersToNumber $matches[1] }
    return 0
}

function Get-XlsxFiles {
    param([string]$InputPath)
    if (Test-Path -LiteralPath $InputPath -PathType Leaf) {
        if ($InputPath -match '\.xlsx$') { return @(Get-Item -LiteralPath $InputPath) }
        throw "Input file is not .xlsx: $InputPath"
    }
    if (Test-Path -LiteralPath $InputPath -PathType Container) {
        return @(Get-ChildItem -LiteralPath $InputPath -Filter *.xlsx -File -Recurse)
    }
    throw "Path not found: $InputPath"
}

$results = New-Object System.Collections.Generic.List[object]
foreach ($file in (Get-XlsxFiles -InputPath $Path)) {
    $zip = $null
    try {
        $zip = [System.IO.Compression.ZipFile]::OpenRead($file.FullName)
        $wbText = Read-ZipEntryText -Zip $zip -EntryName 'xl/workbook.xml'
        $relsText = Read-ZipEntryText -Zip $zip -EntryName 'xl/_rels/workbook.xml.rels'
        if (-not $wbText -or -not $relsText) { throw 'workbook.xml or workbook relationships missing' }

        [xml]$wbXml = $wbText
        [xml]$relsXml = $relsText
        $nsm = New-Object System.Xml.XmlNamespaceManager($wbXml.NameTable)
        $nsm.AddNamespace('d', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main')
        $nsm.AddNamespace('r', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships')
        $relNs = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'

        $ridToTarget = @{}
        foreach ($rel in $relsXml.Relationships.Relationship) {
            $ridToTarget[($rel.Id + '')] = ($rel.Target + '')
        }

        foreach ($sheet in $wbXml.SelectNodes('//d:sheet', $nsm)) {
            $sheetName = ($sheet.name + '')
            if ($SheetNamePattern -and ($sheetName -notlike "*$SheetNamePattern*")) { continue }
            $rid = $sheet.GetAttribute('id', $relNs)
            $target = $ridToTarget[$rid]
            if (-not $target) { continue }
            $entryName = if ($target.StartsWith('/')) { $target.TrimStart('/') } else { 'xl/' + $target }
            $entryName = $entryName -replace '^xl//', 'xl/'
            $entry = $zip.GetEntry($entryName)
            if (-not $entry) { continue }
            $xml = Read-ZipEntryText -Zip $zip -EntryName $entryName
            $cellNodes = ([regex]::Matches($xml, '<c\b')).Count
            $dimension = ''
            $m = [regex]::Match($xml, '<dimension\s+ref="([^"]+)"')
            if ($m.Success) { $dimension = $m.Groups[1].Value }
            $maxCol = Get-MaxColFromDimension -Dimension $dimension
            $xmlKb = [math]::Round(($entry.Length / 1KB), 1)
            $risk = ($cellNodes -gt $CellNodeThreshold -or $xmlKb -gt $XmlSizeKbThreshold)
            $results.Add([pscustomobject]@{
                Risk       = if ($risk) { 'HIGH' } else { 'OK' }
                File       = $file.Name
                Sheet      = $sheetName
                Dimension  = $dimension
                MaxCol     = $maxCol
                CellNodes  = $cellNodes
                XmlSizeKB  = $xmlKb
                FullPath   = $file.FullName
            }) | Out-Null
        }
    } catch {
        $results.Add([pscustomobject]@{
            Risk       = 'ERROR'
            File       = $file.Name
            Sheet      = ''
            Dimension  = ''
            MaxCol     = 0
            CellNodes  = 0
            XmlSizeKB  = 0
            FullPath   = $file.FullName
            Error      = $_.Exception.Message
        }) | Out-Null
    } finally {
        if ($zip) { $zip.Dispose() }
    }
}

if ($OutCsv) {
    $results | Export-Csv -LiteralPath $OutCsv -NoTypeInformation -Encoding UTF8
    Write-Host "Saved: $OutCsv"
}

$results | Sort-Object Risk, File | Format-Table -AutoSize
