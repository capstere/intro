﻿# Build phase: CSV import, Data Summary scan, RuleEngine shadow
# Extracted from App/BuildReportFlow.ps1 during PASS4.

try { Set-UiStep 34 'Läser CSV och regelmotor…' } catch {}
        #region Build: CSV-inläsning och RuleEngine
        # ============================
        # === CSV (Info/Control)  ====
        # ============================

        $csvRows = @()
        $runAssay = $null

        if ($selCsv) {
            try {
                $csvInfo = Get-Item -LiteralPath $selCsv -ErrorAction Stop
                $thresholdMb = 25
                try {
                    if ($Config -and ($Config -is [System.Collections.IDictionary]) -and $Config.Contains('CsvStreamingThresholdMB')) {
                        $thresholdMb = [int]$Config['CsvStreamingThresholdMB']
                    }
                } catch {
                    Gui-Log "⚠️ Kunde inte läsa CsvStreamingThresholdMB från konfigurationen." 'Warn'
                }

                $useStreaming = ($csvInfo.Length -ge ($thresholdMb * 1MB))
                if ($useStreaming) {
                    Gui-Log ("⏳ CSV är stor ({0:N1} MB) – använder streaming-import…" -f ($csvInfo.Length / 1MB)) 'Info'
                    Set-UiStep 35 "Läser CSV (streaming)…"
                    $list = New-Object System.Collections.Generic.List[object]
                    Import-CsvRowsStreaming -Path $selCsv -StartRow 10 -ProcessRow {
                        param($Fields,$RowIndex)
                        [void]$list.Add($Fields)
                        if (($RowIndex % 2000) -eq 0) { Invoke-UiPump }
                    }
                    $csvRows = @($list.ToArray())
                } else {
                    Set-UiStep 35 "Läser CSV…"
                    $csvRows = Import-CsvRows -Path $selCsv -StartRow 10
                }

                # --- Robusthet: Sortera på kolumn C (Sample ID) innan vidare bearbetning.
                # Många efterföljande steg (gruppering/skrivning) förutsätter att raderna är konsekvent sorterade.
                try {
                    if ($csvRows -and $csvRows.Count -gt 1) {
                        if ($csvRows[0] -is [object[]]) {
                            # Import-CsvRows* returnerar fält-arrayer: kolumn C = index 2
                            $csvRows = @($csvRows | Sort-Object { [string]($_[2]) })
                        } else {
                            # Om vi i framtiden får PSCustomObject-rader
                            $csvRows = @($csvRows | Sort-Object { [string]($_.'Sample ID') })
                        }
                        Gui-Log ("🔃 CSV sorterad på kolumn C (Sample ID). Rader: {0}" -f $csvRows.Count) 'Info' 'PROGRESS'
                    }
                } catch {
                    Gui-Log "⚠️ Kunde inte sortera CSV på kolumn C (Sample ID)." 'Warn'
                }
            } catch {
                Gui-Log "⚠️ CSV-import misslyckades: $($_.Exception.Message)" 'Warn'
                $csvRows = @()
            }
            try { $runAssay = Get-AssayFromCsv -Path $selCsv -StartRow 10 } catch {}
            if ($runAssay) { Gui-Log "🔎 Assay från CSV: $runAssay" }
        }

        # --- Import av Resample-CSV ---
        $csvRowsRes = @()
        $runAssayRes = $null
        if ($selCsvRes) {
            try {
                Set-UiStep 37 "Läser Resample-CSV…"
                $csvRowsRes = Import-CsvRows -Path $selCsvRes -StartRow 10
                try {
                    if ($csvRowsRes -and $csvRowsRes.Count -gt 1) {
                        if ($csvRowsRes[0] -is [object[]]) {
                            $csvRowsRes = @($csvRowsRes | Sort-Object { [string]($_[2]) })
                        } else {
                            $csvRowsRes = @($csvRowsRes | Sort-Object { [string]($_.'Sample ID') })
                        }
                        Gui-Log ("🔃 Resample-CSV sorterad. Rader: {0}" -f $csvRowsRes.Count) 'Info' 'PROGRESS'
                    }
                } catch {
                    Gui-Log "⚠️ Kunde inte sortera Resample-CSV på kolumn C (Sample ID)." 'Warn'
                }
            } catch {
                Gui-Log "⚠️ Resample-CSV-import misslyckades: $($_.Exception.Message)" 'Warn'
                $csvRowsRes = @()
            }
            try { $runAssayRes = Get-AssayFromCsv -Path $selCsvRes -StartRow 10 } catch {}
            if (-not $runAssayRes -and $runAssay) { $runAssayRes = $runAssay }  # Fallback till primary assay
        }

        # =====================================================
        # === SKANNING AV DATA SUMMARY-BLAD (fynd)
        # === Primär → 'Data Summary' + 'Extra Data Summary', Resample → 'Resample Data Summary'
        # =====================================================
        Mark-Phase 'CsvRead'
        $dataSummaryFindings     = @()
        $dataSummaryFindingsExtra = @()
        $dataSummaryFindingsRes  = @()
        $script:WsPkg            = $null  # Återanvänds av Equipment/Header/QC-sektionerna

        $effectiveAssay = if ($runAssay) { $runAssay } elseif ($runAssayRes) { $runAssayRes } else { $null }
        if ($effectiveAssay) {
            try {
                $selLspDs = $null
                try { $selLspDs = Get-CheckedFilePath $clbLsp } catch { $selLspDs = $null }

                if ($selLspDs -and (Test-Path -LiteralPath $selLspDs)) {
                    $script:WsPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selLspDs))

                    # --- Primär CSV → 'Data Summary' ---
                    if ($selCsv) {
                        $dataSummaryFindings = @(Get-DataSummaryFindings -ExcelPackages @($script:WsPkg) -AssayName $effectiveAssay -SheetName $Layout.SheetDataSummary)
                        $dataSummaryFindingsExtra = @(Get-DataSummaryFindings -ExcelPackages @($script:WsPkg) -AssayName $effectiveAssay -SheetName $Layout.SheetExtraSummary)
                    }

                    # --- Resample-CSV → 'Resample Data Summary' ---
                    if ($selCsvRes) {
                        $resSheetName = 'Resample Data Summary'
                        $dataSummaryFindingsRes = @(Get-DataSummaryFindings -ExcelPackages @($script:WsPkg) -AssayName $effectiveAssay -SheetName $resSheetName)
                        if ($dataSummaryFindingsRes.Count -gt 0) {
                        }
                    }
                }
            } catch {
                Gui-Log ("⚠️ Data Summary scan fel: " + $_.Exception.Message) 'Warn'
                $dataSummaryFindings     = @()
                $dataSummaryFindingsExtra = @()
                $dataSummaryFindingsRes  = @()
                if ($script:WsPkg) { try { $script:WsPkg.Dispose() } catch {} }
                $script:WsPkg = $null
            }
        }
        # Kombinerat DataSummaryFindings (primär + resample) för CSV Sammanfattning
        $allDataSummaryFindings = @($dataSummaryFindings) + @($dataSummaryFindingsExtra) + @($dataSummaryFindingsRes)
        $script:DataSummaryFindings = $allDataSummaryFindings

        # ============================
        # === RuleEngine (skuggresultat) ===
        # ============================
        Mark-Phase 'DataSummary'
        $script:RuleEngineShadowRes = $null   # Resample-resultat (separat)
        try {
            if ((Get-ConfigFlag -Name 'EnableRuleEngine' -Default $false -ConfigOverride $Config) -and
                ($selCsv -or $selCsvRes)) {

                # Ladda rulebank en gång
                $rb = Load-RuleBank -RuleBankDir $Config.RuleBankDir
                try {
                    $rb = Compile-RuleBank -RuleBank $rb
                } catch {
                    Gui-Log ("⚠️ Regelmotor: kunde inte kompilera RuleBank: " + $_.Exception.Message) 'Warn' 'DEBUG'
                }
                $script:RuleBankCache = $rb

                # ======================================
                # PRIMÄR CSV → RuleEngine
                # ======================================
                if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
                    $csvObjs = @()
                    if ($csvRows -and $csvRows.Count -gt 0) {
                        $csvObjs = @($csvRows)
                        Gui-Log ("🧠 Regelmotor: CSV-källa: Import-CsvRows ({0})" -f $csvObjs.Count) 'Info' 'PROGRESS'
                    } else {
                        try {
                            $all = $script:CsvLinesPrimary
                            if ($all -and $all.Count -gt 0) {
                                $prof = Get-TestSummaryCsvProfile -Path $selCsv -Lines $all
                                if ($prof) {
                                    $hdr = @($prof.HeaderFields)
                                    $dl  = @()
                                    for ($ri=[int]$prof.DataStartIndex; $ri -lt $all.Count; $ri++) {
                                        $lnTmp = $all[$ri]
                                        if ($lnTmp -and $lnTmp.Trim()) { $dl += $lnTmp }
                                    }
                                    $csvObjs = @(ConvertFrom-Csv -InputObject ($dl -join "`n") -Delimiter $prof.Delimiter -Header $hdr)
                                }
                            }
                        } catch {
                            Gui-Log ("⚠️ Regelmotor: fallback-raw för CSV misslyckades: " + $_.Exception.Message) 'Warn' 'DEBUG'
                            $csvObjs = @()
                        }
                        Gui-Log ("🧠 Regelmotor: CSV-källa: Fallback-raw ({0})" -f ($csvObjs.Count)) 'Info' 'PROGRESS'
                    }
                    $script:RuleEngineCsvObjs = $csvObjs

                    if (-not $csvObjs -or $csvObjs.Count -eq 0) {
                        Gui-Log "⚠️ Regelmotor: CSV-objekt saknas (0 rader) – hoppar över." 'Warn'
                        $script:RuleEngineShadow = $null
                    } else {
                        $re = Invoke-RuleEngine -CsvObjects $csvObjs -RuleBank $rb -CsvPath $selCsv
                        $script:RuleEngineShadow = $re
                    }
                }

                # ======================================
                # RESAMPLE-CSV → RuleEngine
                # ======================================
                if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
                    $csvObjsRes = @()
                    if ($csvRowsRes -and $csvRowsRes.Count -gt 0) {
                        $csvObjsRes = @($csvRowsRes)
                        Gui-Log ("🧠 Regelmotor (Resample): Import-CsvRows ({0})" -f $csvObjsRes.Count) 'Info' 'PROGRESS'
                    } else {
                        try {
                            $allR = $script:CsvLinesResample
                            if ($allR -and $allR.Count -gt 0) {
                                $profR = Get-TestSummaryCsvProfile -Path $selCsvRes -Lines $allR
                                if ($profR) {
                                    $hdrR = @($profR.HeaderFields)
                                    $dlR  = @()
                                    for ($riR=[int]$profR.DataStartIndex; $riR -lt $allR.Count; $riR++) {
                                        $lnTmpR = $allR[$riR]
                                        if ($lnTmpR -and $lnTmpR.Trim()) { $dlR += $lnTmpR }
                                    }
                                    $csvObjsRes = @(ConvertFrom-Csv -InputObject ($dlR -join "`n") -Delimiter $profR.Delimiter -Header $hdrR)
                                }
                            }
                        } catch {
                            Gui-Log ("⚠️ Regelmotor: fallback-raw för Resample-CSV misslyckades: " + $_.Exception.Message) 'Warn' 'DEBUG'
                            $csvObjsRes = @()
                        }
                    }
                    $script:RuleEngineCsvObjsRes = $csvObjsRes

                    if ($csvObjsRes -and $csvObjsRes.Count -gt 0) {
                        $reRes = Invoke-RuleEngine -CsvObjects $csvObjsRes -RuleBank $rb -CsvPath $selCsvRes
                        $script:RuleEngineShadowRes = $reRes
                    }
                }

                # ======================================
                # KOMBINERAD SUMMERING (primär + resample)
                # ======================================
                $rePrimary = $script:RuleEngineShadow
                $reResamp  = $script:RuleEngineShadowRes

                # Sammanfogning: bygg nytt kombinerat resultat (undvik PS 5.1-bugg med readonly NoteProperty)
                if ($rePrimary -and $reResamp) {
                    try {
                        # Rader
                        $mergedRows = @($rePrimary.Rows) + @($reResamp.Rows)

                        # DeviationCounts — kopiera primär, addera resample
                        $mergedDev = @{}
                        if ($rePrimary.Summary.DeviationCounts) {
                            foreach ($dk in $rePrimary.Summary.DeviationCounts.Keys) { $mergedDev[$dk] = [int]$rePrimary.Summary.DeviationCounts[$dk] }
                        }
                        if ($reResamp.Summary.DeviationCounts) {
                            foreach ($dk in $reResamp.Summary.DeviationCounts.Keys) {
                                if ($mergedDev.ContainsKey($dk)) { $mergedDev[$dk] = [int]$mergedDev[$dk] + [int]$reResamp.Summary.DeviationCounts[$dk] }
                                else { $mergedDev[$dk] = [int]$reResamp.Summary.DeviationCounts[$dk] }
                            }
                        }

                        # ObservedCounts
                        $mergedObs = @{}
                        if ($rePrimary.Summary.ObservedCounts) {
                            foreach ($ok2 in $rePrimary.Summary.ObservedCounts.Keys) { $mergedObs[$ok2] = [int]$rePrimary.Summary.ObservedCounts[$ok2] }
                        }
                        if ($reResamp.Summary.ObservedCounts) {
                            foreach ($ok2 in $reResamp.Summary.ObservedCounts.Keys) {
                                if ($mergedObs.ContainsKey($ok2)) { $mergedObs[$ok2] = [int]$mergedObs[$ok2] + [int]$reResamp.Summary.ObservedCounts[$ok2] }
                                else { $mergedObs[$ok2] = [int]$reResamp.Summary.ObservedCounts[$ok2] }
                            }
                        }

                        # Enkla räknare
                        $mergedInstErr  = ($rePrimary.Summary.InstrumentError + 0) + ($reResamp.Summary.InstrumentError + 0)
                        $mergedMinFunc  = ($rePrimary.Summary.MinorFunctionalError + 0) + ($reResamp.Summary.MinorFunctionalError + 0)
                        $mergedTotal    = ($rePrimary.Summary.Total + 0) + ($reResamp.Summary.Total + 0)
                        $mergedRetest   = ($rePrimary.Summary.RetestYes + 0) + ($reResamp.Summary.RetestYes + 0)

                        # TopDeviations
                        $mergedTop = @($rePrimary.TopDeviations) + @($reResamp.TopDeviations)

                        # QC (behåll primär)
                        $mergedQC = $rePrimary.QC

                        # Bygg nytt resultatobjekt
                        $mergedSummary = [pscustomobject]@{
                            Total                = $mergedTotal
                            ObservedCounts       = $mergedObs
                            DeviationCounts      = $mergedDev
                            RetestYes            = $mergedRetest
                            InstrumentError      = $mergedInstErr
                            MinorFunctionalError = $mergedMinFunc
                        }
                        $script:RuleEngineShadow = [pscustomobject]@{
                            Rows          = $mergedRows
                            Summary       = $mergedSummary
                            TopDeviations = $mergedTop
                            QC            = $mergedQC
                        }
                        Gui-Log ("✅ Merge CSV + Resampling CSV: {0} rader totalt" -f $mergedRows.Count) 'Info'
                    } catch {
                        Gui-Log "⚠️ Merge CSV + Resampling CSV resultat: $($_.Exception.Message)" 'Warn'
                    }
                } elseif (-not $rePrimary -and $reResamp) {
                    # Endast resample
                    $script:RuleEngineShadow = $reResamp
                }

                $re = $script:RuleEngineShadow
                if ($re -and $re.Summary) {
                    try {
                        $pos = 0; $neg = 0; $err = 0
                        if ($re.Summary.ObservedCounts) {
                            if ($re.Summary.ObservedCounts.ContainsKey('POS'))   { $pos = [int]$re.Summary.ObservedCounts['POS'] }
                            if ($re.Summary.ObservedCounts.ContainsKey('NEG'))   { $neg = [int]$re.Summary.ObservedCounts['NEG'] }
                            if ($re.Summary.ObservedCounts.ContainsKey('ERROR')) { $err = [int]$re.Summary.ObservedCounts['ERROR'] }
                        }

                        $ok = 0; $fp = 0; $fn = 0; $derr = 0; $ie = 0
                        if ($re.Summary.DeviationCounts) {
                            if ($re.Summary.DeviationCounts.ContainsKey('OK'))    { $ok   = [int]$re.Summary.DeviationCounts['OK'] }
                            if ($re.Summary.DeviationCounts.ContainsKey('FP'))    { $fp   = [int]$re.Summary.DeviationCounts['FP'] }
                            if ($re.Summary.DeviationCounts.ContainsKey('FN'))    { $fn   = [int]$re.Summary.DeviationCounts['FN'] }
                            if ($re.Summary.DeviationCounts.ContainsKey('ERROR')) { $derr = [int]$re.Summary.DeviationCounts['ERROR'] }
                        }
                        $ie = 0; if ($re.Summary.InstrumentError -ne $null) { $ie = [int]$re.Summary.InstrumentError }
                        $mf = 0; if ($re.Summary.MinorFunctionalError -ne $null) { $mf = [int]$re.Summary.MinorFunctionalError }

                        $resTag = if ($hasResampleCsv) { ' [+Resample]' } else { '' }
                        $sum = "🧠 Regelkontroll$resTag`: POS=$pos, NEG=$neg, Error=$err | OK=$ok, FP=$fp, FN=$fn, Minor Func=$mf | Instrument Error=$ie"
                        # Regelkontroll-detaljer döljs i GUI (kan stressa användare)
                        # Gui-Log -Text $sum -Severity Info -Category SUMMARY
                    } catch { }

                    if ((Get-ConfigFlag -Name 'EnableShadowCompare' -Default $false -ConfigOverride $Config) -and $re.TopDeviations) {
                        $n = 0
                        foreach ($d in $re.TopDeviations) {
                            $n++; if ($n -gt 20) { break }
                            $msg = "⚠️ RuleEngine dev: " + ($d.Deviation + '') + " | " + ($d.SampleId + '') + " | Exp=" + ($d.ExpectedCall + '') + " | Obs=" + ($d.ObservedCall + '')
                            if (($d.ErrorCode + '').Trim()) { $msg += " | Err=" + ($d.ErrorCode + '') }
                            Gui-Log -Text $msg -Severity Info -Category RuleEngineDev
                        }
                    }
                }
            }
        } catch {
            Gui-Log ("⚠️ RuleEngine (shadow) fel: " + $_.Exception.Message) 'Warn'
        }

        $controlTab = $null
        if ($runAssay) { $controlTab = Get-ControlTabName -AssayName $runAssay }
        if ($controlTab) { Gui-Log "🧪 Kontrollmaterial-flik: $controlTab" } else { Gui-Log "ℹ️ Ingen Kontrollmaterialsflik (fortsätter utan)." }

