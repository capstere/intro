# AutoMapp Rewrite Clean Test v3

Det här paketet är byggt för att vara enkelt att testa lokalt på Windows/PowerShell 5.1.

## Viktig princip

Det här är fortfarande **dry-run**:

- Ingen SharePoint-koppling
- Ingen UNC-path
- Ingen personlig server/path
- Ingen inbäddad certifikatnyckel
- Ingen Excel COM automation

Målet är att verifiera den nya rewrite-idén lokalt: produktdata från CSV + dokumentmapping + Open XML-fyllning av Excel.

## Kör exakt så här

1. Packa upp zippen.
2. Gå in i mappen `AutoMappRewrite_CleanTest_v3`.
3. Kör:

```text
START_HERE.cmd
```

Det kör:

```powershell
Run-Test.ps1 -Force -Pause
```

## Förväntad output

I första hand:

```text
C:\AutoMappRewriteTest
```

Om datorn inte tillåter skrivning direkt under `C:\` används fallback:

```text
%USERPROFILE%\AutoMappRewriteTest
```

Viktigaste filen:

```text
C:\AutoMappRewriteTest\TemplateGenerator\GXMTB_RIF-ULTRA-10_96104.xlsx
```

Den ska öppnas i Excel utan repair/recovery prompt.

## Vad v3 tog från agentens version

Agentens bästa idé var ett tydligt `Process-Lot`-API:

```powershell
Process-Lot -Material 'GXMTB/RIF-ULTRA-10' -LotNumber '96104' -Keywords $keywords
```

I v3 finns detta kvar som kompatibilitets-wrapper, men den riktiga funktionen heter:

```powershell
Process-AutoMapLot
```

Testpaketet använder alltså ett mer strukturerat flöde:

```text
ProductMap.csv
  -> Process-AutoMapLot
      -> keyword merge från produktdata + lotdata
      -> kopiera Target.xlsx
      -> applicera Deviations.json med Open XML
      -> skapa output workbook + summary + logg + status
```

## Var ändrar jag testdata?

### Produkt/masterdata

```text
Data\ProductMap.csv
```

Viktiga kolumner:

```text
MaterialKey
Aliases
Assay
MatRev
Product
SealAssay
PartNr
Ultra
HighPos
NaText
TemplateFolder
SourceWorkbookFile
ReferenceFile
TemplateFile
MappingFile
Active
```

V3 har kvar de cirka 79 extraherade raderna från gamla AutoMappScript och har lagt till agentens template-fälttänk.

### Lot/testvärden

I `Run-Test.ps1`:

```powershell
Process-AutoMapLot `
    -Material 'GXMTB/RIF-ULTRA-10' `
    -LotNumber '96104' `
    -BatchNumber '1001525941' `
    -LspNumber '96104' `
    -ExpirationDate '2027 09 12'
```

## Manuell Process-Lot-test

Du kan även köra:

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
.\Run-ProcessLot-Example.ps1 -Force
```

## Var ligger config?

```text
Config\AutoMapp.CleanTest.config.json
```

Default:

```json
{
  "PreferredDryRunRoot": "C:\\AutoMappRewriteTest",
  "FallbackDryRunRoot": "%USERPROFILE%\\AutoMappRewriteTest",
  "UseSharePoint": false,
  "UseExcelCom": false
}
```

## Nyckel / certifikat

Du ska inte lägga till någon nyckel i detta paket.

När SharePoint byggs in senare bör nycklar inte ligga i scriptet. Rekommenderad modell är service account/app registration + certifikat i Windows Certificate Store eller styrda miljövariabler.

## Acceptanstest

Testet är godkänt om:

1. `START_HERE.cmd` kör klart utan rött fel.
2. Output-Excel öppnar utan repair/recovery.
3. `TargetFilled.summary.json` eller motsvarande material/lot-summary skapas.
4. `status.json` visar `OK`.
5. `Logs\AutoMap_LogEvents.csv` innehåller start/slut-rader.
