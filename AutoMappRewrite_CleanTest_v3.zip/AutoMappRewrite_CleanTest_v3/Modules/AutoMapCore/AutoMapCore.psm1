# AutoMapCore.psm1
# Core orchestration helpers for AutoMapp Rewrite clean test package.
# Windows PowerShell 5.1 compatible. No SharePoint and no Excel COM in dry-run.

function Get-AutoMapPackageRoot {
    [CmdletBinding()]
    param()
    # Module path: <root>\Modules\AutoMapCore\AutoMapCore.psm1
    return (Split-Path -Parent (Split-Path -Parent $PSScriptRoot))
}

function Resolve-AutoMapEnvPath {
    [CmdletBinding()]
    param([AllowNull()][string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return $Path }
    return [Environment]::ExpandEnvironmentVariables($Path)
}

function Read-AutoMapConfig {
    [CmdletBinding()]
    param([string]$ConfigPath)

    if ([string]::IsNullOrWhiteSpace($ConfigPath)) {
        $ConfigPath = Join-Path (Get-AutoMapPackageRoot) 'Config\AutoMapp.CleanTest.config.json'
    }
    if (-not (Test-Path -LiteralPath $ConfigPath)) { throw "Config not found: $ConfigPath" }
    return (Get-Content -LiteralPath $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json)
}

function New-AutoMapFolderSafe {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Test-AutoMapCanWriteFolder {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Path)
    try {
        New-AutoMapFolderSafe -Path $Path
        $probe = Join-Path $Path ("write_test_{0}.tmp" -f ([guid]::NewGuid().ToString('N')))
        'ok' | Set-Content -LiteralPath $probe -Encoding UTF8
        Remove-Item -LiteralPath $probe -Force
        return $true
    }
    catch {
        return $false
    }
}

function Resolve-AutoMapDryRunRoot {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]$Config,
        [string]$DryRunRoot
    )

    if (-not [string]::IsNullOrWhiteSpace($DryRunRoot)) {
        return (Resolve-AutoMapEnvPath -Path $DryRunRoot)
    }

    $preferred = Resolve-AutoMapEnvPath -Path ([string]$Config.PreferredDryRunRoot)
    $fallback  = Resolve-AutoMapEnvPath -Path ([string]$Config.FallbackDryRunRoot)

    if (Test-AutoMapCanWriteFolder -Path $preferred) { return $preferred }
    return $fallback
}

function Initialize-AutoMapDryRunRoot {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]$Config,
        [string]$DryRunRoot
    )

    $root = Resolve-AutoMapDryRunRoot -Config $Config -DryRunRoot $DryRunRoot
    New-AutoMapFolderSafe -Path $root
    New-AutoMapFolderSafe -Path (Join-Path $root ([string]$Config.OutputSubFolder))
    New-AutoMapFolderSafe -Path (Join-Path $root ([string]$Config.LogSubFolder))
    return $root
}

function Write-AutoMapLog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('Info','Warning','Error')][string]$Severity = 'Info',
        [string]$Source = 'AutoMappRewrite',
        [string]$LogRoot = 'C:\AutoMappRewriteTest\Logs',
        [string]$Material = '',
        [string]$LotNumber = '',
        [string]$RunId = ''
    )

    New-AutoMapFolderSafe -Path $LogRoot
    if ([string]::IsNullOrWhiteSpace($RunId)) { $RunId = [guid]::NewGuid().ToString('N') }

    $row = [pscustomobject]@{
        EventTime = (Get-Date).ToString('s')
        Severity = $Severity
        Source = $Source
        Material = $Material
        LotNumber = $LotNumber
        RunId = $RunId
        Message = $Message
    }

    $path = Join-Path $LogRoot 'AutoMap_LogEvents.csv'
    if (-not (Test-Path -LiteralPath $path)) {
        $row | Export-Csv -Path $path -NoTypeInformation -Encoding UTF8
    }
    else {
        $row | Export-Csv -Path $path -NoTypeInformation -Encoding UTF8 -Append
    }
    return $row
}

function Write-AutoMapRunStatus {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [ValidateSet('OK','Warning','Error','Disabled')][string]$Result = 'OK',
        [string]$Message = '',
        [string]$RunId = '',
        [string]$Material = '',
        [string]$LotNumber = '',
        [string]$OutputPath = ''
    )

    $status = [ordered]@{
        LastHeartbeat = (Get-Date).ToString('s')
        LastResult = $Result
        HostName = $env:COMPUTERNAME
        UserName = $env:USERNAME
        RunId = $RunId
        Material = $Material
        LotNumber = $LotNumber
        OutputPath = $OutputPath
        Message = $Message
    }

    $dir = Split-Path -Parent $Path
    New-AutoMapFolderSafe -Path $dir
    $status | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $Path -Encoding UTF8
    return [pscustomobject]$status
}

function Get-AutoMapProductMap {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) { throw "ProductMap not found: $Path" }

    $firstLine = Get-Content -LiteralPath $Path -TotalCount 1 -Encoding UTF8
    $delimiter = ';'
    if ($firstLine -match ',' -and $firstLine -notmatch ';') { $delimiter = ',' }

    return (Import-Csv -Path $Path -Delimiter $delimiter)
}

function Get-AutoMapProductConfig {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Material,
        [Parameter(Mandatory)][string]$ProductMapPath
    )

    $rows = Get-AutoMapProductMap -Path $ProductMapPath
    foreach ($row in $rows) {
        $keys = @()
        if ($row.PSObject.Properties.Name -contains 'MaterialKey') { $keys += [string]$row.MaterialKey }
        if ($row.PSObject.Properties.Name -contains 'Material')    { $keys += [string]$row.Material }
        if ($row.PSObject.Properties.Name -contains 'Aliases') {
            $keys += (($row.Aliases -split '\|') | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
        }
        if ($keys -contains $Material) { return $row }
    }
    return $null
}

function ConvertTo-AutoMapKeywordTable {
    [CmdletBinding()]
    param(
        [hashtable]$Keywords,
        [object]$Product,
        [string]$Material,
        [string]$LotNumber,
        [string]$BatchNumber,
        [string]$LspNumber,
        [string]$ExpirationDate
    )

    $merged = @{}

    if ($Keywords) {
        foreach ($key in $Keywords.Keys) {
            $cleanKey = ([string]$key).Trim()
            if ($cleanKey.StartsWith('%') -and $cleanKey.EndsWith('%') -and $cleanKey.Length -gt 2) {
                $cleanKey = $cleanKey.Substring(1, $cleanKey.Length - 2)
            }
            $merged[$cleanKey] = [string]$Keywords[$key]
        }
    }

    function AddKeywordIfValue {
        param([string]$Key, [object]$Value)
        if ($null -ne $Value -and -not [string]::IsNullOrWhiteSpace([string]$Value)) {
            $merged[$Key] = [string]$Value
        }
    }

    AddKeywordIfValue -Key 'MATERIAL' -Value $Material
    AddKeywordIfValue -Key 'LOT' -Value $LotNumber
    AddKeywordIfValue -Key 'LOTNUMBER' -Value $LotNumber
    AddKeywordIfValue -Key 'LSP' -Value $LspNumber
    AddKeywordIfValue -Key 'BATCH' -Value $BatchNumber
    AddKeywordIfValue -Key 'EXPDATE' -Value $ExpirationDate
    AddKeywordIfValue -Key 'DATE' -Value (Get-Date -Format 'yyyy MM dd')

    if ($Product) {
        foreach ($name in $Product.PSObject.Properties.Name) {
            $value = $Product.$name
            switch -Regex ($name) {
                '^PartNr$'       { AddKeywordIfValue -Key 'PARTNR' -Value $value; AddKeywordIfValue -Key 'PN' -Value $value; continue }
                '^PartNumber$'   { AddKeywordIfValue -Key 'PARTNR' -Value $value; AddKeywordIfValue -Key 'PN' -Value $value; continue }
                '^MaterialKey$'  { AddKeywordIfValue -Key 'KITPN' -Value $value; AddKeywordIfValue -Key 'MATERIAL' -Value $value; continue }
                '^Material$'     { AddKeywordIfValue -Key 'KITPN' -Value $value; AddKeywordIfValue -Key 'MATERIAL' -Value $value; continue }
                '^NaText$'       { AddKeywordIfValue -Key 'NA' -Value $value; continue }
                default          { AddKeywordIfValue -Key ($name.ToUpperInvariant()) -Value $value }
            }
        }
    }

    return $merged
}

function ConvertTo-AutoMapSafeFileName {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Value)
    $invalid = [System.IO.Path]::GetInvalidFileNameChars()
    $chars = $Value.ToCharArray()
    for ($i = 0; $i -lt $chars.Length; $i++) {
        if ($invalid -contains $chars[$i] -or $chars[$i] -eq '/' -or $chars[$i] -eq '\\') { $chars[$i] = '_' }
    }
    return -join $chars
}

function Resolve-AutoMapPackageRelativePath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [string]$BaseRoot
    )

    if ([System.IO.Path]::IsPathRooted($Path)) { return $Path }
    if ([string]::IsNullOrWhiteSpace($BaseRoot)) { $BaseRoot = Get-AutoMapPackageRoot }
    return (Join-Path $BaseRoot $Path)
}

function Process-AutoMapLot {
    <#
    .SYNOPSIS
        Data-driven dry-run lot processor inspired by the agent's Process-Lot idea.

    .DESCRIPTION
        Resolves material data from ProductMap.csv, builds a keyword table from product
        fields and caller-provided values, copies a source workbook to output, applies
        the mapping JSON using the DocumentMapping Open XML path, and writes log/status.

        This function intentionally does not use SharePoint, UNC paths, Excel COM, or a
        personal account in the clean test package.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Material,
        [Parameter(Mandatory)][string]$LotNumber,
        [hashtable]$Keywords = @{},
        [string]$BatchNumber = '',
        [string]$LspNumber = '',
        [string]$ExpirationDate = '',
        [string]$ConfigPath = '',
        [string]$DryRunRoot = '',
        [string]$ProductMapPath = '',
        [switch]$Force,
        [switch]$GenerateMappingIfMissing
    )

    $runId = [guid]::NewGuid().ToString('N')
    $packageRoot = Get-AutoMapPackageRoot
    $config = Read-AutoMapConfig -ConfigPath $ConfigPath
    $resolvedRoot = Initialize-AutoMapDryRunRoot -Config $config -DryRunRoot $DryRunRoot
    $outputRoot = Join-Path $resolvedRoot ([string]$config.OutputSubFolder)
    $logRoot = Join-Path $resolvedRoot ([string]$config.LogSubFolder)
    $statusPath = Join-Path $resolvedRoot 'status.json'

    if ([string]::IsNullOrWhiteSpace($ProductMapPath)) {
        $ProductMapPath = Join-Path $packageRoot ([string]$config.ProductMapPath)
    }
    else {
        $ProductMapPath = Resolve-AutoMapPackageRelativePath -Path $ProductMapPath -BaseRoot $packageRoot
    }

    try {
        Write-AutoMapLog -LogRoot $logRoot -Source 'Process-AutoMapLot' -Material $Material -LotNumber $LotNumber -RunId $runId -Message 'Started lot processing' | Out-Null

        $product = Get-AutoMapProductConfig -Material $Material -ProductMapPath $ProductMapPath
        if (-not $product) { throw "Material '$Material' was not found in ProductMap.csv" }

        if ([string]::IsNullOrWhiteSpace($LspNumber)) { $LspNumber = $LotNumber }

        $templateFolder = ''
        if ($product.PSObject.Properties.Name -contains 'TemplateFolder') { $templateFolder = [string]$product.TemplateFolder }
        if ([string]::IsNullOrWhiteSpace($templateFolder)) { $templateFolder = [string]$config.DemoInputRelativePath }

        $templateFolderPath = Resolve-AutoMapPackageRelativePath -Path $templateFolder -BaseRoot $packageRoot
        if (-not (Test-Path -LiteralPath $templateFolderPath)) { throw "Template/demo folder not found: $templateFolderPath" }

        $sourceWorkbookFile = ''
        if ($product.PSObject.Properties.Name -contains 'SourceWorkbookFile') { $sourceWorkbookFile = [string]$product.SourceWorkbookFile }
        if ([string]::IsNullOrWhiteSpace($sourceWorkbookFile) -and $product.PSObject.Properties.Name -contains 'TemplateFile') { $sourceWorkbookFile = [string]$product.TemplateFile }
        if ([string]::IsNullOrWhiteSpace($sourceWorkbookFile)) { $sourceWorkbookFile = [string]$config.DefaultSourceWorkbookFile }
        if ([string]::IsNullOrWhiteSpace($sourceWorkbookFile)) { $sourceWorkbookFile = 'Target.xlsx' }

        $mappingFile = ''
        if ($product.PSObject.Properties.Name -contains 'MappingFile') { $mappingFile = [string]$product.MappingFile }
        if ([string]::IsNullOrWhiteSpace($mappingFile)) { $mappingFile = [string]$config.DefaultMappingFile }
        if ([string]::IsNullOrWhiteSpace($mappingFile)) { $mappingFile = 'Deviations.json' }

        $sourceWorkbookPath = Join-Path $templateFolderPath $sourceWorkbookFile
        $mappingPath = Join-Path $templateFolderPath $mappingFile

        if (-not (Test-Path -LiteralPath $sourceWorkbookPath)) { throw "Source workbook not found: $sourceWorkbookPath" }

        if (-not (Test-Path -LiteralPath $mappingPath)) {
            if ($GenerateMappingIfMissing) {
                throw 'Mapping generation is not enabled in the clean test package unless ImportExcel is installed and a hardened generator is added. Keep Deviations.json present for dry-run.'
            }
            else {
                throw "Mapping JSON not found: $mappingPath"
            }
        }

        $keywordTable = ConvertTo-AutoMapKeywordTable -Keywords $Keywords -Product $product -Material $Material -LotNumber $LotNumber -BatchNumber $BatchNumber -LspNumber $LspNumber -ExpirationDate $ExpirationDate

        $safeMaterial = ConvertTo-AutoMapSafeFileName -Value $Material
        $safeLot = ConvertTo-AutoMapSafeFileName -Value $LotNumber
        $targetPath = Join-Path $outputRoot ("{0}_{1}.xlsx" -f $safeMaterial, $safeLot)
        $summaryPath = Join-Path $outputRoot ("{0}_{1}.summary.json" -f $safeMaterial, $safeLot)

        Copy-Item -LiteralPath $sourceWorkbookPath -Destination $targetPath -Force

        $summary = Invoke-ExcelDocumentMapping -TargetPath $targetPath -MappingJsonPath $mappingPath -Keywords $keywordTable -Force:$Force
        $result = [ordered]@{
            Result = 'OK'
            RunId = $runId
            Material = $Material
            LotNumber = $LotNumber
            BatchNumber = $BatchNumber
            LspNumber = $LspNumber
            Product = $product.Product
            PartNr = if ($product.PSObject.Properties.Name -contains 'PartNr') { $product.PartNr } elseif ($product.PSObject.Properties.Name -contains 'PartNumber') { $product.PartNumber } else { '' }
            TargetPath = $targetPath
            SummaryPath = $summaryPath
            MappingPath = $mappingPath
            SourceWorkbookPath = $sourceWorkbookPath
            KeywordCount = $keywordTable.Count
            MappingSummary = $summary
        }

        $result | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $summaryPath -Encoding UTF8
        Write-AutoMapRunStatus -Path $statusPath -Result 'OK' -RunId $runId -Material $Material -LotNumber $LotNumber -OutputPath $targetPath -Message 'Lot processing completed' | Out-Null
        Write-AutoMapLog -LogRoot $logRoot -Source 'Process-AutoMapLot' -Material $Material -LotNumber $LotNumber -RunId $runId -Message "Created $targetPath" | Out-Null

        return [pscustomobject]$result
    }
    catch {
        $message = $_.Exception.Message
        Write-AutoMapLog -LogRoot $logRoot -Source 'Process-AutoMapLot' -Severity 'Error' -Material $Material -LotNumber $LotNumber -RunId $runId -Message $message | Out-Null
        Write-AutoMapRunStatus -Path $statusPath -Result 'Error' -RunId $runId -Material $Material -LotNumber $LotNumber -Message $message | Out-Null
        throw
    }
}

function Process-Lot {
    <#
    .SYNOPSIS
        Compatibility wrapper matching the agent prototype name.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Material,
        [Parameter(Mandatory)][string]$LotNumber,
        [hashtable]$Keywords = @{},
        [string]$BatchNumber = '',
        [string]$LspNumber = '',
        [string]$ExpirationDate = '',
        [switch]$Force
    )
    return Process-AutoMapLot -Material $Material -LotNumber $LotNumber -Keywords $Keywords -BatchNumber $BatchNumber -LspNumber $LspNumber -ExpirationDate $ExpirationDate -Force:$Force
}

function Test-AutoMapPackagePreflight {
    [CmdletBinding()]
    param([string]$PackageRoot = '')

    if ([string]::IsNullOrWhiteSpace($PackageRoot)) { $PackageRoot = Get-AutoMapPackageRoot }

    $findings = New-Object System.Collections.ArrayList
    function AddFinding { param([string]$Level, [string]$Message) [void]$findings.Add([pscustomobject]@{ Level = $Level; Message = $Message }) }

    $required = @(
        'START_HERE.cmd',
        'Run-Test.ps1',
        'Config\AutoMapp.CleanTest.config.json',
        'Data\ProductMap.csv',
        'DemoInput\Target.xlsx',
        'DemoInput\Deviations.json',
        'Modules\DocumentMapping\DocumentMapping.psm1',
        'Modules\DocumentMapping\lib\DocumentFormat.OpenXml.dll'
    )

    foreach ($relative in $required) {
        $path = Join-Path $PackageRoot $relative
        if (Test-Path -LiteralPath $path) { AddFinding -Level 'OK' -Message "Found $relative" }
        else { AddFinding -Level 'Error' -Message "Missing $relative" }
    }

    $scriptFiles = Get-ChildItem -Path $PackageRoot -Recurse -Include *.ps1,*.psm1 -File
    foreach ($file in $scriptFiles) {
        $text = Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8
        if ($text -match [char]0x2010 -or $text -match [char]0x2011 -or $text -match [char]0x2012 -or $text -match [char]0x2013 -or $text -match [char]0x2014) {
            AddFinding -Level 'Error' -Message "Unicode dash found in $($file.Name)"
        }
        if ($text -match 'New-Object\s+-ComObject' -or $text -match 'Excel\.Application') {
            AddFinding -Level 'Error' -Message "Excel COM marker found in $($file.Name)"
        }
    }

    return $findings
}

Export-ModuleMember -Function `
    Get-AutoMapPackageRoot, `
    Read-AutoMapConfig, `
    Initialize-AutoMapDryRunRoot, `
    Write-AutoMapLog, `
    Write-AutoMapRunStatus, `
    Get-AutoMapProductMap, `
    Get-AutoMapProductConfig, `
    ConvertTo-AutoMapKeywordTable, `
    Process-AutoMapLot, `
    Process-Lot, `
    Test-AutoMapPackagePreflight
