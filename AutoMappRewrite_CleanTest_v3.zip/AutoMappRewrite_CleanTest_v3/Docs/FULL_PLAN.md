# Full plan för AutoMapp Rewrite

## Mål

Ersätta personbundet AutoMappScript med en robust, datadriven lösning som kan köras från gemensam automation host/service account.

## Rekommenderad arkitektur

```text
Power App / SharePoint Lists
    ProductMap
    Equipment
    RunStatus
    LogEvents
        ↓
PowerShell automation engine
    Process-AutoMapLot
    DocumentMapping/Open XML
    folder/document generation
        ↓
N:/UNC eller SharePoint output, beroende på produktionsbeslut
```

## Fas 1: Lokal dry-run

- Kör v3-paketet.
- Verifiera att output-Excel öppnas utan repair.
- Verifiera att mapping ersätter placeholders.
- Verifiera logg och status.

## Fas 2: Datamodell

Flytta `Data\ProductMap.csv` till SharePoint List:

- MaterialKey
- Aliases
- Assay
- MatRev
- Product
- SealAssay
- PartNr
- Ultra
- HighPos
- NaText
- TemplateFolder
- SourceWorkbookFile
- MappingFile
- Active

Power App används för att lägga till/ändra dessa värden.

## Fas 3: Service-host

- Lägg script på gemensam automation host.
- Kör via service account eller gemensam app registration.
- Ingen privat nyckel i kod.
- Hemligheter via Certificate Store eller styrd secret-hantering.

## Fas 4: SharePoint/Power Apps

- Power App redigerar ProductMap och Equipment.
- Power App visar RunStatus och LogEvents.
- AutoMappScript läser från lista/cache.
- Lokal CSV/cache finns som fallback.

## Fas 5: Template/mapping hardening

- En template i taget.
- Jämför output mot nuvarande AutoMappScript.
- Undvik Excel COM i 24/7-jobbet.
- Mapping-generatorn kan komma senare; den ska inte blockera MVP.
