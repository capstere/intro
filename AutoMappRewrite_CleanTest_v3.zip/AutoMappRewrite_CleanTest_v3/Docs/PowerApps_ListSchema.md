# Power Apps / SharePoint Lists - föreslagen MVP schema

## AutoMap_ProductMap

- MaterialKey
- Aliases
- Assay
- AssayFamily
- HighPos
- MatRev
- Product
- SealAssay
- PartNr
- Ultra
- DoubleSampling
- HPV
- Carba
- Japan
- NaText
- Active
- Notes

## AutoMap_RunStatus

- Title = Current
- Enabled
- LastHeartbeat
- LastRunStart
- LastRunEnd
- LastResult
- ScriptVersion
- HostName
- CurrentStep
- LastError

## AutoMap_LogEvents

- EventTime
- Severity
- Source
- Message
- Material
- LSP
- OrderNo
- Batch
- RunId
- ScriptVersion
- Acknowledged
- AcknowledgedBy
- AcknowledgedAt

## AutoMap_MissingProducts

- MaterialKey
- FirstSeen
- LastSeen
- Count
- LastOrderNo
- LastLSP
- Status
- CreatedProductMapItem
