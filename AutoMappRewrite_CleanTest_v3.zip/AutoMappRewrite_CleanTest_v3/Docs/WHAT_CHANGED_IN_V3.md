# Vad som ändrades i v3

V3 är en förbättring av v2 baserat på det användbara i agentens pilot.

## Taget från agentens idé

- Ett tydligare `Process-Lot`-liknande anrop.
- Materialdriven körning i stället för hårdkodade switchar.
- Automatisk keyword merge från produktdata, t.ex. `PARTNR`, `ASSAY`, `PRODUCT`, `SEALASSAY`, `MATREV`, `ULTRA`, `HIGHPOS`, `NA`.
- Fält i `ProductMap.csv` för template/mapping: `TemplateFolder`, `SourceWorkbookFile`, `ReferenceFile`, `TemplateFile`, `MappingFile`.

## Medvetet inte taget från agentens paket

- Inga Unicode-minus.
- Ingen default UNC-path.
- Ingen saknad demo-input.
- Ingen inbäddad SharePoint/certifikatnyckel.
- Ingen Excel COM-körning.
- Ingen beroendekrav på ImportExcel för vanlig dry-run.

## Nytt i v3

- `Process-AutoMapLot` i `Modules\AutoMapCore\AutoMapCore.psm1`.
- `Process-Lot` wrapper för att matcha agentens exempel.
- `Run-ProcessLot-Example.ps1`.
- Preflight-check i `Run-Test.ps1`.
- Utökad `ProductMap.csv` med både gamla AutoMappScript-fält och agentens template/mapping-fält.
- Bättre loggrad med `Material`, `LotNumber` och `RunId`.
