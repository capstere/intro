@echo off
setlocal
cd /d "%~dp0"
title AutoMapp Rewrite Clean Test v3

echo.
echo ================================================
echo  AutoMapp Rewrite Clean Test v3
echo ================================================
echo.
echo This runs a local dry-run only:
echo  - No SharePoint
echo  - No UNC path
echo  - No Excel COM
echo  - Output: C:\AutoMappRewriteTest, or user profile fallback
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Run-Test.ps1" -Force -Pause

endlocal
