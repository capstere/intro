<#
.SYNOPSIS
    One-command test runner for AutoMapp Rewrite clean test package v3.

.DESCRIPTION
    This runner tests the new data-driven Process-AutoMapLot path:
    - No SharePoint connection
    - No UNC or personal paths
    - No Excel COM automation
    - Reads Data\ProductMap.csv
    - Copies DemoInput\Target.xlsx to local output
    - Applies DemoInput\Deviations.json with Open XML SDK
    - Writes summary, status.json and Logs\AutoMap_LogEvents.csv

.NOTES
    Designed for Windows PowerShell 5.1.
#>
[CmdletBinding()]
param(
    [string]$ConfigPath = $null,
    [string]$DryRunRoot = $null,
    [switch]$Force,
    [switch]$Pause
)

$ErrorActionPreference = 'Stop'
$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

function Write-Step {
    param([string]$Text)
    Write-Host "[AutoMapp Test] $Text"
}

try {
    if ([string]::IsNullOrWhiteSpace($ConfigPath)) {
        $ConfigPath = Join-Path $ScriptRoot 'Config\AutoMapp.CleanTest.config.json'
    }

    $coreModule = Join-Path $ScriptRoot 'Modules\AutoMapCore\AutoMapCore.psm1'
    $mappingModule = Join-Path $ScriptRoot 'Modules\DocumentMapping\DocumentMapping.psm1'

    if (-not (Test-Path -LiteralPath $coreModule)) { throw "Missing module: $coreModule" }
    if (-not (Test-Path -LiteralPath $mappingModule)) { throw "Missing module: $mappingModule" }

    Import-Module $coreModule -Force
    Import-Module $mappingModule -Force

    Write-Step 'Running preflight checks.'
    $preflight = Test-AutoMapPackagePreflight -PackageRoot $ScriptRoot
    $errors = @($preflight | Where-Object { $_.Level -eq 'Error' })
    if ($errors.Count -gt 0) {
        $errors | Format-Table -AutoSize
        throw 'Preflight failed. Fix the errors above before continuing.'
    }

    Write-Step 'Preflight OK.'
    Write-Step 'Running Process-AutoMapLot dry-run.'

    $keywords = @{
        '%DATE%' = (Get-Date -Format 'yyyy MM dd')
        '%EXTRA_NOTE%' = 'Dry-run v3'
    }

    $result = Process-AutoMapLot `
        -Material 'GXMTB/RIF-ULTRA-10' `
        -LotNumber '96104' `
        -BatchNumber '1001525941' `
        -LspNumber '96104' `
        -ExpirationDate '2027 09 12' `
        -Keywords $keywords `
        -ConfigPath $ConfigPath `
        -DryRunRoot $DryRunRoot `
        -Force:$Force

    Write-Host ''
    Write-Host 'DONE - v3 dry-run completed.' -ForegroundColor Green
    Write-Host ''
    Write-Host 'Open this workbook in Excel:'
    Write-Host "  $($result.TargetPath)"
    Write-Host ''
    Write-Host 'Check summary:'
    Write-Host "  $($result.SummaryPath)"
    Write-Host ''
    Write-Host 'Check status/log:'
    $config = Read-AutoMapConfig -ConfigPath $ConfigPath
    $resolvedRoot = Initialize-AutoMapDryRunRoot -Config $config -DryRunRoot $DryRunRoot
    Write-Host "  $(Join-Path $resolvedRoot 'status.json')"
    Write-Host "  $(Join-Path (Join-Path $resolvedRoot ([string]$config.LogSubFolder)) 'AutoMap_LogEvents.csv')"
    Write-Host ''
}
catch {
    Write-Host ''
    Write-Host 'FAILED - v3 dry-run stopped.' -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
finally {
    if ($Pause) {
        Write-Host ''
        Read-Host 'Press Enter to close'
    }
}
