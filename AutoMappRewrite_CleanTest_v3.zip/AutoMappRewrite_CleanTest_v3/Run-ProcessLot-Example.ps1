<#
.SYNOPSIS
    Minimal manual example showing the agent-inspired Process-Lot call.

.DESCRIPTION
    This is not the main launcher. START_HERE.cmd / Run-Test.ps1 are still the easiest path.
#>
[CmdletBinding()]
param(
    [switch]$Force
)

$ErrorActionPreference = 'Stop'
$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

Import-Module (Join-Path $ScriptRoot 'Modules\AutoMapCore\AutoMapCore.psm1') -Force
Import-Module (Join-Path $ScriptRoot 'Modules\DocumentMapping\DocumentMapping.psm1') -Force

$keywords = @{
    '%DATE%' = (Get-Date -Format 'yyyy MM dd')
}

$result = Process-Lot `
    -Material 'GXMTB/RIF-ULTRA-10' `
    -LotNumber '96104' `
    -BatchNumber '1001525941' `
    -LspNumber '96104' `
    -ExpirationDate '2027 09 12' `
    -Keywords $keywords `
    -Force:$Force

$result | Format-List
