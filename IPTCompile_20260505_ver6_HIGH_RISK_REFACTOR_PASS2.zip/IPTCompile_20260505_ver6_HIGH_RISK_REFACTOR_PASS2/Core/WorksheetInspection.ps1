﻿# Auto-extracted from Main.ps1 in high-risk refactor pass 2.
# Behavior should remain unchanged; functions were moved without intentional logic edits.

if (-not (Get-Command Find-RegexCell -ErrorAction SilentlyContinue)) {
        function Find-RegexCell {
            param(
                [OfficeOpenXml.ExcelWorksheet]$Ws,
                [regex]$Rx,
                [int]$MaxRows = 200,
                [int]$MaxCols = 40
            )
            if (-not $Ws -or -not $Ws.Dimension) { return $null }

            $rMax = [Math]::Min($Ws.Dimension.End.Row, $MaxRows)
            $cMax = [Math]::Min($Ws.Dimension.End.Column, $MaxCols)

            for ($r = 1; $r -le $rMax; $r++) {
                for ($c = 1; $c -le $cMax; $c++) {
                    $t = Normalize-HeaderText ($Ws.Cells[$r,$c].Text + '')
                    if ($t -and $Rx.IsMatch($t)) {
                        return @{ Row = $r; Col = $c; Text = $t }
                    }
                }
            }
            return $null
        }
    }

if (-not (Get-Command Get-SealHeaderDocInfo -ErrorAction SilentlyContinue)) {
        function Get-SealHeaderDocInfo {
            param([OfficeOpenXml.ExcelPackage]$Pkg)

            $result = [pscustomobject]@{ Raw=''; DocNo=''; Rev='' }
            if (-not $Pkg) { return $result }

            $ws = $Pkg.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' } | Select-Object -First 1
            if (-not $ws) { return $result }

            try {
                $lt = ($ws.HeaderFooter.OddHeader.LeftAlignedText + '').Trim()
                if (-not $lt) { $lt = ($ws.HeaderFooter.EvenHeader.LeftAlignedText + '').Trim() }

                $result.Raw = $lt

                $rx = [regex]'(?i)(?:document\s*(?:no|nr|#|number)\s*[:#]?\s*([A-Z0-9\-_\.\/]+))?.*?(?:rev(?:ision)?\.?\s*[:#]?\s*([A-Z0-9\-_\.]+))?'
                $m = $rx.Match($lt)
                if ($m.Success) {
                    if ($m.Groups[1].Value) { $result.DocNo = $m.Groups[1].Value.Trim() }
                    if ($m.Groups[2].Value) { $result.Rev   = $m.Groups[2].Value.Trim() }
                }
            } catch {}

            return $result
        }
    }

if (-not (Get-Command Find-LabelValueRightward -ErrorAction SilentlyContinue)) {
        function Find-LabelValueRightward {
            param(
                [OfficeOpenXml.ExcelWorksheet]$Ws,
                [string]$Label,
                [int]$MaxRows = 200,
                [int]$MaxCols = 40
            )
            if (-not $Ws -or -not $Ws.Dimension) { return $null }

            $normLbl = Normalize-HeaderText $Label
            $pat = '^(?i)\s*' + [regex]::Escape($normLbl).Replace('\ ', '\s*') + '\s*[:\.]*\s*$'
            $rx  = [regex]::new($pat, [Text.RegularExpressions.RegexOptions]::IgnoreCase)

            $hit = Find-RegexCell -Ws $Ws -Rx $rx -MaxRows $MaxRows -MaxCols $MaxCols
            if (-not $hit) { return $null }

            $cMax = [Math]::Min($Ws.Dimension.End.Column, $MaxCols)
            for ($c = $hit.Col + 1; $c -le $cMax; $c++) {
                $t = Normalize-HeaderText ($Ws.Cells[$hit.Row,$c].Text + '')
                if ($t) { return $t }
            }
            return $null
        }
    }

