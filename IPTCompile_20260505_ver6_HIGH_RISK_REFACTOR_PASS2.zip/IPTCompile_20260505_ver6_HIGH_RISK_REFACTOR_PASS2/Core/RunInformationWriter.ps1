﻿# Auto-extracted from Main.ps1 in high-risk refactor pass 2.
# Behavior should remain unchanged; functions were moved without intentional logic edits.

if (-not (Get-Command Write-SPBlockIntoInformation -ErrorAction SilentlyContinue)) {
    function Write-SPBlockIntoInformation {
        param(
            [Parameter(Mandatory)][OfficeOpenXml.ExcelPackage]$Pkg,
            [Parameter()][object[]]$Rows,
            [Parameter()][string]$Batch,
            [Parameter()][string]$TargetSheetName = 'Run Information',
            [Parameter()][int]$StartRow = 1,
            [Parameter()][int]$StartCol = 5 # E = 5
        )

        if (-not $Pkg) { return $false }
        $Rows = @($Rows)

        $ws = $Pkg.Workbook.Worksheets[$TargetSheetName]
        if (-not $ws) { return $false }

        $labelCol = $StartCol
        $valueCol = $StartCol + 1

        # Harmoniserade färger (matchar CSV Sammanfattning)
        $HeaderBg   = [System.Drawing.Color]::FromArgb(68, 84, 106)    # Mörkblå
        $HeaderFg   = [System.Drawing.Color]::White
        $SectionBg  = [System.Drawing.Color]::FromArgb(217, 225, 242)  # Ljusblå
        $SectionFg  = [System.Drawing.Color]::FromArgb(0, 32, 96)      # Mörkblå text
        $BorderColor = [System.Drawing.Color]::FromArgb(68, 84, 106)

        # Rensa tidigare block (bara i block-ytan, påverkar inte A-D)
        try {
            $clearRows = 120
            $rngClear = $ws.Cells[$StartRow, $labelCol, ($StartRow + $clearRows - 1), $valueCol]
            $rngClear.Clear()
        } catch {}

        # Huvudrubrik
        $ws.Cells[$StartRow, $labelCol].Value = "SharePoint Info"
        $ws.Cells[$StartRow, $valueCol].Value = ""
        $ws.Cells[$StartRow, $labelCol, $StartRow, $valueCol].Merge = $true
        $ws.Cells[$StartRow, $labelCol].Style.Font.Bold = $true
        $ws.Cells[$StartRow, $labelCol].Style.Font.Size = 14
        $ws.Cells[$StartRow, $labelCol].Style.Font.Name = "Calibri"
        $ws.Cells[$StartRow, $labelCol].Style.Font.Color.SetColor($HeaderFg)
        $ws.Cells[$StartRow, $labelCol].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $ws.Cells[$StartRow, $labelCol].Style.Fill.BackgroundColor.SetColor($HeaderBg)
        $ws.Cells[$StartRow, $labelCol].Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Left
        $ws.Cells[$StartRow, $labelCol].Style.VerticalAlignment   = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
        $ws.Row($StartRow).Height = 22

        $r = $StartRow + 1

        if (-not $Rows -or $Rows.Count -eq 0 -or $Rows[0] -eq $null) {
            # Tom data
            $ws.Cells[$r, $labelCol].Value = "Batch"
            $ws.Cells[$r, $valueCol].Value = $Batch
            $r++
            $ws.Cells[$r, $labelCol].Value = "Status"
            $ws.Cells[$r, $valueCol].Value = "SharePoint avstängt för optimering."
            $lastRow = $r
        } else {
            foreach ($row in $Rows) {
                $ws.Cells[$r, $labelCol].Value = $row.Rubrik
                # Normalisera värdet (tar bort NBSP/tabbar/extra whitespace som kan få kolumnen att se "bred" ut)
                $val = $row.'Värde'
                $valN = Normalize-HeaderText (($val + ''))
                $valN = ($valN -replace '\s+', ' ').Trim()
                $ws.Cells[$r, $valueCol].Value = $valN
                $r++
            }
            $lastRow = $r - 1
        }

        # Styling rubrik-kolumn
        try {
            $labelRange = $ws.Cells[($StartRow + 1), $labelCol, $lastRow, $labelCol]
            $labelRange.Style.Font.Bold = $true
            $labelRange.Style.Font.Name = "Calibri"
            $labelRange.Style.Font.Size = 10
            $labelRange.Style.Font.Color.SetColor($SectionFg)
            $labelRange.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $labelRange.Style.Fill.BackgroundColor.SetColor($SectionBg)

            # Styling värde-kolumn
            $valueRange = $ws.Cells[($StartRow + 1), $valueCol, $lastRow, $valueCol]
            $valueRange.Style.Font.Name = "Calibri"
            $valueRange.Style.Font.Size = 10
            $valueRange.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $valueRange.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::White)
            $valueRange.Style.WrapText = $true
            $valueRange.Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Top
            $valueRange.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Left

            # Borders kring block
            $rng = $ws.Cells[$StartRow, $labelCol, $lastRow, $valueCol]
            $rng.Style.Border.Top.Style    = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Left.Style   = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Right.Style  = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Top.Color.SetColor($BorderColor)
            $rng.Style.Border.Bottom.Color.SetColor($BorderColor)
            $rng.Style.Border.Left.Color.SetColor($BorderColor)
            $rng.Style.Border.Right.Color.SetColor($BorderColor)
        } catch {}

# Run Information: template styr kolumnbredder.
# Koden får inte skriva över E/F-bredd.
try { $ws.Column($valueCol).Style.ShrinkToFit = $false } catch {}
        try {
            $script:RunInfoSpBlockStartRow = $StartRow
            $script:RunInfoSpBlockLastRow  = $lastRow
            $script:RunInfoSpBlockStartCol = $StartCol
        } catch {}
        return $true
    }
}

if (-not (Get-Command Get-RunInformationColumnWidths -ErrorAction SilentlyContinue)) {
    function Get-RunInformationColumnWidths {
        param(
            [Parameter(Mandatory=$true)]$Ws,
            [int[]]$Columns = @(1,2,3,4,5,6,7,8)
        )
        $map = @{}
        if (-not $Ws) { return $map }
        foreach ($c in $Columns) {
            try {
                $map[[int]$c] = [double]$Ws.Column([int]$c).Width
            } catch {}
        }
        return $map
    }
}

if (-not (Get-Command Restore-RunInformationColumnWidths -ErrorAction SilentlyContinue)) {
    function Restore-RunInformationColumnWidths {
        param(
            [Parameter(Mandatory=$true)]$Ws,
            [Parameter(Mandatory=$true)][hashtable]$Widths
        )
        if (-not $Ws -or -not $Widths) { return }
        foreach ($key in @($Widths.Keys)) {
            try {
                $col = [int]$key
                $Ws.Column($col).Width = [double]$Widths[$key]
                $Ws.Column($col).BestFit = $false
            } catch {}
        }
        try { $Ws.Column(6).Style.ShrinkToFit = $false } catch {}
        try { $Ws.Column(6).Style.WrapText = $false } catch {}
    }
}

function Find-InfoRow {
            param([OfficeOpenXml.ExcelWorksheet]$Ws, [string]$Label)
            if (-not $Ws -or -not $Ws.Dimension) { return $null }
            $maxRow = [Math]::Min($Ws.Dimension.End.Row, 300)
            for ($ri=1; $ri -le $maxRow; $ri++) {
                $txt = (($Ws.Cells[$ri,1].Text) + '').Trim()
                if (-not $txt) { continue }
                if ($txt.ToLowerInvariant() -eq $Label.ToLowerInvariant()) { return $ri }
            }
            return $null
        }

if (-not (Get-Command Add-Hyperlink -ErrorAction SilentlyContinue)) {
        function Add-Hyperlink {
            param(
                [OfficeOpenXml.ExcelRange]$Cell,
                [string]$Text,
                [string]$Url
            )
            try {
                $Cell.Value = $Text
                $Cell.Hyperlink = [Uri]$Url
                $Cell.Style.Font.UnderLine = $true
                $Cell.Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(0,102,204))
            } catch {}
        }
    }

