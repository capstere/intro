﻿# Auto-extracted from Main.ps1 in high-risk refactor pass 2.
# Behavior should remain unchanged; functions were moved without intentional logic edits.

function _SignSealTestSheets([object]$pkg, [string]$sigText, [string]$sigCell, [bool]$overwrite) {
                $written = 0; $skipped = 0
                if (-not $pkg) { return @{ Written = 0; Skipped = 0 } }
                foreach ($ws in $pkg.Workbook.Worksheets) {
                    if ($ws.Name -eq 'Worksheet Instructions') { continue }
                    $h3 = Get-CellText $ws $Layout.SealActiveCheckCell
                    if ($h3 -match '^[0-9]') {
                        $existing = Get-CellText $ws $sigCell
                        if ($existing -and -not $overwrite) { $skipped++; continue }
                        $ws.Cells[$sigCell].Style.Numberformat.Format = '@'
                        $ws.Cells[$sigCell].Value = $sigText
                        $written++
                    }
elseif ([string]::IsNullOrWhiteSpace($h3) -or $h3 -match '^(?i)(N\/?A|NA|Tomt( innehåll)?)$') {
    break
}
                }
                return @{ Written = $written; Skipped = $skipped }
            }

function _BuildUnsignedSealText([string[]]$sheetNames) {
            $arr = @($sheetNames | Where-Object { $_ })
            if ($arr.Count -eq 0) { return '' }
            $arr = @($arr | Select-Object -Unique)
            if ($arr.Count -eq 1) { return ($arr[0] + ' osignerat') }
            return (($arr -join ', ') + ' osignerade')
        }

if (-not (Get-Command Set-MergedWrapAutoHeight -ErrorAction SilentlyContinue)) {
            function Set-MergedWrapAutoHeight {
                param([OfficeOpenXml.ExcelWorksheet]$Sheet,[int]$RowIndex,[int]$ColStart=2,[int]$ColEnd=3,[string]$Text)
                $rng = $Sheet.Cells[$RowIndex, $ColStart, $RowIndex, $ColEnd]
                $rng.Style.WrapText = $true
                $rng.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::None
                $Sheet.Row($RowIndex).CustomHeight = $false
                try {
                    $wChars = [Math]::Floor(($Sheet.Column($ColStart).Width + $Sheet.Column($ColEnd).Width) - 2); if ($wChars -lt 1) { $wChars = 1 }
                    $segments = $Text -split "(\r\n|\n|\r)"; $lineCount = 0
                    foreach ($seg in $segments) { if (-not $seg) { $lineCount++ } else { $lineCount += [Math]::Ceiling($seg.Length / $wChars) } }
                    if ($lineCount -lt 1) { $lineCount = 1 }
                    $targetHeight = [Math]::Max(15, [Math]::Ceiling(15 * $lineCount * 2.15))
                    if ($Sheet.Row($RowIndex).Height -lt $targetHeight) {
                        $Sheet.Row($RowIndex).Height = $targetHeight
                        $Sheet.Row($RowIndex).CustomHeight = $true
                    }
                } catch { $Sheet.Row($RowIndex).CustomHeight = $false }
            }
        }

