# Extracted from Main.ps1 during high-risk refactor.
# Intent: keep Main.ps1 as orchestration/UI and move reusable helpers into focused modules.

function Get-UniqueRegexTokens {
    param(
        [object[]]$Values,
        [string]$Regex
    )
    $seen = @{}
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($v0 in @($Values)) {
        $s = ('' + $v0)
        if ([string]::IsNullOrWhiteSpace($s)) { continue }
        foreach ($m in [regex]::Matches($s, $Regex)) {
            $tok = ''
            if ($m.Groups.Count -gt 1) { $tok = $m.Groups[1].Value }
            else { $tok = $m.Value }
            $tok = ($tok + '').Trim()
            if (-not $tok) { continue }
            if (-not $seen.ContainsKey($tok)) {
                $seen[$tok] = $true
                [void]$out.Add($tok)
            }
        }
    }
    return @($out.ToArray())
}

function Get-BatchTokenList {
    param([object[]]$Values)
    return @(Get-UniqueRegexTokens -Values $Values -Regex '(?<!\d)(\d{10})(?!\d)')
}

function Get-LspTokenList {
    param([object[]]$Values)
    return @(Get-UniqueRegexTokens -Values $Values -Regex '(?<![A-Za-z0-9])(\d{5})(?!\d)')
}

function Join-TokenList {
    param([object[]]$Tokens)
    $t = @($Tokens | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    if ($t.Count -eq 0) { return '—' }
    return ($t -join ', ')
}

function Get-SpRowValue {
    param(
        [object[]]$Rows,
        [string]$Label
    )
    foreach ($r in @($Rows)) {
        if (-not $r) { continue }
        if ((($r.Rubrik + '').Trim()) -eq $Label) {
            return (($r.'Värde' + '').Trim())
        }
    }
    return ''
}

function Compare-TokenSetExact {
    param(
        [object[]]$Expected,
        [object[]]$Actual
    )
    $exp = @($Expected | Where-Object { $_ } | Sort-Object -Unique)
    $act = @($Actual   | Where-Object { $_ } | Sort-Object -Unique)
    if ($exp.Count -eq 0 -and $act.Count -eq 0) {
        return [pscustomobject]@{
            Status  = 'NoData'
            Missing = @()
            Extra   = @()
        }
    }
    if ($exp.Count -eq 0) {
        return [pscustomobject]@{
            Status  = 'NoRef'
            Missing = @()
            Extra   = $act
        }
    }
    if ($act.Count -eq 0) {
        return [pscustomobject]@{
            Status  = 'MissingActual'
            Missing = $exp
            Extra   = @()
        }
    }
    $missing = @($exp | Where-Object { $act -notcontains $_ })
    $extra   = @($act | Where-Object { $exp -notcontains $_ })
    if ($missing.Count -eq 0 -and $extra.Count -eq 0) {
        return [pscustomobject]@{
            Status  = 'Match'
            Missing = @()
            Extra   = @()
        }
    }
    return [pscustomobject]@{
        Status  = 'Mismatch'
        Missing = $missing
        Extra   = $extra
    }
}

function Test-SharePointBatchLspConsistency {
    param(
        [object[]]$Rows,
        [object]$HeaderWs,
        [object[]]$WorksheetHeaderRows,
        [string]$SealPosPath,
        [string]$SealNegPath,
        [string]$SearchedLsp,
        [object]$BatchInfo
    )
    if (-not $Rows -or @($Rows).Count -eq 0) {
        return [pscustomobject]@{
            Status  = 'NoRef'
            Message = ''
        }
    }
    $spOrderRaw = Get-SpRowValue -Rows $Rows -Label 'Order#'
    $spBatch1   = Get-SpRowValue -Rows $Rows -Label 'SAP Batch#'
    $spBatch2   = Get-SpRowValue -Rows $Rows -Label 'SAP Batch# 2'
    $spLspRaw   = Get-SpRowValue -Rows $Rows -Label 'LSP'
    $expectedOrder = ''
    try { if ($BatchInfo -and $BatchInfo.Order) { $expectedOrder = Normalize-OrderNumber $BatchInfo.Order } } catch {}
    $spOrder = Normalize-OrderNumber $spOrderRaw
    $spBatchTokens = @(Get-BatchTokenList -Values @($spBatch1, $spBatch2))
    $spLspTokens   = @(Get-LspTokenList   -Values @($spLspRaw))
    $wsBatchVals = @()
    $wsLspVals   = @()
    try {
        if ($HeaderWs) {
            $wsBatchVals += $HeaderWs.BatchNo
            $wsLspVals   += $HeaderWs.CartridgeNo
        }
    } catch {}
    try {
        foreach ($r in @($WorksheetHeaderRows)) {
            if (-not $r) { continue }
            $wsBatchVals += $r.BatchNo
            $wsLspVals   += $r.CartridgeNo
        }
    } catch {}
    $sealPosBatch = ''
    $sealNegBatch = ''
    try { if ($SealPosPath) { $sealPosBatch = Get-BatchNumberFromSealFile $SealPosPath } } catch {}
    try { if ($SealNegPath) { $sealNegBatch = Get-BatchNumberFromSealFile $SealNegPath } } catch {}
    $batchInfoBatch = ''
    try { if ($BatchInfo -and $BatchInfo.Batch) { $batchInfoBatch = $BatchInfo.Batch } } catch {}
    $fileBatchTokens = @(Get-BatchTokenList -Values @($wsBatchVals + $sealPosBatch + $sealNegBatch + $batchInfoBatch))
    $fileLspTokens   = @(Get-LspTokenList   -Values @($wsLspVals + $SearchedLsp))
    $batchCmp = Compare-TokenSetExact -Expected $spBatchTokens -Actual $fileBatchTokens
    $lspCmp   = Compare-TokenSetExact -Expected $spLspTokens   -Actual $fileLspTokens
    $parts = New-Object System.Collections.Generic.List[string]
    $status = 'Match'
    $orderMessage = ''
    $batchMessage = ''
    $lspMessage = ''
    if ($expectedOrder -and $spOrder -and $expectedOrder -eq $spOrder) {
        $orderMessage = ("✓ SP=[{0}] Seal=[{1}]" -f $spOrder, $expectedOrder)
        [void]$parts.Add(("Order# {0}" -f $orderMessage))
    }
    else {
        $status = 'Mismatch'
        $orderMessage = ("⚠ SP=[{0}] Seal=[{1}]" -f $(if($spOrder){$spOrder}else{'—'}), $(if($expectedOrder){$expectedOrder}else{'—'}))
        [void]$parts.Add(("Order# {0}" -f $orderMessage))
    }
    if ($batchCmp.Status -eq 'Match') {
        $batchMessage = ("✓ SP=[{0}] Filer=[{1}]" -f (Join-TokenList $spBatchTokens), (Join-TokenList $fileBatchTokens))
        [void]$parts.Add(("Batch {0}" -f $batchMessage))
    }
    else {
        $status = 'Mismatch'
        $batchMessage = ("⚠ SP=[{0}] Filer=[{1}]" -f (Join-TokenList $spBatchTokens), (Join-TokenList $fileBatchTokens))
        [void]$parts.Add(("Batch {0}" -f $batchMessage))
    }
    if ($lspCmp.Status -eq 'Match') {
        $lspMessage = ("✓ SP=[{0}] Filer/Sökning=[{1}]" -f (Join-TokenList $spLspTokens), (Join-TokenList $fileLspTokens))
        [void]$parts.Add(("LSP {0}" -f $lspMessage))
    }
    else {
        $status = 'Mismatch'
        $lspMessage = ("⚠ SP=[{0}] Filer/Sökning=[{1}]" -f (Join-TokenList $spLspTokens), (Join-TokenList $fileLspTokens))
        [void]$parts.Add(("LSP {0}" -f $lspMessage))
    }
    $prefix = if ($status -eq 'Match') { '✓ Match' } else { '⚠ Mismatch' }
    return [pscustomobject]@{
        Status       = $status
        Message      = ($prefix + ' — ' + (@($parts.ToArray()) -join ' / '))
        SummaryText  = $prefix
        OrderStatus  = if ($orderMessage -like '⚠*') { 'Mismatch' } else { 'Match' }
        OrderMessage = $orderMessage
        BatchStatus  = if ($batchMessage -like '⚠*') { 'Mismatch' } else { 'Match' }
        BatchMessage = $batchMessage
        LspStatus    = if ($lspMessage -like '⚠*') { 'Mismatch' } else { 'Match' }
        LspMessage   = $lspMessage
    }
}

