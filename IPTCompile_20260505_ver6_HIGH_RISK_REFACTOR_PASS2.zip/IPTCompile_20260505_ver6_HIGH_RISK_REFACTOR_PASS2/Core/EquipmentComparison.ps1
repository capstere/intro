﻿# Auto-extracted from Main.ps1 in high-risk refactor pass 2.
# Behavior should remain unchanged; functions were moved without intentional logic edits.

function _EquipTokens([string]$s) {
            if ([string]::IsNullOrWhiteSpace($s)) { return @() }
            $parts = $s -split '[,;]' |
                ForEach-Object { ($_ -replace '\s+', ' ').Trim() } |
                Where-Object { $_ }
            $tok  = New-Object System.Collections.Generic.List[string]
            $seen = @{}
            foreach ($p in $parts) {
                $v = (Normalize-HeaderText $p).Trim().ToUpper()
                $v = $v -replace '^(NR\.?|NO\.?)\s*', ''
                $v = $v -replace '[^A-Z0-9_-]', ''
                if ($v -and -not $seen.ContainsKey($v)) {
                    $seen[$v] = $true
                    [void]$tok.Add($v)
                }
            }
            return @($tok.ToArray())
        }

function _EquipPretty([string[]]$tokens, [string]$label) {
            # StrictMode-säker: $tokens kan vara $null eller ett enstaka värde beroende på källa
            if (@($tokens).Count -eq 0) { return '' }
            $seen = @{}
            $t = New-Object System.Collections.Generic.List[string]
            foreach ($item in @($tokens)) {
                $v = ('' + $item).Trim()
                if (-not $v) { continue }
                if (-not $seen.ContainsKey($v)) {
                    $seen[$v] = $true
                    [void]$t.Add($v)
                }
            }
            $out = @($t.ToArray())
            if ($label -ieq 'Timer ID Number') {
                # Visa som "Nr. 24, Nr. 25"
                return (($out | ForEach-Object {
                    if (('' + $_) -match '^(?i)NR\.') { $_ } else { "Nr. $_" }
                }) -join ', ')
            }
            return ($out -join ', ')
        }

function _FixMonthText([string]$s) {
            if ([string]::IsNullOrWhiteSpace($s)) { return '' }
            $t = (Normalize-HeaderText $s).Trim()
            # Byt ut kyrillisk A (А/а) mot latin A – vanligt i "Аpr-26"
            $t = $t -replace '[Аа]', 'A'
            $t = ($t -replace '\s+', ' ').Trim()
            return $t
        }

function _EquipMonthTokens([string]$s) {
            if ([string]::IsNullOrWhiteSpace($s)) { return @() }
            $parts = $s -split '[,;]' |
                ForEach-Object { _FixMonthText $_ } |
                Where-Object { $_ }
            $tok  = New-Object System.Collections.Generic.List[string]
            $seen = @{}
            foreach ($p in $parts) {
                $v = ('' + $p).Trim().ToUpper()
                if ($v -and -not $seen.ContainsKey($v)) {
                    $seen[$v] = $true
                    [void]$tok.Add($v)
                }
            }
            return @($tok.ToArray())
        }

function _EquipEvalList([string]$actual, [string]$expected) {
            # Returnerar: Match | Delvis | Saknas | Mismatch | Ingen referens
            if ([string]::IsNullOrWhiteSpace($expected)) { return 'NoRef' }
            $aT = _EquipTokens $actual
            $eT = _EquipTokens $expected
            # StrictMode-säker: Count på $null kastar i StrictMode
            if (@($aT).Count -eq 0) { return 'Saknas' }
            foreach ($a in $aT) { if (-not ($eT -contains $a)) { return 'Mismatch' } }
            foreach ($e in $eT) { if (-not ($aT -contains $e)) { return 'Delvis' } }
            return 'Match'
        }

function _EquipEvalMonth([string]$actual, [string]$expected) {
            # Returnerar: Match | Delvis | Saknas | Mismatch | NoRef
            if ([string]::IsNullOrWhiteSpace($expected)) { return 'NoRef' }
            $aT = _EquipMonthTokens $actual
            $eT = _EquipMonthTokens $expected
            if (@($aT).Count -eq 0) { return 'Saknas' }
            foreach ($a in $aT) {
                if (-not ($eT -contains $a)) { return 'Mismatch' }
            }
            foreach ($e in $eT) {
                if (-not ($aT -contains $e)) { return 'Delvis' }
            }
            return 'Match'
        }

function _Txt($s) {
                    switch ($s) {
                        'Match'   { '✓ Match' }
                        'Delvis'  { '✓ Delvis' }
                        'Saknas'  { '⚠ Saknas' }
                        'Mismatch'{ '⚠ Mismatch' }
                        default   { '?' }
                    }
                }

function _CleanSheets([string[]]$arr) {
                    ($arr | ForEach-Object { ($_ -replace '@.*$','').Trim() } | Select-Object -Unique) -join ', '
                }

