﻿@{
    'v1.3.6 2026 04 26' = @'
Nytt i denna version:

• Den här dialogrutan.
• SharePoint Order/Batch/LSP visas tydligare i Run Information.
• Säkrare hantering av HPV Sample code 0.
• Seal Test "N/A" triggar inte längre falsk "Saknar utvägning".

'@
    'v1.3.8 2026 04 28' = @'
Nytt i denna version:

• SharePoint-sökning använder Order# som primär nyckel.
• SP Kontroll visas tydligare i Run Information med egna rader för Order#, Batch# och LSP.
• Batch# och LSP används som verifieringsvärden, inte som primär SharePoint-nyckel.
• QC Data-påminnelsen flyttas ned automatiskt så att den inte överlappar SharePoint-blocket.
• Split-batch visas och kontrolleras mer robust.

'@
    'v1.3.9 2026 05 01' = @'
Nytt i denna version:

• Mindre korrigeringar av rapportflikarna.

'@
    'v1.4.0 2026 05 05' = @'
Nytt i denna version:

• Fixat Seal Test POS/NEG säger rätt: Print Full Name, Sign, and Date

'@
    'v1.4.1 2026 05 05' = @'
Nytt i denna version:

• Fixat "Test Type" i rapport.

'@
    'v1.4.3 2026 05 05' = @'
Nytt i denna version:

Om Seal Test POS/NEG är öppen i Excel:
→ signering stoppas innan skrivning

Om Worksheet är öppen i Excel:
→ signering stoppas innan signeringsplan/skrivning

Om någon öppnar Worksheet efter kontroll men före skrivning:
→ OpenXML-skrivningen försöker ta exklusivt lås
→ misslyckas säkert i stället för att skriva delvis

Om Excel ägarfil "~$..." finns:
→ signering stoppas

'@
}