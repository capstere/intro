﻿# Auto-extracted from Main.ps1 in high-risk refactor pass 2.
# Behavior should remain unchanged; functions were moved without intentional logic edits.

function Get-CleanLeaf([string]$Path) {
        if (-not $Path) { return '' }
        $leaf = Split-Path $Path -Leaf
        $leaf -replace '^(CSV_Primary|CSV_Resample|SealNEG|SealPOS|Worksheet)__', ''
    }

function Mark-Phase([string]$Name) {
 $now = $buildTimer.ElapsedMilliseconds
 $phaseTimings[$Name] = ($now - $lastPhaseMs)
 Set-Variable -Name lastPhaseMs -Value $now -Scope 1
 }

