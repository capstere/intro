﻿QDIP SharePoint Investigation Package
Created: 2026-04-26 18:25:23

Recommended analysis order:
1. Open ProductionOrders_ImportantFieldMap.csv
2. Open CalculatedFormulas_Cepheid _ Production orders.csv
   - Find "Lead-time"
   - Find "DVM - Current phase lead-time (h)"
   - Find Order type / DVM / IPT testing in progress formulas
3. Open Views_Cepheid _ Production orders.csv
   - Look for views related to Lead, IPT, Review, Delivery, DVM, Active, Archive
4. If order search was exported:
   - Check whether missing old orders appear in REWORK original order fields
   - Check whether Archive contains old Order# / Lead-time
5. If needed, use menu option 8 to export version history for specific items.

Output folder:
C:\Users\jesper.fredriksson\OneDrive - Danaher\Desktop\QDIP_SP_Investigation_20260426_182313
