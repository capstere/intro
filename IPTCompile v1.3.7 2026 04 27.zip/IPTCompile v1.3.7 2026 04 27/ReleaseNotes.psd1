﻿@{
    'v1.3.6 2026 04 26' = @'
Nytt i denna version:

• Den här dialogrutan.
• SharePoint Order/Batch/LSP visas tydligare i Run Information.
• Säkrare hantering av HPV Sample code 0.
• Seal Test "N/A" triggar inte längre falsk "Saknar utvägning".

'@
    'v1.3.7 2026 04 27' = @'
Nytt i denna version:

• Split-batch visas och kontrolleras mer robust.

'@
}