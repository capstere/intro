﻿# Safe refactor: extracted function definitions from Main.ps1

function Get-UserProfileFromConfig {
    param([hashtable]$Config)

    $u = (($env:USERNAME + '').Trim()).ToLowerInvariant()
    if (-not $u) { return $null }

    $users = $null
    try { $users = $Config.Users } catch { $users = $null }

    if ($users -and ($users -is [System.Collections.IDictionary]) -and $users.Contains($u)) {
        $p = $users[$u]
        return [pscustomobject]@{
            Username         = $u
            FullName         = (($p.FullName + '').Trim())
            SealTestInitials = (($p.SealTestInitials + '').Trim())
        }
    }
    return $null
}

function Apply-UserDefaults {
    try {
        if (-not $script:UserProfile) { $script:UserProfile = Get-UserProfileFromConfig -Config $Config }
        $p = $script:UserProfile
        if (-not $p) { return }

        # Sammanställning: Full Name + Seal Test initialer
        if ($txtSammName -and -not (($txtSammName.Text + '').Trim())) { $txtSammName.Text = $p.FullName }
        if ($txtSealTestSign -and -not (($txtSealTestSign.Text + '').Trim())) { $txtSealTestSign.Text = $p.SealTestInitials }

        # Granskning: Full Name
        if ($txtGranskName -and -not (($txtGranskName.Text + '').Trim())) { $txtGranskName.Text = $p.FullName }
    } catch {}
}

function Assert-StartupReady {
    if ($global:StartupReady) { return $true }
    Gui-Log "❌ Startkontroll misslyckades. Åtgärda konfigurationsfel innan du fortsätter." 'Error'
    return $false
}

function Show-PasswordInputDialog {
    param(
        [string]$Title = 'Utvecklarlås',
        [string]$Prompt = 'Ange lösenord:',
        [string]$DefaultValue = ''
    )
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text            = $Title
    $dlg.StartPosition   = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox     = $false
    $dlg.MinimizeBox     = $false
    $dlg.ShowInTaskbar   = $false
    $dlg.ClientSize      = New-Object System.Drawing.Size(420, 145)
    $dlg.Font            = New-Object System.Drawing.Font('Segoe UI', 10)
    $lbl = New-Object System.Windows.Forms.Label
    $lbl.AutoSize = $false
    $lbl.Left     = 16
    $lbl.Top      = 16
    $lbl.Width    = 388
    $lbl.Height   = 40
    $lbl.Text     = $Prompt
    $txt = New-Object System.Windows.Forms.TextBox
    $txt.Left = 16
    $txt.Top  = 62
    $txt.Width = 388
    $txt.Text = $DefaultValue
    $txt.UseSystemPasswordChar = $true
    $btnOk = New-Object System.Windows.Forms.Button
    $btnOk.Text = 'OK'
    $btnOk.Width = 90
    $btnOk.Height = 30
    $btnOk.Left = 218
    $btnOk.Top  = 100
    $btnOk.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text = 'Avbryt'
    $btnCancel.Width = 90
    $btnCancel.Height = 30
    $btnCancel.Left = 314
    $btnCancel.Top  = 100
    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $dlg.Controls.Add($lbl)
    $dlg.Controls.Add($txt)
    $dlg.Controls.Add($btnOk)
    $dlg.Controls.Add($btnCancel)
    $dlg.AcceptButton = $btnOk
    $dlg.CancelButton = $btnCancel
    try { $dlg.Add_Shown({ $txt.Focus(); $txt.SelectAll() }) } catch {}
    $res = $null
    try {
        if ($form) { $res = $dlg.ShowDialog($form) }
        else       { $res = $dlg.ShowDialog() }
    } catch {
        $res = $dlg.ShowDialog()
    }
    if ($res -eq [System.Windows.Forms.DialogResult]::OK) {
        return ($txt.Text + '')
    }
    # Behåll gammalt beteende: avbryt ger tom sträng, vilket inte låser upp.
    return ''
}


function Assert-DevUnlocked {
    if ($script:DevUnlocked) { return $true }

    $pwd = $null
    try {
        $pwd = Show-PasswordInputDialog `
            -Title 'Utvecklarlås' `
            -Prompt "TEST-knappen är låst.`nAnge lösenord för att låsa upp (session):" `
            -DefaultValue ''
    } catch {
        try {
            [System.Windows.Forms.MessageBox]::Show(
                "Kunde inte visa lösenordsruta. TEST avbröts.",
                'Utvecklarlås',
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            ) | Out-Null
        } catch {}
        return $false
    }

    if (($pwd + '') -eq $script:DevUnlockPassword) {
        $script:DevUnlocked = $true
        try { Gui-Log "🔓 TEST upplåst för denna session." 'Info' } catch {}
        return $true
    }

    try {
        [System.Windows.Forms.MessageBox]::Show(
            'Fel lösenord. TEST avbröts.',
            'Utvecklarlås',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    } catch {}
    return $false
}

