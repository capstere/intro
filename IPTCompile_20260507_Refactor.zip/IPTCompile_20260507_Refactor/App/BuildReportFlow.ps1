﻿# Extracted from Main.ps1. Registers Build button click handler in caller scope.
# ============================
# ===== RAPPORTLOGIK =========
# ============================

$btnBuild.Add_Click({
    if ($script:_logPlaceholderActive) { $outputBox.Text = ''; $outputBox.ForeColor = [System.Drawing.SystemColors]::WindowText; $script:_logPlaceholderActive = $false }
    #region Build: Rapportgenerering (huvudloop)
    if (-not (Assert-StartupReady)) { return }

    # Hjälpfunktion: ta bort TEMP-prefix (CSV_Primary__, SealNEG__, etc.) från filnamn för ren visning

    if ($script:ScanInProgress) { Gui-Log "⚠️ Sökning pågår – vänta innan du skapar rapport." 'Warn'; return }
    if ($script:BuildInProgress) { Gui-Log "⚠️ Rapportgenerering kör redan – vänta." 'Warn'; return }
    $script:BuildInProgress = $true

 # --- Tidsmätning (metrics) ---
 $buildTimer = [System.Diagnostics.Stopwatch]::StartNew()
 $phaseTimings = [ordered]@{}
 $lastPhaseMs = 0

    Gui-Log -Text '🔃 Skapar rapport…' -Severity Info -Category USER -Immediate
    Set-UiBusy -Busy $true -Message 'Skapar rapport…'
    Set-UiStep 5 'Initierar…'

    # --- Levande elapsed-timer i statusfältet (uppdateras varje sekund) ---
    $script:buildElapsedTimer = New-Object System.Windows.Forms.Timer
    $script:buildElapsedTimer.Interval = 1000
    $script:buildElapsedTimer.add_Tick({
        try {
            $elapsed = $buildTimer.Elapsed
            $slWork.Text = ('Bygger… {0:mm\:ss}' -f $elapsed)
            $status.Refresh()
        } catch {}
    })
    $script:buildElapsedTimer.Start()

    $pkgNeg = $null
    $pkgPos = $null
    $pkgOut = $null
    $stageDir = $null

    # Original paths (används för transparens + ev. signering)
    $selNegOrig = $null
    $selPosOrig = $null
    $selCsvOrig = $null
    $selCsvResOrig = $null
    $selLspOrig = $null

    # Regelmotor-cache (per körning)
    $script:RuleEngineShadow     = $null
    $script:RuleEngineShadowRes  = $null
    $script:RuleEngineCsvObjs    = $null
    $script:RuleEngineCsvObjsRes = $null
    $script:RuleBankCache        = $null

    # Guard rails för audit/finally (även vid tidiga return)
    $selCsv = $null
    $selCsvRes = $null
    $hasResampleCsv = $false
    $runAssay = $null
    $batch = $null
    $csvStats = $null
    $csvStatsRes = $null
    $sigMismatch = $false
    $mismatchSheets = @()
    $violationsNeg = @()
    $violationsPos = @()
    $granskName = ''
    $granskDate = ''
    $lsp = ''
    $SavePath = $null
    $totalMs = 0
    $phaseJson = ''
    $auditStatusText = 'Aborted'
    $auditWritten = $false

    try {
        if (-not (Load-EPPlus)) { Gui-Log "❌ EPPlus kunde inte laddas – avbryter." 'Error'; return }

        Set-UiStep 10 '🔃 Läser in Seal Test-filer…'
        Mark-Phase 'Init'

        $allCsvPaths = @(Get-AllCheckedFilePaths $clbCsv)
        $csvSel = Resolve-CsvPrimaryAndResample -CsvPaths $allCsvPaths
        if (-not $csvSel.Ok) {
            Gui-Log $csvSel.ErrorMessage 'Error'
            return
        }
        if ($csvSel.WarningMessage) {
            Gui-Log $csvSel.WarningMessage 'Warn'
        }
        $selCsv = $csvSel.PrimaryCsv
        $selCsvRes = $csvSel.ResampleCsv
        $hasResampleCsv = [bool]$csvSel.HasResample

        $selNeg = Get-CheckedFilePath $clbNeg
        $selPos = Get-CheckedFilePath $clbPos

        if (-not $selNeg -or -not $selPos) { Gui-Log "❌ Du måste välja en Seal NEG och en Seal POS." 'Error'; return }

        $lspRaw    = ($txtLSP.Text + '').Trim()
        $lspDigits = ($lspRaw -replace '\D','')
        $hasLsp    = -not [string]::IsNullOrWhiteSpace($lspDigits)

        if ($hasLsp) {
            $lsp = $lspDigits
        } else {
            $lsp = 'Manuell'
            Gui-Log "ℹ️ Filval via Bläddra." 'Warn'
        }

        $lspForLinks = if ($hasLsp) { $lsp } else { '' }

        # ---- TEMP snapshot av valda filer (för att inte stanna om någon har filen öppen) ----
        $enableStaging = Get-ConfigFlag -Name 'EnableLocalStaging' -Default $true -ConfigOverride $Config
        if ($enableStaging) {
            try {

                # Standard: C:\IPTCompile_TEMP\... (kan styras via Config: TempSnapshotRoot)
                $root = Get-ConfigValue -Name 'TempSnapshotRoot' -Default 'C:\IPTCompile_TEMP' -ConfigOverride $Config
                if (-not $root) { $root = 'C:\IPTCompile_TEMP' }
                if (-not (Test-Path -LiteralPath $root)) { New-Item -ItemType Directory -Path $root -Force | Out-Null }
                $stageDir = Join-Path $root ("IPTCompile_" + $lsp + "_" + (Get-Date -Format 'yyyyMMdd_HHmmss') + "_" + ([guid]::NewGuid().ToString('N')))
                New-Item -ItemType Directory -Path $stageDir -Force | Out-Null
                # Spara original paths
                $selNegOrig = $selNeg
                $selPosOrig = $selPos
                if ($selCsv) { $selCsvOrig = $selCsv }
                if ($selCsvRes) { $selCsvResOrig = $selCsvRes }

                # Snapshot paths används för all läsning/rapportbygge
                $selNeg = Stage-InputFileSnapshot -Path $selNeg -StageDir $stageDir -Prefix 'SealNEG'
                $selPos = Stage-InputFileSnapshot -Path $selPos -StageDir $stageDir -Prefix 'SealPOS'
                if ($selCsv) { $selCsv = Stage-InputFileSnapshot -Path $selCsv -StageDir $stageDir -Prefix 'CSV_Primary' }
                if ($selCsvRes) { $selCsvRes = Stage-InputFileSnapshot -Path $selCsvRes -StageDir $stageDir -Prefix 'CSV_Resample' }

            } catch {
                Gui-Log ("⚠️ Kunde inte skapa arbetskopia: " + $_.Exception.Message) 'Warn'
            }
        }

        # Logg: visa originalfilnamn (utan TEMP-prefix)
        $negLeaf = Get-CleanLeaf $selNeg
        $posLeaf = Get-CleanLeaf $selPos
        Gui-Log "📄 Neg: $negLeaf" 'Info'
        Gui-Log "📄 Pos: $posLeaf" 'Info'
        if ($selCsv) {
            $csvLeaf = Get-CleanLeaf $selCsv
            Gui-Log "📄 CSV: $csvLeaf" 'Info'
        } else { Gui-Log "ℹ️ Ingen CSV vald." 'Info' }
        if ($selCsvRes) {
            $csvResLeaf = Get-CleanLeaf $selCsvRes
            Gui-Log "📄 CSV (Resample): $csvResLeaf" 'Info'
        }

        # =====================================================
        # === CSV-RADCACHE (läs varje fil max en gång)      ===
        # =====================================================
        Mark-Phase 'SealTestLoad'
        $script:CsvLinesPrimary  = $null
        $script:CsvLinesResample = $null
        if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
            try { $script:CsvLinesPrimary = Get-Content -LiteralPath $selCsv } catch { Gui-Log ("⚠️ Kunde inte läsa CSV: " + $_.Exception.Message) 'Warn' }
        }
        if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
            try { $script:CsvLinesResample = Get-Content -LiteralPath $selCsvRes } catch { Gui-Log ("⚠️ Kunde inte läsa Resample CSV: " + $_.Exception.Message) 'Warn' }
        }

        $negWritable = $true; $posWritable = $true
        if ($chkSealTest.Checked) {
            # GDP A5: Fil-lås med Retry-dialog för originalfiler (signering)
            $negLockPath = if ($selNegOrig) { $selNegOrig } else { $selNeg }
            $posLockPath = if ($selPosOrig) { $selPosOrig } else { $selPos }
            $signPaths = @($negLockPath, $posLockPath) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
if ($signPaths.Count -gt 0) {
    if (-not (Ensure-SignatureFilesClosedOrCancel -Paths $signPaths -Hint 'Stäng Seal Test POS/NEG i Excel och klicka Försök igen. Signering kan inte genomföras mot en öppen eller låst fil.')) {
        Gui-Log "🛑 Seal Test-signatur avbruten: fil(er) öppna/låsta." 'Error'
        return
    }
}
        }
        # UX: Om någon vald fil är öppen/låst – be användaren stänga den och Försök igen.
        $pathsToCheck = @($selNeg, $selPos)
        if (-not (Ensure-FilesClosedOrCancel -Paths $pathsToCheck)) {
            Gui-Log "🛑 Avbrutet: en eller flera filer var öppna/låsta." 'Warn'
            return
        }

        # ----------------------------
        # Öppna paket
        # ----------------------------
        try {
            $pkgNeg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selNeg))
            $pkgPos = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selPos))
        } catch {
            Gui-Log "❌ Kunde inte öppna NEG/POS: $($_.Exception.Message)" 'Error'
            return
        }

        $templatePath = Join-Path $ScriptRootPath "output_template-v4.xlsx"
        if (-not (Test-Path -LiteralPath $templatePath)) { Gui-Log "❌ Mallfilen 'output_template-v4.xlsx' saknas!" 'Error'; return }
        # UX: Mallfilen kan vara låst om någon har den öppen (t.ex. förhandsvisning/Excel).
        if (-not (Ensure-FilesClosedOrCancel -Paths @($templatePath))) {
            Gui-Log "🛑 Avbrutet: mallfilen är öppen/låst." 'Warn'
            return
        }
try {
    $pkgOut = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($templatePath))
} catch {
    Gui-Log "❌ Kunde inte läsa mall: $($_.Exception.Message)" 'Error'
    return
}

$script:RunInfoTemplateColumnWidths = @{}
try {
    $wsTemplateRunInfo = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if ($wsTemplateRunInfo) {
        $script:RunInfoTemplateColumnWidths = Get-RunInformationColumnWidths -Ws $wsTemplateRunInfo
    }
} catch {}

        # ============================
        # === SIGNATUR I NEG/POS  ====
        # ============================

        $doSealTest = $chkSealTest.Checked
        $doWsSamm   = $chkWsSamm.Checked
        $doWsGransk = $chkWsGransk.Checked
        $doOverwrite      = $chkSignOverwrite.Checked
        $doOverwriteGransk = $chkGranskOverwrite.Checked
        if (($doSealTest -or $doWsSamm) -and (-not $doOverwrite)) {
            Gui-Log "❌ Overwrite måste kryssas i för att skapa rapport med signering (Sammanställning)." 'Error'
            return
        }
        if ($doWsGransk -and (-not $doOverwriteGransk)) {
            Gui-Log "❌ Overwrite måste kryssas i för att skapa rapport med signering (Granskning)." 'Error'
            return
        }

        # --- Sammanställnings-fält (delat av Seal Test + Worksheet Sammanställning) ---
        $sammName = ($txtSammName.Text + '').Trim()
        $sammDate = ($txtSammDate.Text + '').Trim()
        $sammSign = ($txtSealTestSign.Text + '').Trim()

        if ($doSealTest) {
            if (-not $sammName) { Gui-Log "❌ Sammanställning: Full Name saknas." 'Error'; return }
            if (-not $sammSign) { Gui-Log "❌ Sammanställning: SIGN saknas." 'Error'; return }
            if (-not $sammDate) { Gui-Log "❌ Sammanställning: Date saknas." 'Error'; return }
        }
        if ($doWsSamm) {
            if (-not $sammName) { Gui-Log "❌ Sammanställning: Full Name saknas." 'Error'; return }
            if (-not $sammDate) { Gui-Log "❌ Sammanställning: Date saknas." 'Error'; return }
        }
        if ($doWsGransk) {
            $granskName = ($txtGranskName.Text + '').Trim()
            $granskDate = ($txtGranskDate.Text + '').Trim()
            if (-not $granskName) { Gui-Log "❌ Granskning: Full Name saknas." 'Error'; return }
            if (-not $granskDate) { Gui-Log "❌ Granskning: Date saknas." 'Error'; return }
        }
# ============================================================
# === Global spärr före signering                          ===
# ============================================================
# Om användaren har valt flera signeringar ska ALLA filer vara stängda
# innan någon originalfil skrivs. Annars kan Seal Test hinna signeras
# innan Worksheet stoppas.
try {
    $allSignaturePaths = New-Object System.Collections.Generic.List[string]
    if ($doSealTest) {
        $negPreSignPath = if ($selNegOrig) { $selNegOrig } else { $selNeg }
        $posPreSignPath = if ($selPosOrig) { $selPosOrig } else { $selPos }
        if ($negPreSignPath -and (Test-Path -LiteralPath $negPreSignPath)) {
            [void]$allSignaturePaths.Add($negPreSignPath)
        }
        if ($posPreSignPath -and (Test-Path -LiteralPath $posPreSignPath)) {
            [void]$allSignaturePaths.Add($posPreSignPath)
        }
    }
    if ($doWsSamm -or $doWsGransk) {
        $wsPreSignPath = $null
        try { $wsPreSignPath = Get-CheckedFilePath $clbLsp } catch {}
        if ($wsPreSignPath -and (Test-Path -LiteralPath $wsPreSignPath)) {
            [void]$allSignaturePaths.Add($wsPreSignPath)
        } else {
            Gui-Log "⚠️ Worksheet-signering vald men ingen Worksheet-fil hittades." 'Warn'
        }
    }
    $allSignaturePathsClean = @($allSignaturePaths.ToArray() | Where-Object { $_ } | Select-Object -Unique)
    if ($allSignaturePathsClean.Count -gt 0) {
        if (-not (Ensure-SignatureFilesClosedOrCancel -Paths $allSignaturePathsClean -Hint 'Stäng alla filer som ska signeras: Seal Test POS, Seal Test NEG och Worksheet. Signering kan inte starta om någon av filerna är öppen eller låst.')) {
            Gui-Log "🛑 Signering avbruten: en eller flera signeringsfiler är öppna/låsta. Inga nya signaturer skrevs i denna körning." 'Error'
            return
        }
    }
} catch {
    Gui-Log "🛑 Signering avbruten: kunde inte verifiera att signeringsfilerna är stängda. $($_.Exception.Message)" 'Error'
    return
}

# Seal Test B47 = "Full name, SIGN, Date"
$signToWrite = ''
# Sätts per fil när denna körning faktiskt har skrivit signatur
# och read-back verifieringen har passerat.
# Då ska gammal inläst tom B47 inte flaggas som "Signatur saknas".
$negSealSignatureAppliedThisRun = $false
$posSealSignatureAppliedThisRun = $false
# Slutlogg ska baseras på faktisk verifierad signering, inte bara checkbox-val.
$wsSammSignatureVerifiedThisRun   = $false
$wsGranskSignatureVerifiedThisRun = $false
if ($doSealTest) {
            $signToWrite = "$sammName, $sammSign, $sammDate"
            if (-not (Confirm-SignatureInput -Text $signToWrite)) { Gui-Log "🛑 Seal Test-signatur ej bekräftad. Avbryter."; return }

            # Signera ORIGINAL om möjligt (snapshot används endast för läsning)
            $negPathForSign = if ($selNegOrig) { $selNegOrig } else { $selNeg }
            $posPathForSign = if ($selPosOrig) { $selPosOrig } else { $selPos }
            $pkgNegSign = $null
            $pkgPosSign = $null
            try {
                if ($negWritable) { $pkgNegSign = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($negPathForSign)) }
                if ($posWritable) { $pkgPosSign = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($posPathForSign)) }
            } catch {
                Gui-Log ("⚠️ Kunde inte öppna filen för signering: " + $_.Exception.Message) 'Warn'
            }
            }
            $negWritten = 0; $posWritten = 0; $negSkipped = 0; $posSkipped = 0

            # Hjälpfunktion: skriver signatur i alla aktiva datablad

            $resNeg = _SignSealTestSheets $pkgNegSign $signToWrite $Layout.SignatureCell $doOverwrite
            $resPos = _SignSealTestSheets $pkgPosSign $signToWrite $Layout.SignatureCell $doOverwrite
            $negWritten = $resNeg.Written; $negSkipped = $resNeg.Skipped
            $posWritten = $resPos.Written; $posSkipped = $resPos.Skipped

            # GDP A1: Ingen silent fail — Save-fel stoppar hela flödet
            if ($negWritten -eq 0 -and $negSkipped -eq 0 -and $posWritten -eq 0 -and $posSkipped -eq 0) {
            } else {
                try {
                    if ($negWritten -gt 0 -and $pkgNegSign) { $pkgNegSign.Save() }
                    if ($posWritten -gt 0 -and $pkgPosSign) { $pkgPosSign.Save() }
                } catch {
                    Gui-Log "❌ SIGNERINGSFEL: Kunde inte spara Seal Test: $($_.Exception.Message)" 'Error'
                    try { Save-ForensicSnapshot -SourcePath $(if($negPathForSign){$negPathForSign}else{$posPathForSign}) -Reason "Save() misslyckades: $($_.Exception.Message)" -AuditDir (Join-Path $ScriptRootPath 'audit') -Details @{ SignText=$signToWrite; NEG_Written=$negWritten; POS_Written=$posWritten } } catch {}
                    try { if ($pkgNegSign) { $pkgNegSign.Dispose() } } catch {}
                    try { if ($pkgPosSign) { $pkgPosSign.Dispose() } } catch {}
                    return
                }
                Gui-Log "🖊️ Signatur satt: NEG $negWritten blad (överhoppade $negSkipped), POS $posWritten blad (överhoppade $posSkipped)."
            }
            try { if ($pkgNegSign) { $pkgNegSign.Dispose() } } catch {}
            try { if ($pkgPosSign) { $pkgPosSign.Dispose() } } catch {}

            # GDP A2: Write → Save → Read-back verifiering
            $sealVerifyFailed = $false
            foreach ($vEntry in @(
                @{ Label='NEG'; Path=$negPathForSign; Written=$negWritten },
                @{ Label='POS'; Path=$posPathForSign; Written=$posWritten }
            )) {
                if ($vEntry.Written -gt 0 -and $vEntry.Path -and (Test-Path -LiteralPath $vEntry.Path)) {
                    $vr = Verify-SealTestSignatures -Path $vEntry.Path -ExpectedText $signToWrite -SignatureCell $Layout.SignatureCell -ActiveCheckCell $Layout.SealActiveCheckCell -ExpectedWritten $vEntry.Written
if ($vr.OK) {
    if ($vEntry.Label -eq 'NEG') { $negSealSignatureAppliedThisRun = $true }
    if ($vEntry.Label -eq 'POS') { $posSealSignatureAppliedThisRun = $true }
    Gui-Log "✅ Seal Test $($vEntry.Label) verifierad: $($vr.SheetsVerified)/$($vr.SheetsChecked) blad OK." 'Info'
} else {
                        $sealVerifyFailed = $true
                        $reason = if ($vr.Error) { $vr.Error } else { ($vr.Mismatches -join '; ') }
                        Gui-Log "❌ VERIFIERINGSFEL Seal Test $($vEntry.Label): $reason" 'Error'
                        # GDP A4: Forensisk snapshot
                        try { Save-ForensicSnapshot -SourcePath $vEntry.Path -Reason "Read-back mismatch: $reason" -AuditDir (Join-Path $ScriptRootPath 'audit') -Details @{ SignText=$signToWrite; Expected=$vEntry.Written; Verified=$vr.SheetsVerified; Mismatches=($vr.Mismatches -join '|') } } catch {}
                    }
                }
            }
if ($sealVerifyFailed) {
    Gui-Log "🛑 Seal Test-signatur ej verifierad. Rapport stoppas." 'Error'
    return

}

        # ==========================================
        # === SIGNATUR I WORKSHEET              ====
        # ==========================================

        if ($doWsSamm -or $doWsGransk) {
            $wsSignPath = $null
            try { $wsSignPath = Get-CheckedFilePath $clbLsp } catch {}
if (-not $wsSignPath -or -not (Test-Path -LiteralPath $wsSignPath)) {
    Gui-Log "⚠️ Ingen Worksheet vald – hoppar över Worksheet-signatur." 'Warn'
} else {
    # Hård spärr före signeringsplan.
    # Worksheet får inte vara öppen/låst när signering ska planeras eller skrivas.
    if (-not (Ensure-SignatureFilesClosedOrCancel -Paths @($wsSignPath) -Hint 'Stäng Worksheet-filen i Excel och klicka Försök igen. Signering kan inte genomföras mot en öppen eller låst fil.')) {
        Gui-Log "🛑 Worksheet-signatur avbruten: filen är öppen/låst." 'Error'
        return
    }
    # Bekräftelse
    $hasResample = [bool]$hasResampleCsv
                $wsTargets = New-Object System.Collections.Generic.List[string]
                if ($doWsSamm) {
                    try {
                        $planS = Get-WorksheetSignaturePlan_OpenXml -Path $wsSignPath -Mode 'Sammanstallning' -HasResample $hasResample -ModulesRoot $modulesRoot
                        if ($planS -and $planS.Planned) {
                            foreach ($p in $planS.Planned) { [void]$wsTargets.Add("Sammanställning: $p") }
                        }
                    } catch {
                        Gui-Log ("⚠️ Kunde inte läsa signeringsplan (Sammanställning): " + $_.Exception.Message) 'Warn'
                    }
                }
                if ($doWsGransk) {
                    try {
                        $planG = Get-WorksheetSignaturePlan_OpenXml -Path $wsSignPath -Mode 'Granskning' -HasResample $hasResample -ModulesRoot $modulesRoot
                        if ($planG -and $planG.Planned) {
                            foreach ($p in $planG.Planned) { [void]$wsTargets.Add("Granskning: $p") }
                        }
                    } catch {
                        Gui-Log ("⚠️ Kunde inte läsa signeringsplan (Granskning): " + $_.Exception.Message) 'Warn'
                    }
                }
                $wsConfirmed = Confirm-WorksheetSignInput -FullName $(if ($doWsSamm) { $sammName } else { $granskName }) -SignDate $(if ($doWsSamm) { $sammDate } else { $granskDate }) -Targets @($wsTargets.ToArray())
                if (-not $wsConfirmed) {
                    Gui-Log "🛑 Worksheet-signatur ej bekräftad." 'Info'
} elseif (-not (Ensure-SignatureFilesClosedOrCancel -Paths @($wsSignPath) -Hint 'Stäng Worksheet-filen i Excel och klicka Försök igen. Signering kan inte genomföras mot en öppen eller låst fil.')) {
    # Extra spärr precis före OpenXML-skrivning.
    Gui-Log "🛑 Worksheet-signatur avbruten: filen är öppen/låst." 'Error'
    return
} else {
$wsAllWrittenCells = New-Object System.Collections.Generic.List[pscustomobject]
$wsWrittenModes = New-Object System.Collections.Generic.HashSet[string]
try {
    $hasResample = [bool]$hasResampleCsv

                        # Konsoliderad loop: kör varje signerings-mode
                        $wsModes = @()
                        if ($doWsSamm)   { $wsModes += @{ Mode='Sammanstallning'; Label='Sammanställning'; Name=$sammName; Date=$sammDate; Overwrite=$doOverwrite } }
                        if ($doWsGransk) { $wsModes += @{ Mode='Granskning';      Label='Granskning';      Name=$granskName; Date=$granskDate; Overwrite=$doOverwriteGransk } }

                        foreach ($m in $wsModes) {
                            $wsRes = Invoke-WorksheetSignature_OpenXml -Path $wsSignPath -FullName $m.Name -SignDateYmd $m.Date -Mode $m.Mode -HasResample:$hasResample -Overwrite ([bool]$m.Overwrite) -ModulesRoot $modulesRoot
                            if ($wsRes.Written.Count -gt 0) {
                                Gui-Log ("🖊️ WS $($m.Label): " + ($wsRes.Written -join ', ')) 'Info'
                            }
                            if ($wsRes.Skipped.Count -gt 0) {
                                Gui-Log ("WS $($m.Label) – överhoppade: " + ($wsRes.Skipped -join ', ')) -Severity 'Info' -Category 'DEBUG'
                            }
# Samla skrivna celler för verifiering
if ($wsRes.WrittenCells -and $wsRes.WrittenCells.Count -gt 0) {
    [void]$wsWrittenModes.Add(($m.Mode + ''))
    foreach ($wc in $wsRes.WrittenCells) { [void]$wsAllWrittenCells.Add($wc) }
}
                        }
                        # GDP A2: Write → Save → Read-back verifiering
                        if ($wsAllWrittenCells.Count -gt 0) {
                            $wsVerify = Verify-WorksheetSignatures -Path $wsSignPath -WrittenCells @($wsAllWrittenCells.ToArray())
                            if ($wsVerify.OK) {
    if ($wsWrittenModes.Contains('Sammanstallning')) {
        $wsSammSignatureVerifiedThisRun = $true
    }
    if ($wsWrittenModes.Contains('Granskning')) {
        $wsGranskSignatureVerifiedThisRun = $true
    }
    Gui-Log "✅ Worksheet-signatur verifierad: $($wsVerify.CellsVerified)/$($wsVerify.CellsChecked) celler OK. $(Split-Path $wsSignPath -Leaf)" 'Info'
} else {
                                $reason = if ($wsVerify.Error) { $wsVerify.Error } else { ($wsVerify.Mismatches -join '; ') }
                                Gui-Log "❌ VERIFIERINGSFEL Worksheet: $reason" 'Error'
                                # GDP A4: Forensisk snapshot
                                try { Save-ForensicSnapshot -SourcePath $wsSignPath -Reason "WS read-back mismatch: $reason" -AuditDir (Join-Path $ScriptRootPath 'audit') -Details @{ Checked=$wsVerify.CellsChecked; Verified=$wsVerify.CellsVerified; Mismatches=($wsVerify.Mismatches -join '|') } } catch {}
                                Gui-Log "🛑 Worksheet-signatur ej verifierad. Rapport stoppas." 'Error'
                                return
                            }
                        } else {
                            Gui-Log "✅ Worksheet-signatur sparad (inga nya celler skrivna — redan ifyllda): $(Split-Path $wsSignPath -Leaf)" 'Info'
                        }
                    } catch {
                        # GDP A1: Ingen silent fail — Exception stoppar flödet
                        Gui-Log ("❌ SIGNERINGSFEL Worksheet: " + $_.Exception.Message) 'Error'
                        try { Save-ForensicSnapshot -SourcePath $wsSignPath -Reason "Exception: $($_.Exception.Message)" -AuditDir (Join-Path $ScriptRootPath 'audit') } catch {}
                        return
                    }
                }
            }
        }

        Mark-Phase 'Signering'

        #region Build: CSV-inläsning och RuleEngine
        # ============================
        # === CSV (Info/Control)  ====
        # ============================

        $csvRows = @()
        $runAssay = $null

        if ($selCsv) {
            try {
                $csvInfo = Get-Item -LiteralPath $selCsv -ErrorAction Stop
                $thresholdMb = 25
                try {
                    if ($Config -and ($Config -is [System.Collections.IDictionary]) -and $Config.Contains('CsvStreamingThresholdMB')) {
                        $thresholdMb = [int]$Config['CsvStreamingThresholdMB']
                    }
                } catch {
                    Gui-Log "⚠️ Kunde inte läsa CsvStreamingThresholdMB från konfigurationen." 'Warn'
                }

                $useStreaming = ($csvInfo.Length -ge ($thresholdMb * 1MB))
                if ($useStreaming) {
                    Gui-Log ("⏳ CSV är stor ({0:N1} MB) – använder streaming-import…" -f ($csvInfo.Length / 1MB)) 'Info'
                    Set-UiStep 35 "Läser CSV (streaming)…"
                    $list = New-Object System.Collections.Generic.List[object]
                    Import-CsvRowsStreaming -Path $selCsv -StartRow 10 -ProcessRow {
                        param($Fields,$RowIndex)
                        [void]$list.Add($Fields)
                        if (($RowIndex % 2000) -eq 0) { Invoke-UiPump }
                    }
                    $csvRows = @($list.ToArray())
                } else {
                    Set-UiStep 35 "Läser CSV…"
                    $csvRows = Import-CsvRows -Path $selCsv -StartRow 10
                }

                # --- Robusthet: Sortera på kolumn C (Sample ID) innan vidare bearbetning.
                # Många efterföljande steg (gruppering/skrivning) förutsätter att raderna är konsekvent sorterade.
                try {
                    if ($csvRows -and $csvRows.Count -gt 1) {
                        if ($csvRows[0] -is [object[]]) {
                            # Import-CsvRows* returnerar fält-arrayer: kolumn C = index 2
                            $csvRows = @($csvRows | Sort-Object { [string]($_[2]) })
                        } else {
                            # Om vi i framtiden får PSCustomObject-rader
                            $csvRows = @($csvRows | Sort-Object { [string]($_.'Sample ID') })
                        }
                        Gui-Log ("🔃 CSV sorterad på kolumn C (Sample ID). Rader: {0}" -f $csvRows.Count) 'Info' 'PROGRESS'
                    }
                } catch {
                    Gui-Log "⚠️ Kunde inte sortera CSV på kolumn C (Sample ID)." 'Warn'
                }
            } catch {
                Gui-Log "⚠️ CSV-import misslyckades: $($_.Exception.Message)" 'Warn'
                $csvRows = @()
            }
            try { $runAssay = Get-AssayFromCsv -Path $selCsv -StartRow 10 } catch {}
            if ($runAssay) { Gui-Log "🔎 Assay från CSV: $runAssay" }
        }

        # --- Import av Resample-CSV ---
        $csvRowsRes = @()
        $runAssayRes = $null
        if ($selCsvRes) {
            try {
                Set-UiStep 37 "Läser Resample-CSV…"
                $csvRowsRes = Import-CsvRows -Path $selCsvRes -StartRow 10
                try {
                    if ($csvRowsRes -and $csvRowsRes.Count -gt 1) {
                        if ($csvRowsRes[0] -is [object[]]) {
                            $csvRowsRes = @($csvRowsRes | Sort-Object { [string]($_[2]) })
                        } else {
                            $csvRowsRes = @($csvRowsRes | Sort-Object { [string]($_.'Sample ID') })
                        }
                        Gui-Log ("🔃 Resample-CSV sorterad. Rader: {0}" -f $csvRowsRes.Count) 'Info' 'PROGRESS'
                    }
                } catch {
                    Gui-Log "⚠️ Kunde inte sortera Resample-CSV på kolumn C (Sample ID)." 'Warn'
                }
            } catch {
                Gui-Log "⚠️ Resample-CSV-import misslyckades: $($_.Exception.Message)" 'Warn'
                $csvRowsRes = @()
            }
            try { $runAssayRes = Get-AssayFromCsv -Path $selCsvRes -StartRow 10 } catch {}
            if (-not $runAssayRes -and $runAssay) { $runAssayRes = $runAssay }  # Fallback till primary assay
        }

        # =====================================================
        # === SKANNING AV DATA SUMMARY-BLAD (fynd)
        # === Primär → 'Data Summary' + 'Extra Data Summary', Resample → 'Resample Data Summary'
        # =====================================================
        Mark-Phase 'CsvRead'
        $dataSummaryFindings     = @()
        $dataSummaryFindingsExtra = @()
        $dataSummaryFindingsRes  = @()
        $script:WsPkg            = $null  # Återanvänds av Equipment/Header/QC-sektionerna

        $effectiveAssay = if ($runAssay) { $runAssay } elseif ($runAssayRes) { $runAssayRes } else { $null }
        if ($effectiveAssay) {
            try {
                $selLspDs = $null
                try { $selLspDs = Get-CheckedFilePath $clbLsp } catch { $selLspDs = $null }

                if ($selLspDs -and (Test-Path -LiteralPath $selLspDs)) {
                    $script:WsPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selLspDs))

                    # --- Primär CSV → 'Data Summary' ---
                    if ($selCsv) {
                        $dataSummaryFindings = @(Get-DataSummaryFindings -ExcelPackages @($script:WsPkg) -AssayName $effectiveAssay -SheetName $Layout.SheetDataSummary)
                        $dataSummaryFindingsExtra = @(Get-DataSummaryFindings -ExcelPackages @($script:WsPkg) -AssayName $effectiveAssay -SheetName $Layout.SheetExtraSummary)
                    }

                    # --- Resample-CSV → 'Resample Data Summary' ---
                    if ($selCsvRes) {
                        $resSheetName = 'Resample Data Summary'
                        $dataSummaryFindingsRes = @(Get-DataSummaryFindings -ExcelPackages @($script:WsPkg) -AssayName $effectiveAssay -SheetName $resSheetName)
                        if ($dataSummaryFindingsRes.Count -gt 0) {
                        }
                    }
                }
            } catch {
                Gui-Log ("⚠️ Data Summary scan fel: " + $_.Exception.Message) 'Warn'
                $dataSummaryFindings     = @()
                $dataSummaryFindingsExtra = @()
                $dataSummaryFindingsRes  = @()
                if ($script:WsPkg) { try { $script:WsPkg.Dispose() } catch {} }
                $script:WsPkg = $null
            }
        }
        # Kombinerat DataSummaryFindings (primär + resample) för CSV Sammanfattning
        $allDataSummaryFindings = @($dataSummaryFindings) + @($dataSummaryFindingsExtra) + @($dataSummaryFindingsRes)
        $script:DataSummaryFindings = $allDataSummaryFindings

        # ============================
        # === RuleEngine (skuggresultat) ===
        # ============================
        Mark-Phase 'DataSummary'
        $script:RuleEngineShadowRes = $null   # Resample-resultat (separat)
        try {
            if ((Get-ConfigFlag -Name 'EnableRuleEngine' -Default $false -ConfigOverride $Config) -and
                ($selCsv -or $selCsvRes)) {

                # Ladda rulebank en gång
                $rb = Load-RuleBank -RuleBankDir $Config.RuleBankDir
                try {
                    $rb = Compile-RuleBank -RuleBank $rb
                } catch {
                    Gui-Log ("⚠️ Regelmotor: kunde inte kompilera RuleBank: " + $_.Exception.Message) 'Warn' 'DEBUG'
                }
                $script:RuleBankCache = $rb

                # ======================================
                # PRIMÄR CSV → RuleEngine
                # ======================================
                if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
                    $csvObjs = @()
                    if ($csvRows -and $csvRows.Count -gt 0) {
                        $csvObjs = @($csvRows)
                        Gui-Log ("🧠 Regelmotor: CSV-källa: Import-CsvRows ({0})" -f $csvObjs.Count) 'Info' 'PROGRESS'
                    } else {
                        try {
                            $all = $script:CsvLinesPrimary
                            if ($all -and $all.Count -gt 9) {
                                $del = Get-CsvDelimiter -Path $selCsv
                                $hdr = ConvertTo-CsvFields $all[7]
                                $dl  = $all[9..($all.Count-1)] | Where-Object { $_ -and $_.Trim() }
                                $csvObjs = @(ConvertFrom-Csv -InputObject ($dl -join "`n") -Delimiter $del -Header $hdr)
                            }
                        } catch {
                            Gui-Log ("⚠️ Regelmotor: fallback-raw för CSV misslyckades: " + $_.Exception.Message) 'Warn' 'DEBUG'
                            $csvObjs = @()
                        }
                        Gui-Log ("🧠 Regelmotor: CSV-källa: Fallback-raw ({0})" -f ($csvObjs.Count)) 'Info' 'PROGRESS'
                    }
                    $script:RuleEngineCsvObjs = $csvObjs

                    if (-not $csvObjs -or $csvObjs.Count -eq 0) {
                        Gui-Log "⚠️ Regelmotor: CSV-objekt saknas (0 rader) – hoppar över." 'Warn'
                        $script:RuleEngineShadow = $null
                    } else {
                        $re = Invoke-RuleEngine -CsvObjects $csvObjs -RuleBank $rb -CsvPath $selCsv
                        $script:RuleEngineShadow = $re
                    }
                }

                # ======================================
                # RESAMPLE-CSV → RuleEngine
                # ======================================
                if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
                    $csvObjsRes = @()
                    if ($csvRowsRes -and $csvRowsRes.Count -gt 0) {
                        $csvObjsRes = @($csvRowsRes)
                        Gui-Log ("🧠 Regelmotor (Resample): Import-CsvRows ({0})" -f $csvObjsRes.Count) 'Info' 'PROGRESS'
                    } else {
                        try {
                            $allR = $script:CsvLinesResample
                            if ($allR -and $allR.Count -gt 9) {
                                $delR = Get-CsvDelimiter -Path $selCsvRes
                                $hdrR = ConvertTo-CsvFields $allR[7]
                                $dlR  = $allR[9..($allR.Count-1)] | Where-Object { $_ -and $_.Trim() }
                                $csvObjsRes = @(ConvertFrom-Csv -InputObject ($dlR -join "`n") -Delimiter $delR -Header $hdrR)
                            }
                        } catch {
                            Gui-Log ("⚠️ Regelmotor: fallback-raw för Resample-CSV misslyckades: " + $_.Exception.Message) 'Warn' 'DEBUG'
                            $csvObjsRes = @()
                        }
                    }
                    $script:RuleEngineCsvObjsRes = $csvObjsRes

                    if ($csvObjsRes -and $csvObjsRes.Count -gt 0) {
                        $reRes = Invoke-RuleEngine -CsvObjects $csvObjsRes -RuleBank $rb -CsvPath $selCsvRes
                        $script:RuleEngineShadowRes = $reRes
                    }
                }

                # ======================================
                # KOMBINERAD SUMMERING (primär + resample)
                # ======================================
                $rePrimary = $script:RuleEngineShadow
                $reResamp  = $script:RuleEngineShadowRes

                # Sammanfogning: bygg nytt kombinerat resultat (undvik PS 5.1-bugg med readonly NoteProperty)
                if ($rePrimary -and $reResamp) {
                    try {
                        # Rader
                        $mergedRows = @($rePrimary.Rows) + @($reResamp.Rows)

                        # DeviationCounts — kopiera primär, addera resample
                        $mergedDev = @{}
                        if ($rePrimary.Summary.DeviationCounts) {
                            foreach ($dk in $rePrimary.Summary.DeviationCounts.Keys) { $mergedDev[$dk] = [int]$rePrimary.Summary.DeviationCounts[$dk] }
                        }
                        if ($reResamp.Summary.DeviationCounts) {
                            foreach ($dk in $reResamp.Summary.DeviationCounts.Keys) {
                                if ($mergedDev.ContainsKey($dk)) { $mergedDev[$dk] = [int]$mergedDev[$dk] + [int]$reResamp.Summary.DeviationCounts[$dk] }
                                else { $mergedDev[$dk] = [int]$reResamp.Summary.DeviationCounts[$dk] }
                            }
                        }

                        # ObservedCounts
                        $mergedObs = @{}
                        if ($rePrimary.Summary.ObservedCounts) {
                            foreach ($ok2 in $rePrimary.Summary.ObservedCounts.Keys) { $mergedObs[$ok2] = [int]$rePrimary.Summary.ObservedCounts[$ok2] }
                        }
                        if ($reResamp.Summary.ObservedCounts) {
                            foreach ($ok2 in $reResamp.Summary.ObservedCounts.Keys) {
                                if ($mergedObs.ContainsKey($ok2)) { $mergedObs[$ok2] = [int]$mergedObs[$ok2] + [int]$reResamp.Summary.ObservedCounts[$ok2] }
                                else { $mergedObs[$ok2] = [int]$reResamp.Summary.ObservedCounts[$ok2] }
                            }
                        }

                        # Enkla räknare
                        $mergedInstErr  = ($rePrimary.Summary.InstrumentError + 0) + ($reResamp.Summary.InstrumentError + 0)
                        $mergedMinFunc  = ($rePrimary.Summary.MinorFunctionalError + 0) + ($reResamp.Summary.MinorFunctionalError + 0)
                        $mergedTotal    = ($rePrimary.Summary.Total + 0) + ($reResamp.Summary.Total + 0)
                        $mergedRetest   = ($rePrimary.Summary.RetestYes + 0) + ($reResamp.Summary.RetestYes + 0)

                        # TopDeviations
                        $mergedTop = @($rePrimary.TopDeviations) + @($reResamp.TopDeviations)

                        # QC (behåll primär)
                        $mergedQC = $rePrimary.QC

                        # Bygg nytt resultatobjekt
                        $mergedSummary = [pscustomobject]@{
                            Total                = $mergedTotal
                            ObservedCounts       = $mergedObs
                            DeviationCounts      = $mergedDev
                            RetestYes            = $mergedRetest
                            InstrumentError      = $mergedInstErr
                            MinorFunctionalError = $mergedMinFunc
                        }
                        $script:RuleEngineShadow = [pscustomobject]@{
                            Rows          = $mergedRows
                            Summary       = $mergedSummary
                            TopDeviations = $mergedTop
                            QC            = $mergedQC
                        }
                        Gui-Log ("✅ Merge CSV + Resampling CSV: {0} rader totalt" -f $mergedRows.Count) 'Info'
                    } catch {
                        Gui-Log "⚠️ Merge CSV + Resampling CSV resultat: $($_.Exception.Message)" 'Warn'
                    }
                } elseif (-not $rePrimary -and $reResamp) {
                    # Endast resample
                    $script:RuleEngineShadow = $reResamp
                }

                $re = $script:RuleEngineShadow
                if ($re -and $re.Summary) {
                    try {
                        $pos = 0; $neg = 0; $err = 0
                        if ($re.Summary.ObservedCounts) {
                            if ($re.Summary.ObservedCounts.ContainsKey('POS'))   { $pos = [int]$re.Summary.ObservedCounts['POS'] }
                            if ($re.Summary.ObservedCounts.ContainsKey('NEG'))   { $neg = [int]$re.Summary.ObservedCounts['NEG'] }
                            if ($re.Summary.ObservedCounts.ContainsKey('ERROR')) { $err = [int]$re.Summary.ObservedCounts['ERROR'] }
                        }

                        $ok = 0; $fp = 0; $fn = 0; $derr = 0; $ie = 0
                        if ($re.Summary.DeviationCounts) {
                            if ($re.Summary.DeviationCounts.ContainsKey('OK'))    { $ok   = [int]$re.Summary.DeviationCounts['OK'] }
                            if ($re.Summary.DeviationCounts.ContainsKey('FP'))    { $fp   = [int]$re.Summary.DeviationCounts['FP'] }
                            if ($re.Summary.DeviationCounts.ContainsKey('FN'))    { $fn   = [int]$re.Summary.DeviationCounts['FN'] }
                            if ($re.Summary.DeviationCounts.ContainsKey('ERROR')) { $derr = [int]$re.Summary.DeviationCounts['ERROR'] }
                        }
                        $ie = 0; if ($re.Summary.InstrumentError -ne $null) { $ie = [int]$re.Summary.InstrumentError }
                        $mf = 0; if ($re.Summary.MinorFunctionalError -ne $null) { $mf = [int]$re.Summary.MinorFunctionalError }

                        $resTag = if ($hasResampleCsv) { ' [+Resample]' } else { '' }
                        $sum = "🧠 Regelkontroll$resTag`: POS=$pos, NEG=$neg, Error=$err | OK=$ok, FP=$fp, FN=$fn, Minor Func=$mf | Instrument Error=$ie"
                        # Regelkontroll-detaljer döljs i GUI (kan stressa användare)
                        # Gui-Log -Text $sum -Severity Info -Category SUMMARY
                    } catch { }

                    if ((Get-ConfigFlag -Name 'EnableShadowCompare' -Default $false -ConfigOverride $Config) -and $re.TopDeviations) {
                        $n = 0
                        foreach ($d in $re.TopDeviations) {
                            $n++; if ($n -gt 20) { break }
                            $msg = "⚠️ RuleEngine dev: " + ($d.Deviation + '') + " | " + ($d.SampleId + '') + " | Exp=" + ($d.ExpectedCall + '') + " | Obs=" + ($d.ObservedCall + '')
                            if (($d.ErrorCode + '').Trim()) { $msg += " | Err=" + ($d.ErrorCode + '') }
                            Gui-Log -Text $msg -Severity Info -Category RuleEngineDev
                        }
                    }
                }
            }
        } catch {
            Gui-Log ("⚠️ RuleEngine (shadow) fel: " + $_.Exception.Message) 'Warn'
        }

        $controlTab = $null
        if ($runAssay) { $controlTab = Get-ControlTabName -AssayName $runAssay }
        if ($controlTab) { Gui-Log "🧪 Kontrollmaterial-flik: $controlTab" } else { Gui-Log "ℹ️ Ingen Kontrollmaterialsflik (fortsätter utan)." }

        # ============================
        # === Läs avvikelser       ===
        # ============================

        # P2: Extraherad hjälpfunktion (ersätter duplicerad NEG/POS-loop)
$resNeg = Get-SealViolations -Pkg $pkgNeg
        $resPos = Get-SealViolations -Pkg $pkgPos
        $violationsNeg = $resNeg.Violations; $failNegCount = $resNeg.FailCount
        $violationsPos = $resPos.Violations; $failPosCount = $resPos.FailCount
        # STF-count för CSV Sammanfattning: räkna endast riktiga FAIL (Minusvärde visas fortfarande i STF Sum-bladet)
        $script:StfCount = $failNegCount + $failPosCount

        # ============================
        # === Seal Test Info (blad) ==
        # ============================
        Mark-Phase 'RuleEngine'
        $wsOut1 = $pkgOut.Workbook.Worksheets[$Layout.SheetSealTestInfo]
        if (-not $wsOut1) { Gui-Log "❌ Fliken 'Seal Test Info' saknas i mallen"; return }

        for ($row = 3; $row -le 15; $row++) {
            $wsOut1.Cells["D$row"].Value = $null
            try { $wsOut1.Cells["D$row"].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::None } catch {}
        }

        $fields = @(
            @{ Label = "ROBAL";                         Cell = "F2"  }
            @{ Label = "Part Number";                   Cell = "B2"  }
            @{ Label = "Batch Number";                  Cell = "D2"  }
            @{ Label = "Cartridge Number (LSP)";        Cell = "B6"  }
            @{ Label = "PO Number";                     Cell = "B10" }
            @{ Label = "Assay Family";                  Cell = "D10" }
            @{ Label = "Weight Loss Spec";              Cell = "F10" }
            @{ Label = "Balance ID Number";             Cell = "B14" }
            @{ Label = "Balance Cal Due Date";          Cell = "D14" }
            @{ Label = "Vacuum Oven ID Number";         Cell = "B20" }
            @{ Label = "Vacuum Oven Cal Due Date";      Cell = "D20" }
            @{ Label = "Timer ID Number";               Cell = "B25" }
            @{ Label = "Timer Cal Due Date";            Cell = "D25" }
        )

        $forceText = @("ROBAL","Part Number","Batch Number","Cartridge Number (LSP)","PO Number","Assay Family","Balance ID Number","Vacuum Oven ID Number","Timer ID Number")
        $mismatchFields = $fields[0..6] | ForEach-Object { $_.Label }


            # --- Förväntad utrustningslista (valfritt, från equipment.xml) ---
        $equip = $null
        $equipPath = $null
        try {
            $equipPath = Get-ConfigValue -Name 'EquipmentXmlPath' -Default (Join-Path $ScriptRootPath 'equipment.xml') -ConfigOverride $Config
            if ($equipPath -and -not (Test-Path -LiteralPath $equipPath)) {
                Gui-Log ("⚠️ Equipment.xml hittades inte: " + $equipPath) 'Warn'
            }
            if ($equipPath -and (Test-Path -LiteralPath $equipPath)) {
                $equip = Import-Clixml -LiteralPath $equipPath
            }
        } catch {
            $equip = $null
        }

        $equipMap = @{
            'Balance ID Number'        = @{ NegKey='SCALESNEG';       PosKey='SCALESPOS';       Mode='LIST'  }
            'Balance Cal Due Date'     = @{ NegKey='CAL_D_SCALES_NEG'; PosKey='CAL_D_SCALES_POS'; Mode='MONTH' }
            'Vacuum Oven ID Number'    = @{ NegKey='OVENSNEG';        PosKey='OVENSPOS';        Mode='LIST'  }
            'Vacuum Oven Cal Due Date' = @{ NegKey='CAL_D_OVENSNEG';  PosKey='CAL_D_OVENSPOS';  Mode='MONTH' }
            'Timer ID Number'          = @{ NegKey='TIMERSNEG';       PosKey='TIMERSPOS';       Mode='LIST'  }
            'Timer Cal Due Date'       = @{ NegKey='CAL_D_TIMERSNEG'; PosKey='CAL_D_TIMERSPOS'; Mode='MONTH' }
        }

        $row = 3
        foreach ($f in $fields) {
$valNeg=''; $valPos=''
$srcNeg=''; $srcPos=''

# För utrustningsrader: samla per flik (inte avbrott på första!)
$perNeg = $null
$perPos = $null
$isEquip = ($equip -and $equipMap -and $equipMap.ContainsKey($f.Label))

if ($isEquip) {
    $perNegObj = _GetPerSheetValueObjects $pkgNeg $f.Cell
    $perPosObj = _GetPerSheetValueObjects $pkgPos $f.Cell
    $perNeg = @($perNegObj | ForEach-Object { $_.Value })
    $perPos = @($perPosObj | ForEach-Object { $_.Value })

    # Visa i B/C: union (för LIST) eller första icke-tom (för MONTH), bara för läsbarhet
    $map = $equipMap[$f.Label]
    if ($map.Mode -eq 'MONTH') {
        $valNeg = ($perNeg | Where-Object { $_ -and $_.Trim() } | Select-Object -First 1)
        $valPos = ($perPos | Where-Object { $_ -and $_.Trim() } | Select-Object -First 1)
    } else {
        $tokN = @()
        foreach ($x in $perNeg) { $tokN += (_EquipTokens $x) }
        $tokP = @()
        foreach ($x in $perPos) { $tokP += (_EquipTokens $x) }
        $valNeg = _EquipPretty $tokN $f.Label
        $valPos = _EquipPretty $tokP $f.Label
    }
}
else {
    # Befintligt beteende för "vanliga" fält: första AKTIVA flik med värde (skippa blad 1 + inaktiva)
    foreach ($wsN in $pkgNeg.Workbook.Worksheets) {
        if (-not (_IsActiveSealSheet $wsN)) { continue }
        $cell = $wsN.Cells[$f.Cell]
        if ($cell.Value -ne $null) {
            if ($cell.Value -is [datetime]) { $valNeg = $cell.Value.ToString('MMM-yy') } else { $valNeg = $cell.Text }
            $srcNeg = $wsN.Name
            break
        }
    }

    foreach ($wsP in $pkgPos.Workbook.Worksheets) {
        if (-not (_IsActiveSealSheet $wsP)) { continue }
        $cell = $wsP.Cells[$f.Cell]
        if ($cell.Value -ne $null) {
            if ($cell.Value -is [datetime]) { $valPos = $cell.Value.ToString('MMM-yy') } else { $valPos = $cell.Text }
            $srcPos = $wsP.Name
            break
        }
    }
}

            if ($forceText -contains $f.Label) {
                $wsOut1.Cells["B$row"].Style.Numberformat.Format = '@'
                $wsOut1.Cells["C$row"].Style.Numberformat.Format = '@'
            }

            $wsOut1.Cells["B$row"].Value = $valNeg
            $wsOut1.Cells["C$row"].Value = $valPos
            try { $wsOut1.Cells["B$row"].Style.Border.Right.Style = "Medium" } catch {}
            try { $wsOut1.Cells["C$row"].Style.Border.Left.Style  = "Medium" } catch {}

        if ($mismatchFields -contains $f.Label) {
                # D3:D9: visa tydlig Match/Mismatch med symboler
                if ($valNeg -and $valPos) {
                    if ($valNeg -ne $valPos) {
                        # Spårbarhet endast vid mismatch: flik + cell för var värdet hämtades
                        $tN = if ($srcNeg) { ("NEG:{0}@{1}" -f $srcNeg, $f.Cell) } else { ("NEG@{0}" -f $f.Cell) }
                        $tP = if ($srcPos) { ("POS:{0}@{1}" -f $srcPos, $f.Cell) } else { ("POS@{0}" -f $f.Cell) }
                        $wsOut1.Cells["D$row"].Value = ("⚠ Mismatch ({0} | {1})" -f $tN, $tP)
                        try { $wsOut1.Cells["D$row"].Style.Font.Size = 9 } catch {}
                        Style-Cell $wsOut1.Cells["D$row"] $true "FF0000" "Medium" "FFFFFF"
                        Gui-Log "⚠️ Avvikelse: $($f.Label) (NEG='$valNeg' vs POS='$valPos')"
                    } else {
                        $wsOut1.Cells["D$row"].Value = "✓ Match"
                        Style-Cell $wsOut1.Cells["D$row"] $true "C6EFCE" "Medium" "006100"
                    }
                } elseif ($valNeg -or $valPos) {
                    # Bara en av filerna har värde - markera som varning
                    $wsOut1.Cells["D$row"].Value = "⚠ Saknas"
                    Style-Cell $wsOut1.Cells["D$row"] $true "FFE699" "Medium" "806000"
                }
            }

            # --- Utrustningskontroll (POS/NEG har egna tillåtna värden i equipment.xml) ---
            if ($equip -and $equipMap -and $equipMap.ContainsKey($f.Label)) {
                $map = $equipMap[$f.Label]
                $expNeg = $null; $expPos = $null
                try { if ($equip.Contains($map.NegKey)) { $expNeg = (""+$equip[$map.NegKey]).Trim() } } catch {}
                try { if ($equip.Contains($map.PosKey)) { $expPos = (""+$equip[$map.PosKey]).Trim() } } catch {}

# Utvärdera PER FLIK och summera
$stNegAll = @()
$stPosAll = @()
                $negMismatchSheets = @()
                $posMismatchSheets = @()
                $negDelvisSheets = @()
                $posDelvisSheets = @()

if ($map.Mode -eq 'MONTH') {
    for ($i = 0; $i -lt $perNegObj.Count; $i++) {
        $st = (_EquipEvalMonth $perNegObj[$i].Value $expNeg); $stNegAll += $st
        if ($st -eq 'Mismatch') { $negMismatchSheets += ("{0}@{1}" -f $perNegObj[$i].Sheet, $perNegObj[$i].Addr) }
        if ($st -eq 'Delvis')   { $negDelvisSheets   += ("{0}@{1}" -f $perNegObj[$i].Sheet, $perNegObj[$i].Addr) }
    }
    for ($i = 0; $i -lt $perPosObj.Count; $i++) {
        $st = (_EquipEvalMonth $perPosObj[$i].Value $expPos); $stPosAll += $st
        if ($st -eq 'Mismatch') { $posMismatchSheets += ("{0}@{1}" -f $perPosObj[$i].Sheet, $perPosObj[$i].Addr) }
        if ($st -eq 'Delvis')   { $posDelvisSheets   += ("{0}@{1}" -f $perPosObj[$i].Sheet, $perPosObj[$i].Addr) }
    }
} else {

    for ($i = 0; $i -lt $perNegObj.Count; $i++) {
        $st = (_EquipEvalList $perNegObj[$i].Value $expNeg); $stNegAll += $st
        if ($st -eq 'Mismatch') { $negMismatchSheets += ("{0}@{1}" -f $perNegObj[$i].Sheet, $perNegObj[$i].Addr) }
        if ($st -eq 'Delvis')   { $negDelvisSheets   += ("{0}@{1}" -f $perNegObj[$i].Sheet, $perNegObj[$i].Addr) }
    }
    for ($i = 0; $i -lt $perPosObj.Count; $i++) {
        $st = (_EquipEvalList $perPosObj[$i].Value $expPos); $stPosAll += $st
        if ($st -eq 'Mismatch') { $posMismatchSheets += ("{0}@{1}" -f $perPosObj[$i].Sheet, $perPosObj[$i].Addr) }
        if ($st -eq 'Delvis')   { $posDelvisSheets   += ("{0}@{1}" -f $perPosObj[$i].Sheet, $perPosObj[$i].Addr) }
    }
}

$sNeg = _AggregateStatus $stNegAll
$sPos = _AggregateStatus $stPosAll

                # Hjälpfunktion: plocka ut enbart bladnamn (ta bort @cellref)

                $hasMismatch = ($sNeg -eq 'Mismatch' -or $sPos -eq 'Mismatch')
                $hasDelvis   = ($sNeg -eq 'Delvis'   -or $sPos -eq 'Delvis')

                if ($hasMismatch -or $hasDelvis) {
                    # NEG → kolumn D
                    $dVal = 'NEG ' + (_Txt $sNeg)
                    if ($sNeg -eq 'Mismatch' -and $negMismatchSheets.Count -gt 0) {
                        $dVal += ': ' + (_CleanSheets $negMismatchSheets)
                    } elseif ($sNeg -eq 'Delvis' -and $negDelvisSheets.Count -gt 0) {
                        $dVal += ': ' + (_CleanSheets $negDelvisSheets)
                    }
                    $wsOut1.Cells["D$row"].Value = $dVal
                    try { $wsOut1.Cells["D$row"].Style.Font.Size = 9 } catch {}

                    # POS → kolumn E
                    $eVal = 'POS ' + (_Txt $sPos)
                    if ($sPos -eq 'Mismatch' -and $posMismatchSheets.Count -gt 0) {
                        $eVal += ': ' + (_CleanSheets $posMismatchSheets)
                    } elseif ($sPos -eq 'Delvis' -and $posDelvisSheets.Count -gt 0) {
                        $eVal += ': ' + (_CleanSheets $posDelvisSheets)
                    }
                    $wsOut1.Cells["E$row"].Value = $eVal
                    try { $wsOut1.Cells["E$row"].Style.Font.Size = 9 } catch {}
                } else {
                    $wsOut1.Cells["D$row"].Value = ('NEG ' + (_Txt $sNeg) + ' / POS ' + (_Txt $sPos))
                }

                # Formatera D+E utifrån respektive status
                $rank = @{ 'NoRef'=0; 'Match'=1; 'Delvis'=2; 'Saknas'=2; 'Mismatch'=3 }

                foreach ($pair in @(@{C='D';S=$sNeg}, @{C='E';S=$sPos})) {
                    $col = $pair.C; $st = $pair.S
                    $cellVal = ($wsOut1.Cells["$col$row"].Text + '').Trim()
                    if (-not $cellVal) { continue }
                    $r = $rank[$st]
                    if ($r -ge 3) {
                        Style-Cell $wsOut1.Cells["$col$row"] $true "FF0000" "Medium" "FFFFFF"
                    } elseif ($r -ge 2) {
                        Style-Cell $wsOut1.Cells["$col$row"] $true "FFE699" "Medium" "806000"
                    } elseif ($r -ge 1) {
                        Style-Cell $wsOut1.Cells["$col$row"] $true "C6EFCE" "Medium" "006100"
                    }
                }
            }
            $row++
        }

        $wsOut1.Cells["D:D"].Style.WrapText = $false
        $wsOut1.Cells["E:E"].Style.WrapText = $false
        $wsOut1.Column(4).AutoFit()
        $wsOut1.Column(4).Width += 1.5
        $wsOut1.Column(4).BestFit = $true
        $wsOut1.Column(5).AutoFit()
        $wsOut1.Column(5).Width += 1.5
        $wsOut1.Column(5).BestFit = $true

        # R2: Freeze panes – fryser rad 1–2 (rubrik) så data scrollas under
        try { $wsOut1.View.FreezePanes(3, 1) } catch {}

        # ============================
        # === Testare (B43)        ===
        # ============================

        $testersNeg = @(); $testersPos = @()
        $unsignedNegSheets = New-Object System.Collections.Generic.List[string]
        $unsignedPosSheets = New-Object System.Collections.Generic.List[string]
        foreach ($s in $pkgNeg.Workbook.Worksheets) {
            if (-not (_IsActiveSealSheet $s)) { continue }
            $t = (($s.Cells["B43"].Text + '')).Trim()
            if ($t) {
                $testersNeg += ($t -split ",")
            } else {
                [void]$unsignedNegSheets.Add($s.Name)
            }
        }
        foreach ($s in $pkgPos.Workbook.Worksheets) {
            if (-not (_IsActiveSealSheet $s)) { continue }
            $t = (($s.Cells["B43"].Text + '')).Trim()
            if ($t) {
                $testersPos += ($t -split ",")
            } else {
                [void]$unsignedPosSheets.Add($s.Name)
            }
        }
        $testersNeg = $testersNeg | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Sort-Object -Unique
        $testersPos = $testersPos | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Sort-Object -Unique

        $wsOut1.Cells["B16"].Value = "Name of Tester"
        $wsOut1.Cells["B16:C16"].Merge = $true
        $wsOut1.Cells["B16"].Style.HorizontalAlignment = "Center"

        $maxTesters = [Math]::Max($testersNeg.Count, $testersPos.Count)
        $initialRows = 11
        if ($maxTesters -lt $initialRows) { $wsOut1.DeleteRow(17 + $maxTesters, $initialRows - $maxTesters) }
        if ($maxTesters -gt $initialRows) {
            $rowsToAdd = $maxTesters - $initialRows
            $lastRow = 16 + $initialRows
            for ($i = 1; $i -le $rowsToAdd; $i++) { $wsOut1.InsertRow($lastRow + 1, 1, $lastRow) }
        }

        for ($i = 0; $i -lt $maxTesters; $i++) {
            $rowIndex = 17 + $i
            $wsOut1.Cells["A$rowIndex"].Value = $null
            $wsOut1.Cells["B$rowIndex"].Value = if ($i -lt $testersNeg.Count) { $testersNeg[$i] } else { "N/A" }
            $wsOut1.Cells["C$rowIndex"].Value = if ($i -lt $testersPos.Count) { $testersPos[$i] } else { "N/A" }

            $topStyle    = if ($i -eq 0) { "Medium" } else { "Thin" }
            $bottomStyle = if ($i -eq $maxTesters - 1) { "Medium" } else { "Thin" }

            foreach ($col in @("B","C")) {
                $cell = $wsOut1.Cells["$col$rowIndex"]
                $cell.Style.Border.Top.Style    = $topStyle
                $cell.Style.Border.Bottom.Style = $bottomStyle
                $cell.Style.Border.Left.Style   = "Medium"
                $cell.Style.Border.Right.Style  = "Medium"
                $cell.Style.Fill.PatternType = "Solid"
                $cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#CCFFFF"))
            }
        }

        $negUnsignedText = _BuildUnsignedSealText @($unsignedNegSheets.ToArray())
        $posUnsignedText = _BuildUnsignedSealText @($unsignedPosSheets.ToArray())
        $unsignedMsgs = @()
        if ($negUnsignedText) { $unsignedMsgs += ('NEG: ' + $negUnsignedText) }
        if ($posUnsignedText) { $unsignedMsgs += ('POS: ' + $posUnsignedText) }
        if ($unsignedMsgs.Count -gt 0) {
            $unsignedInfo = $unsignedMsgs -join ' | '
            $wsOut1.Cells['D16'].Value = 'Name of Tester (osignerat)'
            $wsOut1.Cells['D17'].Value = $unsignedInfo
            $wsOut1.Cells['D16'].Style.Font.Bold = $true
            $wsOut1.Cells['D16:D17'].Style.WrapText = $true
            Style-Cell $wsOut1.Cells['D17'] $true "FFE699" "Medium" "806000"
            try {
                $wsOut1.Column(4).AutoFit()
                if ($wsOut1.Column(4).Width -lt 42) { $wsOut1.Column(4).Width = 42 }
                $wsOut1.Column(4).BestFit = $true
            } catch {}
            Gui-Log ("⚠️ Name of Tester saknas på aktiva datasheets: {0}" -f $unsignedInfo) 'Warn'
        }
        # ============================
        # === Signatur-jämförelse  ===
        # ============================
$negSigSet = Get-SignatureSetForDataSheets -Pkg $pkgNeg -SignatureCell $Layout.SignatureCell -ActiveCheckCell $Layout.SealActiveCheckCell
$posSigSet = Get-SignatureSetForDataSheets -Pkg $pkgPos -SignatureCell $Layout.SignatureCell -ActiveCheckCell $Layout.SealActiveCheckCell
$negSet = New-Object 'System.Collections.Generic.HashSet[string]'
$posSet = New-Object 'System.Collections.Generic.HashSet[string]'
foreach ($n in $negSigSet.NormSet) { [void]$negSet.Add($n) }
foreach ($p in $posSigSet.NormSet) { [void]$posSet.Add($p) }
# Om denna körning har skrivit och verifierat signaturen i en fil,
# är den skrivna/verifierade signaturen mer pålitlig än gammal inläst B47-data.
# Detta löser fallet där rapportpaketet lästes in före signeringen.
if ($negSealSignatureAppliedThisRun -and $signToWrite) {
    $negSet.Clear()
    [void]$negSet.Add((Normalize-Signature $signToWrite))
}
if ($posSealSignatureAppliedThisRun -and $signToWrite) {
    $posSet.Clear()
    [void]$posSet.Add((Normalize-Signature $signToWrite))
}
$hasNeg = ($negSet.Count -gt 0)
$hasPos = ($posSet.Count -gt 0)
# Räkna aktiva blad och saknade signaturer per fil.
# Detta behövs för att skilja på:
# 1) helt osignerade Seal Test-filer
# 2) delvis signerade filer där något aktivt blad saknar B47
$negActiveCount = 0
$posActiveCount = 0
$negMissingRawCount = 0
$posMissingRawCount = 0
if ($negSigSet -and $negSigSet.PSObject.Properties['ActiveSheets']) {
    $negActiveCount = @($negSigSet.ActiveSheets | Where-Object { $_ }).Count
}
if ($posSigSet -and $posSigSet.PSObject.Properties['ActiveSheets']) {
    $posActiveCount = @($posSigSet.ActiveSheets | Where-Object { $_ }).Count
}
if ($negSigSet -and $negSigSet.PSObject.Properties['Missing']) {
    $negMissingRawCount = @($negSigSet.Missing | Where-Object { $_ }).Count
}
if ($posSigSet -and $posSigSet.PSObject.Properties['Missing']) {
    $posMissingRawCount = @($posSigSet.Missing | Where-Object { $_ }).Count
}
# En fil räknas som helt osignerad endast om:
# - den har aktiva blad
# - ingen signatur hittades
# - alla aktiva blad saknar signatur
# - denna körning har inte precis skrivit/verifierat signatur i filen
$negAllUnsigned = (
    (-not $negSealSignatureAppliedThisRun) -and
    ($negActiveCount -gt 0) -and
    ($negSet.Count -eq 0) -and
    ($negMissingRawCount -eq $negActiveCount)
)
$posAllUnsigned = (
    (-not $posSealSignatureAppliedThisRun) -and
    ($posActiveCount -gt 0) -and
    ($posSet.Count -eq 0) -and
    ($posMissingRawCount -eq $posActiveCount)
)
# Specialfall:
# Om både NEG och POS är helt osignerade ska detta inte loggas som avvikelse.
# Rapporten ska i stället visa "Seal Test blad ej signerade".
$sealSheetsUnsigned = ($negAllUnsigned -and $posAllUnsigned)
$missingNegSheets = @()
$missingPosSheets = @()
if (-not $sealSheetsUnsigned) {
    if (-not $negSealSignatureAppliedThisRun) {
        if ($negSigSet -and $negSigSet.PSObject.Properties['Missing']) {
            $missingNegSheets = @($negSigSet.Missing | Where-Object { $_ })
        }
    }
    if (-not $posSealSignatureAppliedThisRun) {
        if ($posSigSet -and $posSigSet.PSObject.Properties['Missing']) {
            $missingPosSheets = @($posSigSet.Missing | Where-Object { $_ })
        }
    }
}
$sigMissing = ((-not $sealSheetsUnsigned) -and (($missingNegSheets.Count + $missingPosSheets.Count) -gt 0))
$onlyNeg = @()
$onlyPos = @()
$sigMismatch = $false
if ($sealSheetsUnsigned) {
    $sigMismatch = $false
}
elseif ($hasNeg -and $hasPos) {
    foreach ($n in $negSet) {
        if (-not $posSet.Contains($n)) { $onlyNeg += $n }
    }
    foreach ($p in $posSet) {
        if (-not $negSet.Contains($p)) { $onlyPos += $p }
    }
    $sigMismatch = ($onlyNeg.Count -gt 0 -or $onlyPos.Count -gt 0)
} else {
    $sigMismatch = $false
}
$sigIssue = ((-not $sealSheetsUnsigned) -and ($sigMismatch -or $sigMissing))
$mismatchSheets = @()
if ($sigMissing -and -not $sealSheetsUnsigned) {
    foreach ($sheetName in $missingNegSheets) {
        $mismatchSheets += ("NEG: SIGNATUR SAKNAS  [Blad: " + $sheetName + "]")
    }
    foreach ($sheetName in $missingPosSheets) {
        $mismatchSheets += ("POS: SIGNATUR SAKNAS  [Blad: " + $sheetName + "]")
    }
    $missingParts = @()
    if ($missingNegSheets.Count -gt 0) { $missingParts += ("NEG: " + ($missingNegSheets -join ', ')) }
    if ($missingPosSheets.Count -gt 0) { $missingParts += ("POS: " + ($missingPosSheets -join ', ')) }
}
if ($sigMismatch) {
            foreach ($k in $onlyNeg) {
                $raw = if ($negSigSet.RawByNorm.ContainsKey($k)) { $negSigSet.RawByNorm[$k] } else { $k }
                $where = if ($negSigSet.Occ.ContainsKey($k)) { ($negSigSet.Occ[$k] -join ', ') } else { '—' }
                $mismatchSheets += ("NEG: " + $raw + "  [Blad: " + $where + "]")
            }
            foreach ($k in $onlyPos) {
                $raw = if ($posSigSet.RawByNorm.ContainsKey($k)) { $posSigSet.RawByNorm[$k] } else { $k }
                $where = if ($posSigSet.Occ.ContainsKey($k)) { ($posSigSet.Occ[$k] -join ', ') } else { '—' }
                $mismatchSheets += ("POS: " + $raw + "  [Blad: " + $where + "]")
            }
            Gui-Log "⚠️ Avvikelse: Print Full Name, Sign, and Date (NEG vs POS)"
        }
        $signRow = 17 + $maxTesters + 3
        $displaySignNeg = $null; $displaySignPos = $null
if ($negSealSignatureAppliedThisRun -and $signToWrite) {
    $displaySignNeg = $signToWrite
} else {
    $displaySignNeg = if ($negSigSet.RawFirst) { $negSigSet.RawFirst } else { '—' }
}
if ($posSealSignatureAppliedThisRun -and $signToWrite) {
    $displaySignPos = $signToWrite
} else {
    $displaySignPos = if ($posSigSet.RawFirst) { $posSigSet.RawFirst } else { '—' }
}

        $wsOut1.Cells["B$signRow"].Style.Numberformat.Format = '@'
        $wsOut1.Cells["C$signRow"].Style.Numberformat.Format = '@'
        $wsOut1.Cells["B$signRow"].Value = $displaySignNeg
        $wsOut1.Cells["C$signRow"].Value = $displaySignPos

        foreach ($col in @('B','C')) {
            $cell = $wsOut1.Cells["${col}$signRow"]
            Style-Cell $cell $false 'CCFFFF' 'Medium' $null
            $cell.Style.HorizontalAlignment = 'Center'
        }

        try { $wsOut1.Column(2).Width = 40; $wsOut1.Column(3).Width = 40 } catch {}
if ($sigIssue) {
    # === SIGNATURAVVIKELSE: mismatch och/eller saknad signatur ===
    $mismatchCell = $wsOut1.Cells["D$signRow"]
    if ($sigMissing -and $sigMismatch) {
        $mismatchCell.Value = ([char]0x26A0 + ' Mismatch / saknas')
    }
    elseif ($sigMissing) {
        $mismatchCell.Value = ([char]0x26A0 + ' Signatur saknas')
    }
    else {
        $mismatchCell.Value = ([char]0x26A0 + ' Mismatch')
    }
    Style-Cell $mismatchCell $true 'FF0000' 'Medium' 'FFFFFF'

            if ($mismatchSheets.Count -gt 0) {
                # Bygg kompakt detaljtext: en rad per avvikande signatur
                $detailLines = New-Object System.Collections.Generic.List[string]
                foreach ($text in $mismatchSheets) {
                    $filType = ''; $sigVal = ''; $bladVal = ''
                    if ($text -match '^(NEG|POS):\s*(.+?)\s*\[Blad:\s*(.+?)\]$') {
                        $filType = $matches[1]
                        $sigVal  = $matches[2].Trim()
                        $bladVal = $matches[3].Trim()
                        [void]$detailLines.Add("$filType : $sigVal  ($bladVal)")
                    } else {
                        [void]$detailLines.Add($text)
                    }
                }
                $detailRow = $signRow + 1
                $detailText = ($detailLines -join [char]10)
                $detailCell = $wsOut1.Cells["D$detailRow"]
                $detailCell.Value = $detailText
                $detailCell.Style.WrapText = $true
                $detailCell.Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Top
                $detailCell.Style.Font.Size = 9
                $detailCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $detailCell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#FFE699'))
                $detailCell.Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml('#806000'))
                $detailCell.Style.Border.Top.Style    = 'Medium'
                $detailCell.Style.Border.Bottom.Style = 'Medium'
                $detailCell.Style.Border.Left.Style   = 'Medium'
                $detailCell.Style.Border.Right.Style  = 'Medium'

                # Dynamisk radhöjd baserat på antal rader
                try {
                    $lineCount = [Math]::Max(1, $detailLines.Count)
                    $targetHeight = [Math]::Max(20, $lineCount * 16)
                    $wsOut1.Row($detailRow).Height = $targetHeight
                    $wsOut1.Row($detailRow).CustomHeight = $true
                } catch {}
            }
} elseif ($sealSheetsUnsigned) {
    # === INFO: Seal Test-bladen är medvetet/osignerat läge ===
    # Detta är inte en mismatch och ska inte loggas som avvikelse.
    $unsignedCell = $wsOut1.Cells["D$signRow"]
    $unsignedCell.Value = 'Seal Test blad ej signerade'
    Style-Cell $unsignedCell $true 'D9EAF7' 'Medium' '1F4E79'
} else {
    # === MATCH: grön markering endast när signaturer finns och stämmer ===
    if ($hasNeg -and $hasPos -and -not $sigMissing) {
        $matchCell = $wsOut1.Cells["D$signRow"]
        $matchCell.Value = '✓ Match'
        Style-Cell $matchCell $true 'C6EFCE' 'Medium' '006100'
    }
}
        # ============================
        # === STF Sum              ===
        # ============================

        $wsOut2 = $pkgOut.Workbook.Worksheets[$Layout.SheetStfSummary]
        if (-not $wsOut2) { Gui-Log "❌ Fliken 'STF Summary' saknas i mallen!"; return }

        $totalRows = $violationsNeg.Count + $violationsPos.Count
        $currentRow = 2

        if ($totalRows -eq 0) {
            Gui-Log "✅ Seal Test hittades"
            $wsOut2.Cells["B1:H1"].Value = $null
            $wsOut2.Cells["A1"].Value = "Inga STF hittades!"
            Style-Cell $wsOut2.Cells["A1"] $true "D9EAD3" "Medium" "006100"
            $wsOut2.Cells["A1"].Style.HorizontalAlignment = "Left"
            if ($wsOut2.Dimension -and $wsOut2.Dimension.End.Row -gt 1) { $wsOut2.DeleteRow(2, $wsOut2.Dimension.End.Row - 1) }
        }
        else {

            $oldDataRows = 0
            if ($wsOut2.Dimension) {
                $oldDataRows = $wsOut2.Dimension.End.Row - 1
                if ($oldDataRows -lt 0) { $oldDataRows = 0 }
            }

            if ($totalRows -lt $oldDataRows) {
                $wsOut2.DeleteRow(2 + $totalRows, $oldDataRows - $totalRows)
            }
            elseif ($totalRows -gt $oldDataRows) {
                $wsOut2.InsertRow(2 + $oldDataRows, $totalRows - $oldDataRows, 1 + $oldDataRows)
            }

            $currentRow = 2
            foreach ($v in $violationsNeg) {
                $wsOut2.Cells["A$currentRow"].Value = "NEG"
                $wsOut2.Cells["B$currentRow"].Value = $v.Sheet
                $wsOut2.Cells["C$currentRow"].Value = $v.Cartridge
                $wsOut2.Cells["D$currentRow"].Value = $v.InitialW
                $wsOut2.Cells["E$currentRow"].Value = $v.FinalW
                if ($v.WeightLoss -ne $null) {
    $wsOut2.Cells["F$currentRow"].Value = [Math]::Round([double]$v.WeightLoss, 1)
} else {
    $wsOut2.Cells["F$currentRow"].Value = $null
}
                $wsOut2.Cells["G$currentRow"].Value = $v.Status
                $wsOut2.Cells["H$currentRow"].Value = if ([string]::IsNullOrWhiteSpace($v.Obs)) { 'NA' } else { $v.Obs }

                Style-Cell $wsOut2.Cells["A$currentRow"] $true "B5E6A2" "Medium" $null
                $wsOut2.Cells["C$currentRow:E$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["C$currentRow:E$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#CCFFFF"))
                $wsOut2.Cells["F$currentRow:G$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["F$currentRow:G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFFF99"))
                $wsOut2.Cells["H$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["H$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#D9D9D9"))

if ($v.Status -in @("FAIL","Minusvärde")) {
    $wsOut2.Cells["F$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["F$currentRow"].Style.Font.Color.SetColor([System.Drawing.Color]::Red)
    $wsOut2.Cells["G$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["G$currentRow"].Style.Font.Color.SetColor([System.Drawing.Color]::Red)
    # Röd bakgrund på riktig FAIL
    if ($v.Status -eq "FAIL") {
        $wsOut2.Cells["G$currentRow"].Style.Fill.PatternType = "Solid"
        $wsOut2.Cells["G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFC7CE"))
    }
}
elseif ($v.Status -eq "Saknar utvägning") {
    $wsOut2.Cells["E$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["E$currentRow"].Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#806000"))
    $wsOut2.Cells["G$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["G$currentRow"].Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#806000"))
    $wsOut2.Cells["G$currentRow"].Style.Fill.PatternType = "Solid"
    $wsOut2.Cells["G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFE699"))
}

                Set-RowBorder -ws $wsOut2 -row $currentRow -firstRow 2 -lastRow ($totalRows + 1)
                $currentRow++
            }

            foreach ($v in $violationsPos) {
                $wsOut2.Cells["A$currentRow"].Value = "POS"
                $wsOut2.Cells["B$currentRow"].Value = $v.Sheet
                $wsOut2.Cells["C$currentRow"].Value = $v.Cartridge
                $wsOut2.Cells["D$currentRow"].Value = $v.InitialW
                $wsOut2.Cells["E$currentRow"].Value = $v.FinalW
                if ($v.WeightLoss -ne $null) {
    $wsOut2.Cells["F$currentRow"].Value = [Math]::Round([double]$v.WeightLoss, 1)
} else {
    $wsOut2.Cells["F$currentRow"].Value = $null
}
                $wsOut2.Cells["G$currentRow"].Value = $v.Status
                $wsOut2.Cells["H$currentRow"].Value = if ($v.Obs) { $v.Obs } else { 'NA' }

                Style-Cell $wsOut2.Cells["A$currentRow"] $true "FFB3B3" "Medium" $null
                $wsOut2.Cells["C$currentRow:E$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["C$currentRow:E$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#CCFFFF"))
                $wsOut2.Cells["F$currentRow:G$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["F$currentRow:G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFFF99"))
                $wsOut2.Cells["H$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["H$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#D9D9D9"))

if ($v.Status -in @("FAIL","Minusvärde")) {
    $wsOut2.Cells["F$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["F$currentRow"].Style.Font.Color.SetColor([System.Drawing.Color]::Red)
    $wsOut2.Cells["G$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["G$currentRow"].Style.Font.Color.SetColor([System.Drawing.Color]::Red)
    # Röd bakgrund på riktig FAIL
    if ($v.Status -eq "FAIL") {
        $wsOut2.Cells["G$currentRow"].Style.Fill.PatternType = "Solid"
        $wsOut2.Cells["G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFC7CE"))
    }
}
elseif ($v.Status -eq "Saknar utvägning") {
    $wsOut2.Cells["E$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["E$currentRow"].Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#806000"))
    $wsOut2.Cells["G$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["G$currentRow"].Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#806000"))
    $wsOut2.Cells["G$currentRow"].Style.Fill.PatternType = "Solid"
    $wsOut2.Cells["G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFE699"))
}

                Set-RowBorder -ws $wsOut2 -row $currentRow -firstRow 2 -lastRow ($totalRows + 1)
                $currentRow++
            }

            $wsOut2.Cells.Style.WrapText = $false
            $wsOut2.Cells["A1"].Style.HorizontalAlignment = "Left"
            try { $wsOut2.Cells[2,6,([Math]::Max($currentRow-1,2)),6].Style.Numberformat.Format = '0.0' } catch {}
            if ($wsOut2.Dimension) {
                try {
                    if (Get-Command Safe-AutoFitColumns -ErrorAction SilentlyContinue) {
                        Safe-AutoFitColumns -Ws $wsOut2 -Context 'OutputSheet'
                    } else {
                        $wsOut2.Cells[$wsOut2.Dimension.Address].AutoFitColumns() | Out-Null
                    }
                } catch {}
            }
        }


        #endregion Build: CSV-inläsning och RuleEngine
        #region Build: Output-flikar (Information, Utrustning, Kontrollmaterial, SP, QC)
# ============================
# === Information-blad     ===
# ============================

try {
    Mark-Phase 'Kontrollmaterial'
    $wsInfo = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if (-not $wsInfo) { $wsInfo = $pkgOut.Workbook.Worksheets.Add($Layout.SheetRunInfo) }

# Säkerställ att kolumn C inte är dold (mallen styr bredd och wrap)
try { $wsInfo.Column(3).Hidden = $false } catch {}

    try {
        $csvLines = $null
        $csvStats = $null

        # ✅ Viktigt: initiera alltid, även om ingen CSV är vald
        $csvInstrumentSerials = @()

        if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
            try { $csvLines = $script:CsvLinesPrimary } catch { Gui-Log ("⚠️ Kunde inte läsa CSV: " + $_.Exception.Message) 'Warn' }
            try { $csvStats = Get-CsvStats -Path $selCsv -Lines $csvLines } catch { Gui-Log ("⚠️ Get-CsvStats: " + $_.Exception.Message) 'Warn' }

            # Hämta exakt lista med Instrument S/N från CSV (för Equipment-blad när WS-skanning är av)
            try {
                if ($csvLines -and $csvLines.Count -gt 8) {
                    $hdr = ConvertTo-CsvFields $csvLines[7]

                    $idx = -1
                    for ($ii=0; $ii -lt $hdr.Count; $ii++) {
                        $h = (($hdr[$ii] + '').Trim('\"').ToLower())
                        if ($h -eq 'instrument s/n' -or $h -match 'instrument') { $idx = $ii; break }
                    }

                    if ($idx -ge 0) {
                        $set = New-Object System.Collections.Generic.HashSet[string]
                        for ($rr=9; $rr -lt $csvLines.Count; $rr++) {
                            $ln = $csvLines[$rr]
                            if (-not $ln -or -not $ln.Trim()) { continue }
                            $f = ConvertTo-CsvFields $ln
                            if ($f.Count -gt $idx) {
                                $v = ($f[$idx] + '').Trim().Trim('\"')
                                if ($v) { $null = $set.Add($v) }
                            }
                        }

                        # HashSet[T]-enumerering (PS 5.1-säker)
                        $csvInstrumentSerials = @($set | Sort-Object)
                    }
                }
            } catch {
                Gui-Log ("⚠️ Kunde inte extrahera Instrument S/N från CSV: " + $_.Exception.Message) 'Warn'
                $csvInstrumentSerials = @()
            }
        }

        if (-not $csvStats) {
            $csvStats = [pscustomobject]@{
                TestCount    = 0
                DupCount     = 0
                Duplicates   = @()
                LspValues    = @()
                LspOK        = $null
                InstrumentByType = [ordered]@{}
            }
        }

        # Statistik för Resample-CSV
        $csvStatsRes = $null
        if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
            try {
                $csvLinesRes = $script:CsvLinesResample
                $csvStatsRes = Get-CsvStats -Path $selCsvRes -Lines $csvLinesRes
            } catch { Gui-Log ("⚠️ Resample Get-CsvStats: " + $_.Exception.Message) 'Warn' }
        }

        $infSN = @()
        if ($script:GXINF_Map) {
            foreach ($k in $script:GXINF_Map.Keys) {
                if ($k -like 'Infinity-*') {
                    $infSN += ($script:GXINF_Map[$k].Split(',') | ForEach-Object { ($_ + '').Trim() } | Where-Object { $_ })
                }
            }
        }
        $infSN = $infSN | Select-Object -Unique

        $infSummary = '—'
        try {
            if ($selCsv -and (Test-Path -LiteralPath $selCsv) -and $infSN.Count -gt 0) {
                $infSummary = Get-InfinitySpFromCsvStrict -Path $selCsv -InfinitySerials $infSN -Lines $csvLines
            }
        } catch {
            Gui-Log ("Infinity SP fel: " + $_.Exception.Message) 'Warn'
        }

        # --- Dubbletter Sample ID ---
        $dupSampleCount = 0
        $dupSampleList  = @()
        if ($csvLines -and $csvLines.Count -gt 8) {
            try {
                $headerFields = ConvertTo-CsvFields $csvLines[7]
                $sampleIdx = -1
                for ($i=0; $i -lt $headerFields.Count; $i++) {
                    $hf = ($headerFields[$i] + '').Trim().ToLower()
                    if ($hf -match 'sample') { $sampleIdx = $i; break }
                }
                if ($sampleIdx -ge 0) {
                    $samples = @()
                    for ($r=9; $r -lt $csvLines.Count; $r++) {
                        $line = $csvLines[$r]
                        if (-not $line -or -not $line.Trim()) { continue }
                        $fields = ConvertTo-CsvFields $line
                        if ($fields.Count -gt $sampleIdx) {
                            $val = ($fields[$sampleIdx] + '').Trim()
                            if ($val) { $samples += $val }
                        }
                    }
                    if ($samples.Count -gt 0) {
                        $counts = @{}
                        foreach ($s in $samples) { if (-not $counts.ContainsKey($s)) { $counts[$s] = 0 }; $counts[$s] = [int]$counts[$s] + 1 }
                        foreach ($entry in $counts.GetEnumerator()) {
                            if ($entry.Value -gt 1) { $dupSampleList += ("$($entry.Key) x$($entry.Value)") }
                        }
                        $dupSampleCount = $dupSampleList.Count
                    }
                }
            } catch {
                Gui-Log ("⚠️ Fel vid analys av Sample ID: " + $_.Exception.Message) 'Warn'
            }
        }

        $dupSampleText = if ($dupSampleCount -gt 0) {
            $show = ($dupSampleList | Select-Object -First 8) -join ', '
            "$dupSampleCount ($show)"
        } else { 'N/A' }

        $dupCartText = if ($csvStats.DupCount -gt 0) {
            $show = ($csvStats.Duplicates | Select-Object -First 8) -join ', '
            "$($csvStats.DupCount) ($show)"
        } else { 'N/A' }

        # --- LSP-summering ---
        $lspSummary = ''
        try {
            if ($csvLines -and $csvLines.Count -gt 8) {
                $counts = @{}
                for ($rr = 9; $rr -lt $csvLines.Count; $rr++) {
                    $ln = $csvLines[$rr]
                    if (-not $ln -or -not $ln.Trim()) { continue }
                    $fs = ConvertTo-CsvFields $ln
                    if ($fs.Count -gt 4) {
                        $raw = ($fs[4] + '').Trim()
                        if ($raw) {
                            $mLsp = [regex]::Match($raw,'(\d{5})')
                            $code = if ($mLsp.Success) { $mLsp.Groups[1].Value } else { $raw }
                            if (-not $counts.ContainsKey($code)) { $counts[$code] = 0 }
                            $counts[$code] = [int]$counts[$code] + 1
                        }
                    }
                }

                if ($counts.Count -gt 0) {
                    $sorted = @($counts.GetEnumerator() | Sort-Object Key)
                    $parts = @()
                    foreach ($kvp in $sorted) {
                        $parts += $(if ($kvp.Value -gt 1) { "$($kvp.Key) x$($kvp.Value)" } else { $kvp.Key })
                    }
                    if ($sorted.Count -eq 1) { $lspSummary = $sorted[0].Key }
                    else { $lspSummary = "$($sorted.Count) (" + ($parts -join ', ') + ")" }
                }
            }
        } catch {
            Gui-Log ("⚠️ Fel vid extraktion av LSP från CSV: " + $_.Exception.Message) 'Warn'
            $lspSummary = ''
        }

        $instText = if ($csvStats.InstrumentByType.Keys.Count -gt 0) {
            ($csvStats.InstrumentByType.GetEnumerator() | ForEach-Object { "$($_.Key)" } | Sort-Object) -join '; '
        } else { '' }

        # ✅ Standard: anta INTE nytt layoutläge om vi inte hittar ankaret
        $isNewLayout = $false
        try {
            $tmpRow = Find-InfoRow -Ws $wsInfo -Label 'CSV-Info'
            if ($tmpRow) { $isNewLayout = $true }
        } catch {}

        $rowCsvFile    = Find-InfoRow -Ws $wsInfo -Label 'CSV'
        $rowLsp        = Find-InfoRow -Ws $wsInfo -Label 'LSP'
        $rowBag        = Find-InfoRow -Ws $wsInfo -Label 'Infinity bags'
        if (-not $rowBag) { $rowBag = Find-InfoRow -Ws $wsInfo -Label 'Bag Numbers Tested Using Infinity' }
        if (-not $rowBag) { $rowBag = Find-InfoRow -Ws $wsInfo -Label 'Bag Numbers Tested Using Infinity:' }
        if (-not $rowBag) { $rowBag = 11 }
        $rowAntal      = Find-InfoRow -Ws $wsInfo -Label 'Antal tester'
        if (-not $rowDupSample) { $rowDupSample = Find-InfoRow -Ws $wsInfo -Label 'Dublett Sample ID' }

        $wsInfo.Cells["B$rowBag"].Style.Numberformat.Format = '@'
        $wsInfo.Cells["B$rowBag"].Value = $infSummary

        if ($isNewLayout) {
            if (-not $rowCsvFile)   { $rowCsvFile   = 8 }
            if (-not $rowLsp)       { $rowLsp       = 9 }
            if (-not $rowBag)       { $rowBag       = 10 }
            if (-not $rowAntal)     { $rowAntal     = 11 }
        }

        if ($selCsv -or $selCsvRes) {
            $wsInfo.Cells["B$rowCsvFile"].Style.Numberformat.Format = '@'
            $csvLabel = ''
            if ($selCsv -and $selCsvRes) {
                $csvLabel = "Primary: {0} | Resampling: {1}" -f (Get-CleanLeaf $selCsv), (Get-CleanLeaf $selCsvRes)
            } elseif ($selCsv) {
                $csvLabel = (Get-CleanLeaf $selCsv)
            } else {
                $csvLabel = "Resampling: {0}" -f (Get-CleanLeaf $selCsvRes)
            }
            $wsInfo.Cells["B$rowCsvFile"].Value = $csvLabel
        } else {
            $wsInfo.Cells["B$rowCsvFile"].Value = ''
        }

        $wsInfo.Cells["B$rowLsp"].Style.Numberformat.Format = '@'
        $wsInfo.Cells["B$rowLsp"].Value = $(if ($lspSummary) { $lspSummary } else { $lsp })

        # ✅ Skriv Antal tester EN gång (som text för att inte bli 1.00E+3 etc)
        $wsInfo.Cells["B$rowAntal"].Style.Numberformat.Format = '@'
        $totalTests = [int]$csvStats.TestCount
        $antalText = "$totalTests"
        if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) {
            $totalTests += [int]$csvStatsRes.TestCount
            $antalText = "$totalTests ($($csvStats.TestCount) + $($csvStatsRes.TestCount) Resample)"
        }
        $wsInfo.Cells["B$rowAntal"].Value = $antalText

        try { $wsInfo.Cells['B:B'].Style.WrapText = $false } catch {}

    } catch {
        Gui-Log ("⚠️ CSV data-fel: " + $_.Exception.Message) 'Warn'
    }

    # --- Makro / dokumentinfo ---
    $assayForMacro = ''
    if ($runAssay) { $assayForMacro = $runAssay }
    elseif ($wsOut1) { $assayForMacro = Get-CellText $wsOut1 $Layout.AssayNameCell }

    $miniVal = ''
    if (Get-Command Get-MinitabMacro -ErrorAction SilentlyContinue) {
        $miniVal = Get-MinitabMacro -AssayName $assayForMacro
    }
    if (-not $miniVal) { $miniVal = 'N/A' }

    $hdNeg = $null; $hdPos = $null
    try { $hdNeg = Get-SealHeaderDocInfo -Pkg $pkgNeg } catch {}
    try { $hdPos = Get-SealHeaderDocInfo -Pkg $pkgPos } catch {}
    if (-not $hdNeg) { $hdNeg = [pscustomobject]@{ Raw=''; DocNo=''; Rev='' } }
    if (-not $hdPos) { $hdPos = [pscustomobject]@{ Raw=''; DocNo=''; Rev='' } }

    $wsInfo.Cells['B2'].Value = $ScriptVersion
    $wsInfo.Cells['B3'].Value = $env:USERNAME
    $wsInfo.Cells['B4'].Value = (Get-Date).ToString('yyyy-MM-dd HH:mm')
    $wsInfo.Cells['B5'].Value = $miniVal

    # --- Batch + länkar ---
    $selLsp = $null
    try {
        if (Get-Variable -Name clbLsp -ErrorAction SilentlyContinue) {
            $selLsp = Get-CheckedFilePath $clbLsp
        }
    } catch {}

    # Snapshot även för Worksheet (om vald) – läsning sker från kopian
    if ($enableStaging -and $stageDir -and $selLsp -and (Test-Path -LiteralPath $selLsp)) {
        try {
            $selLspOrig = $selLsp
            $selLsp = Stage-InputFileSnapshot -Path $selLsp -StageDir $stageDir -Prefix 'Worksheet'
        } catch {}
    }
$batchInfo = Get-BatchLinkInfo -SealPosPath $selPos -SealNegPath $selNeg -Lsp $lspForLinks
$batch     = $batchInfo.Batch
$spOrder   = $batchInfo.Order
$wsInfo.Cells['A31'].Value = 'Öppna SharePoint-post'
$wsInfo.Cells['A31'].Style.Font.Bold = $true
Add-Hyperlink -Cell $wsInfo.Cells['B31'] -Text $batchInfo.LinkText -Url $batchInfo.Url

try {
    if ($batchInfo.OrderStatus -eq 'Mismatch') {
        Gui-Log ("⚠️ Seal Test Order# mismatch mellan aktiva blad: " + (($batchInfo.OrderInfo.AllOrders | Sort-Object) -join ', ')) 'Warn'
    }
    elseif ($batchInfo.OrderStatus -ne 'Unique') {
        Gui-Log "⚠️ Entydigt Order# kunde inte läsas från Seal Test. SharePoint-sökning litar inte på Batch/LSP." 'Warn'
    }
} catch {}

    $linkMap = [ordered]@{
        'IPT App'      = 'https://apps.powerapps.com/play/e/default-771c9c47-7f24-44dc-958e-34f8713a8394/a/fd340dbd-bbbf-470b-b043-d2af4cb62c83'
        'MES Login'    = 'http://mes.cepheid.pri/camstarportal/?domain=CEPHEID.COM'
        'CSV Uploader' = 'http://auw2wgxtpap01.cepaws.com/Welcome.aspx'
        'BMRAM'        = 'https://cepheid62468.coolbluecloud.com/'
        'Agile'        = 'https://agileprod.cepheid.com/Agile/default/login-cms.jsp'
    }

    $rowLink = 32
    foreach ($key in $linkMap.Keys) {
        $wsInfo.Cells["A$rowLink"].Value = $key
        Add-Hyperlink -Cell $wsInfo.Cells["B$rowLink"] -Text 'LÄNK' -Url $linkMap[$key]
        $rowLink++
    }

} catch {
    Gui-Log ("⚠️ Run Information fel: " + $_.Exception.Message) 'Warn'
}
                        
# ----------------------------------------------------------------
# WS (LSP-blad): hitta fil och skriv in i Information-bladet
# ----------------------------------------------------------------
try {
    if (-not $selLsp) {
        $probeDir = $null
        if ($selPos) { $probeDir = Split-Path -Parent $selPos }
        if (-not $probeDir -and $selNeg) { $probeDir = Split-Path -Parent $selNeg }

        if ($probeDir -and (Test-Path -LiteralPath $probeDir)) {
            $cand = Get-ChildItem -LiteralPath $probeDir -File -ErrorAction SilentlyContinue |
                    Where-Object {
                        ($_.Name -match '(?i)worksheet') -and
                        ($_.Name -match [regex]::Escape($lsp)) -and
                        ($_.Extension -match '^\.(xlsx|xlsm|xls)$')
                    } |
                    Sort-Object LastWriteTime -Descending |
                    Select-Object -First 1

            if ($cand) { $selLsp = $cand.FullName }
        }
    }

    if ($selLsp -and (Test-Path -LiteralPath $selLsp)) {
        $wsLeaf = Get-CleanLeaf $selLsp
        Gui-Log ("🔎 Worksheet: " + $wsLeaf) 'Info'
    } else {
        Gui-Log "ℹ️ Ingen WS-fil vald/hittad (LSP Worksheet). Hoppar över WS-extraktion." 'Info'
    }
} catch {
    Gui-Log ("⚠️ WS-block fel: " + $_.Exception.Message) 'Warn'
}

try {
    # Se till att dessa alltid finns (de används senare)
    $headerWs  = $null
    $headerNeg = $null
    $headerPos = $null
    # OBS: $eqInfo används senare vid Equipment-blad → initiera här
    if (-not (Get-Variable -Name eqInfo -Scope 1 -ErrorAction SilentlyContinue)) {
        $eqInfo = $null
    }

    # --- Återanvänd WS-paketet från Data Summary-skanning om möjligt ---
    $tmpPkg = $null
    $tmpPkgReused = $false
    try {
        if ($selLsp -and (Test-Path -LiteralPath $selLsp)) {
            try {
                if ($script:WsPkg -and $script:WsPkg.File -and
                    $script:WsPkg.File.FullName -ieq (Resolve-Path -LiteralPath $selLsp -ErrorAction SilentlyContinue).Path) {
                    $tmpPkg = $script:WsPkg
                    $tmpPkgReused = $true
                } else {
                    # Sökväg ändrades (borde inte hända), öppna ny
                    if ($script:WsPkg) { try { $script:WsPkg.Dispose() } catch {} }
                    $script:WsPkg = $null
                    $tmpPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selLsp))
                }

                # ==============================
                # Utrustning / TestSummary
                # ==============================
                try {
                    # "EquipmentSheet" ska endast generera själva BLADET/mallen.
                    # Det ska *inte* automatiskt hämta pipetter/instrument från Test Summary/CSV här,
                    # annars blir det en blandning (automatiskt + manuellt) som förvirrar användaren.
                    if ($Config -and $Config.Contains('EnableEquipmentSheet') -and -not $Config.EnableEquipmentSheet) {
                        $eqInfo = $null
                        Gui-Log 'ℹ️ Utrustningslista avstängt. Hoppar över.' 'Info'
                    } else {
                        $eqInfo = $null
                        Gui-Log '✅ Utrustningslista hämtad.' 'Info' 'PROGRESS'
                    }
                } catch {
                    # Utrustning ska aldrig få stoppa rapporten
                    try { Gui-Log ("⚠️ Utrustningslista: kunde inte hämtas: " + $_.Exception.Message) 'Warn' } catch {}
                    $eqInfo = $null
                }

                # ==============================
                # Bladrubrik (extrahera + jämför)
                # ==============================
                try {
                    $headerWs = Extract-WorksheetHeader -Pkg $tmpPkg
                } catch {
                    $headerWs = $null
                }

                # Reservväg om extrahering gav null: skapa tomt objekt så .PartNo osv inte kraschar
                if (-not $headerWs) {
                    $headerWs = [pscustomobject]@{
                        WorksheetName   = ''
                        PartNo          = ''
                        BatchNo         = ''
                        CartridgeNo     = ''
                        DocumentNumber  = ''
                        Rev             = ''
                        Effective       = ''
                        Attachment      = ''
                    }
                }

                # StrictMode-säker: används senare även om jämförelsen misslyckas
                $wsHeaderCheck = $null
try {
    # QC Data ska bara ingå i headerkontrollen när Additional QC Data faktiskt förväntas.
    # Samma grundlogik som QC-påminnelsen: assay + Test Summary!B3.
    $qcDataHeaderExpected = $false
    $qcDataHeaderB3       = $null
    $qcDataSheetExists    = $false
    try {
        $qcDataSheetExists = @(
            $tmpPkg.Workbook.Worksheets |
            Where-Object { ($_.Name + '') -match '(?i)^\s*QC\s+Data\s*$' }
        ).Count -gt 0
        $qcTriggerAssays = @(
            'Xpert_HIV-1 Viral Load',
            'Xpert HIV-1 Viral Load XC',
            'Xpert_HCV Viral Load',
            'Xpert HCV VL Fingerstick',
            'Xpert HBV Viral Load',
            'Xpert_HIV-1 Qual',
            'HIV-1_Qual RUO',
            'HIV-1 Qual XC DBS RUO',
            'HIV-1 Qual XC DBS IUO',
            'Xpert HIV-1 Qual XC PQC',
            'Xpert HIV-1 Qual XC PQC RUO'
        )
        $qcValidPartNos = @(
            'GXHIV-VL-CE-10',
            'GXHIV-VL-IN-10',
            'GXHIV-VL-CN-10',
            'GXHIV-VL-XC-CE-10',
            'GXHCV-VL-CE-10',
            'GXHCV-VL-IN-10',
            'GXHCV-FS-CE-10',
            'GXHBV-VL-CE-10',
            'GXHIV-QA-CE-10',
            'RHIVQ-10',
            '700-6098/HIV-1 QUAL XC, RUO',
            '700-6137/HIV-1 QUAL XC, IUO',
            '700-6793/ HIV-1 QUAL XC, CE-IVD',
            '700-6911/ HIV-1 QUAL XC, RUO'
        )

        $qcAssayMatch = $false
        if ($runAssay) {
            foreach ($_qa in $qcTriggerAssays) {
                if ($runAssay -ilike "$_qa*") {
                    $qcAssayMatch = $true
                    break
                }
            }
        }
        if ($qcAssayMatch) {
            $tsWs = $tmpPkg.Workbook.Worksheets |
                Where-Object { $_.Name -ieq 'Test Summary' } |
                Select-Object -First 1
            if ($tsWs) {
                $qcDataHeaderB3 = Get-CellText $tsWs 'B3'
                if ($qcDataHeaderB3 -and ($qcValidPartNos -contains $qcDataHeaderB3)) {
                    $qcDataHeaderExpected = $true
                }
            }
        }
    } catch {
        try { Gui-Log ("⚠️ QC Data header-gate: " + $_.Exception.Message) 'Warn' } catch {}
    }

    $wsHeaderRows  = Get-WorksheetHeaderPerSheet -Pkg $tmpPkg -IncludeQcData:$qcDataHeaderExpected
    $wsHeaderCheck = Compare-WorksheetHeaderSet   -Rows $wsHeaderRows

    try {
        if ($qcDataHeaderExpected) {
            if ($qcDataSheetExists) {
                $qcDataChecked = @(
                    $wsHeaderRows |
                    Where-Object { ($_.Sheet + '') -match '(?i)^\s*QC\s+Data\s*$' }
                ).Count -gt 0

                if ($qcDataChecked) {
                    Gui-Log ("✅ Worksheet header-kontroll inkluderar QC Data ({0})" -f $qcDataHeaderB3) 'Info'
                }
                else {
                    Gui-Log ("⚠️ Additional QC Data förväntas ({0}), men QC Data ingick inte i headerkontrollen" -f $qcDataHeaderB3) 'Warn'
                }
            }
            else {
                Gui-Log ("⚠️ Additional QC Data förväntas ({0}), men QC Data-flik saknas i Worksheet" -f $qcDataHeaderB3) 'Warn'
            }
        }
        elseif ($qcDataSheetExists) {
            Gui-Log "ℹ️ QC Data-flik finns, men Additional QC Data förväntas inte enligt Test Summary B3. QC Data exkluderas från headerkontroll." 'Info'
        }
    } catch {}
    try {
        if ($wsHeaderCheck.Issues -gt 0 -and $wsHeaderCheck.Summary) {
            Gui-Log ("⚠️ Worksheet header-avvikelser: {0} – se Run Information!" -f $wsHeaderCheck.Summary) 'Warn'
        } else {
            Gui-Log "✅ Worksheet header korrekt" 'Info' 'PROGRESS'
        }
    } catch {}
} catch {
    try { Gui-Log ("⚠️ Worksheet header-jämförelse: " + $_.Exception.Message) 'Warn' } catch {}
}

                # ==============================
                # Förstärk headerWs via etiketter (om extrahering missade)
                # ==============================
                try {
                    $wsLsp = $tmpPkg.Workbook.Worksheets | Where-Object {
                        $_.Name -ne 'Worksheet Instructions' -and
                        $_.Name -notmatch '(?i)^\s*QC\s+Data\s*$'
                    } | Select-Object -First 1
                    if (-not $wsLsp) {
                        $wsLsp = $tmpPkg.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' } | Select-Object -First 1
                    }
                    if ($wsLsp) {

                        if (-not $headerWs.PartNo) {
                            $val = $null
                            $labels = @('Part No.','Part No.:','Part No','Part Number','Part Number:','Part Number.','Part Number.:')
                            foreach ($lbl in $labels) { $val = Find-LabelValueRightward -Ws $wsLsp -Label $lbl; if ($val) { break } }
                            if ($val) { $headerWs.PartNo = $val }
                        }

                        if (-not $headerWs.BatchNo) {
                            $val = $null
                            $labels = @(
                                'Batch No(s)','Batch No(s).','Batch No(s):','Batch No(s).:',
                                'Batch No','Batch No.','Batch No:','Batch No.:',
                                'Batch Number','Batch Number.','Batch Number:','Batch Number.:'
                            )
                            foreach ($lbl in $labels) { $val = Find-LabelValueRightward -Ws $wsLsp -Label $lbl; if ($val) { break } }
                            if ($val) { $headerWs.BatchNo = $val }
                        }

                        if (-not $headerWs.CartridgeNo -or $headerWs.CartridgeNo -eq '.') {
                            $val = $null
                            $labels = @(
                                'Cartridge No. (LSP)','Cartridge No. (LSP):','Cartridge No. (LSP) :',
                                'Cartridge No (LSP)','Cartridge No (LSP):','Cartridge No (LSP) :',
                                'Cartridge Number (LSP)','Cartridge Number (LSP):','Cartridge Number (LSP) :',
                                'Cartridge No.','Cartridge No.:','Cartridge No. :','Cartridge No :',
                                'Cartridge Number','Cartridge Number:','Cartridge Number :',
                                'Cartridge No','Cartridge No:','Cartridge No :'
                            )
                            foreach ($lbl in $labels) { $val = Find-LabelValueRightward -Ws $wsLsp -Label $lbl; if ($val) { break } }

                            if (-not $val) {
                                $rxCart = [regex]::new('(?i)Cartridge.*\(LSP\)')
                                $maxCols = [Math]::Min($wsLsp.Dimension.End.Column, 100)
                                $hitCart = Find-RegexCell -Ws $wsLsp -Rx $rxCart -MaxRows 200 -MaxCols $maxCols
                                if ($hitCart) {
                                    for ($c = $hitCart.Col + 1; $c -le $wsLsp.Dimension.End.Column; $c++) {
                                        $cellVal = ($wsLsp.Cells[$hitCart.Row, $c].Text + '').Trim()
                                        if (-not $cellVal) { continue }

                                        $mCart = [regex]::Match($cellVal, '(?<![A-Za-z0-9])(\d{5})(?!\d)')
                                        if ($mCart.Success) {
                                            $val = $mCart.Groups[1].Value
                                            break
                                        }
                                    }
                                }
                            }

                            if ($val) {
                                $mCart = [regex]::Match(($val + ''), '(?<![A-Za-z0-9])(\d{5})(?!\d)')
                                if ($mCart.Success) {
                                    $headerWs.CartridgeNo = $mCart.Groups[1].Value
                                }
                            }
                        }

                        if (-not $headerWs.Effective) {
                            $val = Find-LabelValueRightward -Ws $wsLsp -Label 'Effective'
                            if (-not $val) { $val = Find-LabelValueRightward -Ws $wsLsp -Label 'Effective Date' }
                            if ($val) { $headerWs.Effective = $val }
                        }
                    }
                } catch {}

                # Ingen filnamnsfallback för Worksheet CartridgeNo.
                # Worksheet-header ska spegla faktisk header/cell-data, inte filnamn.

                # ==============================
                # QC-påminnelse – HIV/HBV/HCV-assays (läser Test Summary B3 medan $tmpPkg är öppen)
                # ==============================
                $script:QcReminderB3 = $null
                try {
                    $qcTriggerAssays = @(
                        'Xpert_HIV-1 Viral Load',
                        'Xpert HIV-1 Viral Load XC',
                        'Xpert_HCV Viral Load',
                        'Xpert HCV VL Fingerstick',
                        'Xpert HBV Viral Load',
                        'Xpert_HIV-1 Qual',
                        'HIV-1_Qual RUO',
                        'HIV-1 Qual XC DBS RUO',
                        'HIV-1 Qual XC DBS IUO',
                        'Xpert HIV-1 Qual XC PQC',
                        'Xpert HIV-1 Qual XC PQC RUO'


                    )
                    $qcValidPartNos = @(
                        'GXHIV-VL-CE-10','GXHIV-VL-IN-10','GXHIV-VL-CN-10',
                        'GXHIV-VL-XC-CE-10','GXHCV-VL-CE-10','GXHCV-VL-IN-10',
                        'GXHCV-FS-CE-10','GXHBV-VL-CE-10',
                        'GXHIV-QA-CE-10','RHIVQ-10'
                        '700-6098/HIV-1 QUAL XC, RUO','700-6137/HIV-1 QUAL XC, IUO',
                        '700-6793/ HIV-1 QUAL XC, CE-IVD','700-6911/ HIV-1 QUAL XC, RUO'
                    )

                    $qcAssayMatch = $false
                    if ($runAssay) {
                        foreach ($_qa in $qcTriggerAssays) {
                            if ($runAssay -ilike "$_qa*") { $qcAssayMatch = $true; break }
                        }
                    }

                    if ($qcAssayMatch) {
                        $tsWs = $tmpPkg.Workbook.Worksheets | Where-Object { $_.Name -ieq 'Test Summary' } | Select-Object -First 1
                        if ($tsWs) {
                            $b3Val = Get-CellText $tsWs 'B3'
                            if ($b3Val -and ($qcValidPartNos -contains $b3Val)) {
                                $script:QcReminderB3 = $b3Val
                                Gui-Log ("🔬 QC Data Påminnelse: Assay={0}, Part/Cat. No. {1} → aktiverad" -f $runAssay, $b3Val) 'Info'
                            } else {
                                Gui-Log ("ℹ️ QC Data: Assay matchar men Part/Cat. No. '{0}' ej i listan → hoppar över." -f $b3Val) 'Info'
                            }
                        } else {
                            Gui-Log "ℹ️ QC Data: Assay matchar men 'Test Summary'-blad saknas i Worksheet." 'Info'
                        }
                    }
                } catch {
                    Gui-Log ("⚠️ QC Data Påminnelse: " + $_.Exception.Message) 'Warn'
                }

            } catch {
                # Om WS öppnas men något inne fallerar: låt det inte döda hela rapporten
                Gui-Log ("⚠️ WS-fel: " + $_.Exception.Message) 'Warn'
            }
        }
    } finally {
        # Frigör WS-paketet (nollställ $script:WsPkg oavsett om det återanvändes)
        if ($tmpPkg) { try { $tmpPkg.Dispose() } catch {} }
        $script:WsPkg = $null
        $tmpPkg = $null
    }

    # SealTest-rubriker
    try { $headerNeg = Extract-SealTestHeader -Pkg $pkgNeg } catch {}
    try { $headerPos = Extract-SealTestHeader -Pkg $pkgPos } catch {}

    # Reserv för Effective i Seal POS/NEG om fält saknas
    try {
        if ($pkgPos -and $headerPos -and -not $headerPos.Effective) {
            $wsPos = $pkgPos.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' } | Select-Object -First 1
            if ($wsPos) {
                $val = Find-LabelValueRightward -Ws $wsPos -Label 'Effective'
                if (-not $val) { $val = Find-LabelValueRightward -Ws $wsPos -Label 'Effective Date' }
                if ($val) { $headerPos.Effective = $val }
            }
        }
    } catch {}

    try {
        if ($pkgNeg -and $headerNeg -and -not $headerNeg.Effective) {
            $wsNeg = $pkgNeg.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' } | Select-Object -First 1
            if ($wsNeg) {
                $val = Find-LabelValueRightward -Ws $wsNeg -Label 'Effective'
                if (-not $val) { $val = Find-LabelValueRightward -Ws $wsNeg -Label 'Effective Date' }
                if ($val) { $headerNeg.Effective = $val }
            }
        }
    } catch {}

    # --------------------------
    # Rubriksammanfattning → Information
    # --------------------------
    try {
        $wsBatch   = if ($headerWs -and $headerWs.BatchNo) { $headerWs.BatchNo } else { $null }
        $sealBatch = $batch
        if (-not $sealBatch) {
            try { if ($selPos) { $sealBatch = Get-BatchNumberFromSealFile $selPos } } catch {}
            if (-not $sealBatch) { try { if ($selNeg) { $sealBatch = Get-BatchNumberFromSealFile $selNeg } } catch {} }
        }

        $rowWsFile = Find-InfoRow -Ws $wsInfo -Label 'Worksheet'
        if (-not $rowWsFile) { $rowWsFile = 17 }
        $rowPart  = $rowWsFile + 1
        $rowBatch = $rowWsFile + 2
        $rowCart  = $rowWsFile + 3
        $rowDoc   = $rowWsFile + 4
        $rowRev   = $rowWsFile + 5
        $rowEff   = $rowWsFile + 6

        $rowPosFile = Find-InfoRow -Ws $wsInfo -Label 'Seal Test POS'
        if (-not $rowPosFile) { $rowPosFile = $rowWsFile + 7 }
        $rowPosDoc = $rowPosFile + 1
        $rowPosRev = $rowPosFile + 2
        $rowPosEff = $rowPosFile + 3

        $rowNegFile = Find-InfoRow -Ws $wsInfo -Label 'Seal Test NEG'
        if (-not $rowNegFile) { $rowNegFile = $rowPosFile + 4 }
        $rowNegDoc = $rowNegFile + 1
        $rowNegRev = $rowNegFile + 2
        $rowNegEff = $rowNegFile + 3

        if ($selLsp) {
            $wsInfo.Cells["B$rowWsFile"].Style.Numberformat.Format = '@'
            $wsInfo.Cells["B$rowWsFile"].Value = (Get-CleanLeaf $selLsp)
        } else {
            $wsInfo.Cells["B$rowWsFile"].Value = ''
        }

        $consPart  = Get-ConsensusValue -Type 'Part'      -Ws $headerWs.PartNo      -Pos $headerPos.PartNumber   -Neg $headerNeg.PartNumber
        $consBatch = Get-ConsensusValue -Type 'Batch'     -Ws $headerWs.BatchNo     -Pos $headerPos.BatchNumber  -Neg $headerNeg.BatchNumber
        $consCart  = Get-ConsensusValue -Type 'Cartridge' -Ws $headerWs.CartridgeNo -Pos $headerPos.CartridgeNo  -Neg $headerNeg.CartridgeNo
        # Ingen filnamnsfallback för Cartridge i Run Information.
        # Visat Worksheet-värde ska komma från faktisk header/cell-data.
$wsInfo.Cells["B$rowPart"].Value = if ($consPart.Value) { $consPart.Value } else { '' }
$runBatchDisplay = ''
try {
    $runBatchTokens = @(Get-BatchTokenList -Values @(
        $headerWs.BatchNo,
        $headerPos.BatchNumber,
        $headerNeg.BatchNumber,
        $batchInfo.Batch
    ))
    if ($runBatchTokens.Count -gt 0) {
        $runBatchDisplay = Join-TokenList $runBatchTokens
    }
} catch {}

if (-not $runBatchDisplay -and $consBatch.Value) {
    $runBatchDisplay = $consBatch.Value
}

$wsInfo.Cells["B$rowBatch"].Style.Numberformat.Format = '@'
$wsInfo.Cells["B$rowBatch"].Value = $runBatchDisplay
$wsInfo.Cells["B$rowCart"].Value = if ($consCart.Value) { $consCart.Value } else { '' }

        # wsHeaderCheck → skriv Match/Mismatch i C-kolumn för Part/Batch/Cartridge
        try {
            $StyleMismatchCell = {
                param($Cell, $Text)
                $Cell.Style.Numberformat.Format = '@'
                $Cell.Value = '⚠ ' + $Text
                $Cell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $Cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#FFCCCC'))
                $Cell.Style.Font.Bold = $true
                $Cell.Style.Font.Color.SetColor([System.Drawing.Color]::DarkRed)
            }

            $StyleMatchCell = {
                param($Cell)
                $Cell.Style.Numberformat.Format = '@'
                $Cell.Value = '✓ Alla flikar matchar'
                $Cell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $Cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#C6EFCE'))
                $Cell.Style.Font.Bold = $true
                $Cell.Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml('#006100'))
            }

            $devPart = $null;  $devBatch = $null;  $devCart = $null
            $missPart = $null; $missBatch = $null; $missCart = $null

            if ($wsHeaderCheck -and $wsHeaderCheck.Details) {
                $linesDev = ($wsHeaderCheck.Details -split "`r?`n")
                foreach ($ln in $linesDev) {
                    if ($ln -match '^\*Saknas\*\s*-\s*PartNo\b\s*(.*)$') {
                        $missPart = ($matches[1] + '').Trim()
                    }
                    elseif ($ln -match '^\*Saknas\*\s*-\s*BatchNo\b\s*(.*)$') {
                        $missBatch = ($matches[1] + '').Trim()
                    }
                    elseif ($ln -match '^\*Saknas\*\s*-\s*CartridgeNo\b\s*(.*)$') {
                        $missCart = ($matches[1] + '').Trim()
                    }
                    elseif ($ln -match '^-\s*PartNo[^:]*:\s*(.+)$') {
                        $devPart = $matches[1].Trim()
                    }
                    elseif ($ln -match '^-\s*BatchNo[^:]*:\s*(.+)$') {
                        $devBatch = $matches[1].Trim()
                    }
                    elseif ($ln -match '^-\s*CartridgeNo[^:]*:\s*(.+)$') {
                        $devCart = $matches[1].Trim()
                    }
                }
            }

            if ($wsHeaderCheck) {
                if ($missPart -ne $null) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowPart"]  ($(if ($missPart) { 'Header saknas: ' + $missPart } else { 'Header saknas' }))
                }
                elseif ($devPart) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowPart"]  ('Avvikande: ' + $devPart)
                }
                elseif (-not $consPart.Value) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowPart"]  'Header saknas'
                }
                else {
                    & $StyleMatchCell $wsInfo.Cells["C$rowPart"]
                }

                if ($missBatch -ne $null) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowBatch"] ($(if ($missBatch) { 'Header saknas: ' + $missBatch } else { 'Header saknas' }))
                }
                elseif ($devBatch) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowBatch"] ('Avvikande: ' + $devBatch)
                }
                elseif (-not $consBatch.Value) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowBatch"] 'Header saknas'
                }
                else {
                    & $StyleMatchCell $wsInfo.Cells["C$rowBatch"]
                }

                if ($missCart -ne $null) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowCart"]  ($(if ($missCart) { 'Header saknas: ' + $missCart } else { 'Header saknas' }))
                }
                elseif ($devCart) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowCart"]  ('Avvikande: ' + $devCart)
                }
                elseif (-not $consCart.Value) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowCart"]  'Header saknas'
                }
                else {
                    & $StyleMatchCell $wsInfo.Cells["C$rowCart"]
                }
            }
        } catch {}

        if ($headerWs) {
            $doc = $headerWs.DocumentNumber
            if ($doc) { $doc = ($doc -replace '(?i)\s+(?:Rev(?:ision)?|Effective|p\.)\b.*$', '').Trim() }
            if ($headerWs.Attachment -and ($doc -notmatch '(?i)\bAttachment\s+\w+\b')) {
                $doc = "$doc Attachment $($headerWs.Attachment)"
            }
            $wsInfo.Cells["B$rowDoc"].Value = $doc
            $wsInfo.Cells["B$rowRev"].Value = $headerWs.Rev
            $wsInfo.Cells["B$rowEff"].Value = $headerWs.Effective
            
            if ($wsHeaderCheck -and $doc) { & $StyleMatchCell $wsInfo.Cells["C$rowDoc"] }
            if ($wsHeaderCheck -and $headerWs.Rev) { & $StyleMatchCell $wsInfo.Cells["C$rowRev"] }
            if ($wsHeaderCheck -and $headerWs.Effective) { & $StyleMatchCell $wsInfo.Cells["C$rowEff"] }
        } else {
            $wsInfo.Cells["B$rowDoc"].Value = ''
            $wsInfo.Cells["B$rowRev"].Value = ''
            $wsInfo.Cells["B$rowEff"].Value = ''
        }

        if ($selPos) {
            $wsInfo.Cells["B$rowPosFile"].Style.Numberformat.Format = '@'
            $wsInfo.Cells["B$rowPosFile"].Value = (Get-CleanLeaf $selPos)
        } else { $wsInfo.Cells["B$rowPosFile"].Value = '' }

        if ($headerPos) {
            $docPos = $headerPos.DocumentNumber
            if ($docPos) { $docPos = ($docPos -replace '(?i)\s+(?:Rev(?:ision)?|Effective|p\.)\b.*$','').Trim() }
            $wsInfo.Cells["B$rowPosDoc"].Value = $docPos
            $wsInfo.Cells["B$rowPosRev"].Value = $headerPos.Rev
            $wsInfo.Cells["B$rowPosEff"].Value = if ($headerPos.EffectiveDisplay) { $headerPos.EffectiveDisplay } else { $headerPos.Effective }

            $posHeaderCheck = $null
            try { $posHeaderCheck = $headerPos.HeaderCheck } catch {}
            $devPosDoc = $null; $devPosRev = $null; $devPosEff = $null

            if ($posHeaderCheck -and $posHeaderCheck.Details) {
                $linesDev = ($posHeaderCheck.Details -split "`r?`n")
                foreach ($ln in $linesDev) {
                    if ($ln -match '^-\s*DocumentNumber[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devPosDoc = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*Rev[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devPosRev = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*Effective[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devPosEff = $matches[1].Trim() }
                }
            }

            if ($posHeaderCheck) {
                if ($docPos) {
                    if ($devPosDoc) { & $StyleMismatchCell $wsInfo.Cells["C$rowPosDoc"] ('Avvikande flikar: ' + $devPosDoc) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowPosDoc"] }
                }
                if ($headerPos.Rev) {
                    if ($devPosRev) { & $StyleMismatchCell $wsInfo.Cells["C$rowPosRev"] ('Avvikande flikar: ' + $devPosRev) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowPosRev"] }
                }
                if ($headerPos.Effective) {
                    if ($devPosEff) { & $StyleMismatchCell $wsInfo.Cells["C$rowPosEff"] ('Avvikande flikar: ' + $devPosEff) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowPosEff"] }
                }
            } else {
            }
        } else {
            $wsInfo.Cells["B$rowPosDoc"].Value = ''
            $wsInfo.Cells["B$rowPosRev"].Value = ''
            $wsInfo.Cells["B$rowPosEff"].Value = ''
        }

        if ($selNeg) {
            $wsInfo.Cells["B$rowNegFile"].Style.Numberformat.Format = '@'
            $wsInfo.Cells["B$rowNegFile"].Value = (Get-CleanLeaf $selNeg)
        } else { $wsInfo.Cells["B$rowNegFile"].Value = '' }

        if ($headerNeg) {
            $docNeg = $headerNeg.DocumentNumber
            if ($docNeg) { $docNeg = ($docNeg -replace '(?i)\s+(?:Rev(?:ision)?|Effective|p\.)\b.*$','').Trim() }
            $wsInfo.Cells["B$rowNegDoc"].Value = $docNeg
            $wsInfo.Cells["B$rowNegRev"].Value = $headerNeg.Rev
            $wsInfo.Cells["B$rowNegEff"].Value = if ($headerNeg.EffectiveDisplay) { $headerNeg.EffectiveDisplay } else { $headerNeg.Effective }
            
            $negHeaderCheck = $null
            try { $negHeaderCheck = $headerNeg.HeaderCheck } catch {}
            $devNegDoc = $null; $devNegRev = $null; $devNegEff = $null

            if ($negHeaderCheck -and $negHeaderCheck.Details) {
                $linesDev = ($negHeaderCheck.Details -split "`r?`n")
                foreach ($ln in $linesDev) {
                    if ($ln -match '^-\s*DocumentNumber[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devNegDoc = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*Rev[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devNegRev = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*Effective[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devNegEff = $matches[1].Trim() }
                }
            }

            if ($negHeaderCheck) {
                if ($docNeg) {
                    if ($devNegDoc) { & $StyleMismatchCell $wsInfo.Cells["C$rowNegDoc"] ('Avvikande flikar: ' + $devNegDoc) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowNegDoc"] }
                }
                if ($headerNeg.Rev) {
                    if ($devNegRev) { & $StyleMismatchCell $wsInfo.Cells["C$rowNegRev"] ('Avvikande flikar: ' + $devNegRev) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowNegRev"] }
                }
                if ($headerNeg.Effective) {
                    if ($devNegEff) { & $StyleMismatchCell $wsInfo.Cells["C$rowNegEff"] ('Avvikande flikar: ' + $devNegEff) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowNegEff"] }
                }
            } else {
            }
        } else {
            $wsInfo.Cells["B$rowNegDoc"].Value = ''
            $wsInfo.Cells["B$rowNegRev"].Value = ''
            $wsInfo.Cells["B$rowNegEff"].Value = ''
        }

    } catch {
        Gui-Log ("⚠️ Header summary fel: " + $_.Exception.Message) 'Warn'
    }

} catch {
    Gui-Log "⚠️ Run Information fel: $($_.Exception.Message)" 'Warn'
}

# ============================
# === Utrustningsblad      ===
# ============================
Mark-Phase 'SealTestInfo'
# OBS: Endast mall kopieras - ingen automatisk ifyllning av pipetter/instrument.
# Användaren fyller i manuellt i output-filen.
if ($Config -and $Config.Contains('EnableEquipmentSheet') -and -not $Config.EnableEquipmentSheet) {
    Gui-Log 'ℹ️ Utrustningslista avstängt. Hoppar över.' 'Info'
} else {
    try {
        if (Test-Path -LiteralPath $UtrustningListPath) {
            $srcPkg = $null
            try {
                $srcPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($UtrustningListPath))

                $srcWs = $srcPkg.Workbook.Worksheets['Sheet1']
                if (-not $srcWs) { $srcWs = $srcPkg.Workbook.Worksheets[1] }

                if ($srcWs) {
                    # Ta bort befintlig flik om den finns
                    $wsEq = $pkgOut.Workbook.Worksheets[$Layout.SheetUtrustning]
                    if ($wsEq) { $pkgOut.Workbook.Worksheets.Delete($wsEq) }

                    # Kopiera mallen som en ny flik
                    $wsEq = $pkgOut.Workbook.Worksheets.Add($Layout.SheetUtrustning, $srcWs)

                    # Ta bort formler och behåll bara värden
                    if ($wsEq.Dimension) {
                        foreach ($cell in $wsEq.Cells[$wsEq.Dimension.Address]) {
                            if ($cell.Formula -or $cell.FormulaR1C1) {
                                $val = $cell.Value
                                $cell.Formula     = $null
                                $cell.FormulaR1C1 = $null
                                $cell.Value       = $val
                            }
                        }
                        # Kopiera kolumnbredder
                        $colCount = $srcWs.Dimension.End.Column
                        for ($c = 1; $c -le $colCount; $c++) {
                            try { $wsEq.Column($c).Width = $srcWs.Column($c).Width } catch {}
                        }
                    }
                    Gui-Log "✅ Utrustningslista kopierad." 'Info' 'PROGRESS'
                }
            } finally {
                if ($srcPkg) { try { $srcPkg.Dispose() } catch {} }
            }
        } else {
            Gui-Log ("ℹ️ Utrustningslista saknas: $UtrustningListPath") 'Info'
        }
    } catch {
        Gui-Log "⚠️ Kunde inte skapa Utrustningslista-flik: $($_.Exception.Message)" 'Warn'
    }
}

# ============================
# === Kontrollmaterial     ===
# ============================
Mark-Phase 'Equipment'

try {
    if ($controlTab -and (Test-Path -LiteralPath $RawDataPath)) {
        $srcPkg = $null
        try {
            $srcPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($RawDataPath))
            try { $srcPkg.Workbook.Calculate() } catch {}

            $candidates = if ($controlTab -match '\|') {
                $controlTab -split '\|' | ForEach-Object { $_.Trim() } | Where-Object { $_ }
            } else { @($controlTab) }

            $srcWs = $null
            foreach ($cand in $candidates) {
                $srcWs = $srcPkg.Workbook.Worksheets | Where-Object { $_.Name -eq $cand } | Select-Object -First 1
                if ($srcWs) { break }
                $srcWs = $srcPkg.Workbook.Worksheets | Where-Object { $_.Name -like "*$cand*" } | Select-Object -First 1
                if ($srcWs) { break }
            }

            if ($srcWs) {
                $safeName = if ($srcWs.Name.Length -gt 31) { $srcWs.Name.Substring(0,31) } else { $srcWs.Name }
                $destName = $safeName; $n = 1
                while ($pkgOut.Workbook.Worksheets[$destName]) {
                    $base = if ($safeName.Length -gt 27) { $safeName.Substring(0,27) } else { $safeName }
                    $destName = "$base($n)"; $n++
                }

                $wsCM = $pkgOut.Workbook.Worksheets.Add($destName, $srcWs)
                if ($wsCM.Dimension) {
                    foreach ($cell in $wsCM.Cells[$wsCM.Dimension.Address]) {
                        if ($cell.Formula -or $cell.FormulaR1C1) {
                            $v = $cell.Value
                            $cell.Formula = $null
                            $cell.FormulaR1C1 = $null
                            $cell.Value = $v
                        }
                    }
                    try {
                        if (Get-Command Safe-AutoFitColumns -ErrorAction SilentlyContinue) {
                            Safe-AutoFitColumns -Ws $wsCM -Context 'ControlMaterial'
                        } else {
                            $wsCM.Cells[$wsCM.Dimension.Address].AutoFitColumns() | Out-Null
                        }
                    } catch {}
                }

                if ($srcWs.Name -ne $destName) {
                    Gui-Log "✅ Kontrollmaterial: '$($srcWs.Name)' → '$destName'" 'Info'
                if ($srcWs.Name -ne $destName) {
                    Gui-Log "✅ Kontrollmaterial: '$($srcWs.Name)' → '$destName'" 'Info'
                } else {
                    Gui-Log "✅ Kontrollmaterial: '$destName'" 'Info' 'PROGRESS'
                }
                } else {
                    Gui-Log "✅ Kontrollmaterial: '$destName'" 'Info' 'PROGRESS'
                }
            } else {
                Gui-Log "ℹ️ Hittade inget blad i kontrollfilen som matchar '$controlTab'." 'Info'
            }
        } finally {
            if ($srcPkg) { try { $srcPkg.Dispose() } catch {} }
        }
    } else {
        Gui-Log "ℹ️ Ingen Control-flik skapad (saknar mappning eller kontrollfil)." 'Info'
    }
} catch {
    Gui-Log "⚠️ Control Material-fel: $($_.Exception.Message)" 'Warn'
}

# ============================
# === SharePoint Info      ===
# ============================
try {
    $skipSpInfo = -not $global:SpEnabled

    if ($skipSpInfo) {
        Gui-Log "ℹ️ SharePoint Info avstängt i konfigurationen – hoppar över." 'Info'
        try {
            $old = $pkgOut.Workbook.Worksheets["SharePoint Info"]
            if ($old) { $pkgOut.Workbook.Worksheets.Delete($old) }
        } catch {}
    } else {

        $spOk = $false
        $spStatus = Get-SPClientStatus
        if ($spStatus.Connected) { $spOk = $true }

        if (-not $spOk) {
            # Om manuell anslutning är valt: detta är normalt tills användaren klickar "🔌 Anslut SP".
            if ($global:SpEnabled -and (-not $global:SpAutoConnect)) {
                Gui-Log "ℹ️ SharePoint ej anslutet (manuellt läge). Klicka '🔌 Anslut SP' för att hämta SharePoint-data." 'Info'
            }
            else {
                $errMsg = if ($global:SpError) { $global:SpError } else { 'Okänt fel' }
                Gui-Log ("⚠️ SharePoint ej tillgängligt: $errMsg") 'Warn'
            }
        }

$batchInfo = Get-BatchLinkInfo -SealPosPath $selPos -SealNegPath $selNeg -Lsp $lspForLinks
$batch = $batchInfo.Batch
$spOrder = $batchInfo.Order

        # Startcell för SharePoint Info-blocket i bladet 'Information' (konfigurerbart)
        $spStartCell = $null
        try { $spStartCell = Get-ConfigValue -Name 'SharePointInfoStartCell' -Default $Layout.SpInfoStartCell } catch { $spStartCell = $Layout.SpInfoStartCell }
        $spRc = Convert-A1ToRowCol -A1 $spStartCell -DefaultRow 1 -DefaultCol 5
        $spStartRow = $spRc.Row
        $spStartCol = $spRc.Col
if (-not $spOrder) {
    $orderMsg = 'Entydigt Order# saknas i Seal Test B10'
    try {
        if ($batchInfo.OrderStatus -eq 'Mismatch') {
            $orderMsg = 'Order# mismatch i aktiva Seal Test-blad: ' + (($batchInfo.OrderInfo.AllOrders | Sort-Object) -join ', ')
        }
    } catch {}
    Gui-Log ("⚠️ $orderMsg – SharePoint-post hämtas inte via Batch/LSP.") 'Warn'
    $rowsOrderWarn = @(
        [pscustomobject]@{ Rubrik = 'Status'; 'Värde' = $orderMsg },
        [pscustomobject]@{ Rubrik = 'Notering'; 'Värde' = 'SharePoint-sökning avbruten. Order# krävs som unik nyckel.' }
    )
    [void](Write-SPBlockIntoInformation -Pkg $pkgOut -Rows $rowsOrderWarn -Batch '—' -TargetSheetName $Layout.SheetRunInfo -StartRow $spStartRow -StartCol $spStartCol)

            # Säkerställ att separat flik inte finns kvar (banta rapporten)
            try {
                $old = $pkgOut.Workbook.Worksheets["SharePoint Info"]
                if ($old) { $pkgOut.Workbook.Worksheets.Delete($old) }
            } catch {}
        } else {
            Gui-Log "🔎 Order# hittad i Seal Test: $spOrder" 'Info'

            $fields = @(
                'Work_x0020_Center','Title','Batch_x0023_','SAP_x0020_Batch_x0023__x0020_2',
                'LSP','Material','BBD_x002f_SLED','Actual_x0020_startdate_x002f__x0',
                'PAL_x0020__x002d__x0020_Sample_x','Sample_x0020_Reagent_x0020_P_x00',
                'Order_x0020_quantity','Total_x0020_good','ITP_x0020_Test_x0020_results',
                'IPT_x0020__x002d__x0020_Testing_0','MES_x0020__x002d__x0020_Order_x0'
            )
            $renameMap = @{
                'Work Center'            = 'Work Center'
                'Title'                  = 'Order#'
                'Batch#'                 = 'SAP Batch#'
                'SAP Batch# 2'           = 'SAP Batch# 2'
                'LSP'                    = 'LSP'
                'Material'               = 'Material'
                'BBD/SLED'               = 'BBD/SLED'
                'Actual startdate/_x0'   = 'ROBAL - Actual start date/time'
                'PAL - Sample_x'         = 'Sample Reagent use'
                'Sample Reagent P'       = 'Sample Reagent P/N'
                'Order quantity'         = 'Order quantity'
                'Total good'             = 'ROBAL - Till Packning'
                'IPT Test results'       = 'IPT Test results'
                'IPT - Testing_0'        = 'IPT - Testing Finalized'
                'MES - Order_x0'         = 'MES Order'
            }

            $desiredOrder = @(
                'Work Center','Order#','SAP Batch#','SAP Batch# 2','LSP','Material','BBD/SLED',
                'ROBAL - Actual start date/time','Sample Reagent use','Sample Reagent P/N',
                'Order quantity','ROBAL - Till Packning','IPT Test results',
                'IPT - Testing Finalized','MES Order'
            )

            $dateFields      = @('BBD/SLED','ROBAL - Actual start date/time','IPT - Testing Finalized')
            $shortDateFields = @('BBD/SLED')

            $rows = @()
            if ($spOk) {
                try {
                    # Hela PnP-frågan + fält-extraktion körs i SPClient-runspacen
                    # (PnP ListItem-objekt kan inte serialiseras korrekt över runspace-gränser)

$spResult = Invoke-SPClient -Script {
    param($listName, $fieldNames, $orderToFind)
    try {
        function _normOrder {
            param([object]$Value)
            $s = ('' + $Value)
            $s = ($s -replace '[\u00A0\t\r\n]+', ' ')
            $s = ($s -replace '\s+', ' ').Trim()
            return $s.ToUpperInvariant()
        }
        $targetOrder = _normOrder $orderToFind
        if (-not $targetOrder) {
            return @{ Ok = $true; Found = $false; Data = @{}; Reason = 'Missing Order#' }
        }
        $items = Get-PnPListItem -List $listName -Fields $fieldNames -PageSize 2000 -ErrorAction Stop
        $matches = @(
            $items | Where-Object {
                (_normOrder $_['Title']) -eq $targetOrder
            } | Select-Object -First 2
        )
        if ($matches.Count -eq 0) {
            return @{ Ok = $true; Found = $false; Data = @{}; Reason = "No SharePoint item for Order# $targetOrder" }
        }
        if ($matches.Count -gt 1) {
            return @{ Ok = $false; Err = "Mer än en SharePoint-post matchar Order# $targetOrder. Avbryter för att undvika felträff." }
        }
        $match = $matches[0]
                            if (-not $match) {
                                return @{ Ok = $true; Found = $false; Data = @{} }
                            }

                            # Extrahera alla fält som enkel hashtable (kan serialiseras)
                            $extracted = @{}
                            foreach ($fn in $fieldNames) {
                                $val = $match[$fn]
                                if ($null -ne $val -and $val -ne '') {
                                    # Konvertera LookupValue etc. till strings
                                    if ($val -is [Microsoft.SharePoint.Client.FieldLookupValue]) {
                                        $val = $val.LookupValue
                                    }
                                    $extracted[$fn] = $val
                                }
                            }
                            return @{ Ok = $true; Found = $true; Data = $extracted }
                        } catch {
                            return @{ Ok = $false; Err = $_.Exception.ToString() }
                        }
                    } -Arguments @("Cepheid | Production orders", $fields, $spOrder)

                    if (-not $spResult -or -not $spResult.Ok) {
                        $spErrMsg = if ($spResult -and $spResult.Err) { $spResult.Err } else { 'Okänt fel' }
                        Gui-Log "⚠️ SP: Get-PnPListItem misslyckades: $spErrMsg" 'Warn'
                    }
                    elseif ($spResult.Found) {
                        foreach ($f in $fields) {
                            $val = $spResult.Data[$f]
                            if ($null -eq $val -or $val -eq '') { continue }

                            $label = $f -replace '_x0020_', ' ' `
                                         -replace '_x002d_', '-' `
                                         -replace '_x0023_', '#' `
                                         -replace '_x002f_', '/' `
                                         -replace '_x2013_', '–' `
                                         -replace '_x00',''
                            $label = $label.Trim()
                            if ($renameMap.ContainsKey($label)) { $label = $renameMap[$label] }

                            if ($val -eq $true) { $val = 'JA' }
                            elseif ($val -eq $false) { $val = 'NEJ' }
$dt = $null
if ($val -is [datetime]) { $dt = [datetime]$val }
else { try { $dt = [datetime]::Parse($val) } catch { $dt = $null } }

if ($dt -ne $null -and ($dateFields -contains $label)) {
    try {
        if ($dt.Kind -eq [System.DateTimeKind]::Utc) {
            $dt = $dt.ToLocalTime()
        }
        elseif ($dt.Kind -eq [System.DateTimeKind]::Unspecified) {
            $dt = [datetime]::SpecifyKind($dt, [System.DateTimeKind]::Utc).ToLocalTime()
        }
    } catch {}

    $fmt = if ($shortDateFields -contains $label) { 'yyyy-MM-dd' } else { 'yyyy-MM-dd HH:mm' }
    $val = $dt.ToString($fmt)
}

                            $rows += [pscustomobject]@{ Rubrik = $label; 'Värde' = $val }
                        }
if ($rows.Count -gt 0) {
    $ordered = @()
    foreach ($label in $desiredOrder) {
        $hit = $rows | Where-Object { $_.Rubrik -eq $label } | Select-Object -First 1
        if ($hit) { $ordered += $hit }
    }
    if ($ordered.Count -gt 0) { $rows = $ordered }
    try {
        $spCheck = Test-SharePointBatchLspConsistency `
            -Rows $rows `
            -HeaderWs $headerWs `
            -WorksheetHeaderRows $wsHeaderRows `
            -SealPosPath $selPos `
            -SealNegPath $selNeg `
            -SearchedLsp $lspForLinks `
            -BatchInfo $batchInfo
        if ($spCheck -and $spCheck.Status -ne 'NoRef' -and $spCheck.Message) {
            $rows += @(
                [pscustomobject]@{
                    Rubrik = 'SP Kontroll'
                    'Värde' = $(if ($spCheck.SummaryText) { $spCheck.SummaryText } else { $spCheck.Message })
                }
                [pscustomobject]@{
                    Rubrik = 'SP Order#'
                    'Värde' = $(if ($spCheck.OrderMessage) { $spCheck.OrderMessage } else { '—' })
                }
                [pscustomobject]@{
                    Rubrik = 'SP Batch#'
                    'Värde' = $(if ($spCheck.BatchMessage) { $spCheck.BatchMessage } else { '—' })
                }
                [pscustomobject]@{
                    Rubrik = 'SP LSP'
                    'Värde' = $(if ($spCheck.LspMessage) { $spCheck.LspMessage } else { '—' })
                }
            )
            if ($spCheck.Status -eq 'Mismatch') {
                Gui-Log ("⚠️ SharePoint Order/Batch/LSP mismatch: " + $spCheck.Message) 'Warn'
            }
            else {
                Gui-Log "✅ SharePoint Order/Batch/LSP matchar filer/header" 'Info'
            }
        }
    } catch {
        Gui-Log ("⚠️ SharePoint Order/Batch/LSP-kontroll misslyckades: " + $_.Exception.Message) 'Warn'
    }
    # Cache ROBAL-datum för auto-population av signeringsfält
                            $robalRow = $rows | Where-Object { $_.Rubrik -eq 'ROBAL - Actual start date/time' } | Select-Object -First 1
                            if ($robalRow -and $robalRow.'Värde') {
                                $robalVal = ($robalRow.'Värde' + '').Trim()
                                if ($robalVal -match '^\d{4}-\d{2}-\d{2}') {
                                    $script:RobalDateShort = $robalVal.Substring(0,10) -replace '-',' '
                                }
                            }
                        }

                        Gui-Log "📄 SharePoint-post hittad – skriver blad." 'Info'
} else {
    $reason = if ($spResult -and $spResult.Reason) { $spResult.Reason } else { "Ingen post i SharePoint för Order#=$spOrder" }
    Gui-Log ("ℹ️ " + $reason) 'Info'
}
                } catch {
                    Gui-Log "⚠️ SP: Invoke-SPClient misslyckades: $($_.Exception.Message)" 'Warn'
                }
            }

            [void](Write-SPBlockIntoInformation -Pkg $pkgOut -Rows $rows -Batch $batch -TargetSheetName $Layout.SheetRunInfo -StartRow $spStartRow -StartCol $spStartCol)

            try {
                $old = $pkgOut.Workbook.Worksheets["SharePoint Info"]
                if ($old) { $pkgOut.Workbook.Worksheets.Delete($old) }
            } catch {}

try {
    if ($slBatchLink -and $batchInfo -and $batchInfo.OrderStatus -eq 'Unique' -and $batchInfo.Order) {
        $slBatchLink.Text = "SharePoint: Order# $($batchInfo.Order)"
        $slBatchLink.Tag  = $batchInfo.Url
        $slBatchLink.Enabled = $true
    }
    elseif ($slBatchLink) {
        $slBatchLink.Text = 'SharePoint: —'
        $slBatchLink.Tag  = $null
        $slBatchLink.Enabled = $false
    }
} catch {}

            try {
                $wsSP = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
                if ($wsSP) {
                    $labelCol = $spStartCol
                $valueCol = $spStartCol + 1
                for ($r = ($spStartRow + 1); $r -le ($spStartRow + 120); $r++) {
                        if ((Normalize-HeaderText (($wsSP.Cells[$r,$labelCol].Text + '')).Trim()) -ieq 'Sample Reagent use') {
                            $wsSP.Cells[$r,$valueCol].Style.WrapText = $true
                            $wsSP.Cells[$r,$valueCol].Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Top
                            $wsSP.Row($r).CustomHeight = $true
                            break
                        }
                    }
                }
            } catch {
                Gui-Log "⚠️ WrapText på 'Sample Reagent use' misslyckades: $($_.Exception.Message)" 'Warn'
            }
            try {
    $wsSP = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if ($wsSP) {
        $labelCol = $spStartCol
        $valueCol = $spStartCol + 1
        for ($r = ($spStartRow + 1); $r -le ($spStartRow + 120); $r++) {
            $lbl = (Normalize-HeaderText (($wsSP.Cells[$r,$labelCol].Text + '')).Trim())
if ($lbl -in @('SP Kontroll','SP Order#','SP Batch#','SP LSP')) {
    $val = ($wsSP.Cells[$r,$valueCol].Text + '').Trim()
    # Viktigt:
    # Radhöjd gäller hela Excel-raden. Om SP-blocket sätter rad 15-18 till 30,
    # blir även vänster Dokumentkontroll-raderna 15-18 höga.
    # Därför får SP Kontroll-raderna inte tvinga upp radhöjden.
    $wsSP.Cells[$r,$labelCol].Style.WrapText = $false
    $wsSP.Cells[$r,$valueCol].Style.WrapText = $false
    $wsSP.Cells[$r,$labelCol].Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
    $wsSP.Cells[$r,$valueCol].Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
    if ($lbl -ieq 'SP Kontroll') {
                    $wsSP.Cells[$r,$labelCol].Style.Font.Bold = $true
                    $wsSP.Cells[$r,$valueCol].Style.Font.Bold = $true

                    if ($val -like '⚠*') {
                        $rngSp = $wsSP.Cells[$r,$labelCol,$r,$valueCol]
                        $rngSp.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                        $rngSp.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#FFC7CE'))
                        $rngSp.Style.Font.Color.SetColor([System.Drawing.Color]::DarkRed)
                    }
                    elseif ($val -like '✓*') {
                        $rngSp = $wsSP.Cells[$r,$labelCol,$r,$valueCol]
                        $rngSp.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                        $rngSp.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#C6EFCE'))
                        $rngSp.Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml('#006100'))
                    }
                }
                elseif ($val -like '⚠*') {
                    $rngSpWarn = $wsSP.Cells[$r,$labelCol,$r,$valueCol]
                    $rngSpWarn.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                    $rngSpWarn.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#FFF2CC'))
                    $wsSP.Cells[$r,$valueCol].Style.Font.Color.SetColor([System.Drawing.Color]::DarkRed)
                }
            }
        }
    }
} catch {
    Gui-Log "⚠️ Styling av SP Order/Batch/LSP Kontroll misslyckades: $($_.Exception.Message)" 'Warn'
}
# ============================================================
# === Run Information: fasta radhöjder vänsterpanel        ===
# ============================================================
try {
    $wsRI = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if ($wsRI) {
        # Vanliga datarader i vänsterpanelen.
        # Dessa ska vara visuellt lika höga även om högerpanelen använder samma radnummer.
        $runInfoDataRows = @(
            2,3,4,5,        # Körningsinfo
            8,9,10,11,      # Datakällor
            14,15,16,17,18,19,20,  # Worksheet / Dokumentkontroll
            21,22,23,24,    # Seal Test POS
            25,26,27,28,    # Seal Test NEG
            31,32,33,34,35,36 # Snabblänkar
        )
        foreach ($rr in $runInfoDataRows) {
            try {
                $wsRI.Row($rr).Height = 15
                $wsRI.Row($rr).CustomHeight = $true
                # Vänsterpanelens dataceller ska inte driva upp radhöjden.
                $wsRI.Cells[$rr,1,$rr,3].Style.WrapText = $false
                $wsRI.Cells[$rr,1,$rr,3].Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
            } catch {}
        }
        # Rubrik-/sektionsrader får vara lite högre men ska också vara konsekventa.
        foreach ($rr in @(1,7,13,30)) {
            try {
                $wsRI.Row($rr).Height = 22
                $wsRI.Row($rr).CustomHeight = $true
                $wsRI.Cells[$rr,1,$rr,3].Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
            } catch {}
        }
    }
} catch {
    Gui-Log "⚠️ Run Information radhöjdsjustering misslyckades: $($_.Exception.Message)" 'Warn'
}

            # ============================================================
            # === Sample Reagent Checklist-markering (additiv)         ===
            # ============================================================
            try {
                $_srhPNs = @()
                try { $_srhPNs = @(Get-ConfigValue -Name 'SampleReagentChecklistPNs' -Default @()) } catch {}

                if ($_srhPNs.Count -gt 0) {
                    $_srhWs = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
                    if ($_srhWs -and $_srhWs.Dimension) {
                        $_srhLabelCol = $spStartCol
                        $_srhValueCol = $spStartCol + 1
                        $_srhPNRow  = -1; $_srhUseRow = -1
                        $_srhPNVal  = ''; $_srhUseVal = ''

                        for ($_sr = ($spStartRow + 1); $_sr -le ($spStartRow + 120); $_sr++) {
                            $_srhLabel = (Normalize-HeaderText ($_srhWs.Cells[$_sr, $_srhLabelCol].Text + '')).Trim()
                            if ($_srhLabel -ieq 'Sample Reagent P/N') {
                                $_srhPNRow = $_sr
                                $_srhPNVal = ($_srhWs.Cells[$_sr, $_srhValueCol].Text + '').Trim()
                            }
                            if ($_srhLabel -ieq 'Sample Reagent use') {
                                $_srhUseRow = $_sr
                                $_srhUseVal = ($_srhWs.Cells[$_sr, $_srhValueCol].Text + '').Trim()
                            }
                        }

                        $_srhMatch = $false
                        if ($_srhPNVal) {
                            foreach ($_pn in $_srhPNs) {
                                if ($_srhPNVal -eq ($_pn + '').Trim()) { $_srhMatch = $true; break }
                            }
                        }

                        if ($_srhMatch) {
                            $_srhHighlightBg = [System.Drawing.Color]::FromArgb(255, 255, 200)
                            $_srhWarningBg   = [System.Drawing.Color]::FromArgb(255, 235, 156)
                            $_srhWarningFg   = [System.Drawing.Color]::FromArgb(156, 101, 0)
                            $_srhOkBg        = [System.Drawing.Color]::FromArgb(198, 239, 206)
                            $_srhOkFg        = [System.Drawing.Color]::FromArgb(0, 97, 0)

                            if ($_srhPNRow -gt 0) {
                                $_srhWs.Cells[$_srhPNRow, $_srhValueCol].Style.Fill.PatternType = 'Solid'
                                $_srhWs.Cells[$_srhPNRow, $_srhValueCol].Style.Fill.BackgroundColor.SetColor($_srhHighlightBg)
                                $_srhWs.Cells[$_srhPNRow, $_srhValueCol].Style.Font.Bold = $true
                            }

                            if ($_srhUseRow -gt 0) {
                                if ($_srhUseVal) {
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.PatternType = 'Solid'
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.BackgroundColor.SetColor($_srhOkBg)
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Color.SetColor($_srhOkFg)
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Bold = $true
                                } else {
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Value = '⚠ SAKNAS'
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.PatternType = 'Solid'
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.BackgroundColor.SetColor($_srhWarningBg)
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Color.SetColor($_srhWarningFg)
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Bold = $true
                                    Gui-Log '⚠️ Sample Reagent Saknas' 'Warn'
                                }
                            }
                        }
                    }
                }
            } catch {
                Gui-Log "⚠️ Sample Reagent highlight: $($_.Exception.Message)" 'Warn'
            }

        }
    }
} catch {
    Gui-Log "⚠️ SP-blad: $($_.Exception.Message)" 'Warn'
}

# ============================
# === QC-påminnelse (HIV/HBV/HCV) → Information E16:F18 ===
# ============================
try {
    if ($script:QcReminderB3) {
        $wsInfo = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
        if ($wsInfo) {
$eCol  = 5   # E
$fCol  = 6   # F
# Radhöjd gäller hela Excel-raden.
# Därför ska QC-påminnelsen inte placeras mitt i vänster Run Information-panel,
# eftersom den annars kan göra Dokumentkontroll-/Snabblänksrader ojämnt höga.
# Vänsterpanelen använder rad 1-36, så QC börjar tidigast på rad 38.
$qcRow = 38
try {
    if ($script:RunInfoSpBlockLastRow -and [int]$script:RunInfoSpBlockLastRow -ge ($qcRow - 1)) {
        $qcRow = [int]$script:RunInfoSpBlockLastRow + 2
    }
} catch {
    $qcRow = 38
}

            # Färger (samma som SharePoint Info-rubriken)
            $HeaderBg  = [System.Drawing.Color]::FromArgb(68, 84, 106)
            $HeaderFg  = [System.Drawing.Color]::White
            $SectionBg = [System.Drawing.Color]::FromArgb(217, 225, 242)
            $SectionFg = [System.Drawing.Color]::FromArgb(0, 32, 96)
            $BorderClr = [System.Drawing.Color]::FromArgb(68, 84, 106)

            # --- Rad 16: rubrik (sammanfogad E16:F16) ---
            $wsInfo.Cells[$qcRow, $eCol, $qcRow, $fCol].Merge = $true
            $hdrCell = $wsInfo.Cells[$qcRow, $eCol]
            $hdrCell.Value = ('QC Data – ' + $script:QcReminderB3)
            $hdrCell.Style.Font.Bold = $true
            $hdrCell.Style.Font.Size = 14
            $hdrCell.Style.Font.Name = 'Calibri'
            $hdrCell.Style.Font.Color.SetColor($HeaderFg)
            $hdrCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $hdrCell.Style.Fill.BackgroundColor.SetColor($HeaderBg)
            $hdrCell.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Left
            $hdrCell.Style.VerticalAlignment   = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
            $wsInfo.Row($qcRow).Height = 22

            # --- Rad 17: "Additional QC-Data?" / "JA" ---
            $wsInfo.Cells[($qcRow+1), $eCol].Value = 'Additional QC-Data?'
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Font.Bold = $true
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Font.Name = 'Calibri'
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Font.Size = 10
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Font.Color.SetColor($SectionFg)
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Fill.BackgroundColor.SetColor($SectionBg)

            $wsInfo.Cells[($qcRow+1), $fCol].Value = 'JA'
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Font.Bold = $true
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Font.Name = 'Calibri'
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Font.Size = 10
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(0, 128, 0))
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::White)
            $wsInfo.Cells[($qcRow+1), $fCol].Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Left

            # --- Rad 18: "Lathund QC data" med länk (sammanfogad E18:F18) ---
            $wsInfo.Cells[($qcRow+2), $eCol, ($qcRow+2), $fCol].Merge = $true
            $linkCell = $wsInfo.Cells[($qcRow+2), $eCol]

            $lathundPath = ''
            if ($Config) {
                # Primär nyckel (finns i Config.ps1 i LIVE-zippen)
                if ($Config.Contains('QcDataCheatSheetLink')) {
                    $lathundPath = $Config.QcDataCheatSheetLink
                }
                # Reservnyckel om du någon gång vill använda ett annat namn
                elseif ($Config.Contains('QcReminderLathundPath')) {
                    $lathundPath = $Config.QcReminderLathundPath
                }
            }

            $linkCell.Value = 'Lathund QC data'
            $linkCell.Style.Font.Name = 'Calibri'
            $linkCell.Style.Font.Size = 10
            $linkCell.Style.Font.UnderLine = $true
            $linkCell.Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(5, 99, 193))
            $linkCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $linkCell.Style.Fill.BackgroundColor.SetColor($SectionBg)
            # Centrera sammanfogad E18:F18 (både horisontellt och vertikalt)
            $linkCell.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center
            $linkCell.Style.VerticalAlignment   = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center

            if ($lathundPath) {
                try {
                    # Bygg stabil URI:
                    $uriText = $lathundPath
                    if ($uriText -match '^(?i)https?://') {
                        $linkCell.Hyperlink = New-Object System.Uri($uriText)
                   }
                    elseif ($uriText -match '^[A-Za-z]:\\') {
                        # ex: N:\Folder\File.docx -> file:///N:/Folder/File.docx
                        $fileUri = 'file:///' + ($uriText -replace '\\','/')
                        $fileUri = [System.Uri]::EscapeUriString($fileUri)
                        $linkCell.Hyperlink = New-Object System.Uri($fileUri)
                    }
                    elseif ($uriText -match '^\\\\') {
                        # UNC-sökväg: System.Uri hanterar \\server\share nativt och bevarar Unicode
                        $linkCell.Hyperlink = New-Object System.Uri($uriText)
                    }
                    else {
                        # Sista försök (om du ger en redan korrekt URI)
                        $linkCell.Hyperlink = New-Object System.Uri($uriText)
                    }
                 } catch {
                     Gui-Log ("⚠️ QC Data: Kunde inte skapa hyperlänk till '{0}': {1}" -f $lathundPath, $_.Exception.Message) 'Warn'
                 }
             }

            # Ramar runt hela QC-påminnelseblocket
            $rng = $wsInfo.Cells[$qcRow, $eCol, ($qcRow+2), $fCol]
            $rng.Style.Border.Top.Style    = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Left.Style   = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Right.Style  = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Top.Color.SetColor($BorderClr)
            $rng.Style.Border.Bottom.Color.SetColor($BorderClr)
            $rng.Style.Border.Left.Color.SetColor($BorderClr)
            $rng.Style.Border.Right.Color.SetColor($BorderClr)
        }
    }
} catch {
}

# ============================
# === Rubrik-vattenstämpel ===
# ============================
try {
    foreach ($ws in $pkgOut.Workbook.Worksheets) {
        try {
            $ws.HeaderFooter.OddHeader.CenteredText   = '&"Arial,Bold"&14 UNCONTROLLED'
            $ws.HeaderFooter.EvenHeader.CenteredText  = '&"Arial,Bold"&14 UNCONTROLLED'
            $ws.HeaderFooter.FirstHeader.CenteredText = '&"Arial,Bold"&14 UNCONTROLLED'
        } catch {
            Gui-Log ("⚠️ Kunde inte sätta header på blad: " + $ws.Name) 'Warn'
        }
    }
} catch {
    Gui-Log "⚠️ Fel vid vattenstämpling av rapporten." 'Warn'
}

        # ============================
        # === Flikfärger (före sparning)
        # ============================
        try {
            $wsT = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo];     if ($wsT) { $wsT.TabColor = [System.Drawing.Color]::FromArgb(255, 52, 152, 219) }
            $wsT = $pkgOut.Workbook.Worksheets[$Layout.SheetUtrustning];     if ($wsT) { $wsT.TabColor = [System.Drawing.Color]::FromArgb(255, 33, 115, 70) }
        } catch {
        Gui-Log "⚠️ Kunde inte sätta tab-färg: $($_.Exception.Message)" 'Warn'
    }

        #endregion Build: Output-flikar

        #region Build: Spara rapport och revision
        # ============================
        # === Spara & revision     ===
        # ============================

        $nowTs    = Get-Date -Format "yyyyMMdd_HHmmss"
        $baseName = "$($env:USERNAME)_output_${lsp}_$nowTs.xlsx"
        $saveDir  = $env:TEMP
        $SavePath = Join-Path $saveDir $baseName
        Gui-Log ("💾 Sparar rapport: {0}" -f $baseName) 'Info' 'USER'
        try {
            $pkgOut.Workbook.View.ActiveTab = 0
            $wsInitial = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
            if ($wsInitial) { $wsInitial.View.TabSelected = $true }

            # ============================
            # === RuleEngine felsökningsblad ==
            # ============================
            try {
                if ((Get-ConfigFlag -Name 'EnableRuleEngine' -Default $false -ConfigOverride $Config) -and
                    (Get-ConfigFlag -Name 'EnableRuleEngineDebugSheet' -Default $false -ConfigOverride $Config) -and
                    (($selCsv -and (Test-Path -LiteralPath $selCsv)) -or ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)))) {

                    if (-not $script:RuleEngineShadow -or -not $script:RuleEngineShadow.Rows -or $script:RuleEngineShadow.Rows.Count -eq 0) {

                        Gui-Log "🧠 Regelmotor: saknas vid Save → bygger nu..." 'Warn'

                        $rb2 = $script:RuleBankCache
                        if (-not $rb2) {
                            $rb2 = Load-RuleBank -RuleBankDir $Config.RuleBankDir
                            try {
                                $rb2 = Compile-RuleBank -RuleBank $rb2
                            } catch {
                                Gui-Log ("⚠️ Regelmotor: kunde inte kompilera RuleBank vid Save: " + $_.Exception.Message) 'Warn' 'DEBUG'
                            }
                        }

                        # Primär
                        $csvObjs2 = @()
                        if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
                            $csvObjs2 = $script:RuleEngineCsvObjs
                            if (-not $csvObjs2 -or $csvObjs2.Count -eq 0) {
                                if ($csvRows -and $csvRows.Count -gt 0) {
                                    $csvObjs2 = @($csvRows)
                                } else {
                                    try {
                                        $all = $script:CsvLinesPrimary
                                        if ($all -and $all.Count -gt 9) {
                                            $hdr = ConvertTo-CsvFields $all[7]
                                            $dl  = $all[9..($all.Count-1)] | Where-Object { $_ -and $_.Trim() }
                                            $del = Get-CsvDelimiter -Path $selCsv
                                            $csvObjs2 = @(ConvertFrom-Csv -InputObject ($dl -join "`n") -Delimiter $del -Header $hdr)
                                        }
                                    } catch {
                                        Gui-Log ("⚠️ Regelmotor: fallback-raw för CSV vid Save misslyckades: " + $_.Exception.Message) 'Warn' 'DEBUG'
                                        $csvObjs2 = @()
                                    }
                                }
                            }
                            if ($csvObjs2 -and $csvObjs2.Count -gt 0) {
                                $script:RuleEngineShadow = Invoke-RuleEngine -CsvObjects $csvObjs2 -RuleBank $rb2 -CsvPath $selCsv
                            }
                        }

                        # Resample-del
                        if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
                            $csvObjsR2 = $script:RuleEngineCsvObjsRes
                            if (-not $csvObjsR2 -or $csvObjsR2.Count -eq 0) {
                                if ($csvRowsRes -and $csvRowsRes.Count -gt 0) {
                                    $csvObjsR2 = @($csvRowsRes)
                                } else {
                                    try {
                                        $allR = $script:CsvLinesResample
                                        if ($allR -and $allR.Count -gt 9) {
                                            $hdrR = ConvertTo-CsvFields $allR[7]
                                            $dlR  = $allR[9..($allR.Count-1)] | Where-Object { $_ -and $_.Trim() }
                                            $delR = Get-CsvDelimiter -Path $selCsvRes
                                            $csvObjsR2 = @(ConvertFrom-Csv -InputObject ($dlR -join "`n") -Delimiter $delR -Header $hdrR)
                                        }
                                    } catch {
                                        Gui-Log ("⚠️ Regelmotor: fallback-raw för Resample-CSV vid Save misslyckades: " + $_.Exception.Message) 'Warn' 'DEBUG'
                                        $csvObjsR2 = @()
                                    }
                                }
                            }
                            if ($csvObjsR2 -and $csvObjsR2.Count -gt 0) {
                                $reR2 = Invoke-RuleEngine -CsvObjects $csvObjsR2 -RuleBank $rb2 -CsvPath $selCsvRes
                                if ($script:RuleEngineShadow -and $reR2) {
                                    # Sammanfogning (nytt objekt för PS 5.1-kompatibilitet)
                                    $script:RuleEngineShadow = [pscustomobject]@{
                                        Rows          = @($script:RuleEngineShadow.Rows) + @($reR2.Rows)
                                        Summary       = $script:RuleEngineShadow.Summary
                                        TopDeviations = @($script:RuleEngineShadow.TopDeviations) + @($reR2.TopDeviations)
                                        QC            = $script:RuleEngineShadow.QC
                                    }
                                } elseif ($reR2) {
                                    $script:RuleEngineShadow = $reR2
                                }
                            }
                        }

                        if (-not $script:RuleEngineShadow -or -not $script:RuleEngineShadow.Rows -or @($script:RuleEngineShadow.Rows).Count -eq 0) {
                            Gui-Log "⚠️ Regelmotor: kunde inte bygga vid Save (0 rader)." 'Warn'
                        }
                    }

                    if ($script:RuleEngineShadow -and $script:RuleEngineShadow.Rows -and $script:RuleEngineShadow.Rows.Count -gt 0) {
                        Gui-Log "🧠 Skriver CSV-Sammanfattning..." 'Info' 'PROGRESS'
                        $includeAll = Get-ConfigFlag -Name 'RuleEngineDebugIncludeAllRows' -Default $false -ConfigOverride $Config
                        $dsf = @()
                        if ($script:DataSummaryFindings) { $dsf = @($script:DataSummaryFindings) }
                        $stf = 0
                        if ($script:StfCount) { $stf = [int]$script:StfCount }
                        [void](Write-RuleEngineDebugSheet -Pkg $pkgOut -RuleEngineResult $script:RuleEngineShadow -IncludeAllRows $includeAll -DataSummaryFindings $dsf -StfCount $stf)

                        # --- Skriv använda INF/GX i QC Summary (under befintlig data) ---
                        try {
                            $wsQcs = $pkgOut.Workbook.Worksheets[$Layout.SheetQcSummary]
                            if ($wsQcs) {
                                $usedSystems = [ordered]@{}
                                if ($csvStats -and $csvStats.InstrumentByType) {
                                    foreach ($k in $csvStats.InstrumentByType.Keys) {
                                        if ($k -and $k -ne 'Unknown') { $usedSystems[$k] = $true }
                                    }
                                }
                                if ($csvStatsRes -and $csvStatsRes.InstrumentByType) {
                                    foreach ($k in $csvStatsRes.InstrumentByType.Keys) {
                                        if ($k -and $k -ne 'Unknown') { $usedSystems[$k] = $true }
                                    }
                                }
                                $names = @($usedSystems.Keys | Sort-Object)
                                if ($names.Count -gt 0) {
                                    # Hitta sista använda raden
                                    $lastRow = 3
                                    if ($wsQcs.Dimension) {
                                        for ($ri = $wsQcs.Dimension.End.Row; $ri -ge 1; $ri--) {
                                            $cv = ($wsQcs.Cells[$ri, 1].Text + '').Trim()
                                            if ($cv) { $lastRow = $ri; break }
                                        }
                                    }
                                    $hdrRow = $lastRow + 2  # 2 raders mellanrum

                                    # Rubrik (kolumn A, spänner antal system)
                                    $wsQcs.Cells[$hdrRow, 1].Value = 'Använda INF/GX'
                                    $wsQcs.Cells[$hdrRow, 1].Style.Font.Bold = $true
                                    $wsQcs.Cells[$hdrRow, 1].Style.Font.Size = 10
                                    $hdrRng = $wsQcs.Cells[$hdrRow, 1, $hdrRow, $names.Count]
                                    $hdrRng.Merge = $true
                                    $hdrRng.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                    $hdrRng.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::FromArgb(217, 225, 242))
                                    $hdrRng.Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(0, 32, 96))
                                    $hdrRng.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center

                                    $calMap = $script:CalDueMap
                                    for ($ci = 0; $ci -lt $names.Count; $ci++) {
                                        $col = 1 + $ci
                                        $sysName = $names[$ci]

                                        # Systemnamn
                                        $cName = $wsQcs.Cells[($hdrRow + 1), $col]
                                        $cName.Value = $sysName
                                        $cName.Style.Font.Bold = $true
                                        $cName.Style.Font.Size = 9
                                        $cName.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center
                                        $cName.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                        $cName.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::FromArgb(242, 242, 242))

                                        # Cal Due Date
                                        $cCal = $wsQcs.Cells[($hdrRow + 2), $col]
                                        $calVal = ''
                                        if ($calMap -and $calMap.ContainsKey($sysName)) { $calVal = $calMap[$sysName] }
                                        $cCal.Value = $calVal
                                        $cCal.Style.Font.Size = 9
                                        $cCal.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center
                                        $cCal.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                        $cCal.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::FromArgb(198, 239, 206))

                                        try { $wsQcs.Column($col).AutoFit() } catch {}
                                        try { $wsQcs.Column($col).Width = [Math]::Max($wsQcs.Column($col).Width, 14) } catch {}
                                    }
                                }
                            }
                        } catch {
                            Gui-Log ("⚠️ QC Summary INF/GX fel: " + $_.Exception.Message) 'Warn'
                        }

                        # Visa vilken CSV som klassades som primär/resample direkt i CSV Sammanfattning (rad 2)
                        try {
                            $wsDbg = $pkgOut.Workbook.Worksheets['CSV Sammanfattning']
                            if ($wsDbg) {
                                $pPath = if ($selCsvOrig) { $selCsvOrig } elseif ($selCsv) { $selCsv } else { '' }
                                $rPath = if ($selCsvResOrig) { $selCsvResOrig } elseif ($selCsvRes) { $selCsvRes } else { '' }
                                $pLeaf = Get-CleanLeaf $pPath
                                $rLeaf = Get-CleanLeaf $rPath
                                $lbl = if ($pLeaf -and $rLeaf) {
                                    "CSV: {0} | RES CSV: {1}" -f $pLeaf, $rLeaf
                                } elseif ($pLeaf) {
                                    "CSV: {0}" -f $pLeaf
                                } elseif ($rLeaf) {
                                    "Resample CSV: {0}" -f $rLeaf
                                } else { '' }
                                if ($lbl) {
                                    $rng = $wsDbg.Cells[2, 1, 2, 8]
                                    $rng.Merge = $true
                                    $rng.Style.Numberformat.Format = '@'
                                    $rng.Style.Font.Italic = $true
                                    $wsDbg.Cells[2, 1].Value = $lbl
                                }
                            }
                        } catch {
                            Gui-Log ("⚠️ Kunde inte märka CSV-Sammanfattning med vald CSV/Resample: " + $_.Exception.Message) 'Warn' 'DEBUG'
                        }
                    } else {
                        Gui-Log "⚠️ Kunde inte skriva CSV-Sammanfattning." 'Warn'
                    }
                }
            } catch {
                Gui-Log ("⚠️ Kunde inte skriva CSV-Sammanfattning: " + $_.Exception.Message) 'Warn'
            }
try {
    $wsRunInfoFinal = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if ($wsRunInfoFinal -and $script:RunInfoTemplateColumnWidths -and $script:RunInfoTemplateColumnWidths.Count -gt 0) {
        Restore-RunInformationColumnWidths -Ws $wsRunInfoFinal -Widths $script:RunInfoTemplateColumnWidths
    }
} catch {}
Set-UiStep 90 'Sparar rapport…'
Mark-Phase 'RunInfo'
# UX: Om rapportfilen redan finns och är öppen (Excel), be användaren stänga innan SaveAs
            try {
                if ($SavePath -and (Test-Path -LiteralPath $SavePath)) {
                    if (-not (Ensure-FilesClosedOrCancel -Paths @($SavePath) -Hint 'Stäng rapporten i Excel (eller stäng Preview i Explorer) och klicka Försök igen.')) {
                        Gui-Log "🛑 Avbrutet: output-filen är låst/öppen." 'Warn'
                        return
                    }
                }
            } catch {
                Gui-Log ("⚠️ Fil-låskontroll för output misslyckades: " + $_.Exception.Message) 'Warn' 'DEBUG'
            }
            try {
                $pkgOut.SaveAs($SavePath)
            } catch {
                $auditStatusText = 'Error'
                $saveErr = $_.Exception.Message
                if ($saveErr -match 'being used by another process|access.*denied|permission') {
                    Gui-Log ("❌ Kunde inte spara: filen är låst av ett annat program. Stäng Excel/Preview och försök igen.") 'Error'
                } else {
                    Gui-Log ("❌ Kunde inte spara rapporten: $saveErr") 'Error'
                }
                return
            }
            Mark-Phase 'Save'
            $buildTimer.Stop()
            $totalMs = $buildTimer.ElapsedMilliseconds
            $doneMsg = 'Klar ✅  ({0:N1}s)' -f ($totalMs / 1000)
            Set-UiStep 100 $doneMsg
            Gui-Log -Text ("Rapport sparad: {0} ({1:N1}s)" -f $SavePath, ($totalMs / 1000)) -Severity Info -Category RESULT
# Signeringssammanfattning
# Logga endast det som faktiskt skrevs och read-back-verifierades i denna körning.
$signParts = @()
if ($negSealSignatureAppliedThisRun -and $posSealSignatureAppliedThisRun) {
    $signParts += "Seal Test: NEG+POS"
} elseif ($negSealSignatureAppliedThisRun) {
    $signParts += "Seal Test: NEG"
} elseif ($posSealSignatureAppliedThisRun) {
    $signParts += "Seal Test: POS"
}
if ($wsSammSignatureVerifiedThisRun) {
    $signParts += "WS Sammanst."
}
if ($wsGranskSignatureVerifiedThisRun) {
    $signParts += "WS Granskning"
}
if ($signParts.Count -gt 0) {
    Gui-Log ("🔏 Verifierad signering: " + ($signParts -join ', ')) 'Info'
}
            $global:LastReportPath = $SavePath
            try { $form.Text = "IPTCompile – $ScriptVersion — $(Split-Path $SavePath -Leaf)" } catch {}
            try {
                $auditDir = Join-Path $ScriptRootPath 'audit'
                if (-not (Test-Path -LiteralPath $auditDir)) { New-Item -ItemType Directory -Path $auditDir -Force | Out-Null }

            # Fasdetaljerad tidsmätning (ms)
            $phaseJson = ''
            try { $phaseJson = ($phaseTimings | ConvertTo-Json -Compress) } 
            catch { $phaseJson = '' }


                $auditObj = [pscustomobject]@{
                    DatumTid        = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
                    Användare       = $env:USERNAME
                    LSP             = $lsp
                    ValdCSV         = if ($selCsv -or $selCsvRes) { (@($(if($selCsv){Get-CleanLeaf $selCsv}), $(if($selCsvRes){'(Res) '+(Get-CleanLeaf $selCsvRes)})) | Where-Object {$_}) -join ' + ' } else { '' }
                    ValdSealNEG     = Get-CleanLeaf $selNeg
                    ValdSealPOS     = Get-CleanLeaf $selPos
                    Assay           = $runAssay
                    AntalTester     = $(try { if ($csvStats) { 
                    [int]$csvStats.TestCount } else { 0 } } catch { 0 })
                    SignaturSkriven = if ($doSealTest) { 'Ja (verifierad)' } else { 'Nej' }
                    WsSammSkriven   = if ($doWsSamm) { 'Ja (verifierad)' } else { 'Nej' }
                    WsGranskSkriven = if ($doWsGransk) { 'Ja (verifierad)' } else { 'Nej' }
                    SigMismatch     = if ($sigMismatch) { 'Ja' } else { 'Nej' }
                    MismatchSheets  = if ($mismatchSheets -and $mismatchSheets.Count -gt 0) { ($mismatchSheets -join ';') } else { '' }
                    ViolationsNEG   = $violationsNeg.Count
                    ViolationsPOS   = $violationsPos.Count
                    Violations      = ($violationsNeg.Count + $violationsPos.Count)
                    TotalTid_ms     = $totalMs
                    TotalTid_s      = [math]::Round($totalMs / 1000, 1)
                    FasTider_json   = $phaseJson
                    Sparläge        = 'Temporärt'
                    OutputFile      = $SavePath
                    Kommentar       = 'UNCONTROLLED rapport, ingen källfil ändrades automatiskt.'
                    ScriptVersion   = $ScriptVersion
                }

                $auditFile = Join-Path $auditDir ("$($env:USERNAME)_audit_${nowTs}.csv")
                $auditObj | Export-Csv -Path $auditFile -NoTypeInformation -Encoding UTF8

                try {
                    $statusText = 'OK'
                    if (($violationsNeg.Count + $violationsPos.Count) -gt 0 -or $sigMismatch -or ($mismatchSheets -and $mismatchSheets.Count -gt 0)) {
                        $statusText = 'Warnings'
                    }
                    $auditStatusText = $statusText
                    $auditTests = $null
                    try {
                        if ($csvStats) { $auditTests = [int]$csvStats.TestCount }
                        if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) { $auditTests = ($auditTests + 0) + [int]$csvStatsRes.TestCount }
                    } catch {}
                    Add-AuditEntry -Lsp $lsp -Assay $runAssay -BatchNumber $batch -TestCount $auditTests -Status $statusText -ReportPath $SavePath -TotalMs $totalMs -PhaseJson $phaseJson
                    $auditWritten = $true
                } catch {
                    Gui-Log "⚠️ Kunde inte skriva audit-CSV: $($_.Exception.Message)" 'Warn'
                }
            } catch {
                Gui-Log "⚠️ Kunde inte skriva revisionsfil: $($_.Exception.Message)" 'Warn'
            }

            # ---- Sessionsspårning + tidsbesparningsuppskattning ----
            try {
                $script:SessionStats.ReportCount++
                $script:SessionStats.TotalBuildMs += $totalMs
                $buildTests = 0
                try { if ($csvStats) { $buildTests = [int]$csvStats.TestCount } } catch {}
                try { if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) { $buildTests += [int]$csvStatsRes.TestCount } } catch {}
                $script:SessionStats.TotalTestsBuilt += $buildTests

                # Uppskattad manuell tid: ~20 min per rapport (konservativt)
                $manualMinEstimate = 10
                $savedMin = $manualMinEstimate - [math]::Round($totalMs / 60000, 1)
                if ($savedMin -lt 5) { $savedMin = 5 }
                $sessionSavedMin = [math]::Round($script:SessionStats.ReportCount * $manualMinEstimate - $script:SessionStats.TotalBuildMs / 60000, 0)
                if ($sessionSavedMin -lt $script:SessionStats.ReportCount) { $sessionSavedMin = $script:SessionStats.ReportCount * 5 }

                Gui-Log ("   Uppskattad tidsbesparning: ~{0} min (manuellt ~{1} min, IPTCompile {2:N1}s)" -f [int]$savedMin, $manualMinEstimate, ($totalMs / 1000)) 'Info' 'RESULT'

                # Uppdatera statusfältets sessionsindikator
                $sessText = if ($script:SessionStats.ReportCount -eq 1) {
                    "1 rapport | ~{0} min sparad" -f [int]$savedMin
                } else {
                    "{0} rapporter | ~{1} min sparade" -f $script:SessionStats.ReportCount, [int]$sessionSavedMin
                }
                $script:slSession.Text = $sessText
                $script:slSession.Visible = $true
            } catch {}

            # Kort visuell blink på Build-knappen
            $origBack = $btnBuild.BackColor
            try {
                $btnBuild.BackColor = [System.Drawing.Color]::FromArgb(46, 125, 50)
                $btnBuild.Refresh()
                Start-Sleep -Milliseconds 600
                $btnBuild.BackColor = $origBack
                $btnBuild.Refresh()
            } catch { try { $btnBuild.BackColor = $origBack } catch {} }

            try { Start-Process -FilePath $SavePath } catch {

            # Kort ljud-notis vid klar rapport
            try { [System.Media.SystemSounds]::Exclamation.Play() } catch {}
                Gui-Log "ℹ️ Rapporten sparades men kunde inte öppnas automatiskt: $($_.Exception.Message)" 'Info' 'USER'
            }
        }
        catch {
            $auditStatusText = 'Error'
            Gui-Log "❌ Kunde inte spara rapporten: $($_.Exception.Message)" 'Error'
        }

    } finally {
        # Stoppa elapsed-timer
        try { if ($script:buildElapsedTimer) { $script:buildElapsedTimer.Stop(); $script:buildElapsedTimer.Dispose(); $script:buildElapsedTimer = $null } } catch {}
        try {
            if ($buildTimer -and $buildTimer.IsRunning) { $buildTimer.Stop() }
        } catch {}
        if (($totalMs -le 0) -and $buildTimer) {
            try { $totalMs = [int]$buildTimer.ElapsedMilliseconds } catch { $totalMs = 0 }
        }
        if (-not $phaseJson) {
            try { $phaseJson = ($phaseTimings | ConvertTo-Json -Compress) } catch { $phaseJson = '' }
        }
        if (-not $auditWritten) {
            try {
                $auditTests = $null
                if ($csvStats) { $auditTests = [int]$csvStats.TestCount }
                if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) { $auditTests = ($auditTests + 0) + [int]$csvStatsRes.TestCount }
                Add-AuditEntry -Lsp $lsp -Assay $runAssay -BatchNumber $batch -TestCount $auditTests -Status $auditStatusText -ReportPath $SavePath -TotalMs $totalMs -PhaseJson $phaseJson
                $auditWritten = $true
            } catch {
                Gui-Log "⚠️ Kunde inte skriva fallback-audit: $($_.Exception.Message)" 'Warn'
            }
        }
        try { if ($pkgNeg) { $pkgNeg.Dispose() } } catch {}
        try { if ($pkgPos) { $pkgPos.Dispose() } } catch {}
        try { if ($pkgOut) { $pkgOut.Dispose() } } catch {}
        try { if ($script:WsPkg) { $script:WsPkg.Dispose(); $script:WsPkg = $null } } catch {}
        try {
            if ($stageDir -and (Test-Path -LiteralPath $stageDir)) {
                # Säkerhet: radera bara om den ligger under TEMP-root
                $root = Get-ConfigValue -Name 'TempSnapshotRoot' -Default 'C:\IPTCompile_TEMP' -ConfigOverride $Config
                if (-not $root) { $root = 'C:\IPTCompile_TEMP' }
                $stageFull = (Resolve-Path -LiteralPath $stageDir -ErrorAction SilentlyContinue).Path
                $rootFull  = (Resolve-Path -LiteralPath $root -ErrorAction SilentlyContinue).Path
                if ($stageFull -and $rootFull -and $stageFull.StartsWith($rootFull, [System.StringComparison]::OrdinalIgnoreCase)) {
                    Remove-Item -LiteralPath $stageDir -Recurse -Force -ErrorAction SilentlyContinue
                }
            }
        } catch {}
        Set-UiBusy -Busy $false
        $script:BuildInProgress = $false
    }
    #endregion Build: Spara rapport och revision
    #endregion Build: Rapportgenerering (huvudloop)
})

#endregion Händelsehanterare (meny, knappar, tema, scan, build)
