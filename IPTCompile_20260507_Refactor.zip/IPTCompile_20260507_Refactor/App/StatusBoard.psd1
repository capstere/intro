﻿@{
    LastUpdated = '2026-05-07'

    Notes = @(
        'Upptäcker du något som är knas eller kan bli bättre?'
        'Skriv på teams eller skicka meddelande under "Instruktioner → Hjälp"'
	'Det är dina idéer och behov som formar verktyget. :) / Jesper'

    )

    Done = @(
        'N/A'
    )

    Ongoing = @(
        'N/A'
    )

    TBD = @(
        'Fixa - 0. Pilot Testing HIV VL'
        'QC Visual RES'
    )

}