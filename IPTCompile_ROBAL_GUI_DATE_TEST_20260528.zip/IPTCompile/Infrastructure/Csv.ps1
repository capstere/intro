﻿
function Get-CsvDelimiter { param([string]$Path)
    try {
        $lines = @(Get-Content -LiteralPath $Path -Encoding Default -TotalCount 30 | Where-Object { $_ -and $_.Trim() })
        if (-not $lines -or $lines.Count -eq 0) { return ';' }

        $maxSemi = 0
        $maxComma = 0
        foreach ($ln in $lines) {
            $sc = ([regex]::Matches(($ln + ''), ';')).Count
            $cc = ([regex]::Matches(($ln + ''), ',')).Count
            if ($sc -gt $maxSemi) { $maxSemi = $sc }
            if ($cc -gt $maxComma) { $maxComma = $cc }
        }

        if ($maxComma -gt $maxSemi -and $maxComma -ge 2) { return ',' } else { return ';' }
    } catch {
        Gui-Log "⚠️ Get-CsvDelimiter misslyckades: $($_.Exception.Message)" 'Warn'
        return ';'
    }
}

function ConvertTo-CsvFields {
    param(
        [Parameter(Mandatory=$true)][string]$Line,
        [string]$Delimiter
    )
    if ($null -eq $Line) { return @() }

    $del = $Delimiter
    if ([string]::IsNullOrWhiteSpace($del)) {
        # Legacy auto-detect. Supports normal ';' / ',' CSV and the new "all data in column A" layout
        # where Excel Text-to-Columns must use Tab + Comma.
        $cTab   = ([regex]::Matches($Line, "`t")).Count
        $cSemi  = ([regex]::Matches($Line, ';')).Count
        $cComma = ([regex]::Matches($Line, ',')).Count
        if ($cTab -gt 0) {
            $del = '__TAB_COMMA__'
        } elseif ($cSemi -ge $cComma -and $cSemi -gt 0) {
            $del = ';'
        } elseif ($cComma -gt 0) {
            $del = ','
        } else {
            $del = ';'
        }
    }

    if ($del -eq '__TAB_COMMA__' -or $del -eq 'TabComma' -or $del -eq "`t,") {
        # Motsvarar Excel: Text to Columns -> Delimited -> Tab + Comma.
        $rx = '[,\t](?=(?:(?:[^\"]*\"){2})*[^\"]*$)'
        $arr = [regex]::Split($Line, $rx)
        return ,@($arr | ForEach-Object { (($_ + '') -replace '^"|"$','').Trim() })
    }

    $d  = [regex]::Escape($del)
    $rx = $d + '(?=(?:(?:[^\"]*\"){2})*[^\"]*$)'
    $arr = [regex]::Split($Line, $rx)
    return ,@($arr | ForEach-Object { (($_ + '') -replace '^"|"$','').Trim() })
}

function Find-CsvHeaderIndex {
    param(
        [string[]]$Headers,
        [string[]]$Names,
        [int]$Default = -1
    )
    if (-not $Headers) { return $Default }
    for ($i = 0; $i -lt $Headers.Count; $i++) {
        $h = (($Headers[$i] + '') -replace '[\uFEFF\u200B]','').Trim().Trim('"').ToLowerInvariant()
        foreach ($n in $Names) {
            $nn = (($n + '')).ToLowerInvariant()
            if ($h -eq $nn -or $h -like "*$nn*") { return $i }
        }
    }
    return $Default
}

function Get-CsvImportProfile {
    param(
        [string]$Path,
        [string[]]$Lines
    )

    $linesLocal = @($Lines)
    if ($linesLocal.Count -eq 1 -and -not $linesLocal[0]) { $linesLocal = @() }
    if ($linesLocal.Count -eq 0 -and $Path -and (Test-Path -LiteralPath $Path)) {
        try { $linesLocal = @(Get-Content -LiteralPath $Path -Encoding Default -TotalCount 40) } catch { $linesLocal = @() }
    }

    $legacyDelim = ';'
    try {
        if ($Path -and (Test-Path -LiteralPath $Path)) { $legacyDelim = Get-CsvDelimiter -Path $Path }
        elseif ($linesLocal.Count -gt 0) {
            $first = @($linesLocal | Where-Object { $_ -and $_.Trim() } | Select-Object -First 1)
            if ($first.Count -gt 0) {
                $sc = ($first[0] -split ';').Count
                $cc = ($first[0] -split ',').Count
                if ($cc -gt $sc -and $cc -ge 2) { $legacyDelim = ',' }
            }
        }
    } catch { $legacyDelim = ';' }

    $hasTab = $false
    $maxCheck = [Math]::Min($linesLocal.Count, 20)
    for ($i=0; $i -lt $maxCheck; $i++) {
        if (($linesLocal[$i] + '').Contains("`t")) { $hasTab = $true; break }
    }

    $legacyRow11Count = 0
    $tabCommaRow11Count = 0
    if ($linesLocal.Count -ge 11) {
        try { $legacyRow11Count = @(ConvertTo-CsvFields -Line $linesLocal[10] -Delimiter $legacyDelim).Count } catch { $legacyRow11Count = 0 }
        try { $tabCommaRow11Count = @(ConvertTo-CsvFields -Line $linesLocal[10] -Delimiter '__TAB_COMMA__').Count } catch { $tabCommaRow11Count = 0 }
    }

    $legacyHeaderIndex = -1
    $tabCommaHeaderIndex = -1
    for ($i=0; $i -lt $maxCheck; $i++) {
        $ln = $linesLocal[$i]
        if (-not $ln -or -not $ln.Trim()) { continue }
        try {
            $fLegacy = @(ConvertTo-CsvFields -Line $ln -Delimiter $legacyDelim)
            $hasSample = $false; $hasInstrument = $false; $hasCartridge = $false
            foreach ($f in $fLegacy) {
                $s = (($f + '') -replace '[\uFEFF\u200B]','').Trim().ToLowerInvariant()
                if ($s -match '^sample\s*id$' -or $s -eq 'sampleid') { $hasSample = $true }
                if ($s -match 'instrument') { $hasInstrument = $true }
                if ($s -match 'cartridge') { $hasCartridge = $true }
            }
            if ($legacyHeaderIndex -lt 0 -and $hasSample -and ($hasInstrument -or $hasCartridge -or $fLegacy.Count -ge 5)) { $legacyHeaderIndex = $i }
        } catch {}
        try {
            $fTc = @(ConvertTo-CsvFields -Line $ln -Delimiter '__TAB_COMMA__')
            $hasSample = $false; $hasInstrument = $false; $hasCartridge = $false
            foreach ($f in $fTc) {
                $s = (($f + '') -replace '[\uFEFF\u200B]','').Trim().ToLowerInvariant()
                if ($s -match '^sample\s*id$' -or $s -eq 'sampleid') { $hasSample = $true }
                if ($s -match 'instrument') { $hasInstrument = $true }
                if ($s -match 'cartridge') { $hasCartridge = $true }
            }
            if ($tabCommaHeaderIndex -lt 0 -and $hasSample -and ($hasInstrument -or $hasCartridge -or $fTc.Count -ge 5)) { $tabCommaHeaderIndex = $i }
        } catch {}
    }

    $isPackedA = $false
    if ($hasTab -and $tabCommaRow11Count -ge 3 -and $tabCommaRow11Count -gt $legacyRow11Count) { $isPackedA = $true }
    if ($hasTab -and $tabCommaHeaderIndex -ge 0 -and ($legacyHeaderIndex -lt 0 -or $tabCommaRow11Count -gt $legacyRow11Count)) { $isPackedA = $true }

    if ($isPackedA) {
        $hdrIdx = if ($tabCommaHeaderIndex -ge 0) { $tabCommaHeaderIndex } else { 9 }
        return [pscustomobject]@{
            Mode        = 'PackedA_TabComma_Row11'
            Delimiter   = '__TAB_COMMA__'
            StartRow    = 11
            StartIndex  = 10
            HeaderRow   = ($hdrIdx + 1)
            HeaderIndex = $hdrIdx
        }
    }

    $hdrIdx2 = if ($legacyHeaderIndex -ge 0) { $legacyHeaderIndex } else { 7 }
    return [pscustomobject]@{
        Mode        = 'Legacy_Row10'
        Delimiter   = $legacyDelim
        StartRow    = 10
        StartIndex  = 9
        HeaderRow   = ($hdrIdx2 + 1)
        HeaderIndex = $hdrIdx2
    }
}

function Get-CsvHeaderFields {
    param(
        [string]$Path,
        [string[]]$Lines
    )
    $linesLocal = @($Lines)
    if ($linesLocal.Count -eq 1 -and -not $linesLocal[0]) { $linesLocal = @() }
    if ($linesLocal.Count -eq 0 -and $Path -and (Test-Path -LiteralPath $Path)) {
        try { $linesLocal = @(Get-Content -LiteralPath $Path -Encoding Default -TotalCount 40) } catch { $linesLocal = @() }
    }
    if (-not $linesLocal -or $linesLocal.Count -eq 0) { return @() }
    $profile = Get-CsvImportProfile -Path $Path -Lines $linesLocal
    if ($profile.HeaderIndex -lt 0 -or $profile.HeaderIndex -ge $linesLocal.Count) { return @() }
    return ,@(ConvertTo-CsvFields -Line $linesLocal[$profile.HeaderIndex] -Delimiter $profile.Delimiter)
}



function Test-IsResampleCsv {
    <# Returnerar $true om CSV:n innehåller _RES_ i Sample ID-kolumnen (>= MinHits träffar). #>
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$MinHits = 3
    )

    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    $threshold = [Math]::Max(1, [int]$MinHits)

    try {
        $lines = @(Get-Content -LiteralPath $Path -Encoding Default -TotalCount 80 -ErrorAction Stop)
        if (-not $lines -or $lines.Count -lt 1) { return $false }
        $profile = Get-CsvImportProfile -Path $Path -Lines $lines
        if ($lines.Count -le $profile.StartIndex) { return $false }

        $hdr = Get-CsvHeaderFields -Path $Path -Lines $lines
        $sampleIdIdx = Find-CsvHeaderIndex -Headers $hdr -Names @('Sample ID','SampleID','Sample Id') -Default 2

        $resCount = 0
        for ($r = $profile.StartIndex; $r -lt $lines.Count; $r++) {
            $line = $lines[$r]
            if (-not $line -or $line.Trim().Length -eq 0) { continue }

            $fields = $null
            try { $fields = ConvertTo-CsvFields -Line $line -Delimiter $profile.Delimiter } catch { $fields = $null }
            if (-not $fields -or $fields.Count -le $sampleIdIdx) { continue }

            $sid = ($fields[$sampleIdIdx] + '')
            if ($sid -imatch '_RES_') { $resCount++ }
        }

        return ($resCount -ge $threshold)
    } catch {
        try {
            Gui-Log ("⚠️ Test-IsResampleCsv misslyckades för '{0}': {1}" -f (Split-Path $Path -Leaf), $_.Exception.Message) 'Warn' 'DEBUG'
        } catch {}
        return $false
    }
}

function Resolve-CsvPrimaryAndResample {
    <# Klassificerar 0-2 CSV-filer till Primary + ev. Resample med samma regel som i buildflödet. #>
    param([string[]]$CsvPaths)

    $result = [pscustomobject]@{
        Ok             = $true
        PrimaryCsv     = $null
        ResampleCsv    = $null
        HasResample    = $false
        ErrorMessage   = $null
        WarningMessage = $null
    }

    $paths = @($CsvPaths | Where-Object { $_ -and (($_ + '').Trim().Length -gt 0) })

    if ($paths.Count -eq 0) { return $result }

    if ($paths.Count -eq 1) {
        if (Test-IsResampleCsv -Path $paths[0]) {
            $result.Ok = $false
            $result.ResampleCsv = $paths[0]
            $result.ErrorMessage = '❌ Enbart Resampling-CSV vald. Välj även Primary CSV innan rapport kan skapas.'
            return $result
        }
        $result.PrimaryCsv = $paths[0]
        return $result
    }

    if ($paths.Count -eq 2) {
        $isRes0 = Test-IsResampleCsv -Path $paths[0]
        $isRes1 = Test-IsResampleCsv -Path $paths[1]

        if ($isRes0 -and -not $isRes1) {
            $result.ResampleCsv = $paths[0]
            $result.PrimaryCsv = $paths[1]
        } elseif ($isRes1 -and -not $isRes0) {
            $result.PrimaryCsv = $paths[0]
            $result.ResampleCsv = $paths[1]
        } elseif (-not $isRes0 -and -not $isRes1) {
            $result.Ok = $false
            $result.ErrorMessage = '❌ Du har valt 2 CSV-filer men ingen Resampling CSV-fil. Avmarkera en fil eller välj korrekt Resampling CSV-fil.'
            return $result
        } else {
            $result.PrimaryCsv = $paths[0]
            $result.ResampleCsv = $paths[1]
            $result.WarningMessage = '⚠️ Båda CSV har _RES_ i Sample ID – autoväljer Resampling + Original.'
        }

        $result.HasResample = [bool]$result.ResampleCsv
        return $result
    }

    $result.Ok = $false
    $result.ErrorMessage = ("❌ Du har valt {0} CSV-filer. Välj max 2 (Primary + ev. Resample)." -f $paths.Count)
    return $result
}


function Get-AssayFromCsv { param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    try {
        $lines = @(Get-Content -LiteralPath $Path -Encoding Default)
        if (-not $lines -or $lines.Count -lt 1) { return $null }
        $profile = Get-CsvImportProfile -Path $Path -Lines $lines
        $startIndex = if ($StartRow -eq 10) { [int]$profile.StartIndex } else { [Math]::Max(0, [int]$StartRow - 1) }
        if ($lines.Count -le $startIndex) { return $null }
        for ($i = $startIndex; $i -lt $lines.Count; $i++) {
            $ln = $lines[$i]
            if (-not $ln -or $ln.Trim().Length -eq 0) { continue }
            $f = ConvertTo-CsvFields -Line $ln -Delimiter $profile.Delimiter
            if (-not $f -or $f.Length -lt 1) { continue }
            $a = ([string]$f[0]).Trim()
            if ($a -and $a -notmatch '^(?i)\s*assay\s*$') { return $a }
        }
    } catch {
        Gui-Log "⚠️ Kunde inte läsa Assay från CSV: $($_.Exception.Message)" 'Warn'
    }
    return $null
}


function Import-CsvRows { param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    $list  = New-Object System.Collections.Generic.List[object]
    try {
        $lines = @(Get-Content -LiteralPath $Path -Encoding Default)
        if (-not $lines -or $lines.Count -lt 1) { return @() }
        $profile = Get-CsvImportProfile -Path $Path -Lines $lines
        $startIndex = if ($StartRow -eq 10) { [int]$profile.StartIndex } else { [Math]::Max(0, [int]$StartRow - 1) }
        if ($lines.Count -le $startIndex) { return @() }
        try {
            if ($profile.Mode -ne 'Legacy_Row10') {
                Gui-Log ("ℹ️ CSV-layout upptäckt: {0}. Läser data från rad {1}." -f $profile.Mode, $profile.StartRow) 'Info' 'DEBUG'
            }
        } catch {}
        for ($i = $startIndex; $i -lt $lines.Count; $i++) {
            $ln = $lines[$i]
            if (-not $ln -or $ln.Trim().Length -eq 0) { continue }
            $f = ConvertTo-CsvFields -Line $ln -Delimiter $profile.Delimiter
            if (-not $f -or ($f -join '').Trim().Length -eq 0) { continue }
            [void]$list.Add($f)
        }
    } catch {
        Gui-Log "⚠️ Kunde inte läsa rader från CSV: $($_.Exception.Message)" 'Warn'
    }
    return @($list.ToArray())
}


function Get-CsvStats {
    param(
        [string]$Path,
        [string[]]$Lines
    )
    $out = [ordered]@{
        TestCount       = 0
        DupCount        = 0
        Duplicates      = @()
        LspValues       = @()
        LspOK           = $null
        InstrumentByType= [ordered]@{}
    }
    $lines = @($Lines)
    if ($lines.Count -eq 1 -and -not $lines[0]) { $lines = @() }
    if ($lines.Count -eq 0) {
        if (-not (Test-Path -LiteralPath $Path)) { return [pscustomobject]$out }
        try { $lines = @(Get-Content -LiteralPath $Path -Encoding Default) } catch { Gui-Log "⚠️ Kunde inte läsa CSV-statistik: $($_.Exception.Message)" 'Warn'; return [pscustomobject]$out }
    }
    if ($lines.Count -lt 1) { return [pscustomobject]$out }

    $profile = Get-CsvImportProfile -Path $Path -Lines $lines
    $header = Get-CsvHeaderFields -Path $Path -Lines $lines
    $idxCart = Find-CsvHeaderIndex -Headers $header -Names @('Cartridge S/N','Cartridge SN','Cartridge') -Default 3
    $idxLsp  = Find-CsvHeaderIndex -Headers $header -Names @('Reagent Lot ID','Reagent Lot','Lot ID') -Default 4
    $idxIns  = Find-CsvHeaderIndex -Headers $header -Names @('Instrument S/N','Instrument SN','Instrument') -Default 6

    $cartSnList = New-Object System.Collections.Generic.List[string]
    $lspList    = New-Object System.Collections.Generic.List[string]
    $instrList  = New-Object System.Collections.Generic.List[string]

    for ($i = $profile.StartIndex; $i -lt $lines.Count; $i++) {
        $ln = $lines[$i]
        if (-not $ln -or -not $ln.Trim()) { continue }
        $f = $null
        try { $f = ConvertTo-CsvFields -Line $ln -Delimiter $profile.Delimiter } catch { $f = $null }
        if (-not $f -or $f.Count -lt 1) { continue }
        if ($f.Count -gt $idxCart) { $cartSnList.Add( (($f[$idxCart] + '').Trim()) ) }
        if ($f.Count -gt $idxLsp)  { $lspList.Add(    (($f[$idxLsp]  + '').Trim()) ) }
        if ($f.Count -gt $idxIns)  { $instrList.Add(  (($f[$idxIns]  + '').Trim()) ) }
    }

    $cartSn = $cartSnList | Where-Object { $_ -and $_ -ne '' }
    $out.TestCount = @($cartSn).Count
    $dups = $cartSn | Group-Object | Where-Object { $_.Count -gt 1 }
    if ($dups) {
        # @() gör det robust när endast 1 grupp returneras (annars tolkas .Count som gruppens storlek)
        $out.DupCount   = @($dups).Count
        $out.Duplicates = @($dups) | ForEach-Object { "$($_.Name) x$($_.Count)" }
    }
    $lspClean = $lspList | ForEach-Object {
        $m = [regex]::Match($_, '(?<!\d)(\d{5})(?!\d)')
        if ($m.Success) { $m.Groups[1].Value } else { $null }
    } | Where-Object { $_ } | Select-Object -Unique
    $out.LspValues = @($lspClean)
    if (@($lspClean).Count -gt 0) {
        $out.LspOK = (@($lspClean).Count -eq 1)
    }
    $lut = @{}
    foreach ($k in $script:GXINF_Map.Keys) {
        $codes = $script:GXINF_Map[$k].Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ }
        foreach ($code in $codes) { $lut[$code] = $k }
    }
    foreach ($ins in ($instrList | Where-Object { $_ })) {
        $t = $null
        if ($lut.ContainsKey($ins)) { $t = $lut[$ins] } else { $t = 'Unknown' }
        if (-not $out.InstrumentByType.Contains($t)) { $out.InstrumentByType[$t] = 0 }
        $out.InstrumentByType[$t] = [int]$out.InstrumentByType[$t] + 1
    }
    return [pscustomobject]$out
}


function Import-CsvRowsStreaming {
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$StartRow = 10,
        [Parameter(Mandatory)][scriptblock]$ProcessRow
    )
    $profile = Get-CsvImportProfile -Path $Path
    $startRowEffective = if ($StartRow -eq 10) { [int]$profile.StartRow } else { [int]$StartRow }
    $sr = $null
    try {
        try {
            if ($profile.Mode -ne 'Legacy_Row10') {
                Gui-Log ("ℹ️ CSV-layout upptäckt: {0}. Läser data från rad {1}." -f $profile.Mode, $profile.StartRow) 'Info' 'DEBUG'
            }
        } catch {}
        $sr = [System.IO.StreamReader]::new($Path, [System.Text.Encoding]::UTF8, $true)
        $r = 0
        while (($line = $sr.ReadLine()) -ne $null) {
            $r++
            if ($r -lt $startRowEffective) { continue }
            if (-not $line -or $line.Trim().Length -eq 0) { continue }
            $fields = ConvertTo-CsvFields -Line $line -Delimiter $profile.Delimiter
            if ($fields -and (($fields -join '').Trim().Length -gt 0)) {
                & $ProcessRow -Fields $fields -RowIndex $r
            }
        }
    } finally {
        try { if ($sr) { $sr.Close() } } catch {}
        try { if ($sr) { $sr.Dispose() } } catch {}
    }
}

