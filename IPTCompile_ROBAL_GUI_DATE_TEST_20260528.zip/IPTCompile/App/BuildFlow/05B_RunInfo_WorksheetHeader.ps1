﻿# ----------------------------------------------------------------
# WS (LSP-blad): hitta fil och skriv in i Information-bladet
# ----------------------------------------------------------------
try {
    if (-not $selLsp) {
        $probeDir = $null
        if ($selPos) { $probeDir = Split-Path -Parent $selPos }
        if (-not $probeDir -and $selNeg) { $probeDir = Split-Path -Parent $selNeg }

        if ($probeDir -and (Test-Path -LiteralPath $probeDir)) {
            $cand = Get-ChildItem -LiteralPath $probeDir -File -ErrorAction SilentlyContinue |
                    Where-Object {
                        ($_.Name -match '(?i)worksheet') -and
                        ($_.Name -match [regex]::Escape($lsp)) -and
                        ($_.Extension -match '^\.(xlsx|xlsm|xls)$')
                    } |
                    Sort-Object LastWriteTime -Descending |
                    Select-Object -First 1

            if ($cand) { $selLsp = $cand.FullName }
        }
    }

    if ($selLsp -and (Test-Path -LiteralPath $selLsp)) {
        $wsLeaf = Get-CleanLeaf $selLsp
        Gui-Log ("🔎 Worksheet: " + $wsLeaf) 'Info'
    } else {
        Gui-Log "ℹ️ Ingen WS-fil vald/hittad (LSP Worksheet). Hoppar över WS-extraktion." 'Info'
    }
} catch {
    Gui-Log ("⚠️ WS-block fel: " + $_.Exception.Message) 'Warn'
}

try {
    # Se till att dessa alltid finns (de används senare)
    $headerWs  = $null
    $headerNeg = $null
    $headerPos = $null
    # OBS: $eqInfo används senare vid Equipment-blad → initiera här
    if (-not (Get-Variable -Name eqInfo -Scope 1 -ErrorAction SilentlyContinue)) {
        $eqInfo = $null
    }

    # --- Återanvänd WS-paketet från Data Summary-skanning om möjligt ---
    $tmpPkg = $null
    $tmpPkgReused = $false
    try {
        if ($selLsp -and (Test-Path -LiteralPath $selLsp)) {
            try {
                if ($script:WsPkg -and $script:WsPkg.File -and
                    $script:WsPkg.File.FullName -ieq (Resolve-Path -LiteralPath $selLsp -ErrorAction SilentlyContinue).Path) {
                    $tmpPkg = $script:WsPkg
                    $tmpPkgReused = $true
                } else {
                    # Sökväg ändrades (borde inte hända), öppna ny
                    if ($script:WsPkg) { try { $script:WsPkg.Dispose() } catch {} }
                    $script:WsPkg = $null
                    $tmpPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selLsp))
                }

                # ==============================
                # Utrustning / TestSummary
                # ==============================
                try {
                    # "EquipmentSheet" ska endast generera själva BLADET/mallen.
                    # Det ska *inte* automatiskt hämta pipetter/instrument från Test Summary/CSV här,
                    # annars blir det en blandning (automatiskt + manuellt) som förvirrar användaren.
                    if ($Config -and $Config.Contains('EnableEquipmentSheet') -and -not $Config.EnableEquipmentSheet) {
                        $eqInfo = $null
                        Gui-Log 'ℹ️ Utrustningslista avstängt. Hoppar över.' 'Info'
                    } else {
                        $eqInfo = $null
                        Gui-Log '✅ Utrustningslista hämtad.' 'Info' 'PROGRESS'
                    }
                } catch {
                    # Utrustning ska aldrig få stoppa rapporten
                    try { Gui-Log ("⚠️ Utrustningslista: kunde inte hämtas: " + $_.Exception.Message) 'Warn' } catch {}
                    $eqInfo = $null
                }

                # ==============================
                # Bladrubrik (extrahera + jämför)
                # ==============================
                try {
                    $headerWs = Extract-WorksheetHeader -Pkg $tmpPkg
                } catch {
                    $headerWs = $null
                }

                # Reservväg om extrahering gav null: skapa tomt objekt så .PartNo osv inte kraschar
                if (-not $headerWs) {
                    $headerWs = [pscustomobject]@{
                        WorksheetName   = ''
                        PartNo          = ''
                        BatchNo         = ''
                        CartridgeNo     = ''
                        DocumentNumber  = ''
                        Rev             = ''
                        Effective       = ''
                        Attachment      = ''
                    }
                }

                # StrictMode-säker: används senare även om jämförelsen misslyckas
                $wsHeaderCheck = $null
try {
    # QC Data ska bara ingå i headerkontrollen när Additional QC Data faktiskt förväntas.
    # Samma grundlogik som QC-påminnelsen: assay + Test Summary!B3.
    $qcDataHeaderExpected = $false
    $qcDataHeaderB3       = $null
    $qcDataSheetExists    = $false
    try {
        $qcDataSheetExists = @(
            $tmpPkg.Workbook.Worksheets |
            Where-Object { ($_.Name + '') -match '(?i)^\s*QC\s+Data(?:\s+Sheet)?\s*$' }
        ).Count -gt 0
        $qcTriggerAssays = @(
            'Xpert_HIV-1 Viral Load',
            'Xpert HIV-1 Viral Load XC',
            'Xpert_HCV Viral Load',
            'Xpert HCV VL Fingerstick',
            'Xpert HBV Viral Load',
            'Xpert_HIV-1 Qual',
            'HIV-1_Qual RUO',
            'HIV-1 Qual XC DBS RUO',
            'HIV-1 Qual XC DBS IUO',
            'Xpert HIV-1 Qual XC PQC',
            'Xpert HIV-1 Qual XC PQC RUO'
        )
        $qcValidPartNos = @(
            'GXHIV-VL-CE-10',
            'GXHIV-VL-IN-10',
            'GXHIV-VL-CN-10',
            'GXHIV-VL-XC-CE-10',
            'GXHCV-VL-CE-10',
            'GXHCV-VL-IN-10',
            'GXHCV-FS-CE-10',
            'GXHBV-VL-CE-10',
            'GXHIV-QA-CE-10',
            'RHIVQ-10',
            '700-6098/HIV-1 QUAL XC, RUO',
            '700-6137/HIV-1 QUAL XC, IUO',
            '700-6793/ HIV-1 QUAL XC, CE-IVD',
            '700-6911/ HIV-1 QUAL XC, RUO'
        )

        $qcAssayMatch = $false
        if ($runAssay) {
            foreach ($_qa in $qcTriggerAssays) {
                if ($runAssay -ilike "$_qa*") {
                    $qcAssayMatch = $true
                    break
                }
            }
        }
        if ($qcAssayMatch) {
            $tsWs = $tmpPkg.Workbook.Worksheets |
                Where-Object { $_.Name -ieq 'Test Summary' } |
                Select-Object -First 1
            if ($tsWs) {
                $qcDataHeaderB3 = Get-CellText $tsWs 'B3'
                if ($qcDataHeaderB3 -and ($qcValidPartNos -contains $qcDataHeaderB3)) {
                    $qcDataHeaderExpected = $true
                }
            }
        }
    } catch {
        try { Gui-Log ("⚠️ QC Data header-gate: " + $_.Exception.Message) 'Warn' } catch {}
    }

    $wsHeaderRows  = Get-WorksheetHeaderPerSheet -Pkg $tmpPkg -IncludeQcData:$qcDataHeaderExpected
    $wsHeaderCheck = Compare-WorksheetHeaderSet   -Rows $wsHeaderRows

    try {
        if ($qcDataHeaderExpected) {
            if ($qcDataSheetExists) {
                $qcDataChecked = @(
            $wsHeaderRows |
                    Where-Object { ($_.Sheet + '') -match '(?i)^\s*QC\s+Data(?:\s+Sheet)?\s*$' }
                ).Count -gt 0

                if ($qcDataChecked) {
                    Gui-Log ("✅ Worksheet header-kontroll inkluderar QC Data ({0})" -f $qcDataHeaderB3) 'Info'
                }
                else {
                    Gui-Log ("⚠️ Additional QC Data förväntas ({0}), men QC Data ingick inte i headerkontrollen" -f $qcDataHeaderB3) 'Warn'
                }
            }
            else {
                Gui-Log ("⚠️ Additional QC Data förväntas ({0}), men QC Data-flik saknas i Worksheet" -f $qcDataHeaderB3) 'Warn'
            }
        }
        elseif ($qcDataSheetExists) {
            Gui-Log "ℹ️ QC Data-flik finns, men Additional QC Data förväntas inte enligt Test Summary B3. QC Data exkluderas från headerkontroll." 'Info'
        }
    } catch {}
    try {
        if ($wsHeaderCheck.Issues -gt 0 -and $wsHeaderCheck.Summary) {
            Gui-Log ("⚠️ Worksheet header-avvikelser: {0} – se Run Information!" -f $wsHeaderCheck.Summary) 'Warn'
        } else {
            Gui-Log "✅ Worksheet header korrekt" 'Info' 'PROGRESS'
        }
    } catch {}
} catch {
    try { Gui-Log ("⚠️ Worksheet header-jämförelse: " + $_.Exception.Message) 'Warn' } catch {}
}

                # ==============================
                # Förstärk headerWs via etiketter (om extrahering missade)
                # ==============================
                try {
            $wsLsp = $tmpPkg.Workbook.Worksheets | Where-Object {
                $_.Name -ne 'Worksheet Instructions' -and
                $_.Name -notmatch '(?i)^\s*QC\s+Data(?:\s+Sheet)?\s*$'
                    } | Select-Object -First 1
                    if (-not $wsLsp) {
                        $wsLsp = $tmpPkg.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' } | Select-Object -First 1
                    }
                    if ($wsLsp) {

                        if (-not $headerWs.PartNo) {
                            $val = $null
                            $labels = @('Part No.','Part No.:','Part No','Part Number','Part Number:','Part Number.','Part Number.:')
                            foreach ($lbl in $labels) { $val = Find-LabelValueRightward -Ws $wsLsp -Label $lbl; if ($val) { break } }
                            if ($val) { $headerWs.PartNo = $val }
                        }

                        if (-not $headerWs.BatchNo) {
                            $val = $null
                            $labels = @(
                                'Batch No(s)','Batch No(s).','Batch No(s):','Batch No(s).:',
                                'Batch No','Batch No.','Batch No:','Batch No.:',
                                'Batch Number','Batch Number.','Batch Number:','Batch Number.:'
                            )
                            foreach ($lbl in $labels) { $val = Find-LabelValueRightward -Ws $wsLsp -Label $lbl; if ($val) { break } }
                            if ($val) { $headerWs.BatchNo = $val }
                        }

                        if (-not $headerWs.CartridgeNo -or $headerWs.CartridgeNo -eq '.') {
                            $val = $null
                            $labels = @(
                                'Cartridge No. (LSP)','Cartridge No. (LSP):','Cartridge No. (LSP) :',
                                'Cartridge No (LSP)','Cartridge No (LSP):','Cartridge No (LSP) :',
                                'Cartridge Number (LSP)','Cartridge Number (LSP):','Cartridge Number (LSP) :',
                                'Cartridge No.','Cartridge No.:','Cartridge No. :','Cartridge No :',
                                'Cartridge Number','Cartridge Number:','Cartridge Number :',
                                'Cartridge No','Cartridge No:','Cartridge No :'
                            )
                            foreach ($lbl in $labels) { $val = Find-LabelValueRightward -Ws $wsLsp -Label $lbl; if ($val) { break } }

                            if (-not $val) {
                                $rxCart = [regex]::new('(?i)Cartridge.*\(LSP\)')
                                $maxCols = [Math]::Min($wsLsp.Dimension.End.Column, 100)
                                $hitCart = Find-RegexCell -Ws $wsLsp -Rx $rxCart -MaxRows 200 -MaxCols $maxCols
                                if ($hitCart) {
                                    for ($c = $hitCart.Col + 1; $c -le $wsLsp.Dimension.End.Column; $c++) {
                                        $cellVal = ($wsLsp.Cells[$hitCart.Row, $c].Text + '').Trim()
                                        if (-not $cellVal) { continue }

                                        $mCart = [regex]::Match($cellVal, '(?<![A-Za-z0-9])(\d{5})(?!\d)')
                                        if ($mCart.Success) {
                                            $val = $mCart.Groups[1].Value
                                            break
                                        }
                                    }
                                }
                            }

                            if ($val) {
                                $mCart = [regex]::Match(($val + ''), '(?<![A-Za-z0-9])(\d{5})(?!\d)')
                                if ($mCart.Success) {
                                    $headerWs.CartridgeNo = $mCart.Groups[1].Value
                                }
                            }
                        }

                        if (-not $headerWs.Effective) {
                            $val = Find-LabelValueRightward -Ws $wsLsp -Label 'Effective'
                            if (-not $val) { $val = Find-LabelValueRightward -Ws $wsLsp -Label 'Effective Date' }
                            if ($val) { $headerWs.Effective = $val }
                        }
                    }
                } catch {}

                # Ingen filnamnsfallback för Worksheet CartridgeNo.
                # Worksheet-header ska spegla faktisk header/cell-data, inte filnamn.

                # ==============================
                # QC-påminnelse – HIV/HBV/HCV-assays (läser Test Summary B3 medan $tmpPkg är öppen)
                # ==============================
                $script:QcReminderB3 = $null
                try {
                    $qcTriggerAssays = @(
                        'Xpert_HIV-1 Viral Load',
                        'Xpert HIV-1 Viral Load XC',
                        'Xpert_HCV Viral Load',
                        'Xpert HCV VL Fingerstick',
                        'Xpert HBV Viral Load',
                        'Xpert_HIV-1 Qual',
                        'HIV-1_Qual RUO',
                        'HIV-1 Qual XC DBS RUO',
                        'HIV-1 Qual XC DBS IUO',
                        'Xpert HIV-1 Qual XC PQC',
                        'Xpert HIV-1 Qual XC PQC RUO'


                    )
                    $qcValidPartNos = @(
                        'GXHIV-VL-CE-10','GXHIV-VL-IN-10','GXHIV-VL-CN-10',
                        'GXHIV-VL-XC-CE-10','GXHCV-VL-CE-10','GXHCV-VL-IN-10',
                        'GXHCV-FS-CE-10','GXHBV-VL-CE-10',
                        'GXHIV-QA-CE-10','RHIVQ-10'
                        '700-6098/HIV-1 QUAL XC, RUO','700-6137/HIV-1 QUAL XC, IUO',
                        '700-6793/ HIV-1 QUAL XC, CE-IVD','700-6911/ HIV-1 QUAL XC, RUO'
                    )

                    $qcAssayMatch = $false
                    if ($runAssay) {
                        foreach ($_qa in $qcTriggerAssays) {
                            if ($runAssay -ilike "$_qa*") { $qcAssayMatch = $true; break }
                        }
                    }

                    if ($qcAssayMatch) {
                        $tsWs = $tmpPkg.Workbook.Worksheets | Where-Object { $_.Name -ieq 'Test Summary' } | Select-Object -First 1
                        if ($tsWs) {
                            $b3Val = Get-CellText $tsWs 'B3'
                            if ($b3Val -and ($qcValidPartNos -contains $b3Val)) {
                                $script:QcReminderB3 = $b3Val
                                Gui-Log ("🔬 QC Data Påminnelse: Assay={0}, Part/Cat. No. {1} → aktiverad" -f $runAssay, $b3Val) 'Info'
                            } else {
                                Gui-Log ("ℹ️ QC Data: Assay matchar men Part/Cat. No. '{0}' ej i listan → hoppar över." -f $b3Val) 'Info'
                            }
                        } else {
                            Gui-Log "ℹ️ QC Data: Assay matchar men 'Test Summary'-blad saknas i Worksheet." 'Info'
                        }
                    }
                } catch {
                    Gui-Log ("⚠️ QC Data Påminnelse: " + $_.Exception.Message) 'Warn'
                }

            } catch {
                # Om WS öppnas men något inne fallerar: låt det inte döda hela rapporten
                Gui-Log ("⚠️ WS-fel: " + $_.Exception.Message) 'Warn'
            }
        }
    } finally {
        # Frigör WS-paketet (nollställ $script:WsPkg oavsett om det återanvändes)
        if ($tmpPkg) { try { $tmpPkg.Dispose() } catch {} }
        $script:WsPkg = $null
        $tmpPkg = $null
    }

    # SealTest-rubriker
    $sealMergedMode = $false
    try { $sealMergedMode = Test-SealTestMergedMode } catch { $sealMergedMode = $false }
    try { if (-not $sealMergedMode) { $headerNeg = Extract-SealTestHeader -Pkg $pkgNeg } } catch {}
    try { $headerPos = Extract-SealTestHeader -Pkg $pkgPos } catch {}

    # Reserv för Effective i Seal POS/NEG om fält saknas
    try {
        if ($pkgPos -and $headerPos -and -not $headerPos.Effective) {
            $wsPos = $pkgPos.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' } | Select-Object -First 1
            if ($wsPos) {
                $val = Find-LabelValueRightward -Ws $wsPos -Label 'Effective'
                if (-not $val) { $val = Find-LabelValueRightward -Ws $wsPos -Label 'Effective Date' }
                if ($val) { $headerPos.Effective = $val }
            }
        }
    } catch {}

    try {
        if ($pkgNeg -and $headerNeg -and -not $headerNeg.Effective) {
            $wsNeg = $pkgNeg.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' } | Select-Object -First 1
            if ($wsNeg) {
                $val = Find-LabelValueRightward -Ws $wsNeg -Label 'Effective'
                if (-not $val) { $val = Find-LabelValueRightward -Ws $wsNeg -Label 'Effective Date' }
                if ($val) { $headerNeg.Effective = $val }
            }
        }
    } catch {}

    # --------------------------
    # Rubriksammanfattning → Information
    # --------------------------
    try {
        $wsBatch   = if ($headerWs -and $headerWs.BatchNo) { $headerWs.BatchNo } else { $null }
        $sealBatch = $batch
        if (-not $sealBatch) {
            try { if ($selPos) { $sealBatch = Get-BatchNumberFromSealFile $selPos } } catch {}
            if (-not $sealBatch) { try { if ($selNeg) { $sealBatch = Get-BatchNumberFromSealFile $selNeg } } catch {} }
        }

        $rowWsFile = Find-InfoRow -Ws $wsInfo -Label 'Worksheet'
        if (-not $rowWsFile) { $rowWsFile = 17 }
        $rowPart  = $rowWsFile + 1
        $rowBatch = $rowWsFile + 2
        $rowCart  = $rowWsFile + 3
        $rowDoc   = $rowWsFile + 4
        $rowRev   = $rowWsFile + 5
        $rowEff   = $rowWsFile + 6

        $rowPosFile = Find-InfoRow -Ws $wsInfo -Label 'Seal Test POS'
        if (-not $rowPosFile) { $rowPosFile = $rowWsFile + 7 }
        $rowPosDoc = $rowPosFile + 1
        $rowPosRev = $rowPosFile + 2
        $rowPosEff = $rowPosFile + 3

        $rowNegFile = Find-InfoRow -Ws $wsInfo -Label 'Seal Test NEG'
        if (-not $rowNegFile) { $rowNegFile = $rowPosFile + 4 }
        $rowNegDoc = $rowNegFile + 1
        $rowNegRev = $rowNegFile + 2
        $rowNegEff = $rowNegFile + 3

        if ($sealMergedMode) {
            try { $wsInfo.Cells["A$rowPosFile"].Value = 'Seal Test-fil (Merged)' } catch {}
            try { $wsInfo.Cells["A$rowNegFile"].Value = 'Seal Test NEG (ej använd)' } catch {}
        }

        if ($selLsp) {
            $wsInfo.Cells["B$rowWsFile"].Style.Numberformat.Format = '@'
            $wsInfo.Cells["B$rowWsFile"].Value = (Get-CleanLeaf $selLsp)
        } else {
            $wsInfo.Cells["B$rowWsFile"].Value = ''
        }

        $negPartForConsensus  = if ($sealMergedMode) { $null } else { $headerNeg.PartNumber }
        $negBatchForConsensus = if ($sealMergedMode) { $null } else { $headerNeg.BatchNumber }
        $negCartForConsensus  = if ($sealMergedMode) { $null } else { $headerNeg.CartridgeNo }
        $consPart  = Get-ConsensusValue -Type 'Part'      -Ws $headerWs.PartNo      -Pos $headerPos.PartNumber   -Neg $negPartForConsensus
        $consBatch = Get-ConsensusValue -Type 'Batch'     -Ws $headerWs.BatchNo     -Pos $headerPos.BatchNumber  -Neg $negBatchForConsensus
        $consCart  = Get-ConsensusValue -Type 'Cartridge' -Ws $headerWs.CartridgeNo -Pos $headerPos.CartridgeNo  -Neg $negCartForConsensus
        # Ingen filnamnsfallback för Cartridge i Run Information.
        # Visat Worksheet-värde ska komma från faktisk header/cell-data.
$wsInfo.Cells["B$rowPart"].Value = if ($consPart.Value) { $consPart.Value } else { '' }
$runBatchDisplay = ''
try {
    $runBatchTokens = @(Get-BatchTokenList -Values @(
        $headerWs.BatchNo,
        $headerPos.BatchNumber,
        $(if($sealMergedMode){$null}else{$headerNeg.BatchNumber}),
        $batchInfo.Batch
    ))
    if ($runBatchTokens.Count -gt 0) {
        $runBatchDisplay = Join-TokenList $runBatchTokens
    }
} catch {}

if (-not $runBatchDisplay -and $consBatch.Value) {
    $runBatchDisplay = $consBatch.Value
}

$wsInfo.Cells["B$rowBatch"].Style.Numberformat.Format = '@'
$wsInfo.Cells["B$rowBatch"].Value = $runBatchDisplay
$wsInfo.Cells["B$rowCart"].Value = if ($consCart.Value) { $consCart.Value } else { '' }

        # wsHeaderCheck → skriv Match/Mismatch i C-kolumn för Part/Batch/Cartridge
        try {
            $StyleMismatchCell = {
                param($Cell, $Text)
                $Cell.Style.Numberformat.Format = '@'
                $Cell.Value = '⚠ ' + $Text
                $Cell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $Cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#FFCCCC'))
                $Cell.Style.Font.Bold = $true
                $Cell.Style.Font.Color.SetColor([System.Drawing.Color]::DarkRed)
            }

            $StyleMatchCell = {
                param($Cell)
                $Cell.Style.Numberformat.Format = '@'
                $Cell.Value = '✓ Alla flikar matchar'
                $Cell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $Cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#C6EFCE'))
                $Cell.Style.Font.Bold = $true
                $Cell.Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml('#006100'))
            }

            $devPart = $null;  $devBatch = $null;  $devCart = $null
            $missPart = $null; $missBatch = $null; $missCart = $null

            if ($wsHeaderCheck -and $wsHeaderCheck.Details) {
                $linesDev = ($wsHeaderCheck.Details -split "`r?`n")
                foreach ($ln in $linesDev) {
                    if ($ln -match '^\*Saknas\*\s*-\s*PartNo\b\s*(.*)$') {
                        $missPart = ($matches[1] + '').Trim()
                    }
                    elseif ($ln -match '^\*Saknas\*\s*-\s*BatchNo\b\s*(.*)$') {
                        $missBatch = ($matches[1] + '').Trim()
                    }
                    elseif ($ln -match '^\*Saknas\*\s*-\s*CartridgeNo\b\s*(.*)$') {
                        $missCart = ($matches[1] + '').Trim()
                    }
                    elseif ($ln -match '^-\s*PartNo[^:]*:\s*(.+)$') {
                        $devPart = $matches[1].Trim()
                    }
                    elseif ($ln -match '^-\s*BatchNo[^:]*:\s*(.+)$') {
                        $devBatch = $matches[1].Trim()
                    }
                    elseif ($ln -match '^-\s*CartridgeNo[^:]*:\s*(.+)$') {
                        $devCart = $matches[1].Trim()
                    }
                }
            }

            if ($wsHeaderCheck) {
                if ($missPart -ne $null) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowPart"]  ($(if ($missPart) { 'Header saknas: ' + $missPart } else { 'Header saknas' }))
                }
                elseif ($devPart) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowPart"]  ('Avvikande: ' + $devPart)
                }
                elseif (-not $consPart.Value) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowPart"]  'Header saknas'
                }
                else {
                    & $StyleMatchCell $wsInfo.Cells["C$rowPart"]
                }

                if ($missBatch -ne $null) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowBatch"] ($(if ($missBatch) { 'Header saknas: ' + $missBatch } else { 'Header saknas' }))
                }
                elseif ($devBatch) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowBatch"] ('Avvikande: ' + $devBatch)
                }
                elseif (-not $consBatch.Value) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowBatch"] 'Header saknas'
                }
                else {
                    & $StyleMatchCell $wsInfo.Cells["C$rowBatch"]
                }

                if ($missCart -ne $null) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowCart"]  ($(if ($missCart) { 'Header saknas: ' + $missCart } else { 'Header saknas' }))
                }
                elseif ($devCart) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowCart"]  ('Avvikande: ' + $devCart)
                }
                elseif (-not $consCart.Value) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowCart"]  'Header saknas'
                }
                else {
                    & $StyleMatchCell $wsInfo.Cells["C$rowCart"]
                }
            }
        } catch {}

        if ($headerWs) {
            $doc = $headerWs.DocumentNumber
            if ($doc) { $doc = ($doc -replace '(?i)\s+(?:Rev(?:ision)?|Effective|p\.)\b.*$', '').Trim() }
            if ($headerWs.Attachment -and ($doc -notmatch '(?i)\bAttachment\s+\w+\b')) {
                $doc = "$doc Attachment $($headerWs.Attachment)"
            }
            $wsInfo.Cells["B$rowDoc"].Value = $doc
            $wsInfo.Cells["B$rowRev"].Value = $headerWs.Rev
            $wsInfo.Cells["B$rowEff"].Value = $headerWs.Effective
            
            if ($wsHeaderCheck -and $doc) { & $StyleMatchCell $wsInfo.Cells["C$rowDoc"] }
            if ($wsHeaderCheck -and $headerWs.Rev) { & $StyleMatchCell $wsInfo.Cells["C$rowRev"] }
            if ($wsHeaderCheck -and $headerWs.Effective) { & $StyleMatchCell $wsInfo.Cells["C$rowEff"] }
        } else {
            $wsInfo.Cells["B$rowDoc"].Value = ''
            $wsInfo.Cells["B$rowRev"].Value = ''
            $wsInfo.Cells["B$rowEff"].Value = ''
        }