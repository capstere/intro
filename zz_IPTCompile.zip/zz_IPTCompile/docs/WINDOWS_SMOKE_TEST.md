# Windows PowerShell 5.1 Smoke Test

Detta dokument är en fokuserad manuell smoke-testlista för `IPTCompile` i Windows PowerShell 5.1.

Målet är att snabbt bekräfta att:
- normal rapportkörning fungerar
- SharePoint använder `Order#` som primär nyckel
- `SP Kontroll` i `Run Information` är lätt att läsa
- QC-påminnelsen inte överlappar SharePoint-blocket
- kända domänfall inte har regressat

Detta är inte en full regressionstest.

## Förutsättningar

- Kör i `powershell.exe` 5.1
- Använd projektkopian där `Rules/RuleBank.compiled.ps1` finns kvar
- Säkerställ att:
  - `output_template-v4.xlsx` finns
  - `Lib/EPPlus.dll` finns
  - nätverksvägar och SharePoint-åtkomst fungerar om du vill testa live-lookup
- Om SharePoint inte är tillgängligt: kör ändå layout- och rapportkontrollerna, men markera SP-delen som ej fullständigt verifierad

## Föreslagna lokala testfall i denna kopia

Verifierat lokalt som användbara för Order#/Seal Test-kontroller:
- `33301` i `Tests/R6 - HPV v2 #33301 - PQC (20,000)  SE-26-LFI-009 & 26-NC-14599`
- `32101` i `Tests/R12 - HIV VL XC #32101 - PQC (8,000) 26-NC-14508`
- `95107` i `Tests/R8 - GXMTB RIF ULTRA #95107 - PQC (28,800)  OBR`

Särskilt användbara:
- `33301`: normal Order# match + HPV-assay
- `32101`: bra kandidat för QC Data-påminnelse under SP-blocket
- `95107`: ytterligare normalfall för MTB Ultra

Ej bevisat från denna kopia:
- tydligt lokalt split-batch-fall
- tydligt lokalt HPV `sample code 0 + INVALID`-fall

För dessa två scenarier: använd ett känt internt testfall om det finns.

## Testprotokoll

För varje scenario:
- notera datum/tid
- notera testfall/LSP
- notera `PASS`, `FAIL` eller `EJ TESTAT`
- spara gärna genererad rapport, auditfil och loggfil

---

## 1. Normal report generation med SharePoint Order# match

### Rekommenderat case
- `33301`
- alternativt `32101` eller `95107`

### Steg
1. Starta appen i Windows PowerShell 5.1.
2. Välj testfilerna för ett komplett case:
   - `Tests Summary`
   - `Seal Test Pos`
   - `Seal Test Neg`
   - `Worksheet`
3. Kör normal rapportgenerering.
4. Bekräfta att rapporten skapas utan fel.

### Förväntat resultat
- rapportfil skapas
- ingen krasch i GUI eller script
- SharePoint-sökningen använder `Order#` från Seal Test B10
- ingen synlig text antyder att `Batch#` är primär SharePoint-nyckel

### Kontrollera särskilt
- statusraden/länken visar `SharePoint: Order# ...` när Order# är entydigt
- ingen fallback till `SharePoint: Batch# ...`

---

## 2. Run Information: visuell kontroll av nya SP Kontroll-blocket

### Rekommenderat case
- `33301`

### Steg
1. Öppna genererad rapport.
2. Gå till bladet `Run Information`.
3. Titta på området `E:F`.

### Förväntat resultat
Du ska se ett tydligt block med:
- `SP Kontroll`
- `SP Order#`
- `SP Batch#`
- `SP LSP`

### Visuell kontroll
- texten är läsbar utan att en enda lång rad flyter ut
- raderna wrappar vid behov
- `SP Kontroll` är:
  - grön vid match
  - röd vid mismatch
- individuella delrader blir varningsmarkerade om just Order, Batch eller LSP inte matchar

### PASS om
- blocket är lätt att läsa
- användaren kan se vilken del som matchar eller mismatchar

---

## 3. QC reminder placeras under SP-blocket

### Rekommenderat case
- `32101` eftersom HIV/HBV/HCV-flödet är relevant för QC-påminnelse

### Steg
1. Kör ett case där QC Data-påminnelsen förväntas visas.
2. Öppna `Run Information`.
3. Kontrollera området `E:F`.

### Förväntat resultat
- QC-blocket ligger under SharePoint-blocket
- ingen överlappning mellan:
  - `SharePoint Info`
  - `SP Kontroll`
  - `QC Data – ...`

### PASS om
- QC-påminnelsen börjar först efter att SP-blocket är slut
- inga sammanslagna celler eller färgfält kolliderar

---

## 4. Order# mismatch: SharePoint får inte falla tillbaka till Batch#

### Rekommenderat scenario
Använd ett medvetet felparat case:
- välj POS och NEG från olika batch/order
eller
- använd ett känt internt mismatch-case

### Steg
1. Ladda ett case där POS/NEG ger olika Order# i Seal Test B10.
2. Låt appen uppdatera SharePoint-länken/statusen.
3. Kör rapporten om flödet tillåter det.

### Förväntat resultat
- GUI-länken ska inte bli aktiv via Batch#
- status ska visa att Order# mismatchar
- SharePoint-post ska inte hämtas via Batch/LSP som fallback

### PASS om
- länken är avstängd eller tydligt visar Order# mismatch
- ingen synlig Batch#-baserad sökning används som ersättning

---

## 5. Split-batch: båda batchnummer ska visas och verifieras

### Rekommenderat scenario
Använd ett känt internt split-batch-case där SharePoint har:
- två 10-siffriga batchnummer i `Batch#`, eller
- andra batchen i `SAP Batch# 2`

### Steg
1. Kör rapporten på ett bekräftat split-batch-case.
2. Öppna `Run Information`.
3. Kontrollera `SP Batch#`.

### Förväntat resultat
- båda batchnumren visas som två separata batchvärden
- de får inte kollapsa till ett långt sammanhängande nummer
- ordningen ska inte orsaka falsk mismatch om mängden batchnummer är densamma

### PASS om
- båda batchnumren syns tydligt
- kontrollen matchar när samma två batchnummer finns i olika ordning

---

## 6. HPV sample code 0 + INVALID

### Rekommenderat scenario
Använd ett känt internt HPV-fall där:
- sample code i `Sample ID` är `0`
- `Test Result` är `INVALID`

### Steg
1. Kör rapporten på det kända HPV-fallet.
2. Kontrollera rapportens klassning för den raden.

### Förväntat resultat
- detta ska behandlas som förväntat negativt beteende
- ingen falsk `Minor Functional / Invalid w/o error`
- `Sample ID`-koden ska väga tyngre än felaktigt vald `Test Type`

### PASS om
- ingen falsk varning/minor skapas för detta scenario

---

## 7. Seal Test N/A ska inte trigga "Saknar utvägning"

### Rekommenderat scenario
Använd ett case där Seal Test innehåller:
- `N/A`
- `NA`
- `#N/A`
- tomt
- `-`
i slutvikt/utvägning

### Steg
1. Kör rapporten.
2. Granska STF Summary och relevanta varningssektioner.

### Förväntat resultat
- `Saknar utvägning` ska bara varna om initial vikt faktiskt är numeriskt ifylld
- rena placeholders ska inte behandlas som verklig mätdata
- sådana warnings får inte öka verklig FAIL-räkning

### PASS om
- inga falska FAIL skapas från placeholdervärden

---

## 8. Worksheet signing och review signing

### Rekommenderat case
- ett normalt komplett case, t.ex. `33301` eller `32101`

### Steg
1. Kör hela rapportflödet inklusive signering/review om det ingår i testet.
2. Kontrollera:
   - Worksheet-signatur
   - Review-signatur
   - eventuella OpenXML-baserade uppdateringar

### Förväntat resultat
- signering ska genomföras utan krasch
- inga null-reference-liknande fel
- rätt celler/blad uppdateras

### PASS om
- signering lyckas
- inga saknade XML-noder eller blad får processen att dö

---

## Minsta godkända smoke-pass

Minst detta bör vara grönt innan release eller vidare test:
- scenario 1
- scenario 2
- scenario 3
- scenario 4
- scenario 7
- scenario 8

Och när sådana case finns tillgängliga:
- scenario 5
- scenario 6

## Dokumentera utfallet

Spara gärna en enkel tabell:

| Scenario | Case | Resultat | Notering |
| --- | --- | --- | --- |
| 1 | 33301 | PASS/FAIL | |
| 2 | 33301 | PASS/FAIL | |
| 3 | 32101 | PASS/FAIL | |
| 4 | mismatch-case | PASS/FAIL | |
| 5 | split-batch-case | PASS/FAIL | |
| 6 | HPV code 0 INVALID | PASS/FAIL | |
| 7 | relevant case | PASS/FAIL | |
| 8 | 33301 eller 32101 | PASS/FAIL | |

## Viktig gräns

Den här smoke-testen ska inte användas för att ändra domänlogik under test.
Om något fall fallerar:
- dokumentera exakt filuppsättning
- spara genererad rapport
- spara audit/logg
- analysera sedan med minimal patch, inte bred refaktor
