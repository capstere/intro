﻿param(
    [string]$ProjectRoot,
    [string]$CasesPath
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

. (Join-Path $PSScriptRoot 'RuleBankV2.Common.ps1')

function Convert-ObjectToStableJson {
    param($Value)
    return ($Value | ConvertTo-Json -Depth 20 -Compress)
}

function Get-RuleBankGoldenSnapshotPath {
    param(
        [Parameter(Mandatory)][pscustomobject]$Paths,
        [Parameter(Mandatory)][string]$Lsp,
        [Parameter(Mandatory)][string]$Phase
    )
    $fileName = ('{0}.{1}.json' -f $Lsp, $Phase.ToLowerInvariant())
    return (Join-Path $Paths.SnapshotsRoot $fileName)
}

function Get-RuleEngineSnapshot {
    param([pscustomobject]$Result)

    $summary = [ordered]@{
        Total = $Result.Summary.Total
        RetestYes = $Result.Summary.RetestYes
        MinorFunctionalError = $Result.Summary.MinorFunctionalError
        InstrumentError = $Result.Summary.InstrumentError
        DelamCount = $Result.Summary.DelamCount
        ReplacementCount = $Result.Summary.ReplacementCount
        ObservedCounts = [ordered]@{}
        DeviationCounts = [ordered]@{}
    }

    foreach ($k in @($Result.Summary.ObservedCounts.Keys | Sort-Object)) {
        $summary['ObservedCounts'][$k] = [int]$Result.Summary.ObservedCounts[$k]
    }
    foreach ($k in @($Result.Summary.DeviationCounts.Keys | Sort-Object)) {
        $summary['DeviationCounts'][$k] = [int]$Result.Summary.DeviationCounts[$k]
    }

    $rows = @(
        $Result.Rows |
            Sort-Object SampleId, Assay, CartridgeSN |
            ForEach-Object {
                [ordered]@{
                    SampleId = ($_.SampleId + '')
                    Assay = ($_.Assay + '')
                    ControlCode = ($_.ControlCode + '')
                    ExpectedCall = ($_.ExpectedCall + '')
                    ObservedCall = ($_.ObservedCall + '')
                    Deviation = ($_.Deviation + '')
                    ErrorCode = ($_.ErrorCode + '')
                    ErrorName = ($_.ErrorName + '')
                    GeneratesRetest = ($_.GeneratesRetest + '')
                    DelamPresent = [bool]$_.DelamPresent
                    DelamCodes = ($_.DelamCodes + '')
                    ExpectedSuffix = ($_.ExpectedSuffix + '')
                    ActualSuffix = ($_.ActualSuffix + '')
                    SuffixCheck = ($_.SuffixCheck + '')
                    SampleNum = ($_.SampleNum + '')
                    SampleNumOK = ($_.SampleNumOK + '')
                    RuleFlags = ($_.RuleFlags + '')
                }
            }
    )

    return [ordered]@{
        Summary = $summary
        Rows = $rows
    }
}

$paths = Get-RuleBankV2Paths -ProjectRoot $ProjectRoot
if (-not $CasesPath) {
    $CasesPath = Join-Path $paths.TestsRoot 'GoldenCases.psd1'
}
$devCheck = Test-RuleBankV2DevPrerequisites -RequiredPaths @($paths.SourceRoot, $paths.MetaPath, $CasesPath)
if (-not $devCheck.Ok) {
    Write-RuleBankV2DevOnlyNotice -ToolName 'Test-RuleBankV2.ps1' -MissingPaths $devCheck.Missing
    exit 1
}
if (-not (Test-Path -LiteralPath $paths.TestsRoot)) {
    New-Item -Path $paths.TestsRoot -ItemType Directory -Force | Out-Null
}
if (-not (Test-Path -LiteralPath $paths.SnapshotsRoot)) {
    New-Item -Path $paths.SnapshotsRoot -ItemType Directory -Force | Out-Null
}

$bundle = Get-RuleBankV2SourceBundle -ProjectRoot $paths.ProjectRoot
$artifact = New-RuleBankV2CompiledArtifact -Bundle $bundle
Write-RuleBankCompiledPs1 -Artifact $artifact -Path $paths.CanonicalCompiledPath

. ([scriptblock]::Create((Get-RuleBankV2ScriptContent -Path (Join-Path $paths.ProjectRoot 'Infrastructure/Csv.ps1'))))
. ([scriptblock]::Create((Get-RuleBankV2ScriptContent -Path (Join-Path $paths.ProjectRoot 'Core/RuleEngineCore.ps1'))))

$canonicalRuleBank = Load-RuleBank -RuleBankDir $paths.RuntimeRuleBankDir
$caseSpec = Import-PowerShellDataFile -Path $CasesPath
$testRoot = Join-Path (Split-Path -Parent $paths.ProjectRoot) 'TEST-LSP'
$reportRows = New-Object System.Collections.Generic.List[object]
$failures = New-Object System.Collections.Generic.List[string]

foreach ($case in @($caseSpec['Cases'])) {
    $lsp = ($case['Lsp'] + '')
    $folder = Join-Path $testRoot $lsp
    if (-not (Test-Path -LiteralPath $folder)) {
        $failures.Add(('Missing golden case folder: {0}' -f $folder))
        continue
    }

    $csvPaths = @(Get-ChildItem -LiteralPath $folder -File | Where-Object { $_.Name -match '(?i)tests? summary.*\.csv$' } | ForEach-Object { $_.FullName } | Sort-Object)
    $resolved = Resolve-CsvPrimaryAndResample -CsvPaths $csvPaths
    if (-not $resolved.Ok) {
        $failures.Add(('Case {0}: CSV resolution failed: {1}' -f $lsp, $resolved.ErrorMessage))
        continue
    }

    foreach ($csvPath in @($resolved.PrimaryCsv, $resolved.ResampleCsv)) {
        if (-not $csvPath) { continue }
        $label = if ($csvPath -eq $resolved.ResampleCsv) { 'Resample' } else { 'Primary' }
        $rows = Import-CsvRows -Path $csvPath
        $canonicalResult = Invoke-RuleEngine -CsvObjects $rows -RuleBank $canonicalRuleBank -CsvPath $csvPath
        $canonicalSnap = Get-RuleEngineSnapshot -Result $canonicalResult
        $canonicalJson = Convert-ObjectToStableJson -Value $canonicalSnap
        $snapshotPath = Get-RuleBankGoldenSnapshotPath -Paths $paths -Lsp $lsp -Phase $label
        $match = $false
        $missingSnapshot = $false

        if (-not (Test-Path -LiteralPath $snapshotPath)) {
            $missingSnapshot = $true
            $failures.Add(('Case {0} {1}: missing golden snapshot: {2}' -f $lsp, $label, $snapshotPath))
            $canonicalSnap | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath ($snapshotPath + '.actual.json') -Encoding UTF8
        } else {
            $expectedJson = Get-Content -LiteralPath $snapshotPath -Raw -Encoding UTF8
            $match = ($canonicalJson -eq (Convert-ObjectToStableJson -Value (ConvertFrom-Json -InputObject $expectedJson -Depth 50)))
        }

        $reportRows.Add([pscustomobject]@{
            Lsp = $lsp
            Phase = $label
            CsvPath = $csvPath
            SnapshotPath = $snapshotPath
            Match = $match
            Total = $canonicalResult.Summary.Total
            RetestYes = $canonicalResult.Summary.RetestYes
            MinorFunctionalError = $canonicalResult.Summary.MinorFunctionalError
            InstrumentError = $canonicalResult.Summary.InstrumentError
            DelamCount = $canonicalResult.Summary.DelamCount
            ObservedCounts = $canonicalResult.Summary.ObservedCounts
            DeviationCounts = $canonicalResult.Summary.DeviationCounts
        })

        if ((-not $match) -and (-not $missingSnapshot)) {
            $failures.Add(('Case {0} {1}: runtime snapshot mismatch against golden snapshot' -f $lsp, $label))
            $diffPathBase = Join-Path $paths.TestsRoot ('RuleBankV2.diff.{0}.{1}' -f $lsp, $label.ToLowerInvariant())
            $canonicalSnap | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath ($diffPathBase + '.canonical.json') -Encoding UTF8
        }
    }
}

$reportPath = Join-Path $paths.TestsRoot 'RuleBankV2.test-report.json'
$report = [ordered]@{
    ProjectRoot = $paths.ProjectRoot
    CasesPath = $CasesPath
    CanonicalRuleBankDir = $paths.RuntimeRuleBankDir
    CanonicalCompiledPath = $paths.CanonicalCompiledPath
    Results = @($reportRows.ToArray())
    Failures = @($failures)
}
$report | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $reportPath -Encoding UTF8

if ($failures.Count -gt 0) {
    foreach ($line in $failures) { Write-Host ('FAIL ' + $line) }
    Write-Host ('Test report: {0}' -f $reportPath)
    exit 1
}

foreach ($row in @($reportRows.ToArray())) {
    Write-Host ('PASS {0} {1}' -f $row.Lsp, $row.Phase)
}
Write-Host ('PASS RuleBank v2 golden tests')
Write-Host ('Canonical runtime artifact: {0}' -f $paths.CanonicalCompiledPath)
Write-Host ('Test report: {0}' -f $reportPath)
