
<#
.SYNOPSIS
  Field-safe reboot / restart diagnostic collector for Infinity kiosk PCs.

.DESCRIPTION
  PowerShell 5.1 compatible. Read-only. Designed not to hang.
  v1.3 collects the most important reboot/update evidence first, writes live status files,
  skips slow WindowsUpdateLog conversion by default, and runs native commands with timeouts.

.OUTPUT
  Desktop\InfinityKiosk_RebootDiag_<COMPUTER>_<timestamp>
  Desktop\InfinityKiosk_RebootDiag_<COMPUTER>_<timestamp>.zip
  Desktop\InfinityKiosk_RebootDiag_STATUS_<COMPUTER>.txt

.NOTES
  Safe/read-only. Does not change update settings, services, scheduled tasks, or restart behavior.
  Version: 1.3 field-safe / timeout build
#>

[CmdletBinding()]
param(
    [int]$DaysBack = 90,
    [int]$MaxEventsPerLog = 1500,
    [int]$NativeTimeoutSeconds = 30,
    [int]$TimelineWindowMinutes = 180,
    [switch]$Full,
    [switch]$IncludeEvtxExport,
    [switch]$IncludeWindowsUpdateLog,
    [switch]$NoZip
)

$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'

# -----------------------------
# Setup
# -----------------------------
$ScriptStart = Get-Date
$StartTime = (Get-Date).AddDays(-1 * [Math]::Abs($DaysBack))
$EndTime = Get-Date
$ComputerName = $env:COMPUTERNAME
$SafeComputerName = ($ComputerName -replace '[^A-Za-z0-9_.-]', '_')

function Get-DesktopPath {
    try {
        $p = [Environment]::GetFolderPath('Desktop')
        if ([string]::IsNullOrWhiteSpace($p) -or -not (Test-Path -LiteralPath $p)) { $p = Join-Path $env:USERPROFILE 'Desktop' }
        if (-not (Test-Path -LiteralPath $p)) { New-Item -Path $p -ItemType Directory -Force | Out-Null }
        return $p
    } catch { return $env:TEMP }
}

$Desktop = Get-DesktopPath
$Stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$OutRoot = Join-Path $Desktop ("InfinityKiosk_RebootDiag_{0}_{1}" -f $SafeComputerName, $Stamp)
$RawDir = Join-Path $OutRoot 'Raw'
$CsvDir = Join-Path $OutRoot 'CSV'
$JsonDir = Join-Path $OutRoot 'JSON'
$TxtDir = Join-Path $OutRoot 'TXT'
$HtmlDir = Join-Path $OutRoot 'HTML'
New-Item -Path $OutRoot,$RawDir,$CsvDir,$JsonDir,$TxtDir,$HtmlDir -ItemType Directory -Force | Out-Null

$StatusFile = Join-Path $OutRoot 'LIVE_STATUS.txt'
$DesktopStatusFile = Join-Path $Desktop ("InfinityKiosk_RebootDiag_STATUS_{0}.txt" -f $SafeComputerName)
$TranscriptPath = Join-Path $TxtDir 'transcript.txt'
try { Start-Transcript -Path $TranscriptPath -Force | Out-Null } catch {}

$script:Findings = New-Object System.Collections.Generic.List[object]
$script:Errors = New-Object System.Collections.Generic.List[object]
$script:Steps = New-Object System.Collections.Generic.List[object]
$script:AllEvents = New-Object System.Collections.Generic.List[object]

function Write-LiveStatus {
    param([string]$Message,[string]$Level = 'INFO')
    $line = "{0} [{1}] {2}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
    try { Write-Host $line }
    catch {}
    try { Add-Content -Path $StatusFile -Value $line -Encoding UTF8 }
    catch {}
    try { Set-Content -Path $DesktopStatusFile -Value @(
            "Infinity kiosk diagnostic live status",
            "Computer: $env:COMPUTERNAME",
            "Output: $OutRoot",
            "Last update: $line",
            "",
            "If this file stops changing for many minutes, the current step may be slow/hung.",
            "v1.3 is designed to continue past most failures and timeouts."
        ) -Encoding UTF8 }
    catch {}
}

function Add-Finding {
    param([string]$Severity,[string]$Area,[string]$Message,[string]$Evidence = '')
    try {
        $script:Findings.Add([PSCustomObject]@{
            TimeCollected = Get-Date
            Severity      = $Severity
            Area          = $Area
            Message       = $Message
            Evidence      = $Evidence
        }) | Out-Null
    } catch {}
}

function Add-ErrorRecord {
    param([string]$Area,[string]$Message)
    try {
        $script:Errors.Add([PSCustomObject]@{
            TimeCollected = Get-Date
            Area          = $Area
            Error         = $Message
        }) | Out-Null
    } catch {}
}

function Add-StepRecord {
    param([string]$Name,[string]$Status,[double]$Seconds,[string]$Note = '')
    try {
        $script:Steps.Add([PSCustomObject]@{
            TimeCollected = Get-Date
            Step          = $Name
            Status        = $Status
            Seconds       = [Math]::Round($Seconds,2)
            Note          = $Note
        }) | Out-Null
    } catch {}
}

function ConvertTo-SafeObjectArray {
    param($Data)
    $list = New-Object System.Collections.ArrayList
    if ($null -eq $Data) { return @() }
    if (($Data -is [string]) -or ($Data -is [System.Collections.IDictionary])) { [void]$list.Add($Data) }
    elseif ($Data -is [System.Collections.IEnumerable]) {
        foreach ($item in $Data) { if ($null -ne $item) { [void]$list.Add($item) } }
    }
    else { [void]$list.Add($Data) }
    return $list.ToArray()
}

function New-NoRowsObject {
    param([string]$Reason = 'NO_ROWS_COLLECTED')
    return [PSCustomObject]@{ ComputerName = $env:COMPUTERNAME; TimeCollected = Get-Date; Info = $Reason }
}

function Export-CsvSafe {
    param($Data,[string]$Path)
    try {
        $arr = @(ConvertTo-SafeObjectArray -Data $Data)
        if ($arr.Count -eq 0) { New-NoRowsObject | Export-Csv -Path $Path -NoTypeInformation -Encoding UTF8 -Force }
        else { $arr | Where-Object { $null -ne $_ } | Export-Csv -Path $Path -NoTypeInformation -Encoding UTF8 -Force }
    } catch {
        Add-ErrorRecord -Area "Export-CsvSafe $Path" -Message $_.Exception.Message
        try { New-NoRowsObject -Reason 'CSV_EXPORT_FAILED' | Export-Csv -Path $Path -NoTypeInformation -Encoding UTF8 -Force } catch {}
    }
}

function Export-JsonSafe {
    param($Data,[string]$Path,[int]$Depth = 6)
    try {
        if ($null -eq $Data) { @() | ConvertTo-Json -Depth $Depth | Out-File -FilePath $Path -Encoding UTF8 -Force }
        else { $Data | ConvertTo-Json -Depth $Depth | Out-File -FilePath $Path -Encoding UTF8 -Force }
    } catch { Add-ErrorRecord -Area "Export-JsonSafe $Path" -Message $_.Exception.Message }
}

function Out-TextSafe {
    param([string[]]$Text,[string]$Path)
    try { $Text | Out-File -FilePath $Path -Encoding UTF8 -Force }
    catch { Add-ErrorRecord -Area "Out-TextSafe $Path" -Message $_.Exception.Message }
}

function Invoke-Step {
    param([string]$Name,[scriptblock]$ScriptBlock)
    $sw = [Diagnostics.Stopwatch]::StartNew()
    Write-LiveStatus "START: $Name"
    try {
        & $ScriptBlock
        $sw.Stop()
        Add-StepRecord -Name $Name -Status 'OK' -Seconds $sw.Elapsed.TotalSeconds
        Write-LiveStatus ("DONE:  {0} ({1}s)" -f $Name,[Math]::Round($sw.Elapsed.TotalSeconds,1))
    } catch {
        $sw.Stop()
        $msg = $_.Exception.Message
        Add-ErrorRecord -Area $Name -Message $msg
        Add-Finding -Severity 'WARN' -Area $Name -Message 'Collection step failed; script continued.' -Evidence $msg
        Add-StepRecord -Name $Name -Status 'FAILED' -Seconds $sw.Elapsed.TotalSeconds -Note $msg
        Write-LiveStatus ("FAILED: {0} - {1}" -f $Name,$msg) 'WARN'
    }
}

function Run-NativeCommandTimed {
    param([string]$Name,[string]$CommandLine,[string]$OutputFile,[int]$TimeoutSeconds = $NativeTimeoutSeconds)
    Write-LiveStatus ("START native: {0} timeout={1}s" -f $Name,$TimeoutSeconds)
    $sw = [Diagnostics.Stopwatch]::StartNew()
    $stdout = "$OutputFile.stdout.tmp"
    $stderr = "$OutputFile.stderr.tmp"
    try {
        $header = @()
        $header += "COMMAND: $CommandLine"
        $header += "TIME:    $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
        $header += "COMPUTER:$env:COMPUTERNAME"
        $header += "TIMEOUT: $TimeoutSeconds seconds"
        $header += ('-' * 80)
        $header | Out-File -FilePath $OutputFile -Encoding UTF8 -Force

        $p = Start-Process -FilePath "$env:WINDIR\System32\cmd.exe" -ArgumentList "/c $CommandLine" -RedirectStandardOutput $stdout -RedirectStandardError $stderr -WindowStyle Hidden -PassThru
        $finished = $p.WaitForExit($TimeoutSeconds * 1000)
        if (-not $finished) {
            try { $p.Kill() } catch {}
            Add-Finding -Severity 'WARN' -Area "Native command: $Name" -Message 'Native command timed out and was killed.' -Evidence $CommandLine
            Add-StepRecord -Name "Native: $Name" -Status 'TIMEOUT' -Seconds $sw.Elapsed.TotalSeconds -Note $CommandLine
            Add-Content -Path $OutputFile -Value "`r`nTIMEOUT: Command exceeded $TimeoutSeconds seconds and was killed." -Encoding UTF8
        } else {
            Add-StepRecord -Name "Native: $Name" -Status "EXIT_$($p.ExitCode)" -Seconds $sw.Elapsed.TotalSeconds -Note $CommandLine
        }
        if (Test-Path -LiteralPath $stdout) { Add-Content -Path $OutputFile -Value "`r`nSTDOUT:`r`n" -Encoding UTF8; Get-Content -LiteralPath $stdout -ErrorAction SilentlyContinue | Add-Content -Path $OutputFile -Encoding UTF8 }
        if (Test-Path -LiteralPath $stderr) { Add-Content -Path $OutputFile -Value "`r`nSTDERR:`r`n" -Encoding UTF8; Get-Content -LiteralPath $stderr -ErrorAction SilentlyContinue | Add-Content -Path $OutputFile -Encoding UTF8 }
    } catch {
        Add-ErrorRecord -Area "Run-NativeCommandTimed $Name" -Message $_.Exception.Message
        Add-Finding -Severity 'WARN' -Area "Native command: $Name" -Message 'Native command failed; script continued.' -Evidence $_.Exception.Message
    } finally {
        Remove-Item -LiteralPath $stdout,$stderr -Force -ErrorAction SilentlyContinue
        $sw.Stop()
        Write-LiveStatus ("DONE native: {0} ({1}s)" -f $Name,[Math]::Round($sw.Elapsed.TotalSeconds,1))
    }
}

function Test-IsAdmin {
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal($id)
        return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Get-CimOrWmi {
    param([string]$ClassName,[string]$Namespace = 'root\cimv2')
    try { return Get-CimInstance -ClassName $ClassName -Namespace $Namespace -ErrorAction Stop }
    catch {
        try { return Get-WmiObject -Class $ClassName -Namespace $Namespace -ErrorAction Stop }
        catch { Add-ErrorRecord -Area "WMI/CIM $ClassName" -Message $_.Exception.Message; return $null }
    }
}

function Convert-WmiDateSafe {
    param($WmiDate)
    try { if ($null -eq $WmiDate) { return $null }; return [System.Management.ManagementDateTimeConverter]::ToDateTime([string]$WmiDate) }
    catch { return $null }
}

function Convert-EventRecord {
    param($Event)
    if ($null -eq $Event) { return $null }
    $msg = ''
    $props = ''
    try { $msg = [string]$Event.Message } catch { $msg = '' }
    try {
        $pv = @()
        foreach ($p in $Event.Properties) { $pv += [string]$p.Value }
        $props = ($pv -join ' | ')
    } catch { $props = '' }
    if ($msg.Length -gt 8000) { $msg = $msg.Substring(0,8000) + '...[TRUNCATED]' }
    if ($props.Length -gt 4000) { $props = $props.Substring(0,4000) + '...[TRUNCATED]' }
    return [PSCustomObject]@{
        ComputerName      = $env:COMPUTERNAME
        TimeCreated       = $Event.TimeCreated
        LogName           = $Event.LogName
        ProviderName      = $Event.ProviderName
        Id                = $Event.Id
        LevelDisplayName  = $Event.LevelDisplayName
        RecordId          = $Event.RecordId
        UserId            = $Event.UserId
        MachineName       = $Event.MachineName
        PropertiesText    = $props
        Message           = $msg
    }
}

function Get-WinEventRows {
    param(
        [string]$LogName,
        [int[]]$Id,
        [datetime]$Since = $StartTime,
        [datetime]$Until = $EndTime,
        [int]$MaxEvents = $MaxEventsPerLog
    )
    $rows = New-Object System.Collections.Generic.List[object]
    try {
        $log = Get-WinEvent -ListLog $LogName -ErrorAction Stop
        if ($null -eq $log) { return @() }
    } catch {
        Add-ErrorRecord -Area "EventLog exists: $LogName" -Message $_.Exception.Message
        return @()
    }
    try {
        $filter = @{ LogName = $LogName; StartTime = $Since; EndTime = $Until }
        if ($Id -and $Id.Count -gt 0) { $filter.Id = $Id }
        $events = Get-WinEvent -FilterHashtable $filter -MaxEvents $MaxEvents -ErrorAction Stop
        foreach ($e in $events) {
            $row = Convert-EventRecord -Event $e
            if ($null -ne $row) { $rows.Add($row) | Out-Null; $script:AllEvents.Add($row) | Out-Null }
        }
    } catch {
        # No matching events is normal; do not make it fatal.
        if ($_.Exception.Message -notmatch 'No events were found') {
            Add-ErrorRecord -Area "Get-WinEvent $LogName" -Message $_.Exception.Message
        }
    }
    return $rows.ToArray()
}

function Get-RegistryValuesOneKey {
    param([string]$Path)
    $rows = New-Object System.Collections.Generic.List[object]
    try {
        if (-not (Test-Path -LiteralPath $Path)) {
            $rows.Add([PSCustomObject]@{ ComputerName=$env:COMPUTERNAME; TimeCollected=Get-Date; Path=$Path; Name='__KEY_NOT_FOUND__'; Value=''; Type='' }) | Out-Null
            return $rows.ToArray()
        }
        $item = Get-Item -LiteralPath $Path -ErrorAction Stop
        $props = Get-ItemProperty -LiteralPath $Path -ErrorAction Stop
        foreach ($name in $item.GetValueNames()) {
            $value = $item.GetValue($name)
            $kind = $item.GetValueKind($name)
            $rows.Add([PSCustomObject]@{
                ComputerName  = $env:COMPUTERNAME
                TimeCollected = Get-Date
                Path          = $Path
                Name          = $name
                Value         = $(if ($value -is [array]) { ($value -join ' | ') } else { [string]$value })
                Type          = [string]$kind
            }) | Out-Null
        }
        if ($item.GetValueNames().Count -eq 0) {
            $rows.Add([PSCustomObject]@{ ComputerName=$env:COMPUTERNAME; TimeCollected=Get-Date; Path=$Path; Name='__KEY_EXISTS_BUT_NO_VALUES__'; Value=''; Type='' }) | Out-Null
        }
    } catch {
        Add-ErrorRecord -Area "Registry $Path" -Message $_.Exception.Message
        $rows.Add([PSCustomObject]@{ ComputerName=$env:COMPUTERNAME; TimeCollected=Get-Date; Path=$Path; Name='__ERROR__'; Value=$_.Exception.Message; Type='' }) | Out-Null
    }
    return $rows.ToArray()
}

function Get-RegistryTreeRows {
    param([string[]]$Paths,[switch]$Recurse)
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($p in $Paths) {
        foreach ($r in @(Get-RegistryValuesOneKey -Path $p)) { $rows.Add($r) | Out-Null }
        if ($Recurse -and (Test-Path -LiteralPath $p)) {
            try {
                Get-ChildItem -LiteralPath $p -Recurse -ErrorAction SilentlyContinue | ForEach-Object {
                    foreach ($r in @(Get-RegistryValuesOneKey -Path $_.PSPath)) { $rows.Add($r) | Out-Null }
                }
            } catch { Add-ErrorRecord -Area "Registry recurse $p" -Message $_.Exception.Message }
        }
    }
    return $rows.ToArray()
}

function Get-PendingRebootRows {
    $checks = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending',
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootInProgress',
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\PackagesPending',
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired',
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\PostRebootReporting',
        'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager'
    )
    $rows = New-Object System.Collections.Generic.List[object]
    foreach ($p in $checks) {
        try {
            $exists = Test-Path -LiteralPath $p
            $detail = ''
            if ($p -like '*Session Manager*') {
                try {
                    $val = (Get-ItemProperty -LiteralPath $p -Name PendingFileRenameOperations -ErrorAction Stop).PendingFileRenameOperations
                    if ($val) { $detail = ($val -join ' | ') }
                } catch {}
                $exists = -not [string]::IsNullOrWhiteSpace($detail)
            }
            $rows.Add([PSCustomObject]@{ ComputerName=$env:COMPUTERNAME; TimeCollected=Get-Date; Indicator=$p; Present=$exists; Detail=$detail }) | Out-Null
        } catch {
            $rows.Add([PSCustomObject]@{ ComputerName=$env:COMPUTERNAME; TimeCollected=Get-Date; Indicator=$p; Present='ERROR'; Detail=$_.Exception.Message }) | Out-Null
        }
    }
    return $rows.ToArray()
}

function New-HtmlReport {
    param([string]$Path)
    try {
        $find = @(ConvertTo-SafeObjectArray $script:Findings)
        $steps = @(ConvertTo-SafeObjectArray $script:Steps)
        $errs = @(ConvertTo-SafeObjectArray $script:Errors)
        $html = @()
        $html += '<html><head><meta charset="utf-8"><title>Infinity Kiosk Reboot Diagnostics</title>'
        $html += '<style>body{font-family:Segoe UI,Arial,sans-serif;font-size:13px} table{border-collapse:collapse;margin-bottom:18px} th,td{border:1px solid #bbb;padding:4px;vertical-align:top} th{background:#eee}.warn{color:#9a5b00}.err{color:#b00020}</style></head><body>'
        $html += "<h1>Infinity Kiosk Reboot Diagnostics v1.3</h1>"
        $html += "<p><b>Computer:</b> $env:COMPUTERNAME<br><b>Collected:</b> $(Get-Date)<br><b>Range:</b> $StartTime to $EndTime<br><b>Output:</b> $OutRoot</p>"
        $html += '<h2>Findings</h2>'
        $html += ($find | ConvertTo-Html -Fragment)
        $html += '<h2>Step status</h2>'
        $html += ($steps | ConvertTo-Html -Fragment)
        $html += '<h2>Collection errors</h2>'
        $html += ($errs | ConvertTo-Html -Fragment)
        $html += '</body></html>'
        $html -join "`r`n" | Out-File -FilePath $Path -Encoding UTF8 -Force
    } catch { Add-ErrorRecord -Area 'HTML report' -Message $_.Exception.Message }
}

# -----------------------------
# Main
# -----------------------------
Write-LiveStatus "Collecting Infinity kiosk reboot diagnostics v1.3"
Write-LiveStatus "Output folder: $OutRoot"
Write-LiveStatus "Range: $StartTime to $EndTime"

$IsAdmin = Test-IsAdmin
if (-not $IsAdmin) { Add-Finding -Severity 'WARN' -Area 'Privilege' -Message 'Script is not running as Administrator. Some computer policy/event data may be incomplete.' -Evidence 'Right-click batch file > Run as administrator if possible.' }
else { Add-Finding -Severity 'INFO' -Area 'Privilege' -Message 'Script is running as Administrator.' -Evidence '' }

Invoke-Step -Name '01 Core system summary' -ScriptBlock {
    $os = Get-CimOrWmi -ClassName Win32_OperatingSystem
    $cs = Get-CimOrWmi -ClassName Win32_ComputerSystem
    $bios = Get-CimOrWmi -ClassName Win32_BIOS
    $summary = [PSCustomObject]@{
        ComputerName       = $env:COMPUTERNAME
        UserName           = $env:USERNAME
        UserDomain         = $env:USERDOMAIN
        IsAdmin            = $IsAdmin
        ScriptVersion      = '1.3'
        CollectionStart    = $ScriptStart
        DaysBack           = $DaysBack
        OS_Caption         = $os.Caption
        OS_Version         = $os.Version
        OS_BuildNumber     = $os.BuildNumber
        OS_InstallDate     = Convert-WmiDateSafe $os.InstallDate
        OS_LastBootUpTime  = Convert-WmiDateSafe $os.LastBootUpTime
        Manufacturer       = $cs.Manufacturer
        Model              = $cs.Model
        Domain             = $cs.Domain
        PartOfDomain       = $cs.PartOfDomain
        BIOS_SerialNumber  = $bios.SerialNumber
        BIOS_Version       = $(if ($bios.SMBIOSBIOSVersion) { $bios.SMBIOSBIOSVersion } else { ($bios.BIOSVersion -join ' | ') })
        BIOS_ReleaseDate   = Convert-WmiDateSafe $bios.ReleaseDate
    }
    Export-CsvSafe $summary (Join-Path $CsvDir '01_core_system_summary.csv')
    Export-JsonSafe $summary (Join-Path $JsonDir '01_core_system_summary.json')
}

Invoke-Step -Name '02 EARLY critical reboot/shutdown System events' -ScriptBlock {
    $ids = @(12,13,19,20,41,42,43,44,1074,6005,6006,6008,1001,109)
    $rows = Get-WinEventRows -LogName 'System' -Id $ids -Since $StartTime -Until $EndTime -MaxEvents ([Math]::Min($MaxEventsPerLog,2500))
    Export-CsvSafe $rows (Join-Path $CsvDir '05_early_reboot_shutdown_markers.csv')
    if (@($rows).Count -gt 0) {
        Add-Finding -Severity 'INFO' -Area 'EventLog/System' -Message ('Collected critical reboot/shutdown markers: {0} rows.' -f @($rows).Count) -Evidence 'See CSV\05_early_reboot_shutdown_markers.csv'
    } else {
        Add-Finding -Severity 'WARN' -Area 'EventLog/System' -Message 'No critical reboot/shutdown markers were collected.' -Evidence 'Could be no events in time window, access issue, or log retention issue.'
    }
}

Invoke-Step -Name '03 EARLY Windows Update / Update Orchestrator operational events' -ScriptBlock {
    $logs = @(
        'Microsoft-Windows-WindowsUpdateClient/Operational',
        'Microsoft-Windows-UpdateOrchestrator/Operational',
        'Microsoft-Windows-TaskScheduler/Operational',
        'Microsoft-Windows-Kernel-Boot/Operational',
        'Application'
    )
    foreach ($log in $logs) {
        $safe = ($log -replace '[\\/:*?"<>| ]','_')
        $max = $(if ($log -eq 'Application') { 800 } else { [Math]::Min($MaxEventsPerLog,1500) })
        $ids = $null
        if ($log -eq 'Application') { $ids = @(1000,1001,1026,1033,11707,11724) }
        $rows = Get-WinEventRows -LogName $log -Id $ids -Since $StartTime -Until $EndTime -MaxEvents $max
        Export-CsvSafe $rows (Join-Path $CsvDir ("06_early_events_{0}.csv" -f $safe))
    }
}

Invoke-Step -Name '04 Reboot/update timeline around markers' -ScriptBlock {
    $all = @(ConvertTo-SafeObjectArray $script:AllEvents)
    $markers = @($all | Where-Object { $_.Id -in @(12,13,41,1074,6005,6006,6008,1001,109) } | Sort-Object TimeCreated)
    Export-CsvSafe $markers (Join-Path $CsvDir '65_reboot_shutdown_markers.csv')
    $timeline = New-Object System.Collections.Generic.List[object]
    foreach ($m in $markers) {
        $from = ([datetime]$m.TimeCreated).AddMinutes(-1 * $TimelineWindowMinutes)
        $to = ([datetime]$m.TimeCreated).AddMinutes($TimelineWindowMinutes)
        foreach ($e in @($all | Where-Object { ([datetime]$_.TimeCreated) -ge $from -and ([datetime]$_.TimeCreated) -le $to } | Sort-Object TimeCreated)) {
            $timeline.Add([PSCustomObject]@{
                MarkerTime       = $m.TimeCreated
                MarkerId         = $m.Id
                MarkerProvider   = $m.ProviderName
                EventTime        = $e.TimeCreated
                EventLog         = $e.LogName
                EventProvider    = $e.ProviderName
                EventId          = $e.Id
                Level            = $e.LevelDisplayName
                PropertiesText   = $e.PropertiesText
                Message          = $e.Message
            }) | Out-Null
        }
    }
    Export-CsvSafe $timeline.ToArray() (Join-Path $CsvDir '66_timeline_windows_around_reboot_markers.csv')
}

Invoke-Step -Name '05 Restart prompt and forced reboot clue filter' -ScriptBlock {
    $all = @(ConvertTo-SafeObjectArray $script:AllEvents)
    $pattern = 'restart|reboot|shutdown|UpdateOrchestrator|USO|MoUso|MusNotification|RestartManager|RebootRequired|pending|deadline|active hour|automatic restart|restart now'
    $clues = @($all | Where-Object { (($_.Message + ' ' + $_.PropertiesText + ' ' + $_.ProviderName) -match $pattern) } | Sort-Object TimeCreated)
    Export-CsvSafe $clues (Join-Path $CsvDir '63_events_restart_prompt_clues.csv')
    if (@($clues).Count -gt 0) { Add-Finding -Severity 'INFO' -Area 'Restart clues' -Message ('Restart/reboot/update prompt clues found: {0} rows.' -f @($clues).Count) -Evidence 'See CSV\63_events_restart_prompt_clues.csv' }
}

Invoke-Step -Name '06 Pending reboot indicators' -ScriptBlock {
    $rows = Get-PendingRebootRows
    Export-CsvSafe $rows (Join-Path $CsvDir '10_pending_reboot_indicators.csv')
    foreach ($r in @($rows | Where-Object { $_.Present -eq $true })) {
        Add-Finding -Severity 'WARN' -Area 'Pending reboot' -Message ('Pending reboot indicator present: {0}' -f $r.Indicator) -Evidence $r.Detail
    }
}

Invoke-Step -Name '07 Windows Update and restart policy registry' -ScriptBlock {
    $paths = @(
        'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate',
        'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU',
        'HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings',
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update',
        'HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\Update',
        'HKLM:\SOFTWARE\Microsoft\PolicyManager\default\Update',
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\WindowsUpdate'
    )
    $rows = Get-RegistryTreeRows -Paths $paths -Recurse
    Export-CsvSafe $rows (Join-Path $CsvDir '11_all_registry_update_policy_rows.csv')
    $interesting = @($rows | Where-Object { $_.Name -match 'NoAutoReboot|NoAUShutdown|ActiveHours|WUServer|WUStatus|UseWUServer|AUOptions|Deadline|Restart|Reboot|DualScan|TargetRelease|Pause|Schedule|DetectionFrequency|ConfigureDeadline|EngagedRestart|SetActiveHours' })
    Export-CsvSafe $interesting (Join-Path $CsvDir '12_interesting_registry_update_policy_rows.csv')
}

Invoke-Step -Name '08 Scheduled tasks update/reboot/auth' -ScriptBlock {
    $pattern = 'Update|Orchestrator|Reboot|Restart|USO|MoUSO|MusNotification|EdgeUpdate|Gate|Keeper|Token|Auth|Duo|Intune|MDM|SCCM|ConfigMgr|Tanium'
    $rows = New-Object System.Collections.Generic.List[object]
    try {
        $tasks = Get-ScheduledTask -ErrorAction Stop | Where-Object { ($_.TaskName + ' ' + $_.TaskPath + ' ' + $_.Description) -match $pattern }
        foreach ($t in $tasks) {
            $info = $null
            try { $info = Get-ScheduledTaskInfo -TaskName $t.TaskName -TaskPath $t.TaskPath -ErrorAction Stop } catch {}
            $rows.Add([PSCustomObject]@{
                ComputerName   = $env:COMPUTERNAME
                TimeCollected  = Get-Date
                TaskPath       = $t.TaskPath
                TaskName       = $t.TaskName
                State          = $t.State
                Author         = $t.Author
                Description    = $t.Description
                LastRunTime    = $(if ($info) { $info.LastRunTime } else { $null })
                LastTaskResult = $(if ($info) { $info.LastTaskResult } else { $null })
                NextRunTime    = $(if ($info) { $info.NextRunTime } else { $null })
            }) | Out-Null
        }
    } catch { Add-ErrorRecord -Area 'Scheduled tasks' -Message $_.Exception.Message }
    Export-CsvSafe $rows.ToArray() (Join-Path $CsvDir '31_interesting_scheduled_tasks_update_reboot_auth.csv')
}

Invoke-Step -Name '09 Services update/auth/management' -ScriptBlock {
    $pattern = 'Update|Orchestrator|UsoSvc|WaaS|BITS|CryptSvc|TrustedInstaller|Edge|Gate|Keeper|Token|Auth|Duo|Intune|MDM|SCCM|ConfigMgr|Tanium|CrowdStrike|Sentinel|Defender|Qualys|Ivanti|Kaseya|ManageEngine'
    $rows = New-Object System.Collections.Generic.List[object]
    try {
        $svcs = Get-WmiObject -Class Win32_Service -ErrorAction Stop | Where-Object { ($_.Name + ' ' + $_.DisplayName + ' ' + $_.PathName) -match $pattern }
        foreach ($s in $svcs) {
            $rows.Add([PSCustomObject]@{
                ComputerName  = $env:COMPUTERNAME
                TimeCollected = Get-Date
                Name          = $s.Name
                DisplayName   = $s.DisplayName
                State         = $s.State
                StartMode     = $s.StartMode
                StartName     = $s.StartName
                PathName      = $s.PathName
                Description   = $s.Description
            }) | Out-Null
        }
    } catch { Add-ErrorRecord -Area 'Services' -Message $_.Exception.Message }
    Export-CsvSafe $rows.ToArray() (Join-Path $CsvDir '21_interesting_services_update_auth_security.csv')
}

Invoke-Step -Name '10 Processes update/auth/management' -ScriptBlock {
    $pattern = 'Update|Orchestrator|Uso|MoUso|MusNotification|shutdown|restart|Edge|Gate|Keeper|Token|Auth|Duo|Intune|MDM|SCCM|ConfigMgr|Tanium|CrowdStrike|Sentinel|Defender|Qualys'
    $rows = New-Object System.Collections.Generic.List[object]
    try {
        $procs = Get-WmiObject Win32_Process -ErrorAction Stop | Where-Object { ($_.Name + ' ' + $_.CommandLine + ' ' + $_.ExecutablePath) -match $pattern }
        foreach ($p in $procs) {
            $rows.Add([PSCustomObject]@{
                ComputerName  = $env:COMPUTERNAME
                TimeCollected = Get-Date
                ProcessId     = $p.ProcessId
                ParentProcessId = $p.ParentProcessId
                Name          = $p.Name
                ExecutablePath= $p.ExecutablePath
                CommandLine   = $p.CommandLine
            }) | Out-Null
        }
    } catch { Add-ErrorRecord -Area 'Processes' -Message $_.Exception.Message }
    Export-CsvSafe $rows.ToArray() (Join-Path $CsvDir '22_interesting_processes_update_auth_security.csv')
}

Invoke-Step -Name '11 Hotfix inventory' -ScriptBlock {
    try { $h = Get-HotFix -ErrorAction Stop | Sort-Object InstalledOn -Descending; Export-CsvSafe $h (Join-Path $CsvDir '41_hotfixes.csv') }
    catch { Add-ErrorRecord -Area 'Get-HotFix' -Message $_.Exception.Message; Export-CsvSafe $null (Join-Path $CsvDir '41_hotfixes.csv') }
}

Invoke-Step -Name '12 Quick native commands with timeout' -ScriptBlock {
    Run-NativeCommandTimed -Name 'whoami all' -CommandLine 'whoami /all' -OutputFile (Join-Path $TxtDir 'whoami_all.txt') -TimeoutSeconds 20
    Run-NativeCommandTimed -Name 'ipconfig all' -CommandLine 'ipconfig /all' -OutputFile (Join-Path $TxtDir 'ipconfig_all.txt') -TimeoutSeconds 20
    Run-NativeCommandTimed -Name 'gpresult computer r' -CommandLine 'gpresult /scope computer /r' -OutputFile (Join-Path $TxtDir 'gpresult_computer_r.txt') -TimeoutSeconds 45
    Run-NativeCommandTimed -Name 'gpresult user r' -CommandLine 'gpresult /scope user /r' -OutputFile (Join-Path $TxtDir 'gpresult_user_r.txt') -TimeoutSeconds 45
    Run-NativeCommandTimed -Name 'powercfg waketimers' -CommandLine 'powercfg /waketimers' -OutputFile (Join-Path $TxtDir 'powercfg_waketimers.txt') -TimeoutSeconds 20
    Run-NativeCommandTimed -Name 'powercfg requests' -CommandLine 'powercfg /requests' -OutputFile (Join-Path $TxtDir 'powercfg_requests.txt') -TimeoutSeconds 20
    Run-NativeCommandTimed -Name 'powercfg lastwake' -CommandLine 'powercfg /lastwake' -OutputFile (Join-Path $TxtDir 'powercfg_lastwake.txt') -TimeoutSeconds 20
}

if ($Full) {
    Invoke-Step -Name '13 FULL optional native commands' -ScriptBlock {
        Run-NativeCommandTimed -Name 'systeminfo' -CommandLine 'systeminfo' -OutputFile (Join-Path $TxtDir 'systeminfo.txt') -TimeoutSeconds 90
        Run-NativeCommandTimed -Name 'schtasks query csv verbose' -CommandLine 'schtasks /Query /V /FO CSV' -OutputFile (Join-Path $TxtDir 'schtasks_query_verbose.csv.txt') -TimeoutSeconds 90
        Run-NativeCommandTimed -Name 'dism packages' -CommandLine 'dism /online /get-packages /format:table' -OutputFile (Join-Path $TxtDir 'dism_online_get_packages.txt') -TimeoutSeconds 120
        Run-NativeCommandTimed -Name 'powercfg q' -CommandLine 'powercfg /q' -OutputFile (Join-Path $TxtDir 'powercfg_full_q.txt') -TimeoutSeconds 90
    }
} else {
    Add-Finding -Severity 'INFO' -Area 'Mode' -Message 'Full/heavy native commands were skipped by default to avoid hanging in the lab.' -Evidence 'Run with -Full if needed.'
}

if ($IncludeWindowsUpdateLog -or $Full) {
    Invoke-Step -Name '14 Optional Get-WindowsUpdateLog' -ScriptBlock {
        if (Get-Command Get-WindowsUpdateLog -ErrorAction SilentlyContinue) {
            $wuLog = Join-Path $TxtDir 'WindowsUpdate_converted.log'
            # Do not timeout this internally; only run when explicitly requested.
            Get-WindowsUpdateLog -LogPath $wuLog -ErrorAction Stop | Out-Null
        } else {
            Add-Finding -Severity 'INFO' -Area 'Windows Update log' -Message 'Get-WindowsUpdateLog command was not available.' -Evidence ''
        }
    }
} else {
    Add-Finding -Severity 'INFO' -Area 'Windows Update log' -Message 'Skipped Get-WindowsUpdateLog by default because it can take a long time and appear hung.' -Evidence 'Run with -IncludeWindowsUpdateLog if needed.'
}

if ($IncludeEvtxExport -or $Full) {
    Invoke-Step -Name '15 Optional EVTX export with timeout' -ScriptBlock {
        $exportLogs = @('System','Application','Microsoft-Windows-WindowsUpdateClient/Operational','Microsoft-Windows-UpdateOrchestrator/Operational','Microsoft-Windows-TaskScheduler/Operational')
        foreach ($log in $exportLogs) {
            $safe = ($log -replace '[\\/:*?"<>| ]','_')
            $dest = Join-Path $RawDir ("{0}.evtx" -f $safe)
            Run-NativeCommandTimed -Name "wevtutil export $log" -CommandLine ('wevtutil epl "{0}" "{1}" /ow:true' -f $log,$dest) -OutputFile (Join-Path $TxtDir ("wevtutil_export_{0}.txt" -f $safe)) -TimeoutSeconds 60
        }
    }
} else {
    Add-Finding -Severity 'INFO' -Area 'EVTX export' -Message 'Skipped raw EVTX export by default to avoid slow collection.' -Evidence 'Run with -IncludeEvtxExport if needed.'
}

Invoke-Step -Name '90 Final exports and HTML report' -ScriptBlock {
    Export-CsvSafe $script:Findings (Join-Path $CsvDir '00_FINDINGS_read_this_first.csv')
    Export-CsvSafe $script:Errors (Join-Path $CsvDir '00_collection_errors.csv')
    Export-CsvSafe $script:Steps (Join-Path $CsvDir '00_step_status.csv')
    Export-CsvSafe $script:AllEvents (Join-Path $CsvDir '60_all_collected_event_rows.csv')
    New-HtmlReport -Path (Join-Path $HtmlDir 'InfinityKiosk_RebootDiag_Report.html')
}

if (-not $NoZip) {
    Invoke-Step -Name '91 Create ZIP package' -ScriptBlock {
        $ZipPath = "$OutRoot.zip"
        if (Test-Path -LiteralPath $ZipPath) { Remove-Item -LiteralPath $ZipPath -Force -ErrorAction SilentlyContinue }
        if (Get-Command Compress-Archive -ErrorAction SilentlyContinue) {
            Compress-Archive -Path (Join-Path $OutRoot '*') -DestinationPath $ZipPath -Force -ErrorAction Stop
            Add-Finding -Severity 'INFO' -Area 'ZIP' -Message 'ZIP package created.' -Evidence $ZipPath
            Export-CsvSafe $script:Findings (Join-Path $CsvDir '00_FINDINGS_read_this_first.csv')
        } else {
            Add-Finding -Severity 'WARN' -Area 'ZIP' -Message 'Compress-Archive not available. Output folder exists, but ZIP was not created.' -Evidence $OutRoot
        }
    }
} else {
    Add-Finding -Severity 'INFO' -Area 'ZIP' -Message 'ZIP was skipped because -NoZip was used.' -Evidence $OutRoot
}

$duration = [Math]::Round(((Get-Date) - $ScriptStart).TotalSeconds,1)
Write-LiveStatus "DONE. Duration ${duration}s. Output: $OutRoot" 'DONE'
Write-LiveStatus "ZIP: $OutRoot.zip" 'DONE'
try { Stop-Transcript | Out-Null } catch {}

Write-Host ""
Write-Host "============================================================"
Write-Host " DONE - Infinity kiosk reboot diagnostics v1.3"
Write-Host "============================================================"
Write-Host "Output folder: $OutRoot"
Write-Host "ZIP:           $OutRoot.zip"
Write-Host "Status file:   $DesktopStatusFile"
Write-Host "Start review:  CSV\00_FINDINGS_read_this_first.csv"
Write-Host "               CSV\05_early_reboot_shutdown_markers.csv"
Write-Host "               CSV\66_timeline_windows_around_reboot_markers.csv"
Write-Host "============================================================"
