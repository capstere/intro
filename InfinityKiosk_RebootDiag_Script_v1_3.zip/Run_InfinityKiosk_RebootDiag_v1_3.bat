@echo off
setlocal EnableExtensions EnableDelayedExpansion

title Infinity Kiosk Reboot Diagnostic v1.3

REM ============================================================
REM Infinity Kiosk Reboot Diagnostic Launcher v1.3
REM Default mode is quick/field-safe. It skips known slow steps.
REM ============================================================

set "DAYS_BACK=90"
set "MAX_EVENTS=1500"
set "SCRIPT_DIR=%~dp0"
set "PS_SCRIPT=%SCRIPT_DIR%Collect-InfinityKioskRebootDiag_v1_3.ps1"
set "DESKTOP=%USERPROFILE%\Desktop"
set "LAUNCH_LOG=%DESKTOP%\InfinityKiosk_RebootDiag_Launcher_v1_3.log"

echo ============================================================ > "%LAUNCH_LOG%"
echo Infinity Kiosk Reboot Diagnostic Launcher v1.3              >> "%LAUNCH_LOG%"
echo Started: %DATE% %TIME%                                      >> "%LAUNCH_LOG%"
echo Computer: %COMPUTERNAME%                                    >> "%LAUNCH_LOG%"
echo User: %USERNAME%                                             >> "%LAUNCH_LOG%"
echo Script: %PS_SCRIPT%                                          >> "%LAUNCH_LOG%"
echo ============================================================ >> "%LAUNCH_LOG%"
echo. >> "%LAUNCH_LOG%"

echo.
echo ============================================================
echo  Infinity Kiosk Reboot Diagnostic v1.3
echo ============================================================
echo.
echo Default mode: QUICK / field-safe
echo Skips slow WindowsUpdateLog conversion and raw EVTX export.
echo.
echo Launcher log:
echo %LAUNCH_LOG%
echo.

if not exist "%PS_SCRIPT%" (
    echo ERROR: PowerShell script not found:
    echo "%PS_SCRIPT%"
    echo ERROR: PowerShell script not found: "%PS_SCRIPT%" >> "%LAUNCH_LOG%"
    pause
    exit /b 1
)

if exist "%WINDIR%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" (
    set "POWERSHELL_EXE=%WINDIR%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
) else (
    set "POWERSHELL_EXE=%WINDIR%\System32\WindowsPowerShell\v1.0\powershell.exe"
)

net session >nul 2>&1
if "%ERRORLEVEL%"=="0" (
    echo Admin check: Running as administrator.
    echo Admin check: Running as administrator. >> "%LAUNCH_LOG%"
) else (
    echo WARNING: Not running as administrator.
    echo Some computer policy details may be incomplete, but collection continues.
    echo WARNING: Not running as administrator. >> "%LAUNCH_LOG%"
)

echo.
echo Running diagnostic collection...
echo Watch this window. It should show START/DONE for each step.
echo A live status file is also written to Desktop.
echo.

"%POWERSHELL_EXE%" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%" -DaysBack %DAYS_BACK% -MaxEventsPerLog %MAX_EVENTS% >> "%LAUNCH_LOG%" 2>&1
set "EXIT_CODE=%ERRORLEVEL%"

echo. >> "%LAUNCH_LOG%"
echo Finished: %DATE% %TIME% >> "%LAUNCH_LOG%"
echo Exit code: %EXIT_CODE% >> "%LAUNCH_LOG%"

echo.
echo ============================================================
echo  Finished with exit code %EXIT_CODE%
echo ============================================================
echo.
echo Check Desktop for:
echo  - InfinityKiosk_RebootDiag_... folder
echo  - InfinityKiosk_RebootDiag_... zip
echo  - InfinityKiosk_RebootDiag_STATUS_%COMPUTERNAME%.txt
echo  - InfinityKiosk_RebootDiag_Launcher_v1_3.log
echo.
pause
exit /b %EXIT_CODE%
