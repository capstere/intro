Infinity Kiosk Reboot Diagnostic v1.3
=====================================

Purpose
-------
Read-only evidence collector for Infinity kiosk PCs that reboot or show "restart now" prompts while tests may be running.

What changed in v1.3
--------------------
- Field-safe quick mode is now default.
- Collects critical reboot/update Event Logs FIRST.
- Writes live status both in console and Desktop status file.
- Native commands are run with timeouts.
- Get-WindowsUpdateLog is skipped by default because it can take a long time and look hung.
- Raw EVTX export is skipped by default.
- Full/heavy commands are optional.

Normal run
----------
Right-click Run_InfinityKiosk_RebootDiag_v1_3.bat and choose "Run as administrator" if possible.
If admin is not possible, run anyway.

Manual run
----------
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\Collect-InfinityKioskRebootDiag_v1_3.ps1 -DaysBack 90

Optional full/heavy run
-----------------------
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\Collect-InfinityKioskRebootDiag_v1_3.ps1 -DaysBack 90 -Full

Optional raw EVTX export
------------------------
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\Collect-InfinityKioskRebootDiag_v1_3.ps1 -DaysBack 90 -IncludeEvtxExport

Optional WindowsUpdateLog conversion
------------------------------------
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\Collect-InfinityKioskRebootDiag_v1_3.ps1 -DaysBack 90 -IncludeWindowsUpdateLog

Files to review first
---------------------
CSV\00_FINDINGS_read_this_first.csv
CSV\00_step_status.csv
CSV\05_early_reboot_shutdown_markers.csv
CSV\06_early_events_Microsoft-Windows-WindowsUpdateClient_Operational.csv
CSV\06_early_events_Microsoft-Windows-UpdateOrchestrator_Operational.csv
CSV\63_events_restart_prompt_clues.csv
CSV\65_reboot_shutdown_markers.csv
CSV\66_timeline_windows_around_reboot_markers.csv
HTML\InfinityKiosk_RebootDiag_Report.html

Safety
------
The script does not change Windows Update, services, scheduled tasks, registry settings, or reboot behavior.
