﻿param(
    [string]$RawDataPath  = "N:\QC\QC-1\IPT\8. IPT - WR + Rework\1. PQC - Kontrollprovsfil - RÖR EJ -\Script Raw Data\raw_data.xlsx",
    [string]$OutputDir    = "N:\QC\QC-1\IPT\8. IPT - WR + Rework\1. PQC - Kontrollprovsfil - RÖR EJ -\Inventeringsrapport",
    [string]$UpdateLogCsvPath = "",
    [bool]$AutoRepairUpdateLog = $true
)

# =====================[ App-info ]=====================
$script:AppName    = "Kontrollprovsfil"
$script:AppVersion = "FLOW v2.3 / Robust logg + fungerande rapporter / renare UI / 2026-05-25"

# =====================[ Kolumnschema för rådata ]=====================
$InventoryColumns = @{
    PN              = 1
    Lot             = 2
    Exp             = 3
    Qty             = 4
    LastUpdate      = 5
    Signature       = 6
    ProductStartCol = 7
    ProductEndCol   = 13
    Description     = 14
    LabbDescription = 15
    LabbCode        = 16
}

# =====================[ Minimal update-logg (CSV) ]=====================
$script:RawDataBackedUp = $false

if ([string]::IsNullOrWhiteSpace($UpdateLogCsvPath)) {
    $rawDir = Split-Path $RawDataPath -Parent
    $UpdateLogCsvPath = Join-Path $rawDir "UpdateLog_Kontrollprovsfil.csv"
}
$script:UpdateLogCsvPath = $UpdateLogCsvPath

# =====================[ Excel COM: öppna + spara raw_data.xlsx ]=====================
$script:ExcelOpenSave_Enabled = $true
$script:ExcelOpenSave_TimeoutSec = 90

# =====================[ EPPlus bootstrap (minimal) ]=====================

function Ensure-EPPlus {
    param(
        [string] $SourceDllPath = "N:\QC\QC-1\IPT\Skiftspecifika dokument\PQC analyst\JESPER\Scripts\Modules\EPPlus\EPPlus.4.5.3.3\lib\net35\EPPlus.dll"
    )

    $candidatePaths = @()
    if (-not [string]::IsNullOrWhiteSpace($SourceDllPath)) { $candidatePaths += $SourceDllPath }
    $candidatePaths += (Join-Path $PSScriptRoot 'EPPlus.dll')

    foreach ($cand in $candidatePaths) {
        if (-not [string]::IsNullOrWhiteSpace($cand) -and (Test-Path -LiteralPath $cand)) {
            return $cand
        }
    }

    Write-Warning "❌ EPPlus.dll hittades inte. Lägg EPPlus.dll bredvid skriptet eller uppdatera SourceDllPath i Ensure-EPPlus."
    return $null
}

function Load-EPPlus {
    if ([System.AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GetName().Name -eq 'EPPlus' }) {
        return $true
    }

    $dllPath = Ensure-EPPlus
    if (-not $dllPath) { return $false }

    try {
        $bytes = [System.IO.File]::ReadAllBytes($dllPath)
        [System.Reflection.Assembly]::Load($bytes) | Out-Null
        return $true
    }
    catch {
        Write-Warning "❌ EPPlus-fel vid inläsning från '$dllPath': $($_.Exception.Message)"
        return $false
    }
}

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force -ErrorAction SilentlyContinue

if (-not (Load-EPPlus)) {
    Write-Host "Kritisk komponent (EPPlus) kunde inte laddas. Skriptet avbryts." -ForegroundColor Red
    exit 1
}

# =====================[ Utilities ]=====================

function Backup-RawDataFile {
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [string]$BackupDir = "$PSScriptRoot\Backups"
    )
    try {
        if (-not (Test-Path -LiteralPath $BackupDir)) {
            New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
        }
        $timestamp  = (Get-Date).ToString("yyyyMMdd_HHmmss")
        $filename   = Split-Path $FilePath -Leaf
        $backupPath = Join-Path $BackupDir "$($filename)_$timestamp.bak"
        Copy-Item -LiteralPath $FilePath -Destination $backupPath -Force
        Write-Host "Säkerhetskopia skapad: $backupPath" -ForegroundColor Green
    } catch {
        Write-Host "⚠ Kunde inte skapa backup: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

function Pause-AnyKey {
    param([string]$Prompt = "Tryck Enter för att återgå till huvudmenyn...")

    try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") }
    catch { $null = Read-Host $Prompt }
}

function Invoke-WithRetry {
    param(
        [Parameter(Mandatory=$true)][scriptblock]$Action,
        [int]$MaxAttempts = 6,
        [int]$BaseDelayMs = 200
    )
    for ($i=1; $i -le $MaxAttempts; $i++) {
        try { return & $Action }
        catch {
            if ($i -eq $MaxAttempts) { throw }
            $delay = [int]($BaseDelayMs * [Math]::Pow(1.7, ($i-1)) + (Get-Random -Minimum 0 -Maximum 120))
            Start-Sleep -Milliseconds $delay
        }
    }
}

function Invoke-ExcelOpenSave {
    <#
      Minimal “Excel-magi”:
      Öppnar arbetsboken headless, väntar lite på kalkyl/async och sparar.
      Målet är att efterlikna att någon öppnar filen i Excel och trycker Ctrl+S.
    #>
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [int]$TimeoutSec = 90
    )

    if (-not (Test-Path -LiteralPath $Path)) { throw "Saknar fil: $Path" }

    $excel = $null
    $wb = $null
    try {
        $excel = New-Object -ComObject Excel.Application
        $excel.Visible = $false
        $excel.DisplayAlerts = $false
        try { $excel.EnableEvents = $false } catch {}
        try { $excel.AskToUpdateLinks = $false } catch {}

        # Visa “avvakta” så användaren inte stänger appen
        Write-Host "⏳ Avvakta: Excel måste öppna och spara raw_data.xlsx p.g.a att det ska fungera med appen... Så det tar några sekunder extra. Sorry" -ForegroundColor Yellow
        # UpdateLinks=3 => Excel försöker uppdatera externa länkar vid öppning
        $wb = $excel.Workbooks.Open($Path, 3, $false)

        # Visa “avvakta” så användaren inte stänger appen
        Write-Host "⏳ Avvakta: Excel måste öppna och spara raw_data.xlsx p.g.a att det ska fungera med appen... Så det tar några sekunder extra. Sorry" -ForegroundColor Yellow

        # Vänta en kort stund på kalkyl/async (utan att anta refresh-typ)
        $sw = [Diagnostics.Stopwatch]::StartNew()
        $tick = 0
        while ($sw.Elapsed.TotalSeconds -lt $TimeoutSec) {
            $state = 0
            try { $state = [int]$excel.CalculationState } catch { $state = 0 }
            if ($state -eq 0) { break } # 0 = xlDone
            $tick++
            if (($tick % 10) -eq 0) { Write-Host "   ... fortfarande igång ..." -ForegroundColor DarkYellow }
            Start-Sleep -Milliseconds 200
        }
        $sw.Stop() | Out-Null

        # Spara (det är detta du behöver för att “uppdateringen” ska bli verklig på disk)
        $wb.Save()
        return $true
    } finally {
        try { if ($wb) { $wb.Close($true) | Out-Null } } catch {}
        try { if ($excel) { $excel.Quit() | Out-Null } } catch {}
        try { if ($wb) { [Runtime.InteropServices.Marshal]::ReleaseComObject($wb) | Out-Null } } catch {}
        try { if ($excel) { [Runtime.InteropServices.Marshal]::ReleaseComObject($excel) | Out-Null } } catch {}
        [GC]::Collect()
        [GC]::WaitForPendingFinalizers()
    }
}


# =====================[ Robust CSV update-logg / audit trail ]=====================
# Viktigt:
# - Den gamla loggningen blev korrupt p.g.a. PowerShell-syntaxen "CsvCell $ts, CsvCell $user".
#   PowerShell tolkade det inte som separata funktionsanrop. Därför blev raderna t.ex.
#   "2026-03-05 18:18:03 CsvCell" i stället för 13 CSV-fält.
# - Denna version bygger varje rad via en objektlista + ForEach-Object, låser loggfilen
#   med en .lock-fil och använder spool/emergency-logg om huvudloggfilen är låst.

$script:UpdateLogHeaderColumns = @(
    'Timestamp','User','Signature','Action','PN','Row',
    'OldLot','OldExp','OldQty','NewLot','NewExp','NewQty','Machine'
)
$script:UpdateLogExpectedHeader = ($script:UpdateLogHeaderColumns -join ';')
$script:UpdateLogExpectedSemicolonCount = $script:UpdateLogHeaderColumns.Count - 1

function ConvertTo-LogCsvCell {
    param([AllowNull()][object]$Value)

    if ($null -eq $Value) { $text = '' }
    else { $text = [string]$Value }

    # En loggrad ska alltid vara exakt en fysisk rad.
    $text = $text -replace "(\r\n|\n|\r|\t)", ' '
    $text = $text.Trim()
    $text = $text.Replace('"','""')
    return ('"{0}"' -f $text)
}

function New-UpdateLogCsvLine {
    param([Parameter(Mandatory=$true)][object[]]$Values)

    if ($Values.Count -ne $script:UpdateLogHeaderColumns.Count) {
        throw "Internt loggfel: förväntade $($script:UpdateLogHeaderColumns.Count) fält men fick $($Values.Count)."
    }

    return (($Values | ForEach-Object { ConvertTo-LogCsvCell -Value $_ }) -join ';')
}

function Get-SafeFileNamePart {
    param([AllowNull()][string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return 'unknown' }
    return ($Text -replace '[^a-zA-Z0-9_\.-]', '_')
}

function Acquire-LockFile {
    param(
        [Parameter(Mandatory=$true)][string]$LockPath,
        [string]$Purpose = 'filoperation',
        [int]$TimeoutSec = 60,
        [int]$DelayMs = 250
    )

    $dir = Split-Path $LockPath -Parent
    if (-not [string]::IsNullOrWhiteSpace($dir) -and -not (Test-Path -LiteralPath $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }

    $sw = [Diagnostics.Stopwatch]::StartNew()
    $lastError = $null
    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSec) {
        try {
            $fs = [System.IO.File]::Open($LockPath, [System.IO.FileMode]::OpenOrCreate, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
            try {
                $bytes = [System.Text.Encoding]::UTF8.GetBytes(("Locked by {0}\{1} PID {2} at {3} for {4}" -f $env:COMPUTERNAME, [Environment]::UserName, $PID, (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'), $Purpose))
                $fs.SetLength(0)
                $fs.Write($bytes, 0, $bytes.Length)
                $fs.Flush()
            } catch {}
            return $fs
        }
        catch {
            $lastError = $_.Exception.Message
            Start-Sleep -Milliseconds $DelayMs
        }
    }

    throw "Kunde inte få lås för $Purpose inom $TimeoutSec sekunder. Låsfil: $LockPath. Senaste fel: $lastError"
}

function Release-LockFile {
    param(
        [Parameter(Mandatory=$true)]$LockHandle,
        [string]$LockPath
    )

    try { if ($LockHandle) { $LockHandle.Close() } } catch {}
    try { if ($LockHandle) { $LockHandle.Dispose() } } catch {}
    if (-not [string]::IsNullOrWhiteSpace($LockPath)) {
        try { Remove-Item -LiteralPath $LockPath -Force -ErrorAction SilentlyContinue } catch {}
    }
}

function Invoke-WithFileLock {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][scriptblock]$Action,
        [string]$Purpose = 'loggskrivning',
        [int]$TimeoutSec = 60
    )

    $lockPath = "$Path.lock"
    $lock = $null
    try {
        $lock = Acquire-LockFile -LockPath $lockPath -Purpose $Purpose -TimeoutSec $TimeoutSec
        return (& $Action)
    }
    finally {
        if ($lock) { Release-LockFile -LockHandle $lock -LockPath $lockPath }
    }
}

function Write-TextLineUtf8Unlocked {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$Line,
        [bool]$Append = $true,
        [bool]$Bom = $false
    )

    $dir = Split-Path $Path -Parent
    if (-not [string]::IsNullOrWhiteSpace($dir) -and -not (Test-Path -LiteralPath $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }

    $encoding = New-Object System.Text.UTF8Encoding($Bom)
    $sw = New-Object System.IO.StreamWriter($Path, $Append, $encoding)
    try {
        $sw.WriteLine($Line)
        $sw.Flush()
    }
    finally {
        $sw.Close()
        $sw.Dispose()
    }
}

function Get-UpdateLogHealth {
    param([Parameter(Mandatory=$true)][string]$Path)

    $result = [pscustomobject]@{
        Exists       = (Test-Path -LiteralPath $Path)
        IsHealthy    = $true
        Reason       = ''
        BadLineCount = 0
        LineCount    = 0
    }

    if (-not $result.Exists) { return $result }

    try {
        $reader = [System.IO.File]::OpenText($Path)
        try {
            while (($line = $reader.ReadLine()) -ne $null) {
                $result.LineCount++
                $cleanLine = $line.TrimStart([char]0xFEFF)

                if ($result.LineCount -eq 1) {
                    if ($cleanLine -ne $script:UpdateLogExpectedHeader) {
                        $result.IsHealthy = $false
                        $result.Reason = "Fel CSV-header. Förväntade: $($script:UpdateLogExpectedHeader)"
                        return $result
                    }
                    continue
                }

                if ([string]::IsNullOrWhiteSpace($cleanLine)) {
                    $result.BadLineCount++
                    continue
                }

                # Eftersom våra loggceller alltid saneras till en fysisk rad och skrivs med fast antal fält
                # ska varje datarad ha exakt 12 semikolon. Detta fångar den gamla "CsvCell"-korruptionen.
                $semiCount = ([regex]::Matches($cleanLine, ';')).Count
                if ($semiCount -ne $script:UpdateLogExpectedSemicolonCount -or $cleanLine -match '\sCsvCell"?$') {
                    $result.BadLineCount++
                }
            }
        }
        finally {
            $reader.Close()
            $reader.Dispose()
        }

        if ($result.BadLineCount -gt 0) {
            $result.IsHealthy = $false
            $result.Reason = "Hittade $($result.BadLineCount) korrupta loggrader av $($result.LineCount) rader."
        }
    }
    catch {
        $result.IsHealthy = $false
        $result.Reason = "Kunde inte läsa loggen: $($_.Exception.Message)"
    }

    return $result
}

function Initialize-UpdateLogCsv {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [bool]$AutoRepair = $true
    )

    Invoke-WithFileLock -Path $Path -Purpose 'initiering/reparation av uppdateringslogg' -TimeoutSec 60 -Action {
        $dir = Split-Path $Path -Parent
        if (-not [string]::IsNullOrWhiteSpace($dir) -and -not (Test-Path -LiteralPath $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
        }

        if (Test-Path -LiteralPath $Path) {
            $health = Get-UpdateLogHealth -Path $Path
            if (-not $health.IsHealthy) {
                if (-not $AutoRepair) {
                    throw "Update-loggen är inte frisk: $($health.Reason)"
                }

                $timestamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
                $base = [System.IO.Path]::GetFileNameWithoutExtension($Path)
                $ext  = [System.IO.Path]::GetExtension($Path)
                $backupPath = Join-Path $dir ("{0}.CORRUPT_BACKUP_{1}{2}" -f $base, $timestamp, $ext)
                Move-Item -LiteralPath $Path -Destination $backupPath -Force
                Write-Host "⚠ Befintlig CSV-logg var korrupt och har sparats som backup:" -ForegroundColor Yellow
                Write-Host "   $backupPath" -ForegroundColor DarkYellow
            }
        }

        if (-not (Test-Path -LiteralPath $Path)) {
            Write-TextLineUtf8Unlocked -Path $Path -Line $script:UpdateLogExpectedHeader -Append:$false -Bom:$true
        }
    } | Out-Null
}

function Ensure-UpdateLogCsv {
    param([Parameter(Mandatory=$true)][string]$Path)
    Initialize-UpdateLogCsv -Path $Path -AutoRepair:$AutoRepairUpdateLog
}

function Append-CsvLineWithRetry {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$Line
    )

    Invoke-WithRetry -MaxAttempts 8 -BaseDelayMs 250 -Action {
        Invoke-WithFileLock -Path $Path -Purpose 'append till uppdateringslogg' -TimeoutSec 30 -Action {
            Write-TextLineUtf8Unlocked -Path $Path -Line $Line -Append:$true -Bom:$false
        } | Out-Null
    } | Out-Null
}

function Get-UpdateLogSpoolPath {
    param([Parameter(Mandatory=$true)][string]$MainCsvPath)
    $dir = Split-Path $MainCsvPath -Parent
    $name = [System.IO.Path]::GetFileNameWithoutExtension($MainCsvPath)
    $pc = Get-SafeFileNamePart -Text $env:COMPUTERNAME
    $spoolName = "{0}.SPOOL.{1}.csv" -f $name, $pc
    return (Join-Path $dir $spoolName)
}

function Write-UpdateLogSpoolLine {
    param(
        [Parameter(Mandatory=$true)][string]$MainCsvPath,
        [Parameter(Mandatory=$true)][string]$Line
    )

    $spool = Get-UpdateLogSpoolPath -MainCsvPath $MainCsvPath
    Invoke-WithFileLock -Path $spool -Purpose 'spoolad uppdateringslogg' -TimeoutSec 30 -Action {
        if (-not (Test-Path -LiteralPath $spool)) {
            Write-TextLineUtf8Unlocked -Path $spool -Line $script:UpdateLogExpectedHeader -Append:$false -Bom:$true
        }
        Write-TextLineUtf8Unlocked -Path $spool -Line $Line -Append:$true -Bom:$false
    } | Out-Null

    return $spool
}

function Write-UpdateLogEmergencyLine {
    param(
        [Parameter(Mandatory=$true)][string]$Line,
        [Parameter(Mandatory=$true)][string]$Reason
    )

    $emergencyDir = Join-Path $PSScriptRoot 'EmergencyLogs'
    if (-not (Test-Path -LiteralPath $emergencyDir)) {
        New-Item -ItemType Directory -Path $emergencyDir -Force | Out-Null
    }

    $pc = Get-SafeFileNamePart -Text $env:COMPUTERNAME
    $emergencyPath = Join-Path $emergencyDir ("UpdateLog_Kontrollprovsfil.EMERGENCY.{0}.csv" -f $pc)

    Invoke-WithFileLock -Path $emergencyPath -Purpose 'emergency-logg' -TimeoutSec 20 -Action {
        if (-not (Test-Path -LiteralPath $emergencyPath)) {
            Write-TextLineUtf8Unlocked -Path $emergencyPath -Line $script:UpdateLogExpectedHeader -Append:$false -Bom:$true
        }
        Write-TextLineUtf8Unlocked -Path $emergencyPath -Line $Line -Append:$true -Bom:$false
        Write-TextLineUtf8Unlocked -Path ($emergencyPath + '.reason.txt') -Line ((Get-Date).ToString('yyyy-MM-dd HH:mm:ss') + ' - ' + $Reason) -Append:$true -Bom:$false
    } | Out-Null

    return $emergencyPath
}

function Flush-UpdateLogSpool {
    param([Parameter(Mandatory=$true)][string]$MainCsvPath)

    $dir  = Split-Path $MainCsvPath -Parent
    $name = [System.IO.Path]::GetFileNameWithoutExtension($MainCsvPath)

    if (-not (Test-Path -LiteralPath $dir)) { return }

    $spools = Get-ChildItem -LiteralPath $dir -Filter ("{0}.SPOOL.*.csv" -f $name) -ErrorAction SilentlyContinue
    if (-not $spools) { return }

    foreach ($spoolFile in $spools) {
        $claimPath = $spoolFile.FullName + ('.flushing.{0}.{1}' -f $env:COMPUTERNAME, $PID)
        try {
            Move-Item -LiteralPath $spoolFile.FullName -Destination $claimPath -ErrorAction Stop
        }
        catch {
            continue
        }

        try {
            $lines = Get-Content -LiteralPath $claimPath -ErrorAction Stop
            if ($lines.Count -le 1) {
                Remove-Item -LiteralPath $claimPath -Force -ErrorAction SilentlyContinue
                continue
            }

            Invoke-WithFileLock -Path $MainCsvPath -Purpose 'flush av spoolad uppdateringslogg' -TimeoutSec 60 -Action {
                for ($i=1; $i -lt $lines.Count; $i++) {
                    if (-not [string]::IsNullOrWhiteSpace($lines[$i])) {
                        Write-TextLineUtf8Unlocked -Path $MainCsvPath -Line $lines[$i] -Append:$true -Bom:$false
                    }
                }
            } | Out-Null

            Remove-Item -LiteralPath $claimPath -Force -ErrorAction SilentlyContinue
        }
        catch {
            try {
                if (Test-Path -LiteralPath $claimPath) {
                    Move-Item -LiteralPath $claimPath -Destination $spoolFile.FullName -Force -ErrorAction SilentlyContinue
                }
            } catch {}
            continue
        }
    }
}

function Write-UpdateLogRow {
    param(
        [Parameter(Mandatory=$true)][string]$PN,
        [Parameter(Mandatory=$true)][string]$Signature,
        [Parameter(Mandatory=$true)][ValidateSet('ADD','REMOVE','QTY','OVERWRITE')][string]$Action,
        [int]$RowNumber = 0,
        [string]$OldLot, [string]$OldExp, [string]$OldQty,
        [string]$NewLot, [string]$NewExp, [string]$NewQty
    )

    $path = $script:UpdateLogCsvPath
    $ts   = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $user = [Environment]::UserName
    $pc   = $env:COMPUTERNAME

    $line = New-UpdateLogCsvLine -Values @(
        $ts,
        $user,
        $Signature,
        $Action,
        $PN,
        [string]$RowNumber,
        $OldLot,
        $OldExp,
        $OldQty,
        $NewLot,
        $NewExp,
        $NewQty,
        $pc
    )

    try {
        Ensure-UpdateLogCsv -Path $path
        Flush-UpdateLogSpool -MainCsvPath $path
        Append-CsvLineWithRetry -Path $path -Line $line
        return 'MAIN'
    }
    catch {
        $mainError = $_.Exception.Message
        try {
            $spoolPath = Write-UpdateLogSpoolLine -MainCsvPath $path -Line $line
            return ('SPOOL:{0}' -f $spoolPath)
        }
        catch {
            $spoolError = $_.Exception.Message
            $emergencyPath = Write-UpdateLogEmergencyLine -Line $line -Reason ("Main log failed: $mainError | Spool failed: $spoolError")
            return ('EMERGENCY:{0}' -f $emergencyPath)
        }
    }
}


# =====================[ Auth + Signature ]=====================

function Request-Password {
    $autoUsers = @("vivian.dao", "elin.sidstedt", "jesper.fredriksson", "afnan.vijitraphongs")
    $currentUser = [Environment]::UserName.ToLower()
    if ($autoUsers -contains $currentUser) {
         Write-Host "Automatiskt godkänd för $currentUser utan lösenord." -ForegroundColor Green
         return $true
    }
    do {
         $securePwd = Read-Host "Ange lösenord eller tryck Enter för PQC-konto" -AsSecureString
         $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePwd)
         $unsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
         [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
         if ($unsecurePassword -eq 'labbkontroll') { return $true }
         Write-Host "Fel lösenord. Tryck (1) för att återgå till huvudmenyn." -ForegroundColor Red -BackgroundColor DarkYellow
         $choice = Read-Host "Ange ditt val"
         if ($choice -eq '1') { return $false }
    } while ($true)
}

function Get-UserSignature {
    param([string]$Prompt = "Ange din signatur för att bekräfta ändringarna")

    $userSignature = @{
        "jesper.fredriksson"   = "JESP"
        "elin.sidstedt"        = "ELS"
        "vivian.dao"           = "vdao"
        "afnan.vijitraphongs"  = "AFVI"
    }

    $currentUser = [Environment]::UserName.ToLower()

    if ($userSignature.ContainsKey($currentUser)) {
        Write-Host "Automatisk signatur för $currentUser $($userSignature[$currentUser])" -ForegroundColor Green
        return $userSignature[$currentUser]
    }

    do {
        $signature = Read-Host $Prompt
        if ($signature.Length -ge 3 -and $signature.Length -le 4) { return $signature }
        Write-Host "Ogiltig signatur – måste vara exakt 3-4 tecken." -ForegroundColor Red
    } while ($true)
}

# =====================[ Date parsing ]=====================

function Try-ParseInventoryDate {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text) -or $Text -eq 'N/A') { return $null }

    try {
        if ($Text -match '^\d{4}-\d{2}-\d{2}$') {
            return [datetime]$Text
        }
        elseif ($Text -match '^\d{4}-\d{2}$') {
            $year  = [int]$Text.Substring(0,4)
            $month = [int]$Text.Substring(5,2)
            $first = New-Object datetime($year, $month, 1)
            return $first.AddMonths(1).AddDays(-1)
        }
        return $null
    } catch { return $null }
}


function Normalize-InventoryText {
    param([AllowNull()][object]$Value)

    if ($null -eq $Value) { return '' }
    $text = [string]$Value
    $text = $text -replace [char]0x00A0, ' '
    return $text.Trim()
}

function Test-IsNAValue {
    param([AllowNull()][object]$Value)

    $text = Normalize-InventoryText -Value $Value
    if ([string]::IsNullOrWhiteSpace($text)) { return $true }

    $upper = $text.ToUpperInvariant()
    if ($upper -eq 'N/A') { return $true }
    if ($upper -eq 'NA') { return $true }
    if ($upper -eq 'N.A.') { return $true }
    if ($upper -eq '-') { return $true }

    return $false
}

function Get-InventoryCellText {
    param(
        [Parameter(Mandatory=$true)]$Sheet,
        [Parameter(Mandatory=$true)][int]$Row,
        [Parameter(Mandatory=$true)][int]$Column
    )

    try { return (Normalize-InventoryText -Value $Sheet.Cells[$Row,$Column].Text) }
    catch { return '' }
}

function Test-InventoryRowIsActive {
    <#
      Returnerar $true endast för rader som ser ut som aktiva materialposter.
      Syftet är att rapporterna inte ska ta med borttagna/avaktiverade rader där raw_data
      innehåller N/A i PN/Lot/Exp/Qty.

      Viktigt: Qty = 0 är fortfarande ett riktigt värde och filtreras inte bort.
    #>
    param(
        [Parameter(Mandatory=$true)]$Sheet,
        [Parameter(Mandatory=$true)][int]$Row
    )

    $pn  = Get-InventoryCellText -Sheet $Sheet -Row $Row -Column $InventoryColumns.PN
    $lot = Get-InventoryCellText -Sheet $Sheet -Row $Row -Column $InventoryColumns.Lot
    $exp = Get-InventoryCellText -Sheet $Sheet -Row $Row -Column $InventoryColumns.Exp
    $qty = Get-InventoryCellText -Sheet $Sheet -Row $Row -Column $InventoryColumns.Qty

    if (Test-IsNAValue -Value $pn)  { return $false }
    if (Test-IsNAValue -Value $lot) { return $false }
    if (Test-IsNAValue -Value $exp) { return $false }
    if (Test-IsNAValue -Value $qty) { return $false }

    return $true
}

function Read-ValidExpiryDate {
    param([string]$Prompt = "Ange utgångsdatum (YYYY-MM-DD eller YYYY-MM)")

    while ($true) {
        $input = Read-Host $Prompt
        if ([string]::IsNullOrWhiteSpace($input)) {
            Write-Host "Utgångsdatum får inte vara tomt." -ForegroundColor Red
            continue
        }
        if ($input -notmatch '^\d{4}-\d{2}-\d{2}$' -and $input -notmatch '^\d{4}-\d{2}$') {
            Write-Host "Ogiltigt format. Använd 'YYYY-MM-DD' eller 'YYYY-MM'." -ForegroundColor Red
            continue
        }
        $parsed = Try-ParseInventoryDate -Text $input
        if (-not $parsed) {
            Write-Host "Ogiltigt datum (t.ex. fel månad/dag). Försök igen." -ForegroundColor Red
            continue
        }
        return $input
    }
}

# =====================[ EPPlus helpers ]=====================

function Open-ExcelPackageWithRetry {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [int]$MaxAttempts = 5,
        [int]$DelaySeconds = 2
    )

    for ($attempt=1; $attempt -le $MaxAttempts; $attempt++) {
        try {
            $file = New-Object System.IO.FileInfo($Path)
            return (New-Object OfficeOpenXml.ExcelPackage($file))
        }
        catch {
            Write-Host "Kunde inte öppna '$Path' (försök $attempt/$MaxAttempts). Fel: $($_.Exception.Message)" -ForegroundColor Yellow
            Start-Sleep -Seconds $DelaySeconds
        }
    }

    Write-Host "❌ Gav upp efter $MaxAttempts försök att öppna '$Path'." -ForegroundColor Red
    return $null
}


# =====================[ UI helpers ]=====================

function Normalize-Choice {
    param([AllowNull()][string]$Value)
    if ($null -eq $Value) { return '' }
    return $Value.Trim().ToUpperInvariant()
}

function Show-AppHeader {
    param([string]$Title = $script:AppName)

    Clear-Host
    Write-Host "==============================================================" -ForegroundColor Cyan
    Write-Host (" {0} - {1}" -f $script:AppName, $Title) -ForegroundColor Cyan
    Write-Host "==============================================================" -ForegroundColor Cyan
    Write-Host ("Version  : {0}" -f $script:AppVersion) -ForegroundColor DarkGray
    Write-Host ("Rådatafil : {0}" -f $RawDataPath) -ForegroundColor DarkGray
    Write-Host ("CSV-logg  : {0}" -f $script:UpdateLogCsvPath) -ForegroundColor DarkGray
    Write-Host ""
}

function Read-RequiredText {
    param(
        [Parameter(Mandatory=$true)][string]$Prompt,
        [string[]]$CancelChoices = @('B','Q')
    )

    while ($true) {
        $value = Read-Host $Prompt
        $choice = Normalize-Choice $value
        if ($CancelChoices -contains $choice) {
            return [pscustomobject]@{ Cancelled = $true; Choice = $choice; Value = $null }
        }
        if (-not [string]::IsNullOrWhiteSpace($value)) {
            return [pscustomobject]@{ Cancelled = $false; Choice = ''; Value = $value.Trim() }
        }
        Write-Host "Värdet får inte vara tomt. Försök igen eller skriv B för back." -ForegroundColor Yellow
    }
}



function Read-ExpiryDateInput {
    param([string]$Prompt = "Ange utgångsdatum (YYYY-MM-DD eller YYYY-MM)")

    while ($true) {
        $input = Read-Host $Prompt
        $choice = Normalize-Choice $input
        if ($choice -eq 'B' -or $choice -eq 'Q') {
            return [pscustomobject]@{ Cancelled=$true; Choice=$choice; Value=$null }
        }
        if ([string]::IsNullOrWhiteSpace($input)) {
            Write-Host "Utgångsdatum får inte vara tomt." -ForegroundColor Red
            continue
        }
        if ($input -notmatch '^\d{4}-\d{2}-\d{2}$' -and $input -notmatch '^\d{4}-\d{2}$') {
            Write-Host "Ogiltigt format. Använd 'YYYY-MM-DD' eller 'YYYY-MM'. Skriv B för back." -ForegroundColor Red
            continue
        }
        $parsed = Try-ParseInventoryDate -Text $input
        if (-not $parsed) {
            Write-Host "Ogiltigt datum (t.ex. fel månad/dag). Försök igen." -ForegroundColor Red
            continue
        }
        return [pscustomobject]@{ Cancelled=$false; Choice=''; Value=$input.Trim() }
    }
}

function Confirm-Action {
    param([string]$Prompt = "Är detta korrekt?")

    while ($true) {
        Write-Host ""
        Write-Host $Prompt -ForegroundColor Cyan
        Write-Host "1: Ja" -ForegroundColor Green
        Write-Host "2: Nej / avbryt" -ForegroundColor Yellow
        $answer = Normalize-Choice (Read-Host "Välj")
        switch ($answer) {
            '1' { return $true }
            'J' { return $true }
            'JA' { return $true }
            'Y' { return $true }
            'YES' { return $true }
            '2' { return $false }
            'N' { return $false }
            'NEJ' { return $false }
            'NO' { return $false }
            default { Write-Host "Ogiltigt val. Skriv 1 eller 2." -ForegroundColor Red }
        }
    }
}

function Read-MenuSelection {
    param(
        [Parameter(Mandatory=$true)][string]$Prompt,
        [Parameter(Mandatory=$true)][int]$Min,
        [Parameter(Mandatory=$true)][int]$Max,
        [bool]$AllowBack = $true,
        [bool]$AllowQuit = $true
    )

    while ($true) {
        $raw = Read-Host $Prompt
        $choice = Normalize-Choice $raw
        if ($AllowQuit -and $choice -eq 'Q') { return [pscustomobject]@{ Mode='QUIT'; Number=0 } }
        if ($AllowBack -and $choice -eq 'B') { return [pscustomobject]@{ Mode='BACK'; Number=0 } }

        [int]$number = 0
        if ([int]::TryParse($raw, [ref]$number) -and $number -ge $Min -and $number -le $Max) {
            return [pscustomobject]@{ Mode='SELECT'; Number=$number }
        }

        if ($AllowBack -and $AllowQuit) {
            Write-Host ("Ogiltigt val. Ange {0}-{1}, B eller Q." -f $Min, $Max) -ForegroundColor Red
        }
        elseif ($AllowBack) {
            Write-Host ("Ogiltigt val. Ange {0}-{1} eller B." -f $Min, $Max) -ForegroundColor Red
        }
        else {
            Write-Host ("Ogiltigt val. Ange {0}-{1}." -f $Min, $Max) -ForegroundColor Red
        }
    }
}

# =====================[ Inventory read/write helpers ]=====================

function Get-InventoryWorksheet {
    param([Parameter(Mandatory=$true)]$Package)

    $sheet = $Package.Workbook.Worksheets[1]
    if (-not $sheet) { throw "Blad 1 saknas i raw_data.xlsx." }
    if (-not $sheet.Dimension) { throw "Blad 1 saknar data." }
    return $sheet
}

function Get-InventoryRowSnapshot {
    param(
        [Parameter(Mandatory=$true)]$Sheet,
        [Parameter(Mandatory=$true)][int]$RowNumber
    )

    return [pscustomobject]@{
        Row         = $RowNumber
        PN          = $Sheet.Cells[$RowNumber,$InventoryColumns.PN].Text
        Lot         = $Sheet.Cells[$RowNumber,$InventoryColumns.Lot].Text
        Exp         = $Sheet.Cells[$RowNumber,$InventoryColumns.Exp].Text
        Qty         = $Sheet.Cells[$RowNumber,$InventoryColumns.Qty].Text
        LastUpdate  = $Sheet.Cells[$RowNumber,$InventoryColumns.LastUpdate].Text
        Signature   = $Sheet.Cells[$RowNumber,$InventoryColumns.Signature].Text
        Description = $Sheet.Cells[$RowNumber,$InventoryColumns.Description].Text
    }
}

function Get-InventoryRowsByPN {
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [Parameter(Mandatory=$true)][string]$PN
    )

    $package = $null
    $rows = @()
    try {
        $package = Open-ExcelPackageWithRetry -Path $FilePath
        if (-not $package) { return @() }

        $sheet = Get-InventoryWorksheet -Package $package
        $rowCount = $sheet.Dimension.End.Row
        for ($i = 2; $i -le $rowCount; $i++) {
            if ($sheet.Cells[$i,$InventoryColumns.PN].Text -eq $PN) {
                $rows += (Get-InventoryRowSnapshot -Sheet $sheet -RowNumber $i)
                if ($rows.Count -eq 4) { break }
            }
        }
    }
    finally {
        if ($package) { $package.Dispose() }
    }

    return $rows
}

function Show-InventoryRows {
    param([Parameter(Mandatory=$true)][object[]]$Rows)

    $index = 1
    foreach ($row in $Rows) {
        Write-Host ("{0}: Lot: {1} | Exp: {2} | Qty: {3} | Sign: {4}" -f `
            $index, $row.Lot, $row.Exp, $row.Qty, $row.Signature) -ForegroundColor Green
        $index++
    }
}

function Test-InventoryRowStillMatches {
    param(
        [Parameter(Mandatory=$true)]$Expected,
        [Parameter(Mandatory=$true)]$Current
    )

    return (
        $Expected.PN  -eq $Current.PN  -and
        $Expected.Lot -eq $Current.Lot -and
        $Expected.Exp -eq $Current.Exp -and
        $Expected.Qty -eq $Current.Qty
    )
}

function Get-InventoryActionName {
    param(
        [string]$OldLot, [string]$OldExp, [string]$OldQty,
        [string]$NewLot, [string]$NewExp, [string]$NewQty
    )

    if ($NewLot -eq 'N/A' -and $NewExp -eq 'N/A' -and $NewQty -eq 'N/A') {
        return 'REMOVE'
    }
    elseif ($OldLot -eq 'N/A' -and $OldExp -eq 'N/A' -and $OldQty -eq 'N/A' -and
            ($NewLot -ne 'N/A' -or $NewExp -ne 'N/A' -or $NewQty -ne 'N/A')) {
        return 'ADD'
    }
    elseif ($OldLot -eq $NewLot -and $OldExp -eq $NewExp -and $OldQty -ne $NewQty) {
        return 'QTY'
    }
    else {
        return 'OVERWRITE'
    }
}

function Read-InventoryChangeRequest {
    param([Parameter(Mandatory=$true)]$Current)

    Write-Host "=============================================" -ForegroundColor Cyan
    Write-Host ("Vald post: PN: {0}" -f $Current.PN) -ForegroundColor Cyan
    Write-Host ("Nuvarande: Lot={0}, Exp={1}, Qty={2}" -f $Current.Lot, $Current.Exp, $Current.Qty) -ForegroundColor DarkYellow
    Write-Host ""
    Write-Host "Vad vill du uppdatera?"
    Write-Host "1: Nytt Lotnummer, Exp och Qty" -ForegroundColor Magenta
    Write-Host "2: Endast kvantitet" -ForegroundColor Magenta
    Write-Host "3: Ta bort post (markeras som N/A)" -ForegroundColor Magenta
    Write-Host "B: Back"

    $selection = Read-MenuSelection -Prompt "Välj" -Min 1 -Max 3 -AllowBack:$true -AllowQuit:$true
    if ($selection.Mode -ne 'SELECT') {
        return [pscustomobject]@{ Cancelled=$true; Quit=($selection.Mode -eq 'QUIT') }
    }

    $newLot = $Current.Lot
    $newExp = $Current.Exp
    $newQty = $Current.Qty
    $changeType = ''

    switch ($selection.Number) {
        1 {
            $lot = Read-RequiredText -Prompt "Ange Lotnummer"
            if ($lot.Cancelled) { return [pscustomobject]@{ Cancelled=$true; Quit=($lot.Choice -eq 'Q') } }
            $newLot = $lot.Value
            $exp = Read-ExpiryDateInput
            if ($exp.Cancelled) { return [pscustomobject]@{ Cancelled=$true; Quit=($exp.Choice -eq 'Q') } }
            $newExp = $exp.Value
            $qty = Read-RequiredText -Prompt "Ange antal"
            if ($qty.Cancelled) { return [pscustomobject]@{ Cancelled=$true; Quit=($qty.Choice -eq 'Q') } }
            $newQty = $qty.Value
            $changeType = 'FullUpdate'
        }
        2 {
            $qty = Read-RequiredText -Prompt "Ange nytt antal"
            if ($qty.Cancelled) { return [pscustomobject]@{ Cancelled=$true; Quit=($qty.Choice -eq 'Q') } }
            $newQty = $qty.Value
            $changeType = 'QuantityOnly'
        }
        3 {
            $newLot = 'N/A'
            $newExp = 'N/A'
            $newQty = 'N/A'
            $changeType = 'Remove'
        }
    }

    if ($Current.Lot -eq $newLot -and $Current.Exp -eq $newExp -and $Current.Qty -eq $newQty) {
        Write-Host "Inga ändringar jämfört med befintligt värde. Ingen uppdatering/loggning görs." -ForegroundColor Yellow
        return [pscustomobject]@{ Cancelled=$true; Quit=$false }
    }

    Write-Host ""
    Write-Host "Sammanfattning av ändring:" -ForegroundColor Cyan
    Write-Host ("PN        : {0}" -f $Current.PN) -ForegroundColor DarkYellow
    Write-Host ("Gammalt   : Lot={0}, Exp={1}, Qty={2}" -f $Current.Lot, $Current.Exp, $Current.Qty) -ForegroundColor DarkYellow
    Write-Host ("Nytt      : Lot={0}, Exp={1}, Qty={2}" -f $newLot, $newExp, $newQty) -ForegroundColor DarkYellow

    $prompt = "Bekräfta att ändringen ska sparas"
    if ($changeType -eq 'Remove') {
        $prompt = "Bekräfta BORTTAGNING. Posten markeras som N/A"
    }
    if (-not (Confirm-Action -Prompt $prompt)) {
        Write-Host "Inga ändringar sparades." -ForegroundColor Yellow
        return [pscustomobject]@{ Cancelled=$true; Quit=$false }
    }

    return [pscustomobject]@{
        Cancelled  = $false
        Quit       = $false
        ChangeType = $changeType
        NewLot     = $newLot
        NewExp     = $newExp
        NewQty     = $newQty
    }
}

function Apply-InventoryChangeToSheet {
    param(
        [Parameter(Mandatory=$true)]$Sheet,
        [Parameter(Mandatory=$true)][int]$RowNumber,
        [Parameter(Mandatory=$true)][string]$NewLot,
        [Parameter(Mandatory=$true)][string]$NewExp,
        [Parameter(Mandatory=$true)][string]$NewQty,
        [Parameter(Mandatory=$true)][string]$Signature,
        [Parameter(Mandatory=$true)][string]$ChangeType
    )

    $today = (Get-Date).ToString('yyyy-MM-dd')
    $Sheet.Cells[$RowNumber,$InventoryColumns.Lot].Value = $NewLot
    $Sheet.Cells[$RowNumber,$InventoryColumns.Exp].Value = $NewExp
    $Sheet.Cells[$RowNumber,$InventoryColumns.Qty].Value = $NewQty

    if ($ChangeType -eq 'Remove') {
        $Sheet.Cells[$RowNumber,$InventoryColumns.LastUpdate].Value = 'N/A'
        $Sheet.Cells[$RowNumber,$InventoryColumns.Signature].Value = 'N/A'
    }
    else {
        $Sheet.Cells[$RowNumber,$InventoryColumns.LastUpdate].Value = $today
        $Sheet.Cells[$RowNumber,$InventoryColumns.Signature].Value = $Signature
    }
}

function Invoke-InventoryUpdateTransaction {
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [Parameter(Mandatory=$true)]$ExpectedOld,
        [Parameter(Mandatory=$true)][string]$NewLot,
        [Parameter(Mandatory=$true)][string]$NewExp,
        [Parameter(Mandatory=$true)][string]$NewQty,
        [Parameter(Mandatory=$true)][string]$Signature,
        [Parameter(Mandatory=$true)][string]$ChangeType
    )

    $result = [pscustomobject]@{
        Saved               = $false
        Conflict            = $false
        Message             = ''
        Action              = ''
        Old                 = $null
        New                 = $null
        ExcelRefreshOk      = $false
        ExcelRefreshMessage = ''
        LogResult           = ''
    }

    $updateLockPath = "$FilePath.update.lock"
    $updateLockHandle = $null

    try {
        # Låset tas först när ändringen faktiskt ska sparas.
        # Det gör att andra användare inte blockeras medan någon sitter i menyerna.
        $updateLockHandle = Acquire-LockFile -LockPath $updateLockPath -Purpose 'uppdatering av raw_data.xlsx' -TimeoutSec 120

        $package = $null
        try {
            $package = Open-ExcelPackageWithRetry -Path $FilePath
            if (-not $package) { throw "Kunde inte öppna raw_data.xlsx." }

            $sheet = Get-InventoryWorksheet -Package $package
            $current = Get-InventoryRowSnapshot -Sheet $sheet -RowNumber ([int]$ExpectedOld.Row)
            $result.Old = $current

            if (-not (Test-InventoryRowStillMatches -Expected $ExpectedOld -Current $current)) {
                $result.Conflict = $true
                $result.Message = "Raden har ändrats sedan den visades. Ingen ändring sparades. Läs in P/N på nytt och kontrollera senaste värden."
                return $result
            }

            if (-not $script:RawDataBackedUp) {
                Backup-RawDataFile -FilePath $FilePath
                $script:RawDataBackedUp = $true
            }

            Apply-InventoryChangeToSheet -Sheet $sheet -RowNumber ([int]$ExpectedOld.Row) `
                -NewLot $NewLot -NewExp $NewExp -NewQty $NewQty `
                -Signature $Signature -ChangeType $ChangeType

            $result.Action = Get-InventoryActionName -OldLot $current.Lot -OldExp $current.Exp -OldQty $current.Qty `
                -NewLot $NewLot -NewExp $NewExp -NewQty $NewQty

            $package.Save()
            $result.Saved = $true
            $result.New = Get-InventoryRowSnapshot -Sheet $sheet -RowNumber ([int]$ExpectedOld.Row)
        }
        finally {
            if ($package) { $package.Dispose() }
        }

        if ($result.Saved -and $script:ExcelOpenSave_Enabled) {
            try {
                Invoke-WithRetry -MaxAttempts 3 -BaseDelayMs 350 -Action {
                    Invoke-ExcelOpenSave -Path $FilePath -TimeoutSec $script:ExcelOpenSave_TimeoutSec | Out-Null
                }
                $result.ExcelRefreshOk = $true
                $result.ExcelRefreshMessage = 'raw_data.xlsx öppnad + sparad via Excel.'
            }
            catch {
                $result.ExcelRefreshOk = $false
                $result.ExcelRefreshMessage = "EPPlus sparade filen, men Excel open/save misslyckades: $($_.Exception.Message)"
            }
        }
    }
    catch {
        $result.Message = "Kunde inte spara ändringen: $($_.Exception.Message)"
    }
    finally {
        if ($updateLockHandle) { Release-LockFile -LockHandle $updateLockHandle -LockPath $updateLockPath }
    }

    return $result
}

function Write-LogResultMessage {
    param(
        [Parameter(Mandatory=$true)][string]$LogResult,
        [Parameter(Mandatory=$true)][string]$Action
    )

    if ($LogResult -eq 'MAIN') {
        Write-Host ("`n✅ Uppdatering sparad + loggad i CSV ({0})." -f $Action) -ForegroundColor Green
    }
    elseif ($LogResult -like 'SPOOL:*') {
        Write-Host "`n⚠ Uppdatering sparad. Huvudloggen var låst/otillgänglig, men loggraden sparades i spool och flushas automatiskt nästa gång." -ForegroundColor Yellow
        Write-Host ("   {0}" -f ($LogResult -replace '^SPOOL:', '')) -ForegroundColor DarkYellow
    }
    elseif ($LogResult -like 'EMERGENCY:*') {
        Write-Host "`n⚠ Uppdatering sparad. Huvudlogg och spool misslyckades, men raden finns i emergency-logg bredvid skriptet." -ForegroundColor Yellow
        Write-Host ("   {0}" -f ($LogResult -replace '^EMERGENCY:', '')) -ForegroundColor DarkYellow
    }
    else {
        Write-Host ("`n✅ Uppdatering sparad. Loggresultat: {0}" -f $LogResult) -ForegroundColor Green
    }
}

# =====================[ Core: Update inventory ]=====================

function Update-ExcelInventory {
    param([Parameter(Mandatory=$true)][string]$FilePath)

    while ($true) {
        Show-AppHeader -Title "Uppdatera Kontrollprovsfil"
        Write-Host "Ange P/N eller skriv [Q] för att avbryta" -ForegroundColor Cyan
        $pnToUpdate = Read-Host "P/N"
        $pnChoice = Normalize-Choice $pnToUpdate
        if ($pnChoice -eq 'Q') { return }
        if ([string]::IsNullOrWhiteSpace($pnToUpdate)) {
            Write-Host "P/N får inte vara tomt." -ForegroundColor Yellow
            Pause-AnyKey
            continue
        }
        $pnToUpdate = $pnToUpdate.Trim()

        $foundRows = @(Get-InventoryRowsByPN -FilePath $FilePath -PN $pnToUpdate)
        if ($foundRows.Count -eq 0) {
            Write-Host ("Inget P/N hittades som matchar '{0}'." -f $pnToUpdate) -ForegroundColor Red
            Pause-AnyKey
            continue
        }

        while ($true) {
            Show-AppHeader -Title "Uppdatera Kontrollprovsfil"
            Write-Host ("P/N: {0}" -f $pnToUpdate) -ForegroundColor Cyan
            Write-Host ""
            Show-InventoryRows -Rows $foundRows
            Write-Host ""
            Write-Host "B: Back till P/N-sökning | Q: Avsluta" -ForegroundColor DarkGray

            $rowChoice = Read-MenuSelection -Prompt ("Välj post att uppdatera (1-{0})" -f $foundRows.Count) -Min 1 -Max $foundRows.Count -AllowBack:$true -AllowQuit:$true
            if ($rowChoice.Mode -eq 'QUIT') { return }
            if ($rowChoice.Mode -eq 'BACK') { break }

            $selected = $foundRows[$rowChoice.Number - 1]
            $request = Read-InventoryChangeRequest -Current $selected
            if ($request.Quit) { return }
            if ($request.Cancelled) {
                Pause-AnyKey
                continue
            }

            $sigPrompt = 'Ange din signatur'
            if ($request.ChangeType -eq 'Remove') { $sigPrompt = 'Ange signatur för borttagning' }
            $userSignature = Get-UserSignature -Prompt $sigPrompt

            $tx = Invoke-InventoryUpdateTransaction -FilePath $FilePath -ExpectedOld $selected `
                -NewLot $request.NewLot -NewExp $request.NewExp -NewQty $request.NewQty `
                -Signature $userSignature -ChangeType $request.ChangeType

            if ($tx.Conflict) {
                Write-Host "`n⚠ Ingen ändring sparades." -ForegroundColor Yellow
                Write-Host $tx.Message -ForegroundColor Yellow
                if ($tx.Old) {
                    Write-Host ("Aktuellt värde nu: Lot={0}, Exp={1}, Qty={2}" -f $tx.Old.Lot, $tx.Old.Exp, $tx.Old.Qty) -ForegroundColor DarkYellow
                }
                $foundRows = @(Get-InventoryRowsByPN -FilePath $FilePath -PN $pnToUpdate)
                Pause-AnyKey
                continue
            }

            if (-not $tx.Saved) {
                Write-Host "`n❌ Ändringen sparades inte." -ForegroundColor Red
                Write-Host $tx.Message -ForegroundColor Red
                Pause-AnyKey
                continue
            }

            if ($tx.ExcelRefreshMessage) {
                if ($tx.ExcelRefreshOk) {
                    Write-Host ("✅ {0}" -f $tx.ExcelRefreshMessage) -ForegroundColor Green
                }
                else {
                    Write-Host ("⚠ {0}" -f $tx.ExcelRefreshMessage) -ForegroundColor Yellow
                }
            }

            try {
                $logResult = Write-UpdateLogRow -PN $pnToUpdate -Signature $userSignature -Action $tx.Action -RowNumber ([int]$selected.Row) `
                    -OldLot $tx.Old.Lot -OldExp $tx.Old.Exp -OldQty $tx.Old.Qty `
                    -NewLot $request.NewLot -NewExp $request.NewExp -NewQty $request.NewQty
                $tx.LogResult = $logResult
                Write-LogResultMessage -LogResult $logResult -Action $tx.Action
            }
            catch {
                Write-Host "⚠ Uppdatering sparad, men kunde inte skriva någon loggrad. Fel: $($_.Exception.Message)" -ForegroundColor Yellow
            }

            $foundRows = @(Get-InventoryRowsByPN -FilePath $FilePath -PN $pnToUpdate)

            Write-Host ""
            Write-Host "Nästa steg:" -ForegroundColor Cyan
            Write-Host "1: Sök nytt P/N" -ForegroundColor Magenta
            Write-Host "2: Avsluta" -ForegroundColor Magenta
            Write-Host "Enter: Fortsätt med samma P/N" -ForegroundColor Magenta
            $nextAction = Normalize-Choice (Read-Host "Välj")
            if ($nextAction -eq '1') { break }
            if ($nextAction -eq '2' -or $nextAction -eq 'Q') { return }
        }
    }
}

# =====================[ Reports (kept, no logging) ]=====================

function Generate-InventoryReport {
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [Parameter(Mandatory=$true)][string]$OutputDir
    )

    $package = $null
    try {
        Clear-Host
        Write-Host "==== Inventeringsrapport ====" -ForegroundColor Cyan
        Write-Host "OBS: Detta är en XLSX-rapport, inte audit-loggen. Audit-loggen är fortsatt CSV-only." -ForegroundColor DarkGray

        $package = Open-ExcelPackageWithRetry -Path $FilePath
        if (-not $package) { return }

        $sheet = $package.Workbook.Worksheets[1]
        if (-not $sheet) { Write-Host "Blad 1 saknas, avbryter..." -ForegroundColor Red; return }
        if (-not $sheet.Dimension) { Write-Host "Bladet verkar vara tomt." -ForegroundColor Yellow; return }

        $rowCount = $sheet.Dimension.End.Row
        $data = @()
        $skippedRows = 0

        for ($i=2; $i -le $rowCount; $i++) {
            if (-not (Test-InventoryRowIsActive -Sheet $sheet -Row $i)) {
                $skippedRows++
                continue
            }

            $data += [pscustomobject]@{
                PN              = Get-InventoryCellText -Sheet $sheet -Row $i -Column $InventoryColumns.PN
                LotNr           = Get-InventoryCellText -Sheet $sheet -Row $i -Column $InventoryColumns.Lot
                Exp             = Get-InventoryCellText -Sheet $sheet -Row $i -Column $InventoryColumns.Exp
                Qty             = Get-InventoryCellText -Sheet $sheet -Row $i -Column $InventoryColumns.Qty
                LabbCode        = Get-InventoryCellText -Sheet $sheet -Row $i -Column $InventoryColumns.LabbCode
                LabbDescription = Get-InventoryCellText -Sheet $sheet -Row $i -Column $InventoryColumns.LabbDescription
            }
        }

        if ($data.Count -eq 0) {
            Write-Host "Ingen aktiv inventeringsdata hittades. Rapport skapas inte." -ForegroundColor Yellow
            Write-Host "Filtrerade bort $skippedRows rad(er) med tomma/N/A-värden i PN, Lot, Exp eller Qty." -ForegroundColor DarkYellow
            return
        }

        if (-not (Test-Path -LiteralPath $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }

        $dateStamp = (Get-Date -Format "yyyyMMdd")
        $xlsxPath  = Join-Path $OutputDir ("InventoryReport_{0}.xlsx" -f $dateStamp)
        if (Test-Path -LiteralPath $xlsxPath) { Remove-Item -LiteralPath $xlsxPath -Force }

        $invPkg = New-Object OfficeOpenXml.ExcelPackage
        try {
            $ws = $invPkg.Workbook.Worksheets.Add("Inventory")

            $ws.Cells["A1"].Value = "PN"
            $ws.Cells["B1"].Value = "LotNr"
            $ws.Cells["C1"].Value = "Exp"
            $ws.Cells["D1"].Value = "Qty"
            $ws.Cells["E1"].Value = "LabbCode"
            $ws.Cells["F1"].Value = "LabbDescription"

            $r=2
            foreach ($it in $data) {
                $ws.Cells["A$r"].Value = $it.PN
                $ws.Cells["B$r"].Value = $it.LotNr
                $ws.Cells["C$r"].Value = $it.Exp
                $ws.Cells["D$r"].Value = $it.Qty
                $ws.Cells["E$r"].Value = $it.LabbCode
                $ws.Cells["F$r"].Value = $it.LabbDescription
                $r++
            }

            $lastRow = $r-1
            $used = $ws.Cells["A1:F$lastRow"]
            $hdr = $ws.Cells["A1:F1"]
            $hdr.Style.Font.Bold = $true
            $ws.View.FreezePanes(2,1)
            $used.AutoFitColumns()

            $invPkg.SaveAs((New-Object System.IO.FileInfo($xlsxPath)))
            Write-Host "✅ Inventeringsrapport genererad: $xlsxPath" -ForegroundColor Green
            Write-Host "Aktiva rader i rapport: $($data.Count)" -ForegroundColor Green
            Write-Host "Filtrerade bort rader med tomma/N/A-värden i PN, Lot, Exp eller Qty: $skippedRows" -ForegroundColor DarkYellow
            try { Invoke-Item $xlsxPath } catch {}
        } finally { if ($invPkg) { $invPkg.Dispose() } }
    }
    catch {
        Write-Host "Fel vid inventeringsrapport: $($_.Exception.Message)" -ForegroundColor Red
    }
    finally { if ($package) { $package.Dispose() } }
}

function Generate-ExpiringPNsReport {
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [Parameter(Mandatory=$true)][string]$OutputDir
    )

    $package = $null
    try {
        Clear-Host
        Write-Host "==== Material med kort utgångsdatum ====" -ForegroundColor Cyan
        Write-Host "OBS: Detta är en XLSX-rapport, inte audit-loggen. Audit-loggen är fortsatt CSV-only." -ForegroundColor DarkGray

        if (-not (Test-Path -LiteralPath $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }

        $package = Open-ExcelPackageWithRetry -Path $FilePath
        if (-not $package) { return }

        $sheet = $package.Workbook.Worksheets[1]
        if (-not $sheet) { Write-Host "Blad saknas, avbryter..." -ForegroundColor Red; return }
        if (-not $sheet.Dimension) { Write-Host "Bladet verkar vara tomt." -ForegroundColor Yellow; return }

        $rowCount  = $sheet.Dimension.End.Row
        $now       = Get-Date
        $lowerDate = $now.AddDays(-15)
        $upperDate = $now.AddDays(30)

        $dateStamp = (Get-Date -Format "yyyyMMdd")
        $xlsxPath  = Join-Path $OutputDir ("ExpiringPNsReport_{0}.xlsx" -f $dateStamp)
        if (Test-Path -LiteralPath $xlsxPath) { Remove-Item -LiteralPath $xlsxPath -Force }

        $repPkg = New-Object OfficeOpenXml.ExcelPackage
        try {
            $ws = $repPkg.Workbook.Worksheets.Add("Expiring")
            $ws.Cells["A1"].Value = "PN"
            $ws.Cells["B1"].Value = "Lotnummer"
            $ws.Cells["C1"].Value = "Exp. Date"
            $ws.Cells["D1"].Value = "Beskrivning"

            $outRow=2
            $skippedRows = 0
            for ($i=2; $i -le $rowCount; $i++) {
                if (-not (Test-InventoryRowIsActive -Sheet $sheet -Row $i)) {
                    $skippedRows++
                    continue
                }

                $expText = Get-InventoryCellText -Sheet $sheet -Row $i -Column $InventoryColumns.Exp
                $expDate = Try-ParseInventoryDate -Text $expText
                if ($expDate -and $expDate -ge $lowerDate -and $expDate -le $upperDate) {
                    $ws.Cells["A$outRow"].Value = Get-InventoryCellText -Sheet $sheet -Row $i -Column $InventoryColumns.PN
                    $ws.Cells["B$outRow"].Value = Get-InventoryCellText -Sheet $sheet -Row $i -Column $InventoryColumns.Lot
                    $ws.Cells["C$outRow"].Value = $expText
                    $ws.Cells["D$outRow"].Value = Get-InventoryCellText -Sheet $sheet -Row $i -Column $InventoryColumns.Description
                    $outRow++
                }
            }

            if ($outRow -gt 2) {
                $lastRow = $outRow-1
                $ws.Cells["A1:D1"].Style.Font.Bold = $true
                $ws.View.FreezePanes(2,1)
                $ws.Cells["A1:D$lastRow"].AutoFitColumns()
                $repPkg.SaveAs((New-Object System.IO.FileInfo($xlsxPath)))
                Write-Host "✅ Rapport genererad: $xlsxPath" -ForegroundColor Green
                Write-Host "Rader i rapport: $($lastRow - 1)" -ForegroundColor Green
                Write-Host "Filtrerade bort rader med tomma/N/A-värden i PN, Lot, Exp eller Qty: $skippedRows" -ForegroundColor DarkYellow
                try { Invoke-Item $xlsxPath } catch {}
            } else {
                Write-Host "Inga aktiva poster hittades inom datumintervallet." -ForegroundColor Yellow
                Write-Host "Filtrerade bort rader med tomma/N/A-värden i PN, Lot, Exp eller Qty: $skippedRows" -ForegroundColor DarkYellow
            }
        } finally { if ($repPkg) { $repPkg.Dispose() } }
    }
    catch {
        Write-Host "Fel vid generering: $($_.Exception.Message)" -ForegroundColor Red
    }
    finally { if ($package) { $package.Dispose() } }
}

function ShowProductInfo {
    param([Parameter(Mandatory=$true)][string]$FilePath)

    Clear-Host
    Write-Host "================ Sök på Produkt för material =================" -ForegroundColor Cyan
    $productName = Read-Host "`nAnge produktnamn"
    if ([string]::IsNullOrWhiteSpace($productName)) { return }

    $package = $null
    try {
        $package = Open-ExcelPackageWithRetry -Path $FilePath
        if (-not $package) { return }

        $sheet = $package.Workbook.Worksheets[1]
        if (-not $sheet) { Write-Host "Inget blad hittades." -ForegroundColor Red; return }

        $rowCount = $sheet.Dimension.End.Row
        $productInfo = @()

        for ($i=2; $i -le $rowCount; $i++) {
            if (-not (Test-InventoryRowIsActive -Sheet $sheet -Row $i)) { continue }

            for ($j=$InventoryColumns.ProductStartCol; $j -le $InventoryColumns.ProductEndCol; $j++) {
                $cellProduct = Get-InventoryCellText -Sheet $sheet -Row $i -Column $j
                if ($cellProduct -eq $productName) {
                    $productInfo += [pscustomobject]@{
                        PN          = Get-InventoryCellText -Sheet $sheet -Row $i -Column $InventoryColumns.PN
                        LotNr       = Get-InventoryCellText -Sheet $sheet -Row $i -Column $InventoryColumns.Lot
                        Exp         = Get-InventoryCellText -Sheet $sheet -Row $i -Column $InventoryColumns.Exp
                        Description = Get-InventoryCellText -Sheet $sheet -Row $i -Column $InventoryColumns.Description
                    }
                }
            }
        }

        if ($productInfo.Count -gt 0) {
            Write-Host "`nProduktinformation hittades:" -ForegroundColor Green
            $productInfo | Format-Table -AutoSize
        } else {
            Write-Host "`nIngen information hittades för '$productName'." -ForegroundColor Yellow
        }
    }
    finally { if ($package) { $package.Dispose() } }
}

function Collect-Feedback {
    Clear-Host
    Write-Host "========== Feedback ==========" -ForegroundColor Cyan
    Write-Host "Skriv feedback och tryck Enter. Tom rad avbryter." -ForegroundColor DarkGray
    Write-Host "OBS: Detta är inte audit-loggen. Audit-loggen är fortsatt UpdateLog_Kontrollprovsfil.csv." -ForegroundColor DarkGray

    $feedback = Read-Host "`nFeedback"
    if ([string]::IsNullOrWhiteSpace($feedback)) {
        Write-Host "Ingen feedback sparad." -ForegroundColor Yellow
        return
    }

    try {
        $rawDir = Split-Path $RawDataPath -Parent
        $feedbackPath = Join-Path $rawDir "Feedback_Kontrollprovsfil.csv"
        $header = 'Timestamp;User;Machine;Feedback'
        $line = ((@(
            (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'),
            $env:USERNAME,
            $env:COMPUTERNAME,
            $feedback
        ) | ForEach-Object { ConvertTo-LogCsvCell -Value $_ }) -join ';')

        Invoke-WithFileLock -Path $feedbackPath -Purpose 'feedbacklogg' -TimeoutSec 30 -Action {
            if (-not (Test-Path -LiteralPath $feedbackPath)) {
                Write-TextLineUtf8Unlocked -Path $feedbackPath -Line $header -Append:$false -Bom:$true
            }
            Write-TextLineUtf8Unlocked -Path $feedbackPath -Line $line -Append:$true -Bom:$false
        } | Out-Null

        Write-Host "✅ Feedback sparad: $feedbackPath" -ForegroundColor Green
    }
    catch {
        Write-Host "⚠ Kunde inte spara feedback: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}



# =====================[ Main menu ]=====================

function Test-StartupPrerequisites {
    $ok = $true

    if (-not (Test-Path -LiteralPath $RawDataPath)) {
        Write-Host "❌ Hittar inte rådatafilen:" -ForegroundColor Red
        Write-Host "   $RawDataPath" -ForegroundColor Yellow
        $ok = $false
    }

    $rawDir = Split-Path $RawDataPath -Parent
    if (-not (Test-Path -LiteralPath $rawDir)) {
        Write-Host "❌ Hittar inte mappen för rådatafilen:" -ForegroundColor Red
        Write-Host "   $rawDir" -ForegroundColor Yellow
        $ok = $false
    }

    $logDir = Split-Path $script:UpdateLogCsvPath -Parent
    if (-not [string]::IsNullOrWhiteSpace($logDir) -and -not (Test-Path -LiteralPath $logDir)) {
        try {
            New-Item -ItemType Directory -Path $logDir -Force | Out-Null
        }
        catch {
            Write-Host "❌ Kunde inte skapa loggmappen:" -ForegroundColor Red
            Write-Host "   $logDir" -ForegroundColor Yellow
            Write-Host "   $($_.Exception.Message)" -ForegroundColor Yellow
            $ok = $false
        }
    }

    return $ok
}

function Main-Menu {
    do {
        Show-AppHeader -Title "Huvudmeny"
        Write-Host "1: Uppdatera Kontrollprovsfil (lösenord krävs)" -ForegroundColor Magenta
        Write-Host "2: Generera inventeringsrapport (lösenord krävs)" -ForegroundColor Magenta
        Write-Host "3: Visa material med kort utgångsdatum"
        Write-Host "4: Visa materialinformation för produkt"
        Write-Host "5: Feedback / förbättringsförslag"
        Write-Host "6: Avsluta"
        Write-Host "==============================================================" -ForegroundColor Cyan
        Write-Host "Audit-logg: CSV-only. Rapportval 2-3 skapar XLSX-rapporter, inte loggfiler." -ForegroundColor DarkGray

        $choice = Normalize-Choice (Read-Host "Välj")
        switch ($choice) {
            '1' { if (Request-Password) { Update-ExcelInventory -FilePath $RawDataPath } }
            '2' { if (Request-Password) { Generate-InventoryReport -FilePath $RawDataPath -OutputDir $OutputDir } }
            '3' { Generate-ExpiringPNsReport -FilePath $RawDataPath -OutputDir $OutputDir }
            '4' { ShowProductInfo -FilePath $RawDataPath }
            '5' { Collect-Feedback }
            '6' { return }
            'Q' { return }
            default {
                Write-Host "Ogiltigt val." -ForegroundColor Red
                Pause-AnyKey
                continue
            }
        }

        Pause-AnyKey
    } while ($true)
}

# =====================[ Startup ]=====================

Show-AppHeader -Title "Startar"

if (-not (Test-StartupPrerequisites)) {
    Write-Host "`nSkriptet avbryts eftersom en eller flera grundförutsättningar saknas." -ForegroundColor Red
    Pause-AnyKey
    exit 1
}

try {
    Ensure-UpdateLogCsv -Path $script:UpdateLogCsvPath
    Flush-UpdateLogSpool -MainCsvPath $script:UpdateLogCsvPath
}
catch {
    Write-Host "❌ Kunde inte initiera eller reparera uppdateringsloggen." -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Yellow
    Pause-AnyKey
    exit 1
}

Main-Menu
