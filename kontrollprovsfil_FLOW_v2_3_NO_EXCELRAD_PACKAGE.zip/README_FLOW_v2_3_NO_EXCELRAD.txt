KONTROLLPROVSFIL - FLOW v2.3 NO EXCELRAD
=============================================

Syfte
-----
Den här versionen bygger på FLOW v2.2 REPORT FIX.
Enda sakliga ändringen i v2.3 är att Excelrad inte längre visas för användaren i normalflödet.

Vad är ändrat från v2.2?
------------------------
- Listan över poster visar nu endast:
  Valnummer, Lot, Exp, Qty och Sign.
- Vald post visar PN, men inte Excelrad.
- Bekräftelserutan visar PN, gammalt värde och nytt värde, men inte Excelrad.
- Prompten säger "Välj post att uppdatera" i stället för "Välj rad att uppdatera".

Vad är inte ändrat?
-------------------
- Robust CSV-loggning är kvar.
- Rapportfunktionerna är kvar.
- Filtrering av N/A i rapporterna är kvar.
- Låsning av raw_data.xlsx vid faktisk sparning är kvar.
- Intern radposition används fortfarande tekniskt för att skriptet ska kunna uppdatera exakt rätt celler och kontrollera konflikt innan sparning.

Viktigt om audit-loggen
-----------------------
För bakåtkompatibilitet har audit-loggens tekniska kolumnstruktur inte ändrats i denna version.
Det betyder att befintlig UpdateLog_Kontrollprovsfil.csv inte behöver roteras eller startas om bara för att UI-texten Excelrad tas bort.

Rekommenderad test
------------------
1. Kör först mot en kopia av raw_data.xlsx/raw_data.xlsm.
2. Testa menyval 1 och kontrollera att inga Excelrad-värden visas i flödet.
3. Testa menyval 2-4 och kontrollera att rapporterna fortfarande fungerar.
4. Kontrollera att UpdateLog_Kontrollprovsfil.csv fortfarande fylls på.

.lnk
----
Om er .lnk pekar på ett specifikt scriptnamn kan du antingen:
- uppdatera .lnk till den nya ps1-filen, eller
- döpa denna ps1-fil till samma namn som .lnk redan använder.
