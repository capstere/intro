# WORK ORDER — v1.3.5-phase9-safe

1. Utgå från `v1.3.4-phase8b-hotfix1`.
2. Flytta endast **hela funktionsdefinitioner** ur `Main.ps1`.
3. Skapa nya `App/*`-filer för de extraherade funktionerna.
4. Lägg in dot-sourcing av nya `App/*`-filer direkt efter modulimporterna i `Main.ps1`.
5. Låt all top-level UI/runtime-kod ligga kvar i `Main.ps1`.
6. Uppdatera `Version.txt` till `1.3.5-phase9-safe`.
7. Kör i Windows PowerShell 5.1 och verifiera start, scan och build.
