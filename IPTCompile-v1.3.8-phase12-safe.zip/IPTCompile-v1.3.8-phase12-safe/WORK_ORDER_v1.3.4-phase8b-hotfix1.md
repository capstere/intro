﻿# Work order — v1.3.4 phase 8b hotfix1

1. Copy the working `phase8-hotfix3` baseline.
2. Recover the original contiguous header-compare block from `Modules/DataHelpers.ps1`.
3. Place that block in `Core/HeaderComparison.ps1` without editing the internal logic.
4. Update `Modules/DataHelpers.ps1` shim to load the new file.
5. Bump version to `1.3.4-phase8b-hotfix1`.
6. Keep all runtime/UI code untouched.
