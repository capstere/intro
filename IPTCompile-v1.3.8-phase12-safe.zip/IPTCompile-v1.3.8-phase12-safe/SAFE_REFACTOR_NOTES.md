# SAFE_REFACTOR_NOTES — v1.3.8-phase12-safe

Utgångspunkt: IPTCompile-v1.3.7-phase11-safe.

Vad som faktiskt gjordes:
- Flyttade hela top-level startup-/bootstrapblocket ur Main.ps1 till App/StartupPreamble.ps1.
- Flyttade hela menyuppsättningsblocket ur Main.ps1 till App/MenuSetup.ps1.
- Flyttade hela post-init-/tooltip-/slutkörningsblocket ur Main.ps1 till App/PostInit.ps1.
- Behöll körordning genom att dot-source:a blocken på exakt motsvarande plats i Main.ps1.
- Ändrade inte någon funktionskropp i modulerna.

Det som medvetet inte rördes:
- top-level UI-komposition i mitten av Main.ps1
- event wiring i övriga delar
- Application.Run-semantik (ligger nu i App/PostInit.ps1 men körs fortfarande från samma position)
- shim-strukturen för Modules/*

Målet med fas 12:
- göra Main.ps1 mindre
- samla konstanter/guard-/startupkod tydligare
- minska upprepning och öka läsbarhet utan att börja gissa om runtime-logik
