# WORK_ORDER_v1.3.4-phase8-safe.md

Objective: safely split `Modules/DataHelpers.ps1` while preserving runtime behavior.

Completed steps:
1. Copied the working `v1.3.3-phase7-safe` project as the baseline.
2. Parsed `Modules/DataHelpers.ps1` and extracted only complete function blocks.
3. Created these files:
   - `Infrastructure/ExcelEpplus.ps1`
   - `Infrastructure/Csv.ps1`
   - `Infrastructure/FileStaging.ps1`
   - `Core/AssayNormalization.ps1`
   - `Core/HeaderParsing.ps1`
   - `Core/OutputPlanning.ps1`
4. Replaced `Modules/DataHelpers.ps1` with a shim that dot-sources the new files.
5. Updated `Version.txt` to `1.3.4-phase8-safe`.

Recommended smoke test in Windows PowerShell 5.1:
1. Start the app.
2. Confirm no startup parser or command-not-found errors.
3. Load CSV files.
4. Run scan/build.
5. Confirm EPPlus-dependent workbook actions still work.
6. Confirm staging and header parsing still behave as before.
