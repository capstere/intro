﻿# Phase 8b hotfix 1

Base: `IPTCompile-v1.3.4-phase8-hotfix3`

What was fixed:
- Restored the original contiguous worksheet/seal header block from `Modules/DataHelpers.ps1` into `Core/HeaderComparison.ps1`.
- This block includes the following public functions exactly as a unit from the original project:
  - `Extract-WorksheetHeader`
  - `Get-WorksheetHeaderPerSheet`
  - `Compare-WorksheetHeaderSet`
  - `Get-SealTestHeaderPerSheet`
  - `Compare-SealTestHeaderSet`
  - `Extract-SealTestHeader`
- The local embedded helper inside `Compare-WorksheetHeaderSet` (`_canonWorksheet`) was preserved because it is part of the original contiguous block.
- Updated `Modules/DataHelpers.ps1` shim to dot-source `Core/HeaderComparison.ps1`.

Why:
- `Compare-WorksheetHeaderSet` and related header functions were still being called from `Main.ps1` but were not available after the previous split.
- The header compare logic has hidden dependencies and local nested helpers, so it must be moved as a complete block rather than as isolated function names.

What was not changed:
- No top-level WinForms runtime code.
- No event handlers.
- No changes to `Main.ps1` runtime flow.
