# WORK_ORDER — v1.3.8-phase12-safe

1. Skapa App/StartupPreamble.ps1 med originalets rader 1-170 från Main.ps1.
2. Ersätt dessa rader i Main.ps1 med minimal entrypoint som beräknar script path/root och dot-sourcar App/StartupPreamble.ps1.
3. Skapa App/MenuSetup.ps1 med originalets hela menyradsblock.
4. Ersätt samma block i Main.ps1 med en enda dot-source-rad.
5. Skapa App/PostInit.ps1 med originalets tooltip/overwrite-ui/post-init/slutkörningsblock.
6. Ersätt samma slutblock i Main.ps1 med en enda dot-source-rad på samma position.
7. Uppdatera Version.txt till 1.3.8-phase12-safe.
