# IPTCompile v1.3.7-phase11-safe — Work Order

## Goal
Safe phase 11 cleanup with no runtime/event refactor.

## Changes actually performed
- Based on `v1.3.6-phase10-safe`
- Extracted the last remaining function definition from `Main.ps1`
- Added `App/EarlyGuards.ps1`
- Moved `Test-IsBlockedUser` into `App/EarlyGuards.ps1`
- Updated `Main.ps1` to compute `scriptPath` / `ScriptRootPath` earlier and dot-source `App/EarlyGuards.ps1` before the blocked-user check
- Removed the duplicate later `scriptPath` / `ScriptRootPath` assignment from `Main.ps1`
- Updated `Version.txt` to `1.3.7-phase11-safe`

## Intentionally not changed
- No top-level WinForms composition moved
- No event handlers moved
- No `Application.Run(...)` changes
- No new splitting of runtime-heavy blocks
