﻿#region Importering och config
if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    $exe = Join-Path $PSHome 'powershell.exe'
    $scriptPath = if ($PSCommandPath) { $PSCommandPath } else { $MyInvocation.MyCommand.Path }
    Start-Process -FilePath $exe -ArgumentList "-NoProfile -STA -ExecutionPolicy Bypass -File `"$scriptPath`""
    exit
}

# ---- Soft spärr ---
$scriptPath = if ($PSCommandPath) { $PSCommandPath } else { $MyInvocation.MyCommand.Path }
$ScriptRootPath = [System.IO.Path]::GetDirectoryName([System.IO.Path]::GetFullPath($scriptPath))
. (Join-Path $ScriptRootPath 'App\EarlyGuards.ps1')

$BlockedUsers = @(
    # Lägg in i lower-case:
    # 'jesper.fredriksson'
    # 'namn.efternamn',
    # 'domain\namn.efternamn'
)

if (Test-IsBlockedUser -DenyList $BlockedUsers) {
    try {
        [System.Windows.Forms.MessageBox]::Show(
            "Tyvärr – skriptet är avstängt för dig.",
            "IPTCompile",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Stop
        ) | Out-Null
    } catch {
        Write-Host "Tyvärr – skriptet är avstängt för dig." -ForegroundColor Red
    }
    exit 1
}

Add-Type -AssemblyName System.Windows.Forms
try { [System.Windows.Forms.Application]::EnableVisualStyles() } catch {}
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.ComponentModel
try {
    Add-Type -AssemblyName 'Microsoft.VisualBasic' -ErrorAction SilentlyContinue
} catch {}

$installLock = Join-Path $ScriptRootPath '.install.lock'
if (Test-Path -LiteralPath $installLock) {
    $msg = "Install/uppdatering pågår (lock-fil finns): $installLock`nStarta om IPTCompile när uppdateringen är klar."
    try { [System.Windows.Forms.MessageBox]::Show($msg,'IPTCompile') | Out-Null } catch { Write-Host $msg }
    exit 2
}
$PSScriptRoot = $ScriptRootPath
try {
    $cwd = (Get-Location).Path
    Write-Host ("[EXEC] Script={0} | ScriptRoot={1} | CWD={2}" -f $scriptPath, $ScriptRootPath, $cwd)
} catch {}
$modulesRoot = Join-Path $ScriptRootPath 'Modules'

$libRoot = Join-Path $ScriptRootPath 'Lib'
$global:ModulesRoot = $modulesRoot
$global:LibRoot     = $libRoot
# Konstanter: bladnamn, cellreferenser.
# Om jag ändrar i mallen!
$Layout = @{
    # Cellreferenser
    SignatureCell        = 'B47'       # Seal Test signaturcell
    SealActiveCheckCell  = 'H3'        # Cell som avgör om Seal-flik är aktiv
    AssayNameCell        = 'D10'       # Assay-namn i output
    SpInfoStartCell      = 'E1'        # SharePoint info start i Run Information

    # Bladnamn i output-mallen
    SheetRunInfo         = 'Run Information'
    SheetDataSummary     = 'Data Summary'
    SheetExtraSummary    = 'Extra Data Summary'
    SheetResampleSummary = 'Resample Data Summary'
    SheetSealTestInfo    = 'Seal Test Info'
    SheetStfSummary      = 'STF Summary'
    SheetQcSummary       = 'QC Summary'
    SheetKontrollmaterial= 'Kontrollmaterial'
    SheetUtrustning      = 'Utrustningslista'
}

. (Join-Path $modulesRoot 'Config.ps1') -ScriptRoot $ScriptRootPath
. (Join-Path $modulesRoot 'Splash.ps1')
. (Join-Path $modulesRoot 'SharePointClient.ps1')
. (Join-Path $modulesRoot 'UiStyling.ps1')
. (Join-Path $modulesRoot 'Logging.ps1')

try {
    $netRoot = ($env:IPT_NETWORK_ROOT + '').Trim()
    $iptRoot = ($global:IPT_ROOT_EFFECTIVE + '').Trim()
    $iptSrc  = ($global:IPT_ROOT_SOURCE + '').Trim()
    $logPath = ($global:LogPath + '').Trim()
    $jsonl   = ($global:StructuredLogPath + '').Trim()

    if (-not $netRoot) { $netRoot = '<empty>' }
    if (-not $iptRoot) { $iptRoot = '<empty>' }
    if (-not $iptSrc)  { $iptSrc  = '<empty>' }
    if (-not $logPath) { $logPath = '<empty>' }
    if (-not $jsonl)   { $jsonl   = '<empty>' }

    $msg = "Sanity: IPT_NETWORK_ROOT=$netRoot | IPT_ROOT_EFFECTIVE=$iptRoot | IPT_ROOT_SOURCE=$iptSrc | LogPath=$logPath | StructuredLogPath=$jsonl"
    try { Gui-Log -Text $msg -Severity 'Info' -Category 'SANITY' } catch { Write-Host $msg }
} catch { }

. (Join-Path $modulesRoot 'DataHelpers.ps1')
if (-not (Get-Command Get-CellText -ErrorAction SilentlyContinue)) {
    throw "DataHelpers.ps1 laddades inte korrekt: Get-CellText saknas. (Troligen avbruten import p.g.a. fel tidigare i filen.)"
}
. (Join-Path $modulesRoot 'SignatureHelpers.ps1')
. (Join-Path $modulesRoot 'OpenXmlHelpers.ps1')
. (Join-Path $modulesRoot 'RuleEngine.ps1')
. (Join-Path $ScriptRootPath 'App\UiHelpers.ps1')
. (Join-Path $ScriptRootPath 'App\Bootstrap.ps1')
. (Join-Path $ScriptRootPath 'App\UiDialogs.ps1')
. (Join-Path $ScriptRootPath 'App\BuildController.ps1')
. (Join-Path $ScriptRootPath 'App\UiTheme.ps1')


$global:SpEnabled = Get-ConfigFlag -Name 'EnableSharePoint' -Default $true -ConfigOverride $Config
$global:SpAutoConnect = if ($global:SpEnabled) {
    Get-ConfigFlag -Name 'EnableSharePointAutoConnect' -Default $true -ConfigOverride $Config
} else { $false }

$global:StartupReady = $true
$configStatus = $null

try {

    $configStatus = Test-Config
    if ($configStatus) {
        foreach ($err in $configStatus.Errors) { Gui-Log "❌ Konfig-fel: $err" 'Error' }
        foreach ($warn in $configStatus.Warnings) { Gui-Log "⚠️ Konfig-varning: $warn" 'Warn' }
        if (-not $configStatus.Ok) {
            $global:StartupReady = $false
            try { [System.Windows.Forms.MessageBox]::Show("Startkontroll misslyckades. Se logg för detaljer.","Startkontroll") | Out-Null } catch {}
        }
    }
} catch { Gui-Log "❌ Test-Config misslyckades: $($_.Exception.Message)" 'Error'; $global:StartupReady = $false }

$Host.UI.RawUI.WindowTitle = "Startar…"
Show-Splash "Laddar PowerShell…"
$env:PNPPOWERSHELL_UPDATECHECK = 'Off'

$global:SpConnected = $false
$global:SpError     = $null

if ($global:SpAutoConnect) {
    # Autokoppling: starta SPClient-runspace + importera PnP + anslut (synkront under splash)
    $spStartOk = Start-SPClient -ProgressCallback { param($m) Update-Splash $m }
    if ($spStartOk) {
        Update-Splash 'Ansluter till SharePoint…'
        $spConnOk = Connect-SPClient -ProgressCallback { param($m) Update-Splash $m }
        if ($spConnOk) {
            $global:SpConnected = $true
        } else {
            $msg = "Connect-PnPOnline misslyckades: $($global:SpError)"
            Update-Splash $msg
        }
    } else {
        $msg = "PnP-import misslyckades: $($global:SpError)"
        Update-Splash $msg
    }
} elseif (-not $global:SpEnabled) {
    $global:SpError = 'SharePoint avstängt i Config'
    try { Gui-Log "ℹ️ SharePoint är avstängt i konfigurationen." 'Info' } catch {}
} else {
    # SpEnabled = true men AutoConnect = false → snabbstart, SPClient startas vid knapptryck
    $global:SpError = $null
    try { Gui-Log "ℹ️ SharePoint: manuell anslutning (klicka '🔌 Anslut SP' vid behov)." 'Info' } catch {}
}
try { $null = Ensure-EPPlus -Version '4.5.3.3' } catch { Gui-Log "⚠️ EPPlus-förkontroll misslyckades: $($_.Exception.Message)" 'Warn' }
#endregion Importering och config
