# Phase 8 hotfix 1

## Faktisk fix

Felet i `Core/OutputPlanning.ps1` kom av att den säkra splitten av `Modules/DataHelpers.ps1` flyttade funktionerna `Get-ControlTabName` och `Get-MinitabMacro`, men inte de tillhörande top-level index-tabellerna:

- `$AssayMap`
- `$AssayIndex`
- `$MinitabMap`
- `$MinitabIndex`

I originalfilen låg dessa direkt ovanför funktionerna. I phase8-safe blev funktionerna kvar beroende av variabler som aldrig initialiserades, vilket gav null-fel vid `.ContainsKey(...)`.

## Åtgärd

Den här hotfixen återställer exakt dessa top-level tabeller i `Core/OutputPlanning.ps1` och lägger dessutom till null-guard på:

- `$AssayIndex.ContainsKey(...)`
- `$MinitabIndex.ContainsKey(...)`
- `Test-Path -LiteralPath $SlangAssayPath`

Ingen annan runtime-logik ändrades.
