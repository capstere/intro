﻿﻿# Shim created in phase 8 safe refactor.
# Preserves original module load path and public function names.
$__iptShimRoot = if ($PSScriptRoot) { Split-Path -Parent $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
. (Join-Path $__iptShimRoot 'Infrastructure\ExcelEpplus.ps1')
. (Join-Path $__iptShimRoot 'Infrastructure\Csv.ps1')
. (Join-Path $__iptShimRoot 'Infrastructure\FileStaging.ps1')
. (Join-Path $__iptShimRoot 'Core\AssayNormalization.ps1')
. (Join-Path $__iptShimRoot 'Core\HeaderParsing.ps1')
. (Join-Path $__iptShimRoot 'Core\HeaderComparison.ps1')
. (Join-Path $__iptShimRoot 'Core\OutputPlanning.ps1')
Remove-Variable __iptShimRoot -ErrorAction SilentlyContinue
