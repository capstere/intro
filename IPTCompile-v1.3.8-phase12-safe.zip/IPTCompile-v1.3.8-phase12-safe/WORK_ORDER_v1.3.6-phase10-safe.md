# WORK ORDER — v1.3.6-phase10-safe

1. Utgå från `v1.3.5-phase9-safe`.
2. Flytta enbart hela funktionsdefinitioner ur `Main.ps1`.
3. Flytta report-/outputnära hjälpfunktioner till `Core/OutputPlanning.ps1`:
   - `_IsActiveSealSheet`
   - `_GetPerSheetValueObjects`
   - `_AggregateStatus`
4. Flytta UI-state-hjälpare till `App/UiHelpers.ps1`:
   - `Update-OverwriteVerificationUI`
   - `Enable-DoubleBuffer`
5. Lämna all top-level runtime-kod kvar i `Main.ps1`.
6. Uppdatera `Version.txt` till `1.3.6-phase10-safe`.
7. Smoke test i användarens riktiga miljö:
   - start
   - scan
   - build
   - overwrite-verification UI
   - rapport med seal/worksheet-output
