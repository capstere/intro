#=======================================================================
# AutoMappScript - SharePoint-Driven Product Configuration Module
# Version: 7.0.0
# Description: Replaces the hardcoded switch-block in get-matvariables
#              with a live SharePoint List lookup. All product constants
#              are now managed in SharePoint and editable via Power Apps.
#
# MIGRATION NOTES:
#   - This file replaces the entire get-matvariables function (~1000 lines)
#   - Drop this file next to AutoMappScript.ps1 and dot-source it:
#       . .\AutoMappScript_SPConfig.ps1
#   - Call Initialize-ProductConfig ONCE after Connect-PnPOnline at startup
#   - get-matvariables now reads from an in-memory cache (no per-call API hit)
#
# SHAREPOINT LIST: "IPT Product Configuration"
#   Site: https://danaher.sharepoint.com/sites/CEP-Sweden-Production-Management
#   Columns (internal names):
#     Title          - Material code (e.g. "GXMTB/RIF-ULTRA-10")
#     MatRev         - Document revision (e.g. "D25862")
#     Assay          - Display name (e.g. "GXMTB RIF ULTRA")
#     HighPos        - Yes/No
#     Product        - Short product code
#     SealAssay      - Seal test category
#     PartNr         - Part number (e.g. "700-5702")
#     IsUltra        - Yes/No
#     TemplatePath   - Full UNC path to template folder
#     NAString       - "N/A" or "NA" (product-specific)
#     AssayFamily    - Optional family tag (MTB / CTNG / HIV / etc.)
#     DoubleSampling - Yes/No
#     IsCarba        - Yes/No
#     IsHPV          - Yes/No
#     JapanType      - Optional: MTB / CTNG / CDIFF / MRSA
#     IsActive       - Yes/No (set to No to disable a product without deleting)
#=======================================================================

# Module-level cache: populated once by Initialize-ProductConfig
# Key  = MaterialCode  (Title column)
# Also indexed by MatRev for reverse-lookup compatibility
$script:ProductConfigCache      = @{}   # keyed by MaterialCode
$script:ProductConfigByMatRev   = @{}   # keyed by MatRev (for legacy lookups)
$script:ProductConfigInitialized = $false

#-----------------------------------------------------------------------
# Initialize-ProductConfig
# Call this ONCE after Connect-PnPOnline. Loads every active product
# from the "IPT Product Configuration" SharePoint list into memory.
# All subsequent get-matvariables calls are instantaneous (cache hit).
#-----------------------------------------------------------------------
function Initialize-ProductConfig {

    param(
        [string]$SiteUrl   = "https://danaher.sharepoint.com/sites/CEP-Sweden-Production-Management",
        [string]$ListName  = "IPT Product Configuration"
    )

    Write-Host "Loading product configuration from SharePoint list '$ListName'..." -ForegroundColor DarkYellow

    try {
        $items = Get-PnPListItem -List $ListName -PageSize 500 -ErrorAction Stop
    } catch {
        Write-Host "CRITICAL: Could not load product configuration from SharePoint. Error: $_" -BackgroundColor DarkRed
        "Could not load product configuration from SharePoint list,$((($_) -replace ',',';')),$(((Get-Date -Format 'yyyy-MM-dd HH:mm:ss').ToString()))" |
            Add-Content -Path ".\Log\Errorlog.csv"
        return
    }

    $loaded = 0

    foreach ($item in $items) {
        $fv = $item.FieldValues

        # Skip inactive products
        if ($fv.IsActive -eq $false) { continue }

        $entry = [ordered]@{
            assay          = if ($fv.Assay)         { $fv.Assay }         else { 0 }
            matrev         = if ($fv.MatRev)        { $fv.MatRev }        else { "N/A" }
            highpos        = [bool]$fv.HighPos
            product        = $fv.Product
            sealassay      = $fv.SealAssay
            partnr         = $fv.PartNr
            ultra          = [bool]$fv.IsUltra
            path           = $fv.TemplatePath
            na             = if ($fv.NAString)      { $fv.NAString }      else { "N/A" }
            assayfam       = $fv.AssayFamily        # may be null/empty
            doublesampling = [bool]$fv.DoubleSampling
            carba          = [bool]$fv.IsCarba
            hpv            = [bool]$fv.IsHPV
            japan          = $fv.JapanType          # may be null/empty
            mail           = $null
        }

        # Primary index: MaterialCode (Title column)
        $matCode = ($fv.Title).Trim()
        if ($matCode -and -not $script:ProductConfigCache.ContainsKey($matCode)) {
            $script:ProductConfigCache[$matCode] = $entry
        }

        # Secondary index: MatRev (for legacy callers that pass the D-number)
        $matRev = ($fv.MatRev).Trim()
        if ($matRev -and $matRev -ne "N/A" -and -not $script:ProductConfigByMatRev.ContainsKey($matRev)) {
            $script:ProductConfigByMatRev[$matRev] = $entry
        }

        $loaded++
    }

    $script:ProductConfigInitialized = $true
    Write-Host "Product configuration loaded: $loaded active products." -ForegroundColor Green
}

#-----------------------------------------------------------------------
# get-matvariables  (drop-in replacement for the original switch block)
# Accepts either a MaterialCode ("GXMTB/RIF-ULTRA-10")
# or a MatRev document number ("D25862") - same as the original.
# Returns a hashtable with identical keys to the original function.
#-----------------------------------------------------------------------
function get-matvariables {

    param([string]$material)

    [hashtable]$return = @{}

    # Warn once if cache was never loaded
    if (-not $script:ProductConfigInitialized) {
        Write-Host "WARNING: Product config cache is empty. Call Initialize-ProductConfig first." -ForegroundColor Yellow
        # Fallback: return an empty/unknown entry so callers can handle gracefully
        $return.assay    = 0
        $return.matrev   = "N/A"
        $return.path     = "\\SE.CEPHEID.PRI\Cepheid Sweden\QC\QC-1\IPT\Skiftspecifika dokument\Skift 1\Mahdi\powerpoint\AutoMappscript\NotYet"
        return $return
    }

    $material = $material.Trim()

    # 1. Direct match on MaterialCode
    if ($script:ProductConfigCache.ContainsKey($material)) {
        return $script:ProductConfigCache[$material]
    }

    # 2. Match on MatRev (D-number) - mirrors original switch behaviour
    if ($script:ProductConfigByMatRev.ContainsKey($material)) {
        return $script:ProductConfigByMatRev[$material]
    }

    # 3. No match - mirrors the original 'default' branch
    Write-Host "Product not found in configuration list: $material" -ForegroundColor DarkYellow
    $return.assay    = 0
    $return.matrev   = "N/A"
    $return.path     = "\\SE.CEPHEID.PRI\Cepheid Sweden\QC\QC-1\IPT\Skiftspecifika dokument\Skift 1\Mahdi\powerpoint\AutoMappscript\NotYet"
    return $return
}

#-----------------------------------------------------------------------
# Reload-ProductConfig
# Hot-reload during a long-running session without restarting the script.
# Call this if someone has just edited the SharePoint list and you want
# the new values to take effect immediately.
#-----------------------------------------------------------------------
function Reload-ProductConfig {
    param(
        [string]$SiteUrl  = "https://danaher.sharepoint.com/sites/CEP-Sweden-Production-Management",
        [string]$ListName = "IPT Product Configuration"
    )
    $script:ProductConfigCache      = @{}
    $script:ProductConfigByMatRev   = @{}
    $script:ProductConfigInitialized = $false
    Initialize-ProductConfig -SiteUrl $SiteUrl -ListName $ListName
}

#=======================================================================
# HOW TO INTEGRATE INTO AutoMappScript.ps1
# ─────────────────────────────────────────
# 1. Remove (or comment out) the entire get-matvariables function
#    (lines 1 – 974 in the original script).
#
# 2. Add this line near the top of AutoMappScript.ps1 (before the main
#    execution block) to load this module:
#
#       . .\AutoMappScript_SPConfig.ps1
#
# 3. In the 'refresh' function, AFTER Connect-PnPOnline succeeds,
#    add ONE call to load the cache:
#
#       Initialize-ProductConfig
#
#    The rest of the script is untouched — every existing call to
#    get-matvariables continues to work without any other changes.
#
# 4. Optional: if the script runs for a very long time between loops,
#    call Reload-ProductConfig at the top of each main loop iteration
#    to pick up any list edits that happened during the session.
#=======================================================================
