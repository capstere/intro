/**
 * IPT_FillWorksheet.ts  —  Office Script for Power Automate
 * ==========================================================
 * Called by the "IPT Folder Creation" Power Automate flow after
 * copying the .xlsx template into the new order folder.
 *
 * Replicates every cell-fill operation previously done by
 * AutoMappScript v6.0 (EPPlus / PowerShell).
 *
 * TEMPLATE REQUIREMENTS
 * ─────────────────────
 * Each .xlsx template must have:
 *   • Worksheet tabs 1–5 (standard/HighPos/Japan/DoubleSampling)
 *     OR 1–4 (Carba positive) + 1–10 (Carba negative)
 *     OR 1–10 (HPV positive) + 1–4 (HPV negative)
 *   • A "Seal Test" or "STF" worksheet (seal) OR a "Vacuum Oven" worksheet (Ultra)
 *   • A "Test Summary" worksheet
 *   • A "Data Summary" and/or "Stats" worksheet
 *   • Each data worksheet contains TWO "Cartridge ID" labels:
 *       – First occurrence  → Positive control section (replicates 11–20)
 *       – Second occurrence → Negative control section (replicates 01–10)
 *   • Green input cells (#CCFFCC) and blue input cells (#CCFFFF) that
 *     should receive N/A when not otherwise filled
 *
 * PARAMETERS (passed by Power Automate)
 * ──────────────────────────────────────
 *   product        Product code for Test Summary (e.g. "GXMTBRIFULTRA50")
 *   partNr         Part number (e.g. "700-5702")
 *   lsp            Cartridge / LSP number (integer)
 *   batchNr        Batch number(s), comma-separated
 *   testDate       ISO date string (e.g. "2026-03-21")
 *   highPos        Whether assay uses High Positive controls
 *   isUltra        Whether assay uses Vacuum Oven seal (Ultra)
 *   doubleSampling Whether assay uses double-sampling cartridge ID pattern
 *   isCarba        Whether assay is Carba-R (4 pos sheets, 10 neg sheets)
 *   isHpv          Whether assay is HPV (10 pos sheets, 4 neg sheets)
 *   japanType      Japan-market variant: "MTB" | "CTNG" | "CDIFF" | "MRSA" | ""
 *   naString       Exact string for empty cells: "N/A" or "NA"
 *   scriptVersion  Version string written to "Recorded By" field
 */

function main(
  workbook: ExcelScript.Workbook,
  product: string,
  partNr: string,
  lsp: number,
  batchNr: string,
  testDate: string,
  highPos: boolean,
  isUltra: boolean,
  doubleSampling: boolean,
  isCarba: boolean,
  isHpv: boolean,
  japanType: string,
  naString: string,
  scriptVersion: string
): void {

  const allSheets = workbook.getWorksheets();

  // ── Step 1 · Seal or Vacuum worksheet ─────────────────────────────────
  for (const sheet of allSheets) {
    const n = sheet.getName().toLowerCase();
    if (n.includes("seal test") || n.includes("stf")) {
      isUltra ? fillVacuumSheet(sheet, testDate, naString)
              : fillSealSheet(sheet, testDate, naString);
    } else if (n.includes("vacuum oven")) {
      fillVacuumSheet(sheet, testDate, naString);
    }
  }

  // ── Step 2 · Test Summary ──────────────────────────────────────────────
  for (const sheet of allSheets) {
    if (sheet.getName() === "Test Summary") {
      fillTestSummary(sheet, product, lsp, testDate, scriptVersion, naString);
    }
  }

  // ── Step 3 · Data Summary + Stats (date + N/A only) ───────────────────
  for (const sheet of allSheets) {
    const n = sheet.getName();
    if (n.includes("Data Summary") || n.includes("Stats")) {
      fillDateSheet(sheet, testDate, naString);
    }
  }

  // ── Step 4 · Positive cartridge IDs ───────────────────────────────────
  if (isCarba) {
    for (let i = 0; i < 4 && i < allSheets.length; i++) {
      fillPosCarba(allSheets[i], i + 1);
    }
  } else if (isHpv) {
    for (let i = 0; i < 10 && i < allSheets.length; i++) {
      fillPosHpv(allSheets[i], i + 1);
    }
  } else {
    for (let i = 0; i < 5 && i < allSheets.length; i++) {
      fillPosMain(allSheets[i], i + 1, highPos, doubleSampling, japanType);
    }
  }

  // ── Step 5 · Negative cartridge IDs ───────────────────────────────────
  if (isCarba) {
    for (let i = 0; i < 10 && i < allSheets.length; i++) {
      fillNegCarba(allSheets[i], i + 1);
    }
  } else if (isHpv) {
    for (let i = 0; i < 4 && i < allSheets.length; i++) {
      fillNegHpv(allSheets[i], i + 1);
    }
  } else {
    for (let i = 0; i < 5 && i < allSheets.length; i++) {
      fillNegMain(allSheets[i], i + 1, doubleSampling);
    }
  }

  // ── Step 6 · N/A fill pass ────────────────────────────────────────────
  for (const sheet of allSheets) {
    if (sheet.getName().includes("QC Data")) continue;
    fillCartridgeNA(sheet, naString);
    fillGreenBlueNA(sheet, naString);
  }
}

// ============================================================================
// UTILITY HELPERS
// ============================================================================

/**
 * Find ALL cells whose text contains `query`.
 * Returns 0-based absolute {row, col} coordinates.
 */
function findAllCells(
  sheet: ExcelScript.Worksheet,
  query: string
): { row: number; col: number }[] {
  const ur = sheet.getUsedRange();
  if (!ur) return [];
  const vals = ur.getValues();
  const sr = ur.getRowIndex();
  const sc = ur.getColumnIndex();
  const results: { row: number; col: number }[] = [];
  for (let r = 0; r < vals.length; r++) {
    for (let c = 0; c < vals[r].length; c++) {
      if (String(vals[r][c]).includes(query)) {
        results.push({ row: sr + r, col: sc + c });
      }
    }
  }
  return results;
}

/** Find the FIRST cell whose text contains `query`. Returns null if not found. */
function findCell(
  sheet: ExcelScript.Worksheet,
  query: string
): { row: number; col: number } | null {
  const all = findAllCells(sheet, query);
  return all.length > 0 ? all[0] : null;
}

/**
 * If the cell at (row, col) is part of a merged range, return the last column
 * of that merged range. Otherwise return col.
 */
function getMergedEndCol(
  sheet: ExcelScript.Worksheet,
  row: number,
  col: number
): number {
  const cell = sheet.getCell(row, col);
  const mergeArea = cell.getMergeArea();
  if (mergeArea) {
    return mergeArea.getColumnIndex() + mergeArea.getColumnCount() - 1;
  }
  return col;
}

/** Zero-pad a number to at least 2 digits. */
function pad2(n: number): string {
  return n < 10 ? "0" + n : String(n);
}

/** Fill all empty green (#CCFFCC) and blue (#CCFFFF) cells with naString. */
function fillGreenBlueNA(sheet: ExcelScript.Worksheet, naString: string): void {
  const ur = sheet.getUsedRange();
  if (!ur) return;
  const vals = ur.getValues();
  const sr = ur.getRowIndex();
  const sc = ur.getColumnIndex();
  for (let r = 0; r < vals.length; r++) {
    for (let c = 0; c < vals[r].length; c++) {
      if (String(vals[r][c]) !== "") continue;
      const cell = sheet.getCell(sr + r, sc + c);
      const color = cell.getFormat().getFill().getColor().replace("#", "").toUpperCase();
      if (color === "CCFFCC" || color === "CCFFFF") {
        cell.setValue(naString);
      }
    }
  }
}

/**
 * In the "Cartridge ID" column, fill any cells that have a colored background
 * but are empty. Also fills the two cells to the right (same convention as
 * the original script's solid-fill N/A pass).
 */
function fillCartridgeNA(sheet: ExcelScript.Worksheet, naString: string): void {
  const positions = findAllCells(sheet, "Cartridge ID");
  for (const pos of positions) {
    let row = pos.row + 1;
    const col = pos.col;
    for (let guard = 0; guard < 120; guard++) {
      const cell = sheet.getCell(row, col);
      const color = cell.getFormat().getFill().getColor().replace("#", "").toUpperCase();
      // Stop when we reach an unfilled (transparent / white) cell
      if (!color || color === "FFFFFF" || color === "") break;
      if (String(cell.getValue()) === "") {
        cell.setValue(naString);
        sheet.getCell(row, col + 1).setValue(naString);
        sheet.getCell(row, col + 2).setValue(naString);
      }
      row++;
    }
  }
}

// ============================================================================
// SEAL / VACUUM WORKSHEETS
// ============================================================================

function fillSealSheet(
  sheet: ExcelScript.Worksheet,
  date: string,
  naString: string
): void {
  const pointPos = findCell(sheet, "Point");
  if (pointPos) {
    let row = pointPos.row + 1;
    const col = pointPos.col;
    for (let guard = 0; guard < 60; guard++) {
      const cell = sheet.getCell(row, col);
      const text = String(cell.getValue());
      if (text.toLowerCase().includes("total") || text === "") break;
      const n = parseInt(text, 10);
      if (!isNaN(n)) {
        sheet.getCell(row, col + 1).setValue(n <= 10 ? 20 : naString);
        sheet.getCell(row, col + 2).setValue(n <= 10 ? 0 : naString);
      }
      row++;
    }
  }
  const datePos = findCell(sheet, "Date");
  if (datePos) {
    const endCol = getMergedEndCol(sheet, datePos.row, datePos.col);
    sheet.getCell(datePos.row, endCol + 1).setValue(date);
  }
  fillGreenBlueNA(sheet, naString);
}

function fillVacuumSheet(
  sheet: ExcelScript.Worksheet,
  date: string,
  naString: string
): void {
  const datePos = findCell(sheet, "Date");
  if (datePos) {
    const endCol = getMergedEndCol(sheet, datePos.row, datePos.col);
    sheet.getCell(datePos.row, endCol + 1).setValue(date);
  }
  fillGreenBlueNA(sheet, naString);
}

// ============================================================================
// TEST SUMMARY WORKSHEET
// ============================================================================

function fillTestSummary(
  sheet: ExcelScript.Worksheet,
  product: string,
  lsp: number,
  date: string,
  version: string,
  naString: string
): void {

  // Product Catalog / Part No.
  const prodPos = findCell(sheet, "Product Catalog/Part No.");
  if (prodPos) {
    const endCol = getMergedEndCol(sheet, prodPos.row, prodPos.col);
    sheet.getCell(prodPos.row, endCol + 1).setValue(product);
  }

  // Cartridge No. (LSP)
  const lspPos = findCell(sheet, "Cartridge No. (LSP)");
  if (lspPos) {
    const endCol = getMergedEndCol(sheet, lspPos.row, lspPos.col);
    sheet.getCell(lspPos.row, endCol + 1).setValue(lsp);
  }

  // Recorded By: + Date
  // The original script puts the version string in "Recorded By", then scans
  // right to find a cell with "Date" text or a green/blue input cell for the date.
  const recPos = findCell(sheet, "Recorded By:");
  if (recPos) {
    const endCol = getMergedEndCol(sheet, recPos.row, recPos.col);
    sheet.getCell(recPos.row, endCol + 1).setValue(version + " — Power Automate");
    // Scan right from the next cell to find the Date input cell
    for (let c = endCol + 2; c < endCol + 20; c++) {
      const cell = sheet.getCell(recPos.row, c);
      const text = String(cell.getValue());
      const color = cell.getFormat().getFill().getColor().replace("#", "").toUpperCase();
      if (text.includes("Date")) {
        // "Date:" label found — enter date one cell to the right
        sheet.getCell(recPos.row, c + 1).setValue(date);
        break;
      }
      if (color === "CCFFCC" || color === "CCFFFF") {
        // Green/blue input cell — this IS the date input cell
        cell.setValue(date);
        break;
      }
    }
  }

  // Type Of Resample
  const torPos = findCell(sheet, "Type Of Resample");
  if (torPos) {
    const endCol = getMergedEndCol(sheet, torPos.row, torPos.col);
    sheet.getCell(torPos.row, endCol + 1).setValue(naString);
  }

  fillGreenBlueNA(sheet, naString);
}

// ============================================================================
// DATA SUMMARY / STATS WORKSHEETS
// ============================================================================

function fillDateSheet(
  sheet: ExcelScript.Worksheet,
  date: string,
  naString: string
): void {
  const datePos = findCell(sheet, "Date");
  if (datePos) {
    const endCol = getMergedEndCol(sheet, datePos.row, datePos.col);
    const inputCell = sheet.getCell(datePos.row, endCol + 1);
    if (String(inputCell.getValue()) === "") inputCell.setValue(date);
  }
  fillGreenBlueNA(sheet, naString);
}

// ============================================================================
// CARTRIDGE ID — POSITIVE SECTION
// The template has TWO "Cartridge ID" labels per data sheet:
//   [0] = Positive section (replicates 11–20)
//   [1] = Negative section (replicates 01–10)
// ============================================================================

/**
 * Fill the Positive cartridge IDs for standard, HighPos, DoubleSampling,
 * and Japan-variant assays (5 worksheets, 2 bags per sheet).
 */
function fillPosMain(
  sheet: ExcelScript.Worksheet,
  idx: number,       // 1-based sheet index
  highPos: boolean,
  doubleSampling: boolean,
  japanType: string
): void {
  const positions = findAllCells(sheet, "Cartridge ID");
  const pos = positions[0]; // First occurrence = Positive section
  if (!pos) return;

  const bag1 = pad2(2 * idx - 1);
  const bag2 = pad2(2 * idx);
  let row = pos.row + 2; // Skip header row and one structural row

  for (const bag of [bag1, bag2]) {
    if (japanType === "MTB") {
      for (let r = 11; r <= 16; r++) { sheet.getCell(row, pos.col).setValue(`${bag}_1_${r}`); row += 2; }
      sheet.getCell(row, pos.col).setValue(`${bag}_2_17`); row += 2;
      sheet.getCell(row, pos.col).setValue(`${bag}_3_18`); row += 2;
      sheet.getCell(row, pos.col).setValue(`${bag}_4_19`); row += 2;
      sheet.getCell(row, pos.col).setValue(`${bag}_5_20`); row += 2;
    } else if (japanType === "CTNG") {
      for (let r = 11; r <= 18; r++) { sheet.getCell(row, pos.col).setValue(`${bag}_1_${r}`); row += 2; }
      sheet.getCell(row, pos.col).setValue(`${bag}_2_19`); row += 2;
      sheet.getCell(row, pos.col).setValue(`${bag}_3_20`); row += 2;
    } else if (japanType === "CDIFF" || japanType === "MRSA") {
      for (let r = 11; r <= 17; r++) { sheet.getCell(row, pos.col).setValue(`${bag}_1_${r}`); row += 2; }
      sheet.getCell(row, pos.col).setValue(`${bag}_2_18`); row += 2;
      sheet.getCell(row, pos.col).setValue(`${bag}_2_19`); row += 2;
      sheet.getCell(row, pos.col).setValue(`${bag}_3_20`); row += 2;
    } else if (doubleSampling) {
      let xp = 1;
      for (let r = 11; r <= 20; r++) {
        sheet.getCell(row, pos.col).setValue(`${bag}_1_${r}${xp <= 5 ? "X" : "+"}`);
        xp++;
        row += 2;
      }
    } else if (highPos) {
      for (let r = 11; r <= 18; r++) { sheet.getCell(row, pos.col).setValue(`${bag}_1_${r}`); row += 2; }
      sheet.getCell(row, pos.col).setValue(`${bag}_2_19`); row += 2;
      sheet.getCell(row, pos.col).setValue(`${bag}_2_20`); row += 2;
    } else {
      // Standard: all replicates use _1_ prefix
      for (let r = 11; r <= 20; r++) { sheet.getCell(row, pos.col).setValue(`${bag}_1_${r}`); row += 2; }
    }
  }
}

/** Carba-R positive: 4 sheets, 3 bags per sheet, replicates 15–20. */
function fillPosCarba(sheet: ExcelScript.Worksheet, idx: number): void {
  const positions = findAllCells(sheet, "Cartridge ID");
  const pos = positions[0];
  if (!pos) return;
  let row = pos.row + 2;
  for (const bag of [pad2(3 * idx - 2), pad2(3 * idx - 1), pad2(3 * idx)]) {
    for (let r = 15; r <= 18; r++) { sheet.getCell(row, pos.col).setValue(`${bag}_1_${r}`); row += 2; }
    sheet.getCell(row, pos.col).setValue(`${bag}_2_19`); row += 2;
    sheet.getCell(row, pos.col).setValue(`${bag}_2_20`); row += 2;
  }
}

/** HPV positive: 10 sheets, 1 bag per sheet, replicates 7–20 + high-pos tail. */
function fillPosHpv(sheet: ExcelScript.Worksheet, idx: number): void {
  const positions = findAllCells(sheet, "Cartridge ID");
  const pos = positions[0];
  if (!pos) return;
  const bag = pad2(idx);
  let row = pos.row + 2;
  for (let r = 7; r <= 18; r++) {
    sheet.getCell(row, pos.col).setValue(`${bag}_0_${pad2(r)}`);
    row += 2;
  }
  sheet.getCell(row, pos.col).setValue(`${bag}_2_19`); row += 2;
  sheet.getCell(row, pos.col).setValue(`${bag}_2_20`); row += 2;
}

// ============================================================================
// CARTRIDGE ID — NEGATIVE SECTION
// Uses the SECOND "Cartridge ID" occurrence (index [1]) in each worksheet.
// Falls back to [0] if the template only has one (single-section templates).
// ============================================================================

/** Standard / HighPos / Japan negative: 5 sheets, 2 bags, replicates 01–10. */
function fillNegMain(
  sheet: ExcelScript.Worksheet,
  idx: number,
  doubleSampling: boolean
): void {
  const positions = findAllCells(sheet, "Cartridge ID");
  const pos = positions.length > 1 ? positions[1] : positions[0];
  if (!pos) return;

  const bag1 = pad2(2 * idx - 1);
  const bag2 = pad2(2 * idx);
  let row = pos.row + 2;

  for (const bag of [bag1, bag2]) {
    if (doubleSampling) {
      let xp = 1;
      for (let r = 1; r <= 10; r++) {
        sheet.getCell(row, pos.col).setValue(`${bag}_0_${pad2(r)}${xp <= 5 ? "X" : "+"}`);
        xp++;
        row += 2;
      }
    } else {
      for (let r = 1; r <= 10; r++) {
        sheet.getCell(row, pos.col).setValue(`${bag}_0_${pad2(r)}`);
        row += 2;
      }
    }
  }
}

/** Carba-R negative: 10 sheets, 1 bag per sheet, replicates 01–14. */
function fillNegCarba(sheet: ExcelScript.Worksheet, idx: number): void {
  const positions = findAllCells(sheet, "Cartridge ID");
  const pos = positions.length > 1 ? positions[1] : positions[0];
  if (!pos) return;
  const bag = pad2(idx);
  let row = pos.row + 2;
  for (let r = 1; r <= 14; r++) {
    sheet.getCell(row, pos.col).setValue(`${bag}_0_${pad2(r)}`);
    row += 2;
  }
}

/** HPV negative: 4 sheets, 3 bags per sheet, replicates 01–06. */
function fillNegHpv(sheet: ExcelScript.Worksheet, idx: number): void {
  const positions = findAllCells(sheet, "Cartridge ID");
  const pos = positions.length > 1 ? positions[1] : positions[0];
  if (!pos) return;
  let row = pos.row + 2;
  for (const bag of [pad2(3 * idx - 2), pad2(3 * idx - 1), pad2(3 * idx)]) {
    for (let r = 1; r <= 6; r++) {
      sheet.getCell(row, pos.col).setValue(`${bag}_0_0${r}`);
      row += 2;
    }
  }
}
