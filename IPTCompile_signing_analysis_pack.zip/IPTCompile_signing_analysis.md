# IPTCompile signing analysis – WORKING vs FAILING worksheets

Scope: read-only inspection of uploaded `IPTCompile.zip`, `WORKING.zip`, `FAILING.zip`, `LOGGAR.zip`.

## Evidence from logs

- WORKING examples complete Worksheet Sammanställning signing and verify 8/8 cells.
- FAILING examples stop during Worksheet signing after Seal Test NEG/POS have already been signed and verified.
- Main recurring error for MRSA NXG / XP3 SARS COV2 and repeated HBV attempts:
  - `Kunde inte spara WorksheetPart 'Seal Test Failure Count': Exception calling "Save" with "0" argument(s): "Unable to determine the identity of domain."`
- HCV FS and some HBV attempts show:
  - `Cannot index into a null array.`

## Strong structural finding

All FAILING worksheets have an extremely bloated `Seal Test Failure Count` XML part.

| File | Status | Seal Test Failure Count dimension | XML cell nodes | Nonblank cells | Raw sheet XML size |
|---|---:|---:|---:|---:|---:|
| fungerande_CARBA 14701.xlsx | WORKING | A1:N290 | 753 | 133 | 27.4 KB |
| fungerande_HPV v2 33901.xlsx | WORKING | A1:M37 | 481 | 132 | 18.0 KB |
| HBV VL #32602.xlsx | FAILING | A2:WVV109 | 532,673 | 129 | 10.6 MB |
| HCV FS #17102.xlsx | FAILING | A2:WVV109 | 532,673 | 132 | 12.1 MB |
| MRSA NXG #15506.xlsx | FAILING | A1:WVV108 | 532,682 | 132 | 10.1 MB |
| XP3 SARS COV2 #17803.xlsx | FAILING | A1:WVV108 | 532,673 | 130 | 11.6 MB |

The FAILING files therefore do not contain hundreds of thousands of meaningful values. They contain hundreds of thousands of mostly styled/empty cell nodes.

Example from `HCV FS #17102.xlsx`, `Seal Test Failure Count`:

- rows 2–26 each contain 16,133 cells, usually only 3 values
- rows 59–65 each contain 16,133 styled blank cells
- row 109 contains 16,140 styled blank cells

The print area itself is not the primary cause; examples still have print areas like:

- `'Seal Test Failure Count'!$A$1:$M$37`
- `'Seal Test Failure Count'!$A$1:$M$36`

The issue is the worksheet XML/used range/style footprint, not simply a wrong print area.

## Relevant code observations

`Core/OpenXmlSignatureWorkflow.ps1` writes and saves each WorksheetPart independently:

```powershell
if ($wroteAny) {
    try { $wsp.Worksheet.Save() } catch {
        throw "Kunde inte spara WorksheetPart '$sheetName': $($_.Exception.Message)"
    }
}
```

`App/BuildFlow/02_Signing.ps1` signs Seal Test NEG/POS before Worksheet signing. Therefore a Worksheet signing failure can occur after Seal Test files have already been changed.

## Recommended safe direction

1. Keep signing disabled in LIVE until patched/tested.
2. Add a preflight check before any signing writes:
   - inspect Worksheet `Seal Test Failure Count`
   - block signing if dimension/max column/cell-node count is excessive
   - show clear message: workbook has bloated STF sheet; sign manually or sanitize/test first
3. Make signing transactional:
   - backup all target files before first write
   - if any later step fails, restore from backup or leave backed-up files with explicit warning
4. Change Worksheet signing to avoid saving bloated/high-risk STF parts in the current path.
5. Fix/null-harden OpenXML helper functions separately.

## Not proven from these files alone

- I did not prove that IPTCompile actively deletes the Seal Test Failure Count sheet.
- The logs prove save failure during `WorksheetPart 'Seal Test Failure Count'`, not an explicit delete call.
- Disappearing sheets could be Excel repair behavior after a failed/corrupted partial save, but that needs a before/after reproduction to prove.
