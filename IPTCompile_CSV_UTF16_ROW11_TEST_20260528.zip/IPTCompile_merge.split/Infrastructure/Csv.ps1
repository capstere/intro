﻿
function Get-CsvFileLines {
    <#
        Läser CSV med BOM-detektering. Viktigt för GeneXpert-exporter som kan vara
        UTF-16LE även om filändelsen är .csv. Get-Content -Encoding Default kan då
        ge nolltecken/garbled text och all efterföljande kolumnlogik faller.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$TotalCount = 0
    )

    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    $sr = $null
    try {
        $enc = [System.Text.Encoding]::Default
        $sr = New-Object System.IO.StreamReader -ArgumentList @($Path, $enc, $true)
        $list = New-Object System.Collections.Generic.List[string]
        while (($line = $sr.ReadLine()) -ne $null) {
            [void]$list.Add($line)
            if ($TotalCount -gt 0 -and $list.Count -ge $TotalCount) { break }
        }
        return @($list.ToArray())
    } catch {
        try { Gui-Log "⚠️ Kunde inte läsa CSV med BOM-detektering: $($_.Exception.Message)" 'Warn' } catch {}
        return @()
    } finally {
        try { if ($sr) { $sr.Close() } } catch {}
        try { if ($sr) { $sr.Dispose() } } catch {}
    }
}

function ConvertTo-CsvFields {
    param(
        [Parameter(Mandatory=$true)][string]$Line,
        [string]$Delimiter
    )
    if ($null -eq $Line) { return @() }

    $del = $Delimiter
    if ([string]::IsNullOrWhiteSpace($del)) {
        $cSemi  = ([regex]::Matches($Line, ';')).Count
        $cComma = ([regex]::Matches($Line, ',')).Count
        $cTab   = ([regex]::Matches($Line, "`t")).Count
        if ($cSemi -gt $cComma -and $cSemi -gt $cTab) { $del = ';' }
        elseif ($cTab -gt 0 -and $cComma -gt 0) { $del = 'tabcomma' }
        elseif ($cTab -gt $cComma) { $del = "`t" }
        else { $del = ',' }
    }

    if (($del + '').Trim().ToLowerInvariant() -in @('tabcomma','tab+comma','tab,comma')) {
        $rx = '[,\t](?=(?:(?:[^\"]*\"){2})*[^\"]*$)'
    } else {
        $d  = [regex]::Escape($del)
        $rx = $d + '(?=(?:(?:[^\"]*\"){2})*[^\"]*$)'
    }

    $arr = [regex]::Split($Line, $rx)
    return ,@($arr | ForEach-Object { ((($_ + '') -replace '^"|"$','') -replace '""','"').Trim() })
}

function Normalize-CsvHeaderName {
    param([string]$Text)
    $s = (($Text + '') -replace '[\uFEFF\u200B]', '').Trim().Trim('"')
    $s = [regex]::Replace($s, '\s+', ' ')
    return $s.ToLowerInvariant()
}

function Get-CsvHeaderIndex {
    param(
        [Parameter(Mandatory)][object[]]$Headers,
        [Parameter(Mandatory)][string[]]$Names,
        [int]$Default = -1
    )
    if (-not $Headers) { return $Default }
    $wanted = @($Names | ForEach-Object { Normalize-CsvHeaderName ($_ + '') })
    for ($i = 0; $i -lt $Headers.Count; $i++) {
        $h = Normalize-CsvHeaderName ($Headers[$i] + '')
        if ($wanted -contains $h) { return $i }
    }
    return $Default
}

function Get-TestSummaryCsvProfile {
    <#
        Identifierar GeneXpert Test Summary-formatet i både äldre och nyare exporter.
        Stöder bl.a.:
          - header rad 8 + data rad 10 (legacy)
          - UTF-16LE-export med header rad 9 + data rad 11
          - komma/semicolon/tab samt praktiskt "Text to Columns"-fall med tab+comma
    #>
    [CmdletBinding()]
    param(
        [string]$Path,
        [string[]]$Lines
    )

    $lines = @($Lines)
    if ($lines.Count -eq 1 -and -not $lines[0]) { $lines = @() }
    if ($lines.Count -eq 0 -and $Path) { $lines = @(Get-CsvFileLines -Path $Path) }
    if (-not $lines -or $lines.Count -eq 0) { return $null }

    $candidates = @(',', ';', "`t", 'tabcomma')
    $best = $null
    $maxScan = [Math]::Min([int]$lines.Count, 80)

    for ($i = 0; $i -lt $maxScan; $i++) {
        $line = $lines[$i]
        if (-not $line -or $line.Trim().Length -eq 0) { continue }

        foreach ($delim in $candidates) {
            $fields = @()
            try { $fields = @(ConvertTo-CsvFields -Line $line -Delimiter $delim) } catch { $fields = @() }
            if (-not $fields -or $fields.Count -lt 5) { continue }

            $norm = @($fields | ForEach-Object { Normalize-CsvHeaderName ($_ + '') })
            $score = 0
            if ($norm -contains 'assay') { $score += 3 }
            if ($norm -contains 'assay version') { $score += 2 }
            if ($norm -contains 'sample id') { $score += 4 }
            if ($norm -contains 'cartridge s/n') { $score += 3 }
            if ($norm -contains 'reagent lot id') { $score += 3 }
            if ($norm -contains 'test type') { $score += 2 }
            if ($norm -contains 'instrument s/n') { $score += 2 }
            if ($norm -contains 'start time') { $score += 1 }

            if ($score -ge 8 -and ($null -eq $best -or $score -gt $best.Score -or ($score -eq $best.Score -and $fields.Count -gt $best.HeaderFields.Count))) {
                $best = [pscustomobject]@{
                    Score       = $score
                    HeaderIndex = $i
                    Delimiter   = $delim
                    HeaderFields= $fields
                }
            }
        }
    }

    if (-not $best) { return $null }

    $dataIndex = [int]$best.HeaderIndex + 1
    while ($dataIndex -lt $lines.Count) {
        $ln = $lines[$dataIndex]
        if ($ln -and $ln.Trim().Length -gt 0) { break }
        $dataIndex++
    }

    return [pscustomobject]@{
        Path           = $Path
        Delimiter      = $best.Delimiter
        HeaderIndex    = [int]$best.HeaderIndex
        HeaderRow      = [int]$best.HeaderIndex + 1
        DataStartIndex = [int]$dataIndex
        DataStartRow   = [int]$dataIndex + 1
        HeaderFields   = @($best.HeaderFields)
        FormatName     = $(if ([int]$best.HeaderIndex -eq 8 -and [int]$dataIndex -eq 10) { 'GeneXpert_UTF16_Row11' } else { 'GeneXpert_LegacyOrDetected' })
    }
}

function Get-CsvDelimiter { param([string]$Path)
    try {
        $profile = Get-TestSummaryCsvProfile -Path $Path
        if ($profile -and $profile.Delimiter) { return $profile.Delimiter }

        $lines = @(Get-CsvFileLines -Path $Path -TotalCount 30)
        $best = $null
        foreach ($line in $lines) {
            if (-not $line -or -not $line.Trim()) { continue }
            $sc = ($line -split ';').Count
            $cc = ($line -split ',').Count
            $tc = ($line -split "`t").Count
            $max = [Math]::Max($sc, [Math]::Max($cc, $tc))
            if ($null -eq $best -or $max -gt $best.Count) {
                $best = [pscustomobject]@{ Count=$max; Delimiter=$(if ($sc -ge $cc -and $sc -ge $tc) {';'} elseif ($tc -gt $cc) {"`t"} else {','}) }
            }
        }
        if ($best -and $best.Delimiter) { return $best.Delimiter }
        return ';'
    } catch {
        Gui-Log "⚠️ Get-CsvDelimiter misslyckades: $($_.Exception.Message)" 'Warn'
        return ';'
    }
}

function Test-IsResampleCsv {
    <# Returnerar $true om CSV:n innehåller _RES_ i Sample ID-kolumnen (>= MinHits träffar). #>
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$MinHits = 3
    )

    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    $threshold = [Math]::Max(1, [int]$MinHits)

    try {
        $lines = @(Get-CsvFileLines -Path $Path)
        if (-not $lines -or $lines.Count -eq 0) { return $false }
        $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
        if (-not $profile) { return $false }

        $sampleIdIdx = Get-CsvHeaderIndex -Headers $profile.HeaderFields -Names @('Sample ID','SampleID','Sample Id') -Default 2
        $resCount = 0
        for ($r = [int]$profile.DataStartIndex; $r -lt $lines.Count; $r++) {
            $line = $lines[$r]
            if (-not $line -or $line.Trim().Length -eq 0) { continue }

            $fields = $null
            try { $fields = ConvertTo-CsvFields -Line $line -Delimiter $profile.Delimiter } catch { $fields = $null }
            if (-not $fields -or $fields.Count -le $sampleIdIdx) { continue }

            $sid = ($fields[$sampleIdIdx] + '')
            if ($sid -imatch '_RES_') { $resCount++ }
        }

        return ($resCount -ge $threshold)
    } catch {
        try {
            Gui-Log ("⚠️ Test-IsResampleCsv misslyckades för '{0}': {1}" -f (Split-Path $Path -Leaf), $_.Exception.Message) 'Warn' 'DEBUG'
        } catch {}
        return $false
    }
}

function Resolve-CsvPrimaryAndResample {
    <# Klassificerar 0-2 CSV-filer till Primary + ev. Resample med samma regel som i buildflödet. #>
    param([string[]]$CsvPaths)

    $result = [pscustomobject]@{
        Ok             = $true
        PrimaryCsv     = $null
        ResampleCsv    = $null
        HasResample    = $false
        ErrorMessage   = $null
        WarningMessage = $null
    }

    $paths = @($CsvPaths | Where-Object { $_ -and (($_ + '').Trim().Length -gt 0) })

    if ($paths.Count -eq 0) { return $result }

    if ($paths.Count -eq 1) {
        if (Test-IsResampleCsv -Path $paths[0]) {
            $result.Ok = $false
            $result.ResampleCsv = $paths[0]
            $result.ErrorMessage = '❌ Enbart Resampling-CSV vald. Välj även Primary CSV innan rapport kan skapas.'
            return $result
        }
        $result.PrimaryCsv = $paths[0]
        return $result
    }

    if ($paths.Count -eq 2) {
        $isRes0 = Test-IsResampleCsv -Path $paths[0]
        $isRes1 = Test-IsResampleCsv -Path $paths[1]

        if ($isRes0 -and -not $isRes1) {
            $result.ResampleCsv = $paths[0]
            $result.PrimaryCsv = $paths[1]
        } elseif ($isRes1 -and -not $isRes0) {
            $result.PrimaryCsv = $paths[0]
            $result.ResampleCsv = $paths[1]
        } elseif (-not $isRes0 -and -not $isRes1) {
            $result.Ok = $false
            $result.ErrorMessage = '❌ Du har valt 2 CSV-filer men ingen Resampling CSV-fil. Avmarkera en fil eller välj korrekt Resampling CSV-fil.'
            return $result
        } else {
            $result.PrimaryCsv = $paths[0]
            $result.ResampleCsv = $paths[1]
            $result.WarningMessage = '⚠️ Båda CSV har _RES_ i Sample ID – autoväljer Resampling + Original.'
        }

        $result.HasResample = [bool]$result.ResampleCsv
        return $result
    }

    $result.Ok = $false
    $result.ErrorMessage = ("❌ Du har valt {0} CSV-filer. Välj max 2 (Primary + ev. Resample)." -f $paths.Count)
    return $result
}

function Get-AssayFromCsv { param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    try {
        $lines = @(Get-CsvFileLines -Path $Path)
        $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
        if (-not $profile) { return $null }
        $assayIdx = Get-CsvHeaderIndex -Headers $profile.HeaderFields -Names @('Assay') -Default 0
        for ($i = [int]$profile.DataStartIndex; $i -lt $lines.Count; $i++) {
            $ln = $lines[$i]
            if (-not $ln -or $ln.Trim().Length -eq 0) { continue }
            $f = ConvertTo-CsvFields -Line $ln -Delimiter $profile.Delimiter
            if (-not $f -or $f.Count -le $assayIdx) { continue }
            $a = ([string]$f[$assayIdx]).Trim()
            if ($a -and $a -notmatch '^(?i)\s*assay\s*$') { return $a }
        }
    } catch {
        Gui-Log "⚠️ Kunde inte läsa Assay från CSV: $($_.Exception.Message)" 'Warn'
    }
    return $null
}

function Import-CsvRows { param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    $list  = New-Object System.Collections.Generic.List[object]
    try {
        $lines = @(Get-CsvFileLines -Path $Path)
        if (-not $lines -or $lines.Count -eq 0) { return @() }
        $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
        $delim = $(if ($profile -and $profile.Delimiter) { $profile.Delimiter } else { Get-CsvDelimiter $Path })
        $startIndex = $(if ($profile) { [int]$profile.DataStartIndex } else { [Math]::Max(0, [int]$StartRow - 1) })

        for ($i = $startIndex; $i -lt $lines.Count; $i++) {
            $ln = $lines[$i]
            if (-not $ln -or $ln.Trim().Length -eq 0) { continue }
            $f = ConvertTo-CsvFields -Line $ln -Delimiter $delim
            if (-not $f -or ($f -join '').Trim().Length -eq 0) { continue }
            [void]$list.Add($f)
        }
    } catch {
        Gui-Log "⚠️ Kunde inte läsa rader från CSV: $($_.Exception.Message)" 'Warn'
    }
    return @($list.ToArray())
}

function Get-CsvStats {
    param(
        [string]$Path,
        [string[]]$Lines
    )
    $out = [ordered]@{
        TestCount       = 0
        DupCount        = 0
        Duplicates      = @()
        LspValues       = @()
        LspOK           = $null
        InstrumentByType= [ordered]@{}
    }
    $lines = @($Lines)
    if ($lines.Count -eq 1 -and -not $lines[0]) { $lines = @() }
    if ($lines.Count -eq 0) {
        if (-not (Test-Path -LiteralPath $Path)) { return [pscustomobject]$out }
        try { $lines = @(Get-CsvFileLines -Path $Path) } catch { Gui-Log "⚠️ Kunde inte läsa CSV-statistik: $($_.Exception.Message)" 'Warn'; return [pscustomobject]$out }
    }
    if (-not $lines -or $lines.Count -eq 0) { return [pscustomobject]$out }

    $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
    if (-not $profile) { return [pscustomobject]$out }

    $idxCart  = Get-CsvHeaderIndex -Headers $profile.HeaderFields -Names @('Cartridge S/N','Cartridge SN') -Default 3
    $idxLsp   = Get-CsvHeaderIndex -Headers $profile.HeaderFields -Names @('Reagent Lot ID','Reagent Lot') -Default 4
    $idxInstr = Get-CsvHeaderIndex -Headers $profile.HeaderFields -Names @('Instrument S/N','Instrument SN','Instrument Serial Number') -Default 6

    $cartSnList = New-Object System.Collections.Generic.List[string]
    $lspList    = New-Object System.Collections.Generic.List[string]
    $instrList  = New-Object System.Collections.Generic.List[string]

    for ($r = [int]$profile.DataStartIndex; $r -lt $lines.Count; $r++) {
        $ln = $lines[$r]
        if (-not $ln -or -not $ln.Trim()) { continue }
        $f = ConvertTo-CsvFields -Line $ln -Delimiter $profile.Delimiter
        if (-not $f -or $f.Count -lt 1) { continue }
        if ($f.Count -gt $idxCart)  { $cartSnList.Add( ($f[$idxCart]  + '').Trim() ) }
        if ($f.Count -gt $idxLsp)   { $lspList.Add(    ($f[$idxLsp]   + '').Trim() ) }
        if ($f.Count -gt $idxInstr) { $instrList.Add(  ($f[$idxInstr] + '').Trim() ) }
    }

    $cartSn = $cartSnList | Where-Object { $_ -and $_ -ne '' }
    $out.TestCount = @($cartSn).Count
    $dups = $cartSn | Group-Object | Where-Object { $_.Count -gt 1 }
    if ($dups) {
        $out.DupCount   = @($dups).Count
        $out.Duplicates = @($dups) | ForEach-Object { "$($_.Name) x$($_.Count)" }
    }
    $lspClean = $lspList | ForEach-Object {
        $m = [regex]::Match($_, '(?<!\d)(\d{5})(?!\d)')
        if ($m.Success) { $m.Groups[1].Value } else { $null }
    } | Where-Object { $_ } | Select-Object -Unique
    $out.LspValues = @($lspClean)
    if (@($lspClean).Count -gt 0) {
        $out.LspOK = (@($lspClean).Count -eq 1)
    }
    $lut = @{}
    if ($script:GXINF_Map) {
        foreach ($k in $script:GXINF_Map.Keys) {
            foreach ($sn in (($script:GXINF_Map[$k] + '') -split ',')) {
                $s = ($sn + '').Trim()
                if ($s) { $lut[$s] = $k }
            }
        }
    }
    foreach ($ins in ($instrList | Where-Object { $_ })) {
        $t = $null
        if ($lut.ContainsKey($ins)) { $t = $lut[$ins] } else { $t = 'Unknown' }
        if (-not $out.InstrumentByType.Contains($t)) { $out.InstrumentByType[$t] = 0 }
        $out.InstrumentByType[$t] = [int]$out.InstrumentByType[$t] + 1
    }
    return [pscustomobject]$out
}

function Import-CsvRowsStreaming {
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$StartRow = 10,
        [Parameter(Mandatory)][scriptblock]$ProcessRow
    )
    $probe = @(Get-CsvFileLines -Path $Path -TotalCount 80)
    $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $probe
    $delim = $(if ($profile -and $profile.Delimiter) { $profile.Delimiter } else { Get-CsvDelimiter -Path $Path })
    $effectiveStartRow = $(if ($profile) { [int]$profile.DataStartRow } else { [int]$StartRow })

    $sr = $null
    try {
        $enc = [System.Text.Encoding]::Default
        $sr = New-Object System.IO.StreamReader -ArgumentList @($Path, $enc, $true)
        $r = 0
        while (($line = $sr.ReadLine()) -ne $null) {
            $r++
            if ($r -lt $effectiveStartRow) { continue }
            if (-not $line -or $line.Trim().Length -eq 0) { continue }
            $fields = ConvertTo-CsvFields -Line $line -Delimiter $delim
            if ($fields -and (($fields -join '').Trim().Length -gt 0)) {
                & $ProcessRow -Fields $fields -RowIndex $r
            }
        }
    } finally {
        try { if ($sr) { $sr.Close() } } catch {}
        try { if ($sr) { $sr.Dispose() } } catch {}
    }
}
