# INF5 May 10 / May 14 correlation report

## Executive summary

- INF5 has two correlated midnight restart sequences: 2026-05-10 00:20 and 2026-05-14 00:18/01:56/01:57.

- The May 14 operator message is strongly corroborated by Event ID 1074: `MusNotificationUx.exe` initiated a planned restart on behalf of `SE\Labuser_IPT` at 00:18:26.

- May 10 is also a planned Windows Update/servicing-style restart, but initiated by `svchost.exe` under SYSTEM rather than `MusNotificationUx.exe`.

- INF1 and INF3 do not show matching 00:00-02:15 events on May 10 or May 14 in the collected data.

- INF5 differs from INF1/INF3 in Windows Update policy rows: INF1/INF3 show WSUS/DisableDualScan/TargetReleaseVersion; INF5 does not in the collected registry rows.


## INF5 focused timeline

- 2026-05-09 12:35:26 | Microsoft-Windows-WindowsUpdateClient | Event 26 | Windows Update successfully found 2 updates.

- 2026-05-09 12:35:26 | Microsoft-Windows-WindowsUpdateClient | Event 26 | Windows Update successfully found 0 updates.

- 2026-05-09 12:35:28 | Microsoft-Windows-WindowsUpdateClient | Event 41 | An update was downloaded.

- 2026-05-09 12:35:28 | Microsoft-Windows-WindowsUpdateClient | Event 43 | Installation Started: Windows has started installing the following update: Intel(R) Corporation - HIDClass - 2.2.2.17

- 2026-05-09 12:35:28 | Microsoft-Windows-WindowsUpdateClient | Event 44 | Windows Update started downloading an update.

- 2026-05-09 12:35:39 | Microsoft-Windows-WindowsUpdateClient | Event 19 | Installation Successful: Windows successfully installed the following update: Intel(R) Corporation - HIDClass - 2.2.2.17

- 2026-05-09 21:36:34 | Microsoft-Windows-WindowsUpdateClient | Event 26 | Windows Update successfully found 0 updates.

- 2026-05-10 00:15:32 | Microsoft-Windows-WindowsUpdateClient | Event 26 | Windows Update successfully found 0 updates.

- 2026-05-10 00:20:00 | User32 | Event 1074 | The process C:\Windows\system32\svchost.exe (CPHD-5RT7YB4) has initiated the restart of computer CPHD-5RT7YB4 on behalf of user NT AUTHORITY\SYSTEM for the following reason: Operating System: Service pack (Planned) Reason Code: 0x80020010 Shutdown Type: restart Comment:

- 2026-05-10 00:20:07 | EventLog | Event 6006 | The Event log service was stopped.

- 2026-05-10 00:20:12 | Microsoft-Windows-Kernel-General | Event 13 | The operating system is shutting down at system time ‎2026‎-‎05‎-‎09T23:20:12.860723400Z.

- 2026-05-10 00:20:12 | Microsoft-Windows-Kernel-Power | Event 109 | The kernel power manager has initiated a shutdown transition. Shutdown Reason: Kernel API

- 2026-05-10 00:20:27 | Microsoft-Windows-Kernel-General | Event 20 | The leap second configuration has been updated. Reason: Leap second data initialized from registry during boot Leap seconds enabled: true New leap second count: 0 Old leap second count: 0

- 2026-05-10 00:20:27 | Microsoft-Windows-Kernel-General | Event 12 | The operating system started at system time ‎2026‎-‎05‎-‎09T23:20:26.500000000Z.

- 2026-05-10 00:20:27 | Microsoft-Windows-Kernel-Boot | Event 20 | The last shutdown's success status was true. The last boot's success status was true.

- 2026-05-10 00:20:27 | Microsoft-Windows-Kernel-Boot | Event 292 | Failed to update the SBAT value in FW.

- 2026-05-10 00:20:54 | EventLog | Event 6005 | The Event log service was started.

- 2026-05-13 07:25:23 | Microsoft-Windows-WindowsUpdateClient | Event 26 | Windows Update successfully found 2 updates.

- 2026-05-13 07:25:34 | Microsoft-Windows-WindowsUpdateClient | Event 26 | Windows Update successfully found 2 updates.

- 2026-05-13 07:25:34 | Microsoft-Windows-WindowsUpdateClient | Event 44 | Windows Update started downloading an update.

- 2026-05-13 07:25:34 | Microsoft-Windows-WindowsUpdateClient | Event 44 | Windows Update started downloading an update.

- 2026-05-13 07:25:34 | Microsoft-Windows-WindowsUpdateClient | Event 44 | Windows Update started downloading an update.

- 2026-05-13 07:51:05 | Microsoft-Windows-WindowsUpdateClient | Event 41 | An update was downloaded.

- 2026-05-13 08:42:21 | Microsoft-Windows-WindowsUpdateClient | Event 43 | Installation Started: Windows has started installing the following update: Windows Malicious Software Removal Tool x64 - v5.141 (KB890830)

- 2026-05-13 08:43:12 | Microsoft-Windows-WindowsUpdateClient | Event 19 | Installation Successful: Windows successfully installed the following update: Windows Malicious Software Removal Tool x64 - v5.141 (KB890830)

- 2026-05-13 09:50:56 | Microsoft-Windows-WindowsUpdateClient | Event 41 | An update was downloaded.

- 2026-05-13 10:43:28 | Microsoft-Windows-WindowsUpdateClient | Event 43 | Installation Started: Windows has started installing the following update: 2026-05 Cumulative Update for .NET Framework 3.5, 4.8 and 4.8.1 for Windows 10 Version 21H2 for x64 (KB5088859)

- 2026-05-13 22:03:17 | Microsoft-Windows-WindowsUpdateClient | Event 26 | Windows Update successfully found 0 updates.

- 2026-05-14 00:18:26 | User32 | Event 1074 | The process C:\Windows\system32\MusNotificationUx.exe (CPHD-5RT7YB4) has initiated the restart of computer CPHD-5RT7YB4 on behalf of user SE\Labuser_IPT for the following reason: Operating System: Service pack (Planned) Reason Code: 0x80020010 Shutdown Type: restart Comment:

- 2026-05-14 00:18:37 | EventLog | Event 6006 | The Event log service was stopped.

- 2026-05-14 00:18:42 | Microsoft-Windows-Kernel-Power | Event 109 | The kernel power manager has initiated a shutdown transition. Shutdown Reason: Kernel API

- 2026-05-14 00:18:43 | Microsoft-Windows-Kernel-General | Event 13 | The operating system is shutting down at system time ‎2026‎-‎05‎-‎13T23:18:43.205811900Z.

- 2026-05-14 00:19:15 | Microsoft-Windows-Kernel-Boot | Event 292 | Failed to update the SBAT value in FW.

- 2026-05-14 00:19:15 | Microsoft-Windows-Kernel-General | Event 12 | The operating system started at system time ‎2026‎-‎05‎-‎13T23:19:14.500000000Z.

- 2026-05-14 00:19:15 | Microsoft-Windows-Kernel-General | Event 20 | The leap second configuration has been updated. Reason: Leap second data initialized from registry during boot Leap seconds enabled: true New leap second count: 0 Old leap second count: 0

- 2026-05-14 00:19:15 | Microsoft-Windows-Kernel-Boot | Event 20 | The last shutdown's success status was true. The last boot's success status was true.

- 2026-05-14 00:19:45 | EventLog | Event 6005 | The Event log service was started.

- 2026-05-14 00:21:22 | Microsoft-Windows-WindowsUpdateClient | Event 19 | Installation Successful: Windows successfully installed the following update: 2026-05 Cumulative Update for .NET Framework 3.5, 4.8 and 4.8.1 for Windows 10 Version 21H2 for x64 (KB5088859)

- 2026-05-14 00:22:50 | Windows Error Reporting | Event 1001 | Fault bucket , type 0 Event Name: StoreAgentScanForUpdatesFailure0 Response: Not available Cab Id: 0 Problem signature: P1: Update; P2: 8024402c P3: 19044 P4: 7184 P5: Windows.Desktop P6: P7: P8: P9: P10: Attached files: These files may be available here: \\?\C:\ProgramData\Microsoft\Windows\WER\ReportQueue\NonCritical_Update;_a3b03fe89611f58a9bdd1

- 2026-05-14 00:22:51 | Windows Error Reporting | Event 1001 | Fault bucket , type 0 Event Name: StoreAgentScanForUpdatesFailure0 Response: Not available Cab Id: 0 Problem signature: P1: Update; P2: 8024402c P3: 19044 P4: 7184 P5: Windows.Desktop P6: P7: P8: P9: P10: Attached files: \\?\C:\ProgramData\Microsoft\Windows\WER\Temp\WER4E50.tmp.WERInternalMetadata.xml These files may be available here: \\?\C:\Progr

- 2026-05-14 00:22:55 | Microsoft-Windows-WindowsUpdateClient | Event 25 | Windows Update failed to check for updates with error 0x8024402C.

- 2026-05-14 00:22:55 | Microsoft-Windows-WindowsUpdateClient | Event 25 | Windows Update failed to check for updates with error 0x8024402C.

- 2026-05-14 00:24:04 | Microsoft-Windows-WindowsUpdateClient | Event 25 | Windows Update failed to check for updates with error 0x8024402C.

- 2026-05-14 01:04:27 | Windows Error Reporting | Event 1001 | Fault bucket 1428830914305276004, type 5 Event Name: StoreAgentScanForUpdatesFailure0 Response: Not available Cab Id: 0 Problem signature: P1: Update; P2: 8024402c P3: 19044 P4: 7184 P5: Windows.Desktop P6: P7: P8: P9: P10: Attached files: \\?\C:\ProgramData\Microsoft\Windows\WER\Temp\WER4E50.tmp.WERInternalMetadata.xml These files may be available

- 2026-05-14 01:09:50 | Windows Error Reporting | Event 1001 | Fault bucket 1424756974335802067, type 5 Event Name: RADAR_PRE_LEAK_64 Response: Not available Cab Id: 0 Problem signature: P1: javaw.exe P2: 8.0.1310.11 P3: 10.0.19044.2.0.0 P4: P5: P6: P7: P8: P9: P10: Attached files: \\?\C:\Users\LABUSE~1\AppData\Local\Temp\RDR4A38.tmp\empty.txt \\?\C:\ProgramData\Microsoft\Windows\WER\Temp\WER4A97.tmp.WERIntern

- 2026-05-14 01:11:01 | Microsoft-Windows-WindowsUpdateClient | Event 41 | An update was downloaded.

- 2026-05-14 01:25:03 | Microsoft-Windows-WindowsUpdateClient | Event 43 | Installation Started: Windows has started installing the following update: 2026-05 Cumulative Update for Windows 10 Version 21H2 for x64-based Systems (KB5087544)

- 2026-05-14 01:30:52 | Windows Error Reporting | Event 1001 | Fault bucket , type 0 Event Name: WindowsServicingFailureInfo Response: Not available Cab Id: 0 Problem signature: P1: 10.0.19041.7183:1 P2: 0x800F0984 0x800F0984 Matching binary: telnet.exe missing for component: amd64_microsoft-windows-telnet-client_31bf3856ad364e35_10.0.19041.7291_none_2cfae314da387b79 P3: File: storelayout.cpp(1698) - Component

- 2026-05-14 01:30:52 | Windows Error Reporting | Event 1001 | Fault bucket , type 0 Event Name: WindowsServicingFailureInfo Response: Not available Cab Id: 0 Problem signature: P1: 10.0.19041.7183:1 P2: 0x800F0984 0x800F0984 Matching binary: telnet.exe missing for component: amd64_microsoft-windows-telnet-client_31bf3856ad364e35_10.0.19041.7291_none_2cfae314da387b79 P3: File: storelayout.cpp(1698) - Component

- 2026-05-14 01:30:54 | Windows Error Reporting | Event 1001 | Fault bucket INVALID_REQUEST, type 0 Event Name: WindowsServicingFailureInfo Response: Not available Cab Id: 0 Problem signature: P1: 10.0.19041.7183:1 P2: 0x800F0984 0x800F0984 Matching binary: telnet.exe missing for component: amd64_microsoft-windows-telnet-client_31bf3856ad364e35_10.0.19041.7291_none_2cfae314da387b79 P3: File: storelayout.cpp(16

- 2026-05-14 01:56:01 | User32 | Event 1074 | The process C:\Windows\system32\svchost.exe (CPHD-5RT7YB4) has initiated the restart of computer CPHD-5RT7YB4 on behalf of user NT AUTHORITY\SYSTEM for the following reason: Operating System: Service pack (Planned) Reason Code: 0x80020010 Shutdown Type: restart Comment:

- 2026-05-14 01:56:28 | EventLog | Event 6006 | The Event log service was stopped.

- 2026-05-14 01:56:33 | Microsoft-Windows-Kernel-Power | Event 109 | The kernel power manager has initiated a shutdown transition. Shutdown Reason: Kernel API

- 2026-05-14 01:56:34 | Microsoft-Windows-Kernel-General | Event 13 | The operating system is shutting down at system time ‎2026‎-‎05‎-‎14T00:56:34.736676000Z.

- 2026-05-14 01:56:50 | Microsoft-Windows-Kernel-General | Event 20 | The leap second configuration has been updated. Reason: Leap second data initialized from registry during boot Leap seconds enabled: true New leap second count: 0 Old leap second count: 0

- 2026-05-14 01:56:50 | Microsoft-Windows-Kernel-Boot | Event 20 | The last shutdown's success status was true. The last boot's success status was true.

- 2026-05-14 01:56:50 | Microsoft-Windows-Kernel-Boot | Event 292 | Failed to update the SBAT value in FW.

- 2026-05-14 01:56:50 | Microsoft-Windows-Kernel-General | Event 12 | The operating system started at system time ‎2026‎-‎05‎-‎14T00:56:49.500000000Z.

- 2026-05-14 01:57:17 | EventLog | Event 6005 | The Event log service was started.

- 2026-05-14 01:57:27 | User32 | Event 1074 | The process C:\Windows\servicing\TrustedInstaller.exe (CPHD-5RT7YB4) has initiated the restart of computer CPHD-5RT7YB4 on behalf of user NT AUTHORITY\SYSTEM for the following reason: Operating System: Upgrade (Planned) Reason Code: 0x80020003 Shutdown Type: restart Comment:

- 2026-05-14 01:57:31 | EventLog | Event 6006 | The Event log service was stopped.

- 2026-05-14 01:57:36 | Microsoft-Windows-Kernel-Power | Event 109 | The kernel power manager has initiated a shutdown transition. Shutdown Reason: Kernel API

- 2026-05-14 01:57:36 | Microsoft-Windows-Kernel-General | Event 13 | The operating system is shutting down at system time ‎2026‎-‎05‎-‎14T00:57:36.342393500Z.

- 2026-05-14 01:57:49 | Microsoft-Windows-Kernel-Boot | Event 292 | Failed to update the SBAT value in FW.

- 2026-05-14 01:57:49 | Microsoft-Windows-Kernel-Boot | Event 20 | The last shutdown's success status was true. The last boot's success status was true.

- 2026-05-14 01:57:49 | Microsoft-Windows-Kernel-General | Event 12 | The operating system started at system time ‎2026‎-‎05‎-‎14T00:57:48.500000000Z.

- 2026-05-14 01:57:49 | Microsoft-Windows-Kernel-General | Event 20 | The leap second configuration has been updated. Reason: Leap second data initialized from registry during boot Leap seconds enabled: true New leap second count: 0 Old leap second count: 0

- 2026-05-14 01:58:16 | EventLog | Event 6005 | The Event log service was started.

- 2026-05-14 01:59:54 | Microsoft-Windows-WindowsUpdateClient | Event 19 | Installation Successful: Windows successfully installed the following update: 2026-05 Cumulative Update for Windows 10 Version 21H2 for x64-based Systems (KB5087544)


## Category counts

| INF   | Computer     | Category                                                                            |   Count |
|:------|:-------------|:------------------------------------------------------------------------------------|--------:|
| INF1  | CPHD-2MYMZ44 | Clean Windows power off via winlogon; original trigger not identified by this event |      18 |
| INF1  | CPHD-2MYMZ44 | SCCM / Configuration Manager client initiated restart                               |       3 |
| INF1  | CPHD-2MYMZ44 | Windows servicing / post-install restart                                            |       2 |
| INF3  | CPHD-B94KQ54 | Clean Windows power off via winlogon; original trigger not identified by this event |      56 |
| INF3  | CPHD-B94KQ54 | User/session power UI path                                                          |       6 |
| INF3  | CPHD-B94KQ54 | SCCM / Configuration Manager client initiated restart                               |       2 |
| INF3  | CPHD-B94KQ54 | Windows servicing / post-install restart                                            |       2 |
| INF3  | CPHD-B94KQ54 | Other/unknown initiator                                                             |       1 |
| INF5  | CPHD-5RT7YB4 | Clean Windows power off via winlogon; original trigger not identified by this event |       7 |
| INF5  | CPHD-5RT7YB4 | Windows Update/servicing planned restart via service host                           |       4 |
| INF5  | CPHD-5RT7YB4 | User/session power UI path                                                          |       3 |
| INF5  | CPHD-5RT7YB4 | Windows servicing / post-install restart                                            |       3 |
| INF5  | CPHD-5RT7YB4 | Windows Update UX prompt / user-visible restart path                                |       2 |


## Key policy rows

| INF   | Path                                                                                                        | Name                          | Value                                  |
|:------|:------------------------------------------------------------------------------------------------------------|:------------------------------|:---------------------------------------|
| INF1  | HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate                                                     | TargetReleaseVersionInfo      | 21H2                                   |
| INF1  | HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate                                                     | DisableDualScan               | 1                                      |
| INF1  | HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate                                                     | WUServer                      | http://dhrau1svapwu01.danaher.org:8530 |
| INF1  | HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate                                                     | WUStatusServer                | http://dhrau1svapwu01.danaher.org:8530 |
| INF1  | Microsoft.PowerShell.Core\Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU | UseWUServer                   | 1                                      |
| INF1  | Microsoft.PowerShell.Core\Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU | NoAutoRebootWithLoggedOnUsers | 1                                      |
| INF1  | Microsoft.PowerShell.Core\Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU | NoAUShutdownOption            | 1                                      |
| INF1  | HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU                                                  | UseWUServer                   | 1                                      |
| INF1  | HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU                                                  | NoAutoRebootWithLoggedOnUsers | 1                                      |
| INF1  | HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU                                                  | NoAUShutdownOption            | 1                                      |
| INF1  | HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings                                                          | ActiveHoursEnd                | 17                                     |
| INF1  | HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings                                                          | ActiveHoursStart              | 8                                      |
| INF1  | HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings                                                          | SmartActiveHoursStart         | 22                                     |
| INF1  | HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings                                                          | SmartActiveHoursEnd           | 13                                     |
| INF3  | HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate                                                     | TargetReleaseVersionInfo      | 21H2                                   |
| INF3  | HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate                                                     | DisableDualScan               | 1                                      |
| INF3  | HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate                                                     | WUServer                      | http://dhrau1svapwu01.danaher.org:8530 |
| INF3  | HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate                                                     | WUStatusServer                | http://dhrau1svapwu01.danaher.org:8530 |
| INF3  | Microsoft.PowerShell.Core\Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU | UseWUServer                   | 1                                      |
| INF3  | Microsoft.PowerShell.Core\Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU | NoAutoRebootWithLoggedOnUsers | 1                                      |
| INF3  | Microsoft.PowerShell.Core\Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU | NoAUShutdownOption            | 1                                      |
| INF3  | HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU                                                  | UseWUServer                   | 1                                      |
| INF3  | HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU                                                  | NoAutoRebootWithLoggedOnUsers | 1                                      |
| INF3  | HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU                                                  | NoAUShutdownOption            | 1                                      |
| INF3  | HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings                                                          | ActiveHoursEnd                | 17                                     |
| INF3  | HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings                                                          | ActiveHoursStart              | 8                                      |
| INF3  | HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings                                                          | SmartActiveHoursStart         | 8                                      |
| INF3  | HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings                                                          | SmartActiveHoursEnd           | 18                                     |
| INF5  | Microsoft.PowerShell.Core\Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU | NoAutoRebootWithLoggedOnUsers | 1                                      |
| INF5  | Microsoft.PowerShell.Core\Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU | NoAUShutdownOption            | 1                                      |
| INF5  | HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU                                                  | NoAutoRebootWithLoggedOnUsers | 1                                      |
| INF5  | HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU                                                  | NoAUShutdownOption            | 1                                      |
| INF5  | HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings                                                          | ActiveHoursEnd                | 17                                     |
| INF5  | HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings                                                          | ActiveHoursStart              | 8                                      |
| INF5  | HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings                                                          | SmartActiveHoursStart         | 23                                     |
| INF5  | HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings                                                          | SmartActiveHoursEnd           | 12                                     |