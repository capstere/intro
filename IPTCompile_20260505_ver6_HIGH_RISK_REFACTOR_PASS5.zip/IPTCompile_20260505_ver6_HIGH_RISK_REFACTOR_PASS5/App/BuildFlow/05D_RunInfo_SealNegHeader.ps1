﻿# Build phase: Run Information Seal Test NEG header block
# Extracted/split during HIGH_RISK_REFACTOR_PASS5.

        if ($selNeg) {
            $wsInfo.Cells["B$rowNegFile"].Style.Numberformat.Format = '@'
            $wsInfo.Cells["B$rowNegFile"].Value = (Get-CleanLeaf $selNeg)
        } else { $wsInfo.Cells["B$rowNegFile"].Value = '' }

        if ($headerNeg) {
            $docNeg = $headerNeg.DocumentNumber
            if ($docNeg) { $docNeg = ($docNeg -replace '(?i)\s+(?:Rev(?:ision)?|Effective|p\.)\b.*$','').Trim() }
            $wsInfo.Cells["B$rowNegDoc"].Value = $docNeg
            $wsInfo.Cells["B$rowNegRev"].Value = $headerNeg.Rev
            $wsInfo.Cells["B$rowNegEff"].Value = if ($headerNeg.EffectiveDisplay) { $headerNeg.EffectiveDisplay } else { $headerNeg.Effective }
            
            $negHeaderCheck = $null
            try { $negHeaderCheck = $headerNeg.HeaderCheck } catch {}
            $devNegDoc = $null; $devNegRev = $null; $devNegEff = $null

            if ($negHeaderCheck -and $negHeaderCheck.Details) {
                $linesDev = ($negHeaderCheck.Details -split "`r?`n")
                foreach ($ln in $linesDev) {
                    if ($ln -match '^-\s*DocumentNumber[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devNegDoc = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*Rev[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devNegRev = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*Effective[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devNegEff = $matches[1].Trim() }
                }
            }

            if ($negHeaderCheck) {
                if ($docNeg) {
                    if ($devNegDoc) { & $StyleMismatchCell $wsInfo.Cells["C$rowNegDoc"] ('Avvikande flikar: ' + $devNegDoc) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowNegDoc"] }
                }
                if ($headerNeg.Rev) {
                    if ($devNegRev) { & $StyleMismatchCell $wsInfo.Cells["C$rowNegRev"] ('Avvikande flikar: ' + $devNegRev) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowNegRev"] }
                }
                if ($headerNeg.Effective) {
                    if ($devNegEff) { & $StyleMismatchCell $wsInfo.Cells["C$rowNegEff"] ('Avvikande flikar: ' + $devNegEff) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowNegEff"] }
                }
            } else {
            }
        } else {
            $wsInfo.Cells["B$rowNegDoc"].Value = ''
            $wsInfo.Cells["B$rowNegRev"].Value = ''
            $wsInfo.Cells["B$rowNegEff"].Value = ''
        }

    } catch {
        Gui-Log ("⚠️ Header summary fel: " + $_.Exception.Message) 'Warn'
    }

} catch {
    Gui-Log "⚠️ Run Information fel: $($_.Exception.Message)" 'Warn'
}

