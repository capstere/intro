﻿# Build phase: QC reminder block
# Extracted/split during HIGH_RISK_REFACTOR_PASS5.

# ============================
# === QC-påminnelse (HIV/HBV/HCV) → Information E16:F18 ===
# ============================
try {
    if ($script:QcReminderB3) {
        $wsInfo = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
        if ($wsInfo) {
$eCol  = 5   # E
$fCol  = 6   # F
# Radhöjd gäller hela Excel-raden.
# Därför ska QC-påminnelsen inte placeras mitt i vänster Run Information-panel,
# eftersom den annars kan göra Dokumentkontroll-/Snabblänksrader ojämnt höga.
# Vänsterpanelen använder rad 1-36, så QC börjar tidigast på rad 38.
$qcRow = 38
try {
    if ($script:RunInfoSpBlockLastRow -and [int]$script:RunInfoSpBlockLastRow -ge ($qcRow - 1)) {
        $qcRow = [int]$script:RunInfoSpBlockLastRow + 2
    }
} catch {
    $qcRow = 38
}

            # Färger (samma som SharePoint Info-rubriken)
            $HeaderBg  = [System.Drawing.Color]::FromArgb(68, 84, 106)
            $HeaderFg  = [System.Drawing.Color]::White
            $SectionBg = [System.Drawing.Color]::FromArgb(217, 225, 242)
            $SectionFg = [System.Drawing.Color]::FromArgb(0, 32, 96)
            $BorderClr = [System.Drawing.Color]::FromArgb(68, 84, 106)

            # --- Rad 16: rubrik (sammanfogad E16:F16) ---
            $wsInfo.Cells[$qcRow, $eCol, $qcRow, $fCol].Merge = $true
            $hdrCell = $wsInfo.Cells[$qcRow, $eCol]
            $hdrCell.Value = ('QC Data – ' + $script:QcReminderB3)
            $hdrCell.Style.Font.Bold = $true
            $hdrCell.Style.Font.Size = 14
            $hdrCell.Style.Font.Name = 'Calibri'
            $hdrCell.Style.Font.Color.SetColor($HeaderFg)
            $hdrCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $hdrCell.Style.Fill.BackgroundColor.SetColor($HeaderBg)
            $hdrCell.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Left
            $hdrCell.Style.VerticalAlignment   = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
            $wsInfo.Row($qcRow).Height = 22

            # --- Rad 17: "Additional QC-Data?" / "JA" ---
            $wsInfo.Cells[($qcRow+1), $eCol].Value = 'Additional QC-Data?'
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Font.Bold = $true
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Font.Name = 'Calibri'
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Font.Size = 10
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Font.Color.SetColor($SectionFg)
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Fill.BackgroundColor.SetColor($SectionBg)

            $wsInfo.Cells[($qcRow+1), $fCol].Value = 'JA'
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Font.Bold = $true
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Font.Name = 'Calibri'
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Font.Size = 10
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(0, 128, 0))
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::White)
            $wsInfo.Cells[($qcRow+1), $fCol].Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Left

            # --- Rad 18: "Lathund QC data" med länk (sammanfogad E18:F18) ---
            $wsInfo.Cells[($qcRow+2), $eCol, ($qcRow+2), $fCol].Merge = $true
            $linkCell = $wsInfo.Cells[($qcRow+2), $eCol]

            $lathundPath = ''
            if ($Config) {
                # Primär nyckel (finns i Config.ps1 i LIVE-zippen)
                if ($Config.Contains('QcDataCheatSheetLink')) {
                    $lathundPath = $Config.QcDataCheatSheetLink
                }
                # Reservnyckel om du någon gång vill använda ett annat namn
                elseif ($Config.Contains('QcReminderLathundPath')) {
                    $lathundPath = $Config.QcReminderLathundPath
                }
            }

            $linkCell.Value = 'Lathund QC data'
            $linkCell.Style.Font.Name = 'Calibri'
            $linkCell.Style.Font.Size = 10
            $linkCell.Style.Font.UnderLine = $true
            $linkCell.Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(5, 99, 193))
            $linkCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $linkCell.Style.Fill.BackgroundColor.SetColor($SectionBg)
            # Centrera sammanfogad E18:F18 (både horisontellt och vertikalt)
            $linkCell.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center
            $linkCell.Style.VerticalAlignment   = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center

            if ($lathundPath) {
                try {
                    # Bygg stabil URI:
                    $uriText = $lathundPath
                    if ($uriText -match '^(?i)https?://') {
                        $linkCell.Hyperlink = New-Object System.Uri($uriText)
                   }
                    elseif ($uriText -match '^[A-Za-z]:\\') {
                        # ex: N:\Folder\File.docx -> file:///N:/Folder/File.docx
                        $fileUri = 'file:///' + ($uriText -replace '\\','/')
                        $fileUri = [System.Uri]::EscapeUriString($fileUri)
                        $linkCell.Hyperlink = New-Object System.Uri($fileUri)
                    }
                    elseif ($uriText -match '^\\\\') {
                        # UNC-sökväg: System.Uri hanterar \\server\share nativt och bevarar Unicode
                        $linkCell.Hyperlink = New-Object System.Uri($uriText)
                    }
                    else {
                        # Sista försök (om du ger en redan korrekt URI)
                        $linkCell.Hyperlink = New-Object System.Uri($uriText)
                    }
                 } catch {
                     Gui-Log ("⚠️ QC Data: Kunde inte skapa hyperlänk till '{0}': {1}" -f $lathundPath, $_.Exception.Message) 'Warn'
                 }
             }

            # Ramar runt hela QC-påminnelseblocket
            $rng = $wsInfo.Cells[$qcRow, $eCol, ($qcRow+2), $fCol]
            $rng.Style.Border.Top.Style    = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Left.Style   = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Right.Style  = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Top.Color.SetColor($BorderClr)
            $rng.Style.Border.Bottom.Color.SetColor($BorderClr)
            $rng.Style.Border.Left.Color.SetColor($BorderClr)
            $rng.Style.Border.Right.Color.SetColor($BorderClr)
        }
    }
} catch {
}

