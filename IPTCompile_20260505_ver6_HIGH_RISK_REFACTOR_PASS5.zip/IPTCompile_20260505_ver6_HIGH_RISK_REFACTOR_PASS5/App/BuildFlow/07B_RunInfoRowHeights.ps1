﻿# Build phase: Run Information row-height polish
# Extracted/split during HIGH_RISK_REFACTOR_PASS5.

# ============================================================
# === Run Information: fasta radhöjder vänsterpanel        ===
# ============================================================
try {
    $wsRI = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if ($wsRI) {
        # Vanliga datarader i vänsterpanelen.
        # Dessa ska vara visuellt lika höga även om högerpanelen använder samma radnummer.
        $runInfoDataRows = @(
            2,3,4,5,        # Körningsinfo
            8,9,10,11,      # Datakällor
            14,15,16,17,18,19,20,  # Worksheet / Dokumentkontroll
            21,22,23,24,    # Seal Test POS
            25,26,27,28,    # Seal Test NEG
            31,32,33,34,35,36 # Snabblänkar
        )
        foreach ($rr in $runInfoDataRows) {
            try {
                $wsRI.Row($rr).Height = 15
                $wsRI.Row($rr).CustomHeight = $true
                # Vänsterpanelens dataceller ska inte driva upp radhöjden.
                $wsRI.Cells[$rr,1,$rr,3].Style.WrapText = $false
                $wsRI.Cells[$rr,1,$rr,3].Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
            } catch {}
        }
        # Rubrik-/sektionsrader får vara lite högre men ska också vara konsekventa.
        foreach ($rr in @(1,7,13,30)) {
            try {
                $wsRI.Row($rr).Height = 22
                $wsRI.Row($rr).CustomHeight = $true
                $wsRI.Cells[$rr,1,$rr,3].Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
            } catch {}
        }
    }
} catch {
    Gui-Log "⚠️ Run Information radhöjdsjustering misslyckades: $($_.Exception.Message)" 'Warn'
}

            # ============================================================
            # === Sample Reagent Checklist-markering (additiv)         ===
            # ============================================================
            try {
                $_srhPNs = @()
                try { $_srhPNs = @(Get-ConfigValue -Name 'SampleReagentChecklistPNs' -Default @()) } catch {}

                if ($_srhPNs.Count -gt 0) {
                    $_srhWs = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
                    if ($_srhWs -and $_srhWs.Dimension) {
                        $_srhLabelCol = $spStartCol
                        $_srhValueCol = $spStartCol + 1
                        $_srhPNRow  = -1; $_srhUseRow = -1
                        $_srhPNVal  = ''; $_srhUseVal = ''

                        for ($_sr = ($spStartRow + 1); $_sr -le ($spStartRow + 120); $_sr++) {
                            $_srhLabel = (Normalize-HeaderText ($_srhWs.Cells[$_sr, $_srhLabelCol].Text + '')).Trim()
                            if ($_srhLabel -ieq 'Sample Reagent P/N') {
                                $_srhPNRow = $_sr
                                $_srhPNVal = ($_srhWs.Cells[$_sr, $_srhValueCol].Text + '').Trim()
                            }
                            if ($_srhLabel -ieq 'Sample Reagent use') {
                                $_srhUseRow = $_sr
                                $_srhUseVal = ($_srhWs.Cells[$_sr, $_srhValueCol].Text + '').Trim()
                            }
                        }

                        $_srhMatch = $false
                        if ($_srhPNVal) {
                            foreach ($_pn in $_srhPNs) {
                                if ($_srhPNVal -eq ($_pn + '').Trim()) { $_srhMatch = $true; break }
                            }
                        }

                        if ($_srhMatch) {
                            $_srhHighlightBg = [System.Drawing.Color]::FromArgb(255, 255, 200)
                            $_srhWarningBg   = [System.Drawing.Color]::FromArgb(255, 235, 156)
                            $_srhWarningFg   = [System.Drawing.Color]::FromArgb(156, 101, 0)
                            $_srhOkBg        = [System.Drawing.Color]::FromArgb(198, 239, 206)
                            $_srhOkFg        = [System.Drawing.Color]::FromArgb(0, 97, 0)

                            if ($_srhPNRow -gt 0) {
                                $_srhWs.Cells[$_srhPNRow, $_srhValueCol].Style.Fill.PatternType = 'Solid'
                                $_srhWs.Cells[$_srhPNRow, $_srhValueCol].Style.Fill.BackgroundColor.SetColor($_srhHighlightBg)
                                $_srhWs.Cells[$_srhPNRow, $_srhValueCol].Style.Font.Bold = $true
                            }

                            if ($_srhUseRow -gt 0) {
                                if ($_srhUseVal) {
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.PatternType = 'Solid'
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.BackgroundColor.SetColor($_srhOkBg)
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Color.SetColor($_srhOkFg)
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Bold = $true
                                } else {
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Value = '⚠ SAKNAS'
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.PatternType = 'Solid'
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.BackgroundColor.SetColor($_srhWarningBg)
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Color.SetColor($_srhWarningFg)
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Bold = $true
                                    Gui-Log '⚠️ Sample Reagent Saknas' 'Warn'
                                }
                            }
                        }
                    }
                }
            } catch {
                Gui-Log "⚠️ Sample Reagent highlight: $($_.Exception.Message)" 'Warn'
            }

        }
    }
} catch {
    Gui-Log "⚠️ SP-blad: $($_.Exception.Message)" 'Warn'
}

