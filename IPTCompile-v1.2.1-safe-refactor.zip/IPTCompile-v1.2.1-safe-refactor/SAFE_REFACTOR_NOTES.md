﻿# IPTCompile v1.2.1-safe-refactor

Detta paket är en säker refactor-omgång som bara flyttar verifierade funktionsdefinitioner ur `Main.ps1`.

## Faktiskt utfört
- `Modules/*` är lämnade intakta och används fortfarande av runtime.
- Följande funktioner har flyttats ur `Main.ps1` till `App/*` som rena funktionsfiler utan top-level UI/event-kod:
  - `App/UiHelpers.ps1`
  - `App/Bootstrap.ps1`
  - `App/UiDialogs.ps1`
  - `App/BuildController.ps1`
  - `App/UiTheme.ps1`
- `Main.ps1` dot-sourcar nu dessa `App/*`-filer vid den punkt där första flyttade funktionen tidigare definierades.
- `App/Splash.ps1`, `Ui/Styling.ps1`, `Rules/RuleBank.compiled.ps1`, `Templates/output_template-v4.xlsx` har lagts till som speglingar/referenser.

## Medvetet ej gjort
- Ingen aggressiv uppdelning av `Modules/DataHelpers.ps1`, `Modules/RuleEngine.ps1`, `Modules/OpenXmlHelpers.ps1` eller annan modul med risk för beteendedrift.
- Ingen flytt av top-level WinForms-kod eller event subscriptions ur `Main.ps1`.
- `Core/*` och `Infrastructure/*` är reserverade platshållare för framtida, säker extrahering.

## Syfte
Att ge en verklig, körbar refactor utan att börja gissa om blockgränser i UI/event-kod.
