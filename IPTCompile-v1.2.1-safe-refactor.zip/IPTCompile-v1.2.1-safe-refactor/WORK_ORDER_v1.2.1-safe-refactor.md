﻿# WORK ORDER v1.2.1-safe-refactor

1. Verifiera att `Main.ps1` startar normalt.
2. Verifiera att följande funktioner inte längre definieras i `Main.ps1` utan i `App/*`:
   - UiHelpers
   - Bootstrap
   - UiDialogs
   - BuildController
   - UiTheme
3. Verifiera att inga `App/*`-filer innehåller top-level `.Add_Click(...)`, `.Controls.Add(...)`, `Application.Run(...)` eller annan runtime-kod.
4. Verifiera att runtime fortfarande använder `Modules/*`.
5. Kör smoke test: start, scan, build, sign, output.
