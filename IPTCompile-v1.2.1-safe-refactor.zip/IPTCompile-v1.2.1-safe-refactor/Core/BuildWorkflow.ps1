﻿function Invoke-IptBuildWorkflow {
    throw 'Invoke-IptBuildWorkflow is reserved for a future safe refactor. Main.ps1 still orchestrates the live workflow in v1.2.1-safe-refactor.'
}
