﻿@{
    'v1.3.6 2026 04 26' = @'
Nytt i denna version:

• Den här dialogrutan.
• SharePoint Order/Batch/LSP visas tydligare i Run Information.
• Säkrare hantering av HPV Sample code 0.
• Seal Test "N/A" triggar inte längre falsk "Saknar utvägning".

'@
    'v1.3.8 2026 04 28' = @'
Nytt i denna version:

• SharePoint-sökning använder Order# som primär nyckel.
• SP Kontroll visas tydligare i Run Information med egna rader för Order#, Batch# och LSP.
• Batch# och LSP används som verifieringsvärden, inte som primär SharePoint-nyckel.
• QC Data-påminnelsen flyttas ned automatiskt så att den inte överlappar SharePoint-blocket.
• Split-batch visas och kontrolleras mer robust.

'@
    'v1.3.9 2026 05 01' = @'
Nytt i denna version:

• Mindre korrigeringar av rapportflikarna.

'@
    'v1.4.0 2026 05 05' = @'
Nytt i denna version:

• Fixat Seal Test POS/NEG säger rätt: Print Full Name, Sign, and Date

'@
    'v1.4.1 2026 05 05' = @'
Nytt i denna version:

• Fixat "Test Type" i rapport.

'@
    'v1.4.3 2026 05 05' = @'
Nytt i denna version:

Om Seal Test POS/NEG är öppen i Excel:
→ signering stoppas innan skrivning

Om Worksheet är öppen i Excel:
→ signering stoppas innan signeringsplan/skrivning

Om någon öppnar Worksheet efter kontroll men före skrivning:
→ OpenXML-skrivningen försöker ta exklusivt lås
→ misslyckas säkert i stället för att skriva delvis

Om Excel ägarfil "~$..." finns:
→ signering stoppas

'@
    'v1.4.4 2026 05 09' = @'
Nytt i denna version:

• Mycket är städat och förbättrat bakom kulisserna.
• Signering ska nu vara säkrare om filer är öppna i Excel.
• Appen känner igen fler Worksheet-varianter.
• Några kontroller har blivit lite smartare.

'@
    'v1.4.5 2026 05 13' = @'
Nytt i denna version:

• HPV-kontroll för MAJOR FUNCTIONAL uppdaterad.

'@

    'v1.4.6 2026 05 17' = @'
Nytt i denna version:

• Signering avaktiverat tills vidare.

'@

    'v1.4.6 2026 05 18' = @'
Nytt i denna version:

• Signering endast aktivt för Seal Test-filer

'@


    'v1.4.7 2026 05 20' = @'
Nytt i denna version:

• Redo/Nästan redo-banner som visar om rapporten kan skapas.
• Smart förslag av Seal Test mode vid filsökning.
• Tydligare progress med faser under rapportbygget.
• Snabblänkar för att öppna rapport eller rapportmapp efter skapad rapport.
• Statusfältet visar endast antal skapade rapporter, ingen tidsbesparing.

'@

    'v1.4.8 2026 06 08' = @'
Nytt i denna version:

• Fungerar med "nytt" CSV-format.
• Förslag av Seal Test vid filsökning.

'@

}