# Trimmed evidence package – Infinity kiosk restart issue

Created from the v1.3 diagnostic output already collected from INF1, INF3 and INF5.

## What can be said with confidence

1. **INF5 restarted automatically/planned on 2026-05-10 at 00:20.**  
   Windows Event ID 1074 shows `C:\Windows\system32\svchost.exe` initiated a `restart` on behalf of `NT AUTHORITY\SYSTEM` with reason `Operating System: Service pack (Planned)` and reason code `0x80020010`.

2. **INF5 restart on 2026-05-14 correlates with the operator's Windows Update message.**  
   Windows Event ID 1074 shows `C:\Windows\system32\MusNotificationUx.exe` initiated a `restart` on behalf of `SE\Labuser_IPT` at `2026-05-14 00:18:26`, with reason `Operating System: Service pack (Planned)` and reason code `0x80020010`. This matches the observed message:
   > We've got an update for you... We'll restart and install this update at 12:29 AM...

3. **INF5 differs from INF1/INF3 in update policy and update level.**  
   INF1 and INF3 show WSUS-related policy rows (`WUServer`, `WUStatusServer`, `UseWUServer`, `DisableDualScan`, `TargetReleaseVersionInfo`). INF5 does not show these rows in the collected registry data. INF5 also shows May update KB5087544 installed on 2026-05-14, while INF1/INF3 do not show that KB in the collected hotfix list.

## Files

- `01_INF5_2026-05-10_auto_restart_evidence.csv`
- `02_INF5_2026-05-14_update_message_evidence.csv`
- `03_INF5_vs_INF1_INF3_concrete_differences.csv`
- `04_1074_compare_INF1_INF3_INF5_May10_May14.csv`
- `Infinity_Reboot_Trimmed_Evidence.xlsx`

## Important limitation

The logs prove Windows initiated the INF5 restarts through Windows Update/servicing components. They do **not** prove that a user clicked "Restart now"; the log shows the Windows Update notification component and the logged-in user context.
