﻿# Auto-extracted from Main.ps1 in high-risk refactor pass 2.
# Behavior should remain unchanged; functions were moved without intentional logic edits.

if (-not (Get-Command Convert-A1ToRowCol -ErrorAction SilentlyContinue)) {
    function Convert-A1ToRowCol {
        param(
            [string]$A1,
            [int]$DefaultRow = 1,
            [int]$DefaultCol = 5
        )

        if ([string]::IsNullOrWhiteSpace($A1)) {
            return [pscustomobject]@{ Row = $DefaultRow; Col = $DefaultCol }
        }

        $s = ($A1 + '').Trim().ToUpper()
        # Tillåt valfritt bladprefix som 'Information!E1' (vi använder bara adressdelen)
        if ($s -match '^(?:[^!]+!)?([A-Z]+)(\d+)$') {
            $letters = $matches[1]
            $row = [int]$matches[2]
            $col = 0
            foreach ($ch in $letters.ToCharArray()) {
                $col = ($col * 26) + ([int][char]$ch - [int][char]'A' + 1)
            }
            if ($row -lt 1) { $row = $DefaultRow }
            if ($col -lt 1) { $col = $DefaultCol }
            return [pscustomobject]@{ Row = $row; Col = $col }
        }

        return [pscustomobject]@{ Row = $DefaultRow; Col = $DefaultCol }
    }
}

if (-not (Get-Command Get-DataSummaryFindings -ErrorAction SilentlyContinue)) {
    function Get-DataSummaryFindings {
        param(
            [Parameter(Mandatory=$true)][object[]]$ExcelPackages,
            [Parameter(Mandatory=$false)][string]$AssayName = '',
            [Parameter(Mandatory=$false)][string]$SheetName = 'Data Summary'
        )

        # --- Bygg aktiv regeluppsättning utifrån assay ---
        $rules = New-Object System.Collections.Generic.List[object]
        try {
            if ($global:IPTConstants -and $global:IPTConstants.DataSummaryRules) {
                foreach ($rule in $global:IPTConstants.DataSummaryRules) {
                    $scope = ($rule.Scope + '').Trim()
                    if ($scope -ieq 'All') {
                        [void]$rules.Add($rule); continue
                    }
                    # Assay-specifikt scope: kontrollera matchande lista
                    if ($AssayName) {
                        $scopeKey = $scope + 'Assays'   # t.ex. 'Hpv' → 'HpvAssays'
                        $assayList = @()
                        if ($global:IPTConstants.ContainsKey($scopeKey)) {
                            $assayList = @($global:IPTConstants[$scopeKey])
                        }
                        $matched = $false
                        foreach ($a in $assayList) {
                            if ($AssayName -imatch [regex]::Escape($a)) { $matched = $true; break }
                        }
                        if ($matched) { [void]$rules.Add($rule) }
                    }
                }
            }
        } catch {}

        # Reservväg: om inga regler laddades, använd universella mönster
        if ($rules.Count -eq 0) {
            foreach ($fallbackRule in @(
                @{ Pattern = '*MINOR VISUAL*';      Severity = 'Minor'; Label = 'Minor Functional (Visual)' }
                @{ Pattern = '*MAJOR VISUAL*';      Severity = 'Major'; Label = 'Major Functional (Visual)' }
                @{ Pattern = '*BARCODE FAIL*';      Severity = 'Major'; Label = 'Major Functional (Barcode Scan)' }
                @{ Pattern = '*DELAMINATION*';      Severity = 'Minor'; Label = 'Minor Functional (Delamination)' }
                @{ Pattern = '*MISQUANTITATION*';   Severity = 'Major'; Label = 'Misquantitation' }
                @{ Pattern = '*MAJOR FUNCTIONAL*';  Severity = 'Major'; Label = 'Major Functional' }
                @{ Pattern = '*MINOR FUNCTIONAL*';  Severity = 'Minor'; Label = 'Minor Functional' }
            )) { [void]$rules.Add($fallbackRule) }
        }

        $results = New-Object System.Collections.Generic.List[object]
        $rowMin = 10; $rowMax = 340
        try { $rowMin = Get-Threshold -Key 'DataSummaryRowMin' -Default 10 } catch {}
        try { $rowMax = Get-Threshold -Key 'DataSummaryRowMax' -Default 340 } catch {}

        foreach ($pkg in $ExcelPackages) {
            if (-not $pkg -or -not $pkg.Workbook) { continue }
            $dataSummaryWs = $null
            foreach ($ws in $pkg.Workbook.Worksheets) {
                if ($ws.Name -ieq $SheetName) { $dataSummaryWs = $ws; break }
            }
            if (-not $dataSummaryWs) { continue }

            for ($row = $rowMin; $row -le $rowMax; $row++) {
                try {
                    $status = Get-SafeCellText -Ws $dataSummaryWs -Row $row -Col 3
                    if (-not $status) { continue }

                    # Matcha mot aktiva regler (första träff vinner)
                    $matchedRule = $null
                    foreach ($rule in $rules) {
                        if ($status -ilike $rule.Pattern) { $matchedRule = $rule; break }
                    }
                    if (-not $matchedRule) { continue }

                    $sampleId = Get-SafeCellText -Ws $dataSummaryWs -Row $row -Col 1
                    $comment  = Get-SafeCellText -Ws $dataSummaryWs -Row $row -Col 5
                    if (-not $sampleId) { continue }

                    [void]$results.Add([pscustomobject]@{
                        SampleId = $sampleId
                        Type     = $matchedRule.Label       # t.ex. 'Major Functional (Visual)'
                        Severity = $matchedRule.Severity    # 'Major' eller 'Minor'
                        Comment  = $comment
                        Source   = $SheetName               # 'Data Summary' eller 'Resample Data Summary'
                    })
                } catch {}
            }
        }
        return @($results.ToArray())
    }
}

