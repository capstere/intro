﻿function Write-RuleEngineDebugSheet {
param(
    [Parameter(Mandatory)][object]$Pkg,
    [Parameter(Mandatory)][pscustomobject]$RuleEngineResult,
    [Parameter(Mandatory=$false)][bool]$IncludeAllRows = $false,
    [Parameter(Mandatory=$false)][object[]]$DataSummaryFindings = @(),
    [Parameter(Mandatory=$false)][int]$StfCount = 0
)

# ============================================================================
# FÄRGDEFINITIONER (EPPlus-kompatibla)
# ============================================================================
$Colors = @{
    # Rubriker och sektioner
    HeaderBg       = [System.Drawing.Color]::FromArgb(68, 84, 106)    # Mörkblå
    HeaderFg       = [System.Drawing.Color]::White
    SectionBg      = [System.Drawing.Color]::FromArgb(217, 225, 242)  # Ljusblå
    SectionFg      = [System.Drawing.Color]::FromArgb(0, 32, 96)      # Mörkblå text
    
    # Status-färger
    OkBg           = [System.Drawing.Color]::FromArgb(198, 239, 206)  # Ljusgrön
    OkFg           = [System.Drawing.Color]::FromArgb(0, 97, 0)       # Mörkgrön
    
    # Major Functional (FP/FN) - MÖRKRÖD
    MajorBg        = [System.Drawing.Color]::FromArgb(255, 199, 206)  # Ljusröd
    MajorFg        = [System.Drawing.Color]::FromArgb(156, 0, 6)      # Mörkröd
    
    # Minor Functional / Max Pressure ≥90 - Ljusgul
    MinorBg        = [System.Drawing.Color]::FromArgb(255, 235, 156)  # Ljusgul
    MinorFg        = [System.Drawing.Color]::FromArgb(156, 101, 0)    # Brunish
    
    # Varningar (Instrument Error, övriga) - Orange/amber, distinkt från Minor Functional
    WarningBg      = [System.Drawing.Color]::FromArgb(255, 213, 128)  # Amber/orange
    WarningFg      = [System.Drawing.Color]::FromArgb(130, 70, 0)     # Mörkbrun
    
    # Tabell
    # Sätt tabellhuvudets bakgrund till samma mörkblå färg som huvudrubriken för att harmonisera med flikens färg
    TableHeaderBg  = [System.Drawing.Color]::FromArgb(68, 84, 106)    # Mörkblå (samma som HeaderBg)
    TableHeaderFg  = [System.Drawing.Color]::White
    TableAltRow    = [System.Drawing.Color]::FromArgb(232, 232, 232)  # Ljusgrå
    
    # Summering
    SummaryGoodBg  = [System.Drawing.Color]::FromArgb(198, 239, 206)  # Ljusgrön 0, 32, 96
}

# ============================================================================
# RADERA GAMMALT BLAD OCH SKAPA NYTT
# ============================================================================
try {
    $old = $Pkg.Workbook.Worksheets['QC Summary']
    if ($old) { $Pkg.Workbook.Worksheets.Delete($old) }
} catch {}

$ws = $Pkg.Workbook.Worksheets.Add('QC Summary')

# Sätt standardfont
try { 
    $ws.Cells.Style.Font.Name = 'Calibri'
    $ws.Cells.Style.Font.Size = 10
} catch {}

# ============================================================================
# KOLUMNDEFINITIONER (14 kolumner)
# ============================================================================
$headers = @(
    'Sample ID',
    'Error Code',
    'Avvikelse',
    'Notering',
    'Förväntat X/+',
    'Cartridge S/N',
    'Module S/N',
    'Förväntad Test Type',
    'Status',
    'Error Type',
    'Ersätts?',
    'Max Pressure (PSI)',
    'Test Result',
    'Error'
)

# ============================================================================
# HJÄLPFUNKTIONER
# ============================================================================

# Svensk översättning av RuleFlags

function _SvRuleFlags([string]$s) {
    $t = (($s + '')).Trim()
    if (-not $t) { return '' }

    $map = @{
        'TESTTYPE_MISMATCH'   = 'Fel Test Type'
        'SUFFIX_BAD'          = 'Fel suffix'
        'SUFFIX_MISSING'      = 'Saknar suffix'
        'DQ_DUP_SAMPLEID'     = 'Dubblett Sample ID'
        'DQ_DUP_CARTSN'       = 'Dubblett Cart S/N'
        'DQ_ASSAYVER_OUTLIER' = 'Assay Version (outlier)'
        'DQ_ASSAY_OUTLIER'    = 'Assay (outlier)'
        'RUNNO_BAD'           = 'Fel Rep-Nr'
        'SAMPLENUM_BAD'       = 'Fel Sample-Nr'
        'DELAM_PRESENT'       = 'Delam'
        'PRESSURE90_NOERR'    = 'Tryck ≥ 90 utan felkod'
        'MODULE_ERR_HOTSPOT'  = 'Återkommande modulfel'
        'REPL_A1'             = 'Ers. A'
        'REPL_A2'             = 'Ers. AA'
        'REPL_A3'             = 'Ers. AAA'
        'PREFIX_BAD'          = 'Fel prefix'
    }

    $tokens = @($t -split '[|,;]+' | ForEach-Object { ($_.Trim()) } | Where-Object { $_ })
    if (-not $tokens -or $tokens.Count -eq 0) { return $t }

    $out = foreach ($tok in $tokens) {
        if ($map.ContainsKey($tok)) { $map[$tok] } else { $tok }
    }
    return ($out -join ', ')
}

function Test-IsQcSummaryFailureRow {
    param([Parameter(Mandatory)][pscustomobject]$Row)

    $dev = (($Row.Deviation + '')).Trim()
    if ($dev.Length -gt 0 -and $dev -ne 'OK') { return $true }

    $obs = (($Row.ObservedCall + '')).Trim().ToUpperInvariant()
    if ($obs -eq 'ERROR') { return $true }

    $pressureFlag = $false
    try { $pressureFlag = [bool]$Row.PressureFlag } catch { $pressureFlag = $false }
    if ($pressureFlag) { return $true }

    if (((($Row.ErrorCode + '')).Trim()).Length -gt 0) { return $true }

    $status = (($Row.Status + '')).Trim()
    if ($status.Length -gt 0 -and $status -ne 'Done') { return $true }

    $rt = (($Row.GeneratesRetest + '')).Trim().ToUpperInvariant()
    if ($rt -in @('YES','Y','TRUE','1')) { return $true }

    return $false
}

function Test-ShouldWriteQcSummaryRow {
    param([Parameter(Mandatory)][pscustomobject]$Row)

    if (Test-IsQcSummaryFailureRow -Row $Row) { return $true }

    $rf = (($Row.RuleFlags + '')).Trim()
    return ($rf.Length -gt 0)
}

function Get-QcSummarySampleKeys {
    param([string]$SampleId)

    $keys = New-Object System.Collections.Generic.List[string]
    $exact = (($SampleId + '')).Trim().ToUpperInvariant()
    if (-not $exact) { return @() }

    [void]$keys.Add($exact)

    $firstUnderscore = $exact.IndexOf('_')
    if ($firstUnderscore -ge 0 -and $firstUnderscore -lt ($exact.Length - 1)) {
        $tail = $exact.Substring($firstUnderscore + 1).Trim()
        if ($tail -and $tail -ne $exact) {
            [void]$keys.Add($tail)
        }
    }

    return @($keys.ToArray() | Select-Object -Unique)
}

function Get-QcSummaryMatchingFindings {
    param(
        [Parameter(Mandatory)][string]$SampleId,
        [Parameter(Mandatory)][hashtable]$FindingsByKey
    )

    $matches = New-Object System.Collections.Generic.List[object]
    $seen = @{}
    foreach ($key in @(Get-QcSummarySampleKeys -SampleId $SampleId)) {
        if (-not $key -or -not $FindingsByKey.ContainsKey($key)) { continue }
        foreach ($finding in @($FindingsByKey[$key])) {
            $sig = ((($finding.Source + '') + '|' + ($finding.SampleId + '') + '|' + ($finding.Type + '')).Trim()).ToUpperInvariant()
            if (-not $seen.ContainsKey($sig)) {
                $seen[$sig] = $true
                [void]$matches.Add($finding)
            }
        }
    }
    return @($matches.ToArray())
}

function Get-QcSummaryDisplayCategory {
    param(
        [Parameter(Mandatory)][pscustomobject]$Row,
        [Parameter()][hashtable]$CoveredFindingsByKey = @{}
    )

    $rawDev = (($Row.Deviation + '')).Trim().ToUpperInvariant()
    $isKnown = $false
    $isMtbInd = $false
    $isExactMtbIndeterminateMinor = $false
    $matchingCoveredFindings = @()
    if ($CoveredFindingsByKey -and $CoveredFindingsByKey.Count -gt 0) {
        $matchingCoveredFindings = @(Get-QcSummaryMatchingFindings -SampleId ($Row.SampleId + '') -FindingsByKey $CoveredFindingsByKey)
    }
    $hasCoveredDelamFinding = @($matchingCoveredFindings | Where-Object { (($_.Type + '') -imatch 'Delamination') }).Count -gt 0
    try { $isExactMtbIndeterminateMinor = (Test-IsMtbIndeterminateMinorFunctionalCase -Row $Row) } catch { $isExactMtbIndeterminateMinor = $false }
    try {
        if ((($Row.Assay + '') -match '(?i)MTB') -and ((($Row.TestResult + '') -match '(?i)INDETERMINATE'))) { $isMtbInd = $true }
    } catch {}

    switch ($rawDev) {
        'ERROR' {
            try { $isKnown = [bool]$Row.IsKnownCode } catch { $isKnown = $false }
            if ($isExactMtbIndeterminateMinor) { return 'Minor Functional (Indeterminate)' }
            if ($isMtbInd) { return 'Minor Functional' }
            if ($isKnown -and $hasCoveredDelamFinding) { return 'Minor Functional (Delamination)' }
            if ($isKnown) { return 'Minor Functional' }
            return 'Instrument Error'
        }
        'FP' { return 'Major Functional' }
        'FN' { return 'Major Functional' }
        'MISMATCH' { return 'Instrument Error' }
        'UNKNOWN' { return 'Instrument Error' }
        'OK' { return 'OK' }
        default { return 'OK' }
    }
}

function Get-QcSummaryCategoryBucket {
    param([string]$DisplayCategory)

    $display = (($DisplayCategory + '')).Trim()
    if (-not $display -or $display -eq 'OK') { return 'OK' }
    if ($display -like 'Major Functional*') { return 'Major' }
    if ($display -like 'Minor Functional*') { return 'Minor' }
    if ($display -eq 'Instrument Error') { return 'Instrument' }
    return 'Other'
}


# Skriv sektionsrubrik med styling

function Write-SectionHeader {
    param([int]$Row, [string]$Text, [int]$ColSpan = 4)
    
    $ws.Cells.Item($Row, 1).Value = $Text
    $rng = $ws.Cells[$Row, 1, $Row, $ColSpan]
    $rng.Merge = $true
    $rng.Style.Font.Bold = $true
    $rng.Style.Font.Size = 11
    $rng.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
    $rng.Style.Fill.BackgroundColor.SetColor($Colors.SectionBg)
    $rng.Style.Font.Color.SetColor($Colors.SectionFg)
    $rng.Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Medium
    $rng.Style.Border.Bottom.Color.SetColor($Colors.SectionFg)
}

# Skriv nyckel-värde par med valfri formatering

function Write-KV {
    param(
        [int]$Row, 
        [string]$Key, 
        $Value, 
        [int]$Col = 1,
        [switch]$Highlight,
        [switch]$Warning,
        [switch]$Good,
        [switch]$Major,
        [switch]$Minor,
        [switch]$Neutral
    )
    
    $ws.Cells.Item($Row, $Col).Value = $Key
    $ws.Cells.Item($Row, $Col).Style.Font.Bold = $true
    $ws.Cells.Item($Row, $Col + 1).Value = $Value
    
    if ($Major) {
        # Major Functional (FP/FN) - Ljusröd bakgrund
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.BackgroundColor.SetColor($Colors.MajorBg)
        $ws.Cells.Item($Row, $Col + 1).Style.Font.Color.SetColor($Colors.MajorFg)
        $ws.Cells.Item($Row, $Col + 1).Style.Font.Bold = $true
    }
    elseif ($Minor) {
        # Minor Functional - Gul bakgrund
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.BackgroundColor.SetColor($Colors.MinorBg)
        $ws.Cells.Item($Row, $Col + 1).Style.Font.Color.SetColor($Colors.MinorFg)
        $ws.Cells.Item($Row, $Col + 1).Style.Font.Bold = $true
    }
    elseif ($Neutral) {
        # Neutral grå bakgrund används t.ex. i Fel och varningar
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.BackgroundColor.SetColor($Colors.TableAltRow)
        $ws.Cells.Item($Row, $Col + 1).Style.Font.Bold = $true
    }
    elseif ($Highlight -or $Warning) {
        # Gul bakgrund (Instrument Error, övriga)
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.BackgroundColor.SetColor($Colors.WarningBg)
        $ws.Cells.Item($Row, $Col + 1).Style.Font.Bold = $true
    }
    elseif ($Good) {
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.BackgroundColor.SetColor($Colors.SummaryGoodBg)
    }
}

# ============================================================================
# HUVUDRUBRIK
# ============================================================================
$row = 1
$ws.Cells.Item($row, 1).Value = 'QC Summary - Summering av din batch'
$titleRng = $ws.Cells[$row, 1, $row, 8]
$titleRng.Merge = $true
$titleRng.Style.Font.Bold = $true
$titleRng.Style.Font.Size = 14
$titleRng.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
$titleRng.Style.Fill.BackgroundColor.SetColor($Colors.HeaderBg)
$titleRng.Style.Font.Color.SetColor($Colors.HeaderFg)
$ws.Row($row).Height = 25
$row += 2

# ============================================================================
# HÄMTA DATA
# ============================================================================

$sum = $RuleEngineResult.Summary
$qc  = $RuleEngineResult.QC
$allRows = @($RuleEngineResult.Rows)
$failureRows = @($allRows | Where-Object { Test-IsQcSummaryFailureRow -Row $_ })


# Worksheetens Data Summary ska äga de Sample ID som står där.
#
# Det betyder:
# - Data Summary-sektionen visar alla Worksheet Data Summary-fynd.
# - CSV-avvikelselistan visar inte samma Sample ID igen.
# - Samma Major Functional visas inte både som CSV-avvikelse och Data Summary-rad.
$displayDataSummaryFindings = @($DataSummaryFindings)
$dataSummaryOwnerKeySet = @{}
foreach ($finding in $displayDataSummaryFindings) {
    foreach ($key in @(Get-QcSummarySampleKeys -SampleId ($finding.SampleId + ''))) {
        if ($key) {
            $dataSummaryOwnerKeySet[$key] = $true
        }
    }
}
# Behåll variabeln för befintlig intern logik, men låt Data Summary visas separat
# i stället för att promota/blanda fynd in i CSV-delen.
$effectiveDataSummaryFindings = @()
# Behåll tom map så befintliga anrop till Get-QcSummaryDisplayCategory inte behöver ändras.
$coveredDataSummaryFindingsByKey = @{}

# ============================================================================
# SEKTION 1: ÖVERGRIPANDE STATISTIK
# ============================================================================
Write-SectionHeader -Row $row -Text 'Övergripande data' -ColSpan 8
$row++

# Rad 1: Totalt, Assay, Version, Lot
$assayTxt = ''
if ($qc -and $qc.DistinctAssays -and $qc.DistinctAssays.Count -eq 1) { 
    $assayTxt = $qc.DistinctAssays[0] 
}
elseif ($qc -and $qc.DistinctAssays -and $qc.DistinctAssays.Count -gt 1) { 
    $assayTxt = ([char]0x26A0 + " Flera ($($qc.DistinctAssays.Count))") 
}

$verTxt = ''
if ($qc -and $qc.DistinctAssayVersions -and $qc.DistinctAssayVersions.Count -eq 1) { 
    $verTxt = $qc.DistinctAssayVersions[0] 
}
elseif ($qc -and $qc.DistinctAssayVersions -and $qc.DistinctAssayVersions.Count -gt 1) { 
    $verTxt = ([char]0x26A0 + " Flera ($($qc.DistinctAssayVersions.Count))") 
}

$lotTxt = ''
if ($qc -and $qc.DistinctReagentLots -and $qc.DistinctReagentLots.Count -eq 1) { 
    $lotTxt = $qc.DistinctReagentLots[0] 
}
elseif ($qc -and $qc.DistinctReagentLots -and $qc.DistinctReagentLots.Count -gt 1) { 
    $lotTxt = ([char]0x26A0 + " Flera ($($qc.DistinctReagentLots.Count))") 
}

Write-KV -Row $row -Key 'Totalt tester' -Value $sum.Total -Col 1
Write-KV -Row $row -Key 'Assay' -Value $assayTxt -Col 3 -Warning:($assayTxt -like '*Flera*')
Write-KV -Row $row -Key 'Assay Version' -Value $verTxt -Col 5 -Warning:($verTxt -like '*Flera*')
Write-KV -Row $row -Key 'Reagent Lot' -Value $lotTxt -Col 7 -Warning:($lotTxt -like '*Flera*')
$row += 2

# ============================================================================
# BERÄKNINGAR FÖR SEKTIONERNA
# ============================================================================

# Slutlig klassning per test/replikat.
# Starta från radens egen slutetikett i CSV/RuleEngine-tabellen och promota därefter
# OK-rader till Major/Minor när Data Summary-fynd finns för samma Sample ID.
$rowStates = New-Object System.Collections.Generic.List[object]
$rowStateIndexesByKey = @{}
for ($idx = 0; $idx -lt $allRows.Count; $idx++) {
    $rowItem = $allRows[$idx]
    $displayCategory = Get-QcSummaryDisplayCategory -Row $rowItem -CoveredFindingsByKey $coveredDataSummaryFindingsByKey
    $bucket = Get-QcSummaryCategoryBucket -DisplayCategory $displayCategory
    $rowState = [pscustomobject]@{
        Index = $idx
        Row = $rowItem
        SampleId = ($rowItem.SampleId + '')
        IsResample = [bool](($rowItem.SampleId + '') -imatch '_RES_')
        DisplayCategory = $displayCategory
        Bucket = $bucket
        PromotedByDataSummary = $false
    }
    [void]$rowStates.Add($rowState)

    foreach ($key in @(Get-QcSummarySampleKeys -SampleId ($rowItem.SampleId + ''))) {
        if (-not $key) { continue }
        if (-not $rowStateIndexesByKey.ContainsKey($key)) { $rowStateIndexesByKey[$key] = New-Object System.Collections.Generic.List[int] }
        [void]$rowStateIndexesByKey[$key].Add($idx)
    }
}

if ($effectiveDataSummaryFindings -and $effectiveDataSummaryFindings.Count -gt 0) {
    $promotionCandidates = @(
        $effectiveDataSummaryFindings |
            Sort-Object @{Expression={ if (($_.Severity + '') -ieq 'Major') { 0 } else { 1 } }}, @{Expression={$_.SampleId}}, @{Expression={$_.Type}}
    )

    foreach ($finding in $promotionCandidates) {
        $candidateIndexes = New-Object System.Collections.Generic.List[int]
        $seenIndexes = @{}
        foreach ($key in @(Get-QcSummarySampleKeys -SampleId ($finding.SampleId + ''))) {
            if (-not $key -or -not $rowStateIndexesByKey.ContainsKey($key)) { continue }
            foreach ($idx in @($rowStateIndexesByKey[$key])) {
                if (-not $seenIndexes.ContainsKey($idx)) {
                    $seenIndexes[$idx] = $true
                    [void]$candidateIndexes.Add([int]$idx)
                }
            }
        }

        foreach ($idx in @($candidateIndexes.ToArray())) {
            $state = $rowStates[$idx]
            if (($state.Bucket + '') -ne 'OK') { continue }

            if ((($finding.Severity + '') -ieq 'Major')) {
                $state.DisplayCategory = 'Major Functional'
                $state.Bucket = 'Major'
            } else {
                $state.DisplayCategory = 'Minor Functional'
                $state.Bucket = 'Minor'
            }
            $state.PromotedByDataSummary = $true
            break
        }
    }
}

# CSV-statistik ska inte räkna Sample ID som redan ägs av Worksheet Data Summary.
$csvSummaryRowStates = @(
    $rowStates | Where-Object {
        $ownedByDataSummary = $false
        foreach ($key in @(Get-QcSummarySampleKeys -SampleId ($_.SampleId + ''))) {
            if ($key -and $dataSummaryOwnerKeySet.ContainsKey($key)) {
                $ownedByDataSummary = $true
                break
            }
        }
        -not $ownedByDataSummary
    }
)
$okCount = @($csvSummaryRowStates | Where-Object { (($_.Bucket + '') -eq 'OK') }).Count
$finalMajorCount = @($csvSummaryRowStates | Where-Object { (($_.Bucket + '') -eq 'Major') }).Count
$finalMinorCount = @($csvSummaryRowStates | Where-Object { (($_.Bucket + '') -eq 'Minor') }).Count
$finalInstrumentErrorCount = @($csvSummaryRowStates | Where-Object { (($_.Bucket + '') -eq 'Instrument') }).Count
$finalOtherCount = @($csvSummaryRowStates | Where-Object { (($_.Bucket + '') -eq 'Other') }).Count
# Behåll gamla namn lokalt för minsta diff i resten av bladbygget.
$csvMajor = $finalMajorCount
$csvMinor = $finalMinorCount
$csvInstrumentError = $finalInstrumentErrorCount
# Primary vs Resample uppdelning, nu på CSV-rader som inte redan ägs av Data Summary.
$hasResample = (@($csvSummaryRowStates | Where-Object { [bool]$_.IsResample }).Count -gt 0)
$priRows = @($csvSummaryRowStates | Where-Object { -not [bool]$_.IsResample })
$resRows = @($csvSummaryRowStates | Where-Object { [bool]$_.IsResample })
$priOk = @($priRows | Where-Object { (($_.Bucket + '') -eq 'OK') }).Count
$resOk = @($resRows | Where-Object { (($_.Bucket + '') -eq 'OK') }).Count
$priFail = @($priRows | Where-Object { (($_.Bucket + '') -ne 'OK') }).Count
$resFail = @($resRows | Where-Object { (($_.Bucket + '') -ne 'OK') }).Count

# Data Summary-avvikelser per källa.
# Här räknas alla fynd som faktiskt står i Worksheetens Data Summary.
$dsfMajorTotal = 0; $dsfMinorTotal = 0
$dsfBySource = [ordered]@{}
if ($displayDataSummaryFindings -and $displayDataSummaryFindings.Count -gt 0) {
    foreach ($dsf in $displayDataSummaryFindings) {
        $sev   = ($dsf.Severity + '').Trim()
        $src   = ($dsf.Source + '').Trim()
        if (-not $src) { $src = 'Data Summary' }
        if (-not $dsfBySource.Contains($src)) { $dsfBySource[$src] = @{ Major = 0; Minor = 0 } }
        if ($sev -ieq 'Major') { $dsfBySource[$src].Major++; $dsfMajorTotal++ }
        else { $dsfBySource[$src].Minor++; $dsfMinorTotal++ }
    }
}

# ============================================================================
# SEKTION 2: SLUTLIGT RESULTAT
# ============================================================================
Write-SectionHeader -Row $row -Text 'Resultat från CSV' -ColSpan 8
$row++

Write-KV -Row $row -Key ([char]0x2713 + ' Godkända (OK)') -Value $okCount -Col 1 -Good
$row++
if ($csvMajor -gt 0) {
    Write-KV -Row $row -Key ([char]0x274C + ' Major Functional (FP/FN)') -Value $csvMajor -Col 1 -Major
    $row++
}
if ($csvMinor -gt 0) {
    Write-KV -Row $row -Key ([char]0x26A0 + ' Minor Functional') -Value $csvMinor -Col 1 -Minor
    $row++
}
if ($csvInstrumentError -gt 0) {
    Write-KV -Row $row -Key 'Instrument Error' -Value $csvInstrumentError -Col 1 -Warning
    $row++
}
if ($finalOtherCount -gt 0) {
    Write-KV -Row $row -Key 'Övrig slutkategori' -Value $finalOtherCount -Col 1 -Warning
    $row++
}

# Primary/Resample-uppdelning (kompakt rad)
if ($hasResample) {
    $ws.Cells.Item($row, 1).Value = 'Primary'
    $ws.Cells.Item($row, 1).Style.Font.Bold = $true
    $ws.Cells.Item($row, 1).Style.Font.Italic = $true
    $ws.Cells.Item($row, 2).Value = "OK=$priOk  Avvikelser=$priFail  (av $($priRows.Count))"
    $ws.Cells.Item($row, 2).Style.Font.Size = 9
    $row++
    $ws.Cells.Item($row, 1).Value = 'Resample'
    $ws.Cells.Item($row, 1).Style.Font.Bold = $true
    $ws.Cells.Item($row, 1).Style.Font.Italic = $true
    $ws.Cells.Item($row, 2).Value = "OK=$resOk  Avvikelser=$resFail  (av $($resRows.Count))"
    $ws.Cells.Item($row, 2).Style.Font.Size = 9
    $row++
}

if ($csvMajor -eq 0 -and $csvMinor -eq 0 -and $csvInstrumentError -eq 0 -and $finalOtherCount -eq 0) {
    $ws.Cells.Item($row, 1).Value = ([char]0x2713 + ' Inga resultatavvikelser')
    $ws.Cells.Item($row, 1).Style.Font.Italic = $true
    $ws.Cells.Item($row, 1).Style.Font.Color.SetColor($Colors.OkFg)
    $row++
}
$row++

# ============================================================================
# SEKTION 3: DATA SUMMARY RESULTAT
# ============================================================================
Write-SectionHeader -Row $row -Text 'Resultat Worksheet Data Summary' -ColSpan 8
$row++

if ($dsfBySource.Keys.Count -gt 0) {
    foreach ($srcName in $dsfBySource.Keys) {
        $srcStats = $dsfBySource[$srcName]
        $srcLabel = $srcName
        $srcTotal = $srcStats.Major + $srcStats.Minor

        $ws.Cells.Item($row, 1).Value = $srcLabel
        $ws.Cells.Item($row, 1).Style.Font.Bold = $true

        if ($srcStats.Major -gt 0 -and $srcStats.Minor -gt 0) {
            $ws.Cells.Item($row, 2).Value = "Major: $($srcStats.Major)  Minor: $($srcStats.Minor)"
        } elseif ($srcStats.Major -gt 0) {
            $ws.Cells.Item($row, 2).Value = "Major: $($srcStats.Major)"
        } elseif ($srcStats.Minor -gt 0) {
            $ws.Cells.Item($row, 2).Value = "Minor: $($srcStats.Minor)"
        }

        # Färgkoda baserat på allvarligaste
        if ($srcStats.Major -gt 0) {
            $ws.Cells.Item($row, 2).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $ws.Cells.Item($row, 2).Style.Fill.BackgroundColor.SetColor($Colors.MajorBg)
            $ws.Cells.Item($row, 2).Style.Font.Color.SetColor($Colors.MajorFg)
            $ws.Cells.Item($row, 2).Style.Font.Bold = $true
        } elseif ($srcStats.Minor -gt 0) {
            $ws.Cells.Item($row, 2).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $ws.Cells.Item($row, 2).Style.Fill.BackgroundColor.SetColor($Colors.MinorBg)
            $ws.Cells.Item($row, 2).Style.Font.Color.SetColor($Colors.MinorFg)
            $ws.Cells.Item($row, 2).Style.Font.Bold = $true
        }
        $row++
    }
} else {
    $ws.Cells.Item($row, 1).Value = ([char]0x2713 + ' Inga Data Summary-avvikelser')
    $ws.Cells.Item($row, 1).Style.Font.Italic = $true
    $ws.Cells.Item($row, 1).Style.Font.Color.SetColor($Colors.OkFg)
    $row++
}
$row++

# ============================================================================
# SEKTION 4: STF + KVALITETSINDIKATORER
# ============================================================================
Write-SectionHeader -Row $row -Text 'Resultat Seal Test och övrigt' -ColSpan 8
$row++

if ($StfCount -gt 0) {
    Write-KV -Row $row -Key 'Seal Test Failure (STF)' -Value $StfCount -Warning
    $row++
}
if ($sum -and $sum.DelamCount -ne $null -and $sum.DelamCount -gt 0) { 
    Write-KV -Row $row -Key 'Delamineringar' -Value $sum.DelamCount -Neutral
    $row++ 
}
if ($sum -and $sum.ReplacementCount -ne $null -and $sum.ReplacementCount -gt 0) { 
    Write-KV -Row $row -Key ([char]0x21BB + ' Ers' + [char]0x00E4 + 'ttningar (A/AA/AAA)') -Value $sum.ReplacementCount -Neutral
    $row++ 
}
if ($sum.RetestYes -gt 0) {
    Write-KV -Row $row -Key ([char]0x21BB + ' Beh' + [char]0x00F6 + 'ver omk' + [char]0x00F6 + 'rning (YES)') -Value $sum.RetestYes -Neutral
    $row++
}
if ($qc) {
    if ($qc.DuplicateSampleIdCount -gt 0) {
        Write-KV -Row $row -Key 'Dubbletter Sample ID' -Value $qc.DuplicateSampleIdCount -Neutral
        $row++
    }
    if ($qc.DuplicateCartridgeSnCount -gt 0) {
        Write-KV -Row $row -Key 'Dubbletter Cartridge S/N' -Value $qc.DuplicateCartridgeSnCount -Neutral
        $row++
    }
    if ($qc.HotModuleCount -gt 0) {
        Write-KV -Row $row -Key ('Moduler med ' + [char]0x2265 + '3 fel') -Value $qc.HotModuleCount -Neutral
        $row++
    }
}

# Max Pressure ≥ 90 PSI
$pressureGE90 = @($allRows | Where-Object {
    $p = $null
    try { $p = [double]$_.MaxPressure } catch { $p = $null }
    return ($null -ne $p -and $p -ge 90)
}).Count
if ($pressureGE90 -gt 0) {
    Write-KV -Row $row -Key ('Max Pressure ' + [char]0x2265 + ' 90 PSI') -Value $pressureGE90 -Neutral
    $row++
}

$pressureFailNoError = @($allRows | Where-Object {
    $p = $null
    try { $p = [double]$_.MaxPressure } catch { $p = $null }
    $hasError = ((($_.ErrorCode + '')).Trim().Length -gt 0)
    return ($null -ne $p -and $p -ge 90 -and -not $hasError)
}).Count
if ($pressureFailNoError -gt 0) {
    Write-KV -Row $row -Key 'Max Pressure Failure (utan Error Code)' -Value $pressureFailNoError -Neutral
    $row++
}

if ($StfCount -eq 0 -and ($sum.DelamCount -eq $null -or $sum.DelamCount -eq 0) -and $pressureGE90 -eq 0) {
    $ws.Cells.Item($row, 1).Value = ([char]0x2713 + ' Inga STF eller kvalitetsavvikelser')
    $ws.Cells.Item($row, 1).Style.Font.Italic = $true
    $ws.Cells.Item($row, 1).Style.Font.Color.SetColor($Colors.OkFg)
    $row++
}
$row++


# ============================================================================
# DETALJTABELL
# ============================================================================

# Filtrera rader
$rowsToWrite = $allRows
if (-not $IncludeAllRows) {
    $rowsToWrite = @(
        $allRows | Where-Object {
            $shouldWrite = (Test-ShouldWriteQcSummaryRow -Row $_)
            if (-not $shouldWrite) {
                $false
            }
            else {
                $ownedByDataSummary = $false
                foreach ($key in @(Get-QcSummarySampleKeys -SampleId ($_.SampleId + ''))) {
                    if ($key -and $dataSummaryOwnerKeySet.ContainsKey($key)) {
                        $ownedByDataSummary = $true
                        break
                    }
                }
                -not $ownedByDataSummary
            }
        }
    )
}

# Tabell-rubrik
$tableInfoRow = $row
$colCount = $headers.Count
$deviationCount = $rowsToWrite.Count
$hasResampleCsvRows = (@($allRows | Where-Object { (($_.SampleId + '') -imatch '_RES_') }).Count -gt 0)
$resampleDeviationCount = 0
$primaryDeviationCount = $deviationCount
if ($hasResampleCsvRows -and $deviationCount -gt 0) {
    $resampleDeviationCount = @($rowsToWrite | Where-Object { (($_.SampleId + '') -imatch '_RES_') }).Count
    $primaryDeviationCount = [Math]::Max(0, ($deviationCount - $resampleDeviationCount))
}
$tableInfoText = if ($deviationCount -eq 0) {
    if ($hasResampleCsvRows) {
        "CSV avvikelser - Inga CSV-avvikelser att visa (Primary: 0, Resample: 0)"
    } else {
        "CSV avvikelser - Inga CSV-avvikelser att visa"
    }
} elseif ($hasResampleCsvRows) {
    "CSV avvikelselista - {0} rader (Primary: {1}, Resample: {2})" -f $deviationCount, $primaryDeviationCount, $resampleDeviationCount
} else {
    "CSV avvikelselista - $deviationCount rader"
}

$ws.Cells.Item($row, 1).Value = $tableInfoText
$infoRng = $ws.Cells[$row, 1, $row, 6]
$infoRng.Merge = $true
$infoRng.Style.Font.Bold = $true
$infoRng.Style.Font.Size = 11
$row++

$tableHeaderRow = $row

# Skriv headers
for ($c = 1; $c -le $headers.Count; $c++) {
    $ws.Cells.Item($tableHeaderRow, $c).Value = $headers[$c - 1]
}

# Styla rubrikrad
$headerRange = $ws.Cells[$tableHeaderRow, 1, $tableHeaderRow, $headers.Count]
$headerRange.Style.Font.Bold = $true
$headerRange.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
$headerRange.Style.Fill.BackgroundColor.SetColor($Colors.TableHeaderBg)
$headerRange.Style.Font.Color.SetColor($Colors.TableHeaderFg)
$headerRange.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center

# AutoFilter och FreezePanes
try { $ws.Cells[$tableHeaderRow, 1, $tableHeaderRow, $headers.Count].AutoFilter = $true } catch {}
try { $ws.View.FreezePanes($tableHeaderRow + 1, 1) } catch {}

# Om inga rader
if (-not $rowsToWrite -or $rowsToWrite.Count -eq 0) {
    $noDevRow = $tableHeaderRow + 1
    $ws.Cells.Item($tableHeaderRow + 1, 1).Value = '✓ Inga CSV-avvikelser hittades i CSV-fil(erna) - alla tester OK!'
    $ws.Cells.Item($tableHeaderRow + 1, 1).Style.Font.Italic = $true
    $ws.Cells.Item($tableHeaderRow + 1, 1).Style.Font.Color.SetColor($Colors.OkFg)
    $noDevRng = $ws.Cells[$noDevRow, 1, $noDevRow, 6]
    $noDevRng.Merge = $true
    $endRow = $noDevRow
} else {
    # ============================================================================
    # SKRIV DATA MED BULK-OPERATION
    # ============================================================================
    $rowCount = $rowsToWrite.Count
    $data = New-Object 'object[,]' $rowCount, $colCount

    for ($i = 0; $i -lt $rowCount; $i++) {
        $r = $rowsToWrite[$i]

        # Kolumn 1: Sample ID
        $data[$i, 0] = ($r.SampleId + '')

        # Kolumn 2: Error Code och Kolumn 3: Avvikelse
        $rawDev = (($r.Deviation + '')).Trim().ToUpperInvariant()
        $displayCategory = Get-QcSummaryDisplayCategory -Row $r -CoveredFindingsByKey $coveredDataSummaryFindingsByKey
        switch ($rawDev) {
            'ERROR' {
                $data[$i, 2] = $displayCategory
                $data[$i, 1] = ($r.ErrorCode + '')
            }
            'FP' {
                $data[$i, 2] = $displayCategory
                $data[$i, 1] = 'Falsk Positiv'
            }
            'FN' {
                $data[$i, 2] = $displayCategory
                $fnLabel = 'Falsk Negativ'
                try {
                    if ((Test-IsStrictMtbUltraAssay -Assay ($r.Assay + '')) -and (((($r.ExpectedCall + '')).Trim().ToUpperInvariant()) -eq 'POS_RIF_NOT_DETECTED')) {
                        $trU = (($r.TestResult + '')).ToUpperInvariant()
                        if ($trU -match 'RIF\s*RESISTANCE\s*DETECTED') {
                            $fnLabel = 'RIF Resistance DETECTED'
                        }
                        elseif ($trU -match 'MTB\s+TRACE\s+DETECTED') {
                            $fnLabel = 'MTB Trace DETECTED'
                        }
                    }
                } catch {}
                $data[$i, 1] = $fnLabel
            }
            'MISMATCH' {
                $data[$i, 2] = $displayCategory
                $data[$i, 1] = 'Mismatch'
            }
            'UNKNOWN' {
                $data[$i, 2] = $displayCategory
                $data[$i, 1] = 'Okänt'
            }
            'OK' {
                $data[$i, 2] = $displayCategory
                $data[$i, 1] = ($r.ErrorCode + '')
            }
            default {
                $data[$i, 2] = $displayCategory
                $data[$i, 1] = ($r.ErrorCode + '')
            }
        }

        # Kolumn 4: Notering (RuleFlags)
        $data[$i, 3] = (_SvRuleFlags ($r.RuleFlags + ''))

        # Kolumn 5: Förväntat X/+
        $sc = (($r.SuffixCheck + '')).Trim().ToUpperInvariant()
        if ($sc -and $sc -ne 'OK') {
            $expectedSuffix = ($r.ExpectedSuffix + '')
            if (-not $expectedSuffix) { $expectedSuffix = '' }
            $data[$i, 4] = $expectedSuffix
        } else {
            $data[$i, 4] = 'OK'
        }

        # Kolumn 6: Cartridge S/N
        $data[$i, 5] = ($r.CartridgeSN + '')

        # Kolumn 7: Module S/N
        $data[$i, 6] = ($r.ModuleSN + '')

        # Kolumn 8: Förväntad Test Type
        $expTestType = ($r.ExpectedTestType + '')
        $obsTestType = (($r.TestType + '')).Trim()
        if ($expTestType -and $obsTestType -and ($expTestType -ne $obsTestType)) {
            $data[$i, 7] = $expTestType
        } else {
            $data[$i, 7] = 'OK'
        }

        # Kolumn 9: Status
        $data[$i, 8] = ($r.Status + '')

        # Kolumn 10: Error Type
        $data[$i, 9] = ($r.ErrorName + '')
      
        # Kolumn 11: Ersätts?
        # Om avvikelsen är Major Functional => ersätts inte (override)
        $devLabel = ($data[$i, 2] + '')
        if ($devLabel -eq 'Major Functional') {
        $data[$i, 10] = 'Nej'   # eller 'Nej' om du föredrar
        }
        else {
        $rt = (($r.GeneratesRetest + '')).Trim().ToUpperInvariant()
        if ($rt -in @('YES','Y','TRUE','1')) {
            $data[$i, 10] = 'Ja'
        } elseif ($rt) {
            $data[$i, 10] = 'Nej'
        } else {
            $data[$i, 10] = ''
        }
        }
        
        # Kolumn 12: Max Pressure (PSI)
        if ($null -ne $r.MaxPressure) {
            $data[$i, 11] = $r.MaxPressure
        } else {
            $data[$i, 11] = ''
        }

        # Kolumn 13: Test Result
        $data[$i, 12] = ($r.TestResult + '')

        # Kolumn 14: Error (feltext)
        $data[$i, 13] = ($r.ErrorText + '')
    }

    $startRow = $tableHeaderRow + 1
    $endRow = $startRow + $rowCount - 1
    $rng = $ws.Cells[$startRow, 1, $endRow, $colCount]
    $rng.Value = $data

    # ============================================================================
    # FÄRGKODNING AV DATA-RADER (baserat på Deviation)
    # ============================================================================
    for ($i = 0; $i -lt $rowCount; $i++) {
        $dataRow = $startRow + $i
        $r = $rowsToWrite[$i]
        $dev = (($r.Deviation + '')).Trim().ToUpperInvariant()
        
        $rowRange = $ws.Cells[$dataRow, 1, $dataRow, $colCount]
        
        # Avvikelse-kolumnen (kolumn C, index 3)
        $devCell = $ws.Cells.Item($dataRow, 3)
        
        # Error Code-kolumnen (kolumn B, index 2) - för Major Functional
        $errorCodeCell = $ws.Cells.Item($dataRow, 2)
        
        switch ($dev) {
            'FP' {
                # Major Functional - Mörkröd bakgrund, vit text
                $devCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $devCell.Style.Fill.BackgroundColor.SetColor($Colors.MajorBg)
                $devCell.Style.Font.Color.SetColor($Colors.MajorFg)
                $devCell.Style.Font.Bold = $true
                # Färgmarkera även Error Code-kolumnen
                $errorCodeCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $errorCodeCell.Style.Fill.BackgroundColor.SetColor($Colors.MajorBg)
                $errorCodeCell.Style.Font.Color.SetColor($Colors.MajorFg)
                $errorCodeCell.Style.Font.Bold = $true
            }
            'FN' {
                # Major Functional - Mörkröd bakgrund, vit text
                $devCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $devCell.Style.Fill.BackgroundColor.SetColor($Colors.MajorBg)
                $devCell.Style.Font.Color.SetColor($Colors.MajorFg)
                $devCell.Style.Font.Bold = $true
                # Färgmarkera även Error Code-kolumnen
                $errorCodeCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $errorCodeCell.Style.Fill.BackgroundColor.SetColor($Colors.MajorBg)
                $errorCodeCell.Style.Font.Color.SetColor($Colors.MajorFg)
                $errorCodeCell.Style.Font.Bold = $true
            }
            'ERROR' {
                # Differentiera mellan Minor Functional och Instrument Error
                $disp = ($data[$i, 2] + '')
                if ($disp -eq 'Instrument Error') {
                    # Instrument Error - använd varningsfärg (gul)
                    $devCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                    $devCell.Style.Fill.BackgroundColor.SetColor($Colors.WarningBg)
                    $devCell.Style.Font.Color.SetColor($Colors.WarningFg)
                    # Error Code-kolumn: samma varningsfärg
                    $errorCodeCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                    $errorCodeCell.Style.Fill.BackgroundColor.SetColor($Colors.WarningBg)
                    $errorCodeCell.Style.Font.Color.SetColor($Colors.WarningFg)
                } else {
                    # Minor Functional - ljusgul bakgrund
                    $devCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                    $devCell.Style.Fill.BackgroundColor.SetColor($Colors.MinorBg)
                    $devCell.Style.Font.Color.SetColor($Colors.MinorFg)
                    # Error Code-kolumn: samma Minor-färg
                    $errorCodeCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                    $errorCodeCell.Style.Fill.BackgroundColor.SetColor($Colors.MinorBg)
                    $errorCodeCell.Style.Font.Color.SetColor($Colors.MinorFg)
                }
                $devCell.Style.Font.Bold = $true
                $errorCodeCell.Style.Font.Bold = $true
            }
            'MISMATCH' {
                # Varning - Gul bakgrund
                $devCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $devCell.Style.Fill.BackgroundColor.SetColor($Colors.WarningBg)
                $devCell.Style.Font.Color.SetColor($Colors.WarningFg)
                $devCell.Style.Font.Bold = $true
                # Error Code-kolumn: samma varningsfärg
                $errorCodeCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $errorCodeCell.Style.Fill.BackgroundColor.SetColor($Colors.WarningBg)
                $errorCodeCell.Style.Font.Color.SetColor($Colors.WarningFg)
                $errorCodeCell.Style.Font.Bold = $true
            }
            'UNKNOWN' {
                # Okänt/Instrument Error - Gul bakgrund
                $devCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $devCell.Style.Fill.BackgroundColor.SetColor($Colors.WarningBg)
                $devCell.Style.Font.Color.SetColor($Colors.WarningFg)
                $devCell.Style.Font.Bold = $true
                # Error Code-kolumn: samma varningsfärg
                $errorCodeCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $errorCodeCell.Style.Fill.BackgroundColor.SetColor($Colors.WarningBg)
                $errorCodeCell.Style.Font.Color.SetColor($Colors.WarningFg)
                $errorCodeCell.Style.Font.Bold = $true
            }
        }
        
        # Markera "Ersätts? = Ja" med gul bakgrund (kolumn 11)
        $ersattsVal = ($data[$i, 10] + '').Trim()
        if ($ersattsVal -eq 'Ja') {
            $ersattsCell = $ws.Cells.Item($dataRow, 11)
            $ersattsCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $ersattsCell.Style.Fill.BackgroundColor.SetColor($Colors.WarningBg)
            $ersattsCell.Style.Font.Bold = $true
        }

        # Markera högt tryck (≥90 PSI) med ljusröd (Minor-nivå) på kolumn 12
        try {
            $pressure = $null
            if ($r.MaxPressure -ne $null) { $pressure = [double]$r.MaxPressure }
            if ($pressure -ne $null -and $pressure -ge 90) {
                $pressCell = $ws.Cells.Item($dataRow, 12)
                $pressCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $pressCell.Style.Fill.BackgroundColor.SetColor($Colors.MinorBg)
                $pressCell.Style.Font.Color.SetColor($Colors.MinorFg)
                $pressCell.Style.Font.Bold = $true
            }
        } catch {}
        
        # Varannan rad med ljusgrå bakgrund (zebra-ränder) för rader utan avvikelse-färg
        if ($i % 2 -eq 1 -and $dev -eq 'OK') {
            $rowRange.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $rowRange.Style.Fill.BackgroundColor.SetColor($Colors.TableAltRow)
        }
    }
}


# ============================================================================
# DATA SUMMARY (grupperat per källa: 'Data Summary' och 'Resample Data Summary')
# ============================================================================
$visualRow = $endRow + 2
if ($displayDataSummaryFindings -and $displayDataSummaryFindings.Count -gt 0) {
    # Gruppera findings per Source-bladnamn (bevara ordning: Primary först)
    $dsfGroups = [ordered]@{}
    foreach ($dsf in $displayDataSummaryFindings) {
        $src = ($dsf.Source + '').Trim()
        if (-not $src) { $src = 'Data Summary' }
        if (-not $dsfGroups.Contains($src)) { $dsfGroups[$src] = @() }
        # PS 5.1: undvik '+=' direkt på hashtable-index (kan kasta op_Addition på System.Object[])
        $dsfGroups[$src] = @($dsfGroups[$src]) + @($dsf)
    }

    foreach ($srcName in $dsfGroups.Keys) {
        $srcFindings = @($dsfGroups[$srcName])

        # Deduplicera (samma SampleId+Type → behåll första)
        $dsfSeen = @{}
        $dsfDeduped = @()
        foreach ($dsf in $srcFindings) {
            $dsfKey = (($dsf.SampleId + '').Trim() + '|' + ($dsf.Type + '').Trim()).ToUpperInvariant()
            if (-not $dsfSeen.ContainsKey($dsfKey)) {
                $dsfSeen[$dsfKey] = $true
                $dsfDeduped += $dsf
            }
        }
        if ($dsfDeduped.Count -eq 0) { continue }

        # Sortera: Major först, sedan Minor, inom varje grupp: Type → SampleId
        $dsfSorted = @($dsfDeduped | Sort-Object @{Expression={if(($_.Severity+'') -ieq 'Major'){0}else{1}}}, @{Expression={$_.Type}}, @{Expression={$_.SampleId}})

        # Sektionsrubrik: t.ex. "Data Summary" eller "Resample Data Summary"
        Write-SectionHeader -Row $visualRow -Text $srcName -ColSpan 8
        $visualRow++

        # Underrubrik
        $ws.Cells.Item($visualRow, 1).Value = 'Sample ID'
        $ws.Cells.Item($visualRow, 2).Value = 'Failure Check'
        $ws.Cells.Item($visualRow, 3).Value = 'Comment (drop-down menu available)'
        for ($vc = 1; $vc -le 3; $vc++) {
            $ws.Cells.Item($visualRow, $vc).Style.Font.Bold = $true
            $ws.Cells.Item($visualRow, $vc).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $ws.Cells.Item($visualRow, $vc).Style.Fill.BackgroundColor.SetColor($Colors.HeaderBg)
            $ws.Cells.Item($visualRow, $vc).Style.Font.Color.SetColor($Colors.HeaderFg)
        }
        $grpHeaderRow = $visualRow
        $visualRow++

        foreach ($dsf in $dsfSorted) {
            $ws.Cells.Item($visualRow, 1).Value = ($dsf.SampleId + '')
            $ws.Cells.Item($visualRow, 2).Value = ($dsf.Type + '')
            $ws.Cells.Item($visualRow, 3).Value = ($dsf.Comment + '')

            $dsfSev = ($dsf.Severity + '')
            if ($dsfSev -ieq 'Major') {
                $ws.Cells.Item($visualRow, 2).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $ws.Cells.Item($visualRow, 2).Style.Fill.BackgroundColor.SetColor($Colors.MajorBg)
                $ws.Cells.Item($visualRow, 2).Style.Font.Color.SetColor($Colors.MajorFg)
                $ws.Cells.Item($visualRow, 2).Style.Font.Bold = $true
            } elseif ($dsfSev -ieq 'Minor') {
                $ws.Cells.Item($visualRow, 2).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $ws.Cells.Item($visualRow, 2).Style.Fill.BackgroundColor.SetColor($Colors.MinorBg)
                $ws.Cells.Item($visualRow, 2).Style.Font.Color.SetColor($Colors.MinorFg)
                $ws.Cells.Item($visualRow, 2).Style.Font.Bold = $true
            }

            # Zebra-ränder
            $vIdx = $visualRow - ($grpHeaderRow + 1)
            if ($vIdx % 2 -eq 1) {
                for ($vc = 1; $vc -le 3; $vc++) {
                    $ws.Cells.Item($visualRow, $vc).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                    if ($vc -ne 2) { $ws.Cells.Item($visualRow, $vc).Style.Fill.BackgroundColor.SetColor($Colors.TableAltRow) }
                }
            }
            $visualRow++
        }

        # Ramar per grupp
        try {
            $dsfTableRange = $ws.Cells[($grpHeaderRow), 1, ($visualRow - 1), 3]
            $dsfTableRange.Style.Border.Top.Style    = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $dsfTableRange.Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $dsfTableRange.Style.Border.Left.Style   = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $dsfTableRange.Style.Border.Right.Style  = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $dsfTableRange.Style.Border.Top.Color.SetColor([System.Drawing.Color]::LightGray)
            $dsfTableRange.Style.Border.Bottom.Color.SetColor([System.Drawing.Color]::LightGray)
            $dsfTableRange.Style.Border.Left.Color.SetColor([System.Drawing.Color]::LightGray)
            $dsfTableRange.Style.Border.Right.Color.SetColor([System.Drawing.Color]::LightGray)
        } catch {}

        $visualRow++  # Tom rad mellan grupper
    }

    $endRow = $visualRow - 1
}

# ============================================================================
# RAMAR OCH FORMATERING
# ============================================================================

# Lägg till tunna ramar runt alla dataceller
try {
    $tableRange = $ws.Cells[$tableHeaderRow, 1, $endRow, $colCount]
    $tableRange.Style.Border.Top.Style    = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
    $tableRange.Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
    $tableRange.Style.Border.Left.Style   = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
    $tableRange.Style.Border.Right.Style  = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
    $tableRange.Style.Border.Top.Color.SetColor([System.Drawing.Color]::LightGray)
    $tableRange.Style.Border.Bottom.Color.SetColor([System.Drawing.Color]::LightGray)
    $tableRange.Style.Border.Left.Color.SetColor([System.Drawing.Color]::LightGray)
    $tableRange.Style.Border.Right.Color.SetColor([System.Drawing.Color]::LightGray)
} catch {}

# Tjockare ram runt rubrikrad
try {
    $headerRange.Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Medium
    $headerRange.Style.Border.Bottom.Color.SetColor([System.Drawing.Color]::FromArgb(68, 84, 106))
} catch {}

# ============================================================================
# KOLUMNBREDDER
# ============================================================================
try {
    $rAll = $ws.Cells[1, 1, $endRow, $colCount]
    if (Get-Command Safe-AutoFitColumns -ErrorAction SilentlyContinue) {
        Safe-AutoFitColumns -Ws $ws -Range $rAll -Context 'QC Summary'
    } else {
        $rAll.AutoFitColumns() | Out-Null
    }
} catch {}

# Sätt minbredd för vissa kolumner
try {
    $ws.Column(1).Width = [Math]::Max($ws.Column(1).Width, 15)   # Sample ID
    $ws.Column(3).Width = [Math]::Max($ws.Column(3).Width, 14)   # Avvikelse
    $ws.Column(7).Width = [Math]::Max($ws.Column(7).Width, 14)   # Cartridge S/N
    # Justera bredder efter att kolumner tagits bort: feltextkolumnen finns nu på kolumn 14
    $ws.Column(14).Width = [Math]::Max($ws.Column(14).Width, 30) # Error (kan vara lång)
} catch {}

# ============================================================================
# FLIK-FÄRG
# ============================================================================
# Grön om inga avvikelser, annars orange
if ($deviationCount -eq 0) {
    $ws.TabColor = [System.Drawing.Color]::Green
} elseif ($deviationCount -le 5) {
    $ws.TabColor = [System.Drawing.Color]::Orange
} else {
    $ws.TabColor = [System.Drawing.Color]::Red
}

return $ws
}
