﻿# Extracted from Main.ps1 during high-risk refactor.
# Intent: keep Main.ps1 as orchestration/UI and move reusable helpers into focused modules.

function Get-SealViolations {
    param(
        [Parameter(Mandatory)][OfficeOpenXml.ExcelPackage]$Pkg,
        [double]$MinusThreshold = -3.0
    )
    function _IsSealNA([string]$s) {
        $t = (($s + '') -replace '\s+', '').Trim().ToUpperInvariant()
        return ($t -in @('', 'N/A', 'NA', 'N.A.', '#N/A', '-'))
    }
    function _TrySealDouble {
        param(
            [object]$Value,
            [string]$Text
        )
        if ($Value -ne $null -and $Value -is [double]) {
            return [pscustomobject]@{ Ok = $true; Value = [double]$Value }
        }
        if ($Value -ne $null -and $Value -is [int]) {
            return [pscustomobject]@{ Ok = $true; Value = [double]$Value }
        }
        if ($Value -ne $null -and $Value -is [decimal]) {
            return [pscustomobject]@{ Ok = $true; Value = [double]$Value }
        }
        $raw = (($Text + '').Trim())
        if (-not $raw -and $Value -ne $null) { $raw = (($Value + '').Trim()) }
        if (_IsSealNA $raw) {
            return [pscustomobject]@{ Ok = $false; Value = $null }
        }
        $norm = ($raw -replace '\s+', '')
        $norm = $norm -replace ',', '.'
        $d = 0.0
        if ([double]::TryParse(
                $norm,
                [System.Globalization.NumberStyles]::Float,
                [System.Globalization.CultureInfo]::InvariantCulture,
                [ref]$d
            )) {
            return [pscustomobject]@{ Ok = $true; Value = $d }
        }
        return [pscustomobject]@{ Ok = $false; Value = $null }
    }
    $violations = New-Object System.Collections.Generic.List[object]
    $failCount  = 0
    foreach ($ws in $Pkg.Workbook.Worksheets) {
        if ($ws.Name -eq "Worksheet Instructions") { continue }
        if (-not $ws.Dimension) { continue }
        $obsC = Find-ObservationCol $ws
        for ($r = 3; $r -le 45; $r++) {
            $cartTxt = ($ws.Cells["H$r"].Text + '').Trim()
            $initVal = $ws.Cells["I$r"].Value
            $initTxt = ($ws.Cells["I$r"].Text + '').Trim()
            $finalVal = $ws.Cells["J$r"].Value
            $finalTxt = ($ws.Cells["J$r"].Text + '').Trim()
            $valK  = $ws.Cells["K$r"].Value
            $textL = ($ws.Cells["L$r"].Text + '').Trim()
            $initParsed  = _TrySealDouble -Value $initVal  -Text $initTxt
            $finalParsed = _TrySealDouble -Value $finalVal -Text $finalTxt
            # Säker varning:
            # Endast om faktisk numerisk invägning finns.
            # N/A, NA, blank och placeholders ska inte räknas som invägning.
            if ($initParsed.Ok -and -not $finalParsed.Ok -and [string]::IsNullOrWhiteSpace($textL)) {
                $obsTxt = $ws.Cells[$r, $obsC].Text
                [void]$violations.Add([PSCustomObject]@{
                    Sheet      = $ws.Name
                    Cartridge  = $cartTxt
                    InitialW   = $initParsed.Value
                    FinalW     = $null
                    WeightLoss = $null
                    Status     = 'Saknar utvägning'
                    Obs        = $obsTxt
                })
                continue
            }
            if ($valK -ne $null -and $valK -is [double]) {
                if ($textL -eq "FAIL" -or $valK -le $MinusThreshold) {
                    $obsTxt = $ws.Cells[$r, $obsC].Text
                    [void]$violations.Add([PSCustomObject]@{
                        Sheet      = $ws.Name
                        Cartridge  = $cartTxt
                        InitialW   = $initVal
                        FinalW     = $finalVal
                        WeightLoss = $valK
                        Status     = if ($textL -eq "FAIL") { "FAIL" } else { "Minusvärde" }
                        Obs        = $obsTxt
                    })
                    if ($textL -eq "FAIL") { $failCount++ }
                }
            }
        }
    }
    return [pscustomobject]@{
        Violations = @($violations.ToArray())
        FailCount  = $failCount
    }
}

