﻿# Regelbank för alla Assays
return @{
    Meta = @{
        SchemaVersion = 2
        RuleBankVersion = '2.0.0'
        RuntimeCompiledFormatVersion = 1
        Source = 'RuleBank v2 source'
        LastUpdated = '2026-03-13'
        GeneratedOn = '2026-03-14T17:23:13+01:00'
        SourceHash = 'f94015ce7d3c2c1a58de58575fa2ec390de8045e55ed0fcbc7e36d1caec7d817'
        QuantSpecRulesStatus = 'legacy-empty-compiled-placeholder'
        Counts = @{
            ResultCallPatterns = 187
            ErrorCodes = 23
            SampleExpectationRules = 4
            SampleIdMarkers = 5
            ParityCheckConfig = 5
            SampleNumberRules = 111
            TestTypePolicy = 91
            MissingSamplesConfig = 1
            AssayVersionRules = 140
            QuantSpecRules = 0
        }
    }
    ParityCheckConfig = @(
        @{
            AssayPattern = 'Xpert MTB-RIF Assay G4'
            Enabled = 'TRUE'
            CartridgeField = 'Cartridge S/N'
            SampleTokenIndex = '3'
            SuffixX = 'X'
            SuffixPlus = '+'
            DelaminationMarkerType = 'DelaminationCodeRegex'
            MinValidCartridgeSNPercent = '80'
            Note = 'Use parity (odd/even) to predict expected suffix for MTB-family; fallback to majority if too many missing/invalid S/N'
            Priority = '9000'
        }
        @{
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            Enabled = 'TRUE'
            CartridgeField = 'Cartridge S/N'
            SampleTokenIndex = '3'
            SuffixX = 'X'
            SuffixPlus = '+'
            DelaminationMarkerType = 'DelaminationCodeRegex'
            MinValidCartridgeSNPercent = '80'
            Note = 'Use parity (odd/even) to predict expected suffix for MTB-family; fallback to majority if too many missing/invalid S/N'
            Priority = '9000'
        }
        @{
            AssayPattern = 'Xpert MTB-RIF Ultra'
            Enabled = 'TRUE'
            CartridgeField = 'Cartridge S/N'
            SampleTokenIndex = '3'
            SuffixX = 'X'
            SuffixPlus = '+'
            DelaminationMarkerType = 'DelaminationCodeRegex'
            MinValidCartridgeSNPercent = '80'
            Note = 'Use parity (odd/even) to predict expected suffix for MTB-family; fallback to majority if too many missing/invalid S/N'
            Priority = '9000'
        }
        @{
            AssayPattern = 'Xpert MTB-XDR'
            Enabled = 'TRUE'
            CartridgeField = 'Cartridge S/N'
            SampleTokenIndex = '3'
            SuffixX = 'X'
            SuffixPlus = '+'
            DelaminationMarkerType = 'DelaminationCodeRegex'
            MinValidCartridgeSNPercent = '80'
            Note = 'Use parity (odd/even) to predict expected suffix for MTB-family; fallback to majority if too many missing/invalid S/N'
            Priority = '9000'
        }
        @{
            AssayPattern = '*'
            Enabled = 'TRUE'
            CartridgeField = 'Cartridge S/N'
            SampleTokenIndex = '3'
            SuffixX = 'X'
            SuffixPlus = '+'
            DelaminationMarkerType = 'DelaminationCodeRegex'
            MinValidCartridgeSNPercent = '80'
            Note = '(Template) Enable per-assay when X/+ naming is used and Cartridge S/N parity is meaningful'
            Priority = '100'
        }
    )
    QuantSpecRules = @()
    TestTypePolicy = @(
        @{
            AssayPattern = 'Xpert-C. difficile G2'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'C.DIFF G2'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert C.difficile BT'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'C.DIFF BT'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert C.diff-Epi'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'C.DIFF EP'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert C.difficile G3'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'C.DIFF'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert C.difficile G3'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'C.DIFF JP'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert Carba-R'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'CARBA IMP1'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'CARBA-R IUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'CARBA IMP1'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Carba-R BEU IUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'CARBA'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'CARBA-R RUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'CARBA'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Carba-R BEU RUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'CARBA'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert_Carba-R'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'CARBA'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert Xpress SARS-CoV-2 CE-IVD'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'SARS'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert Xpress SARS-CoV-2'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'SARS'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'LCE009 Xpress SARS-CoV-2 plus'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'COVID plus'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpress CoV-2 plus IUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'COVID plus'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpress CoV-2 plus RUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'COVID plus'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert Xpress CoV-2 plus'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'COVID plus'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert Xpress CoV-2 plus IVD'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'COVID plus'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'SARS-CoV-2_Flu_RSV_plus'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'FLUVID plus'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'SARS-CoV-2_Flu_RSV plus IUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'FLUVID plus'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'SARS-CoV-2_Flu_RSV plus RUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'FLUVID plus'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpress SARS-CoV-2_Flu_RSV plus'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'FLUVID plus'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpress SARS-CoV-2 Flu RSV plus'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'FLUVID plus'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert CT_CE'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'CT'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert CT_NG'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'CTNG'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert CT_NG'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'CTNG JP'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert Ebola EUA'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'EBOLA'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert Ebola CE-IVD'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'EBOLA'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Ebola RUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'EBOLA'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpress GBS IUO'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'GBS'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpress GBS RUO'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'GBS'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert Xpress GBS RUO'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'GBS'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert Xpress GBS'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'GBS'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'GBS LB RUO'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'GBS'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'GBS LB XC IUO'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'GBS'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert GBS LB XC'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'GBS'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert HBV Viral Load'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HBV*'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert HCV VL Fingerstick'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HCV FS*'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'HCV VL WB RUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HCV FS*'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'HCV IUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HCV'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert HCV PQC'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HCV'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert_HCV Viral Load'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HCV VL*'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'HCV Viral Load RUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HCV VL*'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert_HIV-1 Viral Load'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HIV VL*'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'HIV-1 Viral Load RUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HIV VL*'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'HIV-1 Qual XC DBS RUO'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HIV QA XC'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'HIV-1 Qual XC DBS IUO'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HIV QA XC'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert HIV-1 Qual XC'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '120'
            AssayFamily = 'HIV QA XC'
            Note = 'Manual policy: HIV-1 Qual XC uses Specimen only'
        }
        @{
            AssayPattern = 'HIV-1 Qual XC'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '110'
            AssayFamily = 'HIV QA XC'
            Note = 'Manual policy: HIV-1 Qual XC uses Specimen only'
        }
        @{
            AssayPattern = 'Xpert HIV-1 Qual XC PQC'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HIV QA XC'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert HIV-1 Qual XC PQC RUO'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HIV QA XC'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'HIV-1 Viral Load XC IUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HIV VL XC'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'HIV-1 Viral Load XC RUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HIV VL XC'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert HIV-1 Viral Load XC'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HIV VL XC'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert HPV HR'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HPV'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert HPV v2 HR'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HPV'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'HPV HR AND GENOTYPE RUO ASSAY'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'HPV'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert MRSA NxG'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'MRSA NxG'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'MRSA NxG IUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'MRSA NxG'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'MRSA NxG RUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'MRSA NxG'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert MRSA_SA_BC'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'MRSA SA'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert MRSA_SA_BC_CE'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'MRSA SA'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert MRSA-SA BC G3'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'MRSA SA'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert MRSA-SA SSTI G3'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'MRSA SA'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert SA Nasal Complete G3'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'MRSA SA'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'MRSA-SA ETA'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'MRSA SA'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert MTB-RIF Ultra'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'MTB U'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'MTB-RIF Ultra v2 RUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'MTB U'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert MTB-RIF Assay G4'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'MTB'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert MTB-RIF US IVD'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'MTB'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'MTB JP'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert MTB-XDR'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'MTB XDR'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'MTB-XDR RUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'MTB XDR'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'MTB-XDR IUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'MTB XDR'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert Norovirus'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'NORO'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'TAP Panel RUO'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'TAP Panel'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'TAP Panel IUO'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'TAP Panel'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert TAP Panel'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'TAP Panel'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert vanA vanB'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'VAN AB'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'XP Flu-RSV RUO'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'FLU RSV'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert Xpress Flu-RSV'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'FLU RSV'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpress Flu IPT_EAT off'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'FLU'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Respiratory Panel IUO'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'Resp Panel'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Respiratory Panel RUO'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'Resp Panel'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Respiratory panel'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'Resp Panel'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Respiratory panel CE-IVD'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'Resp Panel'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Respiratory panel UKCA-IVD'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'Resp Panel'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'GI Panel RUO'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'GI Panel'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'GI Panel IUO'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'GI Panel'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert GI Panel'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'GI Panel'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert GI Panel CE-IVD'
            AllowedTestTypes = 'Specimen'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'GI Panel'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert Xpress Strep A'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'STREPA'
            Note = 'Generated from Assay.csv'
        }
        @{
            AssayPattern = 'Xpert Xpress_Strep A'
            AllowedTestTypes = 'Negative Control 1|Positive Control 1|Positive Control 2'
            Enabled = 'TRUE'
            Priority = '100'
            AssayFamily = 'STREPA'
            Note = 'Generated from Assay.csv'
        }
    )
    ErrorCodes = @(
        @{
            ErrorCode = '5001'
            Name = 'Curve Fit Error'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '5002'
            Name = 'Curve Fit Error'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '5003'
            Name = 'Curve Fit Error'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '5004'
            Name = 'Curve Fit Error'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '5005'
            Name = 'Curve Fit Error'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '5015'
            Name = 'Curve Fit Error'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '5016'
            Name = 'Curve Fit Error'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '5007'
            Name = 'Probe Check Low'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '5017'
            Name = 'Probe Check Low'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '5019'
            Name = 'Probe Check Low'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '5006'
            Name = 'Probe Check High'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '5018'
            Name = 'Probe Check High'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '2037'
            Name = 'CIT'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '5011'
            Name = 'SLD'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '2008'
            Name = 'Pressure Abort'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '2096'
            Name = 'Sample Volume Adequacy'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '2097'
            Name = 'Sample Volume Adequacy'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '2125'
            Name = 'Sample Volume Adequacy'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = ''
            Name = 'Max Pressure > 90 PSI'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = ''
            Name = 'Invalid w/o error (SPC Ct=0)'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '####'
            Name = 'Delamination + error code'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = ''
            Name = 'All types of "MTB": RIF Resistance Indeterminate'
            GeneratesRetest = 'No'
        }
        @{
            ErrorCode = '####'
            Name = 'Other error codes'
            GeneratesRetest = 'Yes'
        }
    )
    ResultCallPatterns = @(
        @{
            Assay = '*'
            Call = 'ERROR'
            MatchType = 'EQUALS'
            Pattern = 'ERROR'
            Enabled = 'TRUE'
            Priority = '9500'
            Note = 'Generic: Test Result = ERROR'
        }
        @{
            Assay = '*'
            Call = 'ERROR'
            MatchType = 'CONTAINS'
            Pattern = 'NO RESULT'
            Enabled = 'TRUE'
            Priority = '9500'
            Note = 'Generic: NO RESULT'
        }
        @{
            Assay = '*'
            Call = 'ERROR'
            MatchType = 'CONTAINS'
            Pattern = 'Aborted'
            Enabled = 'TRUE'
            Priority = '9500'
            Note = 'Generic: Aborted'
        }
        @{
            Assay = '*'
            Call = 'ERROR'
            MatchType = 'CONTAINS'
            Pattern = 'INVALID'
            Enabled = 'TRUE'
            Priority = '1000'
            Note = 'Generic: INVALID (non-HPV)'
        }
        @{
            Assay = 'Xpert MTB-RIF Assay G4'
            Call = 'NEG'
            MatchType = 'CONTAINS'
            Pattern = 'MTB NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9400'
            Note = 'MTB family: MTB NOT DETECTED => NEG'
        }
        @{
            Assay = 'Xpert MTB-XDR'
            Call = 'NEG'
            MatchType = 'CONTAINS'
            Pattern = 'MTB NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9400'
            Note = 'MTB family: MTB NOT DETECTED => NEG'
        }
        @{
            Assay = 'Xpert MTB-RIF Ultra'
            Call = 'NEG'
            MatchType = 'CONTAINS'
            Pattern = 'MTB NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9400'
            Note = 'MTB family: MTB NOT DETECTED => NEG'
        }
        @{
            Assay = 'Xpert MTB-RIF JP IVD'
            Call = 'NEG'
            MatchType = 'CONTAINS'
            Pattern = 'MTB NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9400'
            Note = 'MTB family: MTB NOT DETECTED => NEG'
        }
        @{
            Assay = 'Xpert MTB-XDR'
            Call = 'POS'
            MatchType = 'CONTAINS'
            Pattern = 'MTB Trace DETECTED'
            Enabled = 'TRUE'
            Priority = '9390'
            Note = 'MTB family: MTB Trace DETECTED => POS (even if RIF indeterminate)'
        }
        @{
            Assay = 'Xpert MTB-RIF Ultra'
            Call = 'POS'
            MatchType = 'CONTAINS'
            Pattern = 'MTB Trace DETECTED'
            Enabled = 'TRUE'
            Priority = '9390'
            Note = 'MTB family: MTB Trace DETECTED => POS (even if RIF indeterminate)'
        }
        @{
            Assay = 'Xpert MTB-RIF JP IVD'
            Call = 'POS'
            MatchType = 'CONTAINS'
            Pattern = 'MTB Trace DETECTED'
            Enabled = 'TRUE'
            Priority = '9390'
            Note = 'MTB family: MTB Trace DETECTED => POS (even if RIF indeterminate)'
        }
        @{
            Assay = 'Xpert MTB-RIF Assay G4'
            Call = 'POS'
            MatchType = 'CONTAINS'
            Pattern = 'MTB Trace DETECTED'
            Enabled = 'TRUE'
            Priority = '9390'
            Note = 'MTB family: MTB Trace DETECTED => POS (even if RIF indeterminate)'
        }
        @{
            Assay = 'Xpert MTB-RIF Assay G4'
            Call = 'POS'
            MatchType = 'CONTAINS'
            Pattern = 'MTB DETECTED'
            Enabled = 'TRUE'
            Priority = '9380'
            Note = 'MTB family: MTB DETECTED => POS (covers HIGH/LOW; even if RIF indeterminate)'
        }
        @{
            Assay = 'Xpert MTB-RIF Ultra'
            Call = 'POS'
            MatchType = 'CONTAINS'
            Pattern = 'MTB DETECTED'
            Enabled = 'TRUE'
            Priority = '9380'
            Note = 'MTB family: MTB DETECTED => POS (covers HIGH/LOW; even if RIF indeterminate)'
        }
        @{
            Assay = 'Xpert MTB-RIF JP IVD'
            Call = 'POS'
            MatchType = 'CONTAINS'
            Pattern = 'MTB DETECTED'
            Enabled = 'TRUE'
            Priority = '9380'
            Note = 'MTB family: MTB DETECTED => POS (covers HIGH/LOW; even if RIF indeterminate)'
        }
        @{
            Assay = 'Xpert MTB-XDR'
            Call = 'POS'
            MatchType = 'CONTAINS'
            Pattern = 'MTB DETECTED'
            Enabled = 'TRUE'
            Priority = '9380'
            Note = 'MTB family: MTB DETECTED => POS (covers HIGH/LOW; even if RIF indeterminate)'
        }
        @{
            Assay = 'Xpert MRSA NxG'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'MRSA DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MRSA NxG SampleType 1'
        }
        @{
            Assay = 'Xpert MTB-RIF US IVD'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'MTB NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB SampleType 0'
        }
        @{
            Assay = 'Xpert HPV HR'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'HR HPV POS'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HPV SampleType 1'
        }
        @{
            Assay = 'Xpert MTB-RIF Ultra'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'MTB NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB U SampleType 0'
        }
        @{
            Assay = 'Xpert HIV-1 Viral Load XC'
            Call = 'POS'
            MatchType = 'REGEX'
            Pattern = 'HIV\-1\ DETECTED\ .*\ copies/mL\ \(log\ .*\..*\)'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HIV VL XC SampleType 1 (wildcard)'
        }
        @{
            Assay = 'Xpert MTB-RIF Ultra'
            Call = 'POS'
            MatchType = 'REGEX'
            Pattern = 'MTB\ DETECTED\ .*;Rif\ Resistance\ DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB U SampleType 1 (wildcard)'
        }
        @{
            Assay = 'Xpert MTB-RIF Ultra'
            Call = 'POS'
            MatchType = 'REGEX'
            Pattern = 'MTB\ DETECTED\ .*;Rif\ Resistance\ NOT\ DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB U SampleType 2 (wildcard)'
        }
        @{
            Assay = 'Xpert HPV HR'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'INVALID'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HPV SampleType 0'
        }
        @{
            Assay = 'Xpert MTB-XDR'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'MTB DETECTED;INH Resistance DETECTED;FLQ Resistance DETECTED;AMK Resistance DETECTED;KAN Resistance DETECTED;CAP Resistance DETECTED;ETH Resistance DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB XDR SampleType 2'
        }
        @{
            Assay = 'Xpert MTB-XDR'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'MTB DETECTED;INH Resistance NOT DETECTED;FLQ Resistance NOT DETECTED;AMK Resistance NOT DETECTED;KAN Resistance NOT DETECTED;CAP Resistance NOT DETECTED;ETH Resistance NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB XDR SampleType 1'
        }
        @{
            Assay = 'Xpert HIV-1 Viral Load XC'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'HIV-1 NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HIV VL XC SampleType 0'
        }
        @{
            Assay = 'Xpert MTB-XDR'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'MTB NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB XDR SampleType 0'
        }
        @{
            Assay = 'Xpert HCV VL Fingerstick'
            Call = 'POS'
            MatchType = 'REGEX'
            Pattern = 'HCV\ DETECTED\ .*\ IU/mL\ \(log\ .*\..*\)'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HCV FS SampleType 1 (wildcard)'
        }
        @{
            Assay = 'Xpert Norovirus'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'NORO GI DETECTED;NORO GII DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec NORO SampleType 1'
        }
        @{
            Assay = 'Xpert MTB-RIF US IVD'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'MTB DETECTED;Rif Resistance NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB SampleType 1'
        }
        @{
            Assay = 'Xpert HPV v2 HR'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'HR HPV POS'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HPV SampleType 1'
        }
        @{
            Assay = 'Xpert MTB-RIF JP IVD'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'MTB NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB JP SampleType 0'
        }
        @{
            Assay = 'Xpert MRSA_SA_BC_CE'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'MRSA NEGATIVE;SA NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MRSA SA SampleType 0'
        }
        @{
            Assay = 'Xpert MRSA-SA BC G3'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'MRSA NEGATIVE;SA NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MRSA SA SampleType 0'
        }
        @{
            Assay = 'Xpert MRSA-SA BC G3'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'MRSA POSITIVE;SA POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MRSA SA SampleType 1'
        }
        @{
            Assay = 'Xpert MRSA-SA SSTI G3'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'MRSA NEGATIVE;SA NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MRSA SA SampleType 0'
        }
        @{
            Assay = 'Xpert MRSA-SA SSTI G3'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'MRSA POSITIVE;SA POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MRSA SA SampleType 1'
        }
        @{
            Assay = 'Xpert MRSA_SA_BC'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'MRSA NEGATIVE;SA NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MRSA SA SampleType 0'
        }
        @{
            Assay = 'Xpert MRSA_SA_BC'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'MRSA POSITIVE;SA POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MRSA SA SampleType 1'
        }
        @{
            Assay = 'Xpert MRSA_SA_BC_CE'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'MRSA POSITIVE;SA POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MRSA SA SampleType 1'
        }
        @{
            Assay = 'Xpert MRSA NxG'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'MRSA NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MRSA NxG SampleType 0'
        }
        @{
            Assay = 'Xpert HPV v2 HR'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'INVALID'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HPV SampleType 0'
        }
        @{
            Assay = 'Xpert MTB-RIF Assay G4'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'MTB NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB SampleType 0'
        }
        @{
            Assay = 'Xpert SA Nasal Complete G3'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'MRSA NEGATIVE;SA NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MRSA SA SampleType 0'
        }
        @{
            Assay = 'Xpert MTB-RIF Assay G4'
            Call = 'POS'
            MatchType = 'REGEX'
            Pattern = 'MTB\ DETECTED\ .*;Rif\ Resistance\ NOT\ DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB SampleType 1 (wildcard)'
        }
        @{
            Assay = 'Xpert MTB-RIF JP IVD'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'MTB DETECTED;Rif Resistance DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB JP SampleType 2'
        }
        @{
            Assay = 'Xpert MTB-RIF JP IVD'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'MTB DETECTED;Rif Resistance NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB JP SampleType 1'
        }
        @{
            Assay = 'Xpert Norovirus'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'NORO GI NOT DETECTED;NORO GII NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec NORO SampleType 0'
        }
        @{
            Assay = 'Xpert SA Nasal Complete G3'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'MRSA POSITIVE;SA POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MRSA SA SampleType 1'
        }
        @{
            Assay = 'Xpert HCV PQC'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'HCV NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GX HCV SampleType 0'
        }
        @{
            Assay = 'Xpert-C. difficile G2'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Toxigenic C.diff NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec C.DIFF SampleType 0'
        }
        @{
            Assay = 'Xpert_Carba-R'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'IMP1 DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec CARBA SampleType 1'
        }
        @{
            Assay = 'Xpert_Carba-R'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'IMP1 NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec CARBA SampleType 0'
        }
        @{
            Assay = 'Xpert_HCV Viral Load'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'HCV NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HCV VL SampleType 0'
        }
        @{
            Assay = 'Xpert_HCV Viral Load'
            Call = 'POS'
            MatchType = 'REGEX'
            Pattern = 'HCV\ DETECTED\ .*\ IU/mL\ \(log\ .*\..*\)'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HCV VL SampleType 1 (wildcard)'
        }
        @{
            Assay = 'Xpert_HIV-1 Viral Load'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'HIV-1 NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HIV VL SampleType 0'
        }
        @{
            Assay = 'Xpert_HIV-1 Viral Load'
            Call = 'POS'
            MatchType = 'REGEX'
            Pattern = 'HIV\-1\ DETECTED\ .*\ copies/mL\ \(log\ .*\..*\)'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HIV VL SampleType 1 (wildcard)'
        }
        @{
            Assay = 'Xpress CoV-2 plus IUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Covid plus SampleType 0'
        }
        @{
            Assay = 'Xpress CoV-2 plus IUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Covid plus SampleType 1'
        }
        @{
            Assay = 'Xpress CoV-2 plus RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Covid plus SampleType 0'
        }
        @{
            Assay = 'Xpress CoV-2 plus RUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Covid plus SampleType 1'
        }
        @{
            Assay = 'Xpress Flu IPT_EAT off'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Flu A NEGATIVE;Flu B NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec FLU RSV SampleType 0'
        }
        @{
            Assay = 'Xpress Flu IPT_EAT off'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Flu A POSITIVE;Flu B POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec FLU RSV SampleType 1'
        }
        @{
            Assay = 'Xpress GBS IUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'GBS NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GBS SampleType 0'
        }
        @{
            Assay = 'Xpress GBS IUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'GBS POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GBS SampleType 1'
        }
        @{
            Assay = 'Xpress GBS RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'GBS NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GBS SampleType 0'
        }
        @{
            Assay = 'Xpress GBS RUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'GBS POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GBS SampleType 1'
        }
        @{
            Assay = 'Xpress SARS-CoV-2 Flu RSV plus'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec FLUVID plus SampleType 0'
        }
        @{
            Assay = 'Xpress SARS-CoV-2 Flu RSV plus'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE;Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec FLUVID plus SampleType 1'
        }
        @{
            Assay = 'Xpress SARS-CoV-2_Flu_RSV plus'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec FLUVID plus SampleType 0'
        }
        @{
            Assay = 'Xpert-C. difficile G2'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Toxigenic C.diff POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec C.DIFF SampleType 1'
        }
        @{
            Assay = 'Xpert vanA vanB'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'vanA POSITIVE;vanB POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec VAN AB SampleType 1'
        }
        @{
            Assay = 'Xpert TAP Panel'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Ft DETECTED;Ba DETECTED;Yp DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec TAP Panel SampleType 1'
        }
        @{
            Assay = 'Xpert vanA vanB'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'vanA NEGATIVE;vanB NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec VAN AB SampleType 0'
        }
        @{
            Assay = 'Xpert TAP Panel'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Ft NOT DETECTED;Ba NOT DETECTED;Yp NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec TAP Panel SampleType 0'
        }
        @{
            Assay = 'Xpert Xpress CoV-2 plus'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Covid plus SampleType 0'
        }
        @{
            Assay = 'Xpert Xpress CoV-2 plus'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Covid plus SampleType 1'
        }
        @{
            Assay = 'Xpert Xpress CoV-2 plus IVD'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Covid plus SampleType 0'
        }
        @{
            Assay = 'Xpert Xpress CoV-2 plus IVD'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Covid plus SampleType 1'
        }
        @{
            Assay = 'Xpert Xpress Flu-RSV'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec FLU RSV SampleType 0'
        }
        @{
            Assay = 'Xpert Xpress Flu-RSV'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec FLU RSV SampleType 1'
        }
        @{
            Assay = 'Xpert Xpress GBS'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'GBS NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GBS SampleType 0'
        }
        @{
            Assay = 'Xpert Xpress GBS'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'GBS POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GBS SampleType 1'
        }
        @{
            Assay = 'Xpert Xpress GBS RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'GBS NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GBS SampleType 0'
        }
        @{
            Assay = 'Xpert Xpress GBS RUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'GBS POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GBS SampleType 1'
        }
        @{
            Assay = 'Xpert Xpress SARS-CoV-2'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Sars SampleType 0'
        }
        @{
            Assay = 'Xpert Xpress SARS-CoV-2'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Sars SampleType 1'
        }
        @{
            Assay = 'Xpert Xpress SARS-CoV-2 CE-IVD'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Sars SampleType 0'
        }
        @{
            Assay = 'Xpert Xpress SARS-CoV-2 CE-IVD'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Sars SampleType 1'
        }
        @{
            Assay = 'Xpert Xpress Strep A'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Strep A DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec STREPA SampleType 1'
        }
        @{
            Assay = 'Xpert Xpress Strep A'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Strep A NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec STREPA SampleType 0'
        }
        @{
            Assay = 'Xpert Xpress_Strep A'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Strep A DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec STREPA SampleType 1'
        }
        @{
            Assay = 'Xpert Xpress_Strep A'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Strep A NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec STREPA SampleType 0'
        }
        @{
            Assay = 'Xpert HCV VL Fingerstick'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'HCV NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HCV FS SampleType 0'
        }
        @{
            Assay = 'Xpert HCV PQC'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'HCV DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GX HCV SampleType 1'
        }
        @{
            Assay = 'MTB-XDR IUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'MTB DETECTED;INH Resistance NOT DETECTED;FLQ Resistance NOT DETECTED;AMK Resistance NOT DETECTED;KAN Resistance NOT DETECTED;CAP Resistance NOT DETECTED;ETH Resistance NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB XDR SampleType 1'
        }
        @{
            Assay = 'LCE009 Xpress SARS-CoV-2 plus'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Covid plus SampleType 0'
        }
        @{
            Assay = 'HCV Viral Load RUO'
            Call = 'POS'
            MatchType = 'REGEX'
            Pattern = 'HCV\ DETECTED\ .*\ IU/mL\ \(log\ .*\..*\)'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HCV VL SampleType 1 (wildcard)'
        }
        @{
            Assay = 'HIV-1 Viral Load RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'HIV-1 NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HIV VL SampleType 0'
        }
        @{
            Assay = 'HIV-1 Viral Load RUO'
            Call = 'POS'
            MatchType = 'REGEX'
            Pattern = 'HIV\-1\ DETECTED\ .*\ copies/mL\ \(log\ .*\..*\)'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HIV VL SampleType 1 (wildcard)'
        }
        @{
            Assay = 'HIV-1 Viral Load XC IUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'HIV-1 NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HIV VL XC SampleType 0'
        }
        @{
            Assay = 'HIV-1 Viral Load XC IUO'
            Call = 'POS'
            MatchType = 'REGEX'
            Pattern = 'HIV\-1\ DETECTED\ .*\ copies/mL\ \(log\ .*\..*\)'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HIV VL XC SampleType 1 (wildcard)'
        }
        @{
            Assay = 'HIV-1 Viral Load XC RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'HIV-1 NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HIV VL XC SampleType 0'
        }
        @{
            Assay = 'HIV-1 Viral Load XC RUO'
            Call = 'POS'
            MatchType = 'REGEX'
            Pattern = 'HIV\-1\ DETECTED\ .*\ copies/mL\ \(log\ .*\..*\)'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HIV VL XC SampleType 1 (wildcard)'
        }
        @{
            Assay = 'HPV HR AND GENOTYPE RUO ASSAY'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'HR HPV POS'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HPV SampleType 1'
        }
        @{
            Assay = 'HPV HR AND GENOTYPE RUO ASSAY'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'INVALID'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HPV SampleType 0'
        }
        @{
            Assay = 'LCE009 Xpress SARS-CoV-2 plus'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Covid plus SampleType 1'
        }
        @{
            Assay = 'Xpert HBV Viral Load'
            Call = 'POS'
            MatchType = 'REGEX'
            Pattern = 'HBV\ DETECTED\ .*\ IU/mL\ \(log\ .*\..*\)'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HBV VL SampleType 1 (wildcard)'
        }
        @{
            Assay = 'MRSA NxG IUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'MRSA DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MRSA NxG SampleType 1'
        }
        @{
            Assay = 'MRSA NxG IUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'MRSA NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MRSA NxG SampleType 0'
        }
        @{
            Assay = 'MRSA NxG RUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'MRSA DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MRSA NxG SampleType 1'
        }
        @{
            Assay = 'MRSA NxG RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'MRSA NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MRSA NxG SampleType 0'
        }
        @{
            Assay = 'MRSA-SA ETA'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'MRSA NEGATIVE;SA NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MRSA SA SampleType 0'
        }
        @{
            Assay = 'MRSA-SA ETA'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'MRSA POSITIVE;SA POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MRSA SA SampleType 1'
        }
        @{
            Assay = 'MTB-RIF Ultra v2 RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'MTB NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB U SampleType 0'
        }
        @{
            Assay = 'MTB-RIF Ultra v2 RUO'
            Call = 'POS'
            MatchType = 'REGEX'
            Pattern = 'MTB\ DETECTED\ .*;Rif\ Resistance\ DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB U SampleType 1 (wildcard)'
        }
        @{
            Assay = 'MTB-RIF Ultra v2 RUO'
            Call = 'POS'
            MatchType = 'REGEX'
            Pattern = 'MTB\ DETECTED\ .*;Rif\ Resistance\ NOT\ DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB U SampleType 2 (wildcard)'
        }
        @{
            Assay = 'HCV Viral Load RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'HCV NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HCV VL SampleType 0'
        }
        @{
            Assay = 'HCV VL WB RUO'
            Call = 'POS'
            MatchType = 'REGEX'
            Pattern = 'HCV\ DETECTED\ .*\ IU/mL\ \(log\ .*\..*\)'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HCV FS SampleType 1 (wildcard)'
        }
        @{
            Assay = 'HCV VL WB RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'HCV NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HCV FS SampleType 0'
        }
        @{
            Assay = 'HCV IUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'HCV NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GX HCV SampleType 0'
        }
        @{
            Assay = 'CARBA-R IUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'IMP1 DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec CARBA SampleType 1'
        }
        @{
            Assay = 'CARBA-R IUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'IMP1 NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec CARBA SampleType 0'
        }
        @{
            Assay = 'CARBA-R RUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'IMP DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec CARBA SampleType 1'
        }
        @{
            Assay = 'CARBA-R RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'IMP NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec CARBA SampleType 0'
        }
        @{
            Assay = 'Carba-R BEU IUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'IMP DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec CARBA SampleType 1'
        }
        @{
            Assay = 'Carba-R BEU IUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'IMP NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec CARBA SampleType 0'
        }
        @{
            Assay = 'Carba-R BEU RUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'IMP DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec CARBA SampleType 1'
        }
        @{
            Assay = 'Carba-R BEU RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'IMP NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec CARBA SampleType 0'
        }
        @{
            Assay = 'Ebola RUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Ebola GP DETECTED;Ebola NP DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec EBOLA SampleType 1'
        }
        @{
            Assay = 'Ebola RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Ebola GP NOT DETECTED;Ebola NP NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec EBOLA SampleType 0'
        }
        @{
            Assay = 'GBS LB RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'GBS NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GBS XC SampleType 0'
        }
        @{
            Assay = 'GBS LB RUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'GBS POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GBS XC SampleType 1'
        }
        @{
            Assay = 'GBS LB XC IUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'GBS NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GBS XC SampleType 0'
        }
        @{
            Assay = 'GBS LB XC IUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'GBS POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GBS XC SampleType 1'
        }
        @{
            Assay = 'GI Panel IUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Campylobacter NEGATIVE;Salmonella NEGATIVE;STEC stx1 NEGATIVE;STEC stx2 NEGATIVE;Shigella EIEC NEGATIVE;V. cholerae NEGATIVE;V. parahaemolyticus NEGATIVE;Yersinia NEGATIVE;Cryptosporidium NEGATIVE;Giardia NEGATIVE;Norovirus NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GI Panel SampleType 0'
        }
        @{
            Assay = 'GI Panel IUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Campylobacter POSITIVE;Salmonella POSITIVE;STEC stx1 POSITIVE;STEC stx2 POSITIVE;Shigella EIEC POSITIVE;V. cholerae POSITIVE;V. parahaemolyticus POSITIVE;Yersinia POSITIVE;Cryptosporidium POSITIVE;Giardia POSITIVE;Norovirus POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GI Panel SampleType 1'
        }
        @{
            Assay = 'GI Panel RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Campylobacter NEGATIVE;Salmonella NEGATIVE;STEC stx1 NEGATIVE;STEC stx2 NEGATIVE;Shigella EIEC NEGATIVE;V. cholerae NEGATIVE;V. parahaemolyticus NEGATIVE;Yersinia NEGATIVE;Cryptosporidium NEGATIVE;Giardia NEGATIVE;Norovirus NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GI Panel SampleType 0'
        }
        @{
            Assay = 'GI Panel RUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Campylobacter POSITIVE;Salmonella POSITIVE;STEC stx1 POSITIVE;STEC stx2 POSITIVE;Shigella EIEC POSITIVE;V. cholerae POSITIVE;V. parahaemolyticus POSITIVE;Yersinia POSITIVE;Cryptosporidium POSITIVE;Giardia POSITIVE;Norovirus POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GI Panel SampleType 1'
        }
        @{
            Assay = 'HCV IUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'HCV DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GX HCV SampleType 1'
        }
        @{
            Assay = 'MTB-XDR IUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'MTB DETECTED;INH Resistance DETECTED;FLQ Resistance DETECTED;AMK Resistance DETECTED;KAN Resistance DETECTED;CAP Resistance DETECTED;ETH Resistance DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB XDR SampleType 2'
        }
        @{
            Assay = 'Xpress SARS-CoV-2_Flu_RSV plus'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE;Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec FLUVID plus SampleType 1'
        }
        @{
            Assay = 'MTB-XDR IUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'MTB NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB XDR SampleType 0'
        }
        @{
            Assay = 'Xpert C.difficile BT'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Toxigenic C.diff NEG;Binary Toxin NEG;027 NEG'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec C.DIFF SampleType 0'
        }
        @{
            Assay = 'Xpert C.difficile G3'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Toxigenic C.diff NEGATIVE;027 PRESUMPTIVE NEG'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec C.DIFF SampleType 0'
        }
        @{
            Assay = 'Xpert C.difficile G3'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Toxigenic C.diff POSITIVE;027 PRESUMPTIVE POS'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec C.DIFF SampleType 1'
        }
        @{
            Assay = 'Xpert CT_CE'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'CT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec CTNG SampleType 1'
        }
        @{
            Assay = 'Xpert CT_CE'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'CT NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec CTNG SampleType 0'
        }
        @{
            Assay = 'Xpert CT_NG'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'CT DETECTED;NG DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec CTNG SampleType 1'
        }
        @{
            Assay = 'Xpert CT_NG'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'CT NOT DETECTED;NG NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec CTNG SampleType 0'
        }
        @{
            Assay = 'Xpert Carba-R'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'IMP1 DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec CARBA SampleType 1'
        }
        @{
            Assay = 'Xpert Carba-R'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'IMP1 NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec CARBA SampleType 0'
        }
        @{
            Assay = 'Xpert Ebola CE-IVD'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Ebola GP DETECTED;Ebola NP DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec EBOLA SampleType 1'
        }
        @{
            Assay = 'Xpert Ebola CE-IVD'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Ebola GP NOT DETECTED;Ebola NP NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec EBOLA SampleType 0'
        }
        @{
            Assay = 'Xpert Ebola EUA'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Ebola GP DETECTED;Ebola NP DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec EBOLA SampleType 1'
        }
        @{
            Assay = 'Xpert Ebola EUA'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Ebola GP NOT DETECTED;Ebola NP NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec EBOLA SampleType 0'
        }
        @{
            Assay = 'Xpert GBS LB XC'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'GBS NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GBS XC SampleType 0'
        }
        @{
            Assay = 'Xpert GBS LB XC'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'GBS POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GBS XC SampleType 1'
        }
        @{
            Assay = 'Xpert GI Panel'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Campylobacter NEGATIVE;Salmonella NEGATIVE;STEC stx1 NEGATIVE;STEC stx2 NEGATIVE;Shigella EIEC NEGATIVE;V. cholerae NEGATIVE;V. parahaemolyticus NEGATIVE;Yersinia NEGATIVE;Cryptosporidium NEGATIVE;Giardia NEGATIVE;Norovirus NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GI Panel SampleType 0'
        }
        @{
            Assay = 'Xpert GI Panel'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Campylobacter POSITIVE;Salmonella POSITIVE;STEC stx1 POSITIVE;STEC stx2 POSITIVE;Shigella EIEC POSITIVE;V. cholerae POSITIVE;V. parahaemolyticus POSITIVE;Yersinia POSITIVE;Cryptosporidium POSITIVE;Giardia POSITIVE;Norovirus POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GI Panel SampleType 1'
        }
        @{
            Assay = 'Xpert GI Panel CE-IVD'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Campylobacter NEGATIVE;Salmonella NEGATIVE;STEC stx1 NEGATIVE;STEC stx2 NEGATIVE;Shigella EIEC NEGATIVE;V. cholerae NEGATIVE;V. parahaemolyticus NEGATIVE;Yersinia NEGATIVE;Cryptosporidium NEGATIVE;Giardia NEGATIVE;Norovirus NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GI Panel SampleType 0'
        }
        @{
            Assay = 'Xpert GI Panel CE-IVD'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Campylobacter POSITIVE;Salmonella POSITIVE;STEC stx1 POSITIVE;STEC stx2 POSITIVE;Shigella EIEC POSITIVE;V. cholerae POSITIVE;V. parahaemolyticus POSITIVE;Yersinia POSITIVE;Cryptosporidium POSITIVE;Giardia POSITIVE;Norovirus POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec GI Panel SampleType 1'
        }
        @{
            Assay = 'Xpert HBV Viral Load'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'HBV NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec HBV VL SampleType 0'
        }
        @{
            Assay = 'Xpert C.difficile BT'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Toxigenic C.diff POS;Binary Toxin POS;027 PRESUMPTIVE POS'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec C.DIFF SampleType 1'
        }
        @{
            Assay = 'Xpert C.diff-Epi'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Toxigenic C.diff POSITIVE;027 PRESUMPTIVE POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec C.DIFF SampleType 1'
        }
        @{
            Assay = 'MTB-XDR RUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'MTB DETECTED;INH Resistance DETECTED;FLQ Resistance DETECTED;AMK Resistance DETECTED;KAN Resistance DETECTED;CAP Resistance DETECTED;ETH Resistance DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB XDR SampleType 2'
        }
        @{
            Assay = 'Xpert C.diff-Epi'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Toxigenic C.diff NEGATIVE;027 PRESUMPTIVE NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec C.DIFF SampleType 0'
        }
        @{
            Assay = 'MTB-XDR RUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'MTB DETECTED;INH Resistance NOT DETECTED;FLQ Resistance NOT DETECTED;AMK Resistance NOT DETECTED;KAN Resistance NOT DETECTED;CAP Resistance NOT DETECTED;ETH Resistance NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB XDR SampleType 1'
        }
        @{
            Assay = 'MTB-XDR RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'MTB NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec MTB XDR SampleType 0'
        }
        @{
            Assay = 'Respiratory Panel IUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Adenovirus NEGATIVE;Coronavirus NEGATIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza NEGATIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Respiratory Panel SampleType 0'
        }
        @{
            Assay = 'Respiratory Panel RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Adenovirus NEGATIVE;Coronavirus NEGATIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza NEGATIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Respiratory Panel SampleType 0'
        }
        @{
            Assay = 'Respiratory panel'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Adenovirus NEGATIVE;Coronavirus NEGATIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza NEGATIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Respiratory Panel SampleType 0'
        }
        @{
            Assay = 'Respiratory panel CE-IVD'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Adenovirus NEGATIVE;Coronavirus NEGATIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza NEGATIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Respiratory Panel SampleType 0'
        }
        @{
            Assay = 'Respiratory panel UKCA-IVD'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Adenovirus NEGATIVE;Coronavirus NEGATIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza NEGATIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec Respiratory Panel SampleType 0'
        }
        @{
            Assay = 'SARS-CoV-2_Flu_RSV plus IUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec FLUVID plus SampleType 0'
        }
        @{
            Assay = 'SARS-CoV-2_Flu_RSV plus IUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE;Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec FLUVID plus SampleType 1'
        }
        @{
            Assay = 'SARS-CoV-2_Flu_RSV plus RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec FLUVID plus SampleType 0'
        }
        @{
            Assay = 'SARS-CoV-2_Flu_RSV plus RUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE;Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec FLUVID plus SampleType 1'
        }
        @{
            Assay = 'SARS-CoV-2_Flu_RSV_plus'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec FLUVID plus SampleType 0'
        }
        @{
            Assay = 'SARS-CoV-2_Flu_RSV_plus'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE;Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec FLUVID plus SampleType 1'
        }
        @{
            Assay = 'TAP Panel IUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Ft DETECTED;Ba DETECTED;Yp DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec TAP Panel SampleType 1'
        }
        @{
            Assay = 'TAP Panel IUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Ft NOT DETECTED;Ba NOT DETECTED;Yp NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec TAP Panel SampleType 0'
        }
        @{
            Assay = 'TAP Panel RUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Ft DETECTED;Ba DETECTED;Yp DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec TAP Panel SampleType 1'
        }
        @{
            Assay = 'TAP Panel RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Ft NOT DETECTED;Ba NOT DETECTED;Yp NOT DETECTED'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec TAP Panel SampleType 0'
        }
        @{
            Assay = 'XP Flu-RSV RUO'
            Call = 'NEG'
            MatchType = 'EQUALS'
            Pattern = 'Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec FLU RSV SampleType 0'
        }
        @{
            Assay = 'XP Flu-RSV RUO'
            Call = 'POS'
            MatchType = 'EQUALS'
            Pattern = 'Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Spec FLU RSV SampleType 1'
        }
    )
    SampleNumberRules = @(
        @{
            AssayPattern = '*'
            SampleTypeCode = '0'
            BagNoPattern = '^RES$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{3}'
            SampleNumberMin = '1'
            SampleNumberMax = '300'
            SampleNumberPad = '3'
            Enabled = 'TRUE'
            Priority = '9500'
            Note = 'Resample: STC 0, BagNo=RES, 001-300'
        }
        @{
            AssayPattern = '*'
            SampleTypeCode = '1'
            BagNoPattern = '^RES$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{3}'
            SampleNumberMin = '1'
            SampleNumberMax = '300'
            SampleNumberPad = '3'
            Enabled = 'TRUE'
            Priority = '9500'
            Note = 'Resample: STC 1, BagNo=RES, 001-300'
        }
        @{
            AssayPattern = '*'
            SampleTypeCode = '2'
            BagNoPattern = '^RES$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{3}'
            SampleNumberMin = '1'
            SampleNumberMax = '300'
            SampleNumberPad = '3'
            Enabled = 'TRUE'
            Priority = '9500'
            Note = 'Resample: STC 2, BagNo=RES, 001-300'
        }
        @{
            AssayPattern = '*'
            SampleTypeCode = '3'
            BagNoPattern = '^RES$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{3}'
            SampleNumberMin = '1'
            SampleNumberMax = '300'
            SampleNumberPad = '3'
            Enabled = 'TRUE'
            Priority = '9500'
            Note = 'Resample: STC 3, BagNo=RES, 001-300'
        }
        @{
            AssayPattern = '*'
            SampleTypeCode = '4'
            BagNoPattern = '^RES$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{3}'
            SampleNumberMin = '1'
            SampleNumberMax = '300'
            SampleNumberPad = '3'
            Enabled = 'TRUE'
            Priority = '9500'
            Note = 'Resample: STC 4, BagNo=RES, 001-300'
        }
        @{
            AssayPattern = '*'
            SampleTypeCode = '5'
            BagNoPattern = '^RES$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{3}'
            SampleNumberMin = '1'
            SampleNumberMax = '300'
            SampleNumberPad = '3'
            Enabled = 'TRUE'
            Priority = '9500'
            Note = 'Resample: STC 5, BagNo=RES, 001-300'
        }
        @{
            AssayPattern = 'Respiratory Panel IUO'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Respiratory Panel IUO'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '14'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-14'
        }
        @{
            AssayPattern = 'Respiratory Panel IUO'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '15'
            SampleNumberMax = '16'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=15-16'
        }
        @{
            AssayPattern = 'Respiratory Panel IUO'
            SampleTypeCode = '3'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '17'
            SampleNumberMax = '18'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=17-18'
        }
        @{
            AssayPattern = 'Respiratory Panel IUO'
            SampleTypeCode = '4'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '19'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=19-20'
        }
        @{
            AssayPattern = 'TAP Panel IUO'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=01-10'
        }
        @{
            AssayPattern = 'TAP Panel IUO'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-20'
        }
        @{
            AssayPattern = 'TAP Panel IUO'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 00 -> 01-10'
        }
        @{
            AssayPattern = 'Xpert C.difficile BT'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert C.difficile BT'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-20'
        }
        @{
            AssayPattern = 'Xpert C.difficile G3'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert C.difficile G3'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-20'
        }
        @{
            AssayPattern = 'Xpert C.difficile G3'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '18'
            SampleNumberMax = '19'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=18-19'
        }
        @{
            AssayPattern = 'Xpert C.difficile G3'
            SampleTypeCode = '3'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '20'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=20-20'
        }
        @{
            AssayPattern = 'Xpert CT_NG'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert CT_NG'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-20'
        }
        @{
            AssayPattern = 'Xpert CT_NG'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '19'
            SampleNumberMax = '19'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=19-19'
        }
        @{
            AssayPattern = 'Xpert CT_NG'
            SampleTypeCode = '3'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '20'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=20-20'
        }
        @{
            AssayPattern = 'Xpert Ebola EUA'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert Ebola EUA'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '18'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-18'
        }
        @{
            AssayPattern = 'Xpert Ebola EUA'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '19'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=19-20'
        }
        @{
            AssayPattern = 'Xpert GBS LB XC'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert GBS LB XC'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-20'
        }
        @{
            AssayPattern = 'Xpert GBS LB XC'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 00 -> 01-10'
        }
        @{
            AssayPattern = 'Xpert GI Panel'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert GI Panel'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-20'
        }
        @{
            AssayPattern = 'Xpert GI Panel'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 00 -> 01-10'
        }
        @{
            AssayPattern = 'Xpert HBV Viral Load'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert HBV Viral Load'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '18'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-18'
        }
        @{
            AssayPattern = 'Xpert HBV Viral Load'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 00 -> 01-10'
        }
        @{
            AssayPattern = 'Xpert HBV Viral Load'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '19'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=19-20'
        }
        @{
            AssayPattern = 'Xpert HCV PQC'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert HCV PQC'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-20'
        }
        @{
            AssayPattern = 'Xpert HCV PQC'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 00 -> 01-10'
        }
        @{
            AssayPattern = 'Xpert HCV VL Fingerstick'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert HCV VL Fingerstick'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '18'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-18'
        }
        @{
            AssayPattern = 'Xpert HCV VL Fingerstick'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 00 -> 01-10'
        }
        @{
            AssayPattern = 'Xpert HCV VL Fingerstick'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '19'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=19-20'
        }
        @{
            AssayPattern = 'Xpert HIV-1 Qual XC PQC'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert HIV-1 Qual XC PQC'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-20'
        }
        @{
            AssayPattern = 'Xpert HIV-1 Qual XC PQC'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 00 -> 01-10'
        }
        @{
            AssayPattern = 'Xpert HIV-1 Viral Load XC'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert HIV-1 Viral Load XC'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '18'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-18'
        }
        @{
            AssayPattern = 'Xpert HIV-1 Viral Load XC'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 00 -> 01-10'
        }
        @{
            AssayPattern = 'Xpert HIV-1 Viral Load XC'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '19'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=19-20'
        }
        @{
            AssayPattern = 'Xpert HPV HR'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '6'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=01-06'
        }
        @{
            AssayPattern = 'Xpert HPV HR'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '7'
            SampleNumberMax = '18'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 07-18'
        }
        @{
            AssayPattern = 'Xpert HPV HR'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 00 -> 01-10'
        }
        @{
            AssayPattern = 'Xpert HPV HR'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '19'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=19-20'
        }
        @{
            AssayPattern = 'Xpert MRSA NxG'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert MRSA NxG'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '18'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-18'
        }
        @{
            AssayPattern = 'Xpert MRSA NxG'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '19'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=19-20'
        }
        @{
            AssayPattern = 'Xpert MRSA-SA SSTI G3'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert MRSA-SA SSTI G3'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-20'
        }
        @{
            AssayPattern = 'Xpert MTB-RIF Assay G4'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert MTB-RIF Assay G4'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-20'
        }
        @{
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '16'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-16'
        }
        @{
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '17'
            SampleNumberMax = '17'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=17-17'
        }
        @{
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            SampleTypeCode = '3'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '18'
            SampleNumberMax = '18'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=18-18'
        }
        @{
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            SampleTypeCode = '4'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '19'
            SampleNumberMax = '19'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=19-19'
        }
        @{
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            SampleTypeCode = '5'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '20'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=20-20'
        }
        @{
            AssayPattern = 'Xpert MTB-RIF Ultra'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert MTB-RIF Ultra'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '18'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-18'
        }
        @{
            AssayPattern = 'Xpert MTB-RIF Ultra'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '19'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=19-20'
        }
        @{
            AssayPattern = 'Xpert MTB-XDR'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert MTB-XDR'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '18'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-18'
        }
        @{
            AssayPattern = 'Xpert MTB-XDR'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '19'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=19-20'
        }
        @{
            AssayPattern = 'Xpert Norovirus'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert Norovirus'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '18'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-18'
        }
        @{
            AssayPattern = 'Xpert Norovirus'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '19'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=19-20'
        }
        @{
            AssayPattern = 'Xpert SA Nasal Complete G3'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert SA Nasal Complete G3'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-20'
        }
        @{
            AssayPattern = 'Xpert Xpress CoV-2 plus IVD'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert Xpress CoV-2 plus IVD'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-20'
        }
        @{
            AssayPattern = 'Xpert Xpress Flu-RSV'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert Xpress Flu-RSV'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '18'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-18'
        }
        @{
            AssayPattern = 'Xpert Xpress Flu-RSV'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '19'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=19-20'
        }
        @{
            AssayPattern = 'Xpert Xpress GBS'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert Xpress GBS'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-20'
        }
        @{
            AssayPattern = 'Xpert Xpress GBS'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 00 -> 01-10'
        }
        @{
            AssayPattern = 'Xpert Xpress SARS-CoV-2 CE-IVD'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert Xpress SARS-CoV-2 CE-IVD'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-20'
        }
        @{
            AssayPattern = 'Xpert Xpress Strep A'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert Xpress Strep A'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '18'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-18'
        }
        @{
            AssayPattern = 'Xpert Xpress Strep A'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '19'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=19-20'
        }
        @{
            AssayPattern = 'Xpert vanA vanB'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert vanA vanB'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-20'
        }
        @{
            AssayPattern = 'Xpert_Carba-R'
            SampleTypeCode = '0'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '14'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 01-14'
        }
        @{
            AssayPattern = 'Xpert_Carba-R'
            SampleTypeCode = '0'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 00 -> 01-10'
        }
        @{
            AssayPattern = 'Xpert_Carba-R'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '15'
            SampleNumberMax = '18'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=15-18'
        }
        @{
            AssayPattern = 'Xpert_Carba-R'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '19'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=19-20'
        }
        @{
            AssayPattern = 'Xpert_HCV Viral Load'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert_HCV Viral Load'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '18'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-18'
        }
        @{
            AssayPattern = 'Xpert_HCV Viral Load'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 00 -> 01-10'
        }
        @{
            AssayPattern = 'Xpert_HCV Viral Load'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '19'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=19-20'
        }
        @{
            AssayPattern = 'Xpert_HIV-1 Viral Load'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpert_HIV-1 Viral Load'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '18'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-18'
        }
        @{
            AssayPattern = 'Xpert_HIV-1 Viral Load'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9100'
            Note = 'From AssayFam: bag(s) 00 -> 01-10'
        }
        @{
            AssayPattern = 'Xpert_HIV-1 Viral Load'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '19'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=19-20'
        }
        @{
            AssayPattern = 'Xpress Flu IPT_EAT off'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpress Flu IPT_EAT off'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '18'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-18'
        }
        @{
            AssayPattern = 'Xpress Flu IPT_EAT off'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '19'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=19-20'
        }
        @{
            AssayPattern = 'Xpress SARS-CoV-2_Flu_RSV plus'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '1'
            SampleNumberMax = '10'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=11 observed; range=01-10'
        }
        @{
            AssayPattern = 'Xpress SARS-CoV-2_Flu_RSV plus'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = '3'
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = '11'
            SampleNumberMax = '20'
            SampleNumberPad = '2'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'From AssayFam: bags=10 observed; range=11-20'
        }
    )
    SampleIdMarkers = @(
        @{
            AssayPattern = '*'
            MarkerType = 'DelaminationCodeRegex'
            Marker = '^D\d{1,2}[A-Z]?$'
            Enabled = 'TRUE'
            Note = 'Ignore trailing delamination token (e.g., _D2B, _D05, _D11) when evaluating suffix'
            SampleTokenIndex = '-1'
        }
        @{
            AssayPattern = '*'
            MarkerType = 'DelaminationSeparator'
            Marker = '_'
            Enabled = 'TRUE'
            Note = 'Delimiter between base SampleID and delamination token'
            SampleTokenIndex = '-1'
        }
        @{
            AssayPattern = '*'
            MarkerType = 'SuffixChars'
            Marker = 'X|\\+'
            Enabled = 'TRUE'
            Note = 'Valid suffix characters on Base-SampleID (X or +)'
            SampleTokenIndex = '-1'
        }
        @{
            AssayPattern = '*'
            MarkerType = 'SampleTypeCodeTokenIndex'
            Marker = '2'
            Enabled = 'TRUE'
            Note = 'SampleTypeCode is token index 2 (0..5) in Sample ID split by "_"'
            SampleTokenIndex = '2'
        }
        @{
            AssayPattern = '*'
            MarkerType = 'SampleNumberTokenIndex'
            Marker = '3'
            Enabled = 'TRUE'
            Note = 'SampleNumber(+suffix) is token index 3 in Sample ID split by "_"'
            SampleTokenIndex = '3'
        }
    )
    MissingSamplesConfig = @(
        @{
            AssayPattern = '*'
            Bag0SampleMin = '1'
            Bag0SampleMax = '10'
            BagMin = '0'
            BagMax = '10'
            OtherBagSampleMin = '1'
            OtherBagSampleMax = '20'
            SampleNumberPad = '2'
            SampleNumberRegex = '\d+'
            Token_SampleID_SplitIndex = '1'
            Enabled = 'FALSE'
            Priority = '100'
            Notes = 'Default bag/sample expectation (Bag0=1..10; Bags1-10=1..20)'
        }
    )
    SampleExpectationRules = @(
        @{
            Assay = '*'
            SampleIdMatchType = 'REGEX'
            SampleIdPattern = '^[^_]+_[^_]+_0_'
            Expected = 'NEG'
            Enabled = 'TRUE'
            Priority = '9000'
            Note = 'Token2=0 => Negative Control (expected NEG)'
        }
        @{
            Assay = '*'
            SampleIdMatchType = 'REGEX'
            SampleIdPattern = '^[^_]+_[^_]+_[1-5]_'
            Expected = 'POS'
            Enabled = 'TRUE'
            Priority = '8990'
            Note = 'Token2=1-5 => Positive Control (expected POS)'
        }
        @{
            Assay = '*'
            SampleIdMatchType = 'PREFIX'
            SampleIdPattern = 'NEG_'
            Expected = 'NEG'
            Enabled = 'TRUE'
            Priority = '5000'
            Note = 'Legacy: Sample ID starts with NEG_'
        }
        @{
            Assay = '*'
            SampleIdMatchType = 'PREFIX'
            SampleIdPattern = 'POS_'
            Expected = 'POS'
            Enabled = 'TRUE'
            Priority = '4990'
            Note = 'Legacy: Sample ID starts with POS_'
        }
    )
}

<#
   AssayVersionRules = @(
        @{ AssayName='Xpert C.diff Epi'; PartNo='GXCDIFFEPI10'; VersionGX='2'; PFileGX='P0370'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert C.diff Epi'; PartNo='GXCDIFFEPI120'; VersionGX='2'; PFileGX='P0370'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert C.difficile BT'; PartNo='GXCDIFFBTCE10'; VersionGX='1'; PFileGX='P0686'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert C.difficile G2'; PartNo='GXCDIFFICILE10'; VersionGX='2'; PFileGX='P0303'; VersionINF='20'; PFileINF='P0313' }
        @{ AssayName='Xpert C.difficile G2'; PartNo='GXCDIFFICILE120'; VersionGX='2'; PFileGX='P0303'; VersionINF='20'; PFileINF='P0313' }
        @{ AssayName='Xpert C.difficile G3'; PartNo='GXCDIFFICLECE10'; VersionGX='4'; PFileGX='P0366'; VersionINF='24'; PFileINF='P0368' }
        @{ AssayName='Xpert C.difficile G3'; PartNo='GXCDIFFICILECN10'; VersionGX='4'; PFileGX='P0366'; VersionINF='24'; PFileINF='P0368' }
        @{ AssayName='Xpert C.difficile G3'; PartNo='GXCDIFFICILEJP10'; VersionGX='4'; PFileGX='P0366'; VersionINF='24'; PFileINF='P0368' }
        @{ AssayName='Xpert CT_CE'; PartNo='GXCTCE10'; VersionGX='3'; PFileGX='P0527'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert CT  NG  CT_NG'; PartNo='GXCTNG10'; VersionGX='3'; PFileGX='P0561'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert CT  NG  CT_NG'; PartNo='GXCTNG120'; VersionGX='3'; PFileGX='P0561'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert CT  NG  CT_NG'; PartNo='GXCTNGCE10'; VersionGX='3'; PFileGX='P0561'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert CT  NG  CT_NG'; PartNo='GXCTNGCE120'; VersionGX='3'; PFileGX='P0561'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert CT  NG  CT_NG'; PartNo='GXCTNGXCE10'; VersionGX='3'; PFileGX='P0561'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert CT  NG  CT_NG'; PartNo='GXCTNGXCE120'; VersionGX='3'; PFileGX='P0561'; VersionINF=''; PFileINF='' }
        @{ AssayName='Ebola RUO'; PartNo='REBOLA50'; VersionGX='2'; PFileGX='P0644'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Ebola EUA'; PartNo='GXEBOLA10'; VersionGX='2'; PFileGX='P0648'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Ebola CE IVD'; PartNo='GXEBOLACE10'; VersionGX='2'; PFileGX='P0664'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Ebola CE IVD'; PartNo='GXEBOLACE50'; VersionGX='2'; PFileGX='P0664'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Flu CE IVD'; PartNo='GXFLUCE10'; VersionGX='7'; PFileGX='P0525'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpress GBS RUO'; PartNo='9000850'; VersionGX='3'; PFileGX='P0910'; VersionINF=''; PFileINF='' }
        @{ AssayName='GBS LB RUO'; PartNo='9000860'; VersionGX='3'; PFileGX='P0911'; VersionINF=''; PFileINF='' }
        @{ AssayName='GBS LB XC IUO'; PartNo='9000868'; VersionGX='2'; PFileGX='P0935'; VersionINF=''; PFileINF='' }
        @{ AssayName='GBS LB RUO'; PartNo='9000901'; VersionGX='3'; PFileGX='P0911'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert GBS LB XC'; PartNo='GXGBSLBXC10'; VersionGX='2'; PFileGX='P0990'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert GBS LB XC'; PartNo='GXGBSLBXC120'; VersionGX='2'; PFileGX='P0990'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Xpress GBS USIVD'; PartNo='XPRSGBS10'; VersionGX='2'; PFileGX='P1110'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Xpress GBS RUO'; PartNo='RXPRSGBS10'; VersionGX='2'; PFileGX='P1025'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Xpress GBS'; PartNo='XPRSGBSCE10'; VersionGX='1'; PFileGX='P1026'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpress GBS IUO'; PartNo='9000849'; VersionGX='2'; PFileGX='P0945'; VersionINF=''; PFileINF='' }
        @{ AssayName='HBV VL RUO'; PartNo='9000783 (RUO)'; VersionGX='5'; PFileGX='P0673'; VersionINF=''; PFileINF='' }
        @{ AssayName='HBV VL IUO'; PartNo='9000581 (IUO)'; VersionGX='4'; PFileGX='P0680'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert HBV Viral Load'; PartNo='GXHBVVLCE10'; VersionGX='1'; PFileGX='P0835'; VersionINF=''; PFileINF='' }
        @{ AssayName='HCV Viral Load RUO'; PartNo='RHCV10'; VersionGX='1'; PFileGX='P0776'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert HCV Viral Load'; PartNo='GXHCVVLCE10'; VersionGX='1'; PFileGX='P0762'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert HCV Viral Load'; PartNo='GXHCVVLIN10'; VersionGX='1'; PFileGX='P0762'; VersionINF=''; PFileINF='' }
        @{ AssayName='HCV VL WB RUO'; PartNo='RHCVFS10'; VersionGX='3'; PFileGX='P0729'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert HCV VL Fingerstick'; PartNo='GXHCVFSCE10'; VersionGX='1'; PFileGX='P0771'; VersionINF=''; PFileINF='' }
        @{ AssayName='HCV VL WB IUO'; PartNo='9000774 (IUO)'; VersionGX='1'; PFileGX='P0769'; VersionINF=''; PFileINF='' }
        @{ AssayName='HIV1 Qual RUO'; PartNo='7004005RHIVQ10'; VersionGX='1'; PFileGX='P0775'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert HIV1 Qual'; PartNo='7004369GXHIVQACE10'; VersionGX='2'; PFileGX='P0755'; VersionINF=''; PFileINF='' }
        @{ AssayName='HIV1 Qual XC DBS RUO  WB RUO'; PartNo='7006098HIV1 QUAL XC RUO'; VersionGX='4'; PFileGX='P0900'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert HIV1 Qual XC PQC'; PartNo='7006793 HIV1 QUAL XC, CEIVD'; VersionGX='1'; PFileGX='P0999'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert HIV1 Qual XC PQC RUO'; PartNo='7006911 HIV1 QUAL XC, RUO'; VersionGX='1'; PFileGX='P0998'; VersionINF=''; PFileINF='' }
        @{ AssayName='HIV1 Qual XC DBS IUO  WB IUO'; PartNo='7006137HIV1 QUAL XC IUO'; VersionGX='2'; PFileGX='P0918'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert HIV1 Viral Load'; PartNo='GXHIVVLCE10'; VersionGX='2'; PFileGX='P0753'; VersionINF=''; PFileINF='' }
        @{ AssayName='HIV1 Viral Load RUO'; PartNo='RHIV10'; VersionGX='1'; PFileGX='P0774'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert HIV1 Viral Load'; PartNo='GXHIVVLIN10'; VersionGX='2'; PFileGX='P0753'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert HIV1 Viral Load'; PartNo='GXHIVVLCN10'; VersionGX='2'; PFileGX='P0753'; VersionINF=''; PFileINF='' }
        @{ AssayName='HIV1 Viral Load XC IUO'; PartNo='9000812 (IUO)'; VersionGX='4'; PFileGX='P0862'; VersionINF=''; PFileINF='' }
        @{ AssayName='HIV1 Viral Load XC RUO'; PartNo='9000813 (RUO)'; VersionGX='5'; PFileGX='P0863'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert HPV HR  16_1845  HR 16_1845'; PartNo='GXHPVCE10'; VersionGX='1'; PFileGX='P0546'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert HPV HR  16_1845  HR 16_1845'; PartNo='CGXHPVCE10'; VersionGX='1'; PFileGX='P0546'; VersionINF=''; PFileINF='' }
        @{ AssayName='HPV HR AND GENOTYPE RUA ASSAY'; PartNo='RHPV10'; VersionGX='3'; PFileGX='P0528'; VersionINF=''; PFileINF='' }
        @{ AssayName='HPV Assay IUO'; PartNo='9000559'; VersionGX='1'; PFileGX='P0584'; VersionINF=''; PFileINF='' }
        @{ AssayName='MRSA NxG IUO'; PartNo='9000664'; VersionGX='4'; PFileGX='P0668'; VersionINF=''; PFileINF='' }
        @{ AssayName='MRSA NxG RUO'; PartNo='9000670'; VersionGX='4'; PFileGX='P0667'; VersionINF=''; PFileINF='' }
        @{ AssayName='MRSA NxG RUO'; PartNo='RMRSANXG10'; VersionGX='4'; PFileGX='P0667'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MRSA NxG'; PartNo='GXMRSANXGCE10'; VersionGX='2'; PFileGX='P0716'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MRSA NxG'; PartNo='GXMRSANXGCE120'; VersionGX='2'; PFileGX='P0716'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MRSA NxG'; PartNo='GXMRSANGX10'; VersionGX='2'; PFileGX='P0716'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MRSA NxG'; PartNo='GXMRSANXG120'; VersionGX='2'; PFileGX='P0716'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MRSA _SA_BC'; PartNo='GXMRSASABC10'; VersionGX='1'; PFileGX='P0865'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MRSA SA BC CE'; PartNo='GXMRSASABCCE10'; VersionGX='1'; PFileGX='P0866'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MRSA SA BC G3'; PartNo='GXMRSASABCCE10'; VersionGX='5'; PFileGX='P0354'; VersionINF='25'; PFileINF='P0355' }
        @{ AssayName='Xpert MRSA SA SSTI G3'; PartNo='GXMRSASASSTI10'; VersionGX='5'; PFileGX='P0356'; VersionINF='25'; PFileINF='P0357' }
        @{ AssayName='Xpert MRSA SA SSTI G3'; PartNo='GXMRSASASSTICE'; VersionGX='5'; PFileGX='P0356'; VersionINF='25'; PFileINF='P0357' }
        @{ AssayName='Xpert SA Nasal Complete G3'; PartNo='GXSACOMP10'; VersionGX='5'; PFileGX='P0358'; VersionINF='25'; PFileINF='P0359' }
        @{ AssayName='Xpert SA Nasal Complete G3'; PartNo='GXSACOMP120'; VersionGX='5'; PFileGX='P0358'; VersionINF='25'; PFileINF='P0359' }
        @{ AssayName='Xpert SA Nasal Complete G3'; PartNo='GXSACOMPCE10'; VersionGX='5'; PFileGX='P0358'; VersionINF='25'; PFileINF='P0359' }
        @{ AssayName='MRSA SA ETA'; PartNo='RMRSASAETA'; VersionGX='1'; PFileGX='P0670'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert SA Nasal Complete'; PartNo='GXSACOMPCN10'; VersionGX='5'; PFileGX='P0358'; VersionINF='25'; PFileINF='P0359' }
        @{ AssayName='Xpert SA Nasal Complete'; PartNo='GXSACOMPJP10'; VersionGX='5'; PFileGX='P0358'; VersionINF='25'; PFileINF='P0359' }
        @{ AssayName='Xpert MRSASA BC'; PartNo='GXMRSABCJP10'; VersionGX='2'; PFileGX='P0464'; VersionINF='22'; PFileINF='P0465' }
        @{ AssayName='Xpert MTBRIF Assay G4'; PartNo='CGXMTBRIF10'; VersionGX='6'; PFileGX='P0422'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MTBRIF Assay G4'; PartNo='CGXMTBRIF50'; VersionGX='6'; PFileGX='P0422'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MTBRIF Assay G4'; PartNo='CGXMTBRIFIN50'; VersionGX='6'; PFileGX='P0422'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MTBRIF Assay G4'; PartNo='GXMTBRIF10'; VersionGX='6'; PFileGX='P0422'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MTBRIF Assay G4'; PartNo='GXMTBRIF50'; VersionGX='6'; PFileGX='P0422'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MTBRIF Assay G4'; PartNo='GXMTBRIFIN10'; VersionGX='6'; PFileGX='P0422'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MTBRIF US IVD'; PartNo='GXMTBRIFUS10'; VersionGX='1'; PFileGX='P0531'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MTBRIF Assay G4'; PartNo='7006047'; VersionGX='6'; PFileGX='P0422'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MTBRIF Assay G4'; PartNo='7006082'; VersionGX='6'; PFileGX='P0422'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MTBRIF Assay G4'; PartNo='GXMTBRIFCN10'; VersionGX='6'; PFileGX='P0422'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MTBRIF JP IVD'; PartNo='GXMTBRIFJP10'; VersionGX='1'; PFileGX='P0652'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MTBRIF Ultra'; PartNo='GXMTBRIFULTRA10'; VersionGX='4'; PFileGX='P0833'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MTBRIF Ultra'; PartNo='GXMTBRIFULTRA50'; VersionGX='4'; PFileGX='P0833'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MTBRIF Ultra'; PartNo='7006537'; VersionGX='4'; PFileGX='P0833'; VersionINF=''; PFileINF='' }
        @{ AssayName='MTBRIF Ultra v2 RUO'; PartNo='9000779'; VersionGX='2'; PFileGX='P0792'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert MTBXDR'; PartNo='GXMTBXDR10'; VersionGX='1'; PFileGX='P0965'; VersionINF=''; PFileINF='' }
        @{ AssayName='MTBXDR RUO'; PartNo='PN9000795'; VersionGX='8'; PFileGX='P0851'; VersionINF=''; PFileINF='' }
        @{ AssayName='MTBXDR IUO'; PartNo='PN9000796'; VersionGX='3'; PFileGX='P0871'; VersionINF=''; PFileINF='' }
        @{ AssayName='MTBXDR RUO'; PartNo='RMTBXDR10'; VersionGX='8'; PFileGX='P0851'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Norovirus'; PartNo='GXNOVCE10'; VersionGX='1'; PFileGX='P0583'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Norovirus'; PartNo='GXNOV10'; VersionGX='1'; PFileGX='P0583'; VersionINF=''; PFileINF='' }
        @{ AssayName='SARSCoV2 IUO'; PartNo='9000878 (IUO)'; VersionGX='3'; PFileGX='P0957'; VersionINF=''; PFileINF='' }
        @{ AssayName='SARSCoV2 RUO'; PartNo='9000883 (RUO)'; VersionGX='3'; PFileGX='P0956'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Xpress SARS CoV2'; PartNo='XPRSARSCOV210'; VersionGX='2'; PFileGX='P0958'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert vanA G2'; PartNo='GXVANA10'; VersionGX='2'; PFileGX='P0395'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert vanA vanB'; PartNo='GXVANABCE10'; VersionGX='1'; PFileGX='P0233'; VersionINF='20'; PFileINF='P0297' }
        @{ AssayName='XP Flu RUO  RSV RUO  FluRSV RUO'; PartNo='RXPFLURSV10'; VersionGX='5'; PFileGX='P0703'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Xpress Flu  RSV  FluRSV'; PartNo='XPRSFLURSVCE10'; VersionGX='6'; PFileGX='P0846'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Xpress Flu  RSV  FluRSV'; PartNo='XPRSFLURSVCE120'; VersionGX='6'; PFileGX='P0846'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Xpress Flu  RSV  FluRSV'; PartNo='XPRSFLURSV10'; VersionGX='6'; PFileGX='P0846'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Xpress Flu  RSV  FluRSV'; PartNo='XPRSFLURSVCN10'; VersionGX='6'; PFileGX='P0846'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Xpress Flu  RSV  FluRSV'; PartNo='XPRSFLURSV120'; VersionGX='6'; PFileGX='P0846'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpress Flu IPT EAT off'; PartNo='XPRSFLU10'; VersionGX='3'; PFileGX='P0700'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpress Flu IPT EAT off'; PartNo='XPRSFLU120'; VersionGX='3'; PFileGX='P0700'; VersionINF=''; PFileINF='' }
        @{ AssayName='SARSCoV2_Flu_RSV IUO'; PartNo='9000889 RUO'; VersionGX='5'; PFileGX='P0978'; VersionINF=''; PFileINF='' }
        @{ AssayName='SARSCoV2_Flu_RSV RUO'; PartNo='9000890 IUO'; VersionGX='5'; PFileGX='P0979'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Xpress_SARSCoV2_Flu_RSV'; PartNo='XPCOV2FLURSV10'; VersionGX='5'; PFileGX='P0981'; VersionINF=''; PFileINF='' }
        @{ AssayName='LCE009 Xpress SARSCoV2 plus'; PartNo='HACHSARSCOV2'; VersionGX='1'; PFileGX='P1138'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpress CoV2 plus RUO'; PartNo='PN9000918'; VersionGX='4'; PFileGX='P1051'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpress CoV2 plus IUO'; PartNo='PN9000919'; VersionGX='4'; PFileGX='P1052'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpress CoV2 plus RUO'; PartNo='PN9000997'; VersionGX='4'; PFileGX='P1051'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpress CoV2 plus RUO'; PartNo='PN9001023'; VersionGX='4'; PFileGX='P1051'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Xpress CoV2 plus'; PartNo='XP3SARSCOV210'; VersionGX='1'; PFileGX='P1053'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Xpress CoV2 plus IVD'; PartNo='XP3SARSCOV2GB10'; VersionGX='1'; PFileGX='P1153'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Xpress CoV2 plus IVD'; PartNo='XPRSCOV210'; VersionGX='1'; PFileGX='P1153'; VersionINF=''; PFileINF='' }
        @{ AssayName='SARSCoV2_Flu_RSV plus RUO'; PartNo='PN9000966'; VersionGX='2'; PFileGX='P1055'; VersionINF=''; PFileINF='' }
        @{ AssayName='SARSCoV2_Flu_RSV plus IUO'; PartNo='PN9000967'; VersionGX='2'; PFileGX='P1054'; VersionINF=''; PFileINF='' }
        @{ AssayName='SARSCoV2_Flu_RSV plus RUO'; PartNo='PN9001026'; VersionGX='2'; PFileGX='P1055'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpress SARSCoV2_Flu_RSV plus'; PartNo='XP3COV2FLURSV10'; VersionGX='2'; PFileGX='P1064'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpress SARSCoV2_Flu_RSV plus'; PartNo='XP3COV2FLURSVGB10'; VersionGX='4'; PFileGX='P1159'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpress SARSCoV2 Flu RSV plus'; PartNo='XPRS4PLEX10'; VersionGX='3'; PFileGX='P1124'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert_CarbaR'; PartNo='GXCARBAR10'; VersionGX='1'; PFileGX='P0714'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert CarbaR'; PartNo='GXCARBARCE10'; VersionGX='2'; PFileGX='P0575'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert CarbaR'; PartNo='GXCARBARCE120'; VersionGX='2'; PFileGX='P0575'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert_CarbaR'; PartNo='GXCARBARCN10'; VersionGX='1'; PFileGX='P0714'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert_CarbaR'; PartNo='GXCARBARPCE10'; VersionGX='1'; PFileGX='P0714'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert_CarbaR'; PartNo='GXCARBARPCE120'; VersionGX='1'; PFileGX='P0714'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert_CarbaR'; PartNo='GXCARBARPGB10'; VersionGX='1'; PFileGX='P0714'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert_CarbaR'; PartNo='GXCARBARPGB120'; VersionGX='1'; PFileGX='P0714'; VersionINF=''; PFileINF='' }
        @{ AssayName='CARBAR IUO'; PartNo='PN9000612'; VersionGX='5'; PFileGX='P0574'; VersionINF=''; PFileINF='' }
        @{ AssayName='CarbaR BEU IUO'; PartNo='PN9000659'; VersionGX='1'; PFileGX='P0609'; VersionINF=''; PFileINF='' }
        @{ AssayName='CARBAR RUO'; PartNo='RCARBAR10'; VersionGX='6'; PFileGX='P0569'; VersionINF=''; PFileINF='' }
        @{ AssayName='CarbaR BEU RUO'; PartNo='RCARBARBEU10'; VersionGX='5'; PFileGX='P0608'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Xpress_Strep A'; PartNo='XPRSTREPA10'; VersionGX='3'; PFileGX='P0842'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Xpress_Strep A'; PartNo='XPRSTREPA120'; VersionGX='3'; PFileGX='P0842'; VersionINF=''; PFileINF='' }
        @{ AssayName='Xpert Xpress Strep A'; PartNo='XPRSTREPACE10'; VersionGX='2'; PFileGX='P0694'; VersionINF=''; PFileINF='' }
        
    )
Xpert C.diff-Epi
GXCDIFFBTCE10	Xpert C.difficile BT	P0686
GXCDIFFEPI10	Xpert C.diff-Epi	P0370
GXCDIFFEPI120	Xpert C.diff-Epi	P0370
GXCDIFFICILE10	Xpert-C. difficile G2	P0303
GXCDIFFICILE120	Xpert-C. difficile G2	P0303
GXCDIFFICILECE10	Xpert C.difficile G3	P0366
GXCDIFFICILECN10	Xpert C.difficile G3	P0366
GXCDIFF-JP-10	Xpert C.difficile G3	P0366
GXCARBAR10	Xpert_Carba-R	P0714
GXCARBARCE10	Xpert Carba-R	P0575
GXCARBARCE120	Xpert Carba-R	P0575
GXCARBARCN10	Xpert_Carba-R	P0714
GXCARBARPCE10	Xpert_Carba-R	P0714
GXCARBARPCE120	Xpert_Carba-R	P0714
GXCARBARPGB10	Xpert_Carba-R	P0714
GXCARBARPGB120	Xpert_Carba-R	P0714
PN9000612	CARBA-R IUO	P0574
PN9000659	Carba-R BEU IUO	P0609
RCARBAR10	CARBA-R RUO	P0569
RCARBARBEU10	Carba-R BEU RUO	P0608
GXCTCE10	Xpert CT_CE	P0527
GXCTNG10	Xpert CT_NG	P0561
GXCTNG120	Xpert CT_NG	P0561
GXCTNGCE10	Xpert CT_NG	P0561
GXCTNGCE120	Xpert CT_NG	P0561
GXCTNGCN10	Xpert CT_NG	P0561
GXCTNGCN120	Xpert CT_NG	P0561
GXCTNGGB10	Xpert CT_NG	P0561
GXCTNGGB120	Xpert CT_NG	P0561
GXCTNGXCE10	Xpert CT_NG	P0561
GXCTNGXCE120	Xpert CT_NG	P0561
GXCTNGXGB10	Xpert CT_NG	P0561
GXCTNGXGB120	Xpert CT_NG	P0561
GXCT/NG-JP-10	Xpert CT_NG	P0561
GXEBOLA-10	Xpert Ebola EUA	P0648
GXEBOLA-CE-10	Xpert Ebola CE-IVD	P0664
GXEBOLA-CE-50	Xpert Ebola CE-IVD	P0664
REBOLA-50	Ebola RUO	P0644

#>