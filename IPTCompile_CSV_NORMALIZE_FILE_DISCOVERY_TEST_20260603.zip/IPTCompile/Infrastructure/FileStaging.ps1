﻿function Test-FileLocked {
    param([Parameter(Mandatory=$true)][string]$Path)
    # B1: Primärt ReadWrite; fallback till Read vid read-only share
    try {
        $fs = [IO.File]::Open($Path, 'Open', 'ReadWrite', 'None')
        $fs.Close()
        return $false
    } catch [System.UnauthorizedAccessException] {
        # Read-only share: filen är inte "låst" av annan process
        try {
            $fs = [IO.File]::Open($Path, 'Open', 'Read', 'None')
            $fs.Close()
            return $false
        } catch { return $true }
    } catch {
        return $true
    }
}

function Test-FileWriteLocked {
    param(
        [Parameter(Mandatory=$true)][string]$Path
    )
    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    # Excel skapar ofta en ägar-/låsfil bredvid öppna Office-dokument.
    # Vi testar två vanliga varianter eftersom Office kan skapa olika namnformer.
    try {
        $dir  = Split-Path -LiteralPath $Path -Parent
        $leaf = Split-Path -LiteralPath $Path -Leaf
        $ownerCandidates = New-Object System.Collections.Generic.List[string]
        [void]$ownerCandidates.Add((Join-Path $dir (('~$') + $leaf)))
        if (($leaf + '').Length -gt 2) {
            [void]$ownerCandidates.Add((Join-Path $dir (('~$') + ($leaf.Substring(2)))))
        }
        foreach ($ownerPath in $ownerCandidates) {
            if ($ownerPath -and (Test-Path -LiteralPath $ownerPath)) {
                return $true
            }
        }
    } catch {}
    # För signering räcker inte Read-test.
    # Filen måste vara skrivbar och exklusivt låsbar.
    $fs = $null
    try {
        $fs = [System.IO.File]::Open(
            $Path,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::ReadWrite,
            [System.IO.FileShare]::None
        )
        return $false
    } catch {
        return $true
    } finally {
        try {
            if ($fs) {
                $fs.Close()
                $fs.Dispose()
            }
        } catch {}
    }
}
function Stage-InputFileSnapshot {
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$StageDir,
        [Parameter()][string]$Prefix = ''
    )

    if ([string]::IsNullOrWhiteSpace($Path)) { return $Path }
    if (-not (Test-Path -LiteralPath $Path)) { return $Path }

    # Respektera filer som uttryckligen ska köras från nätverk (t.ex. makron) för att undvika sid-effekter.
    try {
        if (Get-Command Get-ConfigValue -ErrorAction SilentlyContinue) {
            $networkOnly = @(Get-ConfigValue -Name 'NetworkOnlyFileNames' -Default @())
            $leaf = Split-Path $Path -Leaf
            foreach ($n in $networkOnly) {
                if ($n -and ($leaf -ieq ($n + ''))) { return $Path }
            }
        }
    } catch {}

    try {
        if (-not (Test-Path -LiteralPath $StageDir)) {
            New-Item -ItemType Directory -Path $StageDir -Force | Out-Null
        }

        $leaf = Split-Path $Path -Leaf
        $dstLeaf = if ($Prefix) { ($Prefix + '__' + $leaf) } else { $leaf }
        $dst  = Join-Path $StageDir $dstLeaf

        $srcInfo = Get-Item -LiteralPath $Path -ErrorAction Stop
        if (Test-Path -LiteralPath $dst) {
            try {
                $dstInfo = Get-Item -LiteralPath $dst -ErrorAction Stop
                if ($dstInfo.Length -eq $srcInfo.Length -and $dstInfo.LastWriteTimeUtc -eq $srcInfo.LastWriteTimeUtc) {
                    return $dst
                }
            } catch {}
        }

        Gui-Log ("📥 Snapshot → TEMP: {0}" -f $dstLeaf) 'Info' 'PROGRESS'
        Copy-Item -LiteralPath $Path -Destination $dst -Force -ErrorAction Stop
        try { (Get-Item -LiteralPath $dst).LastWriteTimeUtc = $srcInfo.LastWriteTimeUtc } catch {}
        return $dst
    } catch {
        Gui-Log ("⚠️ Arbetskopia misslyckades, använder originalfil: {0}" -f (Split-Path $Path -Leaf)) 'Warn'
        return $Path
    }
}
