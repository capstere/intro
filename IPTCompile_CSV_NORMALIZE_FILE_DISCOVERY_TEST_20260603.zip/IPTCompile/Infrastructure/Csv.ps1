function Read-TestSummaryCsvLines {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    $sr = $null
    try {
        # BOM-aware read. Fallback UTF8 is safe for current GeneXpert exports and preserves legacy ASCII content.
        $sr = New-Object System.IO.StreamReader -ArgumentList $Path, ([System.Text.Encoding]::UTF8), $true
        $list = New-Object System.Collections.Generic.List[string]
        while (($line = $sr.ReadLine()) -ne $null) { [void]$list.Add($line) }
        return @($list.ToArray())
    } catch {
        try { return @(Get-Content -LiteralPath $Path -Encoding Default -ErrorAction Stop) } catch { return @() }
    } finally {
        try { if ($sr) { $sr.Close() } } catch {}
        try { if ($sr) { $sr.Dispose() } } catch {}
    }
}

function Test-PackedCsvLine {
    param([AllowNull()][string]$Line)
    if ($null -eq $Line) { return $false }
    $t = ($Line + '').Trim()
    if ($t.Length -lt 2) { return $false }
    if (-not ($t.StartsWith('"') -and $t.EndsWith('"'))) { return $false }
    $inner = $t.Substring(1, $t.Length - 2)
    return ($inner -match '(?i)\bAssay\b\s*,\s*Assay Version\b|,\s*Sample ID\b|\t\s*Sample ID\b') -or ($inner -match ',')
}

function Expand-PackedCsvLine {
    param([AllowNull()][string]$Line)
    if ($null -eq $Line) { return '' }
    $t = ($Line + '').Trim()
    if ($t.Length -ge 2 -and $t.StartsWith('"') -and $t.EndsWith('"')) {
        $t = $t.Substring(1, $t.Length - 2)
        $t = $t -replace '""','"'
    }
    return $t
}

function Get-CsvDelimiter { param([string]$Path)
    try {
        $lines = Read-TestSummaryCsvLines -Path $Path
        foreach ($raw in @($lines | Select-Object -First 40)) {
            if (-not $raw -or -not ($raw + '').Trim()) { continue }
            $line = if (Test-PackedCsvLine -Line $raw) { Expand-PackedCsvLine -Line $raw } else { $raw }
            $sc = ([regex]::Matches($line, ';')).Count
            $cc = ([regex]::Matches($line, ',')).Count
            $tc = ([regex]::Matches($line, "`t")).Count
            if (($cc + $tc + $sc) -lt 1) { continue }
            if ($cc -ge $sc -and $cc -ge $tc -and $cc -gt 0) { return ',' }
            if ($tc -gt $sc -and $tc -gt 0) { return "`t" }
            if ($sc -gt 0) { return ';' }
        }
        return ','
    } catch {
        Gui-Log "⚠️ Get-CsvDelimiter misslyckades: $($_.Exception.Message)" 'Warn'
        return ','
    }
}

function Get-TestSummaryCsvProfile {
    param(
        [string]$Path,
        [string[]]$Lines
    )
    $lines = @($Lines)
    if ($lines.Count -eq 0 -and $Path) { $lines = @(Read-TestSummaryCsvLines -Path $Path) }
    if (-not $lines -or $lines.Count -eq 0) { return $null }

    $maxScan = [Math]::Min($lines.Count - 1, 30)
    for ($i = 0; $i -le $maxScan; $i++) {
        $raw = $lines[$i]
        if (-not $raw -or -not ($raw + '').Trim()) { continue }
        $fields = ConvertTo-CsvFields -Line $raw -Delimiter ''
        if (-not $fields -or $fields.Count -lt 3) { continue }
        $hasAssay = $false; $hasSample = $false; $hasCart = $false
        foreach ($h0 in $fields) {
            $h = (($h0 + '') -replace '^[\uFEFF]+','').Trim()
            if ($h -ieq 'Assay') { $hasAssay = $true }
            elseif ($h -ieq 'Sample ID' -or $h -ieq 'SampleID') { $hasSample = $true }
            elseif ($h -ieq 'Cartridge S/N') { $hasCart = $true }
        }
        if ($hasAssay -and $hasSample -and $hasCart) {
            $dataStart = $i + 1
            while ($dataStart -lt $lines.Count) {
                $ln = $lines[$dataStart]
                if ($ln -and (($ln + '').Trim().Length -gt 0)) { break }
                $dataStart++
            }
            $profileName = 'Legacy'
            if ((Test-PackedCsvLine -Line $raw) -or $i -eq 8) { $profileName = 'PackedA_Row11' }
            return [pscustomobject]@{
                ProfileName    = $profileName
                HeaderIndex    = $i
                HeaderRow      = $i + 1
                DataStartIndex = $dataStart
                DataStartRow   = $dataStart + 1
                Headers        = @($fields)
            }
        }
    }
    return $null
}

function Test-IsResampleCsv {
    <# Returnerar $true om CSV:n innehåller _RES_ i Sample ID-kolumnen (>= MinHits träffar). #>
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$MinHits = 3
    )

    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    $threshold = [Math]::Max(1, [int]$MinHits)

    try {
        $lines = @(Read-TestSummaryCsvLines -Path $Path)
        $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
        if (-not $profile) { return $false }
        $hdr = @($profile.Headers)

        $sampleIdIdx = 0
        for ($i = 0; $i -lt $hdr.Count; $i++) {
            $h = ($hdr[$i] + '').Trim()
            if ($h -imatch '^Sample\s*ID$' -or $h -ieq 'SampleID' -or $h -imatch '^Sample\s*Id$') {
                $sampleIdIdx = $i
                break
            }
        }

        $resCount = 0
        for ($r = [int]$profile.DataStartIndex; $r -lt $lines.Count; $r++) {
            $line = $lines[$r]
            if (-not $line -or $line.Trim().Length -eq 0) { continue }
            $fields = ConvertTo-CsvFields -Line $line -Delimiter ''
            if (-not $fields -or $fields.Count -le $sampleIdIdx) { continue }
            $sid = ($fields[$sampleIdIdx] + '')
            if ($sid -imatch '_RES_') { $resCount++ }
        }

        return ($resCount -ge $threshold)
    } catch {
        try {
            Gui-Log ("⚠️ Test-IsResampleCsv misslyckades för '{0}': {1}" -f (Split-Path $Path -Leaf), $_.Exception.Message) 'Warn' 'DEBUG'
        } catch {}
        return $false
    }
}


function Resolve-CsvPrimaryAndResample {
    <# Klassificerar 0-2 CSV-filer till Primary + ev. Resample med samma regel som i buildflödet. #>
    param([string[]]$CsvPaths)

    $result = [pscustomobject]@{
        Ok             = $true
        PrimaryCsv     = $null
        ResampleCsv    = $null
        HasResample    = $false
        ErrorMessage   = $null
        WarningMessage = $null
    }

    $paths = @($CsvPaths | Where-Object { $_ -and (($_ + '').Trim().Length -gt 0) })

    if ($paths.Count -eq 0) { return $result }

    if ($paths.Count -eq 1) {
        if (Test-IsResampleCsv -Path $paths[0]) {
            $result.Ok = $false
            $result.ResampleCsv = $paths[0]
            $result.ErrorMessage = '❌ Enbart Resampling-CSV vald. Välj även Primary CSV innan rapport kan skapas.'
            return $result
        }
        $result.PrimaryCsv = $paths[0]
        return $result
    }

    if ($paths.Count -eq 2) {
        $isRes0 = Test-IsResampleCsv -Path $paths[0]
        $isRes1 = Test-IsResampleCsv -Path $paths[1]

        if ($isRes0 -and -not $isRes1) {
            $result.ResampleCsv = $paths[0]
            $result.PrimaryCsv = $paths[1]
        } elseif ($isRes1 -and -not $isRes0) {
            $result.PrimaryCsv = $paths[0]
            $result.ResampleCsv = $paths[1]
        } elseif (-not $isRes0 -and -not $isRes1) {
            $result.Ok = $false
            $result.ErrorMessage = '❌ Du har valt 2 CSV-filer men ingen Resampling CSV-fil. Avmarkera en fil eller välj korrekt Resampling CSV-fil.'
            return $result
        } else {
            $result.PrimaryCsv = $paths[0]
            $result.ResampleCsv = $paths[1]
            $result.WarningMessage = '⚠️ Båda CSV har _RES_ i Sample ID – autoväljer Resampling + Original.'
        }

        $result.HasResample = [bool]$result.ResampleCsv
        return $result
    }

    $result.Ok = $false
    $result.ErrorMessage = ("❌ Du har valt {0} CSV-filer. Välj max 2 (Primary + ev. Resample)." -f $paths.Count)
    return $result
}

function Get-AssayFromCsv { param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    try {
        $lines = @(Read-TestSummaryCsvLines -Path $Path)
        $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
        $startIndex = if ($profile) { [int]$profile.DataStartIndex } else { [Math]::Max(0, [int]$StartRow - 1) }
        for ($i = $startIndex; $i -lt $lines.Count; $i++) {
            $ln = $lines[$i]
            if (-not $ln -or $ln.Trim().Length -eq 0) { continue }
            $f = ConvertTo-CsvFields -Line $ln -Delimiter ''
            if (-not $f -or $f.Length -lt 1) { continue }
            $a = ([string]$f[0]).Trim()
            if ($a -and $a -notmatch '^(?i)\s*assay\s*$') { return $a }
        }
    } catch {
        Gui-Log "⚠️ Kunde inte läsa Assay från CSV: $($_.Exception.Message)" 'Warn'
    }
    return $null
}


function Import-CsvRows { param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    $list  = New-Object System.Collections.Generic.List[object]
    try {
        $lines = @(Read-TestSummaryCsvLines -Path $Path)
        if (-not $lines -or $lines.Count -eq 0) { return @() }
        $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
        $startIndex = if ($profile) { [int]$profile.DataStartIndex } else { [Math]::Max(0, [int]$StartRow - 1) }
        for ($i = $startIndex; $i -lt $lines.Count; $i++) {
            $ln = $lines[$i]
            if (-not $ln -or $ln.Trim().Length -eq 0) { continue }
            $f = ConvertTo-CsvFields -Line $ln -Delimiter ''
            if (-not $f -or ($f -join '').Trim().Length -eq 0) { continue }
            [void]$list.Add($f)
        }
    } catch {
        Gui-Log "⚠️ Kunde inte läsa rader från CSV: $($_.Exception.Message)" 'Warn'
    }
    return @($list.ToArray())
}


function ConvertTo-CsvFields {
    param(
        [Parameter(Mandatory=$true)][AllowEmptyString()][string]$Line,
        [string]$Delimiter
    )
    if ($null -eq $Line) { return @() }

    $lineToParse = $Line + ''
    $packed = Test-PackedCsvLine -Line $lineToParse
    if ($packed) {
        # Ny exportvariant: hela logiska CSV-raden ligger i kolumn A och kan vara omsluten av citattecken.
        # Detta motsvarar Excel: Text to Columns -> Delimited -> Tab + Comma -> General.
        $lineToParse = Expand-PackedCsvLine -Line $lineToParse
    }

    $del = $Delimiter
    if ([string]::IsNullOrWhiteSpace($del)) {
        $cSemi  = 0; $cComma = 0; $cTab = 0
        try { $cSemi  = ([regex]::Matches($lineToParse, ';')).Count } catch {}
        try { $cComma = ([regex]::Matches($lineToParse, ',')).Count } catch {}
        try { $cTab   = ([regex]::Matches($lineToParse, "`t")).Count } catch {}

        # Om raden innehåller TAB är det säkrast att köra samma logik som Text to Columns med både TAB och KOMMA.
        # För klassisk CSV utan TAB används komma som tidigare.
        if ($packed -or ($cTab -gt 0)) { $del = '__TABCOMMA__' }
        elseif ($cSemi -gt $cComma -and $cSemi -gt 0) { $del = ';' }
        else { $del = ',' }
    }

    $fields = New-Object System.Collections.Generic.List[string]
    $sb = New-Object System.Text.StringBuilder
    $inQuotes = $false
    for ($i = 0; $i -lt $lineToParse.Length; $i++) {
        $ch = $lineToParse[$i]
        if ($ch -eq '"') {
            if ($inQuotes -and ($i + 1) -lt $lineToParse.Length -and $lineToParse[$i + 1] -eq '"') {
                [void]$sb.Append('"')
                $i++
                continue
            }
            $inQuotes = -not $inQuotes
            continue
        }

        $isDelim = $false
        if (-not $inQuotes) {
            if ($del -eq '__TABCOMMA__') {
                if ($ch -eq ',' -or $ch -eq "`t") { $isDelim = $true }
            } else {
                if (($ch + '') -eq $del) { $isDelim = $true }
            }
        }

        if ($isDelim) {
            [void]$fields.Add(($sb.ToString()).Trim())
            [void]$sb.Clear()
        } else {
            [void]$sb.Append($ch)
        }
    }
    [void]$fields.Add(($sb.ToString()).Trim())
    return ,@($fields.ToArray())
}

function Join-TestSummaryCsvFields {
    param([object[]]$Fields)
    $parts = New-Object System.Collections.Generic.List[string]
    foreach ($v0 in @($Fields)) {
        $v = ($v0 + '')
        $mustQuote = ($v.IndexOf(',') -ge 0 -or $v.IndexOf('"') -ge 0 -or $v.IndexOf("`t") -ge 0 -or $v.IndexOf("`r") -ge 0 -or $v.IndexOf("`n") -ge 0)
        if ($mustQuote) {
            $v = '"' + ($v.Replace('"','""')) + '"'
        }
        [void]$parts.Add($v)
    }
    return ($parts.ToArray() -join ',')
}

function Normalize-TestSummaryCsvForInternalUse {
    <#
      Normaliserar endast TEMP/snapshot-kopian av nya GeneXpert Test Summary CSV.
      Gammal CSV lämnas orörd. Ny CSV skrivs om till klassiskt internt format:
        rad 8 = header, rad 9 = blank, rad 10+ = data.
      Originalfilen på nätverket ändras aldrig.
    #>
    param(
        [Parameter(Mandatory)][string]$Path,
        [string]$Role = 'CSV'
    )

    $result = [ordered]@{
        Path           = $Path
        Role           = $Role
        Normalized     = $false
        ProfileName    = $null
        HeaderRow      = $null
        DataStartRow   = $null
        Message        = ''
    }

    if (-not (Test-Path -LiteralPath $Path)) {
        $result.Message = 'file not found'
        return [pscustomobject]$result
    }

    $lines = @(Read-TestSummaryCsvLines -Path $Path)
    if (-not $lines -or $lines.Count -eq 0) {
        $result.Message = 'empty file'
        return [pscustomobject]$result
    }

    $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
    if (-not $profile) {
        $result.Message = 'no Test Summary header detected'
        return [pscustomobject]$result
    }

    $result.ProfileName  = $profile.ProfileName
    $result.HeaderRow    = $profile.HeaderRow
    $result.DataStartRow = $profile.DataStartRow

    # Klassisk intern layout: header index 7, blank index 8, data index 9.
    # Om filen redan ligger så lämnas den helt orörd för att inte riskera live-flödet.
    if ([int]$profile.HeaderIndex -eq 7 -and [int]$profile.DataStartIndex -eq 9) {
        $result.Message = 'classic layout - unchanged'
        return [pscustomobject]$result
    }

    $out = New-Object System.Collections.Generic.List[string]

    # Behåll upp till sju informationsrader, men skriv dem som vanlig comma-CSV så nedströms kod får samma typ av fil.
    for ($i = 0; $i -lt 7; $i++) {
        if ($i -lt $lines.Count) {
            $fields = ConvertTo-CsvFields -Line ($lines[$i] + '') -Delimiter ''
            [void]$out.Add((Join-TestSummaryCsvFields -Fields $fields))
        } else {
            [void]$out.Add('')
        }
    }

    # Header på intern rad 8.
    [void]$out.Add((Join-TestSummaryCsvFields -Fields @($profile.Headers)))

    # Blank rad 9.
    [void]$out.Add('')

    # Data från faktisk data-start, splittrat enligt Text to Columns: Tab + Comma.
    for ($r = [int]$profile.DataStartIndex; $r -lt $lines.Count; $r++) {
        $ln = $lines[$r]
        if ([string]::IsNullOrWhiteSpace(($ln + ''))) { continue }
        $fields = ConvertTo-CsvFields -Line ($ln + '') -Delimiter ''
        if (-not $fields -or (($fields -join '').Trim().Length -eq 0)) { continue }
        [void]$out.Add((Join-TestSummaryCsvFields -Fields $fields))
    }

    try {
        # UTF8 med BOM är säkert för Windows PowerShell 5.1 och vår BOM-aware läsare.
        Set-Content -LiteralPath $Path -Value $out.ToArray() -Encoding UTF8 -Force
        $result.Normalized = $true
        $result.Message = ('normalized to classic internal layout from HeaderRow={0}, DataStartRow={1}' -f $profile.HeaderRow, $profile.DataStartRow)
    } catch {
        $result.Message = ('normalization failed: ' + $_.Exception.Message)
    }

    return [pscustomobject]$result
}


function Get-CsvStats {
    param(
        [string]$Path,
        [string[]]$Lines
    )
    $out = [ordered]@{
        TestCount       = 0
        DupCount        = 0
        Duplicates      = @()
        LspValues       = @()
        LspOK           = $null
        InstrumentByType= [ordered]@{}
    }

    $lines = @($Lines)
    if ($lines.Count -eq 1 -and -not $lines[0]) { $lines = @() }
    if ($Path -and (Test-Path -LiteralPath $Path)) {
        $lines = @(Read-TestSummaryCsvLines -Path $Path)
    }
    if ($lines.Count -eq 0) { return [pscustomobject]$out }

    $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
    if (-not $profile) { return [pscustomobject]$out }

    $header = @($profile.Headers)
    function _FindHeaderIndex([string[]]$Names, [int]$DefaultIndex) {
        foreach ($name in $Names) {
            for ($ii = 0; $ii -lt $header.Count; $ii++) {
                if ((($header[$ii] + '').Trim()) -ieq $name) { return $ii }
            }
        }
        return $DefaultIndex
    }

    $idxCart = _FindHeaderIndex @('Cartridge S/N') 3
    $idxLsp  = _FindHeaderIndex @('Reagent Lot ID') 4
    $idxIns  = _FindHeaderIndex @('Instrument S/N') 6

    $cartSnList = New-Object System.Collections.Generic.List[string]
    $lspList    = New-Object System.Collections.Generic.List[string]
    $instrList  = New-Object System.Collections.Generic.List[string]

    for ($r = [int]$profile.DataStartIndex; $r -lt $lines.Count; $r++) {
        $ln = $lines[$r]
        if (-not $ln -or -not $ln.Trim()) { continue }
        $f = ConvertTo-CsvFields -Line $ln -Delimiter ''
        if (-not $f -or $f.Count -lt 7) { continue }
        if ($f.Count -gt $idxCart) { $cartSnList.Add( ($f[$idxCart] + '').Trim() ) }
        if ($f.Count -gt $idxLsp)  { $lspList.Add(    ($f[$idxLsp]  + '').Trim() ) }
        if ($f.Count -gt $idxIns)  { $instrList.Add(  ($f[$idxIns]  + '').Trim() ) }
    }

    $cartSn = $cartSnList | Where-Object { $_ -and $_ -ne '' }
    $out.TestCount = @($cartSn).Count
    $dups = $cartSn | Group-Object | Where-Object { $_.Count -gt 1 }
    if ($dups) {
        $out.DupCount   = @($dups).Count
        $out.Duplicates = @($dups) | ForEach-Object { "$($_.Name) x$($_.Count)" }
    }
    $lspClean = $lspList | ForEach-Object {
        $m = [regex]::Match($_, '(?<!\d)(\d{5})(?!\d)')
        if ($m.Success) { $m.Groups[1].Value } else { $null }
    } | Where-Object { $_ } | Select-Object -Unique
    $out.LspValues = @($lspClean)
    if (@($lspClean).Count -gt 0) {
        $out.LspOK = (@($lspClean).Count -eq 1)
    }
    $lut = @{ '6'='GeneXpert 6-color'; '10'='GeneXpert 10-color'; '16'='Infinity 48s'; 'Infinity'='Infinity 48s' }
    foreach ($ins in ($instrList | Where-Object { $_ })) {
        $t = $null
        if ($lut.ContainsKey($ins)) { $t = $lut[$ins] } else { $t = 'Unknown' }
        if (-not $out.InstrumentByType.Contains($t)) { $out.InstrumentByType[$t] = 0 }
        $out.InstrumentByType[$t] = [int]$out.InstrumentByType[$t] + 1
    }
    return [pscustomobject]$out
}


function Import-CsvRowsStreaming {
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$StartRow = 10,
        [Parameter(Mandatory)][scriptblock]$ProcessRow
    )
    try {
        $lines = @(Read-TestSummaryCsvLines -Path $Path)
        $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
        $startIndex = if ($profile) { [int]$profile.DataStartIndex } else { [Math]::Max(0, [int]$StartRow - 1) }
        for ($i = $startIndex; $i -lt $lines.Count; $i++) {
            $line = $lines[$i]
            if (-not $line -or $line.Trim().Length -eq 0) { continue }
            $fields = ConvertTo-CsvFields -Line $line -Delimiter ''
            if ($fields -and (($fields -join '').Trim().Length -gt 0)) {
                & $ProcessRow -Fields $fields -RowIndex ($i + 1)
            }
        }
    } catch {
        throw
    }
}
