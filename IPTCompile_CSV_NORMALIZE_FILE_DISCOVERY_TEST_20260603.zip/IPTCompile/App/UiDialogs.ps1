﻿# Safe refactor: extracted function definitions from Main.ps1

function Show-StyledInfoDialog {
    <# Visar en snygg info-dialog med SteelBlue header, scrollbar och Stäng-knapp. #>
    param(
        [string]$Title = 'Information',
        [string]$HeaderText = 'Information',
        [string]$Body = '',
        [int]$Width = 580,
        [int]$Height = 480
    )
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text            = $Title
    $dlg.StartPosition   = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox     = $false
    $dlg.MinimizeBox     = $false
    $dlg.Size            = New-Object System.Drawing.Size($Width, $Height)
    $dlg.Font            = New-Object System.Drawing.Font('Segoe UI', 10)

    $pHead = New-Object System.Windows.Forms.Panel
    $pHead.Dock      = 'Top'
    $pHead.Height    = 52
    $pHead.BackColor = [System.Drawing.Color]::SteelBlue
    $lblH = New-Object System.Windows.Forms.Label
    $lblH.Text      = $HeaderText
    $lblH.ForeColor = [System.Drawing.Color]::White
    $lblH.Font      = New-Object System.Drawing.Font('Segoe UI Semibold', 13)
    $lblH.AutoSize  = $false
    $lblH.Dock      = 'Fill'
    $lblH.Padding   = New-Object System.Windows.Forms.Padding(16, 0, 0, 0)
    $lblH.TextAlign = 'MiddleLeft'
    $pHead.Controls.Add($lblH)

    $txt = New-Object System.Windows.Forms.TextBox
    $txt.Dock       = 'Fill'
    $txt.Multiline  = $true
    $txt.ReadOnly   = $true
    $txt.ScrollBars = 'Vertical'
    $txt.BackColor  = [System.Drawing.Color]::White
    $txt.Font       = New-Object System.Drawing.Font('Segoe UI', 10)
    $txt.Text       = $Body

    $pBtn = New-Object System.Windows.Forms.FlowLayoutPanel
    $pBtn.Dock          = 'Bottom'
    $pBtn.Height        = 52
    $pBtn.FlowDirection = 'RightToLeft'
    $pBtn.Padding       = New-Object System.Windows.Forms.Padding(16, 8, 16, 8)
    $pBtn.WrapContents  = $false

    $btnClose = New-Object System.Windows.Forms.Button
    $btnClose.Text         = 'Stäng'
    $btnClose.Width        = 100
    $btnClose.Height       = 34
    $btnClose.Margin       = New-Object System.Windows.Forms.Padding(0)
    $btnClose.DialogResult = [System.Windows.Forms.DialogResult]::OK
    try { Set-AccentButton $btnClose } catch {}
    $pBtn.Controls.Add($btnClose)

    $dlg.AcceptButton = $btnClose
    $dlg.Controls.Add($txt)
    $dlg.Controls.Add($pBtn)
    $dlg.Controls.Add($pHead)
    $dlg.ShowDialog($form) | Out-Null
}

function Show-ListSelectionDialog {
    param(
       [Parameter(Mandatory=$true)][string]$Title,
        [Parameter(Mandatory=$true)][string]$Prompt,
        [Parameter(Mandatory=$true)][string[]]$Items
    )
    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text            = $Title
    $dlg.StartPosition   = 'CenterParent'
    $dlg.Size            = New-Object System.Drawing.Size(520, 420)
    $dlg.MinimumSize     = New-Object System.Drawing.Size(520, 420)
    $dlg.MaximizeBox     = $false
    $dlg.MinimizeBox     = $false
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.Font            = New-Object System.Drawing.Font('Segoe UI', 10)

    $pHead = New-Object System.Windows.Forms.Panel
    $pHead.Dock      = 'Top'
    $pHead.Height    = 52
    $pHead.BackColor = [System.Drawing.Color]::SteelBlue
    $lblH = New-Object System.Windows.Forms.Label
    $lblH.Text      = $Title
    $lblH.ForeColor = [System.Drawing.Color]::White
    $lblH.Font      = New-Object System.Drawing.Font('Segoe UI Semibold', 13)
    $lblH.AutoSize  = $false
    $lblH.Dock      = 'Fill'
    $lblH.Padding   = New-Object System.Windows.Forms.Padding(16, 0, 0, 0)
    $lblH.TextAlign = 'MiddleLeft'
    $pHead.Controls.Add($lblH)

    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text    = $Prompt
    $lbl.Dock    = 'Top'
    $lbl.Height  = 40
    $lbl.Padding = New-Object System.Windows.Forms.Padding(16, 10, 10, 0)

    $list = New-Object System.Windows.Forms.ListBox
    $list.Dock = 'Fill'
    $list.IntegralHeight = $false
    $list.SelectionMode = 'One'
    [void]$list.Items.AddRange($Items)

    $pBtn = New-Object System.Windows.Forms.FlowLayoutPanel
    $pBtn.Dock          = 'Bottom'
    $pBtn.Height        = 52
    $pBtn.FlowDirection = 'RightToLeft'
    $pBtn.Padding       = New-Object System.Windows.Forms.Padding(16, 8, 16, 8)
    $pBtn.WrapContents  = $false

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text         = 'Avbryt'
    $btnCancel.Width        = 90
    $btnCancel.Height       = 34
    $btnCancel.Margin       = New-Object System.Windows.Forms.Padding(0)
    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel

    $btnOk = New-Object System.Windows.Forms.Button
    $btnOk.Text         = 'OK'
    $btnOk.Width        = 90
    $btnOk.Height       = 34
    $btnOk.Margin       = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
    $btnOk.DialogResult = [System.Windows.Forms.DialogResult]::OK
    try { Set-AccentButton $btnOk -Primary } catch {}

    $pBtn.Controls.Add($btnCancel)
    $pBtn.Controls.Add($btnOk)

    $dlg.AcceptButton = $btnOk
    $dlg.CancelButton = $btnCancel

    $dlg.Controls.Add($list)
    $dlg.Controls.Add($pBtn)
    $dlg.Controls.Add($lbl)
    $dlg.Controls.Add($pHead)

    $list.add_DoubleClick({ if ($list.SelectedItem) { $dlg.DialogResult = [System.Windows.Forms.DialogResult]::OK; $dlg.Close() } })

    $res = $dlg.ShowDialog($form)
    if ($res -ne [System.Windows.Forms.DialogResult]::OK) { return $null }
    if (-not $list.SelectedItem) { return $null }
    return [string]$list.SelectedItem
}

function Show-ProjectStatusDialog {
    $data = Get-ProjectStatusData

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text = 'Projektstatus'
    $dlg.StartPosition = 'CenterParent'
    $dlg.Size = New-Object System.Drawing.Size(680, 560)
    $dlg.MinimumSize = New-Object System.Drawing.Size(680, 480)
    $dlg.MaximizeBox = $false
    $dlg.MinimizeBox = $false
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $dlg.BackColor = [System.Drawing.Color]::FromArgb(245, 247, 250)

    # ── Header panel ──
    $pHead = New-Object System.Windows.Forms.Panel
    $pHead.Dock      = 'Top'
    $pHead.Height    = 60
    $pHead.BackColor = [System.Drawing.Color]::SteelBlue
    $lblHead = New-Object System.Windows.Forms.Label
    $lblHead.Text      = [char]0x2611 + '  IPTCompile — Projektstatus'
    $lblHead.ForeColor = [System.Drawing.Color]::White
    $lblHead.Font      = New-Object System.Drawing.Font('Segoe UI Semibold', 14)
    $lblHead.AutoSize  = $false
    $lblHead.Dock      = 'Fill'
    $lblHead.Padding   = New-Object System.Windows.Forms.Padding(16, 0, 0, 0)
    $lblHead.TextAlign = 'MiddleLeft'
    $pHead.Controls.Add($lblHead)

    $lastUpdated = (($data.LastUpdated + '')).Trim()
    if (-not $lastUpdated) { $lastUpdated = '-' }
    $lblDate = New-Object System.Windows.Forms.Label
    $lblDate.Text      = "Uppdaterad $lastUpdated"
    $lblDate.ForeColor = [System.Drawing.Color]::FromArgb(200, 215, 235)
    $lblDate.Font      = New-Object System.Drawing.Font('Segoe UI', 9)
    $lblDate.AutoSize  = $true
    $lblDate.Location  = New-Object System.Drawing.Point(($dlg.ClientSize.Width - 180), 38)
    $lblDate.Anchor    = 'Right'
    $pHead.Controls.Add($lblDate)

    # ── Scroll panel ──
    $scroll = New-Object System.Windows.Forms.Panel
    $scroll.Dock       = 'Fill'
    $scroll.AutoScroll = $true
    $scroll.Padding    = New-Object System.Windows.Forms.Padding(24, 16, 24, 16)

    $innerPanel = New-Object System.Windows.Forms.FlowLayoutPanel
    $innerPanel.FlowDirection = 'TopDown'
    $innerPanel.WrapContents  = $false
    $innerPanel.AutoSize      = $true
    $innerPanel.AutoSizeMode  = 'GrowAndShrink'
    $innerPanel.Width         = ($dlg.ClientSize.Width - 60)
    $innerPanel.Anchor        = 'Left,Right,Top'

    $nl = [Environment]::NewLine
    $cardWidth = ($dlg.ClientSize.Width - 80)

    # ── Helper: skapa en sektion ──
    function New-StatusCard {
        param([string]$Title, [string]$Emoji, [System.Drawing.Color]$AccentColor, [string[]]$Items)
        $card = New-Object System.Windows.Forms.Panel
        $card.Width     = $cardWidth
        $card.BackColor = [System.Drawing.Color]::White
        $card.Padding   = New-Object System.Windows.Forms.Padding(0)
        $card.Margin    = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)

        # Accent strip left
        $strip = New-Object System.Windows.Forms.Panel
        $strip.Dock      = 'Left'
        $strip.Width     = 5
        $strip.BackColor = $AccentColor

        # Title
        $lblT = New-Object System.Windows.Forms.Label
        $lblT.Dock      = 'Top'
        $lblT.Height    = 32
        $lblT.Text      = "  $Emoji  $Title"
        $lblT.Font      = New-Object System.Drawing.Font('Segoe UI Semibold', 10.5)
        $lblT.ForeColor = $AccentColor
        $lblT.TextAlign = 'MiddleLeft'
        $lblT.Padding   = New-Object System.Windows.Forms.Padding(8, 0, 0, 0)

        # Items
        $lblItems = New-Object System.Windows.Forms.Label
        $lblItems.Dock     = 'Top'
        $lblItems.AutoSize = $false
        $lblItems.Padding  = New-Object System.Windows.Forms.Padding(20, 0, 8, 8)
        $lblItems.Font     = New-Object System.Drawing.Font('Segoe UI', 9.5)
        $lblItems.ForeColor = [System.Drawing.Color]::FromArgb(60, 60, 70)

        $itemLines = @()
        foreach ($it in $Items) {
            $itemLines += [char]0x2022 + "  $it"
        }
        if ($itemLines.Count -eq 0) { $itemLines = @('Inget inlagt.') }
        $lblItems.Text   = ($itemLines -join $nl)
        $lblItems.Height = [Math]::Max(24, ($itemLines.Count * 22) + 8)

        $card.Height = $lblT.Height + $lblItems.Height + 4
        $card.Controls.Add($lblItems)
        $card.Controls.Add($lblT)
        $card.Controls.Add($strip)
        return $card
    }

    $done    = @($data.Done)
    $ongoing = @($data.Ongoing)
    $todo    = @($data.Todo)
    $notes   = @($data.Notes)

    $cardDone    = New-StatusCard -Title 'Klart'     -Emoji ([string][char]0x2705) -AccentColor ([System.Drawing.Color]::FromArgb(40, 160, 80))  -Items $done
    $cardOngoing = New-StatusCard -Title 'Pågår'     -Emoji ([string][char]0x21BB) -AccentColor ([System.Drawing.Color]::FromArgb(50, 130, 200)) -Items $ongoing
    $cardTodo    = New-StatusCard -Title 'Att göra'  -Emoji ([string][char]0x2610) -AccentColor ([System.Drawing.Color]::FromArgb(200, 150, 40)) -Items $todo

    $innerPanel.Controls.Add($cardDone)
    $innerPanel.Controls.Add($cardOngoing)
    $innerPanel.Controls.Add($cardTodo)

    if ($notes.Count -gt 0) {
        $cardNotes = New-StatusCard -Title 'Notering' -Emoji ([string][char]0x25C6) -AccentColor ([System.Drawing.Color]::FromArgb(140, 140, 150)) -Items $notes
        $innerPanel.Controls.Add($cardNotes)
    }

    $scroll.Controls.Add($innerPanel)

    # ── Button panel ──
    $pBtn = New-Object System.Windows.Forms.FlowLayoutPanel
    $pBtn.Dock          = 'Bottom'
    $pBtn.Height        = 52
    $pBtn.FlowDirection = 'RightToLeft'
    $pBtn.Padding       = New-Object System.Windows.Forms.Padding(16, 8, 16, 8)
    $pBtn.WrapContents  = $false
    $pBtn.BackColor     = $dlg.BackColor

    $btnClose = New-Object System.Windows.Forms.Button
    $btnClose.Text     = 'Stäng'
    $btnClose.Width    = 100
    $btnClose.Height   = 34
    $btnClose.Margin   = New-Object System.Windows.Forms.Padding(0)
    $btnClose.DialogResult = [System.Windows.Forms.DialogResult]::OK
    try { Set-AccentButton $btnClose } catch {}
    $pBtn.Controls.Add($btnClose)

    $dlg.AcceptButton = $btnClose
    $dlg.Controls.Add($scroll)
    $dlg.Controls.Add($pBtn)
    $dlg.Controls.Add($pHead)
    $dlg.ShowDialog($form) | Out-Null
}

function Show-FileMoveSelectionDialog {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Title,
        [Parameter(Mandatory=$true)][string]$Prompt,
        [Parameter(Mandatory=$true)][System.IO.FileInfo[]]$Files,
        [Parameter(Mandatory=$false)][string[]]$DefaultCheckedExtensions = @('.csv','.xlsx','.xlsm','.pdf')
    )

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text            = $Title
    $dlg.StartPosition   = 'CenterParent'
    $dlg.Size            = New-Object System.Drawing.Size(780, 520)
    $dlg.MinimumSize     = New-Object System.Drawing.Size(780, 520)
    $dlg.MaximizeBox     = $false
    $dlg.MinimizeBox     = $false
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.Font            = New-Object System.Drawing.Font('Segoe UI', 10)

    $pHead = New-Object System.Windows.Forms.Panel
    $pHead.Dock      = 'Top'
    $pHead.Height    = 52
    $pHead.BackColor = [System.Drawing.Color]::SteelBlue
    $lblH = New-Object System.Windows.Forms.Label
    $lblH.Text      = $Title
    $lblH.ForeColor = [System.Drawing.Color]::White
    $lblH.Font      = New-Object System.Drawing.Font('Segoe UI Semibold', 13)
    $lblH.AutoSize  = $false
    $lblH.Dock      = 'Fill'
    $lblH.Padding   = New-Object System.Windows.Forms.Padding(16, 0, 0, 0)
    $lblH.TextAlign = 'MiddleLeft'
    $pHead.Controls.Add($lblH)

    $lbl = New-Object System.Windows.Forms.Label
    $lbl.Text = $Prompt
    $lbl.Dock = 'Top'
    $lbl.Height = 54
    $lbl.Padding = New-Object System.Windows.Forms.Padding(10,10,10,0)

    $clb = New-Object System.Windows.Forms.CheckedListBox
    $clb.Dock = 'Fill'
    $clb.IntegralHeight = $false
    $clb.CheckOnClick = $true
    $clb.DisplayMember = 'Display'

    # Bygg items med tydlig rad: filnamn + datum + storlek
    $items = New-Object System.Collections.Generic.List[object]
    foreach ($f in ($Files | Sort-Object LastWriteTime -Descending)) {
       $ts = ''
        try { $ts = $f.LastWriteTime.ToString('yyyy-MM-dd HH:mm') } catch { $ts = '' }
        $kb = ''
        try { $kb = [Math]::Round(($f.Length / 1KB),0) } catch { $kb = '' }
        $items.Add([pscustomobject]@{
            File    = $f
            Display = ("{0}    ({1}, {2} KB)" -f $f.Name, $ts, $kb)
        })
    }
    [void]$clb.Items.AddRange($items.ToArray())

    # Default-check: endast "säkra" filtyper (användaren kan checka i fler)
    $defaultExt = @($DefaultCheckedExtensions | ForEach-Object { (''+$_).ToLowerInvariant() })
    for ($i=0; $i -lt $clb.Items.Count; $i++) {
        try {
            $it = $clb.Items[$i]
            $ext = ''
            try { $ext = [string]$it.File.Extension } catch { $ext = '' }
            $isDefault = $false
            if ($ext) { $isDefault = $defaultExt -contains $ext.ToLowerInvariant() }
            $clb.SetItemChecked($i, $isDefault)
        } catch {}
    }

    # Knapp-panel: vänster (Markera/Avmarkera) + höger (Flytta/Avbryt)
    $panelBtns = New-Object System.Windows.Forms.Panel
    $panelBtns.Dock   = 'Bottom'
    $panelBtns.Height = 56

    $flowLeft = New-Object System.Windows.Forms.FlowLayoutPanel
    $flowLeft.Dock          = 'Left'
    $flowLeft.FlowDirection = 'LeftToRight'
    $flowLeft.Padding       = New-Object System.Windows.Forms.Padding(8, 8, 0, 8)
    $flowLeft.WrapContents  = $false
    $flowLeft.AutoSize      = $true

    $flowRight = New-Object System.Windows.Forms.FlowLayoutPanel
    $flowRight.Dock          = 'Right'
    $flowRight.FlowDirection = 'RightToLeft'
    $flowRight.Padding       = New-Object System.Windows.Forms.Padding(0, 8, 16, 8)
    $flowRight.WrapContents  = $false
    $flowRight.AutoSize      = $true

    $btnAll = New-Object System.Windows.Forms.Button
    $btnAll.Text   = 'Markera alla'
    $btnAll.Width  = 120
    $btnAll.Height = 34
    $btnAll.Margin = New-Object System.Windows.Forms.Padding(0, 0, 6, 0)

    $btnNone = New-Object System.Windows.Forms.Button
    $btnNone.Text   = 'Avmarkera alla'
    $btnNone.Width  = 140
    $btnNone.Height = 34
    $btnNone.Margin = New-Object System.Windows.Forms.Padding(0)

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text         = 'Avbryt'
    $btnCancel.Width        = 100
    $btnCancel.Height       = 34
    $btnCancel.Margin       = New-Object System.Windows.Forms.Padding(0)
    $btnCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel

    $btnOk = New-Object System.Windows.Forms.Button
    $btnOk.Text         = 'Flytta valda'
    $btnOk.Width        = 120
    $btnOk.Height       = 34
    $btnOk.Margin       = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
    $btnOk.DialogResult = [System.Windows.Forms.DialogResult]::OK
    try { Set-AccentButton $btnOk -Primary } catch {}

    $flowLeft.Controls.Add($btnAll)
    $flowLeft.Controls.Add($btnNone)
    $flowRight.Controls.Add($btnCancel)
    $flowRight.Controls.Add($btnOk)
    $panelBtns.Controls.Add($flowLeft)
    $panelBtns.Controls.Add($flowRight)

    $dlg.AcceptButton = $btnOk
    $dlg.CancelButton = $btnCancel

    $btnAll.Add_Click({
        for ($i=0; $i -lt $clb.Items.Count; $i++) { try { $clb.SetItemChecked($i, $true) } catch {} }
    })
    $btnNone.Add_Click({
        for ($i=0; $i -lt $clb.Items.Count; $i++) { try { $clb.SetItemChecked($i, $false) } catch {} }
    })

    $dlg.Controls.Add($clb)
    $dlg.Controls.Add($panelBtns)
    $dlg.Controls.Add($lbl)
    $dlg.Controls.Add($pHead)

    $res = $dlg.ShowDialog($form)
    if ($res -ne [System.Windows.Forms.DialogResult]::OK) { return $null }

    $selected = New-Object System.Collections.Generic.List[System.IO.FileInfo]
    foreach ($obj in $clb.CheckedItems) {
        try { if ($obj -and $obj.File) { $selected.Add([System.IO.FileInfo]$obj.File) } } catch {}
    }
    return @($selected)
}

function Show-CloseFileToContinueDialog {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [string]$ExtraHint = ''
    )

    $leaf = $Path
    try { $leaf = Split-Path $Path -Leaf } catch {}

    $msg = "Stäng fil:`n`n$leaf`n`nFör att fortsätta."
    if ($ExtraHint) { $msg += "`n`nTips: $ExtraHint" }

   try {
        return [System.Windows.Forms.MessageBox]::Show(
            $msg,
            'Filen är öppen',
            [System.Windows.Forms.MessageBoxButtons]::RetryCancel,
            [System.Windows.Forms.MessageBoxIcon]::Warning
        )
    } catch {
        return [System.Windows.Forms.DialogResult]::Cancel
    }
}

function Ensure-FilesClosedOrCancel {
    param(
        [Parameter(Mandatory=$true)][string[]]$Paths,
        [string]$Hint = 'Om filen inte är öppen i Excel: stäng förhandsvisning i Explorer, eller OneDrive/Preview som kan låsa filen.'
    )

    $clean = @($Paths | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique)
    if (-not $clean -or $clean.Count -eq 0) { return $true }

    while ($true) {
        $locked = $null
        foreach ($p in $clean) {
            try {
                if (Test-FileLocked $p) { $locked = $p; break }
            } catch {}
        }

        if (-not $locked) { return $true }

        $res = Show-CloseFileToContinueDialog -Path $locked -ExtraHint $Hint
        if ($res -ne [System.Windows.Forms.DialogResult]::Retry) { return $false }
        Start-Sleep -Milliseconds 200
    }
}

function Ensure-SignatureFilesClosedOrCancel {
    param(
        [Parameter(Mandatory=$true)][string[]]$Paths,
        [string]$Hint = 'Stäng filen i Excel. Stäng även eventuell förhandsvisning i Explorer. Signering kan inte göras mot en öppen eller låst fil.'
    )
    $clean = @($Paths | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique)
    if (-not $clean -or $clean.Count -eq 0) { return $true }
    while ($true) {
        $locked = $null
        foreach ($p in $clean) {
            try {
                if (Test-FileWriteLocked $p) {
                    $locked = $p
                    break
                }
            } catch {
                $locked = $p
                break
            }
        }
        if (-not $locked) { return $true }
        $res = Show-CloseFileToContinueDialog -Path $locked -ExtraHint $Hint
        if ($res -ne [System.Windows.Forms.DialogResult]::Retry) {
            return $false
        }
        Start-Sleep -Milliseconds 300
    }
}
