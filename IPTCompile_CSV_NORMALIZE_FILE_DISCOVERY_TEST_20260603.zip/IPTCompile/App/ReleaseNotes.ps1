﻿# Extracted from Main.ps1 during high-risk refactor.
# Intent: keep Main.ps1 as orchestration/UI and move reusable helpers into focused modules.

function Get-ReleaseNotesCachePath {
    try {
        $base = [Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)
        if ([string]::IsNullOrWhiteSpace($base)) { $base = $env:TEMP }
        $dir = Join-Path $base 'IPTCompile'
        if (-not (Test-Path -LiteralPath $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
        }
        return (Join-Path $dir 'last_release_notes_version.txt')
    } catch {
        return (Join-Path $env:TEMP 'IPTCompile_last_release_notes_version.txt')
    }
}

function Get-ReleaseNotesForVersion {
    param(
        [string]$Version,
        [string]$RootPath
    )
    if ([string]::IsNullOrWhiteSpace($Version)) { return '' }
    $notesPath = Join-Path $RootPath 'ReleaseNotes.psd1'
    if (-not (Test-Path -LiteralPath $notesPath)) { return '' }
    try {
        $map = Import-PowerShellDataFile -Path $notesPath
        if (-not $map) { return '' }
        $key = $Version.Trim()
        if (-not $map.ContainsKey($key)) { return '' }
        $notes = $map[$key]
        if ($notes -is [array]) {
            return (($notes | ForEach-Object { '' + $_ }) -join [Environment]::NewLine)
        }
        return ('' + $notes).Trim()
    } catch {
        try { Gui-Log ("⚠️ Kunde inte läsa ReleaseNotes.psd1: " + $_.Exception.Message) 'Warn' } catch {}
        return ''
    }
}

function Show-ReleaseNotesIfNewVersion {
    param(
        [string]$Version,
        [string]$RootPath
    )
    if ([string]::IsNullOrWhiteSpace($Version)) { return }
    $notes = Get-ReleaseNotesForVersion -Version $Version -RootPath $RootPath
    if ([string]::IsNullOrWhiteSpace($notes)) { return }
    $cachePath = Get-ReleaseNotesCachePath
    $seen = ''
    try {
        if (Test-Path -LiteralPath $cachePath) {
            $seen = ((Get-Content -LiteralPath $cachePath -Raw -ErrorAction Stop) + '').Trim()
        }
    } catch {
        $seen = ''
    }
    if ($seen -eq $Version.Trim()) { return }
    try {
        Show-StyledInfoDialog `
            -Title "Ny version - visas endast när skriptet uppdaterats" `
            -HeaderText ("Ny version – " + $Version) `
            -Body $notes `
            -Width 620 `
            -Height 460
        Set-Content -LiteralPath $cachePath -Value $Version.Trim() -Encoding UTF8
    } catch {
        try { Gui-Log ("⚠️ Kunde inte visa versionsnyheter: " + $_.Exception.Message) 'Warn' } catch {}
    }
}

