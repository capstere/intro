﻿# Build phase: Report watermark and tab colors
# Extracted/split during HIGH_RISK_REFACTOR_PASS5.

# ============================
# === Rubrik-vattenstämpel ===
# ============================
try {
    foreach ($ws in $pkgOut.Workbook.Worksheets) {
        try {
            $ws.HeaderFooter.OddHeader.CenteredText   = '&"Arial,Bold"&14 UNCONTROLLED'
            $ws.HeaderFooter.EvenHeader.CenteredText  = '&"Arial,Bold"&14 UNCONTROLLED'
            $ws.HeaderFooter.FirstHeader.CenteredText = '&"Arial,Bold"&14 UNCONTROLLED'
        } catch {
            Gui-Log ("⚠️ Kunde inte sätta header på blad: " + $ws.Name) 'Warn'
        }
    }
} catch {
    Gui-Log "⚠️ Fel vid vattenstämpling av rapporten." 'Warn'
}

        # ============================
        # === Flikfärger (före sparning)
        # ============================
        try {
            $wsT = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo];     if ($wsT) { $wsT.TabColor = [System.Drawing.Color]::FromArgb(255, 52, 152, 219) }
            $wsT = $pkgOut.Workbook.Worksheets[$Layout.SheetUtrustning];     if ($wsT) { $wsT.TabColor = [System.Drawing.Color]::FromArgb(255, 33, 115, 70) }
        } catch {
        Gui-Log "⚠️ Kunde inte sätta tab-färg: $($_.Exception.Message)" 'Warn'
    }

        #endregion Build: Output-flikar

        #region Build: Spara rapport och revision
