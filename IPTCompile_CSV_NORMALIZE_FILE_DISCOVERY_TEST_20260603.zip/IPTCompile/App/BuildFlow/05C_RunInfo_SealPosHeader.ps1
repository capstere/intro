﻿# Build phase: Run Information Seal Test POS header block
# PASS6: simplified to shared Run Information helper.

        Write-RunInfoSealHeaderBlock `
            -WsInfo $wsInfo `
            -FilePath $selPos `
            -Header $headerPos `
            -FileRow $rowPosFile `
            -DocRow $rowPosDoc `
            -RevRow $rowPosRev `
            -EffRow $rowPosEff `
            -StyleMatchCell $StyleMatchCell `
            -StyleMismatchCell $StyleMismatchCell

