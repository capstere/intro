﻿# Build phase: Run Information Seal Test NEG header block
# PASS6: simplified to shared Run Information helper.

        $sealMergedMode = $false
        try { $sealMergedMode = Test-SealTestMergedMode } catch { $sealMergedMode = $false }
        if ($sealMergedMode) {
            try { $wsInfo.Cells["B$rowNegFile"].Value = 'N/A (Merged)' } catch {}
            try { $wsInfo.Cells["B$rowNegDoc"].Value = '' } catch {}
            try { $wsInfo.Cells["B$rowNegRev"].Value = '' } catch {}
            try { $wsInfo.Cells["B$rowNegEff"].Value = '' } catch {}
        } else {
            Write-RunInfoSealHeaderBlock `
                -WsInfo $wsInfo `
                -FilePath $selNeg `
                -Header $headerNeg `
                -FileRow $rowNegFile `
                -DocRow $rowNegDoc `
                -RevRow $rowNegRev `
                -EffRow $rowNegEff `
                -StyleMatchCell $StyleMatchCell `
                -StyleMismatchCell $StyleMismatchCell
        }

    } catch {
        Gui-Log ("⚠️ Header summary fel: " + $_.Exception.Message) 'Warn'
    }

} catch {
    Gui-Log "⚠️ Run Information fel: $($_.Exception.Message)" 'Warn'
}

