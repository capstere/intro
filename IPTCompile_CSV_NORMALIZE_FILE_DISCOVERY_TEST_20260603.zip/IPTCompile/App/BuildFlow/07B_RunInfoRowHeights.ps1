﻿# Build phase: Run Information row-height polish and Sample Reagent highlight
# PASS6: simplified to shared Run Information helpers.

# ============================================================
# === Run Information: fasta radhöjder vänsterpanel        ===
# ============================================================
try {
    $wsRI = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if ($wsRI) {
        Set-RunInformationLeftPanelRowHeights -Ws $wsRI
    }
} catch {
    Gui-Log "⚠️ Run Information radhöjdsjustering misslyckades: $($_.Exception.Message)" 'Warn'
}

# ============================================================
# === Sample Reagent Checklist-markering (additiv)         ===
# ============================================================
Set-SampleReagentChecklistHighlight `
    -Pkg $pkgOut `
    -Layout $Layout `
    -Config $Config `
    -StartRow $spStartRow `
    -StartCol $spStartCol

        }
    }
} catch {
    Gui-Log "⚠️ SP-blad: $($_.Exception.Message)" 'Warn'
}

