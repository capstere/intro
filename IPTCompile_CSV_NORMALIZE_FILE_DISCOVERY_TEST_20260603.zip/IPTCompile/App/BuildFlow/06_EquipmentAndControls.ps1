﻿# Build phase: Equipment sheet and control materials
# Extracted from App/BuildReportFlow.ps1 during PASS4.

try { Set-UiStep 70 'Kopierar utrustning/kontrollmaterial…' } catch {}
# ============================
# === Utrustningsblad      ===
# ============================
Mark-Phase 'SealTestInfo'
# OBS: Endast mall kopieras - ingen automatisk ifyllning av pipetter/instrument.
# Användaren fyller i manuellt i output-filen.
if ($Config -and $Config.Contains('EnableEquipmentSheet') -and -not $Config.EnableEquipmentSheet) {
    Gui-Log 'ℹ️ Utrustningslista avstängt. Hoppar över.' 'Info'
} else {
    try {
        if (Test-Path -LiteralPath $UtrustningListPath) {
            $srcPkg = $null
            try {
                $srcPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($UtrustningListPath))

                $srcWs = $srcPkg.Workbook.Worksheets['Sheet1']
                if (-not $srcWs) { $srcWs = $srcPkg.Workbook.Worksheets[1] }

                if ($srcWs) {
                    # Ta bort befintlig flik om den finns
                    $wsEq = $pkgOut.Workbook.Worksheets[$Layout.SheetUtrustning]
                    if ($wsEq) { $pkgOut.Workbook.Worksheets.Delete($wsEq) }

                    # Kopiera mallen som en ny flik
                    $wsEq = $pkgOut.Workbook.Worksheets.Add($Layout.SheetUtrustning, $srcWs)

                    # Ta bort formler och behåll bara värden
                    if ($wsEq.Dimension) {
                        foreach ($cell in $wsEq.Cells[$wsEq.Dimension.Address]) {
                            if ($cell.Formula -or $cell.FormulaR1C1) {
                                $val = $cell.Value
                                $cell.Formula     = $null
                                $cell.FormulaR1C1 = $null
                                $cell.Value       = $val
                            }
                        }
                        # Kopiera kolumnbredder
                        $colCount = $srcWs.Dimension.End.Column
                        for ($c = 1; $c -le $colCount; $c++) {
                            try { $wsEq.Column($c).Width = $srcWs.Column($c).Width } catch {}
                        }
                    }
                    Gui-Log "✅ Utrustningslista kopierad." 'Info' 'PROGRESS'
                }
            } finally {
                if ($srcPkg) { try { $srcPkg.Dispose() } catch {} }
            }
        } else {
            Gui-Log ("ℹ️ Utrustningslista saknas: $UtrustningListPath") 'Info'
        }
    } catch {
        Gui-Log "⚠️ Kunde inte skapa Utrustningslista-flik: $($_.Exception.Message)" 'Warn'
    }
}

# ============================
# === Kontrollmaterial     ===
# ============================
Mark-Phase 'Equipment'

try {
    if ($controlTab -and (Test-Path -LiteralPath $RawDataPath)) {
        $srcPkg = $null
        try {
            $srcPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($RawDataPath))
            try { $srcPkg.Workbook.Calculate() } catch {}

            $candidates = if ($controlTab -match '\|') {
                $controlTab -split '\|' | ForEach-Object { $_.Trim() } | Where-Object { $_ }
            } else { @($controlTab) }

            $srcWs = $null
            foreach ($cand in $candidates) {
                $srcWs = $srcPkg.Workbook.Worksheets | Where-Object { $_.Name -eq $cand } | Select-Object -First 1
                if ($srcWs) { break }
                $srcWs = $srcPkg.Workbook.Worksheets | Where-Object { $_.Name -like "*$cand*" } | Select-Object -First 1
                if ($srcWs) { break }
            }

            if ($srcWs) {
                $safeName = if ($srcWs.Name.Length -gt 31) { $srcWs.Name.Substring(0,31) } else { $srcWs.Name }
                $destName = $safeName; $n = 1
                while ($pkgOut.Workbook.Worksheets[$destName]) {
                    $base = if ($safeName.Length -gt 27) { $safeName.Substring(0,27) } else { $safeName }
                    $destName = "$base($n)"; $n++
                }

                $wsCM = $pkgOut.Workbook.Worksheets.Add($destName, $srcWs)
                if ($wsCM.Dimension) {
                    foreach ($cell in $wsCM.Cells[$wsCM.Dimension.Address]) {
                        if ($cell.Formula -or $cell.FormulaR1C1) {
                            $v = $cell.Value
                            $cell.Formula = $null
                            $cell.FormulaR1C1 = $null
                            $cell.Value = $v
                        }
                    }
                    try {
                        if (Get-Command Safe-AutoFitColumns -ErrorAction SilentlyContinue) {
                            Safe-AutoFitColumns -Ws $wsCM -Context 'ControlMaterial'
                        } else {
                            $wsCM.Cells[$wsCM.Dimension.Address].AutoFitColumns() | Out-Null
                        }
                    } catch {}
                }

                if ($srcWs.Name -ne $destName) {
                    Gui-Log "✅ Kontrollmaterial: '$($srcWs.Name)' → '$destName'" 'Info'
                if ($srcWs.Name -ne $destName) {
                    Gui-Log "✅ Kontrollmaterial: '$($srcWs.Name)' → '$destName'" 'Info'
                } else {
                    Gui-Log "✅ Kontrollmaterial: '$destName'" 'Info' 'PROGRESS'
                }
                } else {
                    Gui-Log "✅ Kontrollmaterial: '$destName'" 'Info' 'PROGRESS'
                }
            } else {
                Gui-Log "ℹ️ Hittade inget blad i kontrollfilen som matchar '$controlTab'." 'Info'
            }
        } finally {
            if ($srcPkg) { try { $srcPkg.Dispose() } catch {} }
        }
    } else {
        Gui-Log "ℹ️ Ingen Control-flik skapad (saknar mappning eller kontrollfil)." 'Info'
    }
} catch {
    Gui-Log "⚠️ Control Material-fel: $($_.Exception.Message)" 'Warn'
}

