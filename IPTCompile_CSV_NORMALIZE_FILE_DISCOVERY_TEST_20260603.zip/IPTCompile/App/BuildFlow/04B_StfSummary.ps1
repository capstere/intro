﻿# Build phase: STF Summary sheet
# Extracted/split during HIGH_RISK_REFACTOR_PASS5.

try { Set-UiStep 52 'Skriver STF Summary…' } catch {}
        # ============================
        # === STF Sum              ===
        # ============================

        $sealMergedMode = $false
        try { $sealMergedMode = Test-SealTestMergedMode } catch { $sealMergedMode = $false }

        $wsOut2 = $pkgOut.Workbook.Worksheets[$Layout.SheetStfSummary]
        if (-not $wsOut2) { Gui-Log "❌ Fliken 'STF Summary' saknas i mallen!"; return }

        $totalRows = $violationsNeg.Count + $violationsPos.Count
        $currentRow = 2

        if ($totalRows -eq 0) {
            Gui-Log "✅ Seal Test hittades"
            $wsOut2.Cells["B1:H1"].Value = $null
            $wsOut2.Cells["A1"].Value = "Inga STF hittades!"
            Style-Cell $wsOut2.Cells["A1"] $true "D9EAD3" "Medium" "006100"
            $wsOut2.Cells["A1"].Style.HorizontalAlignment = "Left"
            if ($wsOut2.Dimension -and $wsOut2.Dimension.End.Row -gt 1) { $wsOut2.DeleteRow(2, $wsOut2.Dimension.End.Row - 1) }
        }
        else {

            $oldDataRows = 0
            if ($wsOut2.Dimension) {
                $oldDataRows = $wsOut2.Dimension.End.Row - 1
                if ($oldDataRows -lt 0) { $oldDataRows = 0 }
            }

            if ($totalRows -lt $oldDataRows) {
                $wsOut2.DeleteRow(2 + $totalRows, $oldDataRows - $totalRows)
            }
            elseif ($totalRows -gt $oldDataRows) {
                $wsOut2.InsertRow(2 + $oldDataRows, $totalRows - $oldDataRows, 1 + $oldDataRows)
            }

            $currentRow = 2
            foreach ($v in $violationsNeg) {
                $wsOut2.Cells["A$currentRow"].Value = "NEG"
                $wsOut2.Cells["B$currentRow"].Value = $v.Sheet
                $wsOut2.Cells["C$currentRow"].Value = $v.Cartridge
                $wsOut2.Cells["D$currentRow"].Value = $v.InitialW
                $wsOut2.Cells["E$currentRow"].Value = $v.FinalW
                if ($v.WeightLoss -ne $null) {
    $wsOut2.Cells["F$currentRow"].Value = [Math]::Round([double]$v.WeightLoss, 1)
} else {
    $wsOut2.Cells["F$currentRow"].Value = $null
}
                $wsOut2.Cells["G$currentRow"].Value = $v.Status
                $wsOut2.Cells["H$currentRow"].Value = if ([string]::IsNullOrWhiteSpace($v.Obs)) { 'NA' } else { $v.Obs }

                Style-Cell $wsOut2.Cells["A$currentRow"] $true "B5E6A2" "Medium" $null
                $wsOut2.Cells["C$currentRow:E$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["C$currentRow:E$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#CCFFFF"))
                $wsOut2.Cells["F$currentRow:G$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["F$currentRow:G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFFF99"))
                $wsOut2.Cells["H$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["H$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#D9D9D9"))

if ($v.Status -in @("FAIL","Minusvärde")) {
    $wsOut2.Cells["F$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["F$currentRow"].Style.Font.Color.SetColor([System.Drawing.Color]::Red)
    $wsOut2.Cells["G$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["G$currentRow"].Style.Font.Color.SetColor([System.Drawing.Color]::Red)
    # Röd bakgrund på riktig FAIL
    if ($v.Status -eq "FAIL") {
        $wsOut2.Cells["G$currentRow"].Style.Fill.PatternType = "Solid"
        $wsOut2.Cells["G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFC7CE"))
    }
}
elseif ($v.Status -eq "Saknar utvägning") {
    $wsOut2.Cells["E$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["E$currentRow"].Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#806000"))
    $wsOut2.Cells["G$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["G$currentRow"].Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#806000"))
    $wsOut2.Cells["G$currentRow"].Style.Fill.PatternType = "Solid"
    $wsOut2.Cells["G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFE699"))
}

                Set-RowBorder -ws $wsOut2 -row $currentRow -firstRow 2 -lastRow ($totalRows + 1)
                $currentRow++
            }

            foreach ($v in $violationsPos) {
                $wsOut2.Cells["A$currentRow"].Value = if ($sealMergedMode) { "MERGED" } else { "POS" }
                $wsOut2.Cells["B$currentRow"].Value = $v.Sheet
                $wsOut2.Cells["C$currentRow"].Value = $v.Cartridge
                $wsOut2.Cells["D$currentRow"].Value = $v.InitialW
                $wsOut2.Cells["E$currentRow"].Value = $v.FinalW
                if ($v.WeightLoss -ne $null) {
    $wsOut2.Cells["F$currentRow"].Value = [Math]::Round([double]$v.WeightLoss, 1)
} else {
    $wsOut2.Cells["F$currentRow"].Value = $null
}
                $wsOut2.Cells["G$currentRow"].Value = $v.Status
                $wsOut2.Cells["H$currentRow"].Value = if ($v.Obs) { $v.Obs } else { 'NA' }

                Style-Cell $wsOut2.Cells["A$currentRow"] $true "FFB3B3" "Medium" $null
                $wsOut2.Cells["C$currentRow:E$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["C$currentRow:E$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#CCFFFF"))
                $wsOut2.Cells["F$currentRow:G$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["F$currentRow:G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFFF99"))
                $wsOut2.Cells["H$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["H$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#D9D9D9"))

if ($v.Status -in @("FAIL","Minusvärde")) {
    $wsOut2.Cells["F$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["F$currentRow"].Style.Font.Color.SetColor([System.Drawing.Color]::Red)
    $wsOut2.Cells["G$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["G$currentRow"].Style.Font.Color.SetColor([System.Drawing.Color]::Red)
    # Röd bakgrund på riktig FAIL
    if ($v.Status -eq "FAIL") {
        $wsOut2.Cells["G$currentRow"].Style.Fill.PatternType = "Solid"
        $wsOut2.Cells["G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFC7CE"))
    }
}
elseif ($v.Status -eq "Saknar utvägning") {
    $wsOut2.Cells["E$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["E$currentRow"].Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#806000"))
    $wsOut2.Cells["G$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["G$currentRow"].Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#806000"))
    $wsOut2.Cells["G$currentRow"].Style.Fill.PatternType = "Solid"
    $wsOut2.Cells["G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFE699"))
}

                Set-RowBorder -ws $wsOut2 -row $currentRow -firstRow 2 -lastRow ($totalRows + 1)
                $currentRow++
            }

            $wsOut2.Cells.Style.WrapText = $false
            $wsOut2.Cells["A1"].Style.HorizontalAlignment = "Left"
            try { $wsOut2.Cells[2,6,([Math]::Max($currentRow-1,2)),6].Style.Numberformat.Format = '0.0' } catch {}
            if ($wsOut2.Dimension) {
                try {
                    if (Get-Command Safe-AutoFitColumns -ErrorAction SilentlyContinue) {
                        Safe-AutoFitColumns -Ws $wsOut2 -Context 'OutputSheet'
                    } else {
                        $wsOut2.Cells[$wsOut2.Dimension.Address].AutoFitColumns() | Out-Null
                    }
                } catch {}
            }
        }


        #endregion Build: CSV-inläsning och RuleEngine
        #region Build: Output-flikar (Information, Utrustning, Kontrollmaterial, SP, QC)
