﻿# Build phase: signing summary, audit and session stats
# Extracted/split during HIGH_RISK_REFACTOR_PASS5.

# Signeringssammanfattning
$sealMergedMode = $false
try { $sealMergedMode = Test-SealTestMergedMode } catch { $sealMergedMode = $false }
# Logga endast det som faktiskt skrevs och read-back-verifierades i denna körning.
$signParts = @()
if ($sealMergedMode -and $posSealSignatureAppliedThisRun) {
    $signParts += "Seal Test: Merged file"
} elseif ($negSealSignatureAppliedThisRun -and $posSealSignatureAppliedThisRun) {
    $signParts += "Seal Test: NEG+POS"
} elseif ($negSealSignatureAppliedThisRun) {
    $signParts += "Seal Test: NEG"
} elseif ($posSealSignatureAppliedThisRun) {
    $signParts += "Seal Test: POS"
}
if ($wsSammSignatureVerifiedThisRun) {
    $signParts += "WS Sammanst."
}
if ($wsGranskSignatureVerifiedThisRun) {
    $signParts += "WS Granskning"
}
if ($signParts.Count -gt 0) {
    Gui-Log ("🔏 Verifierad signering: " + ($signParts -join ', ')) 'Info'
}
try {
    $summaryWarnings = 0
    try { $summaryWarnings += [int]$violationsNeg.Count } catch {}
    try { $summaryWarnings += [int]$violationsPos.Count } catch {}
    if ($sigMismatch) { $summaryWarnings++ }
    if ($mismatchSheets -and $mismatchSheets.Count -gt 0) { $summaryWarnings += [int]$mismatchSheets.Count }
    if ($summaryWarnings -gt 0) {
        Gui-Log ("⚠️ Sammanfattning: rapport skapad med {0} varning(ar) | {1:N1}s" -f $summaryWarnings, ($totalMs / 1000)) 'Warn' 'RESULT'
    } else {
        Gui-Log ("✅ Sammanfattning: rapport skapad utan varningar | {0:N1}s" -f ($totalMs / 1000)) 'Info' 'RESULT'
    }
} catch {}
            $global:LastReportPath = $SavePath
            try { if ($script:slOpenReport) { $script:slOpenReport.Visible = $true }; if ($script:slOpenFolder) { $script:slOpenFolder.Visible = $true } } catch {}
            try { $form.Text = "IPTCompile – $ScriptVersion — $(Split-Path $SavePath -Leaf)" } catch {}
            try {
                $auditDir = Join-Path $ScriptRootPath 'audit'
                if (-not (Test-Path -LiteralPath $auditDir)) { New-Item -ItemType Directory -Path $auditDir -Force | Out-Null }

            # Fasdetaljerad tidsmätning (ms)
            $phaseJson = ''
            try { $phaseJson = ($phaseTimings | ConvertTo-Json -Compress) } 
            catch { $phaseJson = '' }


                $auditObj = [pscustomobject]@{
                    DatumTid        = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
                    Användare       = $env:USERNAME
                    LSP             = $lsp
                    ValdCSV         = if ($selCsv -or $selCsvRes) { (@($(if($selCsv){Get-CleanLeaf $selCsv}), $(if($selCsvRes){'(Res) '+(Get-CleanLeaf $selCsvRes)})) | Where-Object {$_}) -join ' + ' } else { '' }
                    SealTestMode    = if ($sealMergedMode) { 'Merged' } else { 'Split' }
                    ValdSealNEG     = if ($sealMergedMode) { 'N/A (Merged)' } else { Get-CleanLeaf $selNeg }
                    ValdSealPOS     = Get-CleanLeaf $selPos
                    Assay           = $runAssay
                    AntalTester     = $(try { if ($csvStats) { 
                    [int]$csvStats.TestCount } else { 0 } } catch { 0 })
                    SignaturSkriven = if ($doSealTest) { $(if($sealMergedMode){'Ja (verifierad, Merged)'}else{'Ja (verifierad)'}) } else { 'Nej' }
                    WsSammSkriven   = if ($doWsSamm) { 'Ja (verifierad)' } else { 'Nej' }
                    WsGranskSkriven = if ($doWsGransk) { 'Ja (verifierad)' } else { 'Nej' }
                    SigMismatch     = if ($sigMismatch) { 'Ja' } else { 'Nej' }
                    MismatchSheets  = if ($mismatchSheets -and $mismatchSheets.Count -gt 0) { ($mismatchSheets -join ';') } else { '' }
                    ViolationsNEG   = $violationsNeg.Count
                    ViolationsPOS   = $violationsPos.Count
                    Violations      = ($violationsNeg.Count + $violationsPos.Count)
                    TotalTid_ms     = $totalMs
                    TotalTid_s      = [math]::Round($totalMs / 1000, 1)
                    FasTider_json   = $phaseJson
                    Sparläge        = 'Temporärt'
                    OutputFile      = $SavePath
                    Kommentar       = 'UNCONTROLLED rapport, ingen källfil ändrades automatiskt.'
                    ScriptVersion   = $ScriptVersion
                }

                $auditFile = Join-Path $auditDir ("$($env:USERNAME)_audit_${nowTs}.csv")
                $auditObj | Export-Csv -Path $auditFile -NoTypeInformation -Encoding UTF8

                try {
                    $statusText = 'OK'
                    if (($violationsNeg.Count + $violationsPos.Count) -gt 0 -or $sigMismatch -or ($mismatchSheets -and $mismatchSheets.Count -gt 0)) {
                        $statusText = 'Warnings'
                    }
                    $auditStatusText = $statusText
                    $auditTests = $null
                    try {
                        if ($csvStats) { $auditTests = [int]$csvStats.TestCount }
                        if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) { $auditTests = ($auditTests + 0) + [int]$csvStatsRes.TestCount }
                    } catch {}
                    Add-AuditEntry -Lsp $lsp -Assay $runAssay -BatchNumber $batch -TestCount $auditTests -Status $statusText -ReportPath $SavePath -TotalMs $totalMs -PhaseJson $phaseJson
                    $auditWritten = $true
                } catch {
                    Gui-Log "⚠️ Kunde inte skriva audit-CSV: $($_.Exception.Message)" 'Warn'
                }
            } catch {
                Gui-Log "⚠️ Kunde inte skriva revisionsfil: $($_.Exception.Message)" 'Warn'
            }

            # ---- Sessionsspårning + rapportantal ----
            try {
                $script:SessionStats.ReportCount++
                $script:SessionStats.TotalBuildMs += $totalMs
                $buildTests = 0
                try { if ($csvStats) { $buildTests = [int]$csvStats.TestCount } } catch {}
                try { if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) { $buildTests += [int]$csvStatsRes.TestCount } } catch {}
                $script:SessionStats.TotalTestsBuilt += $buildTests

                # Visa endast antal skapade rapporter, inte tidsbesparing.
                try { Update-ReportCountIndicator } catch {
                    $script:slSession.Text = if ($script:SessionStats.ReportCount -eq 1) { '1 rapport skapad' } else { ("{0} rapporter skapade" -f $script:SessionStats.ReportCount) }
                    $script:slSession.Visible = $true
                }
            } catch {}

            # Kort visuell blink på Build-knappen
            $origBack = $btnBuild.BackColor
            try {
                $btnBuild.BackColor = [System.Drawing.Color]::FromArgb(46, 125, 50)
                $btnBuild.Refresh()
                Start-Sleep -Milliseconds 600
                $btnBuild.BackColor = $origBack
                $btnBuild.Refresh()
            } catch { try { $btnBuild.BackColor = $origBack } catch {} }

            try { Start-Process -FilePath $SavePath } catch {

            # Kort ljud-notis vid klar rapport
            try { [System.Media.SystemSounds]::Exclamation.Play() } catch {}
                Gui-Log "ℹ️ Rapporten sparades men kunde inte öppnas automatiskt: $($_.Exception.Message)" 'Info' 'USER'
            }
        }
        catch {
            $auditStatusText = 'Error'
            Gui-Log "❌ Kunde inte spara rapporten: $($_.Exception.Message)" 'Error'
        }

