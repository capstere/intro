# Build phase: Init, file selection, staging, package/template load
# Extracted from App/BuildReportFlow.ps1 during PASS4.

    if ($script:_logPlaceholderActive) { $outputBox.Text = ''; $outputBox.ForeColor = [System.Drawing.SystemColors]::WindowText; $script:_logPlaceholderActive = $false }
    #region Build: Rapportgenerering (huvudloop)
    if (-not (Assert-StartupReady)) { return }

    # Hjälpfunktion: ta bort TEMP-prefix (CSV_Primary__, SealNEG__, etc.) från filnamn för ren visning

    if ($script:ScanInProgress) { Gui-Log "⚠️ Sökning pågår – vänta innan du skapar rapport." 'Warn'; return }
    if ($script:BuildInProgress) { Gui-Log "⚠️ Rapportgenerering kör redan – vänta." 'Warn'; return }
    $script:BuildInProgress = $true

 # --- Tidsmätning (metrics) ---
 $buildTimer = [System.Diagnostics.Stopwatch]::StartNew()
 $phaseTimings = [ordered]@{}
 $lastPhaseMs = 0

    Gui-Log -Text '🔃 Skapar rapport…' -Severity Info -Category USER -Immediate
    Set-UiBusy -Busy $true -Message 'Skapar rapport…'
    Set-UiStep 5 'Initierar…'

    # --- Levande elapsed-timer i statusfältet (uppdateras varje sekund) ---
    $script:buildElapsedTimer = New-Object System.Windows.Forms.Timer
    $script:buildElapsedTimer.Interval = 1000
    $script:buildElapsedTimer.add_Tick({
        try {
            $elapsed = $buildTimer.Elapsed
            $msg = ($script:UiCurrentStepMessage + '').Trim()
            if (-not $msg) { $msg = 'Bygger…' }
            $slWork.Text = ('{0}  {1:mm\:ss}' -f $msg, $elapsed)
            $status.Refresh()
            try { Update-ReadinessBanner } catch {}
        } catch {}
    })
    $script:buildElapsedTimer.Start()

    $pkgNeg = $null
    $pkgPos = $null
    $pkgOut = $null
    $stageDir = $null

    # Original paths (används för transparens + ev. signering)
    $selNegOrig = $null
    $selPosOrig = $null
    $selCsvOrig = $null
    $selCsvResOrig = $null
    $selLspOrig = $null

    # Regelmotor-cache (per körning)
    $script:RuleEngineShadow     = $null
    $script:RuleEngineShadowRes  = $null
    $script:RuleEngineCsvObjs    = $null
    $script:RuleEngineCsvObjsRes = $null
    $script:RuleBankCache        = $null

    # Guard rails för audit/finally (även vid tidiga return)
    $selCsv = $null
    $selCsvRes = $null
    $hasResampleCsv = $false
    $runAssay = $null
    $batch = $null
    $csvStats = $null
    $csvStatsRes = $null
    $sigMismatch = $false
    $mismatchSheets = @()
    $violationsNeg = @()
    $violationsPos = @()
    $granskName = ''
    $granskDate = ''
    $lsp = ''
    $SavePath = $null
    $totalMs = 0
    $phaseJson = ''
    $auditStatusText = 'Aborted'
    $auditWritten = $false

    try {
        if (-not (Load-EPPlus)) { Gui-Log "❌ EPPlus kunde inte laddas – avbryter." 'Error'; return }

        Set-UiStep 10 '🔃 Läser in Seal Test-filer…'
        Mark-Phase 'Init'

        $allCsvPaths = @(Get-AllCheckedFilePaths $clbCsv)
        $csvSel = Resolve-CsvPrimaryAndResample -CsvPaths $allCsvPaths
        if (-not $csvSel.Ok) {
            Gui-Log $csvSel.ErrorMessage 'Error'
            return
        }
        if ($csvSel.WarningMessage) {
            Gui-Log $csvSel.WarningMessage 'Warn'
        }
        $selCsv = $csvSel.PrimaryCsv
        $selCsvRes = $csvSel.ResampleCsv
        $hasResampleCsv = [bool]$csvSel.HasResample

        $sealTestMode = Get-SealTestMode
        $sealMergedMode = ($sealTestMode -eq 'Merged')
        $script:SealTestModeCurrent = $sealTestMode

        $selNeg = $null
        $selPos = $null
        if ($sealMergedMode) {
            $selPos = Get-SealMergedInputPath
            if (-not $selPos) { Gui-Log "❌ Merged-läge: du måste välja en Seal Test-fil." 'Error'; return }
            Gui-Log "ℹ️ Seal Test mode: Merged / en Seal Test-fil." 'Info'
        } else {
            $selNeg = Get-CheckedFilePath $clbNeg
            $selPos = Get-CheckedFilePath $clbPos
            if (-not $selNeg -or -not $selPos) { Gui-Log "❌ Du måste välja en Seal NEG och en Seal POS." 'Error'; return }
            Gui-Log "ℹ️ Seal Test mode: Split / NEG+POS." 'Info'
        }

        $lspRaw    = ($txtLSP.Text + '').Trim()
        $lspDigits = ($lspRaw -replace '\D','')
        $hasLsp    = -not [string]::IsNullOrWhiteSpace($lspDigits)

        if ($hasLsp) {
            $lsp = $lspDigits
        } else {
            $lsp = 'Manuell'
            Gui-Log "ℹ️ Filval via Bläddra." 'Warn'
        }

        $lspForLinks = if ($hasLsp) { $lsp } else { '' }

        Set-UiStep 15 'Förbereder arbetskopior…'

        # ---- TEMP snapshot av valda filer (för att inte stanna om någon har filen öppen) ----
        $enableStaging = Get-ConfigFlag -Name 'EnableLocalStaging' -Default $true -ConfigOverride $Config
        if ($enableStaging) {
            try {

                # Standard: C:\IPTCompile_TEMP\... (kan styras via Config: TempSnapshotRoot)
                $root = Get-ConfigValue -Name 'TempSnapshotRoot' -Default 'C:\IPTCompile_TEMP' -ConfigOverride $Config
                if (-not $root) { $root = 'C:\IPTCompile_TEMP' }
                if (-not (Test-Path -LiteralPath $root)) { New-Item -ItemType Directory -Path $root -Force | Out-Null }
                $stageDir = Join-Path $root ("IPTCompile_" + $lsp + "_" + (Get-Date -Format 'yyyyMMdd_HHmmss') + "_" + ([guid]::NewGuid().ToString('N')))
                New-Item -ItemType Directory -Path $stageDir -Force | Out-Null
                # Spara original paths
                if ($sealMergedMode) {
                    $selNegOrig = $null
                    $selPosOrig = $selPos
                } else {
                    $selNegOrig = $selNeg
                    $selPosOrig = $selPos
                }
                if ($selCsv) { $selCsvOrig = $selCsv }
                if ($selCsvRes) { $selCsvResOrig = $selCsvRes }

                # Snapshot paths används för all läsning/rapportbygge
                if ($sealMergedMode) {
                    $selPos = Stage-InputFileSnapshot -Path $selPos -StageDir $stageDir -Prefix 'SealMERGED'
                    $selNeg = $null
                } else {
                    $selNeg = Stage-InputFileSnapshot -Path $selNeg -StageDir $stageDir -Prefix 'SealNEG'
                    $selPos = Stage-InputFileSnapshot -Path $selPos -StageDir $stageDir -Prefix 'SealPOS'
                }
                if ($selCsv) { $selCsv = Stage-InputFileSnapshot -Path $selCsv -StageDir $stageDir -Prefix 'CSV_Primary' }
                if ($selCsvRes) { $selCsvRes = Stage-InputFileSnapshot -Path $selCsvRes -StageDir $stageDir -Prefix 'CSV_Resample' }

                # Normalisera endast TEMP-kopian om GeneXpert-exporten är av nya layouten.
                # Gammal fungerande CSV lämnas orörd. Resten av IPTCompile får därmed läsa klassiskt internt format.
                try {
                    if ($selCsv -and (Get-Command Normalize-TestSummaryCsvForInternalUse -ErrorAction SilentlyContinue)) {
                        $normCsv = Normalize-TestSummaryCsvForInternalUse -Path $selCsv -Role 'Primary'
                        if ($normCsv -and $normCsv.Normalized) {
                            Gui-Log ("🔧 CSV normaliserad internt: Primary (Text to Columns → klassiskt format, header rad {0} → 8, data rad {1} → 10)." -f $normCsv.HeaderRow, $normCsv.DataStartRow) 'Info' 'PROGRESS'
                        } elseif ($normCsv) {
                            Gui-Log ("ℹ️ CSV-profil Primary: {0} | HeaderRow={1} | DataStartRow={2} | {3}" -f $normCsv.ProfileName, $normCsv.HeaderRow, $normCsv.DataStartRow, $normCsv.Message) 'Info' 'DEBUG'
                        }
                    }
                    if ($selCsvRes -and (Get-Command Normalize-TestSummaryCsvForInternalUse -ErrorAction SilentlyContinue)) {
                        $normCsvRes = Normalize-TestSummaryCsvForInternalUse -Path $selCsvRes -Role 'Resample'
                        if ($normCsvRes -and $normCsvRes.Normalized) {
                            Gui-Log ("🔧 CSV normaliserad internt: Resample (Text to Columns → klassiskt format, header rad {0} → 8, data rad {1} → 10)." -f $normCsvRes.HeaderRow, $normCsvRes.DataStartRow) 'Info' 'PROGRESS'
                        } elseif ($normCsvRes) {
                            Gui-Log ("ℹ️ CSV-profil Resample: {0} | HeaderRow={1} | DataStartRow={2} | {3}" -f $normCsvRes.ProfileName, $normCsvRes.HeaderRow, $normCsvRes.DataStartRow, $normCsvRes.Message) 'Info' 'DEBUG'
                        }
                    }
                } catch {
                    Gui-Log ("⚠️ CSV-normalisering misslyckades: " + $_.Exception.Message) 'Warn'
                }

            } catch {
                Gui-Log ("⚠️ Kunde inte skapa arbetskopia: " + $_.Exception.Message) 'Warn'
            }
        }

        # Logg: visa originalfilnamn (utan TEMP-prefix)
        $negLeaf = if ($selNeg) { Get-CleanLeaf $selNeg } else { '' }
        $posLeaf = if ($selPos) { Get-CleanLeaf $selPos } else { '' }
        if ($sealMergedMode) {
            Gui-Log "📄 Seal Test: $posLeaf" 'Info'
        } else {
            Gui-Log "📄 Neg: $negLeaf" 'Info'
            Gui-Log "📄 Pos: $posLeaf" 'Info'
        }
        if ($selCsv) {
            $csvLeaf = Get-CleanLeaf $selCsv
            Gui-Log "📄 CSV: $csvLeaf" 'Info'
        } else { Gui-Log "ℹ️ Ingen CSV vald." 'Info' }
        if ($selCsvRes) {
            $csvResLeaf = Get-CleanLeaf $selCsvRes
            Gui-Log "📄 CSV (Resample): $csvResLeaf" 'Info'
        }

        # =====================================================
        # === CSV-RADCACHE (läs varje fil max en gång)      ===
        # =====================================================
        Mark-Phase 'SealTestLoad'
        $script:CsvLinesPrimary  = $null
        $script:CsvLinesResample = $null
        if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
            try { $script:CsvLinesPrimary = Read-TestSummaryCsvLines -Path $selCsv } catch { Gui-Log ("⚠️ Kunde inte läsa CSV: " + $_.Exception.Message) 'Warn' }
        }
        if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
            try { $script:CsvLinesResample = Read-TestSummaryCsvLines -Path $selCsvRes } catch { Gui-Log ("⚠️ Kunde inte läsa Resample CSV: " + $_.Exception.Message) 'Warn' }
        }

        $negWritable = $true; $posWritable = $true
        if ($chkSealTest.Checked) {
            # GDP A5: Fil-lås med Retry-dialog för originalfiler (signering)
            if ($sealMergedMode) {
                $posLockPath = if ($selPosOrig) { $selPosOrig } else { $selPos }
                $signPaths = @($posLockPath) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
            } else {
                $negLockPath = if ($selNegOrig) { $selNegOrig } else { $selNeg }
                $posLockPath = if ($selPosOrig) { $selPosOrig } else { $selPos }
                $signPaths = @($negLockPath, $posLockPath) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
            }
if ($signPaths.Count -gt 0) {
    if (-not (Ensure-SignatureFilesClosedOrCancel -Paths $signPaths -Hint $(if($sealMergedMode){'Stäng vald Seal Test-fil i Excel och klicka Försök igen. Signering kan inte genomföras mot en öppen eller låst fil.'}else{'Stäng Seal Test POS/NEG i Excel och klicka Försök igen. Signering kan inte genomföras mot en öppen eller låst fil.'}))) {
        Gui-Log "🛑 Seal Test-signatur avbruten: fil(er) öppna/låsta." 'Error'
        return
    }
}
        }
        # UX: Om någon vald fil är öppen/låst – be användaren stänga den och Försök igen.
        $pathsToCheck = if ($sealMergedMode) { @($selPos) } else { @($selNeg, $selPos) }
        if (-not (Ensure-FilesClosedOrCancel -Paths $pathsToCheck)) {
            Gui-Log "🛑 Avbrutet: en eller flera filer var öppna/låsta." 'Warn'
            return
        }

        Set-UiStep 25 'Öppnar Excel-filer…'

        # ----------------------------
        # Öppna paket
        # ----------------------------
        try {
            if ($sealMergedMode) {
                $pkgNeg = $null
                $pkgPos = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selPos))
            } else {
                $pkgNeg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selNeg))
                $pkgPos = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selPos))
            }
        } catch {
            Gui-Log "❌ Kunde inte öppna Seal Test-fil(er): $($_.Exception.Message)" 'Error'
            return
        }

        $templatePath = Join-Path $ScriptRootPath "output_template-v4.xlsx"
        if (-not (Test-Path -LiteralPath $templatePath)) { Gui-Log "❌ Mallfilen 'output_template-v4.xlsx' saknas!" 'Error'; return }
        # UX: Mallfilen kan vara låst om någon har den öppen (t.ex. förhandsvisning/Excel).
        if (-not (Ensure-FilesClosedOrCancel -Paths @($templatePath))) {
            Gui-Log "🛑 Avbrutet: mallfilen är öppen/låst." 'Warn'
            return
        }
try {
    $pkgOut = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($templatePath))
} catch {
    Gui-Log "❌ Kunde inte läsa mall: $($_.Exception.Message)" 'Error'
    return
}

$script:RunInfoTemplateColumnWidths = @{}
try {
    $wsTemplateRunInfo = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if ($wsTemplateRunInfo) {
        $script:RunInfoTemplateColumnWidths = Get-RunInformationColumnWidths -Ws $wsTemplateRunInfo
    }
} catch {}

