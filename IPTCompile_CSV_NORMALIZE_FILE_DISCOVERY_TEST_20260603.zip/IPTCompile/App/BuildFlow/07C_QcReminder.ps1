﻿# Build phase: QC reminder block
# PASS6: simplified to shared Run Information helper.

# ============================
# === QC-påminnelse (HIV/HBV/HCV) → Run Information E:F ===
# ============================
try {
    $wsInfo = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if ($wsInfo) {
        Write-QcReminderBlock `
            -WsInfo $wsInfo `
            -QcReminderB3 $script:QcReminderB3 `
            -Config $Config `
            -MinimumRow 38 `
            -PreviousBlockLastRow $script:RunInfoSpBlockLastRow `
            -LabelCol 5 `
            -ValueCol 6
    }
} catch {
}

