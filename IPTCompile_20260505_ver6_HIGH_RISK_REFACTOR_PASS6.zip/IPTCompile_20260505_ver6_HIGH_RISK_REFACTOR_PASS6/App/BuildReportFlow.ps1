# BuildReportFlow.ps1
# Registers Build button click handler.
#
# PASS5 note:
# The build body is split into smaller App/BuildFlow/*.ps1 phase fragments.
# The fragments are concatenated into one scriptblock at startup, then invoked from the
# Build button click handler. This preserves the original single-flow semantics, including
# return statements inside try/finally blocks, while making the build phases easier to find.

$buildFlowDir = Join-Path $PSScriptRoot 'BuildFlow'
$script:IPTBuildFlowFragmentFiles = @(
    (Join-Path $buildFlowDir '01_InitializeAndLoad.ps1')
    (Join-Path $buildFlowDir '02_Signing.ps1')
    (Join-Path $buildFlowDir '03_CsvAndRuleEngine.ps1')
    (Join-Path $buildFlowDir '04A_SealTestInfo_Table.ps1')
    (Join-Path $buildFlowDir '04B_StfSummary.ps1')
    (Join-Path $buildFlowDir '05A_RunInfo_CsvStats.ps1')
    (Join-Path $buildFlowDir '05B_RunInfo_WorksheetHeader.ps1')
    (Join-Path $buildFlowDir '05C_RunInfo_SealPosHeader.ps1')
    (Join-Path $buildFlowDir '05D_RunInfo_SealNegHeader.ps1')
    (Join-Path $buildFlowDir '06_EquipmentAndControls.ps1')
    (Join-Path $buildFlowDir '07A_SharePointInfo.ps1')
    (Join-Path $buildFlowDir '07B_RunInfoRowHeights.ps1')
    (Join-Path $buildFlowDir '07C_QcReminder.ps1')
    (Join-Path $buildFlowDir '07D_ReportWatermarkAndTabs.ps1')
    (Join-Path $buildFlowDir '08A_SavePrepareAndDebugSheet.ps1')
    (Join-Path $buildFlowDir '08B_SaveFile.ps1')
    (Join-Path $buildFlowDir '08C_AuditSessionAndSignSummary.ps1')
    (Join-Path $buildFlowDir '08D_FinallyCleanup.ps1')
)

$missingBuildFlowFragments = @(
    $script:IPTBuildFlowFragmentFiles | Where-Object { -not (Test-Path -LiteralPath $_) }
)

if ($missingBuildFlowFragments.Count -gt 0) {
    throw ("BuildReportFlow startup error: missing build phase fragment(s): " + ($missingBuildFlowFragments -join '; '))
}

$buildFlowSource = New-Object System.Text.StringBuilder
foreach ($fragmentPath in $script:IPTBuildFlowFragmentFiles) {
    [void]$buildFlowSource.AppendLine("#region " + (Split-Path $fragmentPath -Leaf))
    [void]$buildFlowSource.AppendLine((Get-Content -LiteralPath $fragmentPath -Raw))
    [void]$buildFlowSource.AppendLine("#endregion " + (Split-Path $fragmentPath -Leaf))
}

try {
    $script:IPTBuildReportScriptBlock = [scriptblock]::Create($buildFlowSource.ToString())
} catch {
    throw ("BuildReportFlow startup error: could not compile build phase fragments. " + $_.Exception.Message)
}

$btnBuild.Add_Click({
    & $script:IPTBuildReportScriptBlock
})

#endregion Händelsehanterare (meny, knappar, tema, scan, build)
