﻿# Build phase: Init, file selection, staging, package/template load
# Extracted from App/BuildReportFlow.ps1 during PASS4.

    if ($script:_logPlaceholderActive) { $outputBox.Text = ''; $outputBox.ForeColor = [System.Drawing.SystemColors]::WindowText; $script:_logPlaceholderActive = $false }
    #region Build: Rapportgenerering (huvudloop)
    if (-not (Assert-StartupReady)) { return }

    # Hjälpfunktion: ta bort TEMP-prefix (CSV_Primary__, SealNEG__, etc.) från filnamn för ren visning

    if ($script:ScanInProgress) { Gui-Log "⚠️ Sökning pågår – vänta innan du skapar rapport." 'Warn'; return }
    if ($script:BuildInProgress) { Gui-Log "⚠️ Rapportgenerering kör redan – vänta." 'Warn'; return }
    $script:BuildInProgress = $true

 # --- Tidsmätning (metrics) ---
 $buildTimer = [System.Diagnostics.Stopwatch]::StartNew()
 $phaseTimings = [ordered]@{}
 $lastPhaseMs = 0

    Gui-Log -Text '🔃 Skapar rapport…' -Severity Info -Category USER -Immediate
    Set-UiBusy -Busy $true -Message 'Skapar rapport…'
    Set-UiStep 5 'Initierar…'

    # --- Levande elapsed-timer i statusfältet (uppdateras varje sekund) ---
    $script:buildElapsedTimer = New-Object System.Windows.Forms.Timer
    $script:buildElapsedTimer.Interval = 1000
    $script:buildElapsedTimer.add_Tick({
        try {
            $elapsed = $buildTimer.Elapsed
            $slWork.Text = ('Bygger… {0:mm\:ss}' -f $elapsed)
            $status.Refresh()
        } catch {}
    })
    $script:buildElapsedTimer.Start()

    $pkgNeg = $null
    $pkgPos = $null
    $pkgOut = $null
    $stageDir = $null

    # Original paths (används för transparens + ev. signering)
    $selNegOrig = $null
    $selPosOrig = $null
    $selCsvOrig = $null
    $selCsvResOrig = $null
    $selLspOrig = $null

    # Regelmotor-cache (per körning)
    $script:RuleEngineShadow     = $null
    $script:RuleEngineShadowRes  = $null
    $script:RuleEngineCsvObjs    = $null
    $script:RuleEngineCsvObjsRes = $null
    $script:RuleBankCache        = $null

    # Guard rails för audit/finally (även vid tidiga return)
    $selCsv = $null
    $selCsvRes = $null
    $hasResampleCsv = $false
    $runAssay = $null
    $batch = $null
    $csvStats = $null
    $csvStatsRes = $null
    $sigMismatch = $false
    $mismatchSheets = @()
    $violationsNeg = @()
    $violationsPos = @()
    $granskName = ''
    $granskDate = ''
    $lsp = ''
    $SavePath = $null
    $totalMs = 0
    $phaseJson = ''
    $auditStatusText = 'Aborted'
    $auditWritten = $false

    try {
        if (-not (Load-EPPlus)) { Gui-Log "❌ EPPlus kunde inte laddas – avbryter." 'Error'; return }

        Set-UiStep 10 '🔃 Läser in Seal Test-filer…'
        Mark-Phase 'Init'

        $allCsvPaths = @(Get-AllCheckedFilePaths $clbCsv)
        $csvSel = Resolve-CsvPrimaryAndResample -CsvPaths $allCsvPaths
        if (-not $csvSel.Ok) {
            Gui-Log $csvSel.ErrorMessage 'Error'
            return
        }
        if ($csvSel.WarningMessage) {
            Gui-Log $csvSel.WarningMessage 'Warn'
        }
        $selCsv = $csvSel.PrimaryCsv
        $selCsvRes = $csvSel.ResampleCsv
        $hasResampleCsv = [bool]$csvSel.HasResample

        $selNeg = Get-CheckedFilePath $clbNeg
        $selPos = Get-CheckedFilePath $clbPos

        if (-not $selNeg -or -not $selPos) { Gui-Log "❌ Du måste välja en Seal NEG och en Seal POS." 'Error'; return }

        $lspRaw    = ($txtLSP.Text + '').Trim()
        $lspDigits = ($lspRaw -replace '\D','')
        $hasLsp    = -not [string]::IsNullOrWhiteSpace($lspDigits)

        if ($hasLsp) {
            $lsp = $lspDigits
        } else {
            $lsp = 'Manuell'
            Gui-Log "ℹ️ Filval via Bläddra." 'Warn'
        }

        $lspForLinks = if ($hasLsp) { $lsp } else { '' }

        # ---- TEMP snapshot av valda filer (för att inte stanna om någon har filen öppen) ----
        $enableStaging = Get-ConfigFlag -Name 'EnableLocalStaging' -Default $true -ConfigOverride $Config
        if ($enableStaging) {
            try {

                # Standard: C:\IPTCompile_TEMP\... (kan styras via Config: TempSnapshotRoot)
                $root = Get-ConfigValue -Name 'TempSnapshotRoot' -Default 'C:\IPTCompile_TEMP' -ConfigOverride $Config
                if (-not $root) { $root = 'C:\IPTCompile_TEMP' }
                if (-not (Test-Path -LiteralPath $root)) { New-Item -ItemType Directory -Path $root -Force | Out-Null }
                $stageDir = Join-Path $root ("IPTCompile_" + $lsp + "_" + (Get-Date -Format 'yyyyMMdd_HHmmss') + "_" + ([guid]::NewGuid().ToString('N')))
                New-Item -ItemType Directory -Path $stageDir -Force | Out-Null
                # Spara original paths
                $selNegOrig = $selNeg
                $selPosOrig = $selPos
                if ($selCsv) { $selCsvOrig = $selCsv }
                if ($selCsvRes) { $selCsvResOrig = $selCsvRes }

                # Snapshot paths används för all läsning/rapportbygge
                $selNeg = Stage-InputFileSnapshot -Path $selNeg -StageDir $stageDir -Prefix 'SealNEG'
                $selPos = Stage-InputFileSnapshot -Path $selPos -StageDir $stageDir -Prefix 'SealPOS'
                if ($selCsv) { $selCsv = Stage-InputFileSnapshot -Path $selCsv -StageDir $stageDir -Prefix 'CSV_Primary' }
                if ($selCsvRes) { $selCsvRes = Stage-InputFileSnapshot -Path $selCsvRes -StageDir $stageDir -Prefix 'CSV_Resample' }

            } catch {
                Gui-Log ("⚠️ Kunde inte skapa arbetskopia: " + $_.Exception.Message) 'Warn'
            }
        }

        # Logg: visa originalfilnamn (utan TEMP-prefix)
        $negLeaf = Get-CleanLeaf $selNeg
        $posLeaf = Get-CleanLeaf $selPos
        Gui-Log "📄 Neg: $negLeaf" 'Info'
        Gui-Log "📄 Pos: $posLeaf" 'Info'
        if ($selCsv) {
            $csvLeaf = Get-CleanLeaf $selCsv
            Gui-Log "📄 CSV: $csvLeaf" 'Info'
        } else { Gui-Log "ℹ️ Ingen CSV vald." 'Info' }
        if ($selCsvRes) {
            $csvResLeaf = Get-CleanLeaf $selCsvRes
            Gui-Log "📄 CSV (Resample): $csvResLeaf" 'Info'
        }

        # =====================================================
        # === CSV-RADCACHE (läs varje fil max en gång)      ===
        # =====================================================
        Mark-Phase 'SealTestLoad'
        $script:CsvLinesPrimary  = $null
        $script:CsvLinesResample = $null
        if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
            try { $script:CsvLinesPrimary = Get-Content -LiteralPath $selCsv } catch { Gui-Log ("⚠️ Kunde inte läsa CSV: " + $_.Exception.Message) 'Warn' }
        }
        if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
            try { $script:CsvLinesResample = Get-Content -LiteralPath $selCsvRes } catch { Gui-Log ("⚠️ Kunde inte läsa Resample CSV: " + $_.Exception.Message) 'Warn' }
        }

        $negWritable = $true; $posWritable = $true
        if ($chkSealTest.Checked) {
            # GDP A5: Fil-lås med Retry-dialog för originalfiler (signering)
            $negLockPath = if ($selNegOrig) { $selNegOrig } else { $selNeg }
            $posLockPath = if ($selPosOrig) { $selPosOrig } else { $selPos }
            $signPaths = @($negLockPath, $posLockPath) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
if ($signPaths.Count -gt 0) {
    if (-not (Ensure-SignatureFilesClosedOrCancel -Paths $signPaths -Hint 'Stäng Seal Test POS/NEG i Excel och klicka Försök igen. Signering kan inte genomföras mot en öppen eller låst fil.')) {
        Gui-Log "🛑 Seal Test-signatur avbruten: fil(er) öppna/låsta." 'Error'
        return
    }
}
        }
        # UX: Om någon vald fil är öppen/låst – be användaren stänga den och Försök igen.
        $pathsToCheck = @($selNeg, $selPos)
        if (-not (Ensure-FilesClosedOrCancel -Paths $pathsToCheck)) {
            Gui-Log "🛑 Avbrutet: en eller flera filer var öppna/låsta." 'Warn'
            return
        }

        # ----------------------------
        # Öppna paket
        # ----------------------------
        try {
            $pkgNeg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selNeg))
            $pkgPos = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selPos))
        } catch {
            Gui-Log "❌ Kunde inte öppna NEG/POS: $($_.Exception.Message)" 'Error'
            return
        }

        $templatePath = Join-Path $ScriptRootPath "output_template-v4.xlsx"
        if (-not (Test-Path -LiteralPath $templatePath)) { Gui-Log "❌ Mallfilen 'output_template-v4.xlsx' saknas!" 'Error'; return }
        # UX: Mallfilen kan vara låst om någon har den öppen (t.ex. förhandsvisning/Excel).
        if (-not (Ensure-FilesClosedOrCancel -Paths @($templatePath))) {
            Gui-Log "🛑 Avbrutet: mallfilen är öppen/låst." 'Warn'
            return
        }
try {
    $pkgOut = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($templatePath))
} catch {
    Gui-Log "❌ Kunde inte läsa mall: $($_.Exception.Message)" 'Error'
    return
}

$script:RunInfoTemplateColumnWidths = @{}
try {
    $wsTemplateRunInfo = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if ($wsTemplateRunInfo) {
        $script:RunInfoTemplateColumnWidths = Get-RunInformationColumnWidths -Ws $wsTemplateRunInfo
    }
} catch {}

