﻿# Build phase: SaveAs and output-open
# Extracted/split during HIGH_RISK_REFACTOR_PASS5.

# UX: Om rapportfilen redan finns och är öppen (Excel), be användaren stänga innan SaveAs
            try {
                if ($SavePath -and (Test-Path -LiteralPath $SavePath)) {
                    if (-not (Ensure-FilesClosedOrCancel -Paths @($SavePath) -Hint 'Stäng rapporten i Excel (eller stäng Preview i Explorer) och klicka Försök igen.')) {
                        Gui-Log "🛑 Avbrutet: output-filen är låst/öppen." 'Warn'
                        return
                    }
                }
            } catch {
                Gui-Log ("⚠️ Fil-låskontroll för output misslyckades: " + $_.Exception.Message) 'Warn' 'DEBUG'
            }
            try {
                $pkgOut.SaveAs($SavePath)
            } catch {
                $auditStatusText = 'Error'
                $saveErr = $_.Exception.Message
                if ($saveErr -match 'being used by another process|access.*denied|permission') {
                    Gui-Log ("❌ Kunde inte spara: filen är låst av ett annat program. Stäng Excel/Preview och försök igen.") 'Error'
                } else {
                    Gui-Log ("❌ Kunde inte spara rapporten: $saveErr") 'Error'
                }
                return
            }
            Mark-Phase 'Save'
            $buildTimer.Stop()
            $totalMs = $buildTimer.ElapsedMilliseconds
            $doneMsg = 'Klar ✅  ({0:N1}s)' -f ($totalMs / 1000)
            Set-UiStep 100 $doneMsg
            Gui-Log -Text ("Rapport sparad: {0} ({1:N1}s)" -f $SavePath, ($totalMs / 1000)) -Severity Info -Category RESULT
