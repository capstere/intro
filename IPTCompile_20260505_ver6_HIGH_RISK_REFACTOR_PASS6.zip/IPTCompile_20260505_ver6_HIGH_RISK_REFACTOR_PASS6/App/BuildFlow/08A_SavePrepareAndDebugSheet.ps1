﻿# Build phase: Save preparation and optional RuleEngine debug sheet
# Extracted/split during HIGH_RISK_REFACTOR_PASS5.

        # ============================
        # === Spara & revision     ===
        # ============================

        $nowTs    = Get-Date -Format "yyyyMMdd_HHmmss"
        $baseName = "$($env:USERNAME)_output_${lsp}_$nowTs.xlsx"
        $saveDir  = $env:TEMP
        $SavePath = Join-Path $saveDir $baseName
        Gui-Log ("💾 Sparar rapport: {0}" -f $baseName) 'Info' 'USER'
        try {
            $pkgOut.Workbook.View.ActiveTab = 0
            $wsInitial = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
            if ($wsInitial) { $wsInitial.View.TabSelected = $true }

            # ============================
            # === RuleEngine felsökningsblad ==
            # ============================
            try {
                if ((Get-ConfigFlag -Name 'EnableRuleEngine' -Default $false -ConfigOverride $Config) -and
                    (Get-ConfigFlag -Name 'EnableRuleEngineDebugSheet' -Default $false -ConfigOverride $Config) -and
                    (($selCsv -and (Test-Path -LiteralPath $selCsv)) -or ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)))) {

                    if (-not $script:RuleEngineShadow -or -not $script:RuleEngineShadow.Rows -or $script:RuleEngineShadow.Rows.Count -eq 0) {

                        Gui-Log "🧠 Regelmotor: saknas vid Save → bygger nu..." 'Warn'

                        $rb2 = $script:RuleBankCache
                        if (-not $rb2) {
                            $rb2 = Load-RuleBank -RuleBankDir $Config.RuleBankDir
                            try {
                                $rb2 = Compile-RuleBank -RuleBank $rb2
                            } catch {
                                Gui-Log ("⚠️ Regelmotor: kunde inte kompilera RuleBank vid Save: " + $_.Exception.Message) 'Warn' 'DEBUG'
                            }
                        }

                        # Primär
                        $csvObjs2 = @()
                        if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
                            $csvObjs2 = $script:RuleEngineCsvObjs
                            if (-not $csvObjs2 -or $csvObjs2.Count -eq 0) {
                                if ($csvRows -and $csvRows.Count -gt 0) {
                                    $csvObjs2 = @($csvRows)
                                } else {
                                    try {
                                        $all = $script:CsvLinesPrimary
                                        if ($all -and $all.Count -gt 9) {
                                            $hdr = ConvertTo-CsvFields $all[7]
                                            $dl  = $all[9..($all.Count-1)] | Where-Object { $_ -and $_.Trim() }
                                            $del = Get-CsvDelimiter -Path $selCsv
                                            $csvObjs2 = @(ConvertFrom-Csv -InputObject ($dl -join "`n") -Delimiter $del -Header $hdr)
                                        }
                                    } catch {
                                        Gui-Log ("⚠️ Regelmotor: fallback-raw för CSV vid Save misslyckades: " + $_.Exception.Message) 'Warn' 'DEBUG'
                                        $csvObjs2 = @()
                                    }
                                }
                            }
                            if ($csvObjs2 -and $csvObjs2.Count -gt 0) {
                                $script:RuleEngineShadow = Invoke-RuleEngine -CsvObjects $csvObjs2 -RuleBank $rb2 -CsvPath $selCsv
                            }
                        }

                        # Resample-del
                        if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
                            $csvObjsR2 = $script:RuleEngineCsvObjsRes
                            if (-not $csvObjsR2 -or $csvObjsR2.Count -eq 0) {
                                if ($csvRowsRes -and $csvRowsRes.Count -gt 0) {
                                    $csvObjsR2 = @($csvRowsRes)
                                } else {
                                    try {
                                        $allR = $script:CsvLinesResample
                                        if ($allR -and $allR.Count -gt 9) {
                                            $hdrR = ConvertTo-CsvFields $allR[7]
                                            $dlR  = $allR[9..($allR.Count-1)] | Where-Object { $_ -and $_.Trim() }
                                            $delR = Get-CsvDelimiter -Path $selCsvRes
                                            $csvObjsR2 = @(ConvertFrom-Csv -InputObject ($dlR -join "`n") -Delimiter $delR -Header $hdrR)
                                        }
                                    } catch {
                                        Gui-Log ("⚠️ Regelmotor: fallback-raw för Resample-CSV vid Save misslyckades: " + $_.Exception.Message) 'Warn' 'DEBUG'
                                        $csvObjsR2 = @()
                                    }
                                }
                            }
                            if ($csvObjsR2 -and $csvObjsR2.Count -gt 0) {
                                $reR2 = Invoke-RuleEngine -CsvObjects $csvObjsR2 -RuleBank $rb2 -CsvPath $selCsvRes
                                if ($script:RuleEngineShadow -and $reR2) {
                                    # Sammanfogning (nytt objekt för PS 5.1-kompatibilitet)
                                    $script:RuleEngineShadow = [pscustomobject]@{
                                        Rows          = @($script:RuleEngineShadow.Rows) + @($reR2.Rows)
                                        Summary       = $script:RuleEngineShadow.Summary
                                        TopDeviations = @($script:RuleEngineShadow.TopDeviations) + @($reR2.TopDeviations)
                                        QC            = $script:RuleEngineShadow.QC
                                    }
                                } elseif ($reR2) {
                                    $script:RuleEngineShadow = $reR2
                                }
                            }
                        }

                        if (-not $script:RuleEngineShadow -or -not $script:RuleEngineShadow.Rows -or @($script:RuleEngineShadow.Rows).Count -eq 0) {
                            Gui-Log "⚠️ Regelmotor: kunde inte bygga vid Save (0 rader)." 'Warn'
                        }
                    }

                    if ($script:RuleEngineShadow -and $script:RuleEngineShadow.Rows -and $script:RuleEngineShadow.Rows.Count -gt 0) {
                        Gui-Log "🧠 Skriver CSV-Sammanfattning..." 'Info' 'PROGRESS'
                        $includeAll = Get-ConfigFlag -Name 'RuleEngineDebugIncludeAllRows' -Default $false -ConfigOverride $Config
                        $dsf = @()
                        if ($script:DataSummaryFindings) { $dsf = @($script:DataSummaryFindings) }
                        $stf = 0
                        if ($script:StfCount) { $stf = [int]$script:StfCount }
                        [void](Write-RuleEngineDebugSheet -Pkg $pkgOut -RuleEngineResult $script:RuleEngineShadow -IncludeAllRows $includeAll -DataSummaryFindings $dsf -StfCount $stf)

                        # --- Skriv använda INF/GX i QC Summary (under befintlig data) ---
                        try {
                            $wsQcs = $pkgOut.Workbook.Worksheets[$Layout.SheetQcSummary]
                            if ($wsQcs) {
                                $usedSystems = [ordered]@{}
                                if ($csvStats -and $csvStats.InstrumentByType) {
                                    foreach ($k in $csvStats.InstrumentByType.Keys) {
                                        if ($k -and $k -ne 'Unknown') { $usedSystems[$k] = $true }
                                    }
                                }
                                if ($csvStatsRes -and $csvStatsRes.InstrumentByType) {
                                    foreach ($k in $csvStatsRes.InstrumentByType.Keys) {
                                        if ($k -and $k -ne 'Unknown') { $usedSystems[$k] = $true }
                                    }
                                }
                                $names = @($usedSystems.Keys | Sort-Object)
                                if ($names.Count -gt 0) {
                                    # Hitta sista använda raden
                                    $lastRow = 3
                                    if ($wsQcs.Dimension) {
                                        for ($ri = $wsQcs.Dimension.End.Row; $ri -ge 1; $ri--) {
                                            $cv = ($wsQcs.Cells[$ri, 1].Text + '').Trim()
                                            if ($cv) { $lastRow = $ri; break }
                                        }
                                    }
                                    $hdrRow = $lastRow + 2  # 2 raders mellanrum

                                    # Rubrik (kolumn A, spänner antal system)
                                    $wsQcs.Cells[$hdrRow, 1].Value = 'Använda INF/GX'
                                    $wsQcs.Cells[$hdrRow, 1].Style.Font.Bold = $true
                                    $wsQcs.Cells[$hdrRow, 1].Style.Font.Size = 10
                                    $hdrRng = $wsQcs.Cells[$hdrRow, 1, $hdrRow, $names.Count]
                                    $hdrRng.Merge = $true
                                    $hdrRng.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                    $hdrRng.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::FromArgb(217, 225, 242))
                                    $hdrRng.Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(0, 32, 96))
                                    $hdrRng.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center

                                    $calMap = $script:CalDueMap
                                    for ($ci = 0; $ci -lt $names.Count; $ci++) {
                                        $col = 1 + $ci
                                        $sysName = $names[$ci]

                                        # Systemnamn
                                        $cName = $wsQcs.Cells[($hdrRow + 1), $col]
                                        $cName.Value = $sysName
                                        $cName.Style.Font.Bold = $true
                                        $cName.Style.Font.Size = 9
                                        $cName.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center
                                        $cName.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                        $cName.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::FromArgb(242, 242, 242))

                                        # Cal Due Date
                                        $cCal = $wsQcs.Cells[($hdrRow + 2), $col]
                                        $calVal = ''
                                        if ($calMap -and $calMap.ContainsKey($sysName)) { $calVal = $calMap[$sysName] }
                                        $cCal.Value = $calVal
                                        $cCal.Style.Font.Size = 9
                                        $cCal.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center
                                        $cCal.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                        $cCal.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::FromArgb(198, 239, 206))

                                        try { $wsQcs.Column($col).AutoFit() } catch {}
                                        try { $wsQcs.Column($col).Width = [Math]::Max($wsQcs.Column($col).Width, 14) } catch {}
                                    }
                                }
                            }
                        } catch {
                            Gui-Log ("⚠️ QC Summary INF/GX fel: " + $_.Exception.Message) 'Warn'
                        }

                        # Visa vilken CSV som klassades som primär/resample direkt i CSV Sammanfattning (rad 2)
                        try {
                            $wsDbg = $pkgOut.Workbook.Worksheets['CSV Sammanfattning']
                            if ($wsDbg) {
                                $pPath = if ($selCsvOrig) { $selCsvOrig } elseif ($selCsv) { $selCsv } else { '' }
                                $rPath = if ($selCsvResOrig) { $selCsvResOrig } elseif ($selCsvRes) { $selCsvRes } else { '' }
                                $pLeaf = Get-CleanLeaf $pPath
                                $rLeaf = Get-CleanLeaf $rPath
                                $lbl = if ($pLeaf -and $rLeaf) {
                                    "CSV: {0} | RES CSV: {1}" -f $pLeaf, $rLeaf
                                } elseif ($pLeaf) {
                                    "CSV: {0}" -f $pLeaf
                                } elseif ($rLeaf) {
                                    "Resample CSV: {0}" -f $rLeaf
                                } else { '' }
                                if ($lbl) {
                                    $rng = $wsDbg.Cells[2, 1, 2, 8]
                                    $rng.Merge = $true
                                    $rng.Style.Numberformat.Format = '@'
                                    $rng.Style.Font.Italic = $true
                                    $wsDbg.Cells[2, 1].Value = $lbl
                                }
                            }
                        } catch {
                            Gui-Log ("⚠️ Kunde inte märka CSV-Sammanfattning med vald CSV/Resample: " + $_.Exception.Message) 'Warn' 'DEBUG'
                        }
                    } else {
                        Gui-Log "⚠️ Kunde inte skriva CSV-Sammanfattning." 'Warn'
                    }
                }
            } catch {
                Gui-Log ("⚠️ Kunde inte skriva CSV-Sammanfattning: " + $_.Exception.Message) 'Warn'
            }
try {
    $wsRunInfoFinal = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if ($wsRunInfoFinal -and $script:RunInfoTemplateColumnWidths -and $script:RunInfoTemplateColumnWidths.Count -gt 0) {
        Restore-RunInformationColumnWidths -Ws $wsRunInfoFinal -Widths $script:RunInfoTemplateColumnWidths
    }
} catch {}
Set-UiStep 90 'Sparar rapport…'
Mark-Phase 'RunInfo'
