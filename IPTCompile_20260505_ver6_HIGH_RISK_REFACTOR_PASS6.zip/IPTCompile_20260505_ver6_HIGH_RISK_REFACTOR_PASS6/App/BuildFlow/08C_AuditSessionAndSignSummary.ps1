﻿# Build phase: signing summary, audit and session stats
# Extracted/split during HIGH_RISK_REFACTOR_PASS5.

# Signeringssammanfattning
# Logga endast det som faktiskt skrevs och read-back-verifierades i denna körning.
$signParts = @()
if ($negSealSignatureAppliedThisRun -and $posSealSignatureAppliedThisRun) {
    $signParts += "Seal Test: NEG+POS"
} elseif ($negSealSignatureAppliedThisRun) {
    $signParts += "Seal Test: NEG"
} elseif ($posSealSignatureAppliedThisRun) {
    $signParts += "Seal Test: POS"
}
if ($wsSammSignatureVerifiedThisRun) {
    $signParts += "WS Sammanst."
}
if ($wsGranskSignatureVerifiedThisRun) {
    $signParts += "WS Granskning"
}
if ($signParts.Count -gt 0) {
    Gui-Log ("🔏 Verifierad signering: " + ($signParts -join ', ')) 'Info'
}
            $global:LastReportPath = $SavePath
            try { $form.Text = "IPTCompile – $ScriptVersion — $(Split-Path $SavePath -Leaf)" } catch {}
            try {
                $auditDir = Join-Path $ScriptRootPath 'audit'
                if (-not (Test-Path -LiteralPath $auditDir)) { New-Item -ItemType Directory -Path $auditDir -Force | Out-Null }

            # Fasdetaljerad tidsmätning (ms)
            $phaseJson = ''
            try { $phaseJson = ($phaseTimings | ConvertTo-Json -Compress) } 
            catch { $phaseJson = '' }


                $auditObj = [pscustomobject]@{
                    DatumTid        = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
                    Användare       = $env:USERNAME
                    LSP             = $lsp
                    ValdCSV         = if ($selCsv -or $selCsvRes) { (@($(if($selCsv){Get-CleanLeaf $selCsv}), $(if($selCsvRes){'(Res) '+(Get-CleanLeaf $selCsvRes)})) | Where-Object {$_}) -join ' + ' } else { '' }
                    ValdSealNEG     = Get-CleanLeaf $selNeg
                    ValdSealPOS     = Get-CleanLeaf $selPos
                    Assay           = $runAssay
                    AntalTester     = $(try { if ($csvStats) { 
                    [int]$csvStats.TestCount } else { 0 } } catch { 0 })
                    SignaturSkriven = if ($doSealTest) { 'Ja (verifierad)' } else { 'Nej' }
                    WsSammSkriven   = if ($doWsSamm) { 'Ja (verifierad)' } else { 'Nej' }
                    WsGranskSkriven = if ($doWsGransk) { 'Ja (verifierad)' } else { 'Nej' }
                    SigMismatch     = if ($sigMismatch) { 'Ja' } else { 'Nej' }
                    MismatchSheets  = if ($mismatchSheets -and $mismatchSheets.Count -gt 0) { ($mismatchSheets -join ';') } else { '' }
                    ViolationsNEG   = $violationsNeg.Count
                    ViolationsPOS   = $violationsPos.Count
                    Violations      = ($violationsNeg.Count + $violationsPos.Count)
                    TotalTid_ms     = $totalMs
                    TotalTid_s      = [math]::Round($totalMs / 1000, 1)
                    FasTider_json   = $phaseJson
                    Sparläge        = 'Temporärt'
                    OutputFile      = $SavePath
                    Kommentar       = 'UNCONTROLLED rapport, ingen källfil ändrades automatiskt.'
                    ScriptVersion   = $ScriptVersion
                }

                $auditFile = Join-Path $auditDir ("$($env:USERNAME)_audit_${nowTs}.csv")
                $auditObj | Export-Csv -Path $auditFile -NoTypeInformation -Encoding UTF8

                try {
                    $statusText = 'OK'
                    if (($violationsNeg.Count + $violationsPos.Count) -gt 0 -or $sigMismatch -or ($mismatchSheets -and $mismatchSheets.Count -gt 0)) {
                        $statusText = 'Warnings'
                    }
                    $auditStatusText = $statusText
                    $auditTests = $null
                    try {
                        if ($csvStats) { $auditTests = [int]$csvStats.TestCount }
                        if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) { $auditTests = ($auditTests + 0) + [int]$csvStatsRes.TestCount }
                    } catch {}
                    Add-AuditEntry -Lsp $lsp -Assay $runAssay -BatchNumber $batch -TestCount $auditTests -Status $statusText -ReportPath $SavePath -TotalMs $totalMs -PhaseJson $phaseJson
                    $auditWritten = $true
                } catch {
                    Gui-Log "⚠️ Kunde inte skriva audit-CSV: $($_.Exception.Message)" 'Warn'
                }
            } catch {
                Gui-Log "⚠️ Kunde inte skriva revisionsfil: $($_.Exception.Message)" 'Warn'
            }

            # ---- Sessionsspårning + tidsbesparningsuppskattning ----
            try {
                $script:SessionStats.ReportCount++
                $script:SessionStats.TotalBuildMs += $totalMs
                $buildTests = 0
                try { if ($csvStats) { $buildTests = [int]$csvStats.TestCount } } catch {}
                try { if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) { $buildTests += [int]$csvStatsRes.TestCount } } catch {}
                $script:SessionStats.TotalTestsBuilt += $buildTests

                # Uppskattad manuell tid: ~20 min per rapport (konservativt)
                $manualMinEstimate = 10
                $savedMin = $manualMinEstimate - [math]::Round($totalMs / 60000, 1)
                if ($savedMin -lt 5) { $savedMin = 5 }
                $sessionSavedMin = [math]::Round($script:SessionStats.ReportCount * $manualMinEstimate - $script:SessionStats.TotalBuildMs / 60000, 0)
                if ($sessionSavedMin -lt $script:SessionStats.ReportCount) { $sessionSavedMin = $script:SessionStats.ReportCount * 5 }

                Gui-Log ("   Uppskattad tidsbesparning: ~{0} min (manuellt ~{1} min, IPTCompile {2:N1}s)" -f [int]$savedMin, $manualMinEstimate, ($totalMs / 1000)) 'Info' 'RESULT'

                # Uppdatera statusfältets sessionsindikator
                $sessText = if ($script:SessionStats.ReportCount -eq 1) {
                    "1 rapport | ~{0} min sparad" -f [int]$savedMin
                } else {
                    "{0} rapporter | ~{1} min sparade" -f $script:SessionStats.ReportCount, [int]$sessionSavedMin
                }
                $script:slSession.Text = $sessText
                $script:slSession.Visible = $true
            } catch {}

            # Kort visuell blink på Build-knappen
            $origBack = $btnBuild.BackColor
            try {
                $btnBuild.BackColor = [System.Drawing.Color]::FromArgb(46, 125, 50)
                $btnBuild.Refresh()
                Start-Sleep -Milliseconds 600
                $btnBuild.BackColor = $origBack
                $btnBuild.Refresh()
            } catch { try { $btnBuild.BackColor = $origBack } catch {} }

            try { Start-Process -FilePath $SavePath } catch {

            # Kort ljud-notis vid klar rapport
            try { [System.Media.SystemSounds]::Exclamation.Play() } catch {}
                Gui-Log "ℹ️ Rapporten sparades men kunde inte öppnas automatiskt: $($_.Exception.Message)" 'Info' 'USER'
            }
        }
        catch {
            $auditStatusText = 'Error'
            Gui-Log "❌ Kunde inte spara rapporten: $($_.Exception.Message)" 'Error'
        }

