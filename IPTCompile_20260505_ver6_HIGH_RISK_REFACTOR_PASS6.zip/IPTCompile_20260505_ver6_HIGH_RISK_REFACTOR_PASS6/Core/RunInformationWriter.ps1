# Auto-extracted from Main.ps1 in high-risk refactor pass 2.
# Behavior should remain unchanged; functions were moved without intentional logic edits.

if (-not (Get-Command Write-SPBlockIntoInformation -ErrorAction SilentlyContinue)) {
    function Write-SPBlockIntoInformation {
        param(
            [Parameter(Mandatory)][OfficeOpenXml.ExcelPackage]$Pkg,
            [Parameter()][object[]]$Rows,
            [Parameter()][string]$Batch,
            [Parameter()][string]$TargetSheetName = 'Run Information',
            [Parameter()][int]$StartRow = 1,
            [Parameter()][int]$StartCol = 5 # E = 5
        )

        if (-not $Pkg) { return $false }
        $Rows = @($Rows)

        $ws = $Pkg.Workbook.Worksheets[$TargetSheetName]
        if (-not $ws) { return $false }

        $labelCol = $StartCol
        $valueCol = $StartCol + 1

        # Harmoniserade färger (matchar CSV Sammanfattning)
        $HeaderBg   = [System.Drawing.Color]::FromArgb(68, 84, 106)    # Mörkblå
        $HeaderFg   = [System.Drawing.Color]::White
        $SectionBg  = [System.Drawing.Color]::FromArgb(217, 225, 242)  # Ljusblå
        $SectionFg  = [System.Drawing.Color]::FromArgb(0, 32, 96)      # Mörkblå text
        $BorderColor = [System.Drawing.Color]::FromArgb(68, 84, 106)

        # Rensa tidigare block (bara i block-ytan, påverkar inte A-D)
        try {
            $clearRows = 120
            $rngClear = $ws.Cells[$StartRow, $labelCol, ($StartRow + $clearRows - 1), $valueCol]
            $rngClear.Clear()
        } catch {}

        # Huvudrubrik
        $ws.Cells[$StartRow, $labelCol].Value = "SharePoint Info"
        $ws.Cells[$StartRow, $valueCol].Value = ""
        $ws.Cells[$StartRow, $labelCol, $StartRow, $valueCol].Merge = $true
        $ws.Cells[$StartRow, $labelCol].Style.Font.Bold = $true
        $ws.Cells[$StartRow, $labelCol].Style.Font.Size = 14
        $ws.Cells[$StartRow, $labelCol].Style.Font.Name = "Calibri"
        $ws.Cells[$StartRow, $labelCol].Style.Font.Color.SetColor($HeaderFg)
        $ws.Cells[$StartRow, $labelCol].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $ws.Cells[$StartRow, $labelCol].Style.Fill.BackgroundColor.SetColor($HeaderBg)
        $ws.Cells[$StartRow, $labelCol].Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Left
        $ws.Cells[$StartRow, $labelCol].Style.VerticalAlignment   = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
        $ws.Row($StartRow).Height = 22

        $r = $StartRow + 1

        if (-not $Rows -or $Rows.Count -eq 0 -or $Rows[0] -eq $null) {
            # Tom data
            $ws.Cells[$r, $labelCol].Value = "Batch"
            $ws.Cells[$r, $valueCol].Value = $Batch
            $r++
            $ws.Cells[$r, $labelCol].Value = "Status"
            $ws.Cells[$r, $valueCol].Value = "SharePoint avstängt för optimering."
            $lastRow = $r
        } else {
            foreach ($row in $Rows) {
                $ws.Cells[$r, $labelCol].Value = $row.Rubrik
                # Normalisera värdet (tar bort NBSP/tabbar/extra whitespace som kan få kolumnen att se "bred" ut)
                $val = $row.'Värde'
                $valN = Normalize-HeaderText (($val + ''))
                $valN = ($valN -replace '\s+', ' ').Trim()
                $ws.Cells[$r, $valueCol].Value = $valN
                $r++
            }
            $lastRow = $r - 1
        }

        # Styling rubrik-kolumn
        try {
            $labelRange = $ws.Cells[($StartRow + 1), $labelCol, $lastRow, $labelCol]
            $labelRange.Style.Font.Bold = $true
            $labelRange.Style.Font.Name = "Calibri"
            $labelRange.Style.Font.Size = 10
            $labelRange.Style.Font.Color.SetColor($SectionFg)
            $labelRange.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $labelRange.Style.Fill.BackgroundColor.SetColor($SectionBg)

            # Styling värde-kolumn
            $valueRange = $ws.Cells[($StartRow + 1), $valueCol, $lastRow, $valueCol]
            $valueRange.Style.Font.Name = "Calibri"
            $valueRange.Style.Font.Size = 10
            $valueRange.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $valueRange.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::White)
            $valueRange.Style.WrapText = $true
            $valueRange.Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Top
            $valueRange.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Left

            # Borders kring block
            $rng = $ws.Cells[$StartRow, $labelCol, $lastRow, $valueCol]
            $rng.Style.Border.Top.Style    = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Left.Style   = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Right.Style  = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Top.Color.SetColor($BorderColor)
            $rng.Style.Border.Bottom.Color.SetColor($BorderColor)
            $rng.Style.Border.Left.Color.SetColor($BorderColor)
            $rng.Style.Border.Right.Color.SetColor($BorderColor)
        } catch {}

# Run Information: template styr kolumnbredder.
# Koden får inte skriva över E/F-bredd.
try { $ws.Column($valueCol).Style.ShrinkToFit = $false } catch {}
        try {
            $script:RunInfoSpBlockStartRow = $StartRow
            $script:RunInfoSpBlockLastRow  = $lastRow
            $script:RunInfoSpBlockStartCol = $StartCol
        } catch {}
        return $true
    }
}

if (-not (Get-Command Get-RunInformationColumnWidths -ErrorAction SilentlyContinue)) {
    function Get-RunInformationColumnWidths {
        param(
            [Parameter(Mandatory=$true)]$Ws,
            [int[]]$Columns = @(1,2,3,4,5,6,7,8)
        )
        $map = @{}
        if (-not $Ws) { return $map }
        foreach ($c in $Columns) {
            try {
                $map[[int]$c] = [double]$Ws.Column([int]$c).Width
            } catch {}
        }
        return $map
    }
}

if (-not (Get-Command Restore-RunInformationColumnWidths -ErrorAction SilentlyContinue)) {
    function Restore-RunInformationColumnWidths {
        param(
            [Parameter(Mandatory=$true)]$Ws,
            [Parameter(Mandatory=$true)][hashtable]$Widths
        )
        if (-not $Ws -or -not $Widths) { return }
        foreach ($key in @($Widths.Keys)) {
            try {
                $col = [int]$key
                $Ws.Column($col).Width = [double]$Widths[$key]
                $Ws.Column($col).BestFit = $false
            } catch {}
        }
        try { $Ws.Column(6).Style.ShrinkToFit = $false } catch {}
        try { $Ws.Column(6).Style.WrapText = $false } catch {}
    }
}

function Find-InfoRow {
            param([OfficeOpenXml.ExcelWorksheet]$Ws, [string]$Label)
            if (-not $Ws -or -not $Ws.Dimension) { return $null }
            $maxRow = [Math]::Min($Ws.Dimension.End.Row, 300)
            for ($ri=1; $ri -le $maxRow; $ri++) {
                $txt = (($Ws.Cells[$ri,1].Text) + '').Trim()
                if (-not $txt) { continue }
                if ($txt.ToLowerInvariant() -eq $Label.ToLowerInvariant()) { return $ri }
            }
            return $null
        }

if (-not (Get-Command Add-Hyperlink -ErrorAction SilentlyContinue)) {
        function Add-Hyperlink {
            param(
                [OfficeOpenXml.ExcelRange]$Cell,
                [string]$Text,
                [string]$Url
            )
            try {
                $Cell.Value = $Text
                $Cell.Hyperlink = [Uri]$Url
                $Cell.Style.Font.UnderLine = $true
                $Cell.Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(0,102,204))
            } catch {}
        }
    }



# PASS6: focused Run Information helpers.
# These helpers replace duplicated inline phase code without changing behavior.
if (-not (Get-Command Get-RunInfoHeaderDeviationMap -ErrorAction SilentlyContinue)) {
    function Get-RunInfoHeaderDeviationMap {
        param([object]$HeaderCheck)

        $map = @{
            DocumentNumber = $null
            Rev            = $null
            Effective      = $null
        }

        try {
            if ($HeaderCheck -and $HeaderCheck.Details) {
                $linesDev = ($HeaderCheck.Details -split "`r?`n")
                foreach ($ln in $linesDev) {
                    if ($ln -match '^\-\s*DocumentNumber[^|]*\|\s*avvikande flikar:\s*(.+)$') { $map.DocumentNumber = $matches[1].Trim() }
                    elseif ($ln -match '^\-\s*Rev[^|]*\|\s*avvikande flikar:\s*(.+)$') { $map.Rev = $matches[1].Trim() }
                    elseif ($ln -match '^\-\s*Effective[^|]*\|\s*avvikande flikar:\s*(.+)$') { $map.Effective = $matches[1].Trim() }
                }
            }
        } catch {}

        return $map
    }
}

if (-not (Get-Command Write-RunInfoSealHeaderBlock -ErrorAction SilentlyContinue)) {
    function Write-RunInfoSealHeaderBlock {
        param(
            [Parameter(Mandatory=$true)]$WsInfo,
            [string]$FilePath,
            [object]$Header,
            [Parameter(Mandatory=$true)][int]$FileRow,
            [Parameter(Mandatory=$true)][int]$DocRow,
            [Parameter(Mandatory=$true)][int]$RevRow,
            [Parameter(Mandatory=$true)][int]$EffRow,
            [Parameter(Mandatory=$true)][scriptblock]$StyleMatchCell,
            [Parameter(Mandatory=$true)][scriptblock]$StyleMismatchCell
        )

        if (-not $WsInfo) { return }

        if ($FilePath) {
            try { $WsInfo.Cells["B$FileRow"].Style.Numberformat.Format = '@' } catch {}
            $WsInfo.Cells["B$FileRow"].Value = (Get-CleanLeaf $FilePath)
        } else {
            $WsInfo.Cells["B$FileRow"].Value = ''
        }

        if ($Header) {
            $doc = $Header.DocumentNumber
            if ($doc) { $doc = ($doc -replace '(?i)\s+(?:Rev(?:ision)?|Effective|p\.)\b.*$','').Trim() }

            $WsInfo.Cells["B$DocRow"].Value = $doc
            $WsInfo.Cells["B$RevRow"].Value = $Header.Rev
            $WsInfo.Cells["B$EffRow"].Value = if ($Header.EffectiveDisplay) { $Header.EffectiveDisplay } else { $Header.Effective }

            $headerCheck = $null
            try { $headerCheck = $Header.HeaderCheck } catch {}
            $dev = Get-RunInfoHeaderDeviationMap -HeaderCheck $headerCheck

            if ($headerCheck) {
                if ($doc) {
                    if ($dev.DocumentNumber) { & $StyleMismatchCell $WsInfo.Cells["C$DocRow"] ('Avvikande flikar: ' + $dev.DocumentNumber) }
                    else { & $StyleMatchCell $WsInfo.Cells["C$DocRow"] }
                }
                if ($Header.Rev) {
                    if ($dev.Rev) { & $StyleMismatchCell $WsInfo.Cells["C$RevRow"] ('Avvikande flikar: ' + $dev.Rev) }
                    else { & $StyleMatchCell $WsInfo.Cells["C$RevRow"] }
                }
                if ($Header.Effective) {
                    if ($dev.Effective) { & $StyleMismatchCell $WsInfo.Cells["C$EffRow"] ('Avvikande flikar: ' + $dev.Effective) }
                    else { & $StyleMatchCell $WsInfo.Cells["C$EffRow"] }
                }
            }
        } else {
            $WsInfo.Cells["B$DocRow"].Value = ''
            $WsInfo.Cells["B$RevRow"].Value = ''
            $WsInfo.Cells["B$EffRow"].Value = ''
        }
    }
}

if (-not (Get-Command Set-RunInformationLeftPanelRowHeights -ErrorAction SilentlyContinue)) {
    function Set-RunInformationLeftPanelRowHeights {
        param(
            [Parameter(Mandatory=$true)]$Ws,
            [int[]]$DataRows = @(2,3,4,5,8,9,10,11,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,31,32,33,34,35,36),
            [int[]]$HeaderRows = @(1,7,13,30),
            [double]$DataRowHeight = 15,
            [double]$HeaderRowHeight = 22
        )

        if (-not $Ws) { return }

        foreach ($rr in $DataRows) {
            try {
                $Ws.Row($rr).Height = $DataRowHeight
                $Ws.Row($rr).CustomHeight = $true
                $Ws.Cells[$rr,1,$rr,3].Style.WrapText = $false
                $Ws.Cells[$rr,1,$rr,3].Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
            } catch {}
        }

        foreach ($rr in $HeaderRows) {
            try {
                $Ws.Row($rr).Height = $HeaderRowHeight
                $Ws.Row($rr).CustomHeight = $true
                $Ws.Cells[$rr,1,$rr,3].Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
            } catch {}
        }
    }
}

if (-not (Get-Command Resolve-RunInformationDynamicBlockRow -ErrorAction SilentlyContinue)) {
    function Resolve-RunInformationDynamicBlockRow {
        param(
            [int]$MinimumRow = 38,
            [object]$PreviousBlockLastRow = $null,
            [int]$GapRows = 2
        )

        $row = $MinimumRow
        try {
            if ($PreviousBlockLastRow -and [int]$PreviousBlockLastRow -ge ($row - 1)) {
                $row = [int]$PreviousBlockLastRow + $GapRows
            }
        } catch {
            $row = $MinimumRow
        }
        return $row
    }
}

if (-not (Get-Command Write-QcReminderBlock -ErrorAction SilentlyContinue)) {
    function Write-QcReminderBlock {
        param(
            [Parameter(Mandatory=$true)]$WsInfo,
            [string]$QcReminderB3,
            [object]$Config,
            [int]$MinimumRow = 38,
            [object]$PreviousBlockLastRow = $null,
            [int]$LabelCol = 5,
            [int]$ValueCol = 6
        )

        if (-not $WsInfo -or -not $QcReminderB3) { return }

        $qcRow = Resolve-RunInformationDynamicBlockRow -MinimumRow $MinimumRow -PreviousBlockLastRow $PreviousBlockLastRow -GapRows 2
        $eCol = $LabelCol
        $fCol = $ValueCol

        $HeaderBg  = [System.Drawing.Color]::FromArgb(68, 84, 106)
        $HeaderFg  = [System.Drawing.Color]::White
        $SectionBg = [System.Drawing.Color]::FromArgb(217, 225, 242)
        $SectionFg = [System.Drawing.Color]::FromArgb(0, 32, 96)
        $BorderClr = [System.Drawing.Color]::FromArgb(68, 84, 106)

        $WsInfo.Cells[$qcRow, $eCol, $qcRow, $fCol].Merge = $true
        $hdrCell = $WsInfo.Cells[$qcRow, $eCol]
        $hdrCell.Value = ('QC Data – ' + $QcReminderB3)
        $hdrCell.Style.Font.Bold = $true
        $hdrCell.Style.Font.Size = 14
        $hdrCell.Style.Font.Name = 'Calibri'
        $hdrCell.Style.Font.Color.SetColor($HeaderFg)
        $hdrCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $hdrCell.Style.Fill.BackgroundColor.SetColor($HeaderBg)
        $hdrCell.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Left
        $hdrCell.Style.VerticalAlignment   = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
        $WsInfo.Row($qcRow).Height = 22

        $WsInfo.Cells[($qcRow+1), $eCol].Value = 'Additional QC-Data?'
        $WsInfo.Cells[($qcRow+1), $eCol].Style.Font.Bold = $true
        $WsInfo.Cells[($qcRow+1), $eCol].Style.Font.Name = 'Calibri'
        $WsInfo.Cells[($qcRow+1), $eCol].Style.Font.Size = 10
        $WsInfo.Cells[($qcRow+1), $eCol].Style.Font.Color.SetColor($SectionFg)
        $WsInfo.Cells[($qcRow+1), $eCol].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $WsInfo.Cells[($qcRow+1), $eCol].Style.Fill.BackgroundColor.SetColor($SectionBg)

        $WsInfo.Cells[($qcRow+1), $fCol].Value = 'JA'
        $WsInfo.Cells[($qcRow+1), $fCol].Style.Font.Bold = $true
        $WsInfo.Cells[($qcRow+1), $fCol].Style.Font.Name = 'Calibri'
        $WsInfo.Cells[($qcRow+1), $fCol].Style.Font.Size = 10
        $WsInfo.Cells[($qcRow+1), $fCol].Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(0, 128, 0))
        $WsInfo.Cells[($qcRow+1), $fCol].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $WsInfo.Cells[($qcRow+1), $fCol].Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::White)
        $WsInfo.Cells[($qcRow+1), $fCol].Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Left

        $WsInfo.Cells[($qcRow+2), $eCol, ($qcRow+2), $fCol].Merge = $true
        $linkCell = $WsInfo.Cells[($qcRow+2), $eCol]

        $lathundPath = ''
        if ($Config) {
            if ($Config.Contains('QcDataCheatSheetLink')) {
                $lathundPath = $Config.QcDataCheatSheetLink
            }
            elseif ($Config.Contains('QcReminderLathundPath')) {
                $lathundPath = $Config.QcReminderLathundPath
            }
        }

        $linkCell.Value = 'Lathund QC data'
        $linkCell.Style.Font.Name = 'Calibri'
        $linkCell.Style.Font.Size = 10
        $linkCell.Style.Font.UnderLine = $true
        $linkCell.Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(5, 99, 193))
        $linkCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $linkCell.Style.Fill.BackgroundColor.SetColor($SectionBg)
        $linkCell.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center
        $linkCell.Style.VerticalAlignment   = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center

        if ($lathundPath) {
            try {
                $uriText = $lathundPath
                if ($uriText -match '^(?i)https?://') {
                    $linkCell.Hyperlink = New-Object System.Uri($uriText)
                }
                elseif ($uriText -match '^[A-Za-z]:\\') {
                    $fileUri = 'file:///' + ($uriText -replace '\\','/')
                    $fileUri = [System.Uri]::EscapeUriString($fileUri)
                    $linkCell.Hyperlink = New-Object System.Uri($fileUri)
                }
                elseif ($uriText -match '^\\\\') {
                    $linkCell.Hyperlink = New-Object System.Uri($uriText)
                }
                else {
                    $linkCell.Hyperlink = New-Object System.Uri($uriText)
                }
            } catch {
                Gui-Log ("⚠️ QC Data: Kunde inte skapa hyperlänk till '{0}': {1}" -f $lathundPath, $_.Exception.Message) 'Warn'
            }
        }

        $rng = $WsInfo.Cells[$qcRow, $eCol, ($qcRow+2), $fCol]
        $rng.Style.Border.Top.Style    = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
        $rng.Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
        $rng.Style.Border.Left.Style   = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
        $rng.Style.Border.Right.Style  = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
        $rng.Style.Border.Top.Color.SetColor($BorderClr)
        $rng.Style.Border.Bottom.Color.SetColor($BorderClr)
        $rng.Style.Border.Left.Color.SetColor($BorderClr)
        $rng.Style.Border.Right.Color.SetColor($BorderClr)
    }
}

if (-not (Get-Command Set-SampleReagentChecklistHighlight -ErrorAction SilentlyContinue)) {
    function Set-SampleReagentChecklistHighlight {
        param(
            [Parameter(Mandatory=$true)][OfficeOpenXml.ExcelPackage]$Pkg,
            [Parameter(Mandatory=$true)][hashtable]$Layout,
            [object]$Config,
            [Parameter(Mandatory=$true)][int]$StartRow,
            [Parameter(Mandatory=$true)][int]$StartCol
        )

        try {
            $_srhPNs = @()
            try { $_srhPNs = @(Get-ConfigValue -Name 'SampleReagentChecklistPNs' -Default @()) } catch {}

            if ($_srhPNs.Count -gt 0) {
                $_srhWs = $Pkg.Workbook.Worksheets[$Layout.SheetRunInfo]
                if ($_srhWs -and $_srhWs.Dimension) {
                    $_srhLabelCol = $StartCol
                    $_srhValueCol = $StartCol + 1
                    $_srhPNRow  = -1; $_srhUseRow = -1
                    $_srhPNVal  = ''; $_srhUseVal = ''

                    for ($_sr = ($StartRow + 1); $_sr -le ($StartRow + 120); $_sr++) {
                        $_srhLabel = (Normalize-HeaderText ($_srhWs.Cells[$_sr, $_srhLabelCol].Text + '')).Trim()
                        if ($_srhLabel -ieq 'Sample Reagent P/N') {
                            $_srhPNRow = $_sr
                            $_srhPNVal = ($_srhWs.Cells[$_sr, $_srhValueCol].Text + '').Trim()
                        }
                        if ($_srhLabel -ieq 'Sample Reagent use') {
                            $_srhUseRow = $_sr
                            $_srhUseVal = ($_srhWs.Cells[$_sr, $_srhValueCol].Text + '').Trim()
                        }
                    }

                    $_srhMatch = $false
                    if ($_srhPNVal) {
                        foreach ($_pn in $_srhPNs) {
                            if ($_srhPNVal -eq ($_pn + '').Trim()) { $_srhMatch = $true; break }
                        }
                    }

                    if ($_srhMatch) {
                        $_srhHighlightBg = [System.Drawing.Color]::FromArgb(255, 255, 200)
                        $_srhWarningBg   = [System.Drawing.Color]::FromArgb(255, 235, 156)
                        $_srhWarningFg   = [System.Drawing.Color]::FromArgb(156, 101, 0)
                        $_srhOkBg        = [System.Drawing.Color]::FromArgb(198, 239, 206)
                        $_srhOkFg        = [System.Drawing.Color]::FromArgb(0, 97, 0)

                        if ($_srhPNRow -gt 0) {
                            $_srhWs.Cells[$_srhPNRow, $_srhValueCol].Style.Fill.PatternType = 'Solid'
                            $_srhWs.Cells[$_srhPNRow, $_srhValueCol].Style.Fill.BackgroundColor.SetColor($_srhHighlightBg)
                            $_srhWs.Cells[$_srhPNRow, $_srhValueCol].Style.Font.Bold = $true
                        }

                        if ($_srhUseRow -gt 0) {
                            if ($_srhUseVal) {
                                $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.PatternType = 'Solid'
                                $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.BackgroundColor.SetColor($_srhOkBg)
                                $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Color.SetColor($_srhOkFg)
                                $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Bold = $true
                            } else {
                                $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Value = '⚠ SAKNAS'
                                $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.PatternType = 'Solid'
                                $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.BackgroundColor.SetColor($_srhWarningBg)
                                $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Color.SetColor($_srhWarningFg)
                                $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Bold = $true
                                Gui-Log '⚠️ Sample Reagent Saknas' 'Warn'
                            }
                        }
                    }
                }
            }
        } catch {
            Gui-Log "⚠️ Sample Reagent highlight: $($_.Exception.Message)" 'Warn'
        }
    }
}
