param(
    [string]$ProjectRoot,
    [switch]$RunValidation
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

. (Join-Path $PSScriptRoot 'RuleBankV2.Common.ps1')

# Canonical compiled RuleBank path is Rules/RuleBank.compiled.ps1.
$paths = Get-RuleBankV2Paths -ProjectRoot $ProjectRoot
$bundle = Get-RuleBankV2SourceBundle -ProjectRoot $paths.ProjectRoot
$artifact = New-RuleBankV2CompiledArtifact -Bundle $bundle

Write-RuleBankCompiledPs1 -Artifact $artifact -Path $paths.CanonicalCompiledPath

$counts = @()
foreach ($table in @('ParityCheckConfig','QuantSpecRules','TestTypePolicy','ErrorCodes','ResultCallPatterns','SampleNumberRules','SampleIdMarkers','MissingSamplesConfig','SampleExpectationRules')) {
    $counts += ('{0}={1}' -f $table, @($artifact[$table]).Count)
}

Write-Host ('Built RuleBank v2 compiled artifact: {0}' -f $paths.CanonicalCompiledPath)
Write-Host ($counts -join ', ')
Write-Host ('SourceHash={0}' -f ($artifact['Meta']['SourceHash'] + ''))

if ($RunValidation) {
    & (Join-Path $PSScriptRoot 'Validate-RuleBank.ps1') -ProjectRoot $paths.ProjectRoot
}
