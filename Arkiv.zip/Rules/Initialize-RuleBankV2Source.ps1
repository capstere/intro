param(
    [string]$ProjectRoot,
    [switch]$Force
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

. (Join-Path $PSScriptRoot 'RuleBankV2.Common.ps1')

function Convert-LegacyEnabledToBool {
    param($Value)
    $s = (($Value + '')).Trim().ToUpperInvariant()
    if (-not $s) { return $true }
    return ($s -in @('TRUE','1','YES','Y'))
}

function Convert-LegacyIntOrDefault {
    param($Value, [int]$Default = 0)
    try { return [int]$Value } catch { return $Default }
}

function Split-LegacyAllowedTestTypes {
    param([string]$Value)
    $raw = ($Value + '').Trim()
    if (-not $raw) { return @() }
    if ($raw -like '*|*') {
        return @($raw.Split('|') | ForEach-Object { ($_ + '').Trim() } | Where-Object { $_ })
    }
    return @($raw.Split(',') | ForEach-Object { ($_ + '').Trim() } | Where-Object { $_ })
}

function New-V2RuleBase {
    param([string]$RuleId, [string]$Today, [string]$Notes)
    [ordered]@{
        RuleId = $RuleId
        Version = 1
        Source = 'legacy-import'
        LastUpdated = $Today
        Notes = ($Notes + '')
        CaseInsensitive = $true
        StopProcessing = $true
    }
}

$paths = Get-RuleBankV2Paths -ProjectRoot $ProjectRoot
$today = (Get-Date).ToString('yyyy-MM-dd')
$seedCompiledPath = $paths.CanonicalCompiledPath
$legacyCompiled = Load-RuleBankCompiledArtifact -Path $seedCompiledPath

if ((Test-Path -LiteralPath $paths.MetaPath) -and (-not $Force)) {
    throw "Rules/Source finns redan. Använd -Force om du vill skriva om seed-filerna."
}

$meta = [ordered]@{
    SchemaVersion = 2
    RuleBankVersion = '2.0.0'
    Source = 'RuleBank v2 source'
    LastUpdated = $today
    Notes = @(
        ('Seeded from canonical compiled RuleBank artifact: {0}' -f $seedCompiledPath),
        'QuantSpecRules intentionally omitted from source schema; compiler emits empty legacy placeholder only.',
        'DELAMINATION Data Summary-evidens remains outside RuleBank and is not duplicated here.'
    )
}
Write-RuleBankSourceDataFile -Data $meta -Path $paths.MetaPath -HeaderComment 'RuleBank v2 metadata'

$tableDefs = @(
    @{ Table='ResultCallPatterns'; Prefix='RCP'; Rows=@($legacyCompiled['ResultCallPatterns']) }
    @{ Table='ErrorCodes'; Prefix='ERR'; Rows=@($legacyCompiled['ErrorCodes']) }
    @{ Table='SampleExpectationRules'; Prefix='EXP'; Rows=@($legacyCompiled['SampleExpectationRules']) }
    @{ Table='SampleIdMarkers'; Prefix='SIM'; Rows=@($legacyCompiled['SampleIdMarkers']) }
    @{ Table='ParityCheckConfig'; Prefix='PAR'; Rows=@($legacyCompiled['ParityCheckConfig']) }
    @{ Table='SampleNumberRules'; Prefix='SNR'; Rows=@($legacyCompiled['SampleNumberRules']) }
    @{ Table='TestTypePolicy'; Prefix='TTP'; Rows=@($legacyCompiled['TestTypePolicy']) }
    @{ Table='MissingSamplesConfig'; Prefix='MSC'; Rows=@($legacyCompiled['MissingSamplesConfig']) }
)

foreach ($def in $tableDefs) {
    $rules = New-Object System.Collections.Generic.List[object]
    $index = 1
    foreach ($row in $def.Rows) {
        $rid = ('{0}-{1:0000}' -f $def.Prefix, $index)
        switch ($def.Table) {
            'ResultCallPatterns' {
                $item = New-V2RuleBase -RuleId $rid -Today $today -Notes ($row['Note'] + '')
                $item['AssayPattern'] = ($row['Assay'] + '')
                $item['MatchType'] = ($row['MatchType'] + '').ToUpperInvariant()
                $item['Pattern'] = ($row['Pattern'] + '')
                $item['Call'] = ($row['Call'] + '').ToUpperInvariant()
                $item['Enabled'] = Convert-LegacyEnabledToBool $row['Enabled']
                $item['Priority'] = Convert-LegacyIntOrDefault $row['Priority']
            }
            'ErrorCodes' {
                $item = New-V2RuleBase -RuleId $rid -Today $today -Notes ''
                $item.Remove('CaseInsensitive') | Out-Null
                $item.Remove('StopProcessing') | Out-Null
                $item['ErrorCode'] = ($row['ErrorCode'] + '')
                $item['Name'] = ($row['Name'] + '')
                $item['GeneratesRetest'] = ($row['GeneratesRetest'] + '')
            }
            'SampleExpectationRules' {
                $item = New-V2RuleBase -RuleId $rid -Today $today -Notes ($row['Note'] + '')
                $item['AssayPattern'] = ($row['Assay'] + '')
                $item['SampleIdMatchType'] = ($row['SampleIdMatchType'] + '').ToUpperInvariant()
                $item['SampleIdPattern'] = ($row['SampleIdPattern'] + '')
                $item['ExpectedCall'] = ($row['Expected'] + '').ToUpperInvariant()
                $item['Enabled'] = Convert-LegacyEnabledToBool $row['Enabled']
                $item['Priority'] = Convert-LegacyIntOrDefault $row['Priority']
            }
            'SampleIdMarkers' {
                $item = New-V2RuleBase -RuleId $rid -Today $today -Notes ($row['Note'] + '')
                $item['AssayPattern'] = ($row['AssayPattern'] + '')
                $item['MarkerType'] = ($row['MarkerType'] + '')
                $item['Marker'] = ($row['Marker'] + '')
                $item['Enabled'] = Convert-LegacyEnabledToBool $row['Enabled']
                if ($row.ContainsKey('SampleTokenIndex') -and ($row['SampleTokenIndex'] + '') -ne '') {
                    $item['SampleTokenIndex'] = Convert-LegacyIntOrDefault $row['SampleTokenIndex']
                }
                if ($row.ContainsKey('Priority') -and ($row['Priority'] + '') -ne '') {
                    $item['Priority'] = Convert-LegacyIntOrDefault $row['Priority']
                }
            }
            'ParityCheckConfig' {
                $item = New-V2RuleBase -RuleId $rid -Today $today -Notes ($row['Note'] + '')
                $item['AssayPattern'] = ($row['AssayPattern'] + '')
                $item['Enabled'] = Convert-LegacyEnabledToBool $row['Enabled']
                $item['CartridgeField'] = ($row['CartridgeField'] + '')
                $item['SampleTokenIndex'] = Convert-LegacyIntOrDefault $row['SampleTokenIndex']
                $item['SuffixX'] = ($row['SuffixX'] + '')
                $item['SuffixPlus'] = ($row['SuffixPlus'] + '')
                $item['DelaminationMarkerType'] = ($row['DelaminationMarkerType'] + '')
                $item['MinValidCartridgeSNPercent'] = Convert-LegacyIntOrDefault $row['MinValidCartridgeSNPercent']
                $item['Priority'] = Convert-LegacyIntOrDefault $row['Priority']
            }
            'SampleNumberRules' {
                $item = New-V2RuleBase -RuleId $rid -Today $today -Notes ($row['Note'] + '')
                $item['AssayPattern'] = ($row['AssayPattern'] + '')
                $item['SampleTypeCode'] = ($row['SampleTypeCode'] + '')
                $item['BagNoPattern'] = ($row['BagNoPattern'] + '')
                $item['SampleNumberTokenIndex'] = Convert-LegacyIntOrDefault $row['SampleNumberTokenIndex']
                $item['SampleNumberRegex'] = ($row['SampleNumberRegex'] + '')
                $item['SampleNumberMin'] = Convert-LegacyIntOrDefault $row['SampleNumberMin']
                $item['SampleNumberMax'] = Convert-LegacyIntOrDefault $row['SampleNumberMax']
                $item['SampleNumberPad'] = Convert-LegacyIntOrDefault $row['SampleNumberPad']
                $item['Enabled'] = Convert-LegacyEnabledToBool $row['Enabled']
                $item['Priority'] = Convert-LegacyIntOrDefault $row['Priority']
            }
            'TestTypePolicy' {
                $item = New-V2RuleBase -RuleId $rid -Today $today -Notes ($row['Note'] + '')
                $item['AssayPattern'] = ($row['AssayPattern'] + '')
                $item['AllowedTestTypes'] = @(Split-LegacyAllowedTestTypes -Value ($row['AllowedTestTypes'] + ''))
                $item['Enabled'] = Convert-LegacyEnabledToBool $row['Enabled']
                $item['Priority'] = Convert-LegacyIntOrDefault $row['Priority']
                $item['AssayFamily'] = ($row['AssayFamily'] + '')
            }
            'MissingSamplesConfig' {
                $item = New-V2RuleBase -RuleId $rid -Today $today -Notes ($row['Notes'] + '')
                $item['AssayPattern'] = ($row['AssayPattern'] + '')
                $item['Bag0SampleMin'] = Convert-LegacyIntOrDefault $row['Bag0SampleMin']
                $item['Bag0SampleMax'] = Convert-LegacyIntOrDefault $row['Bag0SampleMax']
                $item['BagMin'] = Convert-LegacyIntOrDefault $row['BagMin']
                $item['BagMax'] = Convert-LegacyIntOrDefault $row['BagMax']
                $item['OtherBagSampleMin'] = Convert-LegacyIntOrDefault $row['OtherBagSampleMin']
                $item['OtherBagSampleMax'] = Convert-LegacyIntOrDefault $row['OtherBagSampleMax']
                $item['SampleNumberPad'] = Convert-LegacyIntOrDefault $row['SampleNumberPad']
                $item['SampleNumberRegex'] = ($row['SampleNumberRegex'] + '')
                $item['TokenSampleIdSplitIndex'] = Convert-LegacyIntOrDefault $row['Token_SampleID_SplitIndex']
                $item['Enabled'] = Convert-LegacyEnabledToBool $row['Enabled']
                $item['Priority'] = Convert-LegacyIntOrDefault $row['Priority']
            }
            default { throw "Okänd table: $($def.Table)" }
        }
        $rules.Add([pscustomobject]$item)
        $index++
    }

    $fileName = switch ($def.Table) {
        'MissingSamplesConfig' { 'MissingSamplesConfig.legacy.psd1' }
        default { $def.Table + '.psd1' }
    }

    $payload = [ordered]@{
        SchemaVersion = 2
        Table = $def.Table
        Rules = @($rules.ToArray())
    }

    Write-RuleBankSourceDataFile -Data $payload -Path (Join-Path $paths.SourceRoot $fileName) -HeaderComment ("RuleBank v2 source: {0}" -f $def.Table)
}

Write-Host ('Seeded RuleBank v2 source in {0}' -f $paths.SourceRoot)
