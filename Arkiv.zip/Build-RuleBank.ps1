param(
    [string]$ProjectRoot,
    [switch]$WriteLegacyMirror,
    [switch]$SkipLegacyMirror,
    [switch]$RunValidation
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

. (Join-Path $PSScriptRoot 'RuleBankV2.Common.ps1')

# Canonical compiled RuleBank path is Rules/RuleBank.compiled.ps1.
# RuleBank/RuleBank.compiled.ps1 is optional and only used as a legacy compatibility mirror.
$paths = Get-RuleBankV2Paths -ProjectRoot $ProjectRoot
$bundle = Get-RuleBankV2SourceBundle -ProjectRoot $paths.ProjectRoot
$artifact = New-RuleBankV2CompiledArtifact -Bundle $bundle
$shouldWriteLegacyMirror = $false
if ($WriteLegacyMirror) { $shouldWriteLegacyMirror = $true }
if ($SkipLegacyMirror) { $shouldWriteLegacyMirror = $false }

Write-RuleBankCompiledPs1 -Artifact $artifact -Path $paths.CanonicalCompiledPath
if ($shouldWriteLegacyMirror) {
    Write-RuleBankCompiledPs1 -Artifact $artifact -Path $paths.LegacyMirrorCompiledPath
}

$counts = @()
foreach ($table in @('ParityCheckConfig','QuantSpecRules','TestTypePolicy','ErrorCodes','ResultCallPatterns','SampleNumberRules','SampleIdMarkers','MissingSamplesConfig','SampleExpectationRules')) {
    $counts += ('{0}={1}' -f $table, @($artifact[$table]).Count)
}

Write-Host ('Built RuleBank v2 compiled artifact: {0}' -f $paths.CanonicalCompiledPath)
if ($shouldWriteLegacyMirror) {
    Write-Host ('Updated legacy compatibility mirror: {0}' -f $paths.LegacyMirrorCompiledPath)
} else {
    Write-Host ('Legacy compatibility mirror not written by default: {0}' -f $paths.LegacyMirrorCompiledPath)
}
Write-Host ($counts -join ', ')
Write-Host ('SourceHash={0}' -f ($artifact['Meta']['SourceHash'] + ''))

if ($RunValidation) {
    & (Join-Path $PSScriptRoot 'Validate-RuleBank.ps1') -ProjectRoot $paths.ProjectRoot
}
