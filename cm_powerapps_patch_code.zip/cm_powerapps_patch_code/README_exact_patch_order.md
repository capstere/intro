# Exact patch order

1. Create columns in SharePoint Lists from `00_SharePoint_columns_create_first.md`.
2. In Power Apps Studio, refresh data sources: `CM_PN_Master`, `CM_Lots`, `CM_Transactions`.
3. Run App.OnStart.
4. Patch these controls/properties:
   - `scrEditLot > lblEditMeta.Text` → `01_lblEditMeta_Text.txt`
   - `scrEditLot > lblQtyLabel.Text` → `02_lblQtyLabel_Text.txt`
   - `scrEditLot > txtQty.HintText` → `03_txtQty_HintText.txt`
   - `scrEditLot > txtQty.Default` → `04_txtQty_Default.txt`
   - `scrEditLot > btnSaveLot.OnSelect` → `05_btnSaveLot_OnSelect.txt`
   - `scrMaterial > lblMatMeta.Text` → `06_lblMatMeta_Text.txt`
   - `scrMaterial > galLots > lblLotQty.Text` → `07_lblLotQty_Text.txt`
   - Set `scrMaterial > galLots > lblLotQty.Width` to `140`.
   - `scrMaterial > btnMarkChecked.OnSelect` → `08_btnMarkChecked_OnSelect.txt`
   - `scrMaterial > btnConfirmDelete.OnSelect` → `09_btnConfirmDelete_OnSelect.txt`
   - `scrList > galList.Items` → `10_galList_Items.txt`
   - `scrList > galList.OnSelect` → `11_galList_OnSelect.txt`
5. Optional: add a new button on `scrHome` called e.g. `btnCustomerSR`. Set `OnSelect` to `12_btnCustomerSR_OnSelect_new_button.txt`.

Do not rename or remove `Qty`. Excel can keep using `Qty` exactly as before.
