﻿function Resolve-OpenXmlDllPath {
    param(
        [Parameter(Mandatory=$true)][string]$ModulesRoot
    )

    $candidates = New-Object System.Collections.Generic.List[string]

    try {
        if ($global:LibRoot -and ($global:LibRoot -ne $ModulesRoot)) {
            $lib = ($global:LibRoot + '')
            if ($lib) {
                $candidates.Add((Join-Path $lib 'DocumentFormat.OpenXml.dll')) | Out-Null
            }
        }
    } catch {}

    $candidates.Add((Join-Path $ModulesRoot 'DocumentFormat.OpenXml.dll'))

    $candidates.Add((Join-Path $ModulesRoot 'OpenXMLSDK\DocumentFormat.OpenXml.2.20.0\lib\net46\DocumentFormat.OpenXml.dll'))
    $candidates.Add((Join-Path $ModulesRoot 'OpenXMLSDK\DocumentFormat.OpenXml.2.20.0\lib\net40\DocumentFormat.OpenXml.dll'))

    $candidates.Add((Join-Path $ModulesRoot 'OpenXMLSDK\lib\net46\DocumentFormat.OpenXml.dll'))
    $candidates.Add((Join-Path $ModulesRoot 'OpenXMLSDK\lib\net40\DocumentFormat.OpenXml.dll'))

    foreach ($p in $candidates) {
        if (Test-Path -LiteralPath $p) { return $p }
    }
    return $null
}

function Import-OpenXmlSdk {
    param(
        [Parameter(Mandatory=$true)][string]$ModulesRoot
    )

    if ([AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GetName().Name -eq 'DocumentFormat.OpenXml' }) {
        return $true
    }

    $dllPath = Resolve-OpenXmlDllPath -ModulesRoot $ModulesRoot
    if ($dllPath -and (Test-Path -LiteralPath $dllPath)) {
        try {
            $bytes = [System.IO.File]::ReadAllBytes($dllPath)
            [void][System.Reflection.Assembly]::Load($bytes)
            return $true
        } catch {
            throw "Kunde inte ladda OpenXML DLL: $dllPath`n$($_.Exception.Message)"
        }
    }

    $b64Path = $null
    try { if ($global:LibRoot) { $b64Path = Join-Path $global:LibRoot 'OpenXMLAssembly.txt' } } catch {}
    if (-not $b64Path) { $b64Path = Join-Path $ModulesRoot 'OpenXMLAssembly.txt' }
    if (Test-Path -LiteralPath $b64Path) {
        try {
            $base64 = Get-Content -LiteralPath $b64Path -Raw
            $bytes  = [Convert]::FromBase64String($base64)
            [void][System.Reflection.Assembly]::Load($bytes)
            return $true
        } catch {
            throw "Kunde inte ladda OpenXML DLL från Base64 ($b64Path):`n$($_.Exception.Message)"
        }
    }

    throw "DocumentFormat.OpenXml.dll hittades inte i Lib/Modules (eller Base64-fallback). Lägg den i Modules eller i Modules\OpenXMLSDK\... (net46 föredras, net40 fallback) eller placera OpenXMLAssembly.txt."
}

function Normalize-OpenXmlText {
    param([string]$Text)
    $t = ($Text + '')
    $t = $t -replace [char]0x00A0,' '
    $t = $t.Trim()
    $t = [regex]::Replace($t,'\s+',' ')
    return $t
}

function Get-OpenXmlChildrenOfType {
    param(
        [Parameter(Mandatory=$false)]$Parent,
        [Parameter(Mandatory=$true)][Type]$Type
    )
    if (-not $Parent) { return @() }
    $out = New-Object System.Collections.Generic.List[object]
    try {
        foreach ($ch in $Parent.ChildElements) {
            if ($ch -is $Type) { $out.Add($ch) }
        }
    } catch {}
    return $out
}

function Get-OpenXmlDescendantsOfType {
    param(
        [Parameter(Mandatory=$false)]$Parent,
        [Parameter(Mandatory=$true)][Type]$Type
    )
    if (-not $Parent) { return @() }
    $out = New-Object System.Collections.Generic.List[object]
    try {
        foreach ($d in $Parent.Descendants()) {
            if ($d -is $Type) { $out.Add($d) }
        }
    } catch {}
    return $out
}

function Convert-ColLetterToIndex {
    param([string]$Col)
    $c = ($Col + '').Trim().ToUpperInvariant()
    if (-not $c) { return 0 }
    $sum = 0
    foreach ($ch in $c.ToCharArray()) {
        if ($ch -lt 'A' -or $ch -gt 'Z') { return 0 }
        $sum = ($sum * 26) + ([int][char]$ch - [int][char]'A' + 1)
    }
    return $sum
}

function Convert-ColIndexToLetter {
    param([int]$Index)
    if ($Index -le 0) { return '' }
    $i = $Index
    $letters = New-Object System.Text.StringBuilder
    while ($i -gt 0) {
        $i--  # 1-based
        $rem = ($i % 26)
        [void]$letters.Insert(0, [char]([int][char]'A' + $rem))
        $i = [int][math]::Floor($i / 26)
    }
    return $letters.ToString()
}

function Split-OpenXmlCellRef {
    param([string]$CellRef)
    $ref = ($CellRef + '').Trim().ToUpperInvariant()
    if ($ref -notmatch '^([A-Z]+)(\d+)$') { return $null }
    return [pscustomobject]@{
        Ref = $ref
        Col = $matches[1]
        Row = [int]$matches[2]
    }
}

function Get-MergeIndexes_OpenXml {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart
    )

    $forward = @{}
    $reverse = @{}

    $ws = $WorksheetPart.Worksheet
    if (-not $ws) { return @{ Forward = $forward; Reverse = $reverse } }

    $mergeCells = (Get-OpenXmlChildrenOfType -Parent $ws -Type ([DocumentFormat.OpenXml.Spreadsheet.MergeCells]))[0]
    if (-not $mergeCells) { return @{ Forward = $forward; Reverse = $reverse } }

    $mergeCellItems = Get-OpenXmlChildrenOfType -Parent $mergeCells -Type ([DocumentFormat.OpenXml.Spreadsheet.MergeCell])
    foreach ($mc in $mergeCellItems) {
        if (-not $mc.Reference) { continue }
        $ref = ($mc.Reference.Value + '').Trim()
        if (-not $ref) { continue }

        $parts = $ref -split ':'
        $a = ($parts[0] + '').Trim().ToUpperInvariant()
        $b = if ($parts.Count -ge 2) { ($parts[1] + '').Trim().ToUpperInvariant() } else { $a }

        $pA = Split-OpenXmlCellRef -CellRef $a
        $pB = Split-OpenXmlCellRef -CellRef $b
        if (-not $pA -or -not $pB) { continue }

        $c1 = Convert-ColLetterToIndex -Col $pA.Col
        $c2 = Convert-ColLetterToIndex -Col $pB.Col
        $rowA = [int]$pA.Row
        $rowB = [int]$pB.Row
        if ($c1 -le 0 -or $c2 -le 0 -or $rowA -le 0 -or $rowB -le 0) { continue }

        $cMin = [math]::Min($c1, $c2)
        $cMax = [math]::Max($c1, $c2)
        $rMin = [math]::Min($rowA, $rowB)
        $rMax = [math]::Max($rowA, $rowB)

        $owner = ("{0}{1}" -f (Convert-ColIndexToLetter -Index $cMin), $rMin)
        if (-not $reverse.ContainsKey($owner)) {
            $reverse[$owner] = New-Object System.Collections.Generic.List[string]
        }

        for ($r = $rMin; $r -le $rMax; $r++) {
            for ($c = $cMin; $c -le $cMax; $c++) {
                $cellRef = ("{0}{1}" -f (Convert-ColIndexToLetter -Index $c), $r)
                if (-not $forward.ContainsKey($cellRef)) { $forward[$cellRef] = $owner }
                if (-not $reverse[$owner].Contains($cellRef)) { [void]$reverse[$owner].Add($cellRef) }
            }
        }
    }

    $reverseFrozen = @{}
    foreach ($k in $reverse.Keys) {
        $reverseFrozen[$k] = @($reverse[$k].ToArray())
    }
    return @{ Forward = $forward; Reverse = $reverseFrozen }
}
function Get-OpenXmlCellText {
    param(
        [Parameter(Mandatory=$true)]$WorkbookPart,
        [Parameter(Mandatory=$true)]$Cell
    )
    if ($null -eq $Cell) { return '' }

    $val = $Cell.CellValue
    if ($null -eq $val) {
        if ($Cell.InlineString -and $Cell.InlineString.Text) { return ($Cell.InlineString.Text.Text + '') }
        return ''
    }

    $raw = ($val.Text + '')
    if (-not $raw) { return '' }

    if ($Cell.DataType -and $Cell.DataType.Value -eq [DocumentFormat.OpenXml.Spreadsheet.CellValues]::SharedString) {
        $sst = $WorkbookPart.SharedStringTablePart
        if (-not $sst -or -not $sst.SharedStringTable) { return '' }
        $idx = 0
        if (-not [int]::TryParse($raw, [ref]$idx)) { return '' }

        $items = Get-OpenXmlChildrenOfType -Parent $sst.SharedStringTable -Type ([DocumentFormat.OpenXml.Spreadsheet.SharedStringItem])
        if ($idx -lt 0 -or $idx -ge $items.Count) { return '' }
        $item = $items[$idx]

        if ($item.Text) { return ($item.Text.Text + '') }

        $sb = New-Object System.Text.StringBuilder
        foreach ($t in (Get-OpenXmlDescendantsOfType -Parent $item -Type ([DocumentFormat.OpenXml.Spreadsheet.Text]))) {
            [void]$sb.Append(($t.Text + ''))
        }
        return $sb.ToString()
    }

    return $raw
}

function Ensure-OpenXmlCell {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)][int]$RowIndex,
        [Parameter(Mandatory=$true)][string]$ColLetter
    )
    $ws = $WorksheetPart.Worksheet
    if (-not $ws) { return $null }
    $sheetData = (Get-OpenXmlChildrenOfType -Parent $ws -Type ([DocumentFormat.OpenXml.Spreadsheet.SheetData]))[0]
    if (-not $sheetData) {
        $sheetData = New-Object DocumentFormat.OpenXml.Spreadsheet.SheetData
        $ws.AppendChild($sheetData) | Out-Null
    }

    $rows = Get-OpenXmlChildrenOfType -Parent $sheetData -Type ([DocumentFormat.OpenXml.Spreadsheet.Row])
    $row = @($rows | Where-Object { $_.RowIndex -and $_.RowIndex.Value -eq $RowIndex })[0]
    if (-not $row) {
        $row = New-Object DocumentFormat.OpenXml.Spreadsheet.Row
        $row.RowIndex = [uint32]$RowIndex

        $ref = @($rows | Where-Object { $_.RowIndex -and $_.RowIndex.Value -gt $RowIndex })[0]
        if ($ref) { $sheetData.InsertBefore($row, $ref) | Out-Null } else { $sheetData.AppendChild($row) | Out-Null }
    }

    $cellRef = "$ColLetter$RowIndex"
    $cells = Get-OpenXmlChildrenOfType -Parent $row -Type ([DocumentFormat.OpenXml.Spreadsheet.Cell])
    $cell  = @($cells | Where-Object { $_.CellReference -and $_.CellReference.Value -eq $cellRef })[0]
    if ($null -ne $cell) { return ,$cell }

    $cell = New-Object DocumentFormat.OpenXml.Spreadsheet.Cell
    $cell.CellReference = $cellRef

    $targetIdx = Convert-ColLetterToIndex -Col $ColLetter
    $refCell = @($cells | Where-Object {
        $_.CellReference -and (Convert-ColLetterToIndex -Col (($_.CellReference.Value -replace '\d+$',''))) -gt $targetIdx
    })[0]

    if ($null -ne $refCell) { $row.InsertBefore($cell, $refCell) | Out-Null } else { $row.AppendChild($cell) | Out-Null }
    return ,$cell
}

function Test-OpenXmlTreatAsBlankText {
    param([string]$Text)
    $t = Normalize-OpenXmlText $Text
    if (-not $t) { return $true }
    if ($t -match '^(?i)(Recorded By:|Performed By:|PQC Reviewed By:|Date:)$') { return $true }
    if ($t -match '^(?i)(N\/?A|NA)$') { return $true }
    return $false
}

function Get-OpenXmlCellSafe {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)][int]$RowIndex,
        [Parameter(Mandatory=$true)][string]$ColLetter
    )

    if ($RowIndex -lt 1) { return $null }
    $col = ($ColLetter + '').Trim().ToUpperInvariant()
    if (-not $col) { return $null }

    $cell = $null
    try {
        $cell = Ensure-OpenXmlCell -WorksheetPart $WorksheetPart -RowIndex $RowIndex -ColLetter $col
    } catch {
        $cell = $null
    }

    if ($cell -is [DocumentFormat.OpenXml.Spreadsheet.CellValue]) { $cell = $cell.Parent }
    if ($cell -is [DocumentFormat.OpenXml.Spreadsheet.InlineString]) { $cell = $cell.Parent }
    if ($cell -is [DocumentFormat.OpenXml.Spreadsheet.Cell]) { return ,$cell }

    $cell = Find-OpenXmlCell -WorksheetPart $WorksheetPart -RowIndex $RowIndex -ColLetter $col
    if ($cell -is [DocumentFormat.OpenXml.Spreadsheet.CellValue]) { $cell = $cell.Parent }
    if ($cell -is [DocumentFormat.OpenXml.Spreadsheet.InlineString]) { $cell = $cell.Parent }
    if ($cell -is [DocumentFormat.OpenXml.Spreadsheet.Cell]) { return ,$cell }

    return $null
}

function Clear-OpenXmlCellContent {
    param([Parameter(Mandatory=$true)]$Cell)
    if (-not ($Cell -is [DocumentFormat.OpenXml.Spreadsheet.Cell])) { return $false }
    $Cell.CellFormula  = $null
    $Cell.CellValue    = $null
    $Cell.InlineString = $null
    $Cell.DataType     = $null
    return $true
}

function Set-OpenXmlCellInlineText {
    param(
        [Parameter(Mandatory=$true)]$Cell,
        [Parameter(Mandatory=$true)][string]$Value
    )
    if (-not ($Cell -is [DocumentFormat.OpenXml.Spreadsheet.Cell])) { return $false }
    [void](Clear-OpenXmlCellContent -Cell $Cell)
    $Cell.DataType = [DocumentFormat.OpenXml.Spreadsheet.CellValues]::InlineString
    $Cell.InlineString = New-Object DocumentFormat.OpenXml.Spreadsheet.InlineString
    $Cell.InlineString.Text = New-Object DocumentFormat.OpenXml.Spreadsheet.Text
    $Cell.InlineString.Text.Text = ($Value + '')
    return $true
}

function Resolve-OpenXmlMergeOwner {
    param(
        [Parameter(Mandatory=$true)][int]$RowIndex,
        [Parameter(Mandatory=$true)][string]$ColLetter,
        [hashtable]$ForwardMap
    )
    $col = ($ColLetter + '').Trim().ToUpperInvariant()
    $targetRef = ("{0}{1}" -f $col, $RowIndex)
    $ownerRef = $targetRef
    if ($ForwardMap -and $ForwardMap.ContainsKey($targetRef)) {
        $ownerRef = (($ForwardMap[$targetRef] + '').Trim().ToUpperInvariant())
    }

    $ownerInfo = Split-OpenXmlCellRef -CellRef $ownerRef
    if (-not $ownerInfo) { $ownerInfo = Split-OpenXmlCellRef -CellRef $targetRef }
    if (-not $ownerInfo) { return $null }

    return [pscustomobject]@{
        TargetRef = $targetRef
        OwnerRef  = $ownerInfo.Ref
        OwnerCol  = $ownerInfo.Col
        OwnerRow  = [int]$ownerInfo.Row
    }
}

function Get-OpenXmlMergeGroupOwnerRowRefs {
    param(
        [Parameter(Mandatory=$true)][string]$OwnerRef,
        [Parameter(Mandatory=$true)][int]$OwnerRow,
        [hashtable]$ReverseMap
    )

    $refs = New-Object System.Collections.Generic.List[string]
    if ($ReverseMap -and $ReverseMap.ContainsKey($OwnerRef)) {
        foreach ($r in @($ReverseMap[$OwnerRef])) {
            $info = Split-OpenXmlCellRef -CellRef $r
            if ($info -and ([int]$info.Row -eq [int]$OwnerRow)) {
                if (-not $refs.Contains($info.Ref)) { [void]$refs.Add($info.Ref) }
            }
        }
    }
    if (-not $refs.Contains($OwnerRef)) { [void]$refs.Add($OwnerRef) }
    return @($refs.ToArray())
}

function Write-OpenXmlCellText_DeterministicMerge {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)]$WorkbookPart,
        [Parameter(Mandatory=$true)][int]$RowIndex,
        [Parameter(Mandatory=$true)][string]$ColLetter,
        [Parameter(Mandatory=$true)][string]$Value,
        [bool]$Overwrite = $false,
        [hashtable]$ForwardMap,
        [hashtable]$ReverseMap,
        [string]$TailValue
    )

    $result = [pscustomobject]@{
        Written     = $false
        TargetRef   = $null
        OwnerRef    = $null
        OwnerRow    = $null
        OwnerCol    = $null
        GroupRefs   = @()
        Reason      = $null
        BlockedBy   = $null
    }

    if ($RowIndex -lt 1) {
        $result.Reason = 'invalid row'
        return $result
    }

    $owner = Resolve-OpenXmlMergeOwner -RowIndex $RowIndex -ColLetter $ColLetter -ForwardMap $ForwardMap
    if (-not $owner) {
        $result.Reason = 'could not resolve owner'
        return $result
    }

    $result.TargetRef = $owner.TargetRef
    $result.OwnerRef = $owner.OwnerRef
    $result.OwnerRow = [int]$owner.OwnerRow
    $result.OwnerCol = $owner.OwnerCol

    $groupRefs = Get-OpenXmlMergeGroupOwnerRowRefs -OwnerRef $owner.OwnerRef -OwnerRow $owner.OwnerRow -ReverseMap $ReverseMap
    $result.GroupRefs = @($groupRefs)

    if (-not $Overwrite) {
        foreach ($ref in $groupRefs) {
            $ri = Split-OpenXmlCellRef -CellRef $ref
            if (-not $ri) { continue }
            $existingCell = Find-OpenXmlCell -WorksheetPart $WorksheetPart -RowIndex ([int]$ri.Row) -ColLetter $ri.Col
            if ($null -eq $existingCell) { continue }
            $existingRaw = Get-OpenXmlCellText -WorkbookPart $WorkbookPart -Cell $existingCell
            if (-not (Test-OpenXmlTreatAsBlankText -Text $existingRaw)) {
                $result.Reason = 'already filled'
                $result.BlockedBy = $ri.Ref
                return $result
            }
        }
    } else {
        foreach ($ref in $groupRefs) {
            $ri = Split-OpenXmlCellRef -CellRef $ref
            if (-not $ri) { continue }
            $clearCell = Get-OpenXmlCellSafe -WorksheetPart $WorksheetPart -RowIndex ([int]$ri.Row) -ColLetter $ri.Col
            if ($clearCell) { [void](Clear-OpenXmlCellContent -Cell $clearCell) }
        }
    }

    $ownerCell = Get-OpenXmlCellSafe -WorksheetPart $WorksheetPart -RowIndex $owner.OwnerRow -ColLetter $owner.OwnerCol
    if ($null -eq $ownerCell) {
        $result.Reason = 'owner cell missing'
        return $result
    }
    if (-not (Set-OpenXmlCellInlineText -Cell $ownerCell -Value $Value)) {
        $result.Reason = 'owner write failed'
        return $result
    }

    $tail = Normalize-OpenXmlText $TailValue
    if ($Overwrite -and $tail) {
        foreach ($ref in $groupRefs) {
            if ($ref -eq $owner.OwnerRef) { continue }
            $ri = Split-OpenXmlCellRef -CellRef $ref
            if (-not $ri) { continue }
            $tailCell = Get-OpenXmlCellSafe -WorksheetPart $WorksheetPart -RowIndex ([int]$ri.Row) -ColLetter $ri.Col
            if ($null -eq $tailCell) { continue }
            [void](Set-OpenXmlCellInlineText -Cell $tailCell -Value $tail)
        }
    }

    $result.Written = $true
    $result.Reason = 'written'
    return $result
}
function Find-FirstRowByContains_OpenXml {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)]$WorkbookPart,
        [Parameter(Mandatory=$true)][string]$ColLetter,
        [Parameter(Mandatory=$true)][string]$Needle
    )
    $needleNorm = (Normalize-OpenXmlText $Needle).ToLowerInvariant()
    $sheetData = (Get-OpenXmlChildrenOfType -Parent $WorksheetPart.Worksheet -Type ([DocumentFormat.OpenXml.Spreadsheet.SheetData]))[0]
    if (-not $sheetData) { return $null }

    foreach ($row in (Get-OpenXmlChildrenOfType -Parent $sheetData -Type ([DocumentFormat.OpenXml.Spreadsheet.Row]))) {
        $r = 0
        if ($row.RowIndex) { $r = [int]$row.RowIndex.Value }
        if ($r -le 0) { continue }
        $cellRef = "$ColLetter$r"

        $cell = @(
            Get-OpenXmlChildrenOfType -Parent $row -Type ([DocumentFormat.OpenXml.Spreadsheet.Cell]) |
            Where-Object { $_.CellReference -and $_.CellReference.Value -eq $cellRef }
        )[0]

        if ($null -eq $cell) { continue }
        $txt = Normalize-OpenXmlText (Get-OpenXmlCellText -WorkbookPart $WorkbookPart -Cell $cell)
        if (-not $txt) { continue }
        if ($txt.ToLowerInvariant().Contains($needleNorm)) { return $r }
    }
    return $null
}

function Find-FirstRowByContains_FromRow_OpenXml {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)]$WorkbookPart,
        [Parameter(Mandatory=$true)][string]$ColLetter,
        [Parameter(Mandatory=$true)][string]$Needle,
        [Parameter(Mandatory=$true)][int]$StartRow
    )
    $needleNorm = (Normalize-OpenXmlText $Needle).ToLowerInvariant()
    $sheetData = (Get-OpenXmlChildrenOfType -Parent $WorksheetPart.Worksheet -Type ([DocumentFormat.OpenXml.Spreadsheet.SheetData]))[0]
    if (-not $sheetData) { return $null }

    $fromRow = $StartRow
    if ($fromRow -lt 1) { $fromRow = 1 }

    foreach ($row in (Get-OpenXmlChildrenOfType -Parent $sheetData -Type ([DocumentFormat.OpenXml.Spreadsheet.Row]))) {
        $r = 0
        if ($row.RowIndex) { $r = [int]$row.RowIndex.Value }
        if ($r -lt $fromRow) { continue }
        if ($r -le 0) { continue }
        $cellRef = "$ColLetter$r"

        $cell = @(
            Get-OpenXmlChildrenOfType -Parent $row -Type ([DocumentFormat.OpenXml.Spreadsheet.Cell]) |
            Where-Object { $_.CellReference -and $_.CellReference.Value -eq $cellRef }
        )[0]

        if ($null -eq $cell) { continue }
        $txt = Normalize-OpenXmlText (Get-OpenXmlCellText -WorkbookPart $WorkbookPart -Cell $cell)
        if (-not $txt) { continue }
        if ($txt.ToLowerInvariant().Contains($needleNorm)) { return $r }
    }
    return $null
}

function Test-OpenXmlDataSummaryHasData {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)]$WorkbookPart,
        [string]$DataColLetter = 'C',
        [hashtable]$MergeMap
    )
    $sheetData = (Get-OpenXmlChildrenOfType -Parent $WorksheetPart.Worksheet -Type ([DocumentFormat.OpenXml.Spreadsheet.SheetData]))[0]
    if (-not $sheetData) { return $false }

    foreach ($row in (Get-OpenXmlChildrenOfType -Parent $sheetData -Type ([DocumentFormat.OpenXml.Spreadsheet.Row]))) {
        $r = 0
        if ($row.RowIndex) { $r = [int]$row.RowIndex.Value }
        if ($r -le 0) { continue }
        $cellRef = "$DataColLetter$r"
        if ($MergeMap -and $MergeMap.ContainsKey($cellRef)) {
            $cellRef = ($MergeMap[$cellRef] + '')
        }

        $cell = @(
            Get-OpenXmlChildrenOfType -Parent $row -Type ([DocumentFormat.OpenXml.Spreadsheet.Cell]) |
            Where-Object { $_.CellReference -and $_.CellReference.Value -eq $cellRef }
        )[0]

        if ($null -eq $cell) { continue }
        $txt = Normalize-OpenXmlText (Get-OpenXmlCellText -WorkbookPart $WorkbookPart -Cell $cell)
        if (-not $txt) { continue }
        if ($txt -match '^(?i)(Performed By:|Recorded By:|PQC Reviewed By:|Date:)$') { continue }
        return $true
    }
    return $false
}

function Write-OpenXmlSignDebug {
    param(
        [bool]$Enabled,
        [System.Collections.Generic.List[string]]$Events,
        [string]$Message
    )
    $msg = ($Message + '')
    if ($null -ne $Events) { [void]$Events.Add($msg) }
    if ($Enabled) { Write-Verbose ("[OpenXML] $msg") -Verbose }
}

function Find-OpenXmlCell {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)][int]$RowIndex,
        [Parameter(Mandatory=$true)][string]$ColLetter
    )
    $ws = $WorksheetPart.Worksheet
    $sheetData = (Get-OpenXmlChildrenOfType -Parent $ws -Type ([DocumentFormat.OpenXml.Spreadsheet.SheetData]))[0]
    if (-not $sheetData) { return $null }

    $rows = Get-OpenXmlChildrenOfType -Parent $sheetData -Type ([DocumentFormat.OpenXml.Spreadsheet.Row])
    $row = @($rows | Where-Object { $_.RowIndex -and $_.RowIndex.Value -eq $RowIndex })[0]
    if (-not $row) { return $null }

    $cellRef = "$ColLetter$RowIndex"
    $cells = Get-OpenXmlChildrenOfType -Parent $row -Type ([DocumentFormat.OpenXml.Spreadsheet.Cell])
    $cell = @($cells | Where-Object { $_.CellReference -and $_.CellReference.Value -eq $cellRef })[0]
    return ,$cell
}

# ============================================================
# SAX / streaming-baserad signering för riskflikar
# ------------------------------------------------------------
# Syfte:
# - Undvik OpenXML DOM-save av extremt uppblåsta WorksheetPart.
# - Patcha endast signaturceller i sheet XML via ZIP + XmlReader/XmlWriter.
# - Behåll övriga cellnoder oförändrade; ingen compact/sanering görs här.
# Riskflikar:
#   Seal Test Failure Count
#   Statistical Process Control STF
#   Statistical Process Control
# ============================================================
function Test-XlsxSaxRiskSignatureSheetName {
    param([string]$SheetName)
    $n = (($SheetName + '').Trim())
    return @(
        'Seal Test Failure Count',
        'Statistical Process Control STF',
        'Statistical Process Control'
    ) -contains $n
}

function Import-XlsxZipAssemblies {
    try { Add-Type -AssemblyName 'System.IO.Compression' -ErrorAction SilentlyContinue } catch {}
    try { Add-Type -AssemblyName 'System.IO.Compression.FileSystem' -ErrorAction SilentlyContinue } catch {}
}

function Join-XlsxPartPath {
    param(
        [Parameter(Mandatory=$true)][string]$SourcePartPath,
        [Parameter(Mandatory=$true)][string]$Target
    )
    $t = (($Target + '') -replace '\\','/').Trim()
    if (-not $t) { return $null }
    if ($t.StartsWith('/')) { $combined = $t.TrimStart('/') }
    else {
        $src = (($SourcePartPath + '') -replace '\\','/').Trim()
        $base = ''
        $slash = $src.LastIndexOf('/')
        if ($slash -ge 0) { $base = $src.Substring(0, $slash) }
        if ($base) { $combined = ($base.TrimEnd('/') + '/' + $t) } else { $combined = $t }
    }

    $parts = New-Object System.Collections.Generic.List[string]
    foreach ($p in ($combined -split '/')) {
        if (-not $p -or $p -eq '.') { continue }
        if ($p -eq '..') {
            if ($parts.Count -gt 0) { $parts.RemoveAt($parts.Count - 1) }
            continue
        }
        [void]$parts.Add($p)
    }
    return ($parts.ToArray() -join '/')
}

function Get-XlsxZipEntryTextUtf8 {
    param(
        [Parameter(Mandatory=$true)]$Archive,
        [Parameter(Mandatory=$true)][string]$EntryPath
    )
    $entry = $Archive.GetEntry($EntryPath)
    if (-not $entry) { return $null }
    $stream = $null
    $reader = $null
    try {
        $stream = $entry.Open()
        $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8, $true)
        return $reader.ReadToEnd()
    } finally {
        try { if ($reader) { $reader.Dispose() } } catch {}
        try { if ($stream) { $stream.Dispose() } } catch {}
    }
}

function Resolve-XlsxWorksheetEntryInfo_Sax {
    param(
        [Parameter(Mandatory=$true)]$Archive,
        [Parameter(Mandatory=$true)][string[]]$SheetNames
    )

    $wbText = Get-XlsxZipEntryTextUtf8 -Archive $Archive -EntryPath 'xl/workbook.xml'
    $relsText = Get-XlsxZipEntryTextUtf8 -Archive $Archive -EntryPath 'xl/_rels/workbook.xml.rels'
    if (-not $wbText) { throw 'xl/workbook.xml saknas i workbook.' }
    if (-not $relsText) { throw 'xl/_rels/workbook.xml.rels saknas i workbook.' }

    $rels = @{}
    $relsDoc = New-Object System.Xml.XmlDocument
    $relsDoc.PreserveWhitespace = $true
    $relsDoc.LoadXml($relsText)
    foreach ($rel in $relsDoc.DocumentElement.ChildNodes) {
        if ($rel.NodeType -ne [System.Xml.XmlNodeType]::Element) { continue }
        $id = ($rel.GetAttribute('Id') + '')
        $target = ($rel.GetAttribute('Target') + '')
        if ($id -and $target) { $rels[$id] = $target }
    }

    $wanted = @{}
    foreach ($s in @($SheetNames)) {
        $k = (($s + '').Trim())
        if ($k) { $wanted[$k] = $true }
    }

    $wbDoc = New-Object System.Xml.XmlDocument
    $wbDoc.PreserveWhitespace = $true
    $wbDoc.LoadXml($wbText)
    $nsMgr = New-Object System.Xml.XmlNamespaceManager($wbDoc.NameTable)
    $nsMgr.AddNamespace('x', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main')
    $nsMgr.AddNamespace('r', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships')

    foreach ($sheet in $wbDoc.SelectNodes('//x:sheet', $nsMgr)) {
        $name = ($sheet.GetAttribute('name') + '')
        if (-not $wanted.ContainsKey($name)) { continue }
        $rid = ($sheet.GetAttribute('id', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships') + '')
        if (-not $rid -or -not $rels.ContainsKey($rid)) { throw "Worksheet relationship saknas för flik '$name'." }
        $entryPath = Join-XlsxPartPath -SourcePartPath 'xl/workbook.xml' -Target ($rels[$rid] + '')
        if (-not $entryPath) { throw "Worksheet target kunde inte lösas för flik '$name'." }
        if (-not $Archive.GetEntry($entryPath)) { throw "Worksheet XML saknas för flik '$name': $entryPath" }
        return [pscustomobject]@{
            SheetName = $name
            EntryPath = $entryPath
            RelationshipId = $rid
        }
    }

    return $null
}

function Read-XlsxSharedStrings_Sax {
    param([Parameter(Mandatory=$true)]$Archive)
    $items = New-Object System.Collections.Generic.List[string]
    $entry = $Archive.GetEntry('xl/sharedStrings.xml')
    if (-not $entry) { return $items }

    $stream = $null
    $xr = $null
    try {
        $stream = $entry.Open()
        $settings = New-Object System.Xml.XmlReaderSettings
        $settings.IgnoreComments = $true
        $settings.IgnoreProcessingInstructions = $true
        $xr = [System.Xml.XmlReader]::Create($stream, $settings)
        $inSi = $false
        $sb = $null
        while ($xr.Read()) {
            if ($xr.NodeType -eq [System.Xml.XmlNodeType]::Element -and $xr.LocalName -eq 'si') {
                $inSi = $true
                $sb = New-Object System.Text.StringBuilder
                if ($xr.IsEmptyElement) {
                    [void]$items.Add('')
                    $inSi = $false
                    $sb = $null
                }
                continue
            }
            if ($inSi -and $xr.NodeType -eq [System.Xml.XmlNodeType]::Element -and $xr.LocalName -eq 't') {
                $txt = $xr.ReadElementContentAsString()
                [void]$sb.Append(($txt + ''))
                continue
            }
            if ($xr.NodeType -eq [System.Xml.XmlNodeType]::EndElement -and $xr.LocalName -eq 'si' -and $inSi) {
                [void]$items.Add($sb.ToString())
                $inSi = $false
                $sb = $null
                continue
            }
        }
    } finally {
        try { if ($xr) { $xr.Close() } } catch {}
        try { if ($stream) { $stream.Dispose() } } catch {}
    }
    return $items
}

function Get-XlsxCellTextFromCellNode_Sax {
    param(
        [Parameter(Mandatory=$true)][System.Xml.XmlElement]$Cell,
        [Parameter(Mandatory=$true)]$SharedStrings
    )
    $type = ($Cell.GetAttribute('t') + '')
    $nsMgr = New-Object System.Xml.XmlNamespaceManager($Cell.OwnerDocument.NameTable)
    $nsMgr.AddNamespace('x', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main')

    if ($type -eq 's') {
        $v = $Cell.SelectSingleNode('x:v', $nsMgr)
        if (-not $v) { return '' }
        $idx = 0
        if (-not [int]::TryParse(($v.InnerText + ''), [ref]$idx)) { return '' }
        if ($idx -lt 0 -or $idx -ge $SharedStrings.Count) { return '' }
        return ($SharedStrings[$idx] + '')
    }

    if ($type -eq 'inlineStr') {
        $sb = New-Object System.Text.StringBuilder
        foreach ($t in $Cell.SelectNodes('.//x:t', $nsMgr)) { [void]$sb.Append(($t.InnerText + '')) }
        return $sb.ToString()
    }

    $v2 = $Cell.SelectSingleNode('x:v', $nsMgr)
    if ($v2) { return ($v2.InnerText + '') }
    return ''
}

function Get-XlsxRowIndexFromRowXmlNode {
    param([Parameter(Mandatory=$true)][System.Xml.XmlElement]$Row)
    $r = 0
    [void][int]::TryParse(($Row.GetAttribute('r') + ''), [ref]$r)
    return $r
}

function Get-XlsxSaxSheetScan {
    param(
        [Parameter(Mandatory=$true)]$Archive,
        [Parameter(Mandatory=$true)][string]$EntryPath,
        [Parameter(Mandatory=$true)]$SharedStrings,
        [int]$MaxRow = 150,
        [string[]]$CaptureCols = @('K','L','M')
    )

    $capture = @{}
    foreach ($c in @($CaptureCols)) { $capture[(($c + '').Trim().ToUpperInvariant())] = $true }

    $scan = [pscustomobject]@{
        CellText   = @{}
        RowExists  = @{}
        Merges     = New-Object System.Collections.Generic.List[string]
        ForwardMap = @{}
        ReverseMap = @{}
    }

    $entry = $Archive.GetEntry($EntryPath)
    if (-not $entry) { throw "Worksheet XML saknas: $EntryPath" }

    $stream = $null
    $xr = $null
    try {
        $stream = $entry.Open()
        $settings = New-Object System.Xml.XmlReaderSettings
        $settings.IgnoreComments = $false
        $settings.IgnoreProcessingInstructions = $false
        $settings.DtdProcessing = [System.Xml.DtdProcessing]::Ignore
        $xr = [System.Xml.XmlReader]::Create($stream, $settings)
        [void]$xr.Read()
        while (-not $xr.EOF) {
            if ($xr.NodeType -eq [System.Xml.XmlNodeType]::Element -and $xr.LocalName -eq 'row') {
                $rowAttr = ($xr.GetAttribute('r') + '')
                $rowIndex = 0
                [void][int]::TryParse($rowAttr, [ref]$rowIndex)
                if ($rowIndex -gt 0 -and $rowIndex -le $MaxRow) {
                    $rowXml = $xr.ReadOuterXml()
                    $rowDoc = New-Object System.Xml.XmlDocument
                    $rowDoc.PreserveWhitespace = $true
                    $rowDoc.LoadXml($rowXml)
                    $rowNode = $rowDoc.DocumentElement
                    $scan.RowExists[$rowIndex] = $true
                    $nsMgr = New-Object System.Xml.XmlNamespaceManager($rowDoc.NameTable)
                    $nsMgr.AddNamespace('x', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main')
                    foreach ($cell in $rowNode.SelectNodes('x:c', $nsMgr)) {
                        $ref = (($cell.GetAttribute('r') + '').Trim().ToUpperInvariant())
                        if (-not $ref) { continue }
                        $info = Split-OpenXmlCellRef -CellRef $ref
                        if (-not $info) { continue }
                        if (-not $capture.ContainsKey($info.Col)) { continue }
                        $txt = Get-XlsxCellTextFromCellNode_Sax -Cell $cell -SharedStrings $SharedStrings
                        $scan.CellText[$info.Ref] = ($txt + '')
                    }
                    continue
                }
            }

            if ($xr.NodeType -eq [System.Xml.XmlNodeType]::Element -and $xr.LocalName -eq 'mergeCell') {
                $mref = (($xr.GetAttribute('ref') + '').Trim().ToUpperInvariant())
                if ($mref) { [void]$scan.Merges.Add($mref) }
            }

            [void]$xr.Read()
        }
    } finally {
        try { if ($xr) { $xr.Close() } } catch {}
        try { if ($stream) { $stream.Dispose() } } catch {}
    }

    foreach ($mref in @($scan.Merges.ToArray())) {
        $parts = $mref -split ':'
        $a = ($parts[0] + '').Trim().ToUpperInvariant()
        $b = if ($parts.Count -ge 2) { ($parts[1] + '').Trim().ToUpperInvariant() } else { $a }
        $pA = Split-OpenXmlCellRef -CellRef $a
        $pB = Split-OpenXmlCellRef -CellRef $b
        if (-not $pA -or -not $pB) { continue }
        $c1 = Convert-ColLetterToIndex -Col $pA.Col
        $c2 = Convert-ColLetterToIndex -Col $pB.Col
        $r1 = [int]$pA.Row
        $r2 = [int]$pB.Row
        if ($c1 -le 0 -or $c2 -le 0 -or $r1 -le 0 -or $r2 -le 0) { continue }
        $cMin = [math]::Min($c1,$c2); $cMax = [math]::Max($c1,$c2)
        $rMin = [math]::Min($r1,$r2); $rMax = [math]::Max($r1,$r2)
        $owner = ('{0}{1}' -f (Convert-ColIndexToLetter -Index $cMin), $rMin)
        if (-not $scan.ReverseMap.ContainsKey($owner)) { $scan.ReverseMap[$owner] = New-Object System.Collections.Generic.List[string] }
        for ($rr=$rMin; $rr -le $rMax; $rr++) {
            for ($cc=$cMin; $cc -le $cMax; $cc++) {
                $cr = ('{0}{1}' -f (Convert-ColIndexToLetter -Index $cc), $rr)
                if (-not $scan.ForwardMap.ContainsKey($cr)) { $scan.ForwardMap[$cr] = $owner }
                if (-not $scan.ReverseMap[$owner].Contains($cr)) { [void]$scan.ReverseMap[$owner].Add($cr) }
            }
        }
    }

    return $scan
}

function Find-XlsxSaxFirstRowByContains {
    param(
        [Parameter(Mandatory=$true)]$Scan,
        [Parameter(Mandatory=$true)][string]$ColLetter,
        [Parameter(Mandatory=$true)][string]$Needle,
        [int]$MinRow = 1,
        [int]$MaxRow = 150
    )
    $col = (($ColLetter + '').Trim().ToUpperInvariant())
    $needleNorm = (Normalize-OpenXmlText $Needle).ToLowerInvariant()
    for ($r=$MinRow; $r -le $MaxRow; $r++) {
        $ref = "$col$r"
        if (-not $Scan.CellText.ContainsKey($ref)) { continue }
        $txt = Normalize-OpenXmlText ($Scan.CellText[$ref] + '')
        if (-not $txt) { continue }
        if ($txt.ToLowerInvariant().Contains($needleNorm)) { return $r }
    }
    return $null
}

function Resolve-XlsxSaxMergeOwner {
    param(
        [Parameter(Mandatory=$true)][string]$CellRef,
        [Parameter(Mandatory=$true)]$Scan
    )
    $ref = (($CellRef + '').Trim().ToUpperInvariant())
    if ($Scan.ForwardMap -and $Scan.ForwardMap.ContainsKey($ref)) { $ref = (($Scan.ForwardMap[$ref] + '').Trim().ToUpperInvariant()) }
    return $ref
}

function Get-XlsxSaxMergeGroupOwnerRowRefs {
    param(
        [Parameter(Mandatory=$true)][string]$OwnerRef,
        [Parameter(Mandatory=$true)]$Scan
    )
    $owner = Split-OpenXmlCellRef -CellRef $OwnerRef
    if (-not $owner) { return @($OwnerRef) }
    $refs = New-Object System.Collections.Generic.List[string]
    if ($Scan.ReverseMap -and $Scan.ReverseMap.ContainsKey($OwnerRef)) {
        foreach ($r in @($Scan.ReverseMap[$OwnerRef])) {
            $ri = Split-OpenXmlCellRef -CellRef $r
            if ($ri -and ([int]$ri.Row -eq [int]$owner.Row)) {
                if (-not $refs.Contains($ri.Ref)) { [void]$refs.Add($ri.Ref) }
            }
        }
    }
    if (-not $refs.Contains($OwnerRef)) { [void]$refs.Add($OwnerRef) }
    return @($refs.ToArray())
}

function New-XlsxSaxPatchCellElement {
    param(
        [Parameter(Mandatory=$true)][System.Xml.XmlDocument]$Doc,
        [Parameter(Mandatory=$true)][string]$CellRef,
        [Parameter(Mandatory=$true)][string]$Value,
        [System.Xml.XmlElement]$ExistingCell = $null
    )
    $ns = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    $cell = $Doc.CreateElement('c', $ns)
    $cell.SetAttribute('r', $CellRef)
    if ($ExistingCell -and $ExistingCell.HasAttribute('s')) { $cell.SetAttribute('s', $ExistingCell.GetAttribute('s')) }
    $cell.SetAttribute('t', 'inlineStr')
    $is = $Doc.CreateElement('is', $ns)
    $t = $Doc.CreateElement('t', $ns)
    $t.SetAttribute('space', 'http://www.w3.org/XML/1998/namespace', 'preserve')
    $t.InnerText = ($Value + '')
    [void]$is.AppendChild($t)
    [void]$cell.AppendChild($is)
    return $cell
}

function Set-XlsxSaxRowPatchCells {
    param(
        [Parameter(Mandatory=$true)][string]$RowXml,
        [Parameter(Mandatory=$true)][hashtable]$PatchesForRow
    )
    $doc = New-Object System.Xml.XmlDocument
    $doc.PreserveWhitespace = $true
    $doc.LoadXml($RowXml)
    $row = $doc.DocumentElement
    $nsMgr = New-Object System.Xml.XmlNamespaceManager($doc.NameTable)
    $nsMgr.AddNamespace('x', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main')

    foreach ($ref in @($PatchesForRow.Keys)) {
        $cellRef = (($ref + '').Trim().ToUpperInvariant())
        $value = ($PatchesForRow[$ref] + '')
        $existing = $null
        foreach ($c in $row.SelectNodes('x:c', $nsMgr)) {
            if ((($c.GetAttribute('r') + '').Trim().ToUpperInvariant()) -eq $cellRef) { $existing = $c; break }
        }
        $newCell = New-XlsxSaxPatchCellElement -Doc $doc -CellRef $cellRef -Value $value -ExistingCell $existing
        if ($existing) {
            [void]$row.ReplaceChild($newCell, $existing)
            continue
        }

        $targetInfo = Split-OpenXmlCellRef -CellRef $cellRef
        $targetColIdx = Convert-ColLetterToIndex -Col $targetInfo.Col
        $insertBefore = $null
        foreach ($c2 in $row.SelectNodes('x:c', $nsMgr)) {
            $ri = Split-OpenXmlCellRef -CellRef (($c2.GetAttribute('r') + '').Trim().ToUpperInvariant())
            if (-not $ri) { continue }
            $ci = Convert-ColLetterToIndex -Col $ri.Col
            if ($ci -gt $targetColIdx) { $insertBefore = $c2; break }
        }
        if ($insertBefore) { [void]$row.InsertBefore($newCell, $insertBefore) }
        else { [void]$row.AppendChild($newCell) }
    }

    return $row.OuterXml
}

function Update-XlsxWorksheetEntryRows_Sax {
    param(
        [Parameter(Mandatory=$true)]$Archive,
        [Parameter(Mandatory=$true)][string]$EntryPath,
        [Parameter(Mandatory=$true)][hashtable]$PatchesByRef
    )

    if (-not $PatchesByRef -or $PatchesByRef.Count -eq 0) { return 0 }

    $patchesByRow = @{}
    foreach ($ref in @($PatchesByRef.Keys)) {
        $ri = Split-OpenXmlCellRef -CellRef (($ref + '').Trim().ToUpperInvariant())
        if (-not $ri) { throw "Ogiltig cellreferens för SAX-patch: $ref" }
        $rowKey = [int]$ri.Row
        if (-not $patchesByRow.ContainsKey($rowKey)) { $patchesByRow[$rowKey] = @{} }
        $patchesByRow[$rowKey][$ri.Ref] = ($PatchesByRef[$ref] + '')
    }

    $entry = $Archive.GetEntry($EntryPath)
    if (-not $entry) { throw "Worksheet XML saknas: $EntryPath" }
    $tmp = [System.IO.Path]::GetTempFileName()
    $patchedRows = 0
    $inStream = $null
    $xr = $null
    $outStream = $null
    $xw = $null
    try {
        $inStream = $entry.Open()
        $settings = New-Object System.Xml.XmlReaderSettings
        $settings.IgnoreComments = $false
        $settings.IgnoreProcessingInstructions = $false
        $settings.DtdProcessing = [System.Xml.DtdProcessing]::Ignore
        $xr = [System.Xml.XmlReader]::Create($inStream, $settings)

        $outSettings = New-Object System.Xml.XmlWriterSettings
        $outSettings.Encoding = New-Object System.Text.UTF8Encoding($false)
        $outSettings.OmitXmlDeclaration = $false
        $outSettings.Indent = $false
        $outSettings.NewLineHandling = [System.Xml.NewLineHandling]::None
        $outStream = [System.IO.File]::Open($tmp, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
        $xw = [System.Xml.XmlWriter]::Create($outStream, $outSettings)

        [void]$xr.Read()
        while (-not $xr.EOF) {
            if ($xr.NodeType -eq [System.Xml.XmlNodeType]::Element -and $xr.LocalName -eq 'row') {
                $r = 0
                [void][int]::TryParse((($xr.GetAttribute('r') + '')), [ref]$r)
                if ($r -gt 0 -and $patchesByRow.ContainsKey($r)) {
                    $rowXml = $xr.ReadOuterXml()
                    $patchedXml = Set-XlsxSaxRowPatchCells -RowXml $rowXml -PatchesForRow $patchesByRow[$r]
                    $xw.WriteRaw($patchedXml)
                    $patchedRows++
                    continue
                }
                $xw.WriteNode($xr, $true)
                continue
            }

            if ($xr.NodeType -eq [System.Xml.XmlNodeType]::Element) {
                $xw.WriteStartElement($xr.Prefix, $xr.LocalName, $xr.NamespaceURI)
                if ($xr.HasAttributes) {
                    while ($xr.MoveToNextAttribute()) {
                        $xw.WriteAttributeString($xr.Prefix, $xr.LocalName, $xr.NamespaceURI, $xr.Value)
                    }
                    $xr.MoveToElement() | Out-Null
                }
                if ($xr.IsEmptyElement) { $xw.WriteEndElement(); [void]$xr.Read(); continue }
                [void]$xr.Read()
                continue
            }
            elseif ($xr.NodeType -eq [System.Xml.XmlNodeType]::EndElement) {
                $xw.WriteFullEndElement()
                [void]$xr.Read()
                continue
            }
            else {
                $xw.WriteNode($xr, $false)
                continue
            }
        }
    } finally {
        try { if ($xw) { $xw.Close() } } catch {}
        try { if ($outStream) { $outStream.Dispose() } } catch {}
        try { if ($xr) { $xr.Close() } } catch {}
        try { if ($inStream) { $inStream.Dispose() } } catch {}
    }

    if ($patchedRows -le 0) {
        try { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue } catch {}
        throw 'SAX-patch hittade inte målraden i worksheet XML.'
    }

    try {
        $entry.Delete()
        $newEntry = $Archive.CreateEntry($EntryPath, [System.IO.Compression.CompressionLevel]::Optimal)
        $src = [System.IO.File]::Open($tmp, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
        $dst = $newEntry.Open()
        try { $src.CopyTo($dst) } finally { try { $dst.Dispose() } catch {}; try { $src.Dispose() } catch {} }
    } finally {
        try { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue } catch {}
    }

    return $patchedRows
}

function Invoke-XlsxRiskWorksheetSignature_Sax {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string[]]$SheetNameCandidates,
        [Parameter(Mandatory=$true)][string]$FullName,
        [Parameter(Mandatory=$true)][string]$SignDateYmd,
        [Parameter(Mandatory=$true)][string]$NameLabelCol,
        [Parameter(Mandatory=$true)][string]$NameNeedle,
        [Parameter(Mandatory=$true)][string]$NameWriteCol,
        [Parameter(Mandatory=$true)][string[]]$DateLabelCols,
        [Parameter(Mandatory=$true)][string]$DateNeedle,
        [Parameter(Mandatory=$true)][string]$DateWriteCol,
        [int]$Offset = 0,
        [bool]$Overwrite = $false,
        [int]$MaxRow = 150
    )

    Import-XlsxZipAssemblies
    $result = [pscustomobject]@{
        ActualSheetName = $null
        Written         = $false
        SkippedReason   = $null
        WrittenCells    = New-Object System.Collections.Generic.List[pscustomobject]
        Debug           = New-Object System.Collections.Generic.List[string]
    }

    $fs = $null
    $zip = $null
    try {
        $fs = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
        $zip = New-Object System.IO.Compression.ZipArchive($fs, [System.IO.Compression.ZipArchiveMode]::Update, $false)
        $info = Resolve-XlsxWorksheetEntryInfo_Sax -Archive $zip -SheetNames $SheetNameCandidates
        if (-not $info) {
            $result.SkippedReason = ('Saknas; provade: ' + (@($SheetNameCandidates) -join ', '))
            return $result
        }
        $result.ActualSheetName = ($info.SheetName + '')
        $sharedStrings = Read-XlsxSharedStrings_Sax -Archive $zip
        $scan = Get-XlsxSaxSheetScan -Archive $zip -EntryPath $info.EntryPath -SharedStrings $sharedStrings -MaxRow $MaxRow -CaptureCols @('K','L','M')

        $nameRow = Find-XlsxSaxFirstRowByContains -Scan $scan -ColLetter $NameLabelCol -Needle $NameNeedle -MinRow 1 -MaxRow $MaxRow
        $dateRow = $null
        foreach ($dc in @($DateLabelCols)) {
            $dateRow = Find-XlsxSaxFirstRowByContains -Scan $scan -ColLetter $dc -Needle $DateNeedle -MinRow 1 -MaxRow $MaxRow
            if ($dateRow) { break }
        }

        [void]$result.Debug.Add(("SAX sheet '{0}': nameRow={1}, dateRow={2}" -f $result.ActualSheetName, $(if($nameRow){$nameRow}else{'-'}), $(if($dateRow){$dateRow}else{'-'})))
        if (-not $nameRow -and -not $dateRow) {
            $result.SkippedReason = 'labels saknas'
            return $result
        }

        $patches = @{}
        $blocked = New-Object System.Collections.Generic.List[string]

        foreach ($field in @(
            @{ Kind='Name'; Row=$nameRow; WriteCol=$NameWriteCol; Value=$FullName },
            @{ Kind='Date'; Row=$dateRow; WriteCol=$DateWriteCol; Value=$SignDateYmd }
        )) {
            if (-not $field.Row) { continue }
            $writeRow = [int]$field.Row + [int]$Offset
            if ($writeRow -lt 1) { continue }
            if (-not $scan.RowExists.ContainsKey($writeRow)) {
                throw ("SAX-signering: målraden {0} saknas i flik '{1}'." -f $writeRow, $result.ActualSheetName)
            }
            $targetRef = ((($field.WriteCol + '').Trim().ToUpperInvariant()) + $writeRow)
            $ownerRef = Resolve-XlsxSaxMergeOwner -CellRef $targetRef -Scan $scan
            $ownerInfo = Split-OpenXmlCellRef -CellRef $ownerRef
            if (-not $ownerInfo) { throw "SAX-signering: kunde inte lösa merge-owner för $targetRef." }
            $groupRefs = @(Get-XlsxSaxMergeGroupOwnerRowRefs -OwnerRef $ownerInfo.Ref -Scan $scan)

            if (-not $Overwrite) {
                $isBlocked = $false
                foreach ($gr in $groupRefs) {
                    $existing = ''
                    if ($scan.CellText.ContainsKey($gr)) { $existing = ($scan.CellText[$gr] + '') }
                    if (-not (Test-OpenXmlTreatAsBlankText -Text $existing)) {
                        [void]$blocked.Add(('{0} redan ifylld i {1}' -f $field.Kind, $gr))
                        $isBlocked = $true
                        break
                    }
                }
                if ($isBlocked) { continue }
            }

            $patches[$ownerInfo.Ref] = ($field.Value + '')
            if ($Overwrite) {
                foreach ($gr in $groupRefs) {
                    if ($gr -eq $ownerInfo.Ref) { continue }
                    $patches[$gr] = 'N/A'
                }
            }
            [void]$result.WrittenCells.Add([pscustomobject]@{ Sheet=$result.ActualSheetName; Row=[int]$ownerInfo.Row; Col=($ownerInfo.Col + ''); Value=($field.Value + '') })
        }

        if ($patches.Count -le 0) {
            if ($blocked.Count -gt 0) { $result.SkippedReason = 'redan ifyllt' }
            else { $result.SkippedReason = 'inga skrivbara celler' }
            return $result
        }

        [void](Update-XlsxWorksheetEntryRows_Sax -Archive $zip -EntryPath $info.EntryPath -PatchesByRef $patches)
        $result.Written = $true
        return $result
    } finally {
        try { if ($zip) { $zip.Dispose() } } catch {}
        try { if ($fs) { $fs.Dispose() } } catch {}
    }
}

function Resolve-XlsxRiskWorksheetSignatureRows_Sax {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string[]]$SheetNameCandidates,
        [Parameter(Mandatory=$true)][string]$NameLabelCol,
        [Parameter(Mandatory=$true)][string]$NameNeedle,
        [Parameter(Mandatory=$true)][string[]]$DateLabelCols,
        [Parameter(Mandatory=$true)][string]$DateNeedle,
        [int]$MaxRow = 150
    )
    Import-XlsxZipAssemblies
    $fs = $null
    $zip = $null
    try {
        $fs = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        $zip = New-Object System.IO.Compression.ZipArchive($fs, [System.IO.Compression.ZipArchiveMode]::Read, $false)
        $info = Resolve-XlsxWorksheetEntryInfo_Sax -Archive $zip -SheetNames $SheetNameCandidates
        if (-not $info) { return [pscustomobject]@{ ActualSheetName=$null; NameRow=$null; DateRow=$null; Missing=$true } }
        $sharedStrings = Read-XlsxSharedStrings_Sax -Archive $zip
        $scan = Get-XlsxSaxSheetScan -Archive $zip -EntryPath $info.EntryPath -SharedStrings $sharedStrings -MaxRow $MaxRow -CaptureCols @('K','L','M')
        $nameRow = Find-XlsxSaxFirstRowByContains -Scan $scan -ColLetter $NameLabelCol -Needle $NameNeedle -MinRow 1 -MaxRow $MaxRow
        $dateRow = $null
        foreach ($dc in @($DateLabelCols)) {
            $dateRow = Find-XlsxSaxFirstRowByContains -Scan $scan -ColLetter $dc -Needle $DateNeedle -MinRow 1 -MaxRow $MaxRow
            if ($dateRow) { break }
        }
        return [pscustomobject]@{ ActualSheetName=($info.SheetName + ''); NameRow=$nameRow; DateRow=$dateRow; Missing=$false }
    } finally {
        try { if ($zip) { $zip.Dispose() } } catch {}
        try { if ($fs) { $fs.Dispose() } } catch {}
    }
}

function Verify-XlsxWorksheetCells_Sax {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][object[]]$WrittenCells
    )
    $result = [pscustomobject]@{
        OK             = $false
        CellsChecked   = 0
        CellsVerified  = 0
        Mismatches     = New-Object System.Collections.Generic.List[string]
        Error          = $null
    }
    if (-not $WrittenCells -or $WrittenCells.Count -eq 0) { $result.OK = $true; return $result }

    Import-XlsxZipAssemblies
    $fs = $null
    $zip = $null
    try {
        $fs = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        $zip = New-Object System.IO.Compression.ZipArchive($fs, [System.IO.Compression.ZipArchiveMode]::Read, $false)

        $bySheet = @{}
        foreach ($wc in @($WrittenCells)) {
            $s = ($wc.Sheet + '')
            if (-not $bySheet.ContainsKey($s)) { $bySheet[$s] = New-Object System.Collections.Generic.List[object] }
            [void]$bySheet[$s].Add($wc)
        }

        foreach ($sheetName in @($bySheet.Keys)) {
            $info = Resolve-XlsxWorksheetEntryInfo_Sax -Archive $zip -SheetNames @($sheetName)
            if (-not $info) {
                foreach ($wcMissing in @($bySheet[$sheetName].ToArray())) {
                    $result.CellsChecked++
                    [void]$result.Mismatches.Add("$sheetName $($wcMissing.Col)$($wcMissing.Row): Fliken hittades inte")
                }
                continue
            }
            $sharedStrings = Read-XlsxSharedStrings_Sax -Archive $zip
            $cols = New-Object System.Collections.Generic.List[string]
            foreach ($wcCol in @($bySheet[$sheetName].ToArray())) {
                $c = (($wcCol.Col + '').Trim().ToUpperInvariant())
                if ($c -and (-not $cols.Contains($c))) { [void]$cols.Add($c) }
            }
            $maxRow = 1
            foreach ($wcRow in @($bySheet[$sheetName].ToArray())) { if ([int]$wcRow.Row -gt $maxRow) { $maxRow = [int]$wcRow.Row } }
            if ($maxRow -lt 150) { $maxRow = 150 }
            $scan = Get-XlsxSaxSheetScan -Archive $zip -EntryPath $info.EntryPath -SharedStrings $sharedStrings -MaxRow $maxRow -CaptureCols @($cols.ToArray())
            foreach ($wc in @($bySheet[$sheetName].ToArray())) {
                $result.CellsChecked++
                $cellRef = ((($wc.Col + '').Trim().ToUpperInvariant()) + [int]$wc.Row)
                $actual = ''
                if ($scan.CellText.ContainsKey($cellRef)) { $actual = Normalize-OpenXmlText ($scan.CellText[$cellRef] + '') }
                $expected = (($wc.Value + '').Trim())
                if (($actual + '').Trim() -eq $expected) { $result.CellsVerified++ }
                else { [void]$result.Mismatches.Add("$sheetName $cellRef: Förväntade='$expected' Faktisk='$actual'") }
            }
        }
        $result.OK = ($result.Mismatches.Count -eq 0 -and $result.CellsVerified -eq $WrittenCells.Count)
    } catch {
        $result.Error = ($_.Exception.Message + '')
    } finally {
        try { if ($zip) { $zip.Dispose() } } catch {}
        try { if ($fs) { $fs.Dispose() } } catch {}
    }
    return $result
}
