Kontrollprovsfil v2.6 originalbaserad + checked
================================================

Denna version bygger på användarens fungerande originalscript kontrollprovsfil_v20260525.ps1.
Den ersätter inte Excel/EPPlus-läsningen med den nya v3-arkitekturen som gav "Argument types do not match".

Ändringar jämfört med original:

1. Nytt val på radnivå:
   4: Mark as checked
   - Uppdaterar endast Senast inventering och SIGN.
   - Lotnr., Utgångsdatum och Antal i lager lämnas orörda.
   - Loggas som Action = CHECK.

2. Nytt val på P/N-nivå:
   A: Markera alla aktiva poster för detta P/N som checked
   - Gäller bara aktiva rader där P/N, Lot, Exp och Qty inte är tomma/N/A.
   - Uppdaterar endast Senast inventering och SIGN per aktiv rad.
   - Loggar en CHECK-rad per aktiv rad.

3. Loggning:
   - Write-UpdateLogRow skriver bara till huvudloggen.
   - Ingen ny SPOOL- eller EMERGENCY-logg skapas vid loggfel.
   - AutoRepairUpdateLog är satt till false som standard, så en korrupt logg stoppas i stället för att flyttas/ersättas automatiskt.

Viktigt:
- Detta är avsiktligt en minimal ändring ovanpå originalet.
- Testa först mot kopia av raw_data.xlsx.
- Om loggen redan är korrupt eller har fel header kommer scriptet stoppa vid start.
