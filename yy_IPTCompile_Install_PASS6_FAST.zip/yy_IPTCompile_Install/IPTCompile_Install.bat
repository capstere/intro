@echo off
setlocal EnableExtensions
REM ------------------------------------------------------------
REM IPTCompile - Installera lokal launcher (kör EN gång)
REM ------------------------------------------------------------
call "%~dp0Launcher\Install.bat"
exit /b %ERRORLEVEL%
