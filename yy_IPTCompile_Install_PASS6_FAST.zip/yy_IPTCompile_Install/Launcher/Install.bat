@echo off
setlocal EnableExtensions EnableDelayedExpansion

REM ------------------------------------------------------------
REM IPTCompile - Installera lokal launcher (kör EN gång från nätet)
REM - Kopierar denna launcher-mapp till C:\IPTCompileLauncher
REM - Skriver LauncherSource.txt (nät-sökvägen till denna mapp)
REM - Skapar en skrivbordsgenväg som kör lokalt via Run.ps1
REM ------------------------------------------------------------

set "APPNAME=IPTCompile"
set "LOCAL_LAUNCHER_ROOT=C:\IPTCompileLauncher"
set "LOCAL_CACHE_ROOT=C:\IPTCompile"

REM Nätets launcher-mapp = där denna Install.bat ligger
set "NET_LAUNCHER_ROOT=%~dp0"
if "%NET_LAUNCHER_ROOT:~-1%"=="\" set "NET_LAUNCHER_ROOT=%NET_LAUNCHER_ROOT:~0,-1%"

echo [%APPNAME%] Installerar lokal launcher...
echo   NET_LAUNCHER_ROOT   = "%NET_LAUNCHER_ROOT%"
echo   LOCAL_LAUNCHER_ROOT = "%LOCAL_LAUNCHER_ROOT%"

if not exist "%LOCAL_LAUNCHER_ROOT%" (
  mkdir "%LOCAL_LAUNCHER_ROOT%" >nul 2>&1
)

REM Kopiera launchern lokalt (robust på SMB)
robocopy "%NET_LAUNCHER_ROOT%" "%LOCAL_LAUNCHER_ROOT%" /E /R:2 /W:1 /XO /FFT /XJ /NP /NFL /NDL >nul
set "RC=%ERRORLEVEL%"

REM Robocopy: 0-7 OK, 8+ fel
if %RC% GEQ 8 (
  echo [%APPNAME%] ERROR: Robocopy misslyckades med kod %RC%.
  exit /b %RC%
)

REM Skriv varifrån vi ska själv-uppdatera launchern vid start
> "%LOCAL_LAUNCHER_ROOT%\LauncherSource.txt" echo %NET_LAUNCHER_ROOT%

REM Snabbvalidering
if not exist "%LOCAL_LAUNCHER_ROOT%\Run.ps1" (
  echo [%APPNAME%] ERROR: Saknar Run.ps1 efter kopiering.
  exit /b 10
)
if not exist "%LOCAL_LAUNCHER_ROOT%\Launcher.ps1" (
  echo [%APPNAME%] ERROR: Saknar Launcher.ps1 efter kopiering.
  exit /b 11
)
if not exist "%LOCAL_LAUNCHER_ROOT%\Create-DesktopShortcut.ps1" (
  echo [%APPNAME%] ERROR: Saknar Create-DesktopShortcut.ps1 efter kopiering.
  exit /b 12
)
if not exist "%LOCAL_LAUNCHER_ROOT%\SourcePath.txt" (
  echo [%APPNAME%] ERROR: Saknar SourcePath.txt efter kopiering.
  exit /b 13
)

echo [%APPNAME%] Skapar skrivbordsgenvag...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%LOCAL_LAUNCHER_ROOT%\Create-DesktopShortcut.ps1" ^
  -ShortcutName "%APPNAME% (Local)" ^
  -LauncherPs1 "%LOCAL_LAUNCHER_ROOT%\Run.ps1" ^
  -WorkingDir "%LOCAL_CACHE_ROOT%"

if errorlevel 1 (
  echo [%APPNAME%] ERROR: Kunde inte skapa genvag.
  exit /b 14
)

echo [%APPNAME%] Klart!
echo Starta via skrivbordsgenvagen: "%APPNAME% (Local)"
exit /b 0
