﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# ----------------------------- Settings -----------------------------
$AppName            = 'IPTCompile'
$CacheRoot          = 'C:\IPTCompile'
$AuditFolderName    = '_LauncherAudit'
$VersionFileName    = 'Version.txt'
$SourcePathFileName = 'SourcePath.txt'
$ForceUpdateFileName = 'ForceUpdate.txt'

$RoboCopyMT   = 8
$RoboRetries  = 2
$RoboWaitSec  = 1

$ExcludeDirs = @($AuditFolderName, '_LocalLauncherAudit', 'Loggar', 'audit')

# ----------------------------- Helpers -----------------------------
function Get-ScriptDir {
    if ($PSScriptRoot) { return $PSScriptRoot }
    if ($PSCommandPath) { return (Split-Path -LiteralPath $PSCommandPath -Parent) }
    return (Get-Location).Path
}

function Read-FirstNonEmptyLine([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    foreach ($line in [System.IO.File]::ReadAllLines($Path)) {
        $t = ($line + '').Trim()
        if ($t) {
            if ($t.StartsWith('"') -and $t.EndsWith('"') -and $t.Length -ge 2) {
                $t = $t.Substring(1, $t.Length - 2)
            }
            return $t.Trim()
        }
    }
    return $null
}

function Ensure-DirWritable([string]$Path) {
    try {
        if (-not (Test-Path -LiteralPath $Path)) {
            New-Item -Path $Path -ItemType Directory -Force | Out-Null
        }
        $probe = Join-Path $Path ("._probe_{0}.tmp" -f [Guid]::NewGuid().ToString('N'))
        [System.IO.File]::WriteAllText($probe, 'ok')
        Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
        return $true
    } catch {
        return $false
    }
}

function Normalize-Version([string]$v) {
    $t = ($v + '').Trim()
    if (-not $t) { return '0' }
    return $t
}

function Resolve-NetworkPath([string]$Path) {
    $p = ($Path + '').Trim()
    if (-not $p) { return $Path }

    if ($p -match '^[A-Za-z]:\\') {
        try {
            $drive = $p.Substring(0,2)
            $ld = Get-WmiObject -Class Win32_LogicalDisk -Filter ("DeviceID='{0}'" -f $drive) -ErrorAction Stop
            if ($ld -and $ld.ProviderName) {
                return ($ld.ProviderName + $p.Substring(2))
            }
        } catch {
            # best-effort
        }
    }
    return $p
}

function Write-Audit {
    param(
        [string]$AuditDir,
        [string]$Message,
        [ValidateSet('INFO','WARN','ERROR')] [string]$Level = 'INFO'
    )
    $ts = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $line = '[{0}] [{1}] {2}' -f $ts, $Level, $Message

    Write-Host $line
    if (-not $AuditDir) { return }

    try {
        if (-not (Test-Path -LiteralPath $AuditDir)) {
            New-Item -Path $AuditDir -ItemType Directory -Force | Out-Null
        }
        $logPath = Join-Path $AuditDir 'Launcher.log'
        Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
    } catch {
    }
}

function Get-LogTail([string]$Path, [int]$Lines = 30) {
    try {
        if ($Path -and (Test-Path -LiteralPath $Path)) {
            return (Get-Content -LiteralPath $Path -Tail $Lines -ErrorAction Stop) -join [Environment]::NewLine
        }
    } catch { }
    return $null
}

function Invoke-Robocopy {
    param(
        [string]$Source,
        [string]$Dest,
        [string[]]$ExcludeDirectories,
        [string[]]$ExcludeFiles,
        [string]$LogFile,
        [int]$MultiThread = $RoboCopyMT,
        [int]$Retries = $RoboRetries,
        [int]$WaitSec = $RoboWaitSec,
        [switch]$Restartable
    )

    # NOTE: Do NOT name this $args — it shadows the PS automatic variable.
    $roboArgs = New-Object System.Collections.Generic.List[string]
    $roboArgs.Add("`"$Source`"")
    $roboArgs.Add("`"$Dest`"")
    $roboArgs.Add('/MIR')
    $roboArgs.Add("/R:$Retries")
    $roboArgs.Add("/W:$WaitSec")
    $roboArgs.Add('/FFT')
    $roboArgs.Add('/XJ')
    $roboArgs.Add('/NP')
    $roboArgs.Add('/NFL')
    $roboArgs.Add('/NDL')
    
    if ($Restartable) { $roboArgs.Add('/Z') }

    if ($MultiThread -gt 1) { $roboArgs.Add("/MT:$MultiThread") }

    foreach ($xd in ($ExcludeDirectories | Where-Object { $_ })) {
        $roboArgs.Add('/XD')
        $roboArgs.Add("`"$xd`"")
    }

    foreach ($xf in ($ExcludeFiles | Where-Object { $_ })) {
        $roboArgs.Add('/XF')
        $roboArgs.Add("`"$xf`"")
    }

    if ($LogFile) {
        $roboArgs.Add("/LOG:`"$LogFile`"")
    }

    $p = Start-Process -FilePath 'robocopy.exe' -ArgumentList $roboArgs.ToArray() -Wait -PassThru -WindowStyle Hidden
    return $p.ExitCode
}

function Invoke-RobocopyWithRetry {
    param(
        [string]$Source,
        [string]$Dest,
        [string[]]$ExcludeDirectories,
        [string[]]$ExcludeFiles,
        [string]$LogFile,
        [string]$AuditDir
    )

    $rc = Invoke-Robocopy -Source $Source -Dest $Dest -ExcludeDirectories $ExcludeDirectories -ExcludeFiles $ExcludeFiles -LogFile $LogFile `
        -MultiThread $RoboCopyMT -Retries $RoboRetries -WaitSec $RoboWaitSec

    if ($rc -lt 8) { return $rc }

    $tail = Get-LogTail -Path $LogFile -Lines 20
    if ($tail) {
        Write-Audit -AuditDir $AuditDir -Level WARN -Message ("Robocopy misslyckades (kod=$rc). Sista loggrader:`n$tail")
    } else {
        Write-Audit -AuditDir $AuditDir -Level WARN -Message ("Robocopy misslyckades (kod=$rc). Försöker igen med säkrare inställningar…")
    }

    Start-Sleep -Seconds 2

    $rc = Invoke-Robocopy -Source $Source -Dest $Dest -ExcludeDirectories $ExcludeDirectories -ExcludeFiles $ExcludeFiles -LogFile $LogFile `
        -MultiThread 1 -Retries 5 -WaitSec 2 -Restartable

    return $rc
}


function Test-FolderNeedsUpdate {
    param(
        [Parameter(Mandatory=$true)][string]$SourceDir,
        [Parameter(Mandatory=$true)][string]$DestDir,
        [string[]]$IncludeFilters = @('*')
    )
    try {
        if (-not (Test-Path -LiteralPath $SourceDir)) { return $false }
        if (-not (Test-Path -LiteralPath $DestDir)) { return $true }

        foreach ($filter in $IncludeFilters) {
            $src = Get-ChildItem -LiteralPath $SourceDir -Recurse -File -Filter $filter -ErrorAction SilentlyContinue
            foreach ($s in $src) {
                $rel = $s.FullName.Substring($SourceDir.Length).TrimStart('\')
                $d = Join-Path $DestDir $rel
                if (-not (Test-Path -LiteralPath $d)) { return $true }
                $di = Get-Item -LiteralPath $d -ErrorAction SilentlyContinue
                if (-not $di) { return $true }
                if ($s.Length -ne $di.Length) { return $true }
                if ($s.LastWriteTimeUtc -gt $di.LastWriteTimeUtc) { return $true }
            }
        }
    } catch {
        return $true
    }
    return $false
}


function Test-CacheHasRequiredProjectFiles {
    param(
        [Parameter(Mandatory=$true)][string]$SourceDir,
        [Parameter(Mandatory=$true)][string]$DestDir,
        [string]$AuditDir
    )

    $required = New-Object System.Collections.Generic.List[string]
    [void]$required.Add('Main.ps1')

    # Adaptiv PASS6-kontroll: kräv bara nya refactor-filer om de finns i källan.
    foreach ($rel in @(
        'App\BuildReportFlow.ps1',
        'App\BuildFlow',
        'App\MainWindow.ps1',
        'Core',
        'Infrastructure',
        'Modules',
        'Lib'
    )) {
        try {
            if (Test-Path -LiteralPath (Join-Path $SourceDir $rel)) {
                [void]$required.Add($rel)
            }
        } catch {}
    }

    $missing = New-Object System.Collections.Generic.List[string]
    foreach ($rel in $required) {
        try {
            if (-not (Test-Path -LiteralPath (Join-Path $DestDir $rel))) {
                [void]$missing.Add($rel)
            }
        } catch {
            [void]$missing.Add($rel)
        }
    }

    if ($missing.Count -gt 0) {
        Write-Audit -AuditDir $AuditDir -Level ERROR -Message ('Cache saknar obligatoriska projektfiler: {0}' -f (($missing.ToArray()) -join ', '))
        return $false
    }

    return $true
}

function Get-PowerShellExe {
    $sysnative = Join-Path $env:WINDIR 'sysnative\WindowsPowerShell\v1.0\powershell.exe'
    if ([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess -and (Test-Path -LiteralPath $sysnative)) {
        return $sysnative
    }
    return (Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe')
}

function Invoke-IptMain {
    param(
        [string]$MainPath
    )

    if ([string]::IsNullOrWhiteSpace($MainPath)) {
        throw "Invoke-IptMain: MainPath saknas."
    }

    if ($script:SourceRoot) { $env:IPT_NETWORK_ROOT = $script:SourceRoot }

    $exe = Get-PowerShellExe

    $full = [System.IO.Path]::GetFullPath($MainPath)
    $wd   = [System.IO.Path]::GetDirectoryName($full)

    Push-Location -LiteralPath $wd
    try {
        & $exe -NoProfile -ExecutionPolicy Bypass -File $full
        $rc = $LASTEXITCODE
    } finally {
        Pop-Location
    }
    exit $rc
}

# ----------------------------- Main -----------------------------
$scriptDir = Get-ScriptDir
$srcFile   = Join-Path $scriptDir $SourcePathFileName
$script:SourceRoot = Read-FirstNonEmptyLine -Path $srcFile

if (-not $script:SourceRoot) {
    Write-Host '[ERROR] SourcePath.txt saknas eller är tom bredvid Launcher.ps1'
    exit 1
}

$script:SourceRoot = Resolve-NetworkPath $script:SourceRoot
$script:SourceRoot = $script:SourceRoot.TrimEnd('\')
$mainNet = Join-Path $script:SourceRoot 'Main.ps1'
$mainLocalEarly = Join-Path $CacheRoot 'Main.ps1'
$sourceAvailable = Test-Path -LiteralPath $mainNet

# Snabb och robust fallback:
# Om nätkällan inte är nåbar men lokal cache finns, starta lokal cache direkt.
# Detta undviker att en kort nätstörning gör att användaren inte kan starta IPTCompile.
if (-not $sourceAvailable) {
    Write-Host ('[WARN] Källsökväg saknar/når inte Main.ps1: {0}' -f $script:SourceRoot)
    if (Test-Path -LiteralPath $mainLocalEarly) {
        Write-Host ('[WARN] Kör befintlig lokal cache: {0}' -f $mainLocalEarly)
        Invoke-IptMain -MainPath $mainLocalEarly
    }
    exit 1
}

$auditDir = Join-Path $script:SourceRoot $AuditFolderName
Write-Audit -AuditDir $auditDir -Level INFO -Message ('Launcher start. SourceRoot={0}' -f $script:SourceRoot)

if (-not (Ensure-DirWritable -Path $CacheRoot)) {
    Write-Audit -AuditDir $auditDir -Level ERROR -Message ('Kunde inte skapa skrivbar cachemapp: {0}. Kör från nätverket.' -f $CacheRoot)
    Invoke-IptMain -MainPath $mainNet
}

$dest  = $CacheRoot
$rbLog = Join-Path $auditDir 'robocopy_last.log'

try {
    $srcFull  = [System.IO.Path]::GetFullPath($script:SourceRoot)
    $destFull = [System.IO.Path]::GetFullPath($dest)
    if ($destFull.StartsWith($srcFull, [System.StringComparison]::OrdinalIgnoreCase) -or
        $srcFull.StartsWith($destFull, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw ('Säkerhetskontroll: käll- och cachesökväg överlappar. Source={0} Cache={1}' -f $srcFull, $destFull)
    }
} catch {
    Write-Audit -AuditDir $auditDir -Level ERROR -Message $_.Exception.Message
    Invoke-IptMain -MainPath $mainNet
}

# ---- Snabb versionsbaserad cachekontroll ----
# Start ska vara snabb för användare. Därför speglas inte hela projektträdet varje start.
# Deployment-regel: bumpa Version.txt när nätversionen ska rullas ut.
# ForceUpdate.txt i källroten kan också användas för att tvinga cacheuppdatering.
$netVerPath = Join-Path $script:SourceRoot $VersionFileName
$locVerPath = Join-Path $dest $VersionFileName

$vNet = Normalize-Version (Read-FirstNonEmptyLine -Path $netVerPath)
$vLoc = Normalize-Version (Read-FirstNonEmptyLine -Path $locVerPath)

$versionChanged = $false
if (Test-Path -LiteralPath $netVerPath) {
    if ($vNet -ne $vLoc) { $versionChanged = $true }
}

$forceUpdate = Test-Path -LiteralPath (Join-Path $script:SourceRoot $ForceUpdateFileName)

$localMain = Join-Path $dest 'Main.ps1'
$cacheReady = $false
if (Test-Path -LiteralPath $localMain) {
    $cacheReady = Test-CacheHasRequiredProjectFiles -SourceDir $script:SourceRoot -DestDir $dest -AuditDir $auditDir
}

# Fast path: om versionen är samma och cachen har nödvändiga filer, starta direkt.
# Ingen robocopy, ingen rekursiv Modules/Lib-scan.
if ($cacheReady -and (-not $versionChanged) -and (-not $forceUpdate)) {
    Write-Audit -AuditDir $auditDir -Level INFO -Message ('Fast start: lokal cache OK. Version={0}' -f $vLoc)
    Invoke-IptMain -MainPath $localMain
}

# Om vi hamnar här behövs uppdatering eller cache-reparation.
$needScriptTreeCopy = ($versionChanged -or $forceUpdate -or (-not $cacheReady))

$srcModules = Join-Path $script:SourceRoot 'Modules'
$dstModules = Join-Path $dest 'Modules'
$needModulesCopy = ((Test-Path -LiteralPath $srcModules) -and ($versionChanged -or $forceUpdate -or (-not (Test-Path -LiteralPath $dstModules)) -or (-not $cacheReady)))

$srcLib = Join-Path $script:SourceRoot 'Lib'
$dstLib = Join-Path $dest 'Lib'
$needLibCopy = ((Test-Path -LiteralPath $srcLib) -and ($versionChanged -or $forceUpdate -or (-not (Test-Path -LiteralPath $dstLib)) -or (-not $cacheReady)))

$mutexName = ('Global\{0}_CacheUpdate' -f $AppName)
try {
    $mutex = New-Object System.Threading.Mutex($false, $mutexName)
} catch {
    $mutexName = ('Local\{0}_CacheUpdate' -f $AppName)
    $mutex = New-Object System.Threading.Mutex($false, $mutexName)
}

$haveMutex = $false

try {
    $haveMutex = $mutex.WaitOne(25000)
    if (-not $haveMutex) {
        Write-Audit -AuditDir $auditDir -Level WARN -Message 'Cache-uppdatering låst av annan instans. Kör befintlig cache om möjligt.'
        if ((Test-Path -LiteralPath $localMain) -and (Test-CacheHasRequiredProjectFiles -SourceDir $script:SourceRoot -DestDir $dest -AuditDir $auditDir)) {
            Invoke-IptMain -MainPath $localMain
        } else {
            Write-Audit -AuditDir $auditDir -Level WARN -Message 'Befintlig cache är ofullständig; kör från nätverket.'
            Invoke-IptMain -MainPath $mainNet
        }
    }

    if ($needScriptTreeCopy -or $needModulesCopy -or $needLibCopy) {
        $installLock = Join-Path $dest '.install.lock'
        try { Set-Content -LiteralPath $installLock -Value (Get-Date).ToString('s') -Encoding ASCII -Force } catch {}
        try {
            Write-Audit -AuditDir $auditDir -Level INFO -Message ('Cache-uppdatering. Dest={0} vNet={1} vLoc={2} versionChanged={3} force={4} scriptTreeCopy={5} modulesCopy={6} libCopy={7}' -f $dest, $vNet, $vLoc, $versionChanged, $forceUpdate, $needScriptTreeCopy, $needModulesCopy, $needLibCopy)

            if (-not (Test-Path -LiteralPath $dest)) {
                New-Item -Path $dest -ItemType Directory -Force | Out-Null
            }

            # Steg 1: Spegla script-trädet endast när version/cache kräver det.
            # Exkludera Modules/Lib; de hanteras separat.
            if ($needScriptTreeCopy) {
                $xDirs = New-Object System.Collections.Generic.List[string]
                foreach ($xd in $ExcludeDirs) {
                    [void]$xDirs.Add((Join-Path $script:SourceRoot $xd))
                }
                [void]$xDirs.Add((Join-Path $script:SourceRoot 'Modules'))
                [void]$xDirs.Add((Join-Path $script:SourceRoot 'Lib'))

                $rc = Invoke-RobocopyWithRetry -Source $script:SourceRoot -Dest $dest -ExcludeDirectories $xDirs.ToArray() -LogFile $rbLog -AuditDir $auditDir
                Write-Audit -AuditDir $auditDir -Level INFO -Message ('Robocopy (skript) exitkod={0} (0-7 OK, 8+ fel). Logg={1}' -f $rc, $rbLog)

                if ($rc -ge 8) {
                    if (Test-Path -LiteralPath $localMain) {
                        Write-Audit -AuditDir $auditDir -Level WARN -Message ('Robocopy misslyckades (kod={0}). Kör befintlig cache: {1}' -f $rc, $dest)
                    } else {
                        Write-Audit -AuditDir $auditDir -Level ERROR -Message ('Robocopy misslyckades (kod={0}). Ingen lokal cache – kör från nätverket.' -f $rc)
                        Invoke-IptMain -MainPath $mainNet
                    }
                }
            }

            # Steg 2: Spegla Modules endast när version/cache kräver det.
            if ($needModulesCopy) {
                $rbLogMod = Join-Path $auditDir 'robocopy_modules_ps1.log'
                if (Test-Path -LiteralPath $srcModules) {
                    Write-Audit -AuditDir $auditDir -Level INFO -Message 'Speglar Modules.'
                    $rcMod = Invoke-RobocopyWithRetry -Source $srcModules -Dest $dstModules -ExcludeFiles @('*.dll','*.txt','*.xlsx','*.xlsm') -LogFile $rbLogMod -AuditDir $auditDir
                    Write-Audit -AuditDir $auditDir -Level INFO -Message ('Robocopy (Modules) exitkod={0}.' -f $rcMod)
                }
            }

            # Steg 3: Uppdatera Lib endast när version/cache kräver det.
            if ($needLibCopy) {
                $rbLogLib = Join-Path $auditDir 'robocopy_lib.log'
                if (Test-Path -LiteralPath $srcLib) {
                    Write-Audit -AuditDir $auditDir -Level INFO -Message 'Uppdaterar Lib.'
                    $rcLib = Invoke-RobocopyWithRetry -Source $srcLib -Dest $dstLib -LogFile $rbLogLib -AuditDir $auditDir
                    Write-Audit -AuditDir $auditDir -Level INFO -Message ('Robocopy (Lib) exitkod={0}.' -f $rcLib)
                } else {
                    Write-Audit -AuditDir $auditDir -Level WARN -Message 'Lib saknas i källan. Hoppar över.'
                }
            }

            if (-not (Test-CacheHasRequiredProjectFiles -SourceDir $script:SourceRoot -DestDir $dest -AuditDir $auditDir)) {
                Write-Audit -AuditDir $auditDir -Level ERROR -Message 'Lokal cache är ofullständig efter uppdatering. Kör från nätverket.'
                Invoke-IptMain -MainPath $mainNet
            }
        } finally {
            try { Remove-Item -LiteralPath $installLock -Force -ErrorAction SilentlyContinue } catch {}
        }
    }

} finally {
    if ($haveMutex) { try { $mutex.ReleaseMutex() } catch { } }
    $mutex.Dispose()
}

$mainLocalFinal = Join-Path $dest 'Main.ps1'

if ((Test-Path -LiteralPath $mainLocalFinal) -and (Test-CacheHasRequiredProjectFiles -SourceDir $script:SourceRoot -DestDir $dest -AuditDir $auditDir)) {
    Write-Audit -AuditDir $auditDir -Level INFO -Message ('Kör lokalt: {0}' -f $mainLocalFinal)
    Invoke-IptMain -MainPath $mainLocalFinal
} else {
    Write-Audit -AuditDir $auditDir -Level WARN -Message ('Lokal cache saknar Main.ps1 eller refactor-filer; kör från nätverket: {0}' -f $mainNet)
    Invoke-IptMain -MainPath $mainNet
}
