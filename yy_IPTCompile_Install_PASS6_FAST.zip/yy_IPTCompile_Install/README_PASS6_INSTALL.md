# IPTCompile launcher installer — PASS6-kompatibel snabbstart

Denna installer installerar bara den lokala launchern.
Den riktiga IPTCompile-källan anges i `Launcher/SourcePath.txt`.

## PASS6
PASS6-refaktorn använder fler mappar än tidigare, bland annat:

- `App/BuildFlow/`
- `Core/`
- `Infrastructure/`
- `Rules/`

Launchern validerar därför att lokal cache `C:\IPTCompile` innehåller nödvändiga PASS6-filer innan den startar lokalt.

## Snabbstart-princip
För att inte användare ska behöva vänta vid varje start gör launchern nu en snabb cachekontroll:

1. Om `Version.txt` är samma i nätkällan och lokal cache.
2. Om lokal cache innehåller obligatoriska filer/mappar.
3. Om `ForceUpdate.txt` inte finns i källroten.

Då startar IPTCompile direkt från `C:\IPTCompile` utan robocopy.

## När uppdateras lokal cache?
Cache uppdateras när:

- `Version.txt` ändras.
- lokal cache saknar nödvändiga filer/mappar.
- `ForceUpdate.txt` finns i källroten.
- `Modules` eller `Lib` saknas lokalt efter versionsbyte/cache-reparation.

## Deployment-regel
När du vill rulla ut en ny version till användare:

1. Uppdatera IPTCompile-källmappen.
2. Bumpa `Version.txt`.
3. Nästa start kopierar användarna ny version till `C:\IPTCompile`.

Om du behöver tvinga uppdatering utan versionsbyte, skapa en tom fil i källroten:

`ForceUpdate.txt`

Ta bort den efter utrullningen, annars uppdateras cache varje start.

## Användning
1. Kontrollera att `Launcher/SourcePath.txt` pekar på aktuell IPTCompile-källmapp.
2. Kör `IPTCompile_Install.bat` en gång.
3. Starta via skrivbordsgenvägen `IPTCompile (Local)`.

## Lokal cache
Launchern kopierar IPTCompile till:

`C:\IPTCompile`

Loggar skrivs lokalt först och speglas tillbaka till källans `Loggar` om möjligt.
