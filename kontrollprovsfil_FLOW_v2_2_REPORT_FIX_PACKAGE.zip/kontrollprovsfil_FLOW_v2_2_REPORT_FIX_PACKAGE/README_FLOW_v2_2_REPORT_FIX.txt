Kontrollprovsfil - FLOW v2.2 REPORT FIX
=======================================

Kort sammanfattning
-------------------
Denna version återställer/förbättrar alla huvudmenyfunktioner från FLOW v2, men behåller robust CSV-auditlogg.

Viktigt:
- UpdateLog_Kontrollprovsfil.csv är fortfarande den enda audit-loggen.
- InventoryReport_yyyyMMdd.xlsx och ExpiringPNsReport_yyyyMMdd.xlsx är rapporter, inte loggfiler.
- InventoryReport filtrerar nu bort rader där PN, Lot, Exp eller Qty är tomt/N/A/NA/N.A./-.
- ExpiringPNsReport använder samma aktiva-rad-filter.
- Visa materialinformation för produkt använder också samma aktiva-rad-filter.
- Feedback sparas nu i Feedback_Kontrollprovsfil.csv, separat från audit-loggen.

Rekommenderat test
------------------
Kör först mot en kopia av raw_data.xlsx/raw_data.xlsm:

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\TEMP\kontrollprovsfil_v20260305_FLOW_v2_2_REPORT_FIX.ps1" -RawDataPath "C:\TEMP\raw_data.xlsx" -OutputDir "C:\TEMP\Rapporter"

Testa huvudmenyn:
1. Uppdatera Kontrollprovsfil
2. Generera inventeringsrapport
3. Visa material med kort utgångsdatum
4. Visa materialinformation för produkt
5. Feedback
6. Avsluta

.lnk-fil
--------
Om er .lnk redan pekar på en specifik .ps1-fil kan ni antingen:
1. Uppdatera .lnk Target så den pekar på denna nya .ps1-fil, eller
2. Byta namn på denna fil till samma namn som .lnk redan pekar på.

Exempel Target:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "N:\...\kontrollprovsfil_v20260305_FLOW_v2_2_REPORT_FIX.ps1"

Filtrering av N/A
-----------------
En rad räknas som ej aktiv och tas inte med i rapporterna om någon av följande kolumner är tom eller N/A-liknande:
- PN
- Lot
- Exp
- Qty

Qty = 0 räknas däremot som ett riktigt värde och filtreras inte bort.

Loggning
--------
Robust update-loggning från tidigare version är kvar:
- fast CSV-header
- semikolonseparerad CSV
- .lock-fil vid skrivning
- spool-logg om huvudloggen är låst
- emergency-logg om både huvudlogg och spool misslyckas
- korrupt gammal logg flyttas till CORRUPT_BACKUP

