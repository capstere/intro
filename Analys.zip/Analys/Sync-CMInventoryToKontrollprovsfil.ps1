<#
.SYNOPSIS
    Synkar aktiva kontrollmaterial-lotar från SharePoint List CM_Lots till befintlig kontrollprovsfil2026.xlsx.

.DESCRIPTION
    Anpassad för nuvarande kontrollprovsfil2026.xlsx:
      - Blad1
      - Rubriker på rad 1
      - Dynamiska kolumner A-F, men scriptet skriver endast B-F
      - P/N i kolumn A
      - Lotnr. i kolumn B
      - Utgångsdatum i kolumn C
      - Antal i lager i kolumn D
      - Senast inventering i kolumn E
      - SIGN i kolumn F
      - Produktkonstanter i G-M lämnas orörda
      - Beskrivning/Förvaringsplats/Labb i N-P lämnas orörda
      - Varje P/N har exakt 4 reserverade rader/slott

    SharePoint-fält från CM_Lots:
      - PN
      - LotNumber
      - ExpirationDate
      - Qty
      - IsActive
      - ChangedAt
      - ChangedByName
      - LastCheckedAt
      - LastCheckedByName

    Senast inventering beräknas som senaste datum av LastCheckedAt och ChangedAt.
    SIGN sätts från den användare som hör till det valda datumet.

.REQUIREMENTS
    - Windows PowerShell 5.1
    - PnP.PowerShell installerad för Windows PowerShell 5.1-miljön
    - EPPlus.dll tillgänglig lokalt eller på nätverkssökväg

.EXAMPLE
    .\Sync-CMInventoryToKontrollprovsfil.ps1 `
      -SiteUrl "https://TENANT.sharepoint.com/sites/YOURSITE" `
      -ExcelPath "\\SE.CEPHEID.PRI\Cepheid Sweden\QC\QC-1\...\kontrollprovsfil2026.xlsx" `
      -EpplusDllPath "C:\Tools\EPPlus\EPPlus.dll" `
      -AuthMode Interactive `
      -DryRun

.EXAMPLE
    .\Sync-CMInventoryToKontrollprovsfil.ps1 `
      -SiteUrl "https://TENANT.sharepoint.com/sites/YOURSITE" `
      -ExcelPath "\\SE.CEPHEID.PRI\Cepheid Sweden\QC\QC-1\...\kontrollprovsfil2026.xlsx" `
      -EpplusDllPath "C:\Tools\EPPlus\EPPlus.dll" `
      -AuthMode Interactive `
      -SyncMode Full
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$SiteUrl,

    [Parameter(Mandatory = $true)]
    [string]$ExcelPath,

    [Parameter(Mandatory = $true)]
    [string]$EpplusDllPath,

    [string]$LotsListName = "CM_Lots",
    [string]$SheetName = "Blad1",

    [int]$FirstDataRow = 2,
    [int]$SlotsPerPN = 4,

    [ValidateSet("Interactive", "UseWebLogin", "AlreadyConnected", "AppCertificate")]
    [string]$AuthMode = "Interactive",

    [string]$Tenant,
    [string]$ClientId,
    [string]$CertificatePath,
    [securestring]$CertificatePassword,

    [ValidateSet("UpdateOnly", "Full")]
    [string]$SyncMode = "UpdateOnly",

    [ValidateSet("Fail", "TruncateNewest", "TruncateOldest")]
    [string]$OverflowMode = "Fail",

    [ValidateSet("Warn", "Fail")]
    [string]$UnknownPNMode = "Warn",

    [ValidateSet("FullName", "Initials")]
    [string]$SignMode = "FullName",

    [switch]$IncludeInactiveLots,
    [switch]$DryRun,

    [string]$BackupFolder,
    [string]$LogPath,
    [string]$ReportCsvPath,

    [int]$PageSize = 2000
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

$script:StartedAt = Get-Date
$script:ReportRows = New-Object System.Collections.Generic.List[object]

function Write-CmLog {
    param(
        [ValidateSet("INFO", "WARN", "ERROR")]
        [string]$Level,
        [string]$Message
    )

    $line = "{0}`t{1}`t{2}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $Level, $Message
    Write-Host $line

    if (-not [string]::IsNullOrWhiteSpace($script:LogPathResolved)) {
        $logDir = Split-Path -Parent $script:LogPathResolved
        if (-not [string]::IsNullOrWhiteSpace($logDir) -and -not (Test-Path -LiteralPath $logDir)) {
            New-Item -Path $logDir -ItemType Directory -Force | Out-Null
        }
        Add-Content -LiteralPath $script:LogPathResolved -Value $line -Encoding UTF8
    }
}

function Normalize-CmText {
    param($Value)
    if ($null -eq $Value) { return "" }
    return ([string]$Value).Trim()
}

function Normalize-CmPN {
    param($Value)
    return (Normalize-CmText -Value $Value).ToUpperInvariant()
}

function ConvertFrom-SharePointValue {
    param($Value)

    if ($null -eq $Value) { return $null }

    $typeName = $Value.GetType().FullName

    if ($typeName -eq "Microsoft.SharePoint.Client.FieldUserValue") {
        return $Value.LookupValue
    }

    if ($typeName -eq "Microsoft.SharePoint.Client.FieldLookupValue") {
        return $Value.LookupValue
    }

    if ($Value -is [System.Array]) {
        $parts = New-Object System.Collections.Generic.List[string]
        foreach ($v in $Value) {
            $converted = ConvertFrom-SharePointValue -Value $v
            if ($null -ne $converted -and -not [string]::IsNullOrWhiteSpace([string]$converted)) {
                $parts.Add([string]$converted)
            }
        }
        return ($parts -join "; ")
    }

    return $Value
}

function Get-SpField {
    param(
        [Parameter(Mandatory = $true)]$Item,
        [Parameter(Mandatory = $true)][string]$Name
    )

    if ($null -eq $Item.FieldValues) { return $null }

    if ($Item.FieldValues.ContainsKey($Name)) {
        return ConvertFrom-SharePointValue -Value $Item.FieldValues[$Name]
    }

    return $null
}

function ConvertTo-CmBool {
    param($Value)

    if ($null -eq $Value) { return $false }
    if ($Value -is [bool]) { return $Value }

    $s = ([string]$Value).Trim()
    if ($s -match '^(true|yes|1|ja)$') { return $true }

    return $false
}

function ConvertTo-CmDate {
    param($Value)

    if ($null -eq $Value) { return $null }
    if ($Value -is [DateTime]) { return $Value }

    $dt = New-Object DateTime
    if ([DateTime]::TryParse([string]$Value, [ref]$dt)) {
        return $dt
    }

    return $null
}

function ConvertTo-CmInitials {
    param([string]$Name)

    if ([string]::IsNullOrWhiteSpace($Name)) { return "" }

    $clean = $Name.Trim()
    if ($clean -match '^[A-Za-zÅÄÖåäö]{2,6}$') {
        return $clean.ToUpperInvariant()
    }

    $tokens = $clean -split '[\s\.-]+' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    $initials = ""
    foreach ($token in $tokens) {
        $initials += $token.Substring(0, 1).ToUpperInvariant()
    }

    return $initials
}

function Select-CmInventoryStamp {
    param(
        [Nullable[DateTime]]$ChangedAt,
        [string]$ChangedByName,
        [Nullable[DateTime]]$LastCheckedAt,
        [string]$LastCheckedByName
    )

    $date = $null
    $name = $null
    $source = ""

    if ($LastCheckedAt.HasValue -and $ChangedAt.HasValue) {
        if ($LastCheckedAt.Value -ge $ChangedAt.Value) {
            $date = $LastCheckedAt.Value
            $name = $LastCheckedByName
            $source = "LastCheckedAt"
        }
        else {
            $date = $ChangedAt.Value
            $name = $ChangedByName
            $source = "ChangedAt"
        }
    }
    elseif ($LastCheckedAt.HasValue) {
        $date = $LastCheckedAt.Value
        $name = $LastCheckedByName
        $source = "LastCheckedAt"
    }
    elseif ($ChangedAt.HasValue) {
        $date = $ChangedAt.Value
        $name = $ChangedByName
        $source = "ChangedAt"
    }

    if ([string]::IsNullOrWhiteSpace($name)) {
        if (-not [string]::IsNullOrWhiteSpace($ChangedByName)) { $name = $ChangedByName }
        elseif (-not [string]::IsNullOrWhiteSpace($LastCheckedByName)) { $name = $LastCheckedByName }
    }

    if ($SignMode -eq "Initials") {
        $name = ConvertTo-CmInitials -Name $name
    }

    return [pscustomobject]@{
        Date   = $date
        Sign   = $name
        Source = $source
    }
}

function Test-FileLocked {
    param([string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) { return $false }

    $stream = $null
    try {
        $stream = [System.IO.File]::Open(
            $Path,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::ReadWrite,
            [System.IO.FileShare]::None
        )
        return $false
    }
    catch {
        return $true
    }
    finally {
        if ($null -ne $stream) {
            $stream.Close()
            $stream.Dispose()
        }
    }
}

function Connect-CmPnP {
    if ($AuthMode -eq "AlreadyConnected") {
        Write-CmLog -Level INFO -Message "AuthMode AlreadyConnected: använder befintlig PnP-anslutning."
        return
    }

    Import-Module PnP.PowerShell -ErrorAction Stop

    if ($AuthMode -eq "Interactive") {
        Write-CmLog -Level INFO -Message "Ansluter till SharePoint via Interactive."
        Connect-PnPOnline -Url $SiteUrl -Interactive
        return
    }

    if ($AuthMode -eq "UseWebLogin") {
        Write-CmLog -Level INFO -Message "Ansluter till SharePoint via UseWebLogin."
        Connect-PnPOnline -Url $SiteUrl -UseWebLogin
        return
    }

    if ($AuthMode -eq "AppCertificate") {
        foreach ($required in @("Tenant", "ClientId", "CertificatePath")) {
            if ([string]::IsNullOrWhiteSpace((Get-Variable -Name $required -ValueOnly))) {
                throw "AuthMode AppCertificate kräver parameter: $required"
            }
        }

        Write-CmLog -Level INFO -Message "Ansluter till SharePoint via AppCertificate."
        if ($null -ne $CertificatePassword) {
            Connect-PnPOnline -Url $SiteUrl -Tenant $Tenant -ClientId $ClientId -CertificatePath $CertificatePath -CertificatePassword $CertificatePassword
        }
        else {
            Connect-PnPOnline -Url $SiteUrl -Tenant $Tenant -ClientId $ClientId -CertificatePath $CertificatePath
        }
        return
    }

    throw "Okänt AuthMode: $AuthMode"
}

function Get-CmLotsFromSharePoint {
    $fields = @(
        "Title",
        "PN",
        "LotNumber",
        "LotKey",
        "ExpirationDate",
        "Qty",
        "IsActive",
        "InventoryStatus",
        "LastCheckedAt",
        "LastCheckedByName",
        "LastCheckedByEmail",
        "ChangedAt",
        "ChangedByName",
        "ChangedByEmail"
    )

    Write-CmLog -Level INFO -Message "Hämtar SharePoint-lista: $LotsListName"

    try {
        $items = Get-PnPListItem -List $LotsListName -PageSize $PageSize -Fields $fields
    }
    catch {
        Write-CmLog -Level WARN -Message "Kunde inte använda -Fields. Försöker hämta listan utan fältbegränsning. Fel: $($_.Exception.Message)"
        $items = Get-PnPListItem -List $LotsListName -PageSize $PageSize
    }

    $rawLots = New-Object System.Collections.Generic.List[object]

    foreach ($item in $items) {
        $pn = Normalize-CmPN -Value (Get-SpField -Item $item -Name "PN")
        if ([string]::IsNullOrWhiteSpace($pn)) {
            $pn = Normalize-CmPN -Value (Get-SpField -Item $item -Name "Title")
        }

        if ([string]::IsNullOrWhiteSpace($pn)) {
            Write-CmLog -Level WARN -Message "Hoppar över SharePoint-rad utan PN. ID=$($item.Id)"
            continue
        }

        $changedAt = ConvertTo-CmDate -Value (Get-SpField -Item $item -Name "ChangedAt")
        $lastCheckedAt = ConvertTo-CmDate -Value (Get-SpField -Item $item -Name "LastCheckedAt")
        $changedByName = Normalize-CmText -Value (Get-SpField -Item $item -Name "ChangedByName")
        $lastCheckedByName = Normalize-CmText -Value (Get-SpField -Item $item -Name "LastCheckedByName")
        $stamp = Select-CmInventoryStamp -ChangedAt $changedAt -ChangedByName $changedByName -LastCheckedAt $lastCheckedAt -LastCheckedByName $lastCheckedByName

        $rawLots.Add([pscustomobject]@{
            ItemId             = $item.Id
            PN                 = $pn
            LotNumber          = Normalize-CmText -Value (Get-SpField -Item $item -Name "LotNumber")
            LotKey             = Normalize-CmText -Value (Get-SpField -Item $item -Name "LotKey")
            ExpirationDate     = ConvertTo-CmDate -Value (Get-SpField -Item $item -Name "ExpirationDate")
            Qty                = Get-SpField -Item $item -Name "Qty"
            IsActive           = ConvertTo-CmBool -Value (Get-SpField -Item $item -Name "IsActive")
            InventoryStatus    = Normalize-CmText -Value (Get-SpField -Item $item -Name "InventoryStatus")
            ChangedAt          = $changedAt
            ChangedByName      = $changedByName
            LastCheckedAt      = $lastCheckedAt
            LastCheckedByName  = $lastCheckedByName
            LastInventoryAt    = $stamp.Date
            LastInventoryBy    = $stamp.Sign
            LastInventorySource = $stamp.Source
        })
    }

    return $rawLots
}

function Add-CmReportRow {
    param(
        [string]$PN,
        [string]$Status,
        [int]$StartRow,
        [int]$EndRow,
        [int]$ActiveLotCount,
        [string]$Message
    )

    $script:ReportRows.Add([pscustomobject]@{
        RunAt          = $script:StartedAt.ToString("yyyy-MM-dd HH:mm:ss")
        PN             = $PN
        Status         = $Status
        StartRow       = $StartRow
        EndRow         = $EndRow
        ActiveLotCount = $ActiveLotCount
        Message        = $Message
    }) | Out-Null
}

function ConvertTo-ExcelColumnName {
    param([int]$ColumnNumber)

    $dividend = $ColumnNumber
    $columnName = ""
    while ($dividend -gt 0) {
        $modulo = ($dividend - 1) % 26
        $columnName = ([char](65 + $modulo)) + $columnName
        $dividend = [math]::Floor(($dividend - $modulo) / 26)
    }
    return $columnName
}

function Get-WorkbookPNMap {
    param($Worksheet)

    $headers = @("P/N", "Lotnr.", "Utgångsdatum", "Antal i lager", "Senast inventering", "SIGN")
    for ($c = 1; $c -le $headers.Count; $c++) {
        $actual = Normalize-CmText -Value $Worksheet.Cells[1, $c].Text
        $expected = $headers[$c - 1]
        if ($actual -ne $expected) {
            throw "Oväntad rubrik i cell $(ConvertTo-ExcelColumnName -ColumnNumber $c)1. Förväntade '$expected', hittade '$actual'."
        }
    }

    if ($null -eq $Worksheet.Dimension) {
        throw "Worksheet '$SheetName' saknar Dimension."
    }

    $lastRow = $Worksheet.Dimension.End.Row
    if ($lastRow -lt $FirstDataRow) {
        throw "Worksheet '$SheetName' saknar datarader."
    }

    $dataRows = $lastRow - $FirstDataRow + 1
    if (($dataRows % $SlotsPerPN) -ne 0) {
        throw "Antal datarader ($dataRows) är inte delbart med SlotsPerPN=$SlotsPerPN. Stoppar för att inte bryta 4-intervallslogiken."
    }

    $map = @{}

    for ($r = $FirstDataRow; $r -le $lastRow; $r += $SlotsPerPN) {
        $pn = Normalize-CmPN -Value $Worksheet.Cells[$r, 1].Text
        if ([string]::IsNullOrWhiteSpace($pn)) {
            throw "Tom P/N i rad $r. Stoppar."
        }

        if ($map.ContainsKey($pn)) {
            throw "Duplicerad P/N i Excel-filen: $pn. Stoppar."
        }

        for ($offset = 0; $offset -lt $SlotsPerPN; $offset++) {
            $rowPn = Normalize-CmPN -Value $Worksheet.Cells[$r + $offset, 1].Text
            if ($rowPn -ne $pn) {
                throw "P/N-blocket är inte sammanhållet. Start rad $r har '$pn', men rad $($r + $offset) har '$rowPn'. Stoppar."
            }
        }

        $map[$pn] = [pscustomobject]@{
            PN       = $pn
            StartRow = $r
            EndRow   = $r + $SlotsPerPN - 1
        }
    }

    return $map
}

function Set-CmNAForSlot {
    param($Worksheet, [int]$Row)

    for ($c = 2; $c -le 6; $c++) {
        $Worksheet.Cells[$Row, $c].Value = "N/A"
    }
}

function Set-CmLotForSlot {
    param($Worksheet, [int]$Row, $Lot)

    $Worksheet.Cells[$Row, 2].Value = [string]$Lot.LotNumber

    if ($null -ne $Lot.ExpirationDate) {
        $Worksheet.Cells[$Row, 3].Value = $Lot.ExpirationDate
        $Worksheet.Cells[$Row, 3].Style.Numberformat.Format = "yyyy-mm-dd"
    }
    else {
        $Worksheet.Cells[$Row, 3].Value = "N/A"
    }

    if ($null -ne $Lot.Qty -and -not [string]::IsNullOrWhiteSpace([string]$Lot.Qty)) {
        $Worksheet.Cells[$Row, 4].Value = $Lot.Qty
    }
    else {
        $Worksheet.Cells[$Row, 4].Value = "N/A"
    }

    if ($null -ne $Lot.LastInventoryAt) {
        $Worksheet.Cells[$Row, 5].Value = $Lot.LastInventoryAt
        $Worksheet.Cells[$Row, 5].Style.Numberformat.Format = "yyyy-mm-dd"
    }
    else {
        $Worksheet.Cells[$Row, 5].Value = "N/A"
    }

    if (-not [string]::IsNullOrWhiteSpace($Lot.LastInventoryBy)) {
        $Worksheet.Cells[$Row, 6].Value = [string]$Lot.LastInventoryBy
    }
    else {
        $Worksheet.Cells[$Row, 6].Value = "N/A"
    }
}

function Ensure-EpplusLicenseContextIfNeeded {
    try {
        $excelPackageType = [type]::GetType("OfficeOpenXml.ExcelPackage, EPPlus")
        if ($null -eq $excelPackageType) { return }

        $prop = $excelPackageType.GetProperty("LicenseContext")
        if ($null -eq $prop) { return }

        $licenseContextType = [type]::GetType("OfficeOpenXml.LicenseContext, EPPlus")
        if ($null -eq $licenseContextType) { return }

        $nonCommercial = [Enum]::Parse($licenseContextType, "NonCommercial")
        $prop.SetValue($null, $nonCommercial, $null)
    }
    catch {
    }
}

try {
    if (-not (Test-Path -LiteralPath $ExcelPath)) {
        throw "ExcelPath finns inte: $ExcelPath"
    }

    if (-not (Test-Path -LiteralPath $EpplusDllPath)) {
        throw "EpplusDllPath finns inte: $EpplusDllPath"
    }

    $excelDir = Split-Path -Parent $ExcelPath
    if ([string]::IsNullOrWhiteSpace($excelDir)) {
        throw "ExcelPath måste vara en komplett path, helst UNC."
    }

    if ([string]::IsNullOrWhiteSpace($BackupFolder)) {
        $BackupFolder = Join-Path $excelDir "_backup_CMInventory"
    }

    if ([string]::IsNullOrWhiteSpace($LogPath)) {
        $LogPath = Join-Path $excelDir "CMInventory_To_Kontrollprovsfil.log"
    }

    if ([string]::IsNullOrWhiteSpace($ReportCsvPath)) {
        $ReportCsvPath = Join-Path $excelDir ("CMInventory_To_Kontrollprovsfil_report_{0}.csv" -f (Get-Date -Format "yyyyMMdd_HHmmss"))
    }

    $script:LogPathResolved = $LogPath

    Write-CmLog -Level INFO -Message "Startar sync. ExcelPath=$ExcelPath, Sheet=$SheetName, SyncMode=$SyncMode, DryRun=$DryRun"
    Write-CmLog -Level INFO -Message "OBS: Scriptet skriver endast kolumn B:F. Kolumn A och G:P lämnas orörda."

    if (-not (Test-Path -LiteralPath $BackupFolder)) {
        New-Item -Path $BackupFolder -ItemType Directory -Force | Out-Null
    }

    if (-not $DryRun) {
        if (Test-FileLocked -Path $ExcelPath) {
            throw "Excel-filen verkar vara öppen eller låst. Stäng filen och kör igen: $ExcelPath"
        }
    }

    Connect-CmPnP
    $rawLots = Get-CmLotsFromSharePoint
    Write-CmLog -Level INFO -Message ("Hämtade {0} lot-rader från SharePoint." -f $rawLots.Count)

    $allSharePointPNs = @{}
    foreach ($lot in $rawLots) { $allSharePointPNs[$lot.PN] = $true }

    $activeLots = $rawLots | Where-Object { $IncludeInactiveLots -or $_.IsActive }
    Write-CmLog -Level INFO -Message ("Lot-rader som ingår efter IsActive-filter: {0}" -f @($activeLots).Count)

    $lotsByPN = @{}
    foreach ($lot in $activeLots) {
        if (-not $lotsByPN.ContainsKey($lot.PN)) {
            $lotsByPN[$lot.PN] = New-Object System.Collections.Generic.List[object]
        }
        $lotsByPN[$lot.PN].Add($lot)
    }

    Add-Type -Path $EpplusDllPath
    Ensure-EpplusLicenseContextIfNeeded

    $tempDir = Join-Path $env:TEMP ("CMInventorySync_{0}" -f ([guid]::NewGuid().ToString("N")))
    New-Item -Path $tempDir -ItemType Directory -Force | Out-Null
    $tempExcelPath = Join-Path $tempDir (Split-Path -Leaf $ExcelPath)
    Copy-Item -LiteralPath $ExcelPath -Destination $tempExcelPath -Force

    $package = $null
    try {
        $fileInfo = New-Object -TypeName System.IO.FileInfo -ArgumentList $tempExcelPath
        $package = New-Object -TypeName OfficeOpenXml.ExcelPackage -ArgumentList $fileInfo
        $ws = $package.Workbook.Worksheets[$SheetName]
        if ($null -eq $ws) {
            throw "Worksheet saknas: $SheetName"
        }

        $pnMap = Get-WorkbookPNMap -Worksheet $ws
        Write-CmLog -Level INFO -Message ("Excel innehåller {0} P/N-block á {1} rader." -f $pnMap.Count, $SlotsPerPN)

        $unknownPNs = New-Object System.Collections.Generic.List[string]
        foreach ($pn in $allSharePointPNs.Keys) {
            if (-not $pnMap.ContainsKey($pn)) {
                $unknownPNs.Add($pn)
            }
        }

        if ($unknownPNs.Count -gt 0) {
            $message = "SharePoint innehåller P/N som inte finns i Excel-filen: $($unknownPNs -join ', ')"
            if ($UnknownPNMode -eq "Fail") { throw $message }
            Write-CmLog -Level WARN -Message $message
            foreach ($pn in $unknownPNs) {
                Add-CmReportRow -PN $pn -Status "UnknownPN" -StartRow 0 -EndRow 0 -ActiveLotCount 0 -Message "Finns i SharePoint men saknas i Excel."
            }
        }

        $pnToUpdate = New-Object System.Collections.Generic.List[string]
        if ($SyncMode -eq "Full") {
            foreach ($pn in ($pnMap.Keys | Sort-Object)) { $pnToUpdate.Add($pn) }
        }
        else {
            foreach ($pn in ($allSharePointPNs.Keys | Sort-Object)) {
                if ($pnMap.ContainsKey($pn)) { $pnToUpdate.Add($pn) }
            }
        }

        Write-CmLog -Level INFO -Message ("P/N-block som kommer uppdateras: {0}" -f $pnToUpdate.Count)

        foreach ($pn in $pnToUpdate) {
            $block = $pnMap[$pn]
            $lots = @()
            if ($lotsByPN.ContainsKey($pn)) {
                $lots = @($lotsByPN[$pn] | Sort-Object @{Expression = { if ($null -ne $_.ExpirationDate) { $_.ExpirationDate } else { [DateTime]::MaxValue } }}, LotNumber)
            }

            if ($lots.Count -gt $SlotsPerPN) {
                $message = "P/N $pn har $($lots.Count) aktiva lotar men Excel har endast $SlotsPerPN slott."
                if ($OverflowMode -eq "Fail") { throw $message }

                Write-CmLog -Level WARN -Message "$message OverflowMode=$OverflowMode."
                if ($OverflowMode -eq "TruncateNewest") {
                    $lots = @($lots | Select-Object -First $SlotsPerPN)
                }
                elseif ($OverflowMode -eq "TruncateOldest") {
                    $lots = @($lots | Select-Object -Last $SlotsPerPN)
                }
            }

            if ($DryRun) {
                Add-CmReportRow -PN $pn -Status "DryRun" -StartRow $block.StartRow -EndRow $block.EndRow -ActiveLotCount $lots.Count -Message "Skulle uppdatera B:F för detta P/N-block."
                continue
            }

            for ($i = 0; $i -lt $SlotsPerPN; $i++) {
                $row = $block.StartRow + $i
                if ($i -lt $lots.Count) {
                    Set-CmLotForSlot -Worksheet $ws -Row $row -Lot $lots[$i]
                }
                else {
                    Set-CmNAForSlot -Worksheet $ws -Row $row
                }
            }

            Add-CmReportRow -PN $pn -Status "Updated" -StartRow $block.StartRow -EndRow $block.EndRow -ActiveLotCount $lots.Count -Message "Uppdaterade endast B:F."
        }

        if ($DryRun) {
            Write-CmLog -Level INFO -Message "DryRun aktivt: ingen Excel-fil skrivs över."
        }
        else {
            $package.Save()

            $backupPath = Join-Path $BackupFolder ("{0}_{1}.xlsx" -f ([System.IO.Path]::GetFileNameWithoutExtension($ExcelPath)), (Get-Date -Format "yyyyMMdd_HHmmss"))
            Copy-Item -LiteralPath $ExcelPath -Destination $backupPath -Force
            Write-CmLog -Level INFO -Message "Backup skapad: $backupPath"

            if (Test-FileLocked -Path $ExcelPath) {
                throw "Excel-filen blev låst innan ersättning kunde göras. Backup finns: $backupPath"
            }

            Copy-Item -LiteralPath $tempExcelPath -Destination $ExcelPath -Force
            Write-CmLog -Level INFO -Message "Excel uppdaterad: $ExcelPath"
        }
    }
    finally {
        if ($null -ne $package) {
            $package.Dispose()
        }

        if (Test-Path -LiteralPath $tempDir) {
            Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }

    if ($script:ReportRows.Count -gt 0) {
        $script:ReportRows | Export-Csv -LiteralPath $ReportCsvPath -NoTypeInformation -Encoding UTF8
        Write-CmLog -Level INFO -Message "Rapport skapad: $ReportCsvPath"
    }

    Write-CmLog -Level INFO -Message "Klar."
}
catch {
    try {
        if ([string]::IsNullOrWhiteSpace($script:LogPathResolved)) {
            $script:LogPathResolved = $LogPath
        }
        Write-CmLog -Level ERROR -Message $_.Exception.Message
    }
    catch {
        Write-Host ("ERROR`t{0}" -f $_.Exception.Message)
    }
    throw
}
