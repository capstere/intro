<# 
QDIP SharePoint Investigation Tool
PowerShell 5.1 + PnP cmdlets

Purpose:
- Investigate official SharePoint logic behind "Lead-time" and Delivery Lagging
- Export calculated field formulas, views, candidate list fields, and selected order rows
- Search Rework/original order fields to understand order renumbering after rework

Before running:
1) Use PowerShell 5.1.
2) Make sure your PnP module/cmdlets work with your certificate login.
3) Fill in CLIENT ID and certificate OR enter them when prompted.
4) Run from a folder where you may create files. Output is saved to Desktop automatically.

IMPORTANT:
- Do not share exported files publicly. They may contain production/order data.
- Do not paste secrets into shared logs.
#>

# -----------------------------
# USER CONFIG
# -----------------------------
$env:PNPPOWERSHELL_UPDATECHECK = "Off"

$TenantDefault = "danaher.onmicrosoft.com"
$SiteUrlDefault = "https://danaher.sharepoint.com/sites/CEP-Sweden-Production-Management"

# You may paste your values here or leave as MY KEY and enter when prompted.
$ClientId = "MY KEY"
$CertificateBase64Encoded = "MY KEY"

# -----------------------------
# GLOBALS
# -----------------------------
$RunStamp = Get-Date -Format "yyyyMMdd_HHmmss"
$Desktop = [Environment]::GetFolderPath("Desktop")
$OutputRoot = Join-Path $Desktop ("QDIP_SP_Investigation_" + $RunStamp)
New-Item -ItemType Directory -Path $OutputRoot -Force | Out-Null

$CandidateLists = @(
    [PSCustomObject]@{Priority=1;  Title="Cepheid | Production orders";              Id="85bf77f5-4f4d-41c9-b89a-371db8d50e25"; Reason="Main official production order list"},
    [PSCustomObject]@{Priority=2;  Title="Cepheid | Production orders - Archive";    Id="534c9592-d98d-480d-8d72-43449201136c"; Reason="Possible historical snapshot/archive"},
    [PSCustomObject]@{Priority=3;  Title="Document Review";                          Id="be07bfc4-8967-4175-bb94-b873c4e524ac"; Reason="Possible document review event/history list"},
    [PSCustomObject]@{Priority=4;  Title="Work Order Changes";                       Id="90c12882-bd26-4ad8-8b02-fc5aea1596ab"; Reason="Possible work order change history"},
    [PSCustomObject]@{Priority=5;  Title="Changes";                                  Id="a8a01224-ccf8-4033-a7bf-1f1ae8e7da4a"; Reason="Possible generic change history"},
    [PSCustomObject]@{Priority=6;  Title="Workflow History";                         Id="e9f3bffa-d8a2-41c0-890f-890419a17112"; Reason="Possible workflow transition history"},
    [PSCustomObject]@{Priority=7;  Title="Restriction Failure Investigations";        Id="50a474d9-0e05-4ab7-b664-a04c7a9658ce"; Reason="FI/NCR related"},
    [PSCustomObject]@{Priority=8;  Title="QAR - Order info";                         Id="4591da58-a8ec-4ec5-9530-daaa5aaa8a46"; Reason="Order info / possible QA relation"},
    [PSCustomObject]@{Priority=9;  Title="QAr";                                      Id="5b8ae623-59ae-45aa-b522-b1d8596cc32f"; Reason="QAR root list"},
    [PSCustomObject]@{Priority=10; Title="QAR INC Solna";                            Id="36b6a2d7-310d-4cfa-8e2b-f3df92c02628"; Reason="Incident / QAR related"},
    [PSCustomObject]@{Priority=11; Title="QAR INC Solna Issues";                     Id="18fbe0b3-8c50-4d02-b617-921c0b6d6636"; Reason="Incident issues"},
    [PSCustomObject]@{Priority=12; Title="Mail sent: FI Non-catalog NC review";       Id="7453f36d-ce93-428f-afa3-fc354e21f714"; Reason="Notifications may reveal FI/NC workflow"},
    [PSCustomObject]@{Priority=13; Title="Mail sent: FI Non-catalog NC review2";      Id="3d3af75a-3248-4c1c-bda6-aeb326d8776b"; Reason="Notifications may reveal FI/NC workflow"},
    [PSCustomObject]@{Priority=14; Title="Mail sent: QA NCR label applied/removed";   Id="f725512f-4c28-4010-b312-20f78fcad6f0c"; Reason="NCR label history"}
)

$ImportantProductionFieldTitles = @(
    "Order#",
    "SAP Batch#",
    "LSP",
    "Material",
    "Work Center",
    "ROBAL - Actual end date/ time",
    "IPT - Testing finalized",
    "IPT – FI request initiated",
    "FI – IPT FI request complete",
    "IPT - Compiling of data",
    "IPT - Document review",
    "Lead-time",
    "DVM - Current phase lead-time (h)",
    "IPT testing in progress",
    "NC (QA) – NCR Number",
    "NC (QA) – Initiate NCR date",
    "NC (Investigator) – Testing Completed date",
    "REWORK - from SAP order# (original order#)",
    "REWORK - from SAP batch# (original batch#)",
    "REWORK - Planned Rework",
    "REWORK - Order Status",
    "REWORK - Actual start date",
    "REWORK - Actual end date",
    "REWORK - Completed",
    "Document review - REWORK",
    "Modified",
    "Created",
    "Modified By",
    "Created By"
)

# -----------------------------
# UTILITY FUNCTIONS
# -----------------------------
function Write-Section($Text) {
    Write-Host ""
    Write-Host ("=" * 90) -ForegroundColor DarkCyan
    Write-Host $Text -ForegroundColor Cyan
    Write-Host ("=" * 90) -ForegroundColor DarkCyan
}

function Safe-FileName($Name) {
    $invalid = [System.IO.Path]::GetInvalidFileNameChars()
    $s = $Name
    foreach ($c in $invalid) { $s = $s.Replace($c, "_") }
    $s = $s.Replace("|", "_").Replace("/", "_").Replace("\", "_").Replace(":", "_")
    return $s
}

function Export-CsvUtf8($Data, $Path) {
    $Data | Export-Csv -Path $Path -NoTypeInformation -Encoding UTF8
    Write-Host "Saved: $Path" -ForegroundColor Green
}

function Get-FormulaFromSchemaXml($SchemaXml) {
    if ([string]::IsNullOrWhiteSpace($SchemaXml)) { return "" }
    if ($SchemaXml -match "<Formula>(.*?)</Formula>") {
        return [System.Net.WebUtility]::HtmlDecode($matches[1])
    }
    return ""
}

function Convert-SpValueToText($Value) {
    if ($null -eq $Value) { return "" }
    try {
        if ($Value.PSObject.Properties.Name -contains "LookupValue") {
            return [string]$Value.LookupValue
        }
    } catch {}
    if ($Value -is [System.Array]) {
        $parts = @()
        foreach ($v in $Value) { $parts += (Convert-SpValueToText $v) }
        return ($parts -join "; ")
    }
    if ($Value -is [DateTime]) { return $Value.ToString("yyyy-MM-dd HH:mm:ss") }
    return [string]$Value
}

function Get-FieldInventory($ListId) {
    return Get-PnPField -List $ListId | Sort-Object Title
}

function Get-PreferredFieldByTitle($Fields, $Title) {
    $matches = @($Fields | Where-Object { $_.Title -eq $Title })
    if ($matches.Count -eq 0) { return $null }
    $preferred = $matches | Where-Object {
        $_.InternalName -eq "Title" -or
        ($_.TypeDisplayName -ne "Computed" -and $_.Hidden -eq $false)
    } | Select-Object -First 1
    if ($null -ne $preferred) { return $preferred }
    return ($matches | Select-Object -First 1)
}

function Get-FieldMapForTitles($ListId, $Titles) {
    $fields = Get-FieldInventory $ListId
    $result = @()
    foreach ($t in $Titles) {
        $f = Get-PreferredFieldByTitle -Fields $fields -Title $t
        if ($null -ne $f) {
            $result += [PSCustomObject]@{Title=$t; Found=$true; InternalName=$f.InternalName; TypeDisplayName=$f.TypeDisplayName; TypeAsString=$f.TypeAsString}
        } else {
            $result += [PSCustomObject]@{Title=$t; Found=$false; InternalName=""; TypeDisplayName=""; TypeAsString=""}
        }
    }
    return $result
}

function XmlEscape($Text) {
    return [System.Security.SecurityElement]::Escape([string]$Text)
}

function New-CamlInClause($FieldInternalName, $Values, $TypeName) {
    $valueXml = ""
    foreach ($v in $Values) { $valueXml += "<Value Type='$TypeName'>" + (XmlEscape $v) + "</Value>" }
    return "<In><FieldRef Name='$FieldInternalName'/><Values>$valueXml</Values></In>"
}

function New-CamlOr($Clauses) {
    $clausesClean = @($Clauses | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    if ($clausesClean.Count -eq 0) { return "" }
    if ($clausesClean.Count -eq 1) { return $clausesClean[0] }
    $current = "<Or>" + $clausesClean[0] + $clausesClean[1] + "</Or>"
    if ($clausesClean.Count -gt 2) {
        for ($i = 2; $i -lt $clausesClean.Count; $i++) { $current = "<Or>" + $current + $clausesClean[$i] + "</Or>" }
    }
    return $current
}

function Read-CommaList($Prompt) {
    $raw = Read-Host $Prompt
    if ([string]::IsNullOrWhiteSpace($raw)) { return @() }
    return @($raw -split "," | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne "" })
}

function Show-CandidateLists {
    Write-Host ""
    $CandidateLists | Sort-Object Priority | Format-Table Priority, Title, Id, Reason -AutoSize
}

function Get-ListChoiceFromUser {
    Show-CandidateLists
    Write-Host ""
    $choice = Read-Host "Enter Priority number, List GUID, exact List Title, or A for all candidate lists"
    return $choice
}

function Resolve-ListSelection($Choice) {
    if ($Choice -eq "A" -or $Choice -eq "a") { return $CandidateLists }
    $byPriority = $CandidateLists | Where-Object { [string]$_.Priority -eq [string]$Choice } | Select-Object -First 1
    if ($null -ne $byPriority) { return @($byPriority) }
    $byId = $CandidateLists | Where-Object { $_.Id -eq $Choice } | Select-Object -First 1
    if ($null -ne $byId) { return @($byId) }
    $byTitle = $CandidateLists | Where-Object { $_.Title -eq $Choice } | Select-Object -First 1
    if ($null -ne $byTitle) { return @($byTitle) }
    return @([PSCustomObject]@{Priority=999; Title=$Choice; Id=$Choice; Reason="Manual selection"})
}

# -----------------------------
# CONNECT
# -----------------------------
function Connect-QDIP {
    Write-Section "CONNECT TO SHAREPOINT"
    $tenant = Read-Host "Tenant [$TenantDefault]"
    if ([string]::IsNullOrWhiteSpace($tenant)) { $tenant = $TenantDefault }
    $siteUrl = Read-Host "Site URL [$SiteUrlDefault]"
    if ([string]::IsNullOrWhiteSpace($siteUrl)) { $siteUrl = $SiteUrlDefault }
    if ($ClientId -eq "MY KEY" -or [string]::IsNullOrWhiteSpace($ClientId)) { $script:ClientId = Read-Host "ClientId" }
    if ($CertificateBase64Encoded -eq "MY KEY" -or [string]::IsNullOrWhiteSpace($CertificateBase64Encoded)) {
        Write-Host ""
        Write-Host "Certificate input:" -ForegroundColor Yellow
        Write-Host "P = paste Base64 directly"
        Write-Host "F = read Base64 from file path"
        $mode = Read-Host "Choose P/F"
        if ($mode -eq "F" -or $mode -eq "f") {
            $certPath = Read-Host "Path to text file containing certificate Base64"
            $script:CertificateBase64Encoded = Get-Content -Path $certPath -Raw
        } else {
            $script:CertificateBase64Encoded = Read-Host "Paste CertificateBase64Encoded"
        }
    }
    try {
        Connect-PnPOnline -Url $siteUrl -Tenant $tenant -ClientId $script:ClientId -CertificateBase64Encoded $script:CertificateBase64Encoded
        Write-Host "Connected OK." -ForegroundColor Green
        Write-Host "Output folder: $OutputRoot" -ForegroundColor Green
    } catch {
        Write-Host "Connection failed:" -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
        throw
    }
}

# -----------------------------
# EXPORT FUNCTIONS
# -----------------------------
function Export-AllLists {
    Write-Section "EXPORT ALL LISTS"
    $path = Join-Path $OutputRoot "All_SharePoint_Lists.csv"
    $lists = Get-PnPList | Sort-Object Title | Select-Object Title, Id, ItemCount, Hidden, BaseTemplate, BaseType, Created, LastItemModifiedDate
    Export-CsvUtf8 $lists $path
}

function Export-FieldsForList($ListObj) {
    Write-Section ("EXPORT FIELDS: " + $ListObj.Title)
    $fields = Get-FieldInventory $ListObj.Id
    $rows = foreach ($f in $fields) {
        [PSCustomObject]@{
            ListTitle=$ListObj.Title; ListId=$ListObj.Id; Title=$f.Title; InternalName=$f.InternalName; StaticName=$f.StaticName
            TypeDisplayName=$f.TypeDisplayName; TypeAsString=$f.TypeAsString; Required=$f.Required; Hidden=$f.Hidden
            ReadOnlyField=$f.ReadOnlyField; Sealed=$f.Sealed; Formula=(Get-FormulaFromSchemaXml $f.SchemaXml); SchemaXml=$f.SchemaXml
        }
    }
    $safe = Safe-FileName $ListObj.Title
    $path = Join-Path $OutputRoot ("Fields_" + $safe + ".csv")
    Export-CsvUtf8 $rows $path
}

function Export-FieldsMenu {
    $choice = Get-ListChoiceFromUser
    $lists = Resolve-ListSelection $choice
    foreach ($l in $lists) { Export-FieldsForList $l }
}

function Export-CalculatedFormulasForList($ListObj) {
    Write-Section ("EXPORT CALCULATED FORMULAS: " + $ListObj.Title)
    $fields = Get-FieldInventory $ListObj.Id
    $rows = foreach ($f in $fields) {
        $formula = Get-FormulaFromSchemaXml $f.SchemaXml
        if ($f.TypeAsString -eq "Calculated" -or $f.TypeDisplayName -eq "Calculated" -or $formula -ne "" -or $f.Title -like "*Lead*" -or $f.Title -like "*DVM*" -or $f.Title -like "*Phase*") {
            [PSCustomObject]@{ListTitle=$ListObj.Title; ListId=$ListObj.Id; Title=$f.Title; InternalName=$f.InternalName; TypeDisplayName=$f.TypeDisplayName; TypeAsString=$f.TypeAsString; Formula=$formula; SchemaXml=$f.SchemaXml}
        }
    }
    $safe = Safe-FileName $ListObj.Title
    $path = Join-Path $OutputRoot ("CalculatedFormulas_" + $safe + ".csv")
    Export-CsvUtf8 $rows $path
}

function Export-CalculatedFormulasMenu {
    Write-Host "Recommended: Start with Production orders, then Archive." -ForegroundColor Yellow
    $choice = Get-ListChoiceFromUser
    $lists = Resolve-ListSelection $choice
    foreach ($l in $lists) { Export-CalculatedFormulasForList $l }
}

function Export-ViewsForList($ListObj) {
    Write-Section ("EXPORT VIEWS: " + $ListObj.Title)
    $views = Get-PnPView -List $ListObj.Id
    $rows = foreach ($v in $views) {
        try { Get-PnPProperty -ClientObject $v -Property ViewFields, ViewQuery | Out-Null } catch {}
        [PSCustomObject]@{ListTitle=$ListObj.Title; ListId=$ListObj.Id; ViewTitle=$v.Title; ViewId=$v.Id; DefaultView=$v.DefaultView; Hidden=$v.Hidden; PersonalView=$v.PersonalView; RowLimit=$v.RowLimit; ViewQuery=$v.ViewQuery; ViewFields=($v.ViewFields | ForEach-Object { $_ }) -join "; "}
    }
    $safe = Safe-FileName $ListObj.Title
    $path = Join-Path $OutputRoot ("Views_" + $safe + ".csv")
    Export-CsvUtf8 $rows $path
}

function Export-ViewsMenu {
    $choice = Get-ListChoiceFromUser
    $lists = Resolve-ListSelection $choice
    foreach ($l in $lists) { Export-ViewsForList $l }
}

function Search-FieldsByKeywordsMenu {
    Write-Section "SEARCH FIELD NAMES BY KEYWORDS"
    $keywords = Read-CommaList "Enter keywords comma-separated, e.g. Lead,Review,Rework,NCR,DVM,IPT,FI"
    if ($keywords.Count -eq 0) { return }
    $scope = Read-Host "Search A = all site lists or C = candidate lists only? [C]"
    $listScope = @()
    if ($scope -eq "A" -or $scope -eq "a") {
        $all = Get-PnPList | Where-Object { $_.Hidden -eq $false } | Sort-Object Title
        foreach ($l in $all) { $listScope += [PSCustomObject]@{Title=$l.Title; Id=[string]$l.Id; Priority=999; Reason="All lists"} }
    } else { $listScope = $CandidateLists }
    $rows = @()
    foreach ($l in $listScope) {
        Write-Host ("Searching fields in: " + $l.Title) -ForegroundColor DarkGray
        try {
            $fields = Get-FieldInventory $l.Id
            foreach ($f in $fields) {
                foreach ($kw in $keywords) {
                    if ($f.Title -like ("*" + $kw + "*") -or $f.InternalName -like ("*" + $kw + "*")) {
                        $rows += [PSCustomObject]@{Keyword=$kw; ListTitle=$l.Title; ListId=$l.Id; FieldTitle=$f.Title; InternalName=$f.InternalName; TypeDisplayName=$f.TypeDisplayName; TypeAsString=$f.TypeAsString; Formula=(Get-FormulaFromSchemaXml $f.SchemaXml); SchemaXml=$f.SchemaXml}
                    }
                }
            }
        } catch {
            $rows += [PSCustomObject]@{Keyword=""; ListTitle=$l.Title; ListId=$l.Id; FieldTitle="ERROR"; InternalName=$_.Exception.Message; TypeDisplayName=""; TypeAsString=""; Formula=""; SchemaXml=""}
        }
    }
    $path = Join-Path $OutputRoot "FieldKeywordSearch.csv"
    Export-CsvUtf8 $rows $path
}

function Export-ImportantProductionFieldMap {
    Write-Section "EXPORT IMPORTANT PRODUCTION FIELD MAP"
    $prod = $CandidateLists | Where-Object { $_.Title -eq "Cepheid | Production orders" } | Select-Object -First 1
    $map = Get-FieldMapForTitles -ListId $prod.Id -Titles $ImportantProductionFieldTitles
    $path = Join-Path $OutputRoot "ProductionOrders_ImportantFieldMap.csv"
    Export-CsvUtf8 $map $path
}

function Get-InternalNamesForUsefulFields($ListId) {
    $fields = Get-FieldInventory $ListId
    $titlesToTry = @(
        "Order#", "SAP Batch#", "SAP Batch# 2", "LSP", "Material", "Work Center",
        "ROBAL - Actual end date/ time", "IPT - Testing finalized", "IPT – FI request initiated", "FI – IPT FI request complete",
        "IPT - Compiling of data", "IPT - Document review", "Lead-time", "DVM - Current phase lead-time (h)",
        "NC (QA) – NCR Number", "NC (QA) – Initiate NCR date",
        "REWORK - from SAP order# (original order#)", "REWORK - from SAP batch# (original batch#)",
        "Document review - REWORK", "REWORK - Completed", "REWORK - Actual end date", "Modified", "Created"
    )
    $map = @{}
    foreach ($t in $titlesToTry) {
        $f = Get-PreferredFieldByTitle -Fields $fields -Title $t
        if ($null -ne $f) { $map[$t] = $f.InternalName }
    }
    $map["ID"] = "ID"; $map["GUID"] = "GUID"; $map["Editor"] = "Editor"; $map["Author"] = "Author"; $map["Title"] = "Title"
    return $map
}

function Get-ItemRowFromMap($Item, $ListObj, $Map) {
    $obj = [ordered]@{}
    $obj["ListTitle"] = $ListObj.Title
    $obj["ListId"] = $ListObj.Id
    foreach ($key in $Map.Keys) {
        $internal = $Map[$key]
        $val = ""
        try { $val = Convert-SpValueToText $Item[$internal] } catch { $val = "" }
        $obj[$key] = $val
    }
    return [PSCustomObject]$obj
}

function Search-OrdersInList($ListObj, $Orders) {
    Write-Host ("Searching orders in: " + $ListObj.Title) -ForegroundColor Cyan
    $map = Get-InternalNamesForUsefulFields $ListObj.Id
    $searchFields = @()
    if ($map.ContainsKey("Order#")) { $searchFields += $map["Order#"] } else { $searchFields += "Title" }
    if ($map.ContainsKey("REWORK - from SAP order# (original order#)")) { $searchFields += $map["REWORK - from SAP order# (original order#)"] }
    $clauses = @()
    foreach ($sf in ($searchFields | Select-Object -Unique)) { $clauses += New-CamlInClause -FieldInternalName $sf -Values $Orders -TypeName "Text" }
    $where = New-CamlOr $clauses
    if ([string]::IsNullOrWhiteSpace($where)) { return @() }
    $caml = "<View Scope='RecursiveAll'><Query><Where>$where</Where></Query></View>"
    $fieldsToLoad = @($map.Values | Select-Object -Unique)
    $items = @()
    try {
        $items = Get-PnPListItem -List $ListObj.Id -PageSize 5000 -Fields $fieldsToLoad -Query $caml
    } catch {
        Write-Host ("CAML search failed in " + $ListObj.Title + ". Trying broad search may be slow.") -ForegroundColor Yellow
        try {
            $all = Get-PnPListItem -List $ListObj.Id -PageSize 5000 -Fields $fieldsToLoad
            $items = @($all | Where-Object {
                $hit = $false
                foreach ($sf in $searchFields) {
                    $v = Convert-SpValueToText $_[$sf]
                    if ($Orders -contains $v) { $hit = $true }
                }
                $hit
            })
        } catch {
            Write-Host ("Failed searching list " + $ListObj.Title + ": " + $_.Exception.Message) -ForegroundColor Red
            return @()
        }
    }
    $rows = @()
    foreach ($it in $items) { $rows += Get-ItemRowFromMap -Item $it -ListObj $ListObj -Map $map }
    return $rows
}

function Search-OrdersMenu {
    Write-Section "SEARCH ORDERS ACROSS CANDIDATE LISTS"
    $orders = Read-CommaList "Enter Order# values comma-separated, e.g. 1116193,1115740,1115700"
    if ($orders.Count -eq 0) { return }
    Write-Host "Default searches Production, Archive, Document Review, Work Order Changes, Changes, Workflow History, RFI, QAR Order info." -ForegroundColor Yellow
    $choice = Read-Host "Search A = all candidate lists or P = priority 1-8 only? [P]"
    if ($choice -eq "A" -or $choice -eq "a") { $lists = $CandidateLists } else { $lists = @($CandidateLists | Where-Object { $_.Priority -le 8 }) }
    $allRows = @()
    foreach ($l in $lists) { $allRows += Search-OrdersInList -ListObj $l -Orders $orders }
    $path = Join-Path $OutputRoot "OrderSearch_Results.csv"
    Export-CsvUtf8 $allRows $path
}

function Export-SampleRowsMenu {
    Write-Section "EXPORT SAMPLE ROWS FROM LIST"
    $choice = Get-ListChoiceFromUser
    $lists = Resolve-ListSelection $choice
    $nRaw = Read-Host "How many rows per list? [50]"
    $n = 50
    if (-not [string]::IsNullOrWhiteSpace($nRaw)) { $n = [int]$nRaw }
    foreach ($l in $lists) {
        Write-Host ("Exporting sample rows: " + $l.Title) -ForegroundColor Cyan
        $map = Get-InternalNamesForUsefulFields $l.Id
        $fieldsToLoad = @($map.Values | Select-Object -Unique)
        try {
            $items = Get-PnPListItem -List $l.Id -PageSize 5000 -Fields $fieldsToLoad | Select-Object -First $n
            $rows = foreach ($it in $items) { Get-ItemRowFromMap -Item $it -ListObj $l -Map $map }
            $safe = Safe-FileName $l.Title
            $path = Join-Path $OutputRoot ("SampleRows_" + $safe + ".csv")
            Export-CsvUtf8 $rows $path
        } catch { Write-Host ("Failed sample for " + $l.Title + ": " + $_.Exception.Message) -ForegroundColor Red }
    }
}

function Export-VersionHistoryMenu {
    Write-Section "EXPORT VERSION HISTORY FOR ONE ITEM"
    $choice = Get-ListChoiceFromUser
    $list = Resolve-ListSelection $choice | Select-Object -First 1
    $itemId = Read-Host "Enter SharePoint item ID"
    $map = Get-InternalNamesForUsefulFields $list.Id
    try {
        $item = Get-PnPListItem -List $list.Id -Id ([int]$itemId)
        $versions = Get-PnPProperty -ClientObject $item -Property Versions
        $rows = @()
        foreach ($ver in $versions) {
            try { Get-PnPProperty -ClientObject $ver -Property FieldValues | Out-Null } catch {}
            $obj = [ordered]@{}
            $obj["ListTitle"] = $list.Title; $obj["ItemID"] = $itemId; $obj["VersionLabel"] = $ver.VersionLabel; $obj["Created"] = $ver.Created
            foreach ($key in $map.Keys) {
                $internal = $map[$key]
                $val = ""
                try { $val = Convert-SpValueToText $ver.FieldValues[$internal] } catch { $val = "" }
                $obj[$key] = $val
            }
            $rows += [PSCustomObject]$obj
        }
        $safe = Safe-FileName $list.Title
        $path = Join-Path $OutputRoot ("VersionHistory_" + $safe + "_Item" + $itemId + ".csv")
        Export-CsvUtf8 $rows $path
    } catch {
        Write-Host "Version history export failed:" -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
    }
}

function Export-FullPackage {
    Write-Section "FULL QDIP INVESTIGATION PACKAGE"
    Export-AllLists
    Export-ImportantProductionFieldMap
    foreach ($l in ($CandidateLists | Where-Object { $_.Priority -le 8 })) {
        Export-FieldsForList $l
        Export-CalculatedFormulasForList $l
        Export-ViewsForList $l
    }
    $orders = Read-CommaList "Optional: enter critical Order# values to search now, or press Enter to skip"
    if ($orders.Count -gt 0) {
        $allRows = @()
        foreach ($l in ($CandidateLists | Where-Object { $_.Priority -le 8 })) { $allRows += Search-OrdersInList -ListObj $l -Orders $orders }
        $path = Join-Path $OutputRoot "OrderSearch_Results.csv"
        Export-CsvUtf8 $allRows $path
    }
    $readme = @"
QDIP SharePoint Investigation Package
Created: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")

Recommended analysis order:
1. Open ProductionOrders_ImportantFieldMap.csv
2. Open CalculatedFormulas_Cepheid _ Production orders.csv
   - Find "Lead-time"
   - Find "DVM - Current phase lead-time (h)"
   - Find Order type / DVM / IPT testing in progress formulas
3. Open Views_Cepheid _ Production orders.csv
   - Look for views related to Lead, IPT, Review, Delivery, DVM, Active, Archive
4. If order search was exported:
   - Check whether missing old orders appear in REWORK original order fields
   - Check whether Archive contains old Order# / Lead-time
5. If needed, use menu option 8 to export version history for specific items.

Output folder:
$OutputRoot
"@
    $readmePath = Join-Path $OutputRoot "README_QDIP_Investigation.txt"
    $readme | Out-File -FilePath $readmePath -Encoding UTF8
    Write-Host "Saved: $readmePath" -ForegroundColor Green
}

# -----------------------------
# MENU
# -----------------------------
function Show-Menu {
    Write-Host ""
    Write-Host "QDIP SharePoint Investigation Tool" -ForegroundColor Cyan
    Write-Host "Output folder: $OutputRoot" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "1. Export ALL SharePoint lists"
    Write-Host "2. Export fields for candidate list(s)"
    Write-Host "3. Export calculated formulas for candidate list(s)"
    Write-Host "4. Export views for candidate list(s)"
    Write-Host "5. Search field names by keyword across lists"
    Write-Host "6. Search Order# across candidate lists, including Rework original order where available"
    Write-Host "7. Export sample rows from list(s)"
    Write-Host "8. Export version history for one item"
    Write-Host "9. Export important Production Orders field map"
    Write-Host "F. Run FULL recommended investigation package"
    Write-Host "Q. Quit"
    Write-Host ""
}

try {
    Connect-QDIP
    do {
        Show-Menu
        $cmd = Read-Host "Choose option"
        switch ($cmd) {
            "1" { Export-AllLists }
            "2" { Export-FieldsMenu }
            "3" { Export-CalculatedFormulasMenu }
            "4" { Export-ViewsMenu }
            "5" { Search-FieldsByKeywordsMenu }
            "6" { Search-OrdersMenu }
            "7" { Export-SampleRowsMenu }
            "8" { Export-VersionHistoryMenu }
            "9" { Export-ImportantProductionFieldMap }
            "F" { Export-FullPackage }
            "f" { Export-FullPackage }
            "Q" { Write-Host "Done. Output folder: $OutputRoot" -ForegroundColor Green }
            "q" { Write-Host "Done. Output folder: $OutputRoot" -ForegroundColor Green }
            default { Write-Host "Unknown option." -ForegroundColor Yellow }
        }
    } while ($cmd -ne "Q" -and $cmd -ne "q")
} catch {
    Write-Host ""
    Write-Host "Script stopped due to error:" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Write-Host ""
    Write-Host "Partial output may still exist here:" -ForegroundColor Yellow
    Write-Host $OutputRoot -ForegroundColor Yellow
}
