# SAFE REFACTOR NOTES — v1.3.6-phase10-safe

Utgångspunkt: `IPTCompile-v1.3.5-phase9-safe`.

Det som faktiskt gjordes i fas 10:
- flyttade endast hela verifierade funktionsdefinitioner från `Main.ps1`
- ingen top-level WinForms-kod flyttades
- inga event handlers flyttades
- ingen `Application.Run(...)` flyttades

Flyttat till `Core/OutputPlanning.ps1`:
- `_IsActiveSealSheet`
- `_GetPerSheetValueObjects`
- `_AggregateStatus`

Flyttat till `App/UiHelpers.ps1`:
- `Update-OverwriteVerificationUI`
- `Enable-DoubleBuffer`

Medvetet kvar i `Main.ps1`:
- `Test-IsBlockedUser`
- all top-level UI-komposition
- event wiring
- `Application.Run(...)`

Detta är en mekanisk safe refactor. Ingen körning i Windows PowerShell 5.1 / WinForms kunde verifieras här.
