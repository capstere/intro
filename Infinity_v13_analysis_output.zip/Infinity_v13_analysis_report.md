# Infinity kiosk reboot diagnostics v1.3 – analysis report

Analysdatum: 2026-05-18. Underlag: tre ZIP-filer från v1.3-körningen.

## Executive summary

- INF5 har tydligast bevis för Windows Update-relaterade omstarter: `MusNotificationUx.exe`, `svchost.exe` och `TrustedInstaller.exe` initierar planerade restarts i samband med Windows Update / cumulative updates.
- INF1 och INF3 har också Windows servicing-/SCCM-initierade restarts, framför allt runt 2026-04-23 och tidigare patchfönster.
- Alla tre har många `winlogon.exe`/`0x500ff` power-off events. Dessa är rena/planerade avstängningar men pekar inte ut originalkällan. De är inte samma tydliga signatur som Windows Update `MusNotificationUx`/`svchost`/`TrustedInstaller`.
- INF3 har separata avvikande tecken på instabilitet: Kernel-Power 41, EventLog 6008 och en bugcheck 0x139 med `C:\Windows\MEMORY.DMP` den 2026-03-17.
- INF5 avviker policy-/patchmässigt: den saknar i insamlingen WSUS/TargetRelease/DisableDualScan-rader som INF1/INF3 har, och har installerat maj-CU KB5087544. INF1/INF3 ligger kvar på april-CU KB5082200 i hotfixlistan.

## Core system summary

| Infinity | Computer | OS | Build | Admin | BIOS | User |
|---|---|---|---:|---|---|---|
| INF1 | CPHD-2MYMZ44 | Microsoft Windows 10 IoT Enterprise LTSC | 19044 | False | 1.38.0 | SE\Labuser_IPT |
| INF3 | CPHD-B94KQ54 | Microsoft Windows 10 IoT Enterprise LTSC | 19044 | False | 1.38.0 | SE\labuser_ipt |
| INF5 | CPHD-5RT7YB4 | Microsoft Windows 10 IoT Enterprise LTSC | 19044 | False | 1.33.2 | SE\Labuser_IPT |

## Event ID 1074 classification counts

| Infinity   | Class                                                      |   Count |
|:-----------|:-----------------------------------------------------------|--------:|
| INF1       | Winlogon power off/restart - unspecified source            |      18 |
| INF1       | SCCM/Configuration Manager initiated restart               |       3 |
| INF1       | Windows servicing / TrustedInstaller restart               |       2 |
| INF3       | Winlogon power off/restart - unspecified source            |      56 |
| INF3       | User session UI initiated restart/shutdown (RuntimeBroker) |       6 |
| INF3       | SCCM/Configuration Manager initiated restart               |       2 |
| INF3       | Windows servicing / TrustedInstaller restart               |       2 |
| INF3       | WMI-initiated restart (likely management/script)           |       1 |
| INF5       | Winlogon power off/restart - unspecified source            |       7 |
| INF5       | Windows Update service/svchost planned restart             |       4 |
| INF5       | User session UI initiated restart/shutdown (RuntimeBroker) |       3 |
| INF5       | Windows servicing / TrustedInstaller restart               |       3 |
| INF5       | Windows Update UX prompt / MusNotificationUx               |       2 |

## Most relevant recent 1074 events

| Infinity   | ComputerName   | TimeCreated           | Process                                   | User                | ShutdownType   | ReasonCode   | Reason                                   | Class                                                      |
|:-----------|:---------------|:----------------------|:------------------------------------------|:--------------------|:---------------|:-------------|:-----------------------------------------|:-----------------------------------------------------------|
| INF1       | CPHD-2MYMZ44   | 5/18/2026 6:03:10 AM  | C:\Windows\system32\winlogon.exe          | NT AUTHORITY\SYSTEM | power off      | 0x500ff      | No title for this reason could be found  | Winlogon power off/restart - unspecified source            |
| INF1       | CPHD-2MYMZ44   | 5/13/2026 7:36:23 AM  | C:\Windows\system32\winlogon.exe          | NT AUTHORITY\SYSTEM | power off      | 0x500ff      | No title for this reason could be found  | Winlogon power off/restart - unspecified source            |
| INF1       | CPHD-2MYMZ44   | 5/3/2026 8:08:40 PM   | C:\Windows\system32\winlogon.exe          | NT AUTHORITY\SYSTEM | power off      | 0x500ff      | No title for this reason could be found  | Winlogon power off/restart - unspecified source            |
| INF1       | CPHD-2MYMZ44   | 4/23/2026 3:07:43 AM  | C:\Windows\servicing\TrustedInstaller.exe | NT AUTHORITY\SYSTEM | restart        | 0x80020003   | Operating System: Upgrade (Planned)      | Windows servicing / TrustedInstaller restart               |
| INF1       | CPHD-2MYMZ44   | 4/23/2026 2:10:25 AM  | C:\Windows\CCM\CcmExec.exe                | NT AUTHORITY\SYSTEM | restart        | 0x80020001   | No title for this reason could be found  | SCCM/Configuration Manager initiated restart               |
| INF1       | CPHD-2MYMZ44   | 4/22/2026 9:51:45 AM  | C:\Windows\system32\winlogon.exe          | NT AUTHORITY\SYSTEM | power off      | 0x500ff      | No title for this reason could be found  | Winlogon power off/restart - unspecified source            |
| INF1       | CPHD-2MYMZ44   | 4/13/2026 6:43:43 AM  | C:\Windows\system32\winlogon.exe          | NT AUTHORITY\SYSTEM | power off      | 0x500ff      | No title for this reason could be found  | Winlogon power off/restart - unspecified source            |
| INF1       | CPHD-2MYMZ44   | 4/11/2026 5:46:55 PM  | C:\Windows\system32\winlogon.exe          | NT AUTHORITY\SYSTEM | power off      | 0x500ff      | No title for this reason could be found  | Winlogon power off/restart - unspecified source            |
| INF3       | CPHD-B94KQ54   | 5/5/2026 8:26:24 AM   | C:\Windows\System32\RuntimeBroker.exe     | SE\Labuser_IPT      | power off      | 0x0          | Other (Unplanned)                        | User session UI initiated restart/shutdown (RuntimeBroker) |
| INF3       | CPHD-B94KQ54   | 4/29/2026 8:08:03 PM  | C:\Windows\system32\winlogon.exe          | NT AUTHORITY\SYSTEM | power off      | 0x500ff      | No title for this reason could be found  | Winlogon power off/restart - unspecified source            |
| INF3       | CPHD-B94KQ54   | 4/27/2026 12:59:03 PM | C:\Windows\system32\winlogon.exe          | NT AUTHORITY\SYSTEM | power off      | 0x500ff      | No title for this reason could be found  | Winlogon power off/restart - unspecified source            |
| INF3       | CPHD-B94KQ54   | 4/23/2026 8:31:14 AM  | C:\Windows\system32\winlogon.exe          | NT AUTHORITY\SYSTEM | power off      | 0x500ff      | No title for this reason could be found  | Winlogon power off/restart - unspecified source            |
| INF3       | CPHD-B94KQ54   | 4/23/2026 3:08:37 AM  | C:\Windows\servicing\TrustedInstaller.exe | NT AUTHORITY\SYSTEM | restart        | 0x80020003   | Operating System: Upgrade (Planned)      | Windows servicing / TrustedInstaller restart               |
| INF3       | CPHD-B94KQ54   | 4/23/2026 2:09:11 AM  | C:\Windows\CCM\CcmExec.exe                | NT AUTHORITY\SYSTEM | restart        | 0x80020001   | No title for this reason could be found  | SCCM/Configuration Manager initiated restart               |
| INF3       | CPHD-B94KQ54   | 4/14/2026 8:26:40 AM  | C:\Windows\system32\winlogon.exe          | NT AUTHORITY\SYSTEM | power off      | 0x500ff      | No title for this reason could be found  | Winlogon power off/restart - unspecified source            |
| INF3       | CPHD-B94KQ54   | 4/13/2026 6:44:47 AM  | C:\Windows\system32\winlogon.exe          | NT AUTHORITY\SYSTEM | power off      | 0x500ff      | No title for this reason could be found  | Winlogon power off/restart - unspecified source            |
| INF5       | CPHD-5RT7YB4   | 5/14/2026 1:57:27 AM  | C:\Windows\servicing\TrustedInstaller.exe | NT AUTHORITY\SYSTEM | restart        | 0x80020003   | Operating System: Upgrade (Planned)      | Windows servicing / TrustedInstaller restart               |
| INF5       | CPHD-5RT7YB4   | 5/14/2026 1:56:01 AM  | C:\Windows\system32\svchost.exe           | NT AUTHORITY\SYSTEM | restart        | 0x80020010   | Operating System: Service pack (Planned) | Windows Update service/svchost planned restart             |
| INF5       | CPHD-5RT7YB4   | 5/14/2026 12:18:26 AM | C:\Windows\system32\MusNotificationUx.exe | SE\Labuser_IPT      | restart        | 0x80020010   | Operating System: Service pack (Planned) | Windows Update UX prompt / MusNotificationUx               |
| INF5       | CPHD-5RT7YB4   | 5/10/2026 12:20:00 AM | C:\Windows\system32\svchost.exe           | NT AUTHORITY\SYSTEM | restart        | 0x80020010   | Operating System: Service pack (Planned) | Windows Update service/svchost planned restart             |
| INF5       | CPHD-5RT7YB4   | 5/3/2026 8:05:44 PM   | C:\Windows\system32\winlogon.exe          | NT AUTHORITY\SYSTEM | power off      | 0x500ff      | No title for this reason could be found  | Winlogon power off/restart - unspecified source            |
| INF5       | CPHD-5RT7YB4   | 4/23/2026 7:44:01 PM  | C:\Windows\system32\winlogon.exe          | NT AUTHORITY\SYSTEM | power off      | 0x500ff      | No title for this reason could be found  | Winlogon power off/restart - unspecified source            |
| INF5       | CPHD-5RT7YB4   | 4/23/2026 4:59:53 AM  | C:\Windows\System32\RuntimeBroker.exe     | SE\Labuser_IPT      | restart        | 0x0          | Other (Unplanned)                        | User session UI initiated restart/shutdown (RuntimeBroker) |
| INF5       | CPHD-5RT7YB4   | 4/15/2026 12:22:40 AM | C:\Windows\servicing\TrustedInstaller.exe | NT AUTHORITY\SYSTEM | restart        | 0x80020003   | Operating System: Upgrade (Planned)      | Windows servicing / TrustedInstaller restart               |

## Key evidence

### INF5
- 2026-05-14 00:18:26: `MusNotificationUx.exe` initierade restart åt `SE\Labuser_IPT`, reason `Operating System: Service pack (Planned)`, code `0x80020010`. Detta matchar Windows Update restart notification/prompt-spåret.
- 2026-05-14 01:56:01: `svchost.exe` initierade planned OS service pack restart.
- 2026-05-14 01:57:27: `TrustedInstaller.exe` initierade planned OS upgrade restart.
- WindowsUpdateClient visar installation av KB5088859 (.NET CU) 00:21 och KB5087544 (Windows 10 21H2 CU) 01:59.

### INF1
- 2026-05-18 06:03:10: `winlogon.exe`/SYSTEM power off, code `0x500ff`; clean shutdown followed by boot 06:20. Original caller is not exposed in Event ID 1074.
- 2026-04-23 02:10:25: `CcmExec.exe` initiated restart. 2026-04-23 03:07:43: `TrustedInstaller.exe` initiated restart. WindowsUpdateClient had started installing cumulative update around midnight.
- Several Windows Update / Store-app style events continue after May 13–18, including Intel Graphics Experience and Intel Arc Software failures, but not a clear 5/18 Windows Update restart marker.

### INF3
- 2026-04-23 02:09:11: `CcmExec.exe` initiated restart. 2026-04-23 03:08:37: `TrustedInstaller.exe` initiated restart. This mirrors INF1.
- 2026-05-05 08:26:24: `RuntimeBroker.exe`/`SE\Labuser_IPT` power off, reason `Other (Unplanned)`, immediately followed by Kernel-Power 42 entering sleep. This is not a clean Windows Update restart signature.
- 2026-03-17/18: has actual unexpected reboot evidence: Kernel-Power 41, EventLog 6008 and WER bugcheck 0x139 with memory dump.

## Policy and configuration

- All three show `NoAutoRebootWithLoggedOnUsers = 1` and `NoAUShutdownOption = 1`.
- Active Hours are `08–17` on all three, which does not protect night/early morning testing windows.
- INF1/INF3 show WSUS/target policy: `WUServer=http://dhrau1svapwu01.danaher.org:8530`, `UseWUServer=1`, `DisableDualScan=1`, `TargetReleaseVersionInfo=21H2`.
- INF5 does not show those WSUS/TargetRelease/DisableDualScan rows in this collection, which should be checked by IT because INF5 is the clearest Windows Update reboot case.

## Recommended actions

1. Treat INF5 as confirmed Windows Update/restart notification evidence and ask IT to check why `MusNotificationUx.exe`/`svchost.exe`/`TrustedInstaller.exe` could restart while tests may run.
2. Ask IT to compare computer-scope GPO/WSUS/SCCM assignment for CPHD-5RT7YB4 vs CPHD-2MYMZ44 and CPHD-B94KQ54.
3. Review Active Hours. 08–17 is likely wrong for instruments that can run tests outside office hours.
4. Ask whether SCCM/Configuration Manager deadlines or maintenance windows are configured for INF1/INF3. `CcmExec.exe` has directly initiated restarts.
5. Separate issue: investigate INF3 bugcheck 0x139 / MEMORY.DMP from 2026-03-17, because that is crash/instability evidence, not Windows Update prompt behavior.
6. Review GateKeeper only as a secondary stability issue. It appears in WER on INF5, but the logs do not show GateKeeper initiating reboots.