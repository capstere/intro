<#
PQC Barcode Builder v2 - grouped by ADF rules
PowerShell 5.1, no external barcode library.
Generates Code 128B barcode PNGs + CSV + printable HTML scan sheet.
Layout: Sample Point sections with subgroups by ADF profile/rule.

IMPORTANT:
- Print generated HTML at 100% / Actual size.
- Visible SampleID is what GX should receive.
- Encoded barcode includes ADF trigger prefix, e.g. @PQCN@.
- Zebra ADF rules must remove 6-character prefix and send key sequence.
#>

Set-StrictMode -Version 2.0
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Web

$OutputRoot = Join-Path $PSScriptRoot ("PQC_Barcodes_Grouped_" + (Get-Date -Format "yyyyMMdd_HHmmss"))
$BarcodeDir = Join-Path $OutputRoot "barcodes"
New-Item -ItemType Directory -Path $BarcodeDir -Force | Out-Null

$Code128Patterns = @(
'212222','222122','222221','121223','121322','131222','122213','122312','132212','221213',
'221312','231212','112232','122132','122231','113222','123122','123221','223211','221132',
'221231','213212','223112','312131','311222','321122','321221','312212','322112','322211',
'212123','212321','232121','111323','131123','131321','112313','132113','132311','211313',
'231113','231311','112133','112331','132131','113123','113321','133121','313121','211331',
'231131','213113','213311','213131','311123','311321','331121','312113','312311','332111',
'314111','221411','431111','111224','111422','121124','121421','141122','141221','112214',
'112412','122114','122411','142112','142211','241211','221114','413111','241112','134111',
'111242','121142','121241','114212','124112','124211','411212','421112','421211','212141',
'214121','412121','111143','111341','131141','114113','114311','411113','411311','113141',
'114131','311141','411131','211412','211214','211232','2331112'
)

$AdfPrefixes = @{
    'PP'    = '@PQC2@'
    'P'     = '@PQC1@'
    'N'     = '@PQCN@'
    'Blank' = '@PQC0@'
}
$ProfileOrder = @('N','P','PP','Blank')
$ProfileLabels = @{
    'N'     = 'Rule N - sends N'
    'P'     = 'Rule P - sends P'
    'PP'    = 'Rule PP - sends PP'
    'Blank' = 'Rule Blank - sends no letter'
}

function Get-Code128BValues {
    param([Parameter(Mandatory=$true)][string]$Data)
    $values = New-Object System.Collections.Generic.List[int]
    $values.Add(104) # Start Code B
    foreach ($ch in $Data.ToCharArray()) {
        $o = [int][char]$ch
        if ($o -lt 32 -or $o -gt 127) { throw "Unsupported Code128B character: '$ch'" }
        $values.Add($o - 32)
    }
    $checksum = $values[0]
    for ($i = 1; $i -lt $values.Count; $i++) { $checksum += $i * $values[$i] }
    $values.Add($checksum % 103)
    $values.Add(106) # Stop
    return ,$values.ToArray()
}

function New-Code128BarcodePng {
    param(
        [Parameter(Mandatory=$true)][string]$Data,
        [Parameter(Mandatory=$true)][string]$Path,
        [int]$ModuleWidth = 3,
        [int]$Height = 105,
        [int]$QuietModules = 30
    )
    $values = Get-Code128BValues -Data $Data
    $moduleCount = $QuietModules * 2
    foreach ($v in $values) {
        foreach ($c in $Code128Patterns[$v].ToCharArray()) { $moduleCount += [int]::Parse($c) }
    }
    $width = $moduleCount * $ModuleWidth
    $bmp = New-Object System.Drawing.Bitmap $width, $Height
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.Clear([System.Drawing.Color]::White)
    $brush = [System.Drawing.Brushes]::Black
    $x = $QuietModules * $ModuleWidth
    foreach ($v in $values) {
        $black = $true
        foreach ($c in $Code128Patterns[$v].ToCharArray()) {
            $w = [int]::Parse($c) * $ModuleWidth
            if ($black) { $g.FillRectangle($brush, $x, 0, $w, $Height) }
            $x += $w
            $black = -not $black
        }
    }
    $bmp.Save($Path, [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose(); $bmp.Dispose()
}

function Add-BarcodeSet {
    param(
        [Parameter(Mandatory=$true)][System.Collections.ArrayList]$Rows,
        [Parameter(Mandatory=$true)][ref]$Order,
        [Parameter(Mandatory=$true)][string]$BaseID,
        [Parameter(Mandatory=$true)][string[]]$SamplePoints,
        [Parameter(Mandatory=$true)][int]$SampleCode,
        [Parameter(Mandatory=$true)][int[]]$Replicates,
        [Parameter(Mandatory=$true)][int]$ReplicateDigits,
        [Parameter(Mandatory=$true)][scriptblock]$LidCutRule,
        [Parameter(Mandatory=$true)][ValidateSet('PP','P','N','Blank')][string]$ADFProfile,
        [Parameter(Mandatory=$true)][string]$Group
    )
    foreach ($sp in $SamplePoints) {
        foreach ($r in $Replicates) {
            $rep = $r.ToString(("0" * $ReplicateDigits))
            $lid = & $LidCutRule $r
            $sampleId = "{0}_{1}_{2}_{3}{4}" -f $BaseID, $sp, $SampleCode, $rep, $lid
            $prefix = $AdfPrefixes[$ADFProfile]
            [void]$Rows.Add([pscustomobject]@{
                ScanOrder = $Order.Value
                Group = $Group
                BaseID = $BaseID
                SamplePoint = $sp
                SampleCode = $SampleCode
                ReplicateNo = $rep
                LidCut = $lid
                ADFProfile = $ADFProfile
                ADFPrefix = $prefix
                SampleID = $sampleId
                BarcodeData = $prefix + $sampleId
            })
            $Order.Value++
        }
    }
}

# ---------------- CURRENT BATCH CONFIGURATION ----------------
$rows = New-Object System.Collections.ArrayList
$order = 1

# Special Sample Point 00
Add-BarcodeSet -Rows $rows -Order ([ref]$order) -BaseID '121425MMM' -SamplePoints @('00') -SampleCode 1 -Replicates (1..10) -ReplicateDigits 2 -LidCutRule { param($r) if ($r -le 5) {'X'} else {'+'} } -ADFProfile 'P' -Group 'Special SP00 / Code 1 / P'

# Sample Points 01-10
foreach ($sp in (1..10 | ForEach-Object { $_.ToString('00') })) {
    Add-BarcodeSet -Rows $rows -Order ([ref]$order) -BaseID '101525ARMO' -SamplePoints @($sp) -SampleCode 0 -Replicates (1..10) -ReplicateDigits 2 -LidCutRule { param($r) if ($r -le 5) {'X'} else {'+'} } -ADFProfile 'N' -Group ("SP$sp / Code 0 / N")
    Add-BarcodeSet -Rows $rows -Order ([ref]$order) -BaseID '121425MMM' -SamplePoints @($sp) -SampleCode 1 -Replicates (11..18) -ReplicateDigits 2 -LidCutRule { param($r) if ($r -le 14) {'X'} else {'+'} } -ADFProfile 'P' -Group ("SP$sp / Code 1 / P")
    Add-BarcodeSet -Rows $rows -Order ([ref]$order) -BaseID '121725MMM' -SamplePoints @($sp) -SampleCode 2 -Replicates @(19,20) -ReplicateDigits 2 -LidCutRule { param($r) if ($r -eq 19) {'X'} else {'+'} } -ADFProfile 'PP' -Group ("SP$sp / Code 2 / PP")
}

if ($rows.Count -ne 210) { throw "Expected 210 rows, got $($rows.Count)." }

foreach ($row in $rows) {
    $safeSid = $row.SampleID.Replace('+','PLUS')
    $file = "{0:000}_{1}_{2}.png" -f $row.ScanOrder, $safeSid, $row.ADFProfile
    $path = Join-Path $BarcodeDir $file
    New-Code128BarcodePng -Data $row.BarcodeData -Path $path
    $row | Add-Member -NotePropertyName PngFile -NotePropertyValue ("barcodes/" + $file)
}

$csvPath = Join-Path $OutputRoot 'PQC_Batch_210_expected_index.csv'
$rows | Export-Csv -NoTypeInformation -Encoding UTF8 -Path $csvPath

# ---------------- GROUPED HTML OUTPUT ----------------
$htmlPath = Join-Path $OutputRoot 'PQC_Batch_210_PrintSheet_GroupedByRules.html'
$htmlRows = New-Object System.Text.StringBuilder

function Add-GroupHtml {
    param($Builder, [string]$Profile, [object[]]$Items)
    if ($Items.Count -eq 0) { return }
    $prefix = [System.Web.HttpUtility]::HtmlEncode($AdfPrefixes[$Profile])
    $label = [System.Web.HttpUtility]::HtmlEncode($ProfileLabels[$Profile])
    [void]$Builder.AppendLine("<h3>$label <span>encoded prefix: $prefix</span></h3>")
    [void]$Builder.AppendLine('<div class="row head"><div>#</div><div>Sample ID</div><div>Barcode</div><div>Done</div></div>')
    foreach ($row in $Items) {
        $sid = [System.Web.HttpUtility]::HtmlEncode($row.SampleID)
        $meta = [System.Web.HttpUtility]::HtmlEncode(("Code {0} / Rep {1}{2}" -f $row.SampleCode, $row.ReplicateNo, $row.LidCut))
        [void]$Builder.AppendLine("<div class='row'><div>$($row.ScanOrder.ToString('000'))<br><span class='small'>$meta</span></div><div><b>$sid</b></div><div><img class='barcode' src='$($row.PngFile)'></div><div><span class='check'></span></div></div>")
    }
}

foreach ($sp in @('00') + (1..10 | ForEach-Object { $_.ToString('00') })) {
    $spRows = @($rows | Where-Object { $_.SamplePoint -eq $sp })
    $heading = if ($sp -eq '00') { 'Special Sample Point 00' } else { "Sample Point $sp" }
    [void]$htmlRows.AppendLine("<section class='sp'><h2>$heading</h2>")
    foreach ($profile in $ProfileOrder) {
        $items = @($spRows | Where-Object { $_.ADFProfile -eq $profile } | Sort-Object ScanOrder)
        Add-GroupHtml -Builder $htmlRows -Profile $profile -Items $items
    }
    [void]$htmlRows.AppendLine('</section>')
}

$html = @"
<!doctype html>
<html><head><meta charset="utf-8"><title>PQC Batch 210 Barcode Sheet - Grouped by Rules</title>
<style>
@page { size: A4 landscape; margin: 10mm; }
body { font-family: Arial, sans-serif; font-size: 9pt; }
h1 { font-size: 16pt; margin: 0 0 6px 0; }
h2 { font-size: 13pt; margin: 12px 0 4px 0; border-top: 2px solid #000; padding-top: 8px; break-after: avoid; }
h3 { font-size: 10pt; margin: 8px 0 2px 0; padding: 4px; background: #ddd; break-after: avoid; }
h3 span { font-weight: normal; margin-left: 12px; }
.sp { break-after: page; page-break-after: always; }
.row { display: grid; grid-template-columns: 58px 220px 350px 42px; align-items: center; gap: 6px; break-inside: avoid; page-break-inside: avoid; border-bottom: 1px solid #ddd; padding: 3px 0; }
.head { font-weight: bold; background: #eee; border-top: 1px solid #aaa; }
.barcode { max-width: 340px; height: 36px; object-fit: contain; }
.small { font-size: 7pt; color: #333; }
.check { border: 1px solid #000; width: 15px; height: 15px; display: inline-block; }
.warn { border: 1px solid #888; padding: 6px; background: #f7f7f7; margin: 6px 0 10px 0; }
</style></head><body>
<h1>PQC Barcode Scan Sheet - Batch 210 cartridges</h1>
<div class="warn"><b>Print:</b> 100% / Actual size. Visible Sample ID is what GX should receive. Encoded barcode includes hidden ADF trigger prefix.</div>
<p><b>Grouped layout:</b> Sample Point sections, then ADF rule/profile groups. Total: 210 barcodes.</p>
$htmlRows
</body></html>
"@
$html | Set-Content -Encoding UTF8 -Path $htmlPath

Write-Host "Created:" -ForegroundColor Green
Write-Host $OutputRoot
Write-Host "Rows: $($rows.Count)"
Write-Host "Open and print: $htmlPath"
