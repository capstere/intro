﻿# Loggfilen
$logPath = "N:\QC\QC-1\IPT\8. IPT - WR + Rework\1. PQC - Kontrollprovsfil - RÖR EJ -\Aktiveringslogg IPT\ActivateMakro_logg.txt"

# Script for changing trust center settings to allow for macros to run on \\se.cepheid.pri\cepheid sweden\

Set-Location -Path "HKCU:\SOFTWARE\Microsoft\Office\16.0\Excel\Security\Trusted Locations"

# Allow trusted locations
Set-ItemProperty -Path "./" -Name "AllowNetworkLocations" -Value 1

$trusted_locations = Get-ChildItem

# Check if settings need to be changed
$location = 0
foreach ($trusted_location in $trusted_locations) {
    if ( (Get-ItemProperty $trusted_location.PSPath -Name "Path").Path -eq "\\se.cepheid.pri\cepheid sweden\" ) {
Write-Host "       2026  " -ForegroundColor Magenta
Write-Host "    .----------------------------------."
Write-Host "   |  KONTROLLPROVSFIL - Version 2.5   |"
Write-Host "    '----------------------------------'"
Write-Host ""

for ($i=0; $i -lt 3; $i++) {
    Write-Host "`r Synkroniserar..." -ForegroundColor DarkYellow -NoNewline
    Start-Sleep -Milliseconds 500
    Write-Host "`r                    " -NoNewline
    Start-Sleep -Milliseconds 500
}

Write-Host "`r Klar! Filen är synkroniserad." -ForegroundColor Green
[console]::beep(1000,500)
Write-Host "Tryck på Enter för att stänga fönstret."
Read-Host | Out-Null
exit
        while ($true) { Start-Sleep -Seconds 100 }
    }
    $location += 1
}

# Add new registy key allowing macros
New-Item -Path .\ -Name ("Location" + $location)
Set-ItemProperty -Path (".\Location" + $location) -Name "Path" -Value "\\se.cepheid.pri\cepheid sweden\"
Set-ItemProperty -Path (".\Location" + $location) -Name "AllowSubFolders" -Value 1

# Logga användaraktiviteten
$user = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
$logMessage = "$timestamp - User: $user - Ran ConfigureExcelSettings.ps1 for location $networkPath"

Add-Content -Path $logPath -Value $logMessage

Write-Host ""
Write-Host "    .----------------." -ForegroundColor Green
Write-Host "   | .--------------. |" -ForegroundColor Green
Write-Host "   | |  LAB STATUS  | |" -ForegroundColor Green
Write-Host "   | '--------------' |" -ForegroundColor Green
Write-Host "    '----------------'" -ForegroundColor Green
Write-Host "          |  |  " -ForegroundColor Green
Write-Host "          |  |  " -ForegroundColor Green
Write-Host "          |  |  " -ForegroundColor Green
Write-Host ""
Write-Host "Kontrollprovsfilen är nu synkroniserad!" -ForegroundColor Cyan
Write-Host "Tryck på Enter för att stänga fönstret."
Read-Host | Out-Null
exit