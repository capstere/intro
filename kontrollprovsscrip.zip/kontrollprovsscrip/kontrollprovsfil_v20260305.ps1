﻿param(
    [string]$RawDataPath  = "N:\QC\QC-1\IPT\8. IPT - WR + Rework\1. PQC - Kontrollprovsfil - RÖR EJ -\Script Raw Data\raw_data.xlsx",
    [string]$OutputDir    = "N:\QC\QC-1\IPT\8. IPT - WR + Rework\1. PQC - Kontrollprovsfil - RÖR EJ -\Inventeringsrapport",
    [string]$UpdateLogCsvPath = ""
)

# =====================[ Kolumnschema för rådata ]=====================
$InventoryColumns = @{
    PN              = 1
    Lot             = 2
    Exp             = 3
    Qty             = 4
    LastUpdate      = 5
    Signature       = 6
    ProductStartCol = 7
    ProductEndCol   = 13
    Description     = 14
    LabbDescription = 15
    LabbCode        = 16
}

# =====================[ Minimal update-logg (CSV) ]=====================
$script:RawDataBackedUp = $false

if ([string]::IsNullOrWhiteSpace($UpdateLogCsvPath)) {
    $rawDir = Split-Path $RawDataPath -Parent
    $UpdateLogCsvPath = Join-Path $rawDir "UpdateLog_Kontrollprovsfil.csv"
}
$script:UpdateLogCsvPath = $UpdateLogCsvPath

# =====================[ Excel COM: öppna + spara raw_data.xlsx ]=====================
$script:ExcelOpenSave_Enabled = $true
$script:ExcelOpenSave_TimeoutSec = 90

# =====================[ EPPlus bootstrap (minimal) ]=====================

function Ensure-EPPlus {
    param(
        [string] $SourceDllPath = "N:\QC\QC-1\IPT\Skiftspecifika dokument\PQC analyst\JESPER\Scripts\Modules\EPPlus\EPPlus.4.5.3.3\lib\net35\EPPlus.dll"
    )

    $candidatePaths = @()
    if (-not [string]::IsNullOrWhiteSpace($SourceDllPath)) { $candidatePaths += $SourceDllPath }
    $candidatePaths += (Join-Path $PSScriptRoot 'EPPlus.dll')

    foreach ($cand in $candidatePaths) {
        if (-not [string]::IsNullOrWhiteSpace($cand) -and (Test-Path -LiteralPath $cand)) {
            return $cand
        }
    }

    Write-Warning "❌ EPPlus.dll hittades inte. Lägg EPPlus.dll bredvid skriptet eller uppdatera SourceDllPath i Ensure-EPPlus."
    return $null
}

function Load-EPPlus {
    if ([System.AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GetName().Name -eq 'EPPlus' }) {
        return $true
    }

    $dllPath = Ensure-EPPlus
    if (-not $dllPath) { return $false }

    try {
        $bytes = [System.IO.File]::ReadAllBytes($dllPath)
        [System.Reflection.Assembly]::Load($bytes) | Out-Null
        return $true
    }
    catch {
        Write-Warning "❌ EPPlus-fel vid inläsning från '$dllPath': $($_.Exception.Message)"
        return $false
    }
}

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force -ErrorAction SilentlyContinue

if (-not (Load-EPPlus)) {
    Write-Host "Kritisk komponent (EPPlus) kunde inte laddas. Skriptet avbryts." -ForegroundColor Red
    exit 1
}

# =====================[ Utilities ]=====================

function Backup-RawDataFile {
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [string]$BackupDir = "$PSScriptRoot\Backups"
    )
    try {
        if (-not (Test-Path -LiteralPath $BackupDir)) {
            New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
        }
        $timestamp  = (Get-Date).ToString("yyyyMMdd_HHmmss")
        $filename   = Split-Path $FilePath -Leaf
        $backupPath = Join-Path $BackupDir "$($filename)_$timestamp.bak"
        Copy-Item -LiteralPath $FilePath -Destination $backupPath -Force
        Write-Host "Säkerhetskopia skapad: $backupPath" -ForegroundColor Green
    } catch {
        Write-Host "⚠ Kunde inte skapa backup: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

function Pause-AnyKey {
    param([string]$Prompt = "Tryck Enter för att återgå till huvudmenyn...")

    try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") }
    catch { $null = Read-Host $Prompt }
}

function Invoke-WithRetry {
    param(
        [Parameter(Mandatory=$true)][scriptblock]$Action,
        [int]$MaxAttempts = 6,
        [int]$BaseDelayMs = 200
    )
    for ($i=1; $i -le $MaxAttempts; $i++) {
        try { return & $Action }
        catch {
            if ($i -eq $MaxAttempts) { throw }
            $delay = [int]($BaseDelayMs * [Math]::Pow(1.7, ($i-1)) + (Get-Random -Minimum 0 -Maximum 120))
            Start-Sleep -Milliseconds $delay
        }
    }
}

function Invoke-ExcelOpenSave {
    <#
      Minimal “Excel-magi”:
      Öppnar arbetsboken headless, väntar lite på kalkyl/async och sparar.
      Målet är att efterlikna att någon öppnar filen i Excel och trycker Ctrl+S.
    #>
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [int]$TimeoutSec = 90
    )

    if (-not (Test-Path -LiteralPath $Path)) { throw "Saknar fil: $Path" }

    $excel = $null
    $wb = $null
    try {
        $excel = New-Object -ComObject Excel.Application
        $excel.Visible = $false
        $excel.DisplayAlerts = $false
        try { $excel.EnableEvents = $false } catch {}
        try { $excel.AskToUpdateLinks = $false } catch {}

        # Visa “avvakta” så användaren inte stänger appen
        Write-Host "⏳ Avvakta: Excel måste öppna och spara raw_data.xlsx p.g.a att det ska fungera med appen... Så det tar några sekunder extra. Sorry" -ForegroundColor Yellow
        # UpdateLinks=3 => Excel försöker uppdatera externa länkar vid öppning
        $wb = $excel.Workbooks.Open($Path, 3, $false)

        # Visa “avvakta” så användaren inte stänger appen
        Write-Host "⏳ Avvakta: Excel måste öppna och spara raw_data.xlsx p.g.a att det ska fungera med appen... Så det tar några sekunder extra. Sorry" -ForegroundColor Yellow

        # Vänta en kort stund på kalkyl/async (utan att anta refresh-typ)
        $sw = [Diagnostics.Stopwatch]::StartNew()
        $tick = 0
        while ($sw.Elapsed.TotalSeconds -lt $TimeoutSec) {
            $state = 0
            try { $state = [int]$excel.CalculationState } catch { $state = 0 }
            if ($state -eq 0) { break } # 0 = xlDone
            $tick++
            if (($tick % 10) -eq 0) { Write-Host "   ... fortfarande igång ..." -ForegroundColor DarkYellow }
            Start-Sleep -Milliseconds 200
        }
        $sw.Stop() | Out-Null

        # Spara (det är detta du behöver för att “uppdateringen” ska bli verklig på disk)
        $wb.Save()
        return $true
    } finally {
        try { if ($wb) { $wb.Close($true) | Out-Null } } catch {}
        try { if ($excel) { $excel.Quit() | Out-Null } } catch {}
        try { if ($wb) { [Runtime.InteropServices.Marshal]::ReleaseComObject($wb) | Out-Null } } catch {}
        try { if ($excel) { [Runtime.InteropServices.Marshal]::ReleaseComObject($excel) | Out-Null } } catch {}
        [GC]::Collect()
        [GC]::WaitForPendingFinalizers()
    }
}


# =====================[ CSV log (append-only) ]=====================

function Ensure-UpdateLogCsv {
    param([Parameter(Mandatory=$true)][string]$Path)

    $dir = Split-Path $Path -Parent
    if (-not (Test-Path -LiteralPath $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }

    if (Test-Path -LiteralPath $Path) { return }

    $header = 'Timestamp;User;Signature;Action;PN;Row;OldLot;OldExp;OldQty;NewLot;NewExp;NewQty;Machine'
    $utf8Bom = New-Object System.Text.UTF8Encoding($true)

    try {
        $fs = [System.IO.File]::Open($Path, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::Read)
        try {
            $bytes = $utf8Bom.GetBytes($header + [Environment]::NewLine)
            $fs.Write($bytes, 0, $bytes.Length)
            $fs.Flush()
        } finally {
            $fs.Close()
        }
    }
    catch [System.IO.IOException] {
        if (-not (Test-Path -LiteralPath $Path)) {
            throw "Kunde inte skapa CSV-logg '$Path': $($_.Exception.Message)"
        }
    }
    catch {
        throw "Kunde inte skapa CSV-logg '$Path': $($_.Exception.Message)"
    }
}

function CsvCell {
    param([string]$Text)
    if ($null -eq $Text) { $Text = "" }
    $t = $Text -replace "(\r\n|\n|\r|\t)", " "
    $t = $t.Trim()
    $t = $t -replace '"','""'
    return '"' + $t + '"'
}

function Append-CsvLineWithRetry {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$Line
    )

    Invoke-WithRetry -Action {
        try {
            $fs = [System.IO.File]::Open($Path, [System.IO.FileMode]::Append, [System.IO.FileAccess]::Write, [System.IO.FileShare]::Read)
            try {
                $bytes = [System.Text.Encoding]::UTF8.GetBytes($Line + [Environment]::NewLine)
                $fs.Write($bytes, 0, $bytes.Length)
                $fs.Flush()
            } finally {
                $fs.Close()
            }
        }
        catch [System.IO.IOException] {
            throw
        }
    } | Out-Null
}

# =====================[ CSV spool / fail-safe ]=====================

function Get-UpdateLogSpoolPath {
    param([Parameter(Mandatory=$true)][string]$MainCsvPath)
    $dir = Split-Path $MainCsvPath -Parent
    $name = [System.IO.Path]::GetFileNameWithoutExtension($MainCsvPath)
    $spoolName = "{0}.SPOOL.{1}.csv" -f $name, $env:COMPUTERNAME
    return (Join-Path $dir $spoolName)
}

function Write-UpdateLogSpoolLine {
    param(
        [Parameter(Mandatory=$true)][string]$MainCsvPath,
        [Parameter(Mandatory=$true)][string]$Line
    )

    $spool = Get-UpdateLogSpoolPath -MainCsvPath $MainCsvPath

    if (-not (Test-Path -LiteralPath $spool)) {
        $header = 'Timestamp;User;Signature;Action;PN;Row;OldLot;OldExp;OldQty;NewLot;NewExp;NewQty;Machine'
        $utf8Bom = New-Object System.Text.UTF8Encoding($true)

        try {
            $fs = [System.IO.File]::Open($spool, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::Read)
            try {
                $bytes = $utf8Bom.GetBytes($header + [Environment]::NewLine)
                $fs.Write($bytes, 0, $bytes.Length)
                $fs.Flush()
            } finally {
                $fs.Close()
            }
        }
        catch [System.IO.IOException] {
        }
    }
    Append-CsvLineWithRetry -Path $spool -Line $Line
}

function Flush-UpdateLogSpool {
    param([Parameter(Mandatory=$true)][string]$MainCsvPath)

    $dir  = Split-Path $MainCsvPath -Parent
    $name = [System.IO.Path]::GetFileNameWithoutExtension($MainCsvPath)

    $spools = Get-ChildItem -LiteralPath $dir -Filter ("{0}.SPOOL.*.csv" -f $name) -ErrorAction SilentlyContinue
    if (-not $spools) { return }

    foreach ($spoolFile in $spools) {
        try {
            $lines = Get-Content -LiteralPath $spoolFile.FullName -ErrorAction Stop
            if ($lines.Count -le 1) {
                Remove-Item -LiteralPath $spoolFile.FullName -Force -ErrorAction SilentlyContinue
                continue
            }
            for ($i=1; $i -lt $lines.Count; $i++) {
                Append-CsvLineWithRetry -Path $MainCsvPath -Line $lines[$i]
            }
            Remove-Item -LiteralPath $spoolFile.FullName -Force -ErrorAction SilentlyContinue
        }
        catch {
        
            continue
        }
    }
}

function Write-UpdateLogRow {
    param(
        [Parameter(Mandatory=$true)][string]$PN,
        [Parameter(Mandatory=$true)][string]$Signature,
        [Parameter(Mandatory=$true)][ValidateSet("ADD","REMOVE","QTY","OVERWRITE")][string]$Action,
        [int]$RowNumber = 0,
        [string]$OldLot, [string]$OldExp, [string]$OldQty,
        [string]$NewLot, [string]$NewExp, [string]$NewQty
    )

    $path = $script:UpdateLogCsvPath
    Ensure-UpdateLogCsv -Path $path

    Flush-UpdateLogSpool -MainCsvPath $path

    $ts   = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $user = [Environment]::UserName
    $pc   = $env:COMPUTERNAME

        $line = (@(
        CsvCell $ts,
        CsvCell $user,
        CsvCell $Signature,
        CsvCell $Action,
        CsvCell $PN,
        CsvCell ([string]$RowNumber),
        CsvCell $OldLot, CsvCell $OldExp, CsvCell $OldQty,
        CsvCell $NewLot, CsvCell $NewExp, CsvCell $NewQty,
        CsvCell $pc
    ) -join ';')

    try {
        Append-CsvLineWithRetry -Path $path -Line $line
    }
    catch {

        Write-UpdateLogSpoolLine -MainCsvPath $path -Line $line
        throw "CSV-loggen var låst/otillgänglig. Loggrad spools i samma mapp som huvud-CSV och flushas automatiskt nästa gång (eller av valfri körning när CSV:n går att skriva till). Orsak: $($_.Exception.Message)"
    }
}


# =====================[ Auth + Signature ]=====================

function Request-Password {
    $autoUsers = @("vivian.dao", "elin.sidstedt", "jesper.fredriksson", "afnan.vijitraphongs")
    $currentUser = [Environment]::UserName.ToLower()
    if ($autoUsers -contains $currentUser) {
         Write-Host "Automatiskt godkänd för $currentUser utan lösenord." -ForegroundColor Green
         return $true
    }
    do {
         $securePwd = Read-Host "Ange lösenord eller tryck Enter för PQC-konto" -AsSecureString
         $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePwd)
         $unsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
         [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
         if ($unsecurePassword -eq 'labbkontroll') { return $true }
         Write-Host "Fel lösenord. Tryck (1) för att återgå till huvudmenyn." -ForegroundColor Red -BackgroundColor DarkYellow
         $choice = Read-Host "Ange ditt val"
         if ($choice -eq '1') { return $false }
    } while ($true)
}

function Get-UserSignature {
    param([string]$Prompt = "Ange din signatur för att bekräfta ändringarna")

    $userSignature = @{
        "jesper.fredriksson"   = "JESP"
        "elin.sidstedt"        = "ELS"
        "vivian.dao"           = "vdao"
        "afnan.vijitraphongs"  = "AFVI"
    }

    $currentUser = [Environment]::UserName.ToLower()

    if ($userSignature.ContainsKey($currentUser)) {
        Write-Host "Automatisk signatur för $currentUser $($userSignature[$currentUser])" -ForegroundColor Green
        return $userSignature[$currentUser]
    }

    do {
        $signature = Read-Host $Prompt
        if ($signature.Length -ge 3 -and $signature.Length -le 4) { return $signature }
        Write-Host "Ogiltig signatur – måste vara exakt 3-4 tecken." -ForegroundColor Red
    } while ($true)
}

# =====================[ Date parsing ]=====================

function Try-ParseInventoryDate {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text) -or $Text -eq 'N/A') { return $null }

    try {
        if ($Text -match '^\d{4}-\d{2}-\d{2}$') {
            return [datetime]$Text
        }
        elseif ($Text -match '^\d{4}-\d{2}$') {
            $year  = [int]$Text.Substring(0,4)
            $month = [int]$Text.Substring(5,2)
            $first = New-Object datetime($year, $month, 1)
            return $first.AddMonths(1).AddDays(-1)
        }
        return $null
    } catch { return $null }
}

function Read-ValidExpiryDate {
    param([string]$Prompt = "Ange utgångsdatum (YYYY-MM-DD eller YYYY-MM)")

    while ($true) {
        $input = Read-Host $Prompt
        if ([string]::IsNullOrWhiteSpace($input)) {
            Write-Host "Utgångsdatum får inte vara tomt." -ForegroundColor Red
            continue
        }
        if ($input -notmatch '^\d{4}-\d{2}-\d{2}$' -and $input -notmatch '^\d{4}-\d{2}$') {
            Write-Host "Ogiltigt format. Använd 'YYYY-MM-DD' eller 'YYYY-MM'." -ForegroundColor Red
            continue
        }
        $parsed = Try-ParseInventoryDate -Text $input
        if (-not $parsed) {
            Write-Host "Ogiltigt datum (t.ex. fel månad/dag). Försök igen." -ForegroundColor Red
            continue
        }
        return $input
    }
}

# =====================[ EPPlus helpers ]=====================

function Open-ExcelPackageWithRetry {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [int]$MaxAttempts = 5,
        [int]$DelaySeconds = 2
    )

    for ($attempt=1; $attempt -le $MaxAttempts; $attempt++) {
        try {
            $file = New-Object System.IO.FileInfo($Path)
            return (New-Object OfficeOpenXml.ExcelPackage($file))
        }
        catch {
            Write-Host "Kunde inte öppna '$Path' (försök $attempt/$MaxAttempts). Fel: $($_.Exception.Message)" -ForegroundColor Yellow
            Start-Sleep -Seconds $DelaySeconds
        }
    }

    Write-Host "❌ Gav upp efter $MaxAttempts försök att öppna '$Path'." -ForegroundColor Red
    return $null
}

# =====================[ Core: Update inventory ]=====================

function Update-ExcelInventory {
    param([Parameter(Mandatory=$true)][string]$FilePath)

    $package = $null
    try {
        $package = Open-ExcelPackageWithRetry -Path $FilePath
        if (-not $package) { return }

        $sheet = $package.Workbook.Worksheets[1]
        if (-not $sheet) {
            Write-Host "Blad 1 saknas i filen. Avbryter..." -ForegroundColor Red
            return
        }

        $rowCount = $sheet.Dimension.End.Row
        while ($true) {
            Clear-Host
            Write-Host "================ Uppdatera Kontrollprovsfil =================" -ForegroundColor Cyan
            Write-Host "CSV-logg: $($script:UpdateLogCsvPath)" -ForegroundColor DarkGray
            Write-Host "`nAnge P/N eller skriv [Q] för att avbryta"
            $pnToUpdate = Read-Host
            if ($pnToUpdate -eq 'Q') { return }
            if ([string]::IsNullOrWhiteSpace($pnToUpdate)) {
                Write-Host "P/N får inte vara tomt. Försök igen!" -ForegroundColor DarkYellow
                Pause-AnyKey
                continue
            }

            $foundRows = @()
            for ($i = 2; $i -le $rowCount; $i++) {
                if ($sheet.Cells[$i,$InventoryColumns.PN].Text -eq $pnToUpdate) {
                    $foundRows += $i
                    if ($foundRows.Count -eq 4) { break }
                }
            }
            if ($foundRows.Count -eq 0) {
                Write-Host "Inget P/N hittades som matchar '$pnToUpdate'." -ForegroundColor Red
                Pause-AnyKey
                continue
            }

            $index = 1
            foreach ($row in $foundRows) {
                $lotNum     = $sheet.Cells[$row,$InventoryColumns.Lot].Text
                $expiryDate = $sheet.Cells[$row,$InventoryColumns.Exp].Text
                $quantity   = $sheet.Cells[$row,$InventoryColumns.Qty].Text
                Write-Host "`n${index}: Lot: ${lotNum}, Exp: ${expiryDate}, Qty: ${quantity}" -ForegroundColor Green
                $index++
            }

            while ($true) {
                Write-Host "`nVälj en rad att uppdatera (1-$($foundRows.Count)) eller tryck 'B' för att backa"
                $choice = Read-Host
                if ($choice -eq 'Q') { return }
                if ($choice -eq 'B') { break }

                if (($choice -as [int]) -and ($choice -gt 0) -and ($choice -le $foundRows.Count)) {
                    $selectedRow = $foundRows[$choice - 1]
                }
                else {
                    Write-Host "Ogiltigt val, försök igen." -ForegroundColor Red
                    continue
                }

                $oldLot = $sheet.Cells[$selectedRow,$InventoryColumns.Lot].Text
                $oldExp = $sheet.Cells[$selectedRow,$InventoryColumns.Exp].Text
                $oldQty = $sheet.Cells[$selectedRow,$InventoryColumns.Qty].Text

                Write-Host "=============================================" -ForegroundColor Cyan
                Write-Host "Vad vill du uppdatera?"
                Write-Host "1: Nytt Lotnummer, Exp och Qty" -ForegroundColor Magenta
                Write-Host "2: Endast kvantitet"           -ForegroundColor Magenta
                Write-Host "3: Ta bort post (markeras som N/A)" -ForegroundColor Magenta
                Write-Host "B: Back"
                $updateChoice = Read-Host "Välj"
                if ($updateChoice -eq 'B') { continue }

                $newLot = $oldLot; $newExp = $oldExp; $newQty = $oldQty

                switch ($updateChoice) {
                    '1' {
                        $newLot = Read-Host "Ange Lotnummer"
                        $newExp = Read-ValidExpiryDate
                        $newQty = Read-Host "Ange antal"
                    }
                    '2' { $newQty = Read-Host "Ange nytt antal" }
                    '3' { $newLot = "N/A"; $newExp = "N/A"; $newQty = "N/A" }
                    default {
                        Write-Host "Ogiltigt val." -ForegroundColor Red
                        continue
                    }
                }

                if ($oldLot -eq $newLot -and $oldExp -eq $newExp -and $oldQty -eq $newQty) {
                    Write-Host "Inga ändringar jämfört med befintligt värde. Ingen uppdatering/loggning görs." -ForegroundColor Yellow
                    continue
                }

                if ($updateChoice -ne '3') {
                    Write-Host "`nBekräfta uppdateringen:" -ForegroundColor Cyan
                    Write-Host "Lotnummer: $newLot" -ForegroundColor DarkYellow
                    Write-Host "Utgångsdatum: $newExp" -ForegroundColor DarkYellow
                    Write-Host "Antal: $newQty" -ForegroundColor DarkYellow
                    $confirm = Read-Host "`nÄr detta korrekt? (1) Ja / (2) Nej"
                    if ($confirm -ne '1') {
                        Write-Host "Inga ändringar sparades."
                        continue
                    }
                }

                $userSignature = Get-UserSignature -Prompt ($(if ($updateChoice -eq '3') { "Ange signatur för borttagning" } else { "Ange din signatur" }))
                $today = (Get-Date).ToString("yyyy-MM-dd")

                $sheet.Cells[$selectedRow,$InventoryColumns.Lot].Value        = $newLot
                $sheet.Cells[$selectedRow,$InventoryColumns.Exp].Value        = $newExp
                $sheet.Cells[$selectedRow,$InventoryColumns.Qty].Value        = $newQty
                $sheet.Cells[$selectedRow,$InventoryColumns.LastUpdate].Value = ($(if ($updateChoice -eq '3') { "N/A" } else { $today }))
                $sheet.Cells[$selectedRow,$InventoryColumns.Signature].Value  = ($(if ($updateChoice -eq '3') { "N/A" } else { $userSignature }))

                if (-not $script:RawDataBackedUp) {
                    Backup-RawDataFile -FilePath $FilePath
                    $script:RawDataBackedUp = $true
                }

                $action = "OVERWRITE"
                if ($newLot -eq "N/A" -and $newExp -eq "N/A" -and $newQty -eq "N/A") {
                    $action = "REMOVE"
                }
                elseif ($oldLot -eq "N/A" -and $oldExp -eq "N/A" -and $oldQty -eq "N/A" -and
                        ($newLot -ne "N/A" -or $newExp -ne "N/A" -or $newQty -ne "N/A")) {
                    $action = "ADD"
                }
                elseif ($oldLot -eq $newLot -and $oldExp -eq $newExp -and $oldQty -ne $newQty) {
                    $action = "QTY"
                }

                $saved = $false
                try {
                    $package.Save()
                    $saved = $true
                }
                catch {
                    Write-Host "❌ Kunde inte spara ändringen i raw_data.xlsx. CSV-logg skrivs inte. Fel: $($_.Exception.Message)" -ForegroundColor Red
                }

                if ($saved -and $script:ExcelOpenSave_Enabled) {
                    try {
                        Invoke-WithRetry -MaxAttempts 3 -BaseDelayMs 350 -Action {
                            Invoke-ExcelOpenSave -Path $FilePath -TimeoutSec $script:ExcelOpenSave_TimeoutSec | Out-Null
                        }
                        Write-Host "✅ raw_data.xlsx öppnad + sparad via Excel." -ForegroundColor Green
                    } catch {
                        Write-Host "⚠ Kunde inte öppna+spara raw_data.xlsx via Excel. Filen är sparad av EPPlus men kan kräva manuell öppning i Excel. Fel: $($_.Exception.Message)" -ForegroundColor Yellow
                    }
                }

                if ($saved) {
                    try {
                        Write-UpdateLogRow -PN $pnToUpdate -Signature $userSignature -Action $action -RowNumber $selectedRow `
                            -OldLot $oldLot -OldExp $oldExp -OldQty $oldQty `
                            -NewLot $newLot -NewExp $newExp -NewQty $newQty

                        Write-Host "`n✅ Uppdatering sparad + loggad i CSV ($action)." -ForegroundColor Green
                    }
                    catch {
                        Write-Host "⚠ Uppdatering sparad, men kunde inte skriva till CSV-loggen. Fel: $($_.Exception.Message)" -ForegroundColor Yellow
                    }
                }

$nextAction = Read-Host "`nUppdatera (1) nytt P/N, (2) avsluta, (Enter) fortsätt med samma P/N"
                if ($nextAction -eq '1') { break }
                if ($nextAction -eq '2') { return }

                Clear-Host
                Write-Host "================ Uppdatera Kontrollprovsfil =================" -ForegroundColor Cyan
                Write-Host "`nP/N: $pnToUpdate"
                $index = 1
                foreach ($row in $foundRows) {
                    $lotNum     = $sheet.Cells[$row,$InventoryColumns.Lot].Text
                    $expiryDate = $sheet.Cells[$row,$InventoryColumns.Exp].Text
                    $quantity   = $sheet.Cells[$row,$InventoryColumns.Qty].Text
                    Write-Host "`n${index}: Lot: ${lotNum}, Exp: ${expiryDate}, Qty: ${quantity}" -ForegroundColor Green
                    $index++
                }
            }
        }
    }
    finally {
        if ($package) { $package.Dispose() }
    }
}

# =====================[ Reports (kept, no logging) ]=====================

function Generate-InventoryReport {
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [Parameter(Mandatory=$true)][string]$OutputDir
    )

    $package = $null
    try {
        $package = Open-ExcelPackageWithRetry -Path $FilePath
        if (-not $package) { return }

        $sheet = $package.Workbook.Worksheets[1]
        if (-not $sheet) { Write-Host "Blad 1 saknas, avbryter..." -ForegroundColor Red; return }

        $rowCount = $sheet.Dimension.End.Row
        $data = @()
        for ($i=2; $i -le $rowCount; $i++) {
            $data += [pscustomobject]@{
                PN              = $sheet.Cells[$i,$InventoryColumns.PN].Text
                LotNr           = $sheet.Cells[$i,$InventoryColumns.Lot].Text
                Exp             = $sheet.Cells[$i,$InventoryColumns.Exp].Text
                Qty             = $sheet.Cells[$i,$InventoryColumns.Qty].Text
                LabbCode        = $sheet.Cells[$i,$InventoryColumns.LabbCode].Text
                LabbDescription = $sheet.Cells[$i,$InventoryColumns.LabbDescription].Text
            }
        }

        if (-not (Test-Path -LiteralPath $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }

        $dateStamp = (Get-Date -Format "yyyyMMdd")
        $xlsxPath  = Join-Path $OutputDir ("InventoryReport_{0}.xlsx" -f $dateStamp)
        if (Test-Path -LiteralPath $xlsxPath) { Remove-Item -LiteralPath $xlsxPath -Force }

        $invPkg = New-Object OfficeOpenXml.ExcelPackage
        try {
            $ws = $invPkg.Workbook.Worksheets.Add("Inventory")

            $ws.Cells["A1"].Value = "PN"
            $ws.Cells["B1"].Value = "LotNr"
            $ws.Cells["C1"].Value = "Exp"
            $ws.Cells["D1"].Value = "Qty"
            $ws.Cells["E1"].Value = "LabbCode"
            $ws.Cells["F1"].Value = "LabbDescription"

            $r=2
            foreach ($it in $data) {
                $ws.Cells["A$r"].Value = $it.PN
                $ws.Cells["B$r"].Value = $it.LotNr
                $ws.Cells["C$r"].Value = $it.Exp
                $ws.Cells["D$r"].Value = $it.Qty
                $ws.Cells["E$r"].Value = $it.LabbCode
                $ws.Cells["F$r"].Value = $it.LabbDescription
                $r++
            }

            if ($r -gt 2) {
                $lastRow = $r-1
                $used = $ws.Cells["A1:F$lastRow"]
                $hdr = $ws.Cells["A1:F1"]
                $hdr.Style.Font.Bold = $true
                $ws.View.FreezePanes(2,1)
                $used.AutoFitColumns()
            }

            $invPkg.SaveAs((New-Object System.IO.FileInfo($xlsxPath)))
            Write-Host "✅ XLSX-rapport genererad: $xlsxPath" -ForegroundColor Green
        } finally { if ($invPkg) { $invPkg.Dispose() } }
    }
    catch {
        Write-Host "Fel vid inventeringsrapport: $($_.Exception.Message)" -ForegroundColor Red
    }
    finally { if ($package) { $package.Dispose() } }
}

function Generate-ExpiringPNsReport {
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [Parameter(Mandatory=$true)][string]$OutputDir
    )

    $package = $null
    try {
        Clear-Host
        Write-Host "==== Material med kort utgångsdatum ====" -ForegroundColor Cyan

        if (-not (Test-Path -LiteralPath $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }

        $package = Open-ExcelPackageWithRetry -Path $FilePath
        if (-not $package) { return }

        $sheet = $package.Workbook.Worksheets[1]
        if (-not $sheet) { Write-Host "Blad saknas, avbryter..." -ForegroundColor Red; return }

        $rowCount  = $sheet.Dimension.End.Row
        $now       = Get-Date
        $lowerDate = $now.AddDays(-15)
        $upperDate = $now.AddDays(30)

        $dateStamp = (Get-Date -Format "yyyyMMdd")
        $xlsxPath  = Join-Path $OutputDir ("ExpiringPNsReport_{0}.xlsx" -f $dateStamp)
        if (Test-Path -LiteralPath $xlsxPath) { Remove-Item -LiteralPath $xlsxPath -Force }

        $repPkg = New-Object OfficeOpenXml.ExcelPackage
        try {
            $ws = $repPkg.Workbook.Worksheets.Add("Expiring")
            $ws.Cells["A1"].Value = "PN"
            $ws.Cells["B1"].Value = "Lotnummer"
            $ws.Cells["C1"].Value = "Exp. Date"
            $ws.Cells["D1"].Value = "Beskrivning"

            $outRow=2
            for ($i=2; $i -le $rowCount; $i++) {
                $expText = $sheet.Cells[$i,$InventoryColumns.Exp].Text
                $expDate = Try-ParseInventoryDate -Text $expText
                if ($expDate -and $expDate -ge $lowerDate -and $expDate -le $upperDate) {
                    $ws.Cells["A$outRow"].Value = $sheet.Cells[$i,$InventoryColumns.PN].Text
                    $ws.Cells["B$outRow"].Value = $sheet.Cells[$i,$InventoryColumns.Lot].Text
                    $ws.Cells["C$outRow"].Value = $expText
                    $ws.Cells["D$outRow"].Value = $sheet.Cells[$i,$InventoryColumns.Description].Text
                    $outRow++
                }
            }

            if ($outRow -gt 2) {
                $lastRow = $outRow-1
                $ws.View.FreezePanes(2,1)
                $ws.Cells["A1:D$lastRow"].AutoFitColumns()
                $repPkg.SaveAs((New-Object System.IO.FileInfo($xlsxPath)))
                Write-Host "✅ Rapport genererad: $xlsxPath" -ForegroundColor Green
                Invoke-Item $xlsxPath
            } else {
                Write-Host "Inga poster hittades inom datumintervallet." -ForegroundColor Yellow
            }
        } finally { if ($repPkg) { $repPkg.Dispose() } }
    }
    catch {
        Write-Host "Fel vid generering: $($_.Exception.Message)" -ForegroundColor Red
    }
    finally { if ($package) { $package.Dispose() } }
}

function ShowProductInfo {
    param([Parameter(Mandatory=$true)][string]$FilePath)

    Clear-Host
    Write-Host "================ Sök på Produkt för material =================" -ForegroundColor Cyan
    $productName = Read-Host "`nAnge produktnamn"
    if ([string]::IsNullOrWhiteSpace($productName)) { return }

    $package = $null
    try {
        $package = Open-ExcelPackageWithRetry -Path $FilePath
        if (-not $package) { return }

        $sheet = $package.Workbook.Worksheets[1]
        if (-not $sheet) { Write-Host "Inget blad hittades." -ForegroundColor Red; return }

        $rowCount = $sheet.Dimension.End.Row
        $productInfo = @()

        for ($i=2; $i -le $rowCount; $i++) {
            for ($j=$InventoryColumns.ProductStartCol; $j -le $InventoryColumns.ProductEndCol; $j++) {
                if ($sheet.Cells[$i,$j].Text -eq $productName) {
                    $lot = $sheet.Cells[$i,$InventoryColumns.Lot].Text
                    $exp = $sheet.Cells[$i,$InventoryColumns.Exp].Text
                    if ($lot -ne "N/A" -and $exp -ne "N/A") {
                        $productInfo += [pscustomobject]@{
                            PN          = $sheet.Cells[$i,$InventoryColumns.PN].Text
                            LotNr       = $lot
                            Exp         = $exp
                            Description = $sheet.Cells[$i,$InventoryColumns.Description].Text
                        }
                    }
                }
            }
        }

        if ($productInfo.Count -gt 0) {
            Write-Host "`nProduktinformation hittades:" -ForegroundColor Green
            $productInfo | Format-Table -AutoSize
        } else {
            Write-Host "`nIngen information hittades för '$productName'." -ForegroundColor Yellow
        }
    }
    finally { if ($package) { $package.Dispose() } }
}

function Collect-Feedback {
    Clear-Host
    Write-Host "========== Feedback ==========" -ForegroundColor Cyan
    Write-Host "OBS: Feedback loggas inte i denna slim-version." -ForegroundColor DarkGray
    $null = Read-Host "`nAnge din feedback (tryck Enter för att avsluta)"
}

# =====================[ Main menu ]=====================

function Main-Menu {
    do {
        Clear-Host
        Write-Host "Rådatafil : $RawDataPath" -ForegroundColor DarkGray
        Write-Host "CSV-logg  : $($script:UpdateLogCsvPath)" -ForegroundColor DarkGray

        Write-Host "`nKontrollprovsfil - Slim (CSV log only)" -ForegroundColor Cyan
        Write-Host "==============================================================" -ForegroundColor Cyan
        Write-Host "1: Uppdatera Kontrollprovsfil (lösenord krävs)" -ForegroundColor Magenta
        Write-Host "2: Generera inventeringsrapport (lösenord krävs)" -ForegroundColor Magenta
        Write-Host "3: Visa material med kort utgångsdatum"
        Write-Host "4: Visa materialinformation för produkt"
        Write-Host "5: Feedback (ingen loggning)"
        Write-Host "6: Avsluta"
        Write-Host "==============================================================" -ForegroundColor Cyan

        $choice = Read-Host "Välj"
        switch ($choice) {
            '1' { if (Request-Password) { Update-ExcelInventory -FilePath $RawDataPath } }
            '2' { if (Request-Password) { Generate-InventoryReport -FilePath $RawDataPath -OutputDir $OutputDir } }
            '3' { Generate-ExpiringPNsReport -FilePath $RawDataPath -OutputDir $OutputDir }
            '4' { ShowProductInfo -FilePath $RawDataPath }
            '5' { Collect-Feedback }
            '6' { return }
            default { Write-Host "Ogiltigt val." -ForegroundColor Red }
        }

        Pause-AnyKey
    } while ($true)
}

# =====================[ Startup ]=====================

if (-not (Test-Path -LiteralPath $RawDataPath)) {
    Write-Host "❌ Hittar inte rådatafilen:" -ForegroundColor Red
    Write-Host "   $RawDataPath" -ForegroundColor Yellow
    exit 1
}

Ensure-UpdateLogCsv -Path $script:UpdateLogCsvPath
Main-Menu