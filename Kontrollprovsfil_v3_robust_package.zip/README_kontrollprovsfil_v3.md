# Kontrollprovsfil v3 – robust PowerShell-version

## Leverans

Huvudfil: `kontrollprovsfil_v3_robust.ps1`

Versionen är en ombyggnad av `kontrollprovsfil_v20260525.ps1`, inte bara en kosmetisk refaktorering. Kärnfunktionerna finns kvar:

- uppdatering av Lot, utgångsdatum och antal
- uppdatering av endast antal
- borttagning av inventeringspost
- inventeringsrapport
- rapport för kort utgångsdatum
- sökning efter material per produkt

## Viktigaste förändringarna

### Transaktion och audit

Varje dataändring får ett unikt `TransactionId` och följer detta flöde:

1. exklusivt lås tas för rådatafilen
2. raden läses om och jämförs med värdena som användaren såg
3. en lokal återställningsjournal skapas
4. auditposten `PENDING` skrivs innan rådata ändras
5. en backup skapas och verifieras med SHA-256
6. ändringen sparas till en temporär arbetsbok
7. arbetsbokens schema och nya radvärden verifieras
8. originalfilen ersätts med `System.IO.File.Replace`
9. installerad fil verifieras med SHA-256
10. auditposten `COMMITTED` skrivs

Om något går fel före `COMMITTED` försöker scriptet återställa den verifierade backupen. Oavslutade lokala journaler kontrolleras vid nästa start.

### Saker som tagits bort

- `Set-ExecutionPolicy Bypass`
- delat klartextlösenord `labbkontroll`
- fritextsignatur som kunde anges av användaren
- automatisk ersättning av en auditfil som bedömts som korrupt
- semikolonräkning som kontroll av CSV
- spool- och emergency-loggar som kunde skapa flera parallella auditkällor
- Excel COM open/save och den falska timeouten kring COM-anropet
- backup endast en gång per scriptkörning
- rapportfiler som skrevs över samma dag
- godtycklig gräns på fyra träffar per P/N
- feedbackmenyn, eftersom den inte hör till inventeringens kärnflöde

### Behörighet och signatur

Uppdatering tillåts endast för Windows-användare i parametern `AuthorizedUsers`. Signaturen hämtas från `SignatureMap`; användaren kan inte skriva in valfri signatur.

Detta ersätter inte Windows-behörigheter. Rådatafil, auditfil, backupmapp, script och EPPlus-DLL måste skyddas med lämpliga NTFS- och share-ACL:er.

### Ny auditfil

Standardfilen är:

`UpdateLog_Kontrollprovsfil_v3.csv`

Den gamla auditfilen ändras inte automatiskt. V3-filen har bland annat:

- `TransactionId`
- `Status`
- `DomainUser`
- SHA-256 före och efter ändringen
- meddelande och backuppath

Möjliga statusvärden är bland annat `PENDING`, `COMMITTED`, `ABORTED`, `ROLLED_BACK`, `RECOVERED_COMMIT` och `REVIEW_REQUIRED`.

## Konfiguration före produktionsprov

Kontrollera parametrarna i början av scriptet:

- `RawDataPath`
- `OutputDir`
- `AuditLogPath`
- `BackupDir`
- `EPPlusDllPath`
- `AuthorizedUsers`
- `SignatureMap`

För starkare kontroll kan `EPPlusSha256` fyllas med den godkända DLL-filens SHA-256. Om värdet lämnas tomt kontrolleras endast att assemblyn verkligen heter EPPlus.

## Rekommenderat test i kontrollerad kopia

1. Kopiera `raw_data.xlsx` till en separat testmapp.
2. Peka scriptets sökvägar mot testmappen.
3. Kör med Windows PowerShell 5.1 och den EPPlus-version som ska användas i produktion.
4. Verifiera ADD, QTY, OVERWRITE och REMOVE.
5. Verifiera att REMOVE behåller datum och den verkliga användarens signatur i kolumn 5–6.
6. Ta bort skrivrättighet till auditmappen och verifiera att rådata inte ändras.
7. Ta bort skrivrättighet till backupmappen och verifiera att rådata inte ändras.
8. Öppna rådatafilen exklusivt och verifiera att ändringen stoppas utan delvis sparad fil.
9. Starta två sessioner och verifiera konfliktkontrollen.
10. Kontrollera att rapportnamn är unika och att befintliga rapporter inte skrivs över.
11. Kontrollera formler och format i samtliga arbetsblad efter en teständring.
12. Verifiera återställningsjournalerna under `%LOCALAPPDATA%\Cepheid\Kontrollprovsfil\Transactions`.

## Viktig begränsning

Scriptet har granskats statiskt och strukturellt i denna miljö. Det har inte körts i er Windows-/SMB-/Excelmiljö eller mot den angivna EPPlus-DLL-filen. `System.IO.File.Replace` ska därför verifieras specifikt på den aktuella nätverksresursen innan produktionssättning.
