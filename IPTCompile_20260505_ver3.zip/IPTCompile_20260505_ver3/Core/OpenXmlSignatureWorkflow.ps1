﻿function Get-WorksheetSignatureTargets_OpenXml {
    param(
        [Parameter(Mandatory=$true)][ValidateSet('Sammanstallning','Granskning')][string]$Mode
    )
    if ($Mode -eq 'Sammanstallning') {
        return @(
            @{ Name='Test Summary';                 NameLabelCol='B'; NameNeedle='Recorded By:';       NameWriteCol='C'; DateLabelCols=@('I');     DateNeedle='Date:'; DateWriteCol='J'; Offset=0;  DataSummaryGuard=$false },
            @{ Name='Data Summary';                 NameLabelCol='A'; NameNeedle='Recorded By:';       NameWriteCol='B'; DateLabelCols=@('C');     DateNeedle='Date:'; DateWriteCol='D'; Offset=0;  DataSummaryGuard=$true  },
            @{ Name='Extra Data Summary';           NameLabelCol='A'; NameNeedle='Recorded By:';       NameWriteCol='B'; DateLabelCols=@('C');     DateNeedle='Date:'; DateWriteCol='D'; Offset=0;  DataSummaryGuard=$true  },
            @{ Name='Resample Data Summary';        NameLabelCol='A'; NameNeedle='Recorded By:';       NameWriteCol='B'; DateLabelCols=@('C');     DateNeedle='Date:'; DateWriteCol='D'; Offset=0;  DataSummaryGuard=$true; ResampleOnly=$true },
            @{ Name='Seal Test Failure Count';      NameLabelCol='K'; NameNeedle='Performed By:';      NameWriteCol='L'; DateLabelCols=@('K');     DateNeedle='Date:'; DateWriteCol='L'; Offset=-1; DataSummaryGuard=$false },
            @{ Name='Statistical Process Control';  NameLabelCol='K'; NameNeedle='Performed By:';      NameWriteCol='L'; DateLabelCols=@('K');     DateNeedle='Date:'; DateWriteCol='L'; Offset=-1; DataSummaryGuard=$false },
            @{ Name='Vacuum Seal Data';             NameLabelCol='B'; NameNeedle='Recorded By:';       NameWriteCol='C'; DateLabelCols=@('D','E'); DateNeedle='Date:'; DateWriteCol='F'; Offset=0;  DataSummaryGuard=$false }
        )
    }
    return @(
        @{ Name='Test Summary'; NameLabelCol='B'; NameNeedle='PQC Reviewed By:'; NameWriteCol='C'; DateLabelCols=@('I'); DateNeedle='Date:'; DateWriteCol='J'; Offset=0; DataSummaryGuard=$false }
    )
}

function Resolve-WorksheetSignatureRows_OpenXml {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)]$WorkbookPart,
        [Parameter(Mandatory=$true)][hashtable]$Target,
        [Parameter(Mandatory=$true)][ValidateSet('Sammanstallning','Granskning')][string]$Mode,
        [bool]$DebugLogEnabled = $false,
        [System.Collections.Generic.List[string]]$DebugEvents = $null
    )

    $sheetName = ($Target.Name + '')
    $nameRow = Find-FirstRowByContains_OpenXml -WorksheetPart $WorksheetPart -WorkbookPart $WorkbookPart -ColLetter $Target.NameLabelCol -Needle $Target.NameNeedle
    $dateRow = $null
    $isReviewTestSummary = (
        $Mode -eq 'Granskning' -and
        $sheetName -eq 'Test Summary' -and
        $Target.NameNeedle -eq 'PQC Reviewed By:'
    )
    if ($isReviewTestSummary -and $nameRow) {
        $startAt = [math]::Max(1, ([int]$nameRow - 1))
        $dateRow = Find-FirstRowByContains_FromRow_OpenXml `
            -WorksheetPart $WorksheetPart `
            -WorkbookPart $WorkbookPart `
            -ColLetter 'I' `
            -Needle $Target.DateNeedle `
            -StartRow $startAt
        Write-OpenXmlSignDebug -Enabled ([bool]$DebugLogEnabled) -Events $DebugEvents -Message ("Sheet '{0}' review date search: startRow={1}, found={2}" -f $sheetName, $startAt, $(if($dateRow){$dateRow}else{'-' }))
    } else {
        foreach ($dc in $Target.DateLabelCols) {
            $dateRow = Find-FirstRowByContains_OpenXml -WorksheetPart $WorksheetPart -WorkbookPart $WorkbookPart -ColLetter $dc -Needle $Target.DateNeedle
            if ($dateRow) { break }
        }
    }

    Write-OpenXmlSignDebug -Enabled ([bool]$DebugLogEnabled) -Events $DebugEvents -Message ("Sheet '{0}': nameRow={1}, dateRow={2}" -f $sheetName, $(if($nameRow){$nameRow}else{'-' }), $(if($dateRow){$dateRow}else{'-' }))

    return [pscustomobject]@{
        NameRow = $nameRow
        DateRow = $dateRow
    }
}

function Get-WorksheetSignaturePlan_OpenXml {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][ValidateSet('Sammanstallning','Granskning')][string]$Mode,
        [bool]$HasResample = $false,
        [Parameter(Mandatory=$true)][string]$ModulesRoot
    )

    Set-StrictMode -Version 2.0
    Import-OpenXmlSdk -ModulesRoot $ModulesRoot | Out-Null

    $plan = [pscustomobject]@{
        Mode    = $Mode
        Planned = New-Object System.Collections.Generic.List[string]
        Skipped = New-Object System.Collections.Generic.List[string]
    }

    $doc = $null
    try {
        $doc = [DocumentFormat.OpenXml.Packaging.SpreadsheetDocument]::Open($Path, $false)
        $wbp = $doc.WorkbookPart
        if (-not $wbp -or -not $wbp.Workbook) { throw 'WorkbookPart saknas.' }
        $sheets = $wbp.Workbook.Sheets
        if (-not $sheets) { throw 'Sheets saknas.' }

        $targets = @(Get-WorksheetSignatureTargets_OpenXml -Mode $Mode)
        foreach ($t in $targets) {
            $sheetName = ($t.Name + '')

            if ($t.ContainsKey('ResampleOnly') -and $t.ResampleOnly -and (-not [bool]$HasResample)) {
                [void]$plan.Skipped.Add("$sheetName (no resampling)")
                continue
            }

            $sheet = @(
                Get-OpenXmlChildrenOfType -Parent $sheets -Type ([DocumentFormat.OpenXml.Spreadsheet.Sheet]) |
                Where-Object { $_.Name -and $_.Name.Value -eq $sheetName }
            )[0]
            if (-not $sheet) {
                [void]$plan.Skipped.Add("$sheetName (Saknas)")
                continue
            }

            $wsp = $wbp.GetPartById($sheet.Id)
            if (-not $wsp) {
                [void]$plan.Skipped.Add("$sheetName (Saknas)")
                continue
            }

            $mergeIndexes = $null
            try { $mergeIndexes = Get-MergeIndexes_OpenXml -WorksheetPart $wsp } catch { $mergeIndexes = $null }
            $forwardMap = if ($mergeIndexes -and $mergeIndexes.ContainsKey('Forward')) { $mergeIndexes.Forward } else { $null }

            if ($t.DataSummaryGuard) {
                $hasData = Test-OpenXmlDataSummaryHasData -WorksheetPart $wsp -WorkbookPart $wbp -DataColLetter 'C' -MergeMap $forwardMap
                if (-not $hasData) {
                    [void]$plan.Skipped.Add("$sheetName (ingen data)")
                    continue
                }
            }

            $rows = Resolve-WorksheetSignatureRows_OpenXml -WorksheetPart $wsp -WorkbookPart $wbp -Target $t -Mode $Mode
            if ($rows.NameRow -or $rows.DateRow) {
                [void]$plan.Planned.Add($sheetName)
            } else {
                [void]$plan.Skipped.Add("$sheetName (labels saknas)")
            }
        }
    } finally {
        try {
            if ($doc) {
                $doc.Close()
                $doc.Dispose()
            }
        } catch {
            try { if ($doc) { $doc.Dispose() } } catch {}
        }
        try {
            if ($fs) {
                $fs.Close()
                $fs.Dispose()
            }
        } catch {}
    }

    return $plan
}

function Invoke-WorksheetSignature_OpenXml {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$FullName,
        [Parameter(Mandatory=$true)][string]$SignDateYmd,
        [Parameter(Mandatory=$true)][ValidateSet('Sammanstallning','Granskning')][string]$Mode,
        [switch]$HasResample,
        [bool]$Overwrite = $false,
        [switch]$DebugLog,
        [Parameter(Mandatory=$true)][string]$ModulesRoot
    )

    Set-StrictMode -Version 2.0

    Import-OpenXmlSdk -ModulesRoot $ModulesRoot | Out-Null

    $res = [pscustomobject]@{
        Mode              = $Mode
        OverwriteRequested= [bool]$Overwrite
        Written           = New-Object System.Collections.Generic.List[string]
        Skipped           = New-Object System.Collections.Generic.List[string]
        WrittenCells      = New-Object System.Collections.Generic.List[pscustomobject]
        DebugEvents       = New-Object System.Collections.Generic.List[string]
    }
    Write-OpenXmlSignDebug -Enabled ([bool]$DebugLog) -Events $res.DebugEvents -Message ("Invoke start: mode={0}, overwrite={1}, file={2}" -f $Mode, [bool]$Overwrite, (Split-Path $Path -Leaf))
    $pendingSheetVerifications = New-Object System.Collections.Generic.List[object]
    $tailFillOnOverwrite = 'N/A'
    $doc = $null
    $fs  = $null
    try {
        # Håll exklusivt filhandtag under hela OpenXML-skrivningen.
        # Detta minskar risken att Excel/Preview/annan process öppnar filen mitt i Save().
        try {
            $fs = [System.IO.File]::Open(
                $Path,
                [System.IO.FileMode]::Open,
                [System.IO.FileAccess]::ReadWrite,
                [System.IO.FileShare]::None
            )
        } catch {
            throw ("Worksheet-filen är öppen/låst eller inte skrivbar: {0}" -f $_.Exception.Message)
        }
        $doc = [DocumentFormat.OpenXml.Packaging.SpreadsheetDocument]::Open($fs, $true)
        $wbp = $doc.WorkbookPart
        if (-not $wbp -or -not $wbp.Workbook) { throw 'WorkbookPart saknas.' }
        $sheets = $wbp.Workbook.Sheets
        if (-not $sheets) { throw 'Sheets saknas.' }

        $targets = @(Get-WorksheetSignatureTargets_OpenXml -Mode $Mode)

        foreach ($t in $targets) {
            $sheetName = $t.Name

            if ($t.ContainsKey('ResampleOnly') -and $t.ResampleOnly -and (-not $HasResample)) {
                [void]$res.Skipped.Add("$sheetName (ej resample)")
                continue
            }

            $sheet = @(
                Get-OpenXmlChildrenOfType -Parent $sheets -Type ([DocumentFormat.OpenXml.Spreadsheet.Sheet]) |
                Where-Object { $_.Name -and $_.Name.Value -eq $sheetName }
            )[0]
            if (-not $sheet) {
                [void]$res.Skipped.Add($sheetName)
                continue
            }
            $wsp = $wbp.GetPartById($sheet.Id)
            if (-not $wsp) {
                [void]$res.Skipped.Add($sheetName)
                continue
            }

            $mergeIndexes = $null
            try { $mergeIndexes = Get-MergeIndexes_OpenXml -WorksheetPart $wsp } catch { $mergeIndexes = $null }
            $forwardMap = if ($mergeIndexes -and $mergeIndexes.ContainsKey('Forward')) { $mergeIndexes.Forward } else { $null }
            $reverseMap = if ($mergeIndexes -and $mergeIndexes.ContainsKey('Reverse')) { $mergeIndexes.Reverse } else { $null }
            $mergeMap = $forwardMap

            if ($t.DataSummaryGuard) {
                $hasData = Test-OpenXmlDataSummaryHasData -WorksheetPart $wsp -WorkbookPart $wbp -DataColLetter 'C' -MergeMap $mergeMap
                if (-not $hasData) {
                    [void]$res.Skipped.Add("$sheetName (ingen data)")
                    continue
                }
            }

            $rows = Resolve-WorksheetSignatureRows_OpenXml `
                -WorksheetPart $wsp `
                -WorkbookPart $wbp `
                -Target $t `
                -Mode $Mode `
                -DebugLogEnabled ([bool]$DebugLog) `
                -DebugEvents $res.DebugEvents
            $nameRow = $rows.NameRow
            $dateRow = $rows.DateRow

            $wroteAny = $false
            $sheetWrittenCells = New-Object System.Collections.Generic.List[pscustomobject]
            if ($nameRow) {
                $nameWriteRow = ($nameRow + $t.Offset)
                $nameWriteCol = $t.NameWriteCol
                $nameWrite = Write-OpenXmlCellText_DeterministicMerge `
                    -WorksheetPart $wsp `
                    -WorkbookPart $wbp `
                    -RowIndex $nameWriteRow `
                    -ColLetter $nameWriteCol `
                    -Value $FullName `
                    -Overwrite ([bool]$Overwrite) `
                    -ForwardMap $forwardMap `
                    -ReverseMap $reverseMap `
                    -TailValue $tailFillOnOverwrite

                Write-OpenXmlSignDebug -Enabled ([bool]$DebugLog) -Events $res.DebugEvents -Message ("Sheet '{0}' Name: target={1}, owner={2}, written={3}, reason={4}" -f $sheetName, $nameWrite.TargetRef, $nameWrite.OwnerRef, $nameWrite.Written, $nameWrite.Reason)

                if ($nameWrite.Written) {
                    [void]$sheetWrittenCells.Add([pscustomobject]@{ Sheet=$sheetName; Row=[int]$nameWrite.OwnerRow; Col=($nameWrite.OwnerCol + ''); Value=$FullName })
                }
                $wroteAny = [bool]$nameWrite.Written -or $wroteAny
            }
            if ($dateRow) {
                $dateWriteRow = ($dateRow + $t.Offset)
                $dateWriteCol = $t.DateWriteCol
                $dateWrite = Write-OpenXmlCellText_DeterministicMerge `
                    -WorksheetPart $wsp `
                    -WorkbookPart $wbp `
                    -RowIndex $dateWriteRow `
                    -ColLetter $dateWriteCol `
                    -Value $SignDateYmd `
                    -Overwrite ([bool]$Overwrite) `
                    -ForwardMap $forwardMap `
                    -ReverseMap $reverseMap `
                    -TailValue $tailFillOnOverwrite

                Write-OpenXmlSignDebug -Enabled ([bool]$DebugLog) -Events $res.DebugEvents -Message ("Sheet '{0}' Date: target={1}, owner={2}, written={3}, reason={4}" -f $sheetName, $dateWrite.TargetRef, $dateWrite.OwnerRef, $dateWrite.Written, $dateWrite.Reason)

                if ($dateWrite.Written) {
                    [void]$sheetWrittenCells.Add([pscustomobject]@{ Sheet=$sheetName; Row=[int]$dateWrite.OwnerRow; Col=($dateWrite.OwnerCol + ''); Value=$SignDateYmd })
                }
                $wroteAny = [bool]$dateWrite.Written -or $wroteAny
            }

            if ($wroteAny) {
                try { $wsp.Worksheet.Save() } catch {
                    throw "Kunde inte spara WorksheetPart '$sheetName': $($_.Exception.Message)"
                }
                if ([bool]$Overwrite) {
                    [void]$pendingSheetVerifications.Add([pscustomobject]@{ Sheet = $sheetName; Cells = @($sheetWrittenCells.ToArray()) })
                } else {
                    [void]$res.Written.Add($sheetName)
                    foreach ($wc in $sheetWrittenCells) { [void]$res.WrittenCells.Add($wc) }
                }
            } else {
                $skipReason = ''
                if (-not $nameRow -and -not $dateRow) {
                    $skipReason = 'labels saknas'
                } else {
                    $skipReason = 'redan ifyllt'
                }
                [void]$res.Skipped.Add("$sheetName ($skipReason)")
            }
        }

        $wbp.Workbook.Save()
    } catch {
        throw
    } finally {
        try { if ($doc) { $doc.Close(); $doc.Dispose() } } catch {
            try { if ($doc) { $doc.Dispose() } } catch {}
        }
    }

    if ([bool]$Overwrite -and $pendingSheetVerifications.Count -gt 0) {
        foreach ($sv in $pendingSheetVerifications) {
            $cells = @($sv.Cells)
            if (-not $cells -or $cells.Count -eq 0) { continue }
            $sheetVerify = Verify-WorksheetSignatures_OpenXml -Path $Path -WrittenCells $cells -ModulesRoot $ModulesRoot
            if ($sheetVerify.OK) {
                [void]$res.Written.Add(($sv.Sheet + ''))
                foreach ($wc in $cells) { [void]$res.WrittenCells.Add($wc) }
                Write-OpenXmlSignDebug -Enabled ([bool]$DebugLog) -Events $res.DebugEvents -Message ("Sheet '{0}' overwrite verify: OK ({1}/{2})" -f $sv.Sheet, $sheetVerify.CellsVerified, $sheetVerify.CellsChecked)
            } else {
                $reason = if ($sheetVerify.Error) { $sheetVerify.Error } else { ($sheetVerify.Mismatches -join '; ') }
                [void]$res.Skipped.Add(("{0} (verify mismatch)" -f $sv.Sheet))
                Write-OpenXmlSignDebug -Enabled ([bool]$DebugLog) -Events $res.DebugEvents -Message ("Sheet '{0}' overwrite verify failed: {1}" -f $sv.Sheet, $reason)
                throw ("OpenXML overwrite verification failed for sheet '{0}': {1}" -f $sv.Sheet, $reason)
            }
        }
    }

    return $res
}

function Verify-WorksheetSignatures_OpenXml {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][object[]]$WrittenCells,
        [Parameter(Mandatory=$true)][string]$ModulesRoot
    )

    $result = [pscustomobject]@{
        OK             = $false
        CellsChecked   = 0
        CellsVerified  = 0
        Mismatches     = New-Object System.Collections.Generic.List[string]
        Error          = $null
    }

    if (-not $WrittenCells -or $WrittenCells.Count -eq 0) {
        $result.OK = $true
        return $result
    }

    Import-OpenXmlSdk -ModulesRoot $ModulesRoot | Out-Null

    $doc = $null
    try {
        $doc = [DocumentFormat.OpenXml.Packaging.SpreadsheetDocument]::Open($Path, $false)  # read-only
        $wbp = $doc.WorkbookPart
        if (-not $wbp -or -not $wbp.Workbook) { throw 'WorkbookPart saknas vid verifiering.' }
        $sheets = $wbp.Workbook.Sheets

        foreach ($wc in $WrittenCells) {
            $result.CellsChecked++
            $sheet = @(
                Get-OpenXmlChildrenOfType -Parent $sheets -Type ([DocumentFormat.OpenXml.Spreadsheet.Sheet]) |
                Where-Object { $_.Name -and $_.Name.Value -eq $wc.Sheet }
            )[0]
            if (-not $sheet) {
                [void]$result.Mismatches.Add("$($wc.Sheet) $($wc.Col)$($wc.Row): Fliken hittades inte vid verifiering")
                continue
            }
            $wsp = $wbp.GetPartById($sheet.Id)
            if (-not $wsp) {
                [void]$result.Mismatches.Add("$($wc.Sheet) $($wc.Col)$($wc.Row): WorksheetPart saknas")
                continue
            }
            $cell = Find-OpenXmlCell -WorksheetPart $wsp -RowIndex $wc.Row -ColLetter $wc.Col
            if ($null -eq $cell) {
                $actual = ''
            } else {
                $actual = Normalize-OpenXmlText (Get-OpenXmlCellText -WorkbookPart $wbp -Cell $cell)
            }
            $actual = ($actual + '').Trim()
            $expected = ($wc.Value + '').Trim()
            if ($actual -eq $expected) {
                $result.CellsVerified++
            } else {
                [void]$result.Mismatches.Add("$($wc.Sheet) $($wc.Col)$($wc.Row): Förväntade='$expected' Faktisk='$actual'")
            }
        }

        $result.OK = ($result.Mismatches.Count -eq 0 -and $result.CellsVerified -eq $WrittenCells.Count)
    } catch {
        $result.Error = $_.Exception.Message
    } finally {
        try { if ($doc) { $doc.Dispose() } } catch {}
    }
    return $result
}
