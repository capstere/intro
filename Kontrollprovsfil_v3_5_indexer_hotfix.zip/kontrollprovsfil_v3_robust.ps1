#requires -Version 5.1
<#
.SYNOPSIS
    Robust inventory management for Kontrollprovsfil.

.DESCRIPTION
    Version 3 replaces the previous save-then-log flow with a write-ahead
    audit transaction. Every update is protected by a cross-process lock,
    schema validation, optimistic concurrency control, a verified backup,
    an atomic file replacement and a local recovery journal.

    Important operational controls outside this script are still required:
    - NTFS/share permissions must restrict raw_data.xlsx and this script.
    - EPPlus.dll must come from an approved, controlled location.
    - The audit CSV and backup directory must be access controlled.
#>

[CmdletBinding()]
param(
    [string]$RawDataPath = 'N:\QC\QC-1\IPT\8. IPT - WR + Rework\1. PQC - Kontrollprovsfil - RÖR EJ -\Script Raw Data\raw_data.xlsx',
    [string]$OutputDir = 'N:\QC\QC-1\IPT\8. IPT - WR + Rework\1. PQC - Kontrollprovsfil - RÖR EJ -\Inventeringsrapport',
    [string]$AuditLogPath = '',
    [string]$BackupDir = '',
    [string]$EPPlusDllPath = 'N:\QC\QC-1\IPT\Skiftspecifika dokument\PQC analyst\JESPER\Scripts\Modules\EPPlus\EPPlus.4.5.3.3\lib\net35\EPPlus.dll',
    [string]$EPPlusSha256 = '',
    [string]$InventoryWorksheetName = 'raw_data',
    [bool]$OpenGeneratedReports = $true,
    [int]$ExpiringPastDays = 15,
    [int]$ExpiringFutureDays = 30,
    [string[]]$AuthorizedUsers = @(
        'vivian.dao',
        'elin.sidstedt',
        'jesper.fredriksson',
        'afnan.vijitraphongs'
    ),
    [hashtable]$SignatureMap = @{
        'jesper.fredriksson'  = 'JESP'
        'elin.sidstedt'       = 'ELS'
        'vivian.dao'          = 'VDAO'
        'afnan.vijitraphongs' = 'AFVI'
    }
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

$script:AppName = 'Kontrollprovsfil'
$script:AppVersion = 'v3.5 2026-06-29'
$script:InventoryLockPath = "$RawDataPath.kontroll.lock"

$script:Columns = [ordered]@{
    PN              = 1
    Lot             = 2
    Exp             = 3
    Qty             = 4
    LastUpdate      = 5
    Signature       = 6
    ProductStartCol = 7
    ProductEndCol   = 13
    Description     = 14
    Location        = 15
    LabCode         = 16
}

$script:ExpectedHeaders = [ordered]@{
    1  = 'P/N'
    2  = 'Lotnr.'
    3  = 'Utgångsdatum'
    4  = 'Antal i lager'
    5  = 'Senast inventering'
    6  = 'SIGN'
    7  = 'Produkt'
    8  = 'Produkt'
    9  = 'Produkt'
    10 = 'Produkt'
    11 = 'Produkt'
    12 = 'Produkt'
    13 = 'Produkt'
    14 = 'Beskrivning'
    15 = 'Förvaringsplats'
    16 = 'Labb'
}

$script:AuditColumns = @(
    'Timestamp', 'TransactionId', 'Status', 'User', 'DomainUser', 'Signature',
    'Action', 'PN', 'Row', 'OldLot', 'OldExp', 'OldQty', 'NewLot', 'NewExp',
    'NewQty', 'Machine', 'RawDataHashBefore', 'RawDataHashAfter', 'Message'
)
$script:AuditHeader = $script:AuditColumns -join ';'
$script:TerminalAuditStatuses = @('COMMITTED', 'ABORTED', 'ROLLED_BACK', 'RECOVERED_COMMIT', 'REVIEW_REQUIRED')

if ([string]::IsNullOrWhiteSpace($AuditLogPath)) {
    $AuditLogPath = Join-Path (Split-Path -Parent $RawDataPath) 'UpdateLog_Kontrollprovsfil_v3.csv'
}
if ([string]::IsNullOrWhiteSpace($BackupDir)) {
    $BackupDir = Join-Path (Split-Path -Parent $RawDataPath) 'Backups'
}

# Make optional relative paths deterministic when the script is launched by a shortcut.
if (-not [System.IO.Path]::IsPathRooted($AuditLogPath)) { $AuditLogPath = Join-Path $PSScriptRoot $AuditLogPath }
if (-not [System.IO.Path]::IsPathRooted($BackupDir)) { $BackupDir = Join-Path $PSScriptRoot $BackupDir }
if (-not [System.IO.Path]::IsPathRooted($OutputDir)) { $OutputDir = Join-Path $PSScriptRoot $OutputDir }
if (-not [System.IO.Path]::IsPathRooted($EPPlusDllPath)) { $EPPlusDllPath = Join-Path $PSScriptRoot $EPPlusDllPath }

$script:AuditLogPath = $AuditLogPath
$script:BackupDir = $BackupDir

function Get-LocalStateDirectory {
    $base = $env:LOCALAPPDATA
    if ([string]::IsNullOrWhiteSpace($base)) {
        $base = [System.IO.Path]::GetTempPath()
    }
    return (Join-Path $base 'Cepheid\Kontrollprovsfil')
}

$script:JournalDir = Join-Path (Get-LocalStateDirectory) 'Transactions\Pending'
$script:CompletedJournalDir = Join-Path (Get-LocalStateDirectory) 'Transactions\Completed'
$script:ReviewJournalDir = Join-Path (Get-LocalStateDirectory) 'Transactions\ReviewRequired'

function Ensure-Directory {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        New-Item -ItemType Directory -Path $Path -Force -ErrorAction Stop | Out-Null
    }
}

function Get-NormalizedText {
    param([AllowNull()][object]$Value)

    if ($null -eq $Value) { return '' }
    return (([string]$Value) -replace [char]0x00A0, ' ').Trim()
}

function Test-IsNAValue {
    param([AllowNull()][object]$Value)

    $text = (Get-NormalizedText -Value $Value).ToUpperInvariant()
    return ([string]::IsNullOrWhiteSpace($text) -or $text -in @('N/A', 'NA', 'N.A.', '-'))
}



function Get-ExcelColumnName {
    param([Parameter(Mandatory = $true)][int]$ColumnNumber)

    if ($ColumnNumber -lt 1) { throw "Ogiltigt kolumnnummer: $ColumnNumber" }

    $name = ''
    while ($ColumnNumber -gt 0) {
        $ColumnNumber--
        $name = ([char](65 + ($ColumnNumber % 26))) + $name
        $ColumnNumber = [math]::Floor($ColumnNumber / 26)
    }
    return $name
}

function Get-ExcelCell {
    param(
        [Parameter(Mandatory = $true)]$Sheet,
        [Parameter(Mandatory = $true)][int]$Row,
        [Parameter(Mandatory = $true)][int]$Column
    )

    # Avoid EPPlus two-argument indexer from PowerShell 5.1.
    # In some EPPlus/PowerShell combinations, Cells[$row, $column] can throw
    # "Argument types do not match". A single A1-style address is more stable.
    $address = ('{0}{1}' -f (Get-ExcelColumnName -ColumnNumber $Column), $Row)
    return $Sheet.Cells[$address]
}

function Get-ExcelRangeByAddress {
    param(
        [Parameter(Mandatory = $true)]$Sheet,
        [Parameter(Mandatory = $true)][string]$Address
    )

    return $Sheet.Cells[$Address]
}

function Get-DomainUser {
    $user = [Environment]::UserName
    $domain = $env:USERDOMAIN
    if ([string]::IsNullOrWhiteSpace($domain)) { return $user }
    return ('{0}\{1}' -f $domain, $user)
}

function Get-SafeFileNamePart {
    param([AllowNull()][string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) { return 'unknown' }
    return ($Text -replace '[^a-zA-Z0-9_.-]', '_')
}

function Get-FileSha256 {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Filen saknas: $Path"
    }
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
}

function Invoke-WithRetry {
    param(
        [Parameter(Mandatory = $true)][scriptblock]$Action,
        [int]$MaxAttempts = 5,
        [int]$InitialDelayMilliseconds = 250
    )

    $lastError = $null
    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        try {
            return (& $Action)
        }
        catch {
            $lastError = $_
            if ($attempt -eq $MaxAttempts) { throw }
            $delay = [int]($InitialDelayMilliseconds * [Math]::Pow(1.7, ($attempt - 1)))
            $delay += Get-Random -Minimum 0 -Maximum 150
            Start-Sleep -Milliseconds $delay
        }
    }
    throw $lastError
}

function Enter-FileLock {
    param(
        [Parameter(Mandatory = $true)][string]$LockPath,
        [Parameter(Mandatory = $true)][string]$Purpose,
        [int]$TimeoutSeconds = 120,
        [int]$RetryMilliseconds = 250
    )

    $parent = Split-Path -Parent $LockPath
    if (-not [string]::IsNullOrWhiteSpace($parent)) { Ensure-Directory -Path $parent }

    $timer = [System.Diagnostics.Stopwatch]::StartNew()
    $lastError = ''
    while ($timer.Elapsed.TotalSeconds -lt $TimeoutSeconds) {
        try {
            $stream = [System.IO.File]::Open(
                $LockPath,
                [System.IO.FileMode]::OpenOrCreate,
                [System.IO.FileAccess]::ReadWrite,
                [System.IO.FileShare]::None
            )
            $metadata = 'LockedBy={0};PID={1};Timestamp={2};Purpose={3}' -f `
                (Get-DomainUser), $PID, ([DateTimeOffset]::Now.ToString('o')), $Purpose
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($metadata)
            $stream.SetLength(0)
            $stream.Write($bytes, 0, $bytes.Length)
            $stream.Flush()
            return $stream
        }
        catch {
            $lastError = $_.Exception.Message
            Start-Sleep -Milliseconds $RetryMilliseconds
        }
    }

    throw "Kunde inte få exklusivt lås för '$Purpose' inom $TimeoutSeconds sekunder. $lastError"
}

function Exit-FileLock {
    param(
        [AllowNull()]$LockHandle,
        [Parameter(Mandatory = $true)][string]$LockPath
    )

    try { if ($null -ne $LockHandle) { $LockHandle.Dispose() } } catch {}
    try { Remove-Item -LiteralPath $LockPath -Force -ErrorAction SilentlyContinue } catch {}
}

function Write-Utf8Line {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Line,
        [bool]$Append = $true,
        [bool]$WriteBom = $false
    )

    $parent = Split-Path -Parent $Path
    if (-not [string]::IsNullOrWhiteSpace($parent)) { Ensure-Directory -Path $parent }

    $encoding = New-Object System.Text.UTF8Encoding($WriteBom)
    $writer = New-Object System.IO.StreamWriter($Path, $Append, $encoding)
    try {
        $writer.WriteLine($Line)
        $writer.Flush()
        $writer.BaseStream.Flush()
    }
    finally {
        $writer.Dispose()
    }
}

function ConvertTo-CsvCell {
    param([AllowNull()][object]$Value)

    $text = Get-NormalizedText -Value $Value
    $text = $text -replace '(\r\n|\n|\r|\t)', ' '
    return ('"{0}"' -f $text.Replace('"', '""'))
}

function Initialize-AuditLog {
    param([Parameter(Mandatory = $true)][string]$Path)

    $lockPath = "$Path.lock"
    $lock = $null
    try {
        $lock = Enter-FileLock -LockPath $lockPath -Purpose 'initiera audit-logg' -TimeoutSeconds 60
        $parent = Split-Path -Parent $Path
        if (-not [string]::IsNullOrWhiteSpace($parent)) { Ensure-Directory -Path $parent }

        if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
            Write-Utf8Line -Path $Path -Line $script:AuditHeader -Append:$false -WriteBom:$true
            return
        }

        $reader = [System.IO.File]::OpenText($Path)
        try { $firstLine = $reader.ReadLine() }
        finally { $reader.Dispose() }

        if ($null -eq $firstLine) { throw 'Audit-loggen är tom.' }
        $firstLine = $firstLine.TrimStart([char]0xFEFF)
        if ($firstLine -ne $script:AuditHeader) {
            throw "Audit-loggens header matchar inte v3-schemat. Befintlig fil lämnas orörd: $Path"
        }

        # Parse the file with the CSV parser instead of counting semicolons.
        $rows = @(Import-Csv -LiteralPath $Path -Delimiter ';' -Encoding UTF8 -ErrorAction Stop)
        foreach ($row in $rows) {
            foreach ($column in $script:AuditColumns) {
                if ($row.PSObject.Properties.Name -notcontains $column) {
                    throw "Audit-loggen saknar kolumnen '$column'."
                }
            }
            if ([string]::IsNullOrWhiteSpace($row.TransactionId) -or [string]::IsNullOrWhiteSpace($row.Status)) {
                throw 'Audit-loggen innehåller en rad utan TransactionId eller Status.'
            }
        }
    }
    finally {
        if ($null -ne $lock) { Exit-FileLock -LockHandle $lock -LockPath $lockPath }
    }
}

function New-AuditRecord {
    param(
        [Parameter(Mandatory = $true)][string]$TransactionId,
        [Parameter(Mandatory = $true)][string]$Status,
        [Parameter(Mandatory = $true)][string]$Signature,
        [Parameter(Mandatory = $true)][string]$Action,
        [Parameter(Mandatory = $true)][string]$PN,
        [Parameter(Mandatory = $true)][int]$Row,
        [AllowNull()]$Old,
        [AllowNull()]$New,
        [string]$RawDataHashBefore = '',
        [string]$RawDataHashAfter = '',
        [string]$Message = ''
    )

    return [pscustomobject][ordered]@{
        Timestamp         = [DateTimeOffset]::Now.ToString('o')
        TransactionId     = $TransactionId
        Status            = $Status
        User              = [Environment]::UserName
        DomainUser        = Get-DomainUser
        Signature         = $Signature
        Action            = $Action
        PN                = $PN
        Row               = [string]$Row
        OldLot            = if ($null -eq $Old) { '' } else { $Old.Lot }
        OldExp            = if ($null -eq $Old) { '' } else { $Old.Exp }
        OldQty            = if ($null -eq $Old) { '' } else { $Old.Qty }
        NewLot            = if ($null -eq $New) { '' } else { $New.Lot }
        NewExp            = if ($null -eq $New) { '' } else { $New.Exp }
        NewQty            = if ($null -eq $New) { '' } else { $New.Qty }
        Machine           = $env:COMPUTERNAME
        RawDataHashBefore = $RawDataHashBefore
        RawDataHashAfter  = $RawDataHashAfter
        Message           = $Message
    }
}

function Write-AuditRecord {
    param(
        [Parameter(Mandatory = $true)]$Record,
        [Parameter(Mandatory = $true)][string]$Path
    )

    $values = foreach ($column in $script:AuditColumns) {
        ConvertTo-CsvCell -Value $Record.$column
    }
    $line = $values -join ';'

    Invoke-WithRetry -MaxAttempts 6 -InitialDelayMilliseconds 300 -Action {
        $lockPath = "$Path.lock"
        $lock = $null
        try {
            $lock = Enter-FileLock -LockPath $lockPath -Purpose 'skriva audit-logg' -TimeoutSeconds 60
            if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
                throw "Audit-loggen saknas vid skrivning. Ingen ny loggfil skapas automatiskt här: $Path"
            }

            $reader = [System.IO.File]::OpenText($Path)
            try { $header = $reader.ReadLine() }
            finally { $reader.Dispose() }
            if ($null -eq $header -or $header.TrimStart([char]0xFEFF) -ne $script:AuditHeader) {
                throw 'Audit-loggens header är fel. Ingen rad skrevs.'
            }

            Write-Utf8Line -Path $Path -Line $line -Append:$true -WriteBom:$false
        }
        finally {
            if ($null -ne $lock) { Exit-FileLock -LockHandle $lock -LockPath $lockPath }
        }
    } | Out-Null
}

function Test-AuditHasTerminalStatus {
    param(
        [Parameter(Mandatory = $true)][string]$TransactionId,
        [Parameter(Mandatory = $true)][string]$Path
    )

    $rows = @(Import-Csv -LiteralPath $Path -Delimiter ';' -Encoding UTF8 -ErrorAction Stop)
    foreach ($row in $rows) {
        if ($row.TransactionId -eq $TransactionId -and $script:TerminalAuditStatuses -contains $row.Status) {
            return $true
        }
    }
    return $false
}

function Get-JournalPath {
    param([Parameter(Mandatory = $true)][string]$TransactionId)

    Ensure-Directory -Path $script:JournalDir
    return (Join-Path $script:JournalDir ("{0}.json" -f $TransactionId))
}

function Write-TransactionJournal {
    param([Parameter(Mandatory = $true)]$Journal)

    Ensure-Directory -Path $script:JournalDir
    $Journal.UpdatedAt = [DateTimeOffset]::Now.ToString('o')
    $path = Get-JournalPath -TransactionId $Journal.TransactionId
    $temp = "$path.tmp.$PID"
    $json = $Journal | ConvertTo-Json -Depth 10
    [System.IO.File]::WriteAllText($temp, $json, (New-Object System.Text.UTF8Encoding($false)))
    Move-Item -LiteralPath $temp -Destination $path -Force -ErrorAction Stop
    return $path
}

function Complete-TransactionJournal {
    param(
        [Parameter(Mandatory = $true)][string]$TransactionId,
        [ValidateSet('Completed', 'ReviewRequired')][string]$Destination = 'Completed'
    )

    $source = Get-JournalPath -TransactionId $TransactionId
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { return }

    $targetDir = if ($Destination -eq 'Completed') { $script:CompletedJournalDir } else { $script:ReviewJournalDir }
    Ensure-Directory -Path $targetDir
    $target = Join-Path $targetDir ([System.IO.Path]::GetFileName($source))
    Move-Item -LiteralPath $source -Destination $target -Force -ErrorAction Stop
}

function Resolve-EPPlusDll {
    $candidates = New-Object 'System.Collections.Generic.List[string]'
    if (-not [string]::IsNullOrWhiteSpace($EPPlusDllPath)) { $candidates.Add($EPPlusDllPath) }
    $candidates.Add((Join-Path $PSScriptRoot 'EPPlus.dll'))

    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { return $candidate }
    }
    throw 'EPPlus.dll hittades inte. Lägg en godkänd EPPlus.dll bredvid scriptet eller ange -EPPlusDllPath.'
}

function Import-EPPlus {
    $loaded = [System.AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GetName().Name -eq 'EPPlus' } | Select-Object -First 1
    if ($null -ne $loaded) { return }

    $dll = Resolve-EPPlusDll
    if (-not [string]::IsNullOrWhiteSpace($EPPlusSha256)) {
        $actualHash = Get-FileSha256 -Path $dll
        if ($actualHash -ne $EPPlusSha256.ToUpperInvariant()) {
            throw "EPPlus.dll har fel SHA-256. Förväntad: $EPPlusSha256. Faktisk: $actualHash"
        }
    }

    $bytes = [System.IO.File]::ReadAllBytes($dll)
    $assembly = [System.Reflection.Assembly]::Load($bytes)
    if ($assembly.GetName().Name -ne 'EPPlus') {
        throw "DLL-filen är inte EPPlus: $dll"
    }
}

function Open-ExcelPackage {
    param([Parameter(Mandatory = $true)][string]$Path)

    return (Invoke-WithRetry -MaxAttempts 5 -InitialDelayMilliseconds 500 -Action {
        $file = New-Object System.IO.FileInfo($Path)
        New-Object OfficeOpenXml.ExcelPackage($file)
    })
}

function Get-InventoryWorksheet {
    param([Parameter(Mandatory = $true)]$Package)

    $sheet = $Package.Workbook.Worksheets[$InventoryWorksheetName]
    if ($null -eq $sheet) {
        throw "Arbetsbladet '$InventoryWorksheetName' saknas."
    }
    if ($null -eq $sheet.Dimension) {
        throw "Arbetsbladet '$InventoryWorksheetName' saknar data."
    }
    return $sheet
}

function Assert-InventorySchema {
    param([Parameter(Mandatory = $true)]$Sheet)

    foreach ($entry in $script:ExpectedHeaders.GetEnumerator()) {
        $actual = Get-NormalizedText -Value (Get-ExcelCell -Sheet $Sheet -Row 1 -Column ([int]$entry.Key)).Value
        if ($actual -ne [string]$entry.Value) {
            throw "Fel kolumnschema i '$InventoryWorksheetName'. Kolumn $($entry.Key) ska vara '$($entry.Value)' men är '$actual'."
        }
    }
}

function Get-InventoryCellText {
    param(
        [Parameter(Mandatory = $true)]$Sheet,
        [Parameter(Mandatory = $true)][int]$Row,
        [Parameter(Mandatory = $true)][int]$Column
    )

    # Do not use EPPlus .Text here. In some Windows/EPPlus combinations,
    # .Text can throw "Argument types do not match" for real Excel date cells.
    # Read .Value and normalize/format dates ourselves instead.
    $cell = Get-ExcelCell -Sheet $Sheet -Row $Row -Column $Column
    $value = $cell.Value

    if ($null -eq $value) { return '' }

    $text = Get-NormalizedText -Value $value

    if ($Column -eq $script:Columns.Exp -or $Column -eq $script:Columns.LastUpdate) {
        if (Test-IsNAValue -Value $text) { return $text }

        if ($value -is [datetime]) {
            return $value.ToString('yyyy-MM-dd', [System.Globalization.CultureInfo]::InvariantCulture)
        }

        if ($value -is [byte] -or $value -is [int16] -or $value -is [int32] -or $value -is [int64] -or
            $value -is [single] -or $value -is [double] -or $value -is [decimal]) {
            try {
                $serial = [double]$value
                # Excel serials for normal inventory dates should be safely inside this range.
                if ($serial -gt 30000 -and $serial -lt 80000) {
                    return ([datetime]::FromOADate($serial)).ToString('yyyy-MM-dd', [System.Globalization.CultureInfo]::InvariantCulture)
                }
            }
            catch {
                # Fall through and return normalized text.
            }
        }

        $parsed = [datetime]::MinValue
        if ([datetime]::TryParse($text, [System.Globalization.CultureInfo]::InvariantCulture, [System.Globalization.DateTimeStyles]::None, [ref]$parsed)) {
            return $parsed.ToString('yyyy-MM-dd', [System.Globalization.CultureInfo]::InvariantCulture)
        }
        if ([datetime]::TryParse($text, [System.Globalization.CultureInfo]::CurrentCulture, [System.Globalization.DateTimeStyles]::None, [ref]$parsed)) {
            return $parsed.ToString('yyyy-MM-dd', [System.Globalization.CultureInfo]::InvariantCulture)
        }
    }

    return $text
}

function Get-InventoryRowSnapshot {
    param(
        [Parameter(Mandatory = $true)]$Sheet,
        [Parameter(Mandatory = $true)][int]$RowNumber
    )

    return [pscustomobject][ordered]@{
        Row         = $RowNumber
        PN          = Get-InventoryCellText -Sheet $Sheet -Row $RowNumber -Column $script:Columns.PN
        Lot         = Get-InventoryCellText -Sheet $Sheet -Row $RowNumber -Column $script:Columns.Lot
        Exp         = Get-InventoryCellText -Sheet $Sheet -Row $RowNumber -Column $script:Columns.Exp
        Qty         = Get-InventoryCellText -Sheet $Sheet -Row $RowNumber -Column $script:Columns.Qty
        LastUpdate  = Get-InventoryCellText -Sheet $Sheet -Row $RowNumber -Column $script:Columns.LastUpdate
        Signature   = Get-InventoryCellText -Sheet $Sheet -Row $RowNumber -Column $script:Columns.Signature
        Description = Get-InventoryCellText -Sheet $Sheet -Row $RowNumber -Column $script:Columns.Description
        Location    = Get-InventoryCellText -Sheet $Sheet -Row $RowNumber -Column $script:Columns.Location
        LabCode     = Get-InventoryCellText -Sheet $Sheet -Row $RowNumber -Column $script:Columns.LabCode
    }
}

function Test-InventoryRowMatches {
    param(
        [Parameter(Mandatory = $true)]$Expected,
        [Parameter(Mandatory = $true)]$Actual
    )

    return (
        $Expected.PN -eq $Actual.PN -and
        $Expected.Lot -eq $Actual.Lot -and
        $Expected.Exp -eq $Actual.Exp -and
        $Expected.Qty -eq $Actual.Qty
    )
}

function Test-InventoryRowIsActive {
    param(
        [Parameter(Mandatory = $true)]$Sheet,
        [Parameter(Mandatory = $true)][int]$Row
    )

    return (
        -not (Test-IsNAValue (Get-InventoryCellText -Sheet $Sheet -Row $Row -Column $script:Columns.PN)) -and
        -not (Test-IsNAValue (Get-InventoryCellText -Sheet $Sheet -Row $Row -Column $script:Columns.Lot)) -and
        -not (Test-IsNAValue (Get-InventoryCellText -Sheet $Sheet -Row $Row -Column $script:Columns.Exp)) -and
        -not (Test-IsNAValue (Get-InventoryCellText -Sheet $Sheet -Row $Row -Column $script:Columns.Qty))
    )
}

function Try-ParseInventoryDate {
    param([AllowNull()][string]$Text)

    $value = Get-NormalizedText -Value $Text
    if (Test-IsNAValue -Value $value) { return $null }

    $parsed = [datetime]::MinValue
    if ([datetime]::TryParseExact(
        $value,
        'yyyy-MM-dd',
        [System.Globalization.CultureInfo]::InvariantCulture,
        [System.Globalization.DateTimeStyles]::None,
        [ref]$parsed
    )) {
        return $parsed.Date
    }

    if ($value -match '^\d{4}-\d{2}$') {
        if ([datetime]::TryParseExact(
            ($value + '-01'),
            'yyyy-MM-dd',
            [System.Globalization.CultureInfo]::InvariantCulture,
            [System.Globalization.DateTimeStyles]::None,
            [ref]$parsed
        )) {
            return $parsed.AddMonths(1).AddDays(-1).Date
        }
    }
    return $null
}

function Assert-AuthorizedUser {
    $user = [Environment]::UserName
    $domainUser = Get-DomainUser
    $isAllowed = $false

    foreach ($allowed in $AuthorizedUsers) {
        if ($allowed -eq $user -or $allowed -eq $domainUser) {
            $isAllowed = $true
            break
        }
    }
    if (-not $isAllowed) {
        throw "Windows-användaren '$domainUser' är inte behörig att uppdatera inventeringen."
    }
    if (-not $SignatureMap.ContainsKey($user) -and -not $SignatureMap.ContainsKey($domainUser)) {
        throw "Ingen kontrollerad signatur är konfigurerad för '$domainUser'."
    }
}

function Get-CurrentUserSignature {
    Assert-AuthorizedUser
    $user = [Environment]::UserName
    $domainUser = Get-DomainUser
    $signature = if ($SignatureMap.ContainsKey($domainUser)) { $SignatureMap[$domainUser] } else { $SignatureMap[$user] }
    $signature = (Get-NormalizedText -Value $signature).ToUpperInvariant()
    if ($signature -notmatch '^[A-Z0-9]{2,8}$') {
        throw "Konfigurerad signatur '$signature' har ogiltigt format."
    }
    return $signature
}

function Get-InventoryAction {
    param(
        [Parameter(Mandatory = $true)]$Old,
        [Parameter(Mandatory = $true)]$New
    )

    $checkOnly = $false
    if ($New.PSObject.Properties.Name -contains 'CheckOnly') {
        $checkOnly = [bool]$New.CheckOnly
    }
    if ($checkOnly) { return 'CHECK' }

    $oldEmpty = (Test-IsNAValue $Old.Lot) -and (Test-IsNAValue $Old.Exp) -and (Test-IsNAValue $Old.Qty)
    $newEmpty = (Test-IsNAValue $New.Lot) -and (Test-IsNAValue $New.Exp) -and (Test-IsNAValue $New.Qty)

    if ($newEmpty) { return 'REMOVE' }
    if ($oldEmpty -and -not $newEmpty) { return 'ADD' }
    if ($Old.Lot -eq $New.Lot -and $Old.Exp -eq $New.Exp -and $Old.Qty -ne $New.Qty) { return 'QTY' }
    return 'OVERWRITE'
}

function New-VerifiedBackup {
    param(
        [Parameter(Mandatory = $true)][string]$SourcePath,
        [Parameter(Mandatory = $true)][string]$TransactionId,
        [Parameter(Mandatory = $true)][string]$ExpectedHash
    )

    Ensure-Directory -Path $script:BackupDir
    $baseName = [System.IO.Path]::GetFileNameWithoutExtension($SourcePath)
    $extension = [System.IO.Path]::GetExtension($SourcePath)
    $timestamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
    $backupPath = Join-Path $script:BackupDir ("{0}_{1}_{2}{3}" -f $baseName, $timestamp, $TransactionId, $extension)

    Copy-Item -LiteralPath $SourcePath -Destination $backupPath -Force -ErrorAction Stop
    $backupHash = Get-FileSha256 -Path $backupPath
    if ($backupHash -ne $ExpectedHash) {
        Remove-Item -LiteralPath $backupPath -Force -ErrorAction SilentlyContinue
        throw 'Backupens SHA-256 matchar inte originalfilen.'
    }
    return $backupPath
}

function Set-WorkbookRecalculationOnOpen {
    param([Parameter(Mandatory = $true)]$Package)

    # EPPlus does not calculate all Excel formulas. These flags ask Excel to
    # recalculate when the workbook is next opened, without launching Excel COM.
    try { $Package.Workbook.CalcMode = [OfficeOpenXml.ExcelCalcMode]::Automatic } catch {}
    try { $Package.Workbook.FullCalcOnLoad = $true } catch {}
    try { $Package.Workbook.ForceFullCalculation = $true } catch {}
}

function Apply-InventoryChange {
    param(
        [Parameter(Mandatory = $true)]$Sheet,
        [Parameter(Mandatory = $true)][int]$RowNumber,
        [Parameter(Mandatory = $true)]$Desired,
        [Parameter(Mandatory = $true)][string]$Signature,
        [Parameter(Mandatory = $true)][string]$InventoryDate
    )

    # CHECK/"Mark as checked" sends the existing Lot/Exp/Qty back as Desired.
    # Therefore this function can use one single write path for all actions:
    # ADD/OVERWRITE/QTY/REMOVE change stock fields, CHECK leaves them unchanged
    # and only refreshes Senast inventering + SIGN.
    (Get-ExcelCell -Sheet $Sheet -Row $RowNumber -Column $script:Columns.Lot).Value = $Desired.Lot
    (Get-ExcelCell -Sheet $Sheet -Row $RowNumber -Column $script:Columns.Exp).Value = $Desired.Exp
    (Get-ExcelCell -Sheet $Sheet -Row $RowNumber -Column $script:Columns.Qty).Value = $Desired.Qty
    (Get-ExcelCell -Sheet $Sheet -Row $RowNumber -Column $script:Columns.LastUpdate).Value = $InventoryDate
    (Get-ExcelCell -Sheet $Sheet -Row $RowNumber -Column $script:Columns.Signature).Value = $Signature
}

function Save-UpdatedWorkbookToTemporaryFile {
    param(
        [Parameter(Mandatory = $true)][string]$SourcePath,
        [Parameter(Mandatory = $true)][int]$RowNumber,
        [Parameter(Mandatory = $true)]$Desired,
        [Parameter(Mandatory = $true)][string]$Signature,
        [Parameter(Mandatory = $true)][string]$TransactionId
    )

    $directory = Split-Path -Parent $SourcePath
    $baseName = [System.IO.Path]::GetFileNameWithoutExtension($SourcePath)
    $extension = [System.IO.Path]::GetExtension($SourcePath)
    $tempPath = Join-Path $directory (".{0}.{1}.tmp{2}" -f $baseName, $TransactionId, $extension)
    if (Test-Path -LiteralPath $tempPath) { Remove-Item -LiteralPath $tempPath -Force }

    $inventoryDate = (Get-Date).ToString('yyyy-MM-dd')

    $package = $null
    try {
        $package = Open-ExcelPackage -Path $SourcePath
        $sheet = Get-InventoryWorksheet -Package $package
        Assert-InventorySchema -Sheet $sheet
        Apply-InventoryChange -Sheet $sheet -RowNumber $RowNumber -Desired $Desired -Signature $Signature -InventoryDate $inventoryDate
        Set-WorkbookRecalculationOnOpen -Package $package
        $package.SaveAs((New-Object System.IO.FileInfo($tempPath)))
    }
    finally {
        if ($null -ne $package) { $package.Dispose() }
    }

    $verificationPackage = $null
    try {
        $verificationPackage = Open-ExcelPackage -Path $tempPath
        $verificationSheet = Get-InventoryWorksheet -Package $verificationPackage
        Assert-InventorySchema -Sheet $verificationSheet
        $actual = Get-InventoryRowSnapshot -Sheet $verificationSheet -RowNumber $RowNumber
        if (
            $actual.Lot -ne $Desired.Lot -or
            $actual.Exp -ne $Desired.Exp -or
            $actual.Qty -ne $Desired.Qty -or
            $actual.LastUpdate -ne $inventoryDate -or
            $actual.Signature -ne $Signature
        ) {
            throw 'Verifiering av den temporära arbetsboken misslyckades.'
        }
    }
    finally {
        if ($null -ne $verificationPackage) { $verificationPackage.Dispose() }
    }

    return [pscustomobject]@{
        Path = $tempPath
        Hash = Get-FileSha256 -Path $tempPath
    }
}

function Install-FileAtomically {
    param(
        [Parameter(Mandatory = $true)][string]$SourcePath,
        [Parameter(Mandatory = $true)][string]$DestinationPath,
        [Parameter(Mandatory = $true)][string]$TransactionId
    )

    $directory = Split-Path -Parent $DestinationPath
    $baseName = [System.IO.Path]::GetFileNameWithoutExtension($DestinationPath)
    $extension = [System.IO.Path]::GetExtension($DestinationPath)
    $swapBackup = Join-Path $directory (".{0}.{1}.swap-backup{2}" -f $baseName, $TransactionId, $extension)
    if (Test-Path -LiteralPath $swapBackup) { Remove-Item -LiteralPath $swapBackup -Force }

    [System.IO.File]::Replace($SourcePath, $DestinationPath, $swapBackup, $true)
    return $swapBackup
}

function Restore-BackupAtomically {
    param(
        [Parameter(Mandatory = $true)][string]$BackupPath,
        [Parameter(Mandatory = $true)][string]$DestinationPath,
        [Parameter(Mandatory = $true)][string]$TransactionId
    )

    $directory = Split-Path -Parent $DestinationPath
    $baseName = [System.IO.Path]::GetFileNameWithoutExtension($DestinationPath)
    $extension = [System.IO.Path]::GetExtension($DestinationPath)
    $restoreTemp = Join-Path $directory (".{0}.{1}.restore.tmp{2}" -f $baseName, $TransactionId, $extension)
    $failedCopy = Join-Path $directory (".{0}.{1}.failed-copy{2}" -f $baseName, $TransactionId, $extension)

    Copy-Item -LiteralPath $BackupPath -Destination $restoreTemp -Force -ErrorAction Stop
    [System.IO.File]::Replace($restoreTemp, $DestinationPath, $failedCopy, $true)
    if (Test-Path -LiteralPath $failedCopy) {
        Remove-Item -LiteralPath $failedCopy -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-InventoryUpdateTransaction {
    param(
        [Parameter(Mandatory = $true)]$ExpectedOld,
        [Parameter(Mandatory = $true)]$Desired,
        [Parameter(Mandatory = $true)][string]$Signature
    )

    $result = [pscustomobject][ordered]@{
        Success = $false
        Conflict = $false
        TransactionId = ''
        Action = ''
        Message = ''
        Old = $null
        New = $null
        BackupPath = ''
        AuditFinalized = $false
    }

    $lock = $null
    $package = $null
    $transactionId = [guid]::NewGuid().ToString('N')
    $result.TransactionId = $transactionId
    $pendingWritten = $false
    $replacementDone = $false
    $backupPath = ''
    $tempPath = ''
    $swapBackupPath = ''
    $hashBefore = ''
    $hashAfter = ''
    $journal = $null
    $commitWritten = $false

    try {
        Assert-AuthorizedUser
        $lock = Enter-FileLock -LockPath $script:InventoryLockPath -Purpose 'inventeringstransaktion' -TimeoutSeconds 120

        $hashBefore = Get-FileSha256 -Path $RawDataPath
        $package = Open-ExcelPackage -Path $RawDataPath
        $sheet = Get-InventoryWorksheet -Package $package
        Assert-InventorySchema -Sheet $sheet
        $current = Get-InventoryRowSnapshot -Sheet $sheet -RowNumber ([int]$ExpectedOld.Row)
        $result.Old = $current
        $package.Dispose()
        $package = $null

        if (-not (Test-InventoryRowMatches -Expected $ExpectedOld -Actual $current)) {
            $result.Conflict = $true
            $result.Message = 'Raden har ändrats sedan den visades. Ingen ändring sparades.'
            return $result
        }

        $action = Get-InventoryAction -Old $current -New $Desired
        $result.Action = $action

        $journal = [pscustomobject][ordered]@{
            TransactionId = $transactionId
            State = 'CREATED'
            CreatedAt = [DateTimeOffset]::Now.ToString('o')
            UpdatedAt = ''
            User = [Environment]::UserName
            DomainUser = Get-DomainUser
            Signature = $Signature
            Action = $action
            PN = $current.PN
            Row = [int]$current.Row
            ExpectedOld = $current
            DesiredNew = $Desired
            RawDataPath = $RawDataPath
            AuditLogPath = $script:AuditLogPath
            RawDataHashBefore = $hashBefore
            RawDataHashAfter = ''
            BackupPath = ''
            TemporaryPath = ''
            LastError = ''
        }
        Write-TransactionJournal -Journal $journal | Out-Null

        $pending = New-AuditRecord -TransactionId $transactionId -Status 'PENDING' -Signature $Signature `
            -Action $action -PN $current.PN -Row ([int]$current.Row) -Old $current -New $Desired `
            -RawDataHashBefore $hashBefore -Message 'Write-ahead record created before raw data change.'
        Write-AuditRecord -Record $pending -Path $script:AuditLogPath
        $pendingWritten = $true
        $journal.State = 'AUDIT_PENDING_WRITTEN'
        Write-TransactionJournal -Journal $journal | Out-Null

        $backupPath = New-VerifiedBackup -SourcePath $RawDataPath -TransactionId $transactionId -ExpectedHash $hashBefore
        $result.BackupPath = $backupPath
        $journal.BackupPath = $backupPath
        $journal.State = 'BACKUP_VERIFIED'
        Write-TransactionJournal -Journal $journal | Out-Null

        $tempResult = Save-UpdatedWorkbookToTemporaryFile -SourcePath $RawDataPath -RowNumber ([int]$current.Row) `
            -Desired $Desired -Signature $Signature -TransactionId $transactionId
        $tempPath = $tempResult.Path
        $hashAfter = $tempResult.Hash
        $journal.TemporaryPath = $tempPath
        $journal.RawDataHashAfter = $hashAfter
        $journal.State = 'TEMP_VERIFIED'
        Write-TransactionJournal -Journal $journal | Out-Null

        $swapBackupPath = Install-FileAtomically -SourcePath $tempPath -DestinationPath $RawDataPath -TransactionId $transactionId
        $tempPath = ''
        $replacementDone = $true

        $installedHash = Get-FileSha256 -Path $RawDataPath
        if ($installedHash -ne $hashAfter) {
            throw 'SHA-256 för installerad arbetsbok matchar inte den verifierade temporära filen.'
        }
        $journal.State = 'RAW_REPLACED'
        Write-TransactionJournal -Journal $journal | Out-Null

        $verifyPackage = $null
        try {
            $verifyPackage = Open-ExcelPackage -Path $RawDataPath
            $verifySheet = Get-InventoryWorksheet -Package $verifyPackage
            Assert-InventorySchema -Sheet $verifySheet
            $result.New = Get-InventoryRowSnapshot -Sheet $verifySheet -RowNumber ([int]$current.Row)
        }
        finally {
            if ($null -ne $verifyPackage) { $verifyPackage.Dispose() }
        }

        $committed = New-AuditRecord -TransactionId $transactionId -Status 'COMMITTED' -Signature $Signature `
            -Action $action -PN $current.PN -Row ([int]$current.Row) -Old $current -New $Desired `
            -RawDataHashBefore $hashBefore -RawDataHashAfter $hashAfter -Message ("Backup: {0}" -f $backupPath)
        Write-AuditRecord -Record $committed -Path $script:AuditLogPath
        $commitWritten = $true
        $result.AuditFinalized = $true
        $result.Success = $true
        $result.Message = 'Ändringen är verifierad, atomiskt installerad och audit-loggad.'

        # Local journal archiving and swap-file cleanup are housekeeping. A
        # failure here must never undo an already committed and audit-logged update.
        try {
            $journal.State = 'COMMITTED'
            Write-TransactionJournal -Journal $journal | Out-Null
            Complete-TransactionJournal -TransactionId $transactionId -Destination 'Completed'
        }
        catch {
            $result.Message += " Lokal journal kunde inte arkiveras: $($_.Exception.Message)"
        }

        try {
            if (-not [string]::IsNullOrWhiteSpace($swapBackupPath) -and (Test-Path -LiteralPath $swapBackupPath)) {
                Remove-Item -LiteralPath $swapBackupPath -Force -ErrorAction Stop
            }
        }
        catch {
            $result.Message += " Tillfällig swap-backup kunde inte raderas: $($_.Exception.Message)"
        }

        return $result
    }
    catch {
        $errorMessage = $_.Exception.Message

        # COMMITTED was already written. Do not roll back a committed
        # transaction because of a later non-data housekeeping error.
        if ($commitWritten) {
            $result.Success = $true
            $result.AuditFinalized = $true
            $result.Message = "Ändringen är committed, men efterarbete misslyckades: $errorMessage"
            return $result
        }

        $result.Message = $errorMessage
        $rollbackSucceeded = $false
        $status = 'ABORTED'

        if ($replacementDone -and -not [string]::IsNullOrWhiteSpace($backupPath) -and (Test-Path -LiteralPath $backupPath)) {
            try {
                Restore-BackupAtomically -BackupPath $backupPath -DestinationPath $RawDataPath -TransactionId $transactionId
                $restoredHash = Get-FileSha256 -Path $RawDataPath
                if ($restoredHash -ne $hashBefore) { throw 'Återställd fil har fel SHA-256.' }
                $rollbackSucceeded = $true
                $status = 'ROLLED_BACK'
                $result.Message = "Uppdateringen misslyckades och originalfilen återställdes. Orsak: $errorMessage"
            }
            catch {
                $status = 'REVIEW_REQUIRED'
                $result.Message = "KRITISKT: uppdateringen misslyckades och automatisk återställning misslyckades. $errorMessage | Rollback: $($_.Exception.Message)"
            }
        }

        if ($null -ne $journal) {
            $journal.State = $status
            $journal.LastError = $result.Message
            try { Write-TransactionJournal -Journal $journal | Out-Null } catch {}
        }

        if ($pendingWritten) {
            try {
                $finalHash = ''
                if ($replacementDone -and (Test-Path -LiteralPath $RawDataPath -PathType Leaf)) {
                    try { $finalHash = Get-FileSha256 -Path $RawDataPath } catch { $finalHash = '' }
                }
                $finalRecord = New-AuditRecord -TransactionId $transactionId -Status $status -Signature $Signature `
                    -Action $result.Action -PN $ExpectedOld.PN -Row ([int]$ExpectedOld.Row) -Old $result.Old -New $Desired `
                    -RawDataHashBefore $hashBefore -RawDataHashAfter $finalHash -Message $result.Message
                Write-AuditRecord -Record $finalRecord -Path $script:AuditLogPath
                if ($status -in @('ABORTED', 'ROLLED_BACK')) {
                    Complete-TransactionJournal -TransactionId $transactionId -Destination 'Completed'
                }
                elseif ($status -eq 'REVIEW_REQUIRED') {
                    Complete-TransactionJournal -TransactionId $transactionId -Destination 'ReviewRequired'
                }
            }
            catch {
                $result.Message += " | Kunde inte skriva slutstatus i audit-loggen: $($_.Exception.Message)"
            }
        }
        return $result
    }
    finally {
        if ($null -ne $package) { try { $package.Dispose() } catch {} }
        if (-not [string]::IsNullOrWhiteSpace($tempPath) -and (Test-Path -LiteralPath $tempPath)) {
            try { Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue } catch {}
        }
        if ($null -ne $lock) { Exit-FileLock -LockHandle $lock -LockPath $script:InventoryLockPath }
    }
}

function Repair-IncompleteTransactions {
    Ensure-Directory -Path $script:JournalDir
    $files = @(Get-ChildItem -LiteralPath $script:JournalDir -Filter '*.json' -File -ErrorAction SilentlyContinue)
    if ($files.Count -eq 0) { return }

    Write-Host "Hittade $($files.Count) oavslutad transaktion(er). Kontrollerar status..." -ForegroundColor Yellow

    foreach ($file in $files) {
        try {
            $journal = Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction Stop
            if (Test-AuditHasTerminalStatus -TransactionId $journal.TransactionId -Path $script:AuditLogPath) {
                Complete-TransactionJournal -TransactionId $journal.TransactionId -Destination 'Completed'
                continue
            }

            $lock = $null
            $package = $null
            try {
                $lock = Enter-FileLock -LockPath $script:InventoryLockPath -Purpose 'återställningskontroll' -TimeoutSeconds 60
                $package = Open-ExcelPackage -Path $journal.RawDataPath
                $sheet = Get-InventoryWorksheet -Package $package
                Assert-InventorySchema -Sheet $sheet
                $current = Get-InventoryRowSnapshot -Sheet $sheet -RowNumber ([int]$journal.Row)
            }
            finally {
                if ($null -ne $package) { $package.Dispose() }
                if ($null -ne $lock) { Exit-FileLock -LockHandle $lock -LockPath $script:InventoryLockPath }
            }

            $currentMatchesNew = (
                $current.PN -eq $journal.PN -and
                $current.Lot -eq $journal.DesiredNew.Lot -and
                $current.Exp -eq $journal.DesiredNew.Exp -and
                $current.Qty -eq $journal.DesiredNew.Qty
            )
            $currentMatchesOld = Test-InventoryRowMatches -Expected $journal.ExpectedOld -Actual $current

            if ($currentMatchesNew) {
                $hashAfter = Get-FileSha256 -Path $journal.RawDataPath
                $record = New-AuditRecord -TransactionId $journal.TransactionId -Status 'RECOVERED_COMMIT' `
                    -Signature $journal.Signature -Action $journal.Action -PN $journal.PN -Row ([int]$journal.Row) `
                    -Old $journal.ExpectedOld -New $journal.DesiredNew -RawDataHashBefore $journal.RawDataHashBefore `
                    -RawDataHashAfter $hashAfter -Message 'Slutstatus återskapad från lokal transaktionsjournal efter avbrott.'
                Write-AuditRecord -Record $record -Path $script:AuditLogPath
                Complete-TransactionJournal -TransactionId $journal.TransactionId -Destination 'Completed'
                Write-Host "Återskapade COMMIT för transaktion $($journal.TransactionId)." -ForegroundColor Green
            }
            elseif ($currentMatchesOld) {
                $record = New-AuditRecord -TransactionId $journal.TransactionId -Status 'ROLLED_BACK' `
                    -Signature $journal.Signature -Action $journal.Action -PN $journal.PN -Row ([int]$journal.Row) `
                    -Old $journal.ExpectedOld -New $journal.DesiredNew -RawDataHashBefore $journal.RawDataHashBefore `
                    -Message 'Ingen rådataändring kvarstår; transaktionen avslutades vid återställningskontroll.'
                Write-AuditRecord -Record $record -Path $script:AuditLogPath
                Complete-TransactionJournal -TransactionId $journal.TransactionId -Destination 'Completed'
                Write-Host "Avslutade transaktion $($journal.TransactionId) som ROLLED_BACK." -ForegroundColor Yellow
            }
            else {
                $record = New-AuditRecord -TransactionId $journal.TransactionId -Status 'REVIEW_REQUIRED' `
                    -Signature $journal.Signature -Action $journal.Action -PN $journal.PN -Row ([int]$journal.Row) `
                    -Old $journal.ExpectedOld -New $journal.DesiredNew -RawDataHashBefore $journal.RawDataHashBefore `
                    -RawDataHashAfter (Get-FileSha256 -Path $journal.RawDataPath) `
                    -Message 'Aktuell rad matchar varken gammalt eller planerat nytt värde. Manuell granskning krävs.'
                Write-AuditRecord -Record $record -Path $script:AuditLogPath
                Complete-TransactionJournal -TransactionId $journal.TransactionId -Destination 'ReviewRequired'
                Write-Host "Transaktion $($journal.TransactionId) kräver manuell granskning." -ForegroundColor Red
            }
        }
        catch {
            Write-Host "Kunde inte återställa journal '$($file.FullName)': $($_.Exception.Message)" -ForegroundColor Red
        }
    }
}

function Pause-Menu {
    [void](Read-Host 'Tryck Enter för att fortsätta')
}

function Show-AppHeader {
    param([string]$Title = '')

    Clear-Host
    Write-Host '==============================================================' -ForegroundColor Cyan
    Write-Host (" {0} - {1}" -f $script:AppName, $Title) -ForegroundColor Cyan
    Write-Host '==============================================================' -ForegroundColor Cyan
    Write-Host ("Version    : {0}" -f $script:AppVersion) -ForegroundColor DarkGray
    Write-Host ("Windows-ID : {0}" -f (Get-DomainUser)) -ForegroundColor DarkGray
    Write-Host ("Rådata     : {0}" -f $RawDataPath) -ForegroundColor DarkGray
    Write-Host ("Audit      : {0}" -f $script:AuditLogPath) -ForegroundColor DarkGray
    Write-Host ''
}

function Read-MenuNumber {
    param(
        [Parameter(Mandatory = $true)][string]$Prompt,
        [Parameter(Mandatory = $true)][int]$Minimum,
        [Parameter(Mandatory = $true)][int]$Maximum,
        [bool]$AllowBack = $true,
        [bool]$AllowQuit = $true
    )

    while ($true) {
        $inputText = (Read-Host $Prompt).Trim()
        $choice = $inputText.ToUpperInvariant()
        if ($AllowBack -and $choice -eq 'B') { return [pscustomobject]@{ Mode = 'BACK'; Number = 0 } }
        if ($AllowQuit -and $choice -eq 'Q') { return [pscustomobject]@{ Mode = 'QUIT'; Number = 0 } }

        $number = 0
        if ([int]::TryParse($inputText, [ref]$number) -and $number -ge $Minimum -and $number -le $Maximum) {
            return [pscustomobject]@{ Mode = 'SELECT'; Number = $number }
        }
        Write-Host "Ange ett nummer mellan $Minimum och $Maximum$(if ($AllowBack) { ', B' })$(if ($AllowQuit) { ' eller Q' })." -ForegroundColor Yellow
    }
}

function Read-ValidatedText {
    param(
        [Parameter(Mandatory = $true)][string]$Prompt,
        [int]$MaximumLength = 100,
        [bool]$AllowNA = $false
    )

    while ($true) {
        $value = (Read-Host "$Prompt (B = tillbaka, Q = avsluta)").Trim()
        $choice = $value.ToUpperInvariant()
        if ($choice -eq 'B') { return [pscustomobject]@{ Mode = 'BACK'; Value = '' } }
        if ($choice -eq 'Q') { return [pscustomobject]@{ Mode = 'QUIT'; Value = '' } }
        if ([string]::IsNullOrWhiteSpace($value)) {
            Write-Host 'Värdet får inte vara tomt.' -ForegroundColor Yellow
            continue
        }
        if ($value.Length -gt $MaximumLength) {
            Write-Host "Värdet får vara högst $MaximumLength tecken." -ForegroundColor Yellow
            continue
        }
        if ($value -match '[\x00-\x1F]') {
            Write-Host 'Kontrolltecken är inte tillåtna.' -ForegroundColor Yellow
            continue
        }
        if (-not $AllowNA -and (Test-IsNAValue $value)) {
            Write-Host 'N/A får bara anges via funktionen Ta bort post.' -ForegroundColor Yellow
            continue
        }
        return [pscustomobject]@{ Mode = 'VALUE'; Value = $value }
    }
}

function Read-ExpiryDate {
    while ($true) {
        $response = Read-ValidatedText -Prompt 'Utgångsdatum (YYYY-MM-DD eller YYYY-MM)' -MaximumLength 10
        if ($response.Mode -ne 'VALUE') { return $response }
        if ($null -eq (Try-ParseInventoryDate -Text $response.Value)) {
            Write-Host 'Ogiltigt datum. Använd YYYY-MM-DD eller YYYY-MM.' -ForegroundColor Yellow
            continue
        }
        return $response
    }
}

function Confirm-YesNo {
    param([Parameter(Mandatory = $true)][string]$Prompt)

    while ($true) {
        $answer = (Read-Host "$Prompt [J/N]").Trim().ToUpperInvariant()
        if ($answer -in @('J', 'JA', 'Y', 'YES')) { return $true }
        if ($answer -in @('N', 'NEJ', 'NO')) { return $false }
        Write-Host 'Svara J eller N.' -ForegroundColor Yellow
    }
}

function Get-InventoryRowsByPN {
    param([Parameter(Mandatory = $true)][string]$PN)

    $lock = $null
    $package = $null
    $rows = New-Object 'System.Collections.Generic.List[object]'
    try {
        $lock = Enter-FileLock -LockPath $script:InventoryLockPath -Purpose 'läsa inventering' -TimeoutSeconds 60
        $package = Open-ExcelPackage -Path $RawDataPath
        $sheet = Get-InventoryWorksheet -Package $package
        Assert-InventorySchema -Sheet $sheet

        for ($row = 2; $row -le $sheet.Dimension.End.Row; $row++) {
            $candidate = Get-InventoryCellText -Sheet $sheet -Row $row -Column $script:Columns.PN
            if ($candidate -eq $PN) {
                $rows.Add((Get-InventoryRowSnapshot -Sheet $sheet -RowNumber $row))
            }
        }
    }
    finally {
        if ($null -ne $package) { $package.Dispose() }
        if ($null -ne $lock) { Exit-FileLock -LockHandle $lock -LockPath $script:InventoryLockPath }
    }
    return @($rows)
}

function Show-InventoryRows {
    param([Parameter(Mandatory = $true)][object[]]$Rows)

    for ($index = 0; $index -lt $Rows.Count; $index++) {
        $row = $Rows[$index]
        Write-Host ("{0}: Rad {1} | Lot: {2} | Exp: {3} | Qty: {4} | Senast: {5} | Sign: {6}" -f `
            ($index + 1), $row.Row, $row.Lot, $row.Exp, $row.Qty, $row.LastUpdate, $row.Signature) -ForegroundColor Green
    }
}

function Test-InventorySnapshotIsActive {
    param([Parameter(Mandatory = $true)]$InventoryRow)

    return (
        -not (Test-IsNAValue $InventoryRow.PN) -and
        -not (Test-IsNAValue $InventoryRow.Lot) -and
        -not (Test-IsNAValue $InventoryRow.Exp) -and
        -not (Test-IsNAValue $InventoryRow.Qty)
    )
}

function New-CheckOnlyDesiredFromRow {
    param([Parameter(Mandatory = $true)]$InventoryRow)

    return [pscustomobject][ordered]@{
        Lot = $InventoryRow.Lot
        Exp = $InventoryRow.Exp
        Qty = $InventoryRow.Qty
        CheckOnly = $true
    }
}

function Invoke-MarkAllActiveRowsChecked {
    param(
        [Parameter(Mandatory = $true)][object[]]$Rows,
        [Parameter(Mandatory = $true)][string]$Signature
    )

    $activeRows = @($Rows | Where-Object { Test-InventorySnapshotIsActive -InventoryRow $_ })
    if ($activeRows.Count -eq 0) {
        Write-Host 'Det finns inga aktiva poster för detta P/N att markera som checked.' -ForegroundColor Yellow
        return [pscustomobject]@{ SuccessCount = 0; FailCount = 0; ConflictCount = 0; TotalCount = 0 }
    }

    Write-Host ''
    Write-Host ("Följande {0} aktiva post(er) kommer markeras som checked:" -f $activeRows.Count) -ForegroundColor Cyan
    Show-InventoryRows -Rows $activeRows
    Write-Host ''
    Write-Host 'Endast Senast inventering och SIGN uppdateras. Lot, Exp och Qty ändras inte.' -ForegroundColor DarkYellow

    if (-not (Confirm-YesNo -Prompt 'Markera alla aktiva poster för detta P/N som checked?')) {
        return [pscustomobject]@{ SuccessCount = 0; FailCount = 0; ConflictCount = 0; TotalCount = $activeRows.Count }
    }

    $successCount = 0
    $failCount = 0
    $conflictCount = 0

    foreach ($row in $activeRows) {
        $desired = New-CheckOnlyDesiredFromRow -InventoryRow $row
        $transaction = Invoke-InventoryUpdateTransaction -ExpectedOld $row -Desired $desired -Signature $Signature

        if ($transaction.Success) {
            $successCount++
            Write-Host ("OK  | Rad {0} | Lot {1} | Transaction {2}" -f $row.Row, $row.Lot, $transaction.TransactionId) -ForegroundColor Green
        }
        elseif ($transaction.Conflict) {
            $conflictCount++
            Write-Host ("SKIP| Rad {0} | Lot {1} | {2}" -f $row.Row, $row.Lot, $transaction.Message) -ForegroundColor Yellow
        }
        else {
            $failCount++
            Write-Host ("FEL | Rad {0} | Lot {1} | {2}" -f $row.Row, $row.Lot, $transaction.Message) -ForegroundColor Red
        }
    }

    Write-Host ''
    Write-Host ("Klart. Markerade: {0}. Konflikter/skip: {1}. Fel: {2}." -f $successCount, $conflictCount, $failCount) -ForegroundColor Cyan

    return [pscustomobject]@{
        SuccessCount = $successCount
        FailCount = $failCount
        ConflictCount = $conflictCount
        TotalCount = $activeRows.Count
    }
}

function Read-InventoryChange {
    param([Parameter(Mandatory = $true)]$Current)

    Write-Host ''
    Write-Host ("Vald rad {0}: PN {1}" -f $Current.Row, $Current.PN) -ForegroundColor Cyan
    Write-Host ("Nuvarande: Lot={0}, Exp={1}, Qty={2}, Senast={3}, Sign={4}" -f $Current.Lot, $Current.Exp, $Current.Qty, $Current.LastUpdate, $Current.Signature) -ForegroundColor DarkYellow
    Write-Host '1: Uppdatera Lot, Exp och Qty'
    Write-Host '2: Uppdatera endast Qty'
    Write-Host '3: Ta bort posten (Lot, Exp och Qty blir N/A)'
    Write-Host '4: Mark as checked (uppdaterar endast Senast inventering och SIGN)'
    Write-Host 'B: Tillbaka | Q: Avsluta'

    $selection = Read-MenuNumber -Prompt 'Välj' -Minimum 1 -Maximum 4
    if ($selection.Mode -ne 'SELECT') {
        return [pscustomobject]@{ Mode = $selection.Mode; Desired = $null }
    }

    $desired = [pscustomobject][ordered]@{
        Lot = $Current.Lot
        Exp = $Current.Exp
        Qty = $Current.Qty
        CheckOnly = $false
    }

    if ($selection.Number -eq 1) {
        $lot = Read-ValidatedText -Prompt 'Lotnummer' -MaximumLength 100
        if ($lot.Mode -ne 'VALUE') { return [pscustomobject]@{ Mode = $lot.Mode; Desired = $null } }
        $exp = Read-ExpiryDate
        if ($exp.Mode -ne 'VALUE') { return [pscustomobject]@{ Mode = $exp.Mode; Desired = $null } }
        $qty = Read-ValidatedText -Prompt 'Antal i lager' -MaximumLength 50
        if ($qty.Mode -ne 'VALUE') { return [pscustomobject]@{ Mode = $qty.Mode; Desired = $null } }
        $desired.Lot = $lot.Value
        $desired.Exp = $exp.Value
        $desired.Qty = $qty.Value
    }
    elseif ($selection.Number -eq 2) {
        $qty = Read-ValidatedText -Prompt 'Nytt antal i lager' -MaximumLength 50
        if ($qty.Mode -ne 'VALUE') { return [pscustomobject]@{ Mode = $qty.Mode; Desired = $null } }
        $desired.Qty = $qty.Value
    }
    elseif ($selection.Number -eq 3) {
        $desired.Lot = 'N/A'
        $desired.Exp = 'N/A'
        $desired.Qty = 'N/A'
    }
    else {
        $desired.CheckOnly = $true
    }

    if (-not $desired.CheckOnly -and $desired.Lot -eq $Current.Lot -and $desired.Exp -eq $Current.Exp -and $desired.Qty -eq $Current.Qty) {
        Write-Host 'Inget värde har ändrats.' -ForegroundColor Yellow
        return [pscustomobject]@{ Mode = 'BACK'; Desired = $null }
    }

    Write-Host ''
    Write-Host ("Gammalt: Lot={0}, Exp={1}, Qty={2}, Senast={3}, Sign={4}" -f $Current.Lot, $Current.Exp, $Current.Qty, $Current.LastUpdate, $Current.Signature) -ForegroundColor DarkYellow
    if ($desired.CheckOnly) {
        Write-Host ("Nytt   : Lot={0}, Exp={1}, Qty={2}, Senast=dagens datum, Sign=din signatur" -f $desired.Lot, $desired.Exp, $desired.Qty) -ForegroundColor Green
        if (-not (Confirm-YesNo -Prompt 'Markera posten som kontrollerad?')) {
            return [pscustomobject]@{ Mode = 'BACK'; Desired = $null }
        }
    }
    else {
        Write-Host ("Nytt   : Lot={0}, Exp={1}, Qty={2}" -f $desired.Lot, $desired.Exp, $desired.Qty) -ForegroundColor Green
        if (-not (Confirm-YesNo -Prompt 'Spara denna ändring?')) {
            return [pscustomobject]@{ Mode = 'BACK'; Desired = $null }
        }
    }

    return [pscustomobject]@{ Mode = 'VALUE'; Desired = $desired }
}

function Update-InventoryInteractive {
    Assert-AuthorizedUser
    $signature = Get-CurrentUserSignature

    while ($true) {
        Show-AppHeader -Title 'Uppdatera inventering'
        Write-Host ("Behörig användare. Kontrollerad signatur: {0}" -f $signature) -ForegroundColor Green
        $pn = (Read-Host 'Ange P/N (Q = tillbaka)').Trim()
        if ($pn.ToUpperInvariant() -eq 'Q') { return }
        if ([string]::IsNullOrWhiteSpace($pn)) { continue }

        $rows = @(Get-InventoryRowsByPN -PN $pn)
        if ($rows.Count -eq 0) {
            Write-Host "P/N '$pn' hittades inte." -ForegroundColor Yellow
            Pause-Menu
            continue
        }

        while ($true) {
            Show-AppHeader -Title 'Uppdatera inventering'
            Write-Host ("P/N: {0}" -f $pn) -ForegroundColor Cyan
            Show-InventoryRows -Rows $rows
            Write-Host ''
            Write-Host 'A: Markera alla aktiva poster för detta P/N som checked'
            Write-Host 'B: Tillbaka | Q: Avsluta'

            $inputText = (Read-Host 'Välj post eller A').Trim()
            $choice = $inputText.ToUpperInvariant()
            if ($choice -eq 'Q') { return }
            if ($choice -eq 'B') { break }

            if ($choice -eq 'A') {
                Invoke-MarkAllActiveRowsChecked -Rows $rows -Signature $signature | Out-Null
                $rows = @(Get-InventoryRowsByPN -PN $pn)
                Pause-Menu
                continue
            }

            $selectedNumber = 0
            $selectionIsNumber = [int]::TryParse($inputText, [ref]$selectedNumber)
            if (-not $selectionIsNumber -or $selectedNumber -lt 1 -or $selectedNumber -gt $rows.Count) {
                Write-Host ("Ange ett nummer mellan 1 och {0}, A, B eller Q." -f $rows.Count) -ForegroundColor Yellow
                Pause-Menu
                continue
            }

            $selected = $rows[$selectedNumber - 1]
            $change = Read-InventoryChange -Current $selected
            if ($change.Mode -eq 'QUIT') { return }
            if ($change.Mode -ne 'VALUE') { continue }

            $transaction = Invoke-InventoryUpdateTransaction -ExpectedOld $selected -Desired $change.Desired -Signature $signature
            if ($transaction.Success) {
                Write-Host ''
                Write-Host 'Ändringen sparades.' -ForegroundColor Green
                Write-Host ("Transaktion : {0}" -f $transaction.TransactionId) -ForegroundColor Green
                Write-Host ("Åtgärd      : {0}" -f $transaction.Action) -ForegroundColor Green
                Write-Host ("Backup      : {0}" -f $transaction.BackupPath) -ForegroundColor DarkGreen
            }
            elseif ($transaction.Conflict) {
                Write-Host "Ingen ändring sparades: $($transaction.Message)" -ForegroundColor Yellow
            }
            else {
                Write-Host "Ändringen misslyckades: $($transaction.Message)" -ForegroundColor Red
            }

            $rows = @(Get-InventoryRowsByPN -PN $pn)
            Pause-Menu
        }
    }
}

function New-UniqueReportPath {
    param(
        [Parameter(Mandatory = $true)][string]$Prefix,
        [Parameter(Mandatory = $true)][string]$Directory
    )

    Ensure-Directory -Path $Directory
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
    return (Join-Path $Directory ("{0}_{1}_{2}.xlsx" -f $Prefix, $stamp, (Get-SafeFileNamePart $env:COMPUTERNAME)))
}

function Generate-InventoryReport {
    $lock = $null
    $package = $null
    $reportPackage = $null
    try {
        Show-AppHeader -Title 'Generera inventeringsrapport'
        $lock = Enter-FileLock -LockPath $script:InventoryLockPath -Purpose 'inventeringsrapport' -TimeoutSeconds 60
        $package = Open-ExcelPackage -Path $RawDataPath
        $sheet = Get-InventoryWorksheet -Package $package
        Assert-InventorySchema -Sheet $sheet

        $data = New-Object 'System.Collections.Generic.List[object]'
        $skipped = 0
        for ($row = 2; $row -le $sheet.Dimension.End.Row; $row++) {
            if (-not (Test-InventoryRowIsActive -Sheet $sheet -Row $row)) {
                $skipped++
                continue
            }
            $data.Add([pscustomobject]@{
                PN = Get-InventoryCellText -Sheet $sheet -Row $row -Column $script:Columns.PN
                LotNr = Get-InventoryCellText -Sheet $sheet -Row $row -Column $script:Columns.Lot
                Exp = Get-InventoryCellText -Sheet $sheet -Row $row -Column $script:Columns.Exp
                Qty = Get-InventoryCellText -Sheet $sheet -Row $row -Column $script:Columns.Qty
                LabCode = Get-InventoryCellText -Sheet $sheet -Row $row -Column $script:Columns.LabCode
                Location = Get-InventoryCellText -Sheet $sheet -Row $row -Column $script:Columns.Location
            })
        }
        $package.Dispose()
        $package = $null
        Exit-FileLock -LockHandle $lock -LockPath $script:InventoryLockPath
        $lock = $null

        if ($data.Count -eq 0) {
            Write-Host 'Ingen aktiv inventeringsdata hittades.' -ForegroundColor Yellow
            return
        }

        $path = New-UniqueReportPath -Prefix 'InventoryReport' -Directory $OutputDir
        $reportPackage = New-Object OfficeOpenXml.ExcelPackage
        $ws = $reportPackage.Workbook.Worksheets.Add('Inventory')
        @('PN', 'LotNr', 'Exp', 'Qty', 'Labb', 'Förvaringsplats') | ForEach-Object -Begin { $column = 1 } -Process {
            (Get-ExcelCell -Sheet $ws -Row 1 -Column $column).Value = $_
            $column++
        }

        $outputRow = 2
        foreach ($item in $data) {
            (Get-ExcelCell -Sheet $ws -Row $outputRow -Column 1).Value = $item.PN
            (Get-ExcelCell -Sheet $ws -Row $outputRow -Column 2).Value = $item.LotNr
            (Get-ExcelCell -Sheet $ws -Row $outputRow -Column 3).Value = $item.Exp
            (Get-ExcelCell -Sheet $ws -Row $outputRow -Column 4).Value = $item.Qty
            (Get-ExcelCell -Sheet $ws -Row $outputRow -Column 5).Value = $item.LabCode
            (Get-ExcelCell -Sheet $ws -Row $outputRow -Column 6).Value = $item.Location
            $outputRow++
        }
        (Get-ExcelRangeByAddress -Sheet $ws -Address 'A1:F1').Style.Font.Bold = $true
        $ws.View.FreezePanes(2, 1)
        (Get-ExcelRangeByAddress -Sheet $ws -Address ('A1:F{0}' -f ($outputRow - 1))).AutoFitColumns()
        $reportPackage.SaveAs((New-Object System.IO.FileInfo($path)))

        Write-Host "Rapport skapad: $path" -ForegroundColor Green
        Write-Host "Aktiva poster: $($data.Count). Bortfiltrerade rader: $skipped." -ForegroundColor DarkGray
        if ($OpenGeneratedReports) { try { Invoke-Item -LiteralPath $path } catch {} }
    }
    finally {
        if ($null -ne $reportPackage) { $reportPackage.Dispose() }
        if ($null -ne $package) { $package.Dispose() }
        if ($null -ne $lock) { Exit-FileLock -LockHandle $lock -LockPath $script:InventoryLockPath }
    }
}

function Generate-ExpiringReport {
    $lock = $null
    $package = $null
    $reportPackage = $null
    try {
        Show-AppHeader -Title 'Material med kort utgångsdatum'
        $lock = Enter-FileLock -LockPath $script:InventoryLockPath -Purpose 'utgångsdatumrapport' -TimeoutSeconds 60
        $package = Open-ExcelPackage -Path $RawDataPath
        $sheet = Get-InventoryWorksheet -Package $package
        Assert-InventorySchema -Sheet $sheet

        $lowerDate = (Get-Date).Date.AddDays(-1 * [Math]::Abs($ExpiringPastDays))
        $upperDate = (Get-Date).Date.AddDays([Math]::Abs($ExpiringFutureDays))
        $data = New-Object 'System.Collections.Generic.List[object]'

        for ($row = 2; $row -le $sheet.Dimension.End.Row; $row++) {
            if (-not (Test-InventoryRowIsActive -Sheet $sheet -Row $row)) { continue }
            $expText = Get-InventoryCellText -Sheet $sheet -Row $row -Column $script:Columns.Exp
            $expDate = Try-ParseInventoryDate -Text $expText
            if ($null -ne $expDate -and $expDate -ge $lowerDate -and $expDate -le $upperDate) {
                $data.Add([pscustomobject]@{
                    PN = Get-InventoryCellText -Sheet $sheet -Row $row -Column $script:Columns.PN
                    LotNr = Get-InventoryCellText -Sheet $sheet -Row $row -Column $script:Columns.Lot
                    Exp = $expText
                    Description = Get-InventoryCellText -Sheet $sheet -Row $row -Column $script:Columns.Description
                })
            }
        }
        $package.Dispose()
        $package = $null
        Exit-FileLock -LockHandle $lock -LockPath $script:InventoryLockPath
        $lock = $null

        if ($data.Count -eq 0) {
            Write-Host "Inga aktiva poster hittades mellan $($lowerDate.ToString('yyyy-MM-dd')) och $($upperDate.ToString('yyyy-MM-dd'))." -ForegroundColor Yellow
            return
        }

        $path = New-UniqueReportPath -Prefix 'ExpiringPNsReport' -Directory $OutputDir
        $reportPackage = New-Object OfficeOpenXml.ExcelPackage
        $ws = $reportPackage.Workbook.Worksheets.Add('Expiring')
        @('PN', 'Lotnummer', 'Utgångsdatum', 'Beskrivning') | ForEach-Object -Begin { $column = 1 } -Process {
            (Get-ExcelCell -Sheet $ws -Row 1 -Column $column).Value = $_
            $column++
        }
        $outputRow = 2
        foreach ($item in $data) {
            (Get-ExcelCell -Sheet $ws -Row $outputRow -Column 1).Value = $item.PN
            (Get-ExcelCell -Sheet $ws -Row $outputRow -Column 2).Value = $item.LotNr
            (Get-ExcelCell -Sheet $ws -Row $outputRow -Column 3).Value = $item.Exp
            (Get-ExcelCell -Sheet $ws -Row $outputRow -Column 4).Value = $item.Description
            $outputRow++
        }
        (Get-ExcelRangeByAddress -Sheet $ws -Address 'A1:D1').Style.Font.Bold = $true
        $ws.View.FreezePanes(2, 1)
        (Get-ExcelRangeByAddress -Sheet $ws -Address ('A1:D{0}' -f ($outputRow - 1))).AutoFitColumns()
        $reportPackage.SaveAs((New-Object System.IO.FileInfo($path)))

        Write-Host "Rapport skapad: $path" -ForegroundColor Green
        Write-Host "Poster: $($data.Count). Intervall: $($lowerDate.ToString('yyyy-MM-dd')) till $($upperDate.ToString('yyyy-MM-dd'))." -ForegroundColor DarkGray
        if ($OpenGeneratedReports) { try { Invoke-Item -LiteralPath $path } catch {} }
    }
    finally {
        if ($null -ne $reportPackage) { $reportPackage.Dispose() }
        if ($null -ne $package) { $package.Dispose() }
        if ($null -ne $lock) { Exit-FileLock -LockHandle $lock -LockPath $script:InventoryLockPath }
    }
}

function Show-ProductInformation {
    Show-AppHeader -Title 'Sök material per produkt'
    $query = (Read-Host 'Produktnamn eller del av produktnamn').Trim()
    if ([string]::IsNullOrWhiteSpace($query)) { return }

    $lock = $null
    $package = $null
    $matches = New-Object 'System.Collections.Generic.List[object]'
    try {
        $lock = Enter-FileLock -LockPath $script:InventoryLockPath -Purpose 'produktsökning' -TimeoutSeconds 60
        $package = Open-ExcelPackage -Path $RawDataPath
        $sheet = Get-InventoryWorksheet -Package $package
        Assert-InventorySchema -Sheet $sheet

        for ($row = 2; $row -le $sheet.Dimension.End.Row; $row++) {
            if (-not (Test-InventoryRowIsActive -Sheet $sheet -Row $row)) { continue }
            $matched = $false
            for ($column = $script:Columns.ProductStartCol; $column -le $script:Columns.ProductEndCol; $column++) {
                $product = Get-InventoryCellText -Sheet $sheet -Row $row -Column $column
                if (-not [string]::IsNullOrWhiteSpace($product) -and $product.IndexOf($query, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
                    $matched = $true
                    break
                }
            }
            if ($matched) {
                $matches.Add([pscustomobject]@{
                    PN = Get-InventoryCellText -Sheet $sheet -Row $row -Column $script:Columns.PN
                    LotNr = Get-InventoryCellText -Sheet $sheet -Row $row -Column $script:Columns.Lot
                    Exp = Get-InventoryCellText -Sheet $sheet -Row $row -Column $script:Columns.Exp
                    Qty = Get-InventoryCellText -Sheet $sheet -Row $row -Column $script:Columns.Qty
                    Description = Get-InventoryCellText -Sheet $sheet -Row $row -Column $script:Columns.Description
                })
            }
        }
    }
    finally {
        if ($null -ne $package) { $package.Dispose() }
        if ($null -ne $lock) { Exit-FileLock -LockHandle $lock -LockPath $script:InventoryLockPath }
    }

    if ($matches.Count -eq 0) {
        Write-Host "Ingen aktiv post matchade '$query'." -ForegroundColor Yellow
    }
    else {
        $matches | Sort-Object PN, LotNr | Format-Table -AutoSize
    }
}

function Test-StartupPrerequisites {
    if (-not (Test-Path -LiteralPath $RawDataPath -PathType Leaf)) {
        throw "Rådatafilen saknas: $RawDataPath"
    }
    if ([System.IO.Path]::GetExtension($RawDataPath) -ne '.xlsx') {
        throw 'RawDataPath måste peka på en .xlsx-fil.'
    }

    Ensure-Directory -Path (Split-Path -Parent $script:AuditLogPath)
    Ensure-Directory -Path $script:BackupDir
    Ensure-Directory -Path $OutputDir
    Ensure-Directory -Path $script:JournalDir
    Ensure-Directory -Path $script:CompletedJournalDir
    Ensure-Directory -Path $script:ReviewJournalDir

    # Confirm write access without modifying controlled files.
    foreach ($directory in @((Split-Path -Parent $script:AuditLogPath), $script:BackupDir, $OutputDir, $script:JournalDir)) {
        $probe = Join-Path $directory (".write-test.{0}.{1}.tmp" -f $env:COMPUTERNAME, $PID)
        try {
            [System.IO.File]::WriteAllText($probe, 'test', (New-Object System.Text.UTF8Encoding($false)))
        }
        finally {
            Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
        }
    }

    Import-EPPlus

    $lock = $null
    $package = $null
    try {
        $lock = Enter-FileLock -LockPath $script:InventoryLockPath -Purpose 'startkontroll' -TimeoutSeconds 60
        $package = Open-ExcelPackage -Path $RawDataPath
        $sheet = Get-InventoryWorksheet -Package $package
        Assert-InventorySchema -Sheet $sheet
    }
    finally {
        if ($null -ne $package) { $package.Dispose() }
        if ($null -ne $lock) { Exit-FileLock -LockHandle $lock -LockPath $script:InventoryLockPath }
    }

    Initialize-AuditLog -Path $script:AuditLogPath
    Repair-IncompleteTransactions
}

function Main-Menu {
    while ($true) {
        Show-AppHeader -Title 'Huvudmeny'
        Write-Host '1: Uppdatera inventering'
        Write-Host '2: Generera inventeringsrapport'
        Write-Host '3: Generera rapport för kort utgångsdatum'
        Write-Host '4: Sök material per produkt'
        Write-Host '5: Avsluta'
        Write-Host ''

        $choice = (Read-Host 'Välj').Trim().ToUpperInvariant()
        try {
            switch ($choice) {
                '1' { Update-InventoryInteractive }
                '2' { Generate-InventoryReport; Pause-Menu }
                '3' { Generate-ExpiringReport; Pause-Menu }
                '4' { Show-ProductInformation; Pause-Menu }
                '5' { return }
                'Q' { return }
                default { Write-Host 'Ogiltigt val.' -ForegroundColor Yellow; Pause-Menu }
            }
        }
        catch {
            Write-Host ''
            Write-Host $_.Exception.Message -ForegroundColor Red
            if ($_.InvocationInfo -and $_.InvocationInfo.ScriptLineNumber) { Write-Host ("Rad i scriptet: {0}" -f $_.InvocationInfo.ScriptLineNumber) -ForegroundColor DarkYellow }
            Pause-Menu
        }
    }
}

try {
    Show-AppHeader -Title 'Startkontroll'
    Test-StartupPrerequisites
    Main-Menu
}
catch {
    Write-Host ''
    Write-Host 'Scriptet avbröts.' -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    if ($_.InvocationInfo -and $_.InvocationInfo.ScriptLineNumber) { Write-Host ("Rad i scriptet: {0}" -f $_.InvocationInfo.ScriptLineNumber) -ForegroundColor DarkYellow }
    [void](Read-Host 'Tryck Enter för att stänga')
    exit 1
}
