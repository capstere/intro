﻿function Read-TestSummaryCsvLines {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    $sr = $null
    try {
        # BOM-aware read. Fallback UTF8 is safe for current GeneXpert exports and preserves legacy ASCII content.
        $sr = New-Object System.IO.StreamReader -ArgumentList $Path, ([System.Text.Encoding]::UTF8), $true
        $list = New-Object System.Collections.Generic.List[string]
        while (($line = $sr.ReadLine()) -ne $null) { [void]$list.Add($line) }
        return @($list.ToArray())
    } catch {
        try { return @(Get-Content -LiteralPath $Path -Encoding Default -ErrorAction Stop) } catch { return @() }
    } finally {
        try { if ($sr) { $sr.Close() } } catch {}
        try { if ($sr) { $sr.Dispose() } } catch {}
    }
}

function Test-PackedCsvLine {
    param([AllowNull()][string]$Line)
    if ($null -eq $Line) { return $false }
    $t = ($Line + '').Trim()
    if ($t.Length -lt 2) { return $false }
    if (-not ($t.StartsWith('"') -and $t.EndsWith('"'))) { return $false }
    $inner = $t.Substring(1, $t.Length - 2)
    return ($inner -match '(?i)\bAssay\b\s*,\s*Assay Version\b|,\s*Sample ID\b|\t\s*Sample ID\b') -or ($inner -match ',')
}

function Expand-PackedCsvLine {
    param([AllowNull()][string]$Line)
    if ($null -eq $Line) { return '' }
    $t = ($Line + '').Trim()
    if ($t.Length -ge 2 -and $t.StartsWith('"') -and $t.EndsWith('"')) {
        $t = $t.Substring(1, $t.Length - 2)
        $t = $t -replace '""','"'
    }
    return $t
}

function Get-CsvDelimiter { param([string]$Path)
    try {
        $lines = Read-TestSummaryCsvLines -Path $Path
        foreach ($raw in @($lines | Select-Object -First 40)) {
            if (-not $raw -or -not ($raw + '').Trim()) { continue }
            $line = if (Test-PackedCsvLine -Line $raw) { Expand-PackedCsvLine -Line $raw } else { $raw }
            $sc = ([regex]::Matches($line, ';')).Count
            $cc = ([regex]::Matches($line, ',')).Count
            $tc = ([regex]::Matches($line, "`t")).Count
            if (($cc + $tc + $sc) -lt 1) { continue }
            if ($cc -ge $sc -and $cc -ge $tc -and $cc -gt 0) { return ',' }
            if ($tc -gt $sc -and $tc -gt 0) { return "`t" }
            if ($sc -gt 0) { return ';' }
        }
        return ','
    } catch {
        Gui-Log "⚠️ Get-CsvDelimiter misslyckades: $($_.Exception.Message)" 'Warn'
        return ','
    }
}

function Get-TestSummaryCsvProfile {
    param(
        [string]$Path,
        [string[]]$Lines
    )
    $lines = @($Lines)
    if ($lines.Count -eq 0 -and $Path) { $lines = @(Read-TestSummaryCsvLines -Path $Path) }
    if (-not $lines -or $lines.Count -eq 0) { return $null }

    $maxScan = [Math]::Min($lines.Count - 1, 30)
    for ($i = 0; $i -le $maxScan; $i++) {
        $raw = $lines[$i]
        if (-not $raw -or -not ($raw + '').Trim()) { continue }
        $fields = ConvertTo-CsvFields -Line $raw -Delimiter ''
        if (-not $fields -or $fields.Count -lt 3) { continue }
        $hasAssay = $false; $hasSample = $false; $hasCart = $false
        foreach ($h0 in $fields) {
            $h = (($h0 + '') -replace '^[\uFEFF]+','').Trim()
            if ($h -ieq 'Assay') { $hasAssay = $true }
            elseif ($h -ieq 'Sample ID' -or $h -ieq 'SampleID') { $hasSample = $true }
            elseif ($h -ieq 'Cartridge S/N') { $hasCart = $true }
        }
        if ($hasAssay -and $hasSample -and $hasCart) {
            $dataStart = $i + 1
            while ($dataStart -lt $lines.Count) {
                $ln = $lines[$dataStart]
                if ($ln -and (($ln + '').Trim().Length -gt 0)) { break }
                $dataStart++
            }
            $profileName = 'Legacy'
            if ((Test-PackedCsvLine -Line $raw) -or $i -eq 8) { $profileName = 'PackedA_Row11' }
            return [pscustomobject]@{
                ProfileName    = $profileName
                HeaderIndex    = $i
                HeaderRow      = $i + 1
                DataStartIndex = $dataStart
                DataStartRow   = $dataStart + 1
                Headers        = @($fields)
            }
        }
    }
    return $null
}

function Test-IsResampleCsv {
    <# Returnerar $true om CSV:n innehåller _RES_ i Sample ID-kolumnen (>= MinHits träffar). #>
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$MinHits = 3
    )

    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    $threshold = [Math]::Max(1, [int]$MinHits)

    try {
        $lines = @(Read-TestSummaryCsvLines -Path $Path)
        $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
        if (-not $profile) { return $false }
        $hdr = @($profile.Headers)

        $sampleIdIdx = 0
        for ($i = 0; $i -lt $hdr.Count; $i++) {
            $h = ($hdr[$i] + '').Trim()
            if ($h -imatch '^Sample\s*ID$' -or $h -ieq 'SampleID' -or $h -imatch '^Sample\s*Id$') {
                $sampleIdIdx = $i
                break
            }
        }

        $resCount = 0
        for ($r = [int]$profile.DataStartIndex; $r -lt $lines.Count; $r++) {
            $line = $lines[$r]
            if (-not $line -or $line.Trim().Length -eq 0) { continue }
            $fields = ConvertTo-CsvFields -Line $line -Delimiter ''
            if (-not $fields -or $fields.Count -le $sampleIdIdx) { continue }
            $sid = ($fields[$sampleIdIdx] + '')
            if ($sid -imatch '_RES_') { $resCount++ }
        }

        return ($resCount -ge $threshold)
    } catch {
        try {
            Gui-Log ("⚠️ Test-IsResampleCsv misslyckades för '{0}': {1}" -f (Split-Path $Path -Leaf), $_.Exception.Message) 'Warn' 'DEBUG'
        } catch {}
        return $false
    }
}


function Resolve-CsvPrimaryAndResample {
    <# Klassificerar 0-2 CSV-filer till Primary + ev. Resample med samma regel som i buildflödet. #>
    param([string[]]$CsvPaths)

    $result = [pscustomobject]@{
        Ok             = $true
        PrimaryCsv     = $null
        ResampleCsv    = $null
        HasResample    = $false
        ErrorMessage   = $null
        WarningMessage = $null
    }

    $paths = @($CsvPaths | Where-Object { $_ -and (($_ + '').Trim().Length -gt 0) })

    if ($paths.Count -eq 0) { return $result }

    if ($paths.Count -eq 1) {
        if (Test-IsResampleCsv -Path $paths[0]) {
            $result.Ok = $false
            $result.ResampleCsv = $paths[0]
            $result.ErrorMessage = '❌ Enbart Resampling-CSV vald. Välj även Primary CSV innan rapport kan skapas.'
            return $result
        }
        $result.PrimaryCsv = $paths[0]
        return $result
    }

    if ($paths.Count -eq 2) {
        $isRes0 = Test-IsResampleCsv -Path $paths[0]
        $isRes1 = Test-IsResampleCsv -Path $paths[1]

        if ($isRes0 -and -not $isRes1) {
            $result.ResampleCsv = $paths[0]
            $result.PrimaryCsv = $paths[1]
        } elseif ($isRes1 -and -not $isRes0) {
            $result.PrimaryCsv = $paths[0]
            $result.ResampleCsv = $paths[1]
        } elseif (-not $isRes0 -and -not $isRes1) {
            $result.Ok = $false
            $result.ErrorMessage = '❌ Du har valt 2 CSV-filer men ingen Resampling CSV-fil. Avmarkera en fil eller välj korrekt Resampling CSV-fil.'
            return $result
        } else {
            $result.PrimaryCsv = $paths[0]
            $result.ResampleCsv = $paths[1]
            $result.WarningMessage = '⚠️ Båda CSV har _RES_ i Sample ID – autoväljer Resampling + Original.'
        }

        $result.HasResample = [bool]$result.ResampleCsv
        return $result
    }

    $result.Ok = $false
    $result.ErrorMessage = ("❌ Du har valt {0} CSV-filer. Välj max 2 (Primary + ev. Resample)." -f $paths.Count)
    return $result
}

function Get-AssayFromCsv { param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    try {
        $lines = @(Read-TestSummaryCsvLines -Path $Path)
        $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
        $startIndex = if ($profile) { [int]$profile.DataStartIndex } else { [Math]::Max(0, [int]$StartRow - 1) }
        for ($i = $startIndex; $i -lt $lines.Count; $i++) {
            $ln = $lines[$i]
            if (-not $ln -or $ln.Trim().Length -eq 0) { continue }
            $f = ConvertTo-CsvFields -Line $ln -Delimiter ''
            if (-not $f -or $f.Length -lt 1) { continue }
            $a = ([string]$f[0]).Trim()
            if ($a -and $a -notmatch '^(?i)\s*assay\s*$') { return $a }
        }
    } catch {
        Gui-Log "⚠️ Kunde inte läsa Assay från CSV: $($_.Exception.Message)" 'Warn'
    }
    return $null
}


function Import-CsvRows { param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    $list  = New-Object System.Collections.Generic.List[object]
    try {
        $lines = @(Read-TestSummaryCsvLines -Path $Path)
        if (-not $lines -or $lines.Count -eq 0) { return @() }
        $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
        $startIndex = if ($profile) { [int]$profile.DataStartIndex } else { [Math]::Max(0, [int]$StartRow - 1) }
        for ($i = $startIndex; $i -lt $lines.Count; $i++) {
            $ln = $lines[$i]
            if (-not $ln -or $ln.Trim().Length -eq 0) { continue }
            $f = ConvertTo-CsvFields -Line $ln -Delimiter ''
            if (-not $f -or ($f -join '').Trim().Length -eq 0) { continue }
            [void]$list.Add($f)
        }
    } catch {
        Gui-Log "⚠️ Kunde inte läsa rader från CSV: $($_.Exception.Message)" 'Warn'
    }
    return @($list.ToArray())
}


function ConvertTo-CsvFields {
    param(
        [Parameter(Mandatory=$true)][AllowEmptyString()][string]$Line,
        [string]$Delimiter
    )
    if ($null -eq $Line) { return @() }

    $lineToParse = $Line
    $packed = Test-PackedCsvLine -Line $lineToParse
    if ($packed) {
        # Ny exportvariant: hela logiska CSV-raden ligger i kolumn A och är omsluten av citattecken.
        # Motsvarar Excel: Text to Columns -> Delimited -> Tab + Comma -> General.
        $lineToParse = Expand-PackedCsvLine -Line $lineToParse
    }

    $del = $Delimiter
    if ([string]::IsNullOrWhiteSpace($del)) {
        $cSemi  = ([regex]::Matches($lineToParse, ';')).Count
        $cComma = ([regex]::Matches($lineToParse, ',')).Count
        $cTab   = ([regex]::Matches($lineToParse, "`t")).Count
        if ($packed -or (($cComma -gt 0) -and ($cTab -gt 0))) { $del = '__TABCOMMA__' }
        elseif ($cTab -gt $cComma -and $cTab -gt $cSemi) { $del = "`t" }
        elseif ($cSemi -gt $cComma) { $del = ';' }
        else { $del = ',' }
    }

    if ($del -eq '__TABCOMMA__') {
        $rx = '(?:,|\t)(?=(?:(?:[^\"]*\"){2})*[^\"]*$)'
    } else {
        $d  = [regex]::Escape($del)
        $rx = $d + '(?=(?:(?:[^\"]*\"){2})*[^\"]*$)'
    }
    $arr = [regex]::Split($lineToParse, $rx)
    return ,@($arr | ForEach-Object { (($_ + '') -replace '^"|"$','').Trim() })
}


function Get-CsvStats {
    param(
        [string]$Path,
        [string[]]$Lines
    )
    $out = [ordered]@{
        TestCount       = 0
        DupCount        = 0
        Duplicates      = @()
        LspValues       = @()
        LspOK           = $null
        InstrumentByType= [ordered]@{}
    }

    $lines = @($Lines)
    if ($lines.Count -eq 1 -and -not $lines[0]) { $lines = @() }
    if ($Path -and (Test-Path -LiteralPath $Path)) {
        $lines = @(Read-TestSummaryCsvLines -Path $Path)
    }
    if ($lines.Count -eq 0) { return [pscustomobject]$out }

    $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
    if (-not $profile) { return [pscustomobject]$out }

    $header = @($profile.Headers)
    function _FindHeaderIndex([string[]]$Names, [int]$DefaultIndex) {
        foreach ($name in $Names) {
            for ($ii = 0; $ii -lt $header.Count; $ii++) {
                if ((($header[$ii] + '').Trim()) -ieq $name) { return $ii }
            }
        }
        return $DefaultIndex
    }

    $idxCart = _FindHeaderIndex @('Cartridge S/N') 3
    $idxLsp  = _FindHeaderIndex @('Reagent Lot ID') 4
    $idxIns  = _FindHeaderIndex @('Instrument S/N') 6

    $cartSnList = New-Object System.Collections.Generic.List[string]
    $lspList    = New-Object System.Collections.Generic.List[string]
    $instrList  = New-Object System.Collections.Generic.List[string]

    for ($r = [int]$profile.DataStartIndex; $r -lt $lines.Count; $r++) {
        $ln = $lines[$r]
        if (-not $ln -or -not $ln.Trim()) { continue }
        $f = ConvertTo-CsvFields -Line $ln -Delimiter ''
        if (-not $f -or $f.Count -lt 7) { continue }
        if ($f.Count -gt $idxCart) { $cartSnList.Add( ($f[$idxCart] + '').Trim() ) }
        if ($f.Count -gt $idxLsp)  { $lspList.Add(    ($f[$idxLsp]  + '').Trim() ) }
        if ($f.Count -gt $idxIns)  { $instrList.Add(  ($f[$idxIns]  + '').Trim() ) }
    }

    $cartSn = $cartSnList | Where-Object { $_ -and $_ -ne '' }
    $out.TestCount = @($cartSn).Count
    $dups = $cartSn | Group-Object | Where-Object { $_.Count -gt 1 }
    if ($dups) {
        $out.DupCount   = @($dups).Count
        $out.Duplicates = @($dups) | ForEach-Object { "$($_.Name) x$($_.Count)" }
    }
    $lspClean = $lspList | ForEach-Object {
        $m = [regex]::Match($_, '(?<!\d)(\d{5})(?!\d)')
        if ($m.Success) { $m.Groups[1].Value } else { $null }
    } | Where-Object { $_ } | Select-Object -Unique
    $out.LspValues = @($lspClean)
    if (@($lspClean).Count -gt 0) {
        $out.LspOK = (@($lspClean).Count -eq 1)
    }
    $lut = @{ '6'='GeneXpert 6-color'; '10'='GeneXpert 10-color'; '16'='Infinity 48s'; 'Infinity'='Infinity 48s' }
    foreach ($ins in ($instrList | Where-Object { $_ })) {
        $t = $null
        if ($lut.ContainsKey($ins)) { $t = $lut[$ins] } else { $t = 'Unknown' }
        if (-not $out.InstrumentByType.Contains($t)) { $out.InstrumentByType[$t] = 0 }
        $out.InstrumentByType[$t] = [int]$out.InstrumentByType[$t] + 1
    }
    return [pscustomobject]$out
}


function Import-CsvRowsStreaming {
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$StartRow = 10,
        [Parameter(Mandatory)][scriptblock]$ProcessRow
    )
    try {
        $lines = @(Read-TestSummaryCsvLines -Path $Path)
        $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
        $startIndex = if ($profile) { [int]$profile.DataStartIndex } else { [Math]::Max(0, [int]$StartRow - 1) }
        for ($i = $startIndex; $i -lt $lines.Count; $i++) {
            $line = $lines[$i]
            if (-not $line -or $line.Trim().Length -eq 0) { continue }
            $fields = ConvertTo-CsvFields -Line $line -Delimiter ''
            if ($fields -and (($fields -join '').Trim().Length -gt 0)) {
                & $ProcessRow -Fields $fields -RowIndex ($i + 1)
            }
        }
    } catch {
        throw
    }
}

# ============================================================================
# CSV internal normalizer for GeneXpert Test Summary exports
# ----------------------------------------------------------------------------
# Purpose:
#   Keep the existing, working IPTCompile CSV flow intact by converting only the
#   staged/TEMP copy of newer Test Summary CSV variants into the classic internal
#   layout expected by the rest of the script:
#       row 8  = header
#       row 9  = blank separator
#       row 10 = first data row
#   The original network/source CSV is never modified.
#
# Handles observed input variants:
#   1) Classic comma CSV, header row 8, data row 10 -> unchanged.
#   2) New quoted comma-in-column-A export, header row 9, data row 11.
#   3) New UTF-16LE tab-delimited export, header row 9, data row 11.
#   Splitting matches Excel Text to Columns: Delimited -> Tab + Comma -> General.
# ============================================================================

function Read-TestSummaryCsvNormalizeLines {
    param([Parameter(Mandatory)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    try {
        $bytes = [System.IO.File]::ReadAllBytes($Path)
        if (-not $bytes -or $bytes.Length -eq 0) { return @() }

        $enc = [System.Text.Encoding]::Default
        $offset = 0
        if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
            $enc = New-Object System.Text.UTF8Encoding -ArgumentList $false, $true
            $offset = 3
        } elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
            $enc = [System.Text.Encoding]::Unicode
            $offset = 2
        } elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF) {
            $enc = [System.Text.Encoding]::BigEndianUnicode
            $offset = 2
        }

        $text = $enc.GetString($bytes, $offset, $bytes.Length - $offset)
        if ($null -eq $text) { return @() }
        $text = ($text + '').Replace(([string][char]0xFEFF), '')
        return ,@($text -split "`r`n|`n|`r")
    } catch {
        try { return @(Get-Content -LiteralPath $Path -Encoding Default -ErrorAction Stop) } catch { return @() }
    }
}

function ConvertTo-TestSummaryTextToColumnsFields {
    param([AllowNull()][string]$Line)

    if ($null -eq $Line) { return @() }
    $s = ($Line + '').Replace(([string][char]0xFEFF), '').Replace(([string][char]0x200B), '')
    $t = $s.Trim()

    # New export variant: the entire logical row may be one quoted value in column A.
    # Example: "Assay,Assay Version,Sample ID,..."
    if ($t.Length -ge 2 -and $t.StartsWith('"') -and $t.EndsWith('"')) {
        $inner = $t.Substring(1, $t.Length - 2)
        if ($inner -match '[,\t]') {
            $s = $inner.Replace('""','"')
        }
    }

    if ([string]::IsNullOrWhiteSpace($s)) { return @() }

    # Excel Text-to-Columns equivalent: delimiters Tab + Comma, respecting double quotes.
    $rx = '[,\t](?=(?:(?:[^\"]*\"){2})*[^\"]*$)'
    $raw = [regex]::Split($s, $rx)
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($item in @($raw)) {
        $v = ($item + '').Trim()
        if ($v.Length -ge 2 -and $v.StartsWith('"') -and $v.EndsWith('"')) {
            $v = $v.Substring(1, $v.Length - 2).Replace('""','"')
        }
        [void]$out.Add($v)
    }

    # Reduce very wide rows caused by trailing empty columns. Keep internal empty fields.
    while ($out.Count -gt 0 -and [string]::IsNullOrWhiteSpace(($out[$out.Count - 1] + ''))) {
        $out.RemoveAt($out.Count - 1)
    }

    return ,@($out.ToArray())
}

function ConvertFrom-TestSummaryFieldsToCsvLine {
    param([object[]]$Fields)

    $parts = New-Object System.Collections.Generic.List[string]
    foreach ($field in @($Fields)) {
        $v = ($field + '')
        if ($v.Contains(',') -or $v.Contains('"') -or $v.Contains("`r") -or $v.Contains("`n")) {
            $v = '"' + $v.Replace('"','""') + '"'
        }
        [void]$parts.Add($v)
    }
    return ($parts.ToArray() -join ',')
}

function Get-TestSummaryCsvNormalizeProfile {
    param([Parameter(Mandatory)][string[]]$Lines)

    $result = [ordered]@{
        HasHeader          = $false
        HeaderIndex        = -1
        DataStartIndex     = -1
        HeaderFields       = @()
        NeedsNormalization = $false
        Reason             = ''
    }

    if (-not $Lines -or $Lines.Count -eq 0) { return [pscustomobject]$result }

    $max = [Math]::Min($Lines.Count - 1, 30)
    for ($i = 0; $i -le $max; $i++) {
        $fields = @(ConvertTo-TestSummaryTextToColumnsFields -Line $Lines[$i])
        if (-not $fields -or $fields.Count -lt 3) { continue }

        $hasAssay = $false
        $hasSampleId = $false
        $hasCart = $false
        foreach ($f0 in @($fields)) {
            $f = ($f0 + '').Trim()
            if ($f -ieq 'Assay') { $hasAssay = $true }
            elseif ($f -ieq 'Sample ID' -or $f -ieq 'SampleID') { $hasSampleId = $true }
            elseif ($f -ieq 'Cartridge S/N') { $hasCart = $true }
        }

        if ($hasAssay -and $hasSampleId -and $hasCart) {
            $result.HasHeader = $true
            $result.HeaderIndex = $i
            $result.HeaderFields = @($fields)
            break
        }
    }

    if (-not $result.HasHeader) { return [pscustomobject]$result }

    $dataStart = [int]$result.HeaderIndex + 1
    while ($dataStart -lt $Lines.Count) {
        $fields = @(ConvertTo-TestSummaryTextToColumnsFields -Line $Lines[$dataStart])
        if ($fields -and (($fields -join '').Trim().Length -gt 0)) { break }
        $dataStart++
    }
    $result.DataStartIndex = $dataStart

    $rawHeader = ''
    try { $rawHeader = ($Lines[$result.HeaderIndex] + '').Trim() } catch { $rawHeader = '' }
    $isPacked = ($rawHeader.Length -ge 2 -and $rawHeader.StartsWith('"') -and $rawHeader.EndsWith('"') -and ($rawHeader -match ','))
    $hasTabs  = ($rawHeader -match "`t")
    $isLegacy = ([int]$result.HeaderIndex -eq 7 -and [int]$result.DataStartIndex -eq 9 -and -not $isPacked -and -not $hasTabs)

    $result.NeedsNormalization = (-not $isLegacy)
    if ($result.NeedsNormalization) {
        $result.Reason = ('header row {0}, data row {1}, packed={2}, tabs={3}' -f ($result.HeaderIndex + 1), ($result.DataStartIndex + 1), $isPacked, $hasTabs)
    } else {
        $result.Reason = 'already classic layout'
    }

    return [pscustomobject]$result
}

function Normalize-TestSummaryCsvForInternalUse {
    <#
      Normalizes only the working/staged copy of a CSV to classic IPTCompile layout.
      Returns an object: Path, Changed, Reason. Path may be the original staged path
      or a normalized temp copy if in-place write is not safe.
    #>
    param(
        [Parameter(Mandatory)][string]$Path,
        [string]$StageDir,
        [string]$Label = 'CSV'
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        return [pscustomobject]@{ Path=$Path; Changed=$false; Reason='path not found' }
    }

    $lines = @(Read-TestSummaryCsvNormalizeLines -Path $Path)
    $profile = Get-TestSummaryCsvNormalizeProfile -Lines $lines

    if (-not $profile.HasHeader) {
        return [pscustomobject]@{ Path=$Path; Changed=$false; Reason='no Test Summary header detected'; Profile=$profile }
    }

    if (-not $profile.NeedsNormalization) {
        return [pscustomobject]@{ Path=$Path; Changed=$false; Reason='already classic Test Summary CSV'; Profile=$profile }
    }

    $outPath = $Path
    $canWriteInPlace = $false
    if ($StageDir -and (Test-Path -LiteralPath $StageDir)) {
        try {
            $stageFull = [System.IO.Path]::GetFullPath($StageDir).TrimEnd([char[]]@([char]92, [char]47))
            $pathFull  = [System.IO.Path]::GetFullPath($Path)
            if ($pathFull.StartsWith($stageFull, [System.StringComparison]::OrdinalIgnoreCase)) { $canWriteInPlace = $true }
        } catch { $canWriteInPlace = $false }
    }

    if (-not $canWriteInPlace) {
        $tmpRoot = if ($StageDir -and (Test-Path -LiteralPath $StageDir)) { $StageDir } else { [System.IO.Path]::GetTempPath() }
        $leaf = [System.IO.Path]::GetFileNameWithoutExtension($Path) + '.normalized.csv'
        $outPath = Join-Path $tmpRoot $leaf
    }

    $out = New-Object System.Collections.Generic.List[string]

    # Preserve first 7 metadata rows, normalized to comma CSV where possible.
    for ($i = 0; $i -lt 7; $i++) {
        if ($i -lt $lines.Count) {
            $fields = @(ConvertTo-TestSummaryTextToColumnsFields -Line $lines[$i])
            if ($fields -and (($fields -join '').Trim().Length -gt 0)) {
                [void]$out.Add((ConvertFrom-TestSummaryFieldsToCsvLine -Fields $fields))
            } else {
                [void]$out.Add('')
            }
        } else {
            [void]$out.Add('')
        }
    }

    # Classic internal layout: header row 8, blank row 9, data from row 10.
    [void]$out.Add((ConvertFrom-TestSummaryFieldsToCsvLine -Fields @($profile.HeaderFields)))
    [void]$out.Add('')

    for ($r = [int]$profile.DataStartIndex; $r -lt $lines.Count; $r++) {
        $fields = @(ConvertTo-TestSummaryTextToColumnsFields -Line $lines[$r])
        if (-not $fields -or (($fields -join '').Trim().Length -eq 0)) { continue }
        [void]$out.Add((ConvertFrom-TestSummaryFieldsToCsvLine -Fields $fields))
    }

    # Internal working copy is plain ANSI/Default-compatible comma CSV. Values here are normally ASCII.
    [System.IO.File]::WriteAllLines($outPath, [string[]]$out.ToArray(), [System.Text.Encoding]::Default)

    return [pscustomobject]@{
        Path    = $outPath
        Changed = $true
        Reason  = ('{0}: normalized to classic layout ({1})' -f $Label, $profile.Reason)
        Profile = $profile
    }
}

