# IPTCompile v1.3.0 phase 4 safe refactor

Detta paket bygger på originalprojektet och gör endast låg-risk-refactor:

- Funktioner (endast definitioner) flyttade från `Main.ps1` till `App/*.ps1`
- `Modules/Logging.ps1` omvandlad till shim som dot-sourcar:
  - `Infrastructure/LoggingCore.ps1`
  - `App/UiLogging.ps1`
- Ingen top-level WinForms/eventkod har flyttats ut från `Main.ps1`
- `Modules/*` behålls som runtime-entrypoints för kompatibilitet

## Flyttade funktioner ur Main.ps1

### App/UiHelpers.ps1
- New-ListRow
- Set-ClbWatermark
- Show-ClbWatermark
- Hide-ClbWatermark
- Add-CLBItems
- Get-CheckedFilePath
- Get-AllCheckedFilePaths
- Clear-GUI
- Get-SelectedFileCount
- Update-StatusBar
- Invoke-UiPump
- Set-UiBusy
- Set-UiStep
- Update-BuildEnabled
- Update-OverwriteVerificationUI
- Enable-DoubleBuffer

### App/Bootstrap.ps1
- Get-UserProfileFromConfig
- Apply-UserDefaults
- Assert-StartupReady
- Assert-DevUnlocked

### App/UiDialogs.ps1
- Show-StyledInfoDialog
- Show-ListSelectionDialog
- Show-ProjectStatusDialog
- Show-FileMoveSelectionDialog
- Show-CloseFileToContinueDialog
- Ensure-FilesClosedOrCancel

### App/BuildController.ps1
- Get-BatchLinkInfo
- Find-LspFolder
- Get-DefaultDownloadsPath
- Get-DownloadsPathEffective
- Get-LspDigitsFromString
- Get-UniqueDestinationPath
- Get-ProjectStatusData
- Move-DownloadedLspFiles
- Invoke-ExternalScript

### App/UiTheme.ps1
- Set-Theme

## Logging split

`Modules/Logging.ps1` är nu en shim. Den publika beteendeytan behålls, men implementeringen delas upp i:

- `Infrastructure/LoggingCore.ps1`
- `App/UiLogging.ps1`

## Avsiktlig begränsning

Ingen parser-risky klippning gjordes i:

- top-level `.Add_Click(...)`
- `.Controls.Add(...)`
- `Application.Run(...)`
- `DataHelpers.ps1`
- `SignatureHelpers.ps1`
- `RuleEngine.ps1`
- `OpenXmlHelpers.ps1`

Detta är en säker fas 4, inte en aggressiv omstrukturering.
