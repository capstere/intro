# Safe refactor notes

Den tidigare trasiga refactoren gick sönder därför att top-level runtime-kod klipptes ut till dot-sourcade filer.

I denna version har endast hela, verifierade funktionsdefinitioner flyttats. All top-level UI/eventkod lämnas kvar i `Main.ps1`.
