try { Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop } catch { }

function Test-HasGetConfigValue {
    try {
        if ($script:__HasGetConfigValue) { return $true }
    } catch {}

    try {
        $cmd = Get-Command Get-ConfigValue -ErrorAction SilentlyContinue
        if ($cmd) {
            $script:__HasGetConfigValue = $true
            return $true
        }
    } catch {}

    return $false
}


function Get-SafeFileNameComponent {
    param(
        [string]$Value,
        [string]$Default = 'NA'
    )

    $s = ($Value + '').Trim()
    if (-not $s) { return $Default }

    foreach ($ch in [System.IO.Path]::GetInvalidFileNameChars()) {
        $s = $s.Replace([string]$ch, '_')
    }

    $s = [regex]::Replace($s, '\s+', ' ').Trim()
    if (-not $s) { return $Default }
    return $s
}


function Add-AuditEntry {
    param(
        [string]$Lsp,
        [string]$Assay,
        [string]$BatchNumber,
        [int]$TestCount,
        [string]$Status,
        [string]$ReportPath,
        [string]$AuditDir,
        [int]$TotalMs = 0,
        [string]$PhaseJson = ''
    )

    try {
        if (-not $AuditDir) {
            $netRootForAudit = ($env:IPT_NETWORK_ROOT + '').Trim()

            if ($netRootForAudit -and (Test-Path -LiteralPath $netRootForAudit)) {
                $AuditDir = Join-Path $netRootForAudit 'audit'
            }
            elseif ($PSScriptRoot) {
                $AuditDir = Join-Path $PSScriptRoot 'audit'
            }
            else {
                $AuditDir = Join-Path $env:TEMP 'audit'
            }
        }

        if (-not (Test-Path -LiteralPath $AuditDir)) {
            New-Item -ItemType Directory -Path $AuditDir -Force | Out-Null
        }

        $date = (Get-Date).ToString('yyyyMMdd')
        $safeUser = Get-SafeFileNameComponent -Value $env:USERNAME -Default 'User'
        $safeLsp  = Get-SafeFileNameComponent -Value $Lsp -Default 'NA'
        $file = Join-Path $AuditDir ("Audit_{0}_{1}_{2}.csv" -f $date, $safeUser, $safeLsp)

        $row = [pscustomobject]@{
            Timestamp  = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
            Username   = $env:USERNAME
            LSP        = $Lsp
            Assay      = $Assay
            Batch      = $BatchNumber
            TestCount  = $TestCount
            Status     = if ($Status) { $Status } else { 'OK' }
            ReportPath = $ReportPath
            TotalMs = $TotalMs
            TotalSec = [math]::Round($TotalMs / 1000, 1)
            PhaseJson = $PhaseJson
        }
				
        $exists = Test-Path -LiteralPath $file
        if ($exists) {
            $row | Export-Csv -LiteralPath $file -NoTypeInformation -Append -Encoding UTF8
        }
        else {
            $row | Export-Csv -LiteralPath $file -NoTypeInformation -Encoding UTF8
        }
    }
    catch {
        Gui-Log -Text "Kunde inte skriva audit-fil: $($_.Exception.Message)" -Severity 'Warn' -Category 'AUDIT'
    }
}


function Write-StructuredLog {
    param(
        [string]$Message,
        [ValidateSet('Info','Warn','Error')][string]$Severity = 'Info',
        [string]$Category = 'General',
        [hashtable]$Context
    )

    if (-not $global:LogPath) { return }
		
    $jsonPath = $null
    try {
        if ($global:StructuredLogPath) {
            $jsonPath = $global:StructuredLogPath
        } else {
            $jsonPath = "$($global:LogPath).jsonl"
        }
    }
    catch {
        $jsonPath = "$($global:LogPath).jsonl"
    }

    $entry = [ordered]@{
        Timestamp = (Get-Date).ToString('o')
        Severity  = $Severity
        Category  = $Category
        Message   = $Message
    }

    if ($Context) {
        foreach ($k in $Context.Keys) {
            $entry[$k] = $Context[$k]
        }
    }

    try {
        Add-Content -LiteralPath $jsonPath -Value ($entry | ConvertTo-Json -Compress) -Encoding UTF8
    }
    catch {

    }
}

