function Get-UserProfileFromConfig {
    param([hashtable]$Config)

    $u = (($env:USERNAME + '').Trim()).ToLowerInvariant()
    if (-not $u) { return $null }

    $users = $null
    try { $users = $Config.Users } catch { $users = $null }

    if ($users -and ($users -is [System.Collections.IDictionary]) -and $users.Contains($u)) {
        $p = $users[$u]
        return [pscustomobject]@{
            Username         = $u
            FullName         = (($p.FullName + '').Trim())
            SealTestInitials = (($p.SealTestInitials + '').Trim())
        }
    }
    return $null
}


function Apply-UserDefaults {
    try {
        if (-not $script:UserProfile) { $script:UserProfile = Get-UserProfileFromConfig -Config $Config }
        $p = $script:UserProfile
        if (-not $p) { return }

        # Sammanställning: Full Name + Seal Test initialer
        if ($txtSammName -and -not (($txtSammName.Text + '').Trim())) { $txtSammName.Text = $p.FullName }
        if ($txtSealTestSign -and -not (($txtSealTestSign.Text + '').Trim())) { $txtSealTestSign.Text = $p.SealTestInitials }

        # Granskning: Full Name
        if ($txtGranskName -and -not (($txtGranskName.Text + '').Trim())) { $txtGranskName.Text = $p.FullName }
    } catch {}
}


function Assert-StartupReady {
    if ($global:StartupReady) { return $true }
    Gui-Log "❌ Startkontroll misslyckades. Åtgärda konfigurationsfel innan du fortsätter." 'Error'
    return $false
}


function Assert-DevUnlocked {
    if ($script:DevUnlocked) { return $true }

    $pwd = $null
    try {
        $pwd = [Microsoft.VisualBasic.Interaction]::InputBox(
            "TEST-knappen är låst.`nAnge lösenord för att låsa upp (session):",
            'Utvecklarlås',
            ''
        )
    } catch {
        try {
            [System.Windows.Forms.MessageBox]::Show(
                "Kunde inte visa lösenordsruta. TEST avbröts.",
                'Utvecklarlås',
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Warning
            ) | Out-Null
        } catch {}
        return $false
    }

    if (($pwd + '') -eq $script:DevUnlockPassword) {
        $script:DevUnlocked = $true
        try { Gui-Log "🔓 TEST upplåst för denna session." 'Info' } catch {}
        return $true
    }

    try {
        [System.Windows.Forms.MessageBox]::Show(
            'Fel lösenord. TEST avbröts.',
            'Utvecklarlås',
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Information
        ) | Out-Null
    } catch {}
    return $false
}

