try { Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop } catch { }
$__iptProjectRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $__iptProjectRoot 'Infrastructure/LoggingCore.ps1')
. (Join-Path $__iptProjectRoot 'App/UiLogging.ps1')
