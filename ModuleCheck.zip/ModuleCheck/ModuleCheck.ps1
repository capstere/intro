

Clear-Host

Write-Host "Checkar om Nuget och PnP Powershell finns..."



    $null = Get-PackageProvider -Name "NuGet" -ForceBootstrap




try{

    import-module PnP.PowerShell -ErrorAction Stop
    

}catch{

    cls

    Write-Host "PnP ej hittad, installerar. Detta kan ta någon minut"
 
    Install-Module pnp.powershell -MaximumVersion 1.12.0 -Scope CurrentUser -Force

    Import-Module PnP.PowerShell
}

cls
Write-Host "Loggar in till Sharepoint...."

#$username = "Labuser_ipt@cepheid.com"

#$secpass = ConvertTo-SecureString -String $password -AsPlainText -Force

#$secpass = Import-Clixml -Path "N:\QC\QC-1\IPT\Skiftspecifika dokument\Skift 1\Mahdi\powerpoint\AutoMappscript\cred.cred"

#$key = Get-Content "N:\QC\QC-1\IPT\Skiftspecifika dokument\Skift 1\Mahdi\powerpoint\AutoMappscript\key.key"

#[PSCredential]$creds = New-Object System.Management.Automation.PSCredential -ArgumentList $username, ($secpass | ConvertTo-SecureString -Key $key)

#$creds = Import-Clixml -Path "N:\QC\QC-1\IPT\Skiftspecifika dokument\Skift 1\Mahdi\powerpoint\AutoMappscript\cred.cred"

$env:PNPPOWERSHELL_UPDATECHECK = "Off"

Connect-PnPOnline -Url https://danaher.sharepoint.com/sites/CEPSwedenCalibrationandMaintenance -ClientId "23715695-a9a6-4f32-af7b-4cd164e0f1f9" -Interactive #-Credentials $creds

$list = Get-PnPList -Identity "Solna Modules"

$items = Get-PnPListItem -List $list


Start-Sleep 2

cls


$selection = Read-host 'Välj vilken typ av fel du vill se

1. Instrumentfel

2. Funktionella fel 

3. Både instrumentfel och funktionella fel

'

cls

$instrumentreference = @{}

Get-Content 'N:\QC\QC-1\IPT\Skiftspecifika dokument\Skift 1\Mahdi\data\instrumentref.txt' | ForEach-Object{$keyvalue = $_.split('	'); $instrumentreference[$keyvalue[0]] = $keyvalue[1]}

$count = $items.Count
$i = 0

cls

foreach($item in $items){

    $Status = $item.FieldValues.Status
    $SNnr = $item.FieldValues.Title
    $Module = $item.FieldValues.Module_x0020_Placve

    Write-Progress -Activity "Hämtar Modul: $($Module)" -Status "$(([math]::Round((($i)/$count * 100),0))) %" -PercentComplete (100*$i/$count)

    $instrumentreference[[string]$SNnr] = "$([string]$Module) - SN: $($SNnr) - Status:$($Status) "
    $i++
}

$errorlist = @(

"2005"
"2006"
"2025"
"2014"
"1001"
"2035"
"1018"
"1002"
"2026"
"2126"
"2022"
"2032"


)

$rederrorlist= @(

"1001"
"1002"
"2014"

)

$mappar = @('N:\QC\QC-1\IPT\2. IPT - PÅGÅENDE KÖRNINGAR','N:\QC\QC-1\IPT\3. IPT - KLART FÖR SAMMANSTÄLLNING','N:\QC\QC-1\IPT\4. IPT - KLART FÖR GRANSKNING',
    'N:\QC\QC-1\IPT\5. IPT - AVSLUTADE KÖRNINGAR, KVAR ATT TESTA','N:\QC\QC-1\IPT\6. IPT - RESAMPLING\RESAMPLING Delamination','N:\QC\QC-1\IPT\6. IPT - RESAMPLING\RESAMPLING Functional',
    'N:\QC\QC-1\IPT\6. IPT - RESAMPLING\RESAMPLING Visual')

$lots = @()
$testsummaries = @()

foreach($mapp in $mappar){

    $lots += $mapp | Get-ChildItem -ErrorAction Stop  | Where-Object{$_ -like "*#*" -and $_.PSiscontainer}

}

foreach($lot in $lots){
    
    try{
            
        $testsummaries += $lot | Get-ChildItem -ErrorAction Stop | Where-Object{$_ -like "*Summary*"}

    }catch{
        

        Write-Host "Kunde inte öppna $lot. Kolla om den är låst eller är ej tillgänglig "

        continue

    }
    
}



 #Get-Content 'N:\QC\QC-1\IPT\Skiftspecifika dokument\Skift 1\Mahdi\data\errors.txt'
<#
    $testsummaries = try{('N:\QC\QC-1\IPT\2. IPT - PÅGÅENDE KÖRNINGAR' | Get-ChildItem -ErrorAction Stop | Where-Object{$_ -notlike '*S.Dokument*' -and $_.PSiscontainer}) | Get-ChildItem -ErrorAction Stop | Where-Object{$_ -like "*Tests Summary*"}}catch{write-host "Kunde ej hämta test summaries, kolla om en eller flera mappar i IPT-PÅGÅENDE är låsta"; Start-Sleep 2}
    $testsummaries += try{('N:\QC\QC-1\IPT\3. IPT - KLART FÖR SAMMANSTÄLLNING' | Get-ChildItem -ErrorAction Stop | Where-Object{$_ -like "*#*" -and $_.PSiscontainer}) | Get-ChildItem -ErrorAction Stop | Where-Object{$_ -like "*Summary*"}}catch{write-host "Kunde ej hämta test summaries, kolla om en eller flera mappar i IPT-SAMMANSTÄLLNING är låsta"}
    $testsummaries += try{('N:\QC\QC-1\IPT\4. IPT - KLART FÖR GRANSKNING' | Get-ChildItem -ErrorAction Stop | Where-Object{$_ -like '*#*' -and $_.PSiscontainer}) | Get-ChildItem -ErrorAction Stop | Where-Object{$_ -like "*Summary*"}}catch{write-host "Kunde ej hämta test summaries, kolla om en eller flera mappar i IPT-GRANSKNING är låsta"}
    $testsummaries += try{('N:\QC\QC-1\IPT\5. IPT - AVSLUTADE KÖRNINGAR, KVAR ATT TESTA' | Get-ChildItem -ErrorAction Stop | Where-Object{$_ -like '*#*' -and $_.PSiscontainer}) | Get-ChildItem -ErrorAction Stop | Where-Object{$_ -like "*Summary*"}}catch{write-host "Kunde ej hämta test summaries, kolla om en eller flera mappar i IPT-AVSLUTADE är låsta"}
    $testsummaries += try{('N:\QC\QC-1\IPT\6. IPT - RESAMPLING\RESAMPLING Delamination' | Get-ChildItem -ErrorAction Stop | Where-Object{$_ -like '*#*' -and $_.PSiscontainer}) | Get-ChildItem -ErrorAction Stop | Where-Object{$_ -like "*Summary*"}}catch{write-host "Kunde ej hämta test summaries, kolla om en eller flera mappar i  RESAMPLING\RESAMPLING Delamination är låsta"}
    $testsummaries += try{('N:\QC\QC-1\IPT\6. IPT - RESAMPLING\RESAMPLING Functional' | Get-ChildItem -ErrorAction Stop | Where-Object{$_ -like '*#*' -and $_.PSiscontainer}) | Get-ChildItem -ErrorAction Stop | Where-Object{$_ -like "*Summary*"}}catch{write-host "Kunde ej hämta test summaries, kolla om en eller flera mappar i  RESAMPLING\RESAMPLING Functional är låsta"}
    $testsummaries += try{('N:\QC\QC-1\IPT\6. IPT - RESAMPLING\RESAMPLING Visual' | Get-ChildItem -ErrorAction Stop | Where-Object{$_ -like '*#*' -and $_.PSiscontainer}) | Get-ChildItem -ErrorAction Stop | Where-Object{$_ -like "*Summary*"}}catch{write-host "Kunde ej hämta test summaries, kolla om en eller flera mappar i  RESAMPLING\RESAMPLING Visual är låsta"}
    #>
$count = $testsummaries.Count
$i = 0

$rawfailedtests = $testsummaries | ForEach-Object{Write-Progress -Activity "Hämtar $($_)" -Status "$(([math]::Round((($i)/$count * 100),0))) %" -PercentComplete (100*$i/$count);Get-Content -Path $_.FullName | Select-Object -Skip 8 | Where-Object{$_ -like '*Error*'}; $i++}

$failedtests = $rawfailedtests | ForEach-Object{ $_ | ConvertFrom-String -Delimiter ','}

$dupecheck = @{}

foreach($failed in $failedtests){

    if(!($dupecheck.ContainsKey($failed.P4))){
    
        $dupecheck[$failed.P4] = $failed
    }
}

$failedtests = $dupecheck.Values


$instrumentlist = @{}

$failedtests | ForEach-Object{

    $InstNr = $instrumentreference[[string]$_.P7]

    $ModuleNr = $instrumentreference[[string]$_.P8]

    if(!$ModuleNr){$ModuleNr = $_.P8}

    foreach($key in $_.PSObject.Properties){

        $value = [string]$key.Value
        
        if($Value -like "*Error*" -and $value.Length -gt 5){

            $value = ($value.Replace(" ","")).Replace('"','')

            if( ($value.Substring(0,$value.IndexOf("Error"))).Length -gt 0 ){

                $value = $value.Replace(($value.Substring(0,$value.IndexOf("Error"))),"")
            }
            
            $errorcode = ($value.Substring(0,$value.IndexOf(":"))).Replace("Error", "")

            if($errorcode -notin $errorlist -and $selection -eq 1){continue}
            if($errorcode -in $errorlist -and $selection -eq 2){continue}

            if($instNr -notin $instrumentlist.Keys){

                $instrumentlist += @{$instnr = @{}}

            }

            if(!(($instrumentlist[$instnr]).ContainsKey($ModuleNr))){
            
                ($instrumentlist[$instnr]) += @{$ModuleNr = @{}}
            
            }

            (($instrumentlist[$instnr])[$ModuleNr])[$errorcode]++   

        } 
    }
}

cls

if($instrumentlist.Count -eq 0){
    
    Write-Host ''
    switch($selection){1{Write-Host 'Inga moduler har fått instrumentfel under de pågående loterna' -ForegroundColor Green}; 2{Write-Host 'Inga moduler har fått funktionella fel under de pågående loterna' -ForegroundColor Green}3{Write-Host 'Inga moduler har fått funktionella/instrument fel under de pågående loterna' -ForegroundColor Green}}
    Write-Host ''

}else{

    foreach($instrumentkey in $instrumentlist.Keys){

        foreach($instrumentvalues in $instrumentlist[$instrumentkey]){

            Write-Host $instrumentkey -nonewline -ForegroundColor White -BackgroundColor DarkGreen ; write-host ':'
            Write-host ''
            
            #Write-Host $instrumentvalues

            #$instrumentvalues | %{$_.keys;$_.values}

            

            foreach($rawmodules in $instrumentvalues.GetEnumerator()){

                $modules = $rawmodules.key

                #Write-Host "`t$modules"
                try{

                    $Statusname = (($modules).Substring(($modules).IndexOf('Status:') + 7)).TrimEnd()
                    $cutmodulename = $modules -replace $Statusname, ''

                    Write-host "`tModule $cutmodulename" -NoNewline

                }catch{
                    
                    $statusname = $null
                    $cutmodulename = $modules
                    Write-host "`tModule $cutmodulename FINNS EJ I SHAREPOINT " -NoNewline
                }
                

                if($Statusname -eq 'H/W Fail' -or $Statusname -eq 'Automation Failure'){
                    Write-host $Statusname -ForegroundColor Red -NoNewline; #Write-Host ':' -NoNewline
                }

                elseif($statusname -eq 'Disabled'){write-host $Statusname -ForegroundColor Yellow -NoNewline; #Write-Host ':' -NoNewline
                }
                else{write-host $Statusname -ForegroundColor Green -NoNewline; #Write-Host ':' -NoNewline
                }
            
                #$rawmodules.Value.Count
                $number = $null
                $text = $null
                #$test += $rawmodules | %{$_.Value} | %{$_.Values} | Select

                #$number = $rawmodules.Value.Count

                $rederror = $false


                ($rawmodules.Value.GetEnumerator()) | %{$number += $_.Value; if($_.Name -in $rederrorlist){$rederror = $true}}

                $text = "Total: " + $number

                if((($rederror) -and $Statusname -eq "Available")){Write-host ' '"Total: " -NoNewline;Write-Host $number -ForegroundColor Red}
                elseif($number -gt 2 -and ($Statusname -eq "Available")){Write-host ' '"Total: " -NoNewline;Write-Host $number -ForegroundColor Red}else{Write-Host ' '$text}

                if($rawmodules.value.Count -ge 2){
                
                
                
                    (($rawmodules.value).GetEnumerator()) | %{
                        write-host ""

                        $vals = $_.value
                        $keys = $_.Key
                        $keys = "E" + $keys

                        write-host "`t`t" -NoNewline

                        #if($vals -gt 2){write-host "$($vals)x" -ForegroundColor Red -NoNewline; Write-Host ""$keys}else{write-host "$($vals)x"$keys}
                        if( (($keys).Replace("E","")) -in $rederrorlist -and $Statusname -eq "Available" ){write-host "$($vals)x" -ForegroundColor Red -NoNewline; Write-Host ""$keys}
                        elseif($vals -gt 2 -and $Statusname -eq "Available"){write-host "$($vals)x" -ForegroundColor Red -NoNewline; Write-Host ""$keys}else{write-host "$($vals)x"$keys}

                    
                    }
                
                    Write-Host ""

                }elseif($rawmodules.Value.Count -lt 2){

                    foreach($errorcode in $rawmodules){
            
                        write-host ""

                        #($rawmodules.Value).Count

                        $rawmodules.Value | %{

                            $vals = $_.values
                            $keys = $_.Keys
                            $keys = "E" + $keys

                            write-host "`t`t" -NoNewline

                            #if($vals -gt 2){write-host "$($vals)x" -ForegroundColor Red -NoNewline; Write-Host ""$keys}else{write-host "$($vals)x"$keys}
                            if( (($keys).Replace("E","")) -in $rederrorlist -and $Statusname -eq "Available" ){write-host "$($vals)x" -ForegroundColor Red -NoNewline; Write-Host ""$keys}
                            elseif($vals -gt 2 -and $Statusname -eq "Available"){write-host "$($vals)x" -ForegroundColor Red -NoNewline; Write-Host ""$keys}else{write-host "$($vals)x"$keys}
                    
                        }
            
                        write-host ""
            
                    }
                
                }


            }

            

            Write-Host '' 
        }

    }
}


$newline = "{0}, {1}" -f [System.Environment]::UserName, (Get-Date).ToString()

$newline | Add-Content -Path "N:\QC\QC-1\IPT\Skiftspecifika dokument\Skift 1\Mahdi\data\modulelog.csv"
