﻿@{
    LastUpdated = '2026-03-24'

    Notes = @(
        'Upptäcker du något som är knas eller kan bli bättre?'
        'Skriv på teams eller skicka meddelande under "Instruktioner → Hjälp"'
	'Det är dina idéer och behov som formar verktyget. :) / Jesper'

    )

    Done = @(
        'Uppdaterat nycklar för att separera OVENSNEG och OVENSPOS'
    )

    Ongoing = @(
        'Bygga Power App'
        'Samla feedback'

    )

    TBD = @(
        'Konvertera all utrustning och material till Power Apps - SharePoint'
        'Dra-och-släpp implementerat för alla filer - KLART - men ej IT-PASS'
    )

}