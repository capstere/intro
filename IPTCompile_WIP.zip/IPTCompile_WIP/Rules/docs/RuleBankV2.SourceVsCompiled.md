# RuleBank v2: Source Schema vs Compiled Schema

## Goal

RuleBank v2 source is designed for human maintenance.

Compiled output is designed for current runtime compatibility.

That means the source schema is intentionally stricter and more typed than the compiled schema.

## Canonical source location

- `/Users/jesperfredriksson/Desktop/IPTCompile-LANSERING/IPTCompile-LANSERING/IPTCompile_20260310/IPTCompile-v1.4.0-consolidated/Rules/Source/RuleBank.meta.psd1`
- `/Users/jesperfredriksson/Desktop/IPTCompile-LANSERING/IPTCompile-LANSERING/IPTCompile_20260310/IPTCompile-v1.4.0-consolidated/Rules/Source/ResultCallPatterns.psd1`
- `/Users/jesperfredriksson/Desktop/IPTCompile-LANSERING/IPTCompile-LANSERING/IPTCompile_20260310/IPTCompile-v1.4.0-consolidated/Rules/Source/ErrorCodes.psd1`
- `/Users/jesperfredriksson/Desktop/IPTCompile-LANSERING/IPTCompile-LANSERING/IPTCompile_20260310/IPTCompile-v1.4.0-consolidated/Rules/Source/SampleExpectationRules.psd1`
- `/Users/jesperfredriksson/Desktop/IPTCompile-LANSERING/IPTCompile-LANSERING/IPTCompile_20260310/IPTCompile-v1.4.0-consolidated/Rules/Source/SampleIdMarkers.psd1`
- `/Users/jesperfredriksson/Desktop/IPTCompile-LANSERING/IPTCompile-LANSERING/IPTCompile_20260310/IPTCompile-v1.4.0-consolidated/Rules/Source/ParityCheckConfig.psd1`
- `/Users/jesperfredriksson/Desktop/IPTCompile-LANSERING/IPTCompile-LANSERING/IPTCompile_20260310/IPTCompile-v1.4.0-consolidated/Rules/Source/SampleNumberRules.psd1`
- `/Users/jesperfredriksson/Desktop/IPTCompile-LANSERING/IPTCompile-LANSERING/IPTCompile_20260310/IPTCompile-v1.4.0-consolidated/Rules/Source/TestTypePolicy.psd1`
- `/Users/jesperfredriksson/Desktop/IPTCompile-LANSERING/IPTCompile-LANSERING/IPTCompile_20260310/IPTCompile-v1.4.0-consolidated/Rules/Source/MissingSamplesConfig.legacy.psd1`

There is deliberately no `QuantSpecRules` source file.

Edit `Rules/Source/*`; do not hand-edit compiled output except for emergency diagnostics.

## Type policy

Source schema uses real types where possible:

- `Enabled = $true/$false`
- `Priority = 1234`
- min/max/token indexes = integers
- `AllowedTestTypes = @('A','B')`

Compiled schema keeps runtime-compatible strings:

- `Enabled = 'TRUE'/'FALSE'`
- `Priority = '1234'`
- numeric fields as strings
- `AllowedTestTypes = 'A|B'`

## Naming policy

Source schema standardizes on:

- `AssayPattern`
- `MatchType`
- `Pattern`
- `ExpectedCall`
- `Notes`

Compiled schema maps back to runtime names where needed:

- `AssayPattern` -> `Assay` for `ResultCallPatterns`
- `AssayPattern` -> `Assay` for `SampleExpectationRules`
- `ExpectedCall` -> `Expected`
- `Notes` -> `Note` or `Notes` depending on legacy table
- `TokenSampleIdSplitIndex` -> `Token_SampleID_SplitIndex`

## Metadata fields available in source only

The following fields exist for maintenance and validation, not for current runtime consumption:

- `RuleId`
- `Version`
- `Source`
- `LastUpdated`
- `Notes`
- `CaseInsensitive`
- `StopProcessing`

Current compiler does not require runtime changes to support them.

## QuantSpecRules policy

RuleBank v2 source does not model `QuantSpecRules`.

Compiler behavior:

- emits `QuantSpecRules = @()` into compiled output
- marks metadata with `QuantSpecRulesStatus = 'legacy-empty-compiled-placeholder'`

Reason:

- current runtime still expects the table to exist structurally
- active decision logic does not consume it
- Data Summary logic already covers the domain area that would otherwise risk duplication

## MissingSamplesConfig policy

`MissingSamplesConfig` remains present only as a legacy source table.

Reason:

- it is part of current load surface
- no active runtime decision logic currently consumes it
- keeping it isolated as `MissingSamplesConfig.legacy.psd1` makes the legacy status explicit without breaking compatibility

## Safe next step after v2 adoption

1. Maintain `Rules/Source` as the only human-edited source of truth.
2. Build `/Rules/RuleBank.compiled.ps1` from source.
3. Keep runtime consuming `/Rules/RuleBank.compiled.ps1` as the canonical compiled artifact.
4. Remove `QuantSpecRules` from runtime load/integrity only in a later change after Windows PowerShell 5.1 verification.

## Release-safe build behavior

`Rules/Build-RuleBank.ps1` now writes:

- `/Rules/RuleBank.compiled.ps1`

Reason:

- app runtime now points at `/Rules/RuleBank.compiled.ps1`
- the old mirror is no longer needed for normal runtime
