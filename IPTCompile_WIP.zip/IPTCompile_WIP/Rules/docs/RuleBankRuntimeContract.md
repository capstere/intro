# RuleBank Runtime Contract

This document describes the current runtime contract in `/Users/jesperfredriksson/Desktop/IPTCompile-LANSERING/IPTCompile-LANSERING/IPTCompile_20260310/IPTCompile-v1.4.0-consolidated`.

## Actual runtime path

Canonical compiled RuleBank path is `/Users/jesperfredriksson/Desktop/IPTCompile-LANSERING/IPTCompile-LANSERING/IPTCompile_20260310/IPTCompile-v1.4.0-consolidated/Rules/RuleBank.compiled.ps1`.

`Modules/Config.ps1` points runtime directly at `Rules/`. `RuleBank/RuleBank.compiled.ps1` is no longer part of the active runtime path.

## Top-level keys in current compiled artifact

- `Meta`
- `ResultCallPatterns`
- `TestTypePolicy`
- `QuantSpecRules`
- `ParityCheckConfig`
- `ErrorCodes`
- `SampleIdMarkers`
- `MissingSamplesConfig`
- `SampleNumberRules`
- `SampleExpectationRules`

`Load-RuleBank` requires all active tables below to exist. `Meta` is tolerated but not used by runtime logic.

## Priority semantics

Higher numeric priority wins.

Current runtime sorts these tables descending by `Priority` before evaluation:

- `ResultCallPatterns`
- `SampleExpectationRules`
- `ParityCheckConfig`
- `SampleIdMarkers`
- `SampleNumberRules`
- `TestTypePolicy`

This means the runtime uses "first match after descending sort" semantics.

## Enabled semantics

Current runtime treats rules as enabled unless `Enabled` is explicitly one of:

- `FALSE`
- `0`
- `NO`
- `N`

Blank or missing `Enabled` is interpreted as enabled.

## Assay vs AssayPattern

Current runtime uses mixed field names in compiled rows.

- `ResultCallPatterns`: `Assay`
- `SampleExpectationRules`: `Assay`
- `SampleIdMarkers`: `AssayPattern`
- `ParityCheckConfig`: `AssayPattern`
- `SampleNumberRules`: `AssayPattern`
- `TestTypePolicy`: `AssayPattern`
- `MissingSamplesConfig`: `AssayPattern`
- `QuantSpecRules`: `AssayPattern`

Matching is done by `Test-AssayMatch` and supports:

- blank or `*` = match all
- wildcard match when the rule contains `*` or `?`
- exact case-insensitive equality
- cautious contains fallback for longer assay strings

## MatchType variants actually supported by runtime

`Match-TextFast` currently supports:

- `CONTAINS`
- `EQUALS`
- `PREFIX`
- `SUFFIX`
- `REGEX`

Observed in current compiled rows:

- `ResultCallPatterns`: `CONTAINS`, `EQUALS`, `REGEX`
- `SampleExpectationRules`: `PREFIX`, `REGEX`

## Compiled field types

Current runtime consumes strings in compiled rows, including:

- `Enabled`
- `Priority`
- numeric min/max fields
- token indexes

That is why RuleBank v2 keeps a stricter typed source schema but still exports strings in compiled rows.

## Field classification by table

### ResultCallPatterns

- required: `Assay`, `Call`, `MatchType`, `Pattern`, `Enabled`, `Priority`
- optional: `Note`
- legacy: none found
- apparently unused: none found

### SampleExpectationRules

- required: `Assay`, `SampleIdMatchType`, `SampleIdPattern`, `Expected`, `Enabled`, `Priority`
- optional: `Note`
- legacy: none found
- apparently unused: none found

### ErrorCodes

- required: `ErrorCode`, `Name`, `GeneratesRetest`
- optional: none
- legacy: none found
- apparently unused: none found

### SampleIdMarkers

- required: `AssayPattern`, `MarkerType`, `Marker`, `Enabled`
- optional: `Note`, `Priority`
- legacy: none found
- apparently unused: `SampleTokenIndex`

### ParityCheckConfig

- required: `AssayPattern`, `Enabled`, `CartridgeField`, `SampleTokenIndex`, `SuffixX`, `SuffixPlus`, `MinValidCartridgeSNPercent`, `Priority`
- optional: `Note`, `DelaminationMarkerType`
- legacy: none found
- apparently unused: none found

### SampleNumberRules

- required: `AssayPattern`, `SampleTypeCode`, `BagNoPattern`, `SampleNumberTokenIndex`, `SampleNumberRegex`, `SampleNumberMin`, `SampleNumberMax`, `SampleNumberPad`, `Enabled`, `Priority`
- optional: `Note`
- legacy: none found
- apparently unused: none found

### TestTypePolicy

- required: `AssayPattern`, `AllowedTestTypes`, `Enabled`, `Priority`
- optional: `Note`
- legacy: `AssayFamily`
- apparently unused: no active runtime read of `AssayFamily` was found

### MissingSamplesConfig

- required: none beyond load/integrity surface
- optional: none in active decision logic
- legacy: whole table
- apparently unused: whole table in current runtime logic

### QuantSpecRules

- required: only for current load/integrity surface
- optional: runtime tolerates extra columns after normalization
- legacy: whole table
- apparently unused: no active decision loop consumes QuantSpecRules in current runtime logic

### Meta

- required: none
- optional: `Counts`, `GeneratedOn`, `SourceHash`
- legacy: metadata only
- apparently unused: whole table in current runtime logic

## QuantSpecRules assessment

RuleBank v2 source intentionally excludes `QuantSpecRules`.

Reason:

- current runtime still requires the table to exist during load/integrity checks
- no active classification logic currently iterates over `RuleBank.QuantSpecRules`
- related Data Summary handling already lives outside RuleBank

Safe transition plan:

1. v2 source has no QuantSpec source file
2. compiler emits `QuantSpecRules = @()` as a legacy placeholder
3. runtime keeps loading successfully
4. a later controlled change may remove `QuantSpecRules` from `Load-RuleBank` integrity requirements once Windows/runtime verification is complete

## Delamination note

Do not duplicate Data Summary evidence logic in RuleBank.

The current project already implements the domain rule outside RuleBank:

- `Data Summary`
- `Resample Data Summary`
- `Extra Data Summary`

If `DELAMINATION` appears in column C on those sheets, the output path promotes that evidence to `Minor Functional (Delamination)` separately from RuleBank.
