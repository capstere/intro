# RuleBank i korthet

Det här är den enkla modellen:

- Du **redigerar** regler i `Rules/Source/*`
- Du **bygger** en körbar regelbank till `Rules/RuleBank.compiled.ps1`
- Själva appen **kör** på `Rules/RuleBank.compiled.ps1`

`RuleBank/RuleBank.compiled.ps1` är pensionerad i denna version.

## Vad är vad?

### 1. Det du redigerar

Det här är källan:

- `Rules/Source/*.psd1`

Det är här framtida regelunderhåll ska ske.

Redigera **inte** `Rules/RuleBank.compiled.ps1` för vanlig utveckling.

### 2. Det appen faktiskt använder

Det här är körfilen:

- `Rules/RuleBank.compiled.ps1`

Det är den filen som runtime läser in.

## Vanligt arbetssätt

Det normala arbetssättet är:

1. Ändra regler i `Rules/Source/*.psd1`
2. Kör `Rules/Validate-RuleBank.ps1`
3. Kör `Rules/Build-RuleBank.ps1`
4. Kör `Rules/Test-RuleBankV2.ps1`

Det betyder i praktiken:

- `Validate` kontrollerar att källfilerna ser rimliga ut
- `Build` bygger den körbara filen
- `Test` jämför utfallet mot kända testfall

## Viktigt att förstå

### Appen behöver inte hela `Rules/`

För vanlig körning behöver appen bara:

- `Rules/RuleBank.compiled.ps1`

Resten i `Rules/` är till för utveckling, byggning, validering, test och dokumentation.

### Build skriver bara körfilen

`Rules/Build-RuleBank.ps1` bygger nu:

- `Rules/RuleBank.compiled.ps1`

## Vilka filer är aktiva och varför?

| Fil eller mapp | Vad den används till | Status |
| --- | --- | --- |
| `Rules/RuleBank.compiled.ps1` | Den körbara RuleBank som appen använder | aktiv runtime |
| `Rules/Source/*` | Regler du underhåller | aktiv källa |
| `Rules/Build-RuleBank.ps1` | Bygger körfilen | aktiv build |
| `Rules/Validate-RuleBank.ps1` | Kontrollerar att källan är sund | aktiv validering |
| `Rules/Test-RuleBankV2.ps1` | Kör golden cases | aktiv test |
| `Rules/tests/GoldenCases.psd1` | Lista över testfall | aktiv testdata |
| `Rules/Analyze-RuleBankRuntime.ps1` | Hjälper till att förstå runtime-kontraktet | aktiv analys |
| `Rules/RuleBankV2.Common.ps1` | Gemensamma hjälpfunktioner för build/test/validate | aktiv buildhjälp |
| `Rules/Initialize-RuleBankV2Source.ps1` | Engångsverktyg för att seeda source-filer | scaffolding |

## QuantSpecRules

Status:

- `required legacy placeholder`

Det betyder:

- `QuantSpecRules` finns **inte** som egen source-fil i `Rules/Source`
- compiled-filen innehåller ändå en tom plats för den, för att nuvarande runtime fortfarande förväntar sig strukturen

Du ska alltså inte återinföra QuantSpec som aktiv source-design.

## DELAMINATION

Logiken för `DELAMINATION` ligger fortfarande **utanför** RuleBank source schema.

Det är medvetet.

Om `DELAMINATION` finns i:

- `Data Summary`
- `Resample Data Summary`
- `Extra Data Summary`

så hanteras det i det vanliga flödet och blir:

- `Minor Functional (Delamination)`

Den logiken ska inte dubbleras i RuleBank.

## Rekommendation om nästa steg

Nästa säkra steg är:

1. fortsätt underhålla regler i `Rules/Source/*`
2. bygg till `Rules/RuleBank.compiled.ps1`
3. kör testerna
4. använd den byggda körfilen i `Rules/`

## Kort chefsversion

Om någon frågar enkelt:

- `Rules/Source` = där regler skrivs
- `Rules/RuleBank.compiled.ps1` = det appen kör
- `RuleBank/` = pensionerat gammalt spår
