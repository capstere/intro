# RuleBank v2 source: ErrorCodes
@{
    SchemaVersion = 2
    Table = 'ErrorCodes'
    Rules = @(
        @{
            RuleId = 'ERR-0001'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '5001'
            Name = 'Curve Fit Error'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0002'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '5002'
            Name = 'Curve Fit Error'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0003'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '5003'
            Name = 'Curve Fit Error'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0004'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '5004'
            Name = 'Curve Fit Error'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0005'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '5005'
            Name = 'Curve Fit Error'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0006'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '5015'
            Name = 'Curve Fit Error'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0007'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '5016'
            Name = 'Curve Fit Error'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0008'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '5007'
            Name = 'Probe Check Low'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0009'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '5017'
            Name = 'Probe Check Low'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0010'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '5019'
            Name = 'Probe Check Low'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0011'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '5006'
            Name = 'Probe Check High'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0012'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '5018'
            Name = 'Probe Check High'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0013'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '2037'
            Name = 'CIT'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0014'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '5011'
            Name = 'SLD'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0015'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '2008'
            Name = 'Pressure Abort'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0016'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '2096'
            Name = 'Sample Volume Adequacy'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0017'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '2097'
            Name = 'Sample Volume Adequacy'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0018'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '2125'
            Name = 'Sample Volume Adequacy'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0019'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = ''
            Name = 'Max Pressure > 90 PSI'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0020'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = ''
            Name = 'Invalid w/o error (SPC Ct=0)'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0021'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '####'
            Name = 'Delamination + error code'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0022'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = ''
            Name = 'All types of "MTB": RIF Resistance Indeterminate'
            GeneratesRetest = 'No'
        }
        @{
            RuleId = 'ERR-0023'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = ''
            ErrorCode = '####'
            Name = 'Other error codes'
            GeneratesRetest = 'Yes'
        }
    )
}
