# RuleBank v2 source: SampleIdMarkers
@{
    SchemaVersion = 2
    Table = 'SampleIdMarkers'
    Rules = @(
        @{
            RuleId = 'SIM-0001'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Ignore trailing delamination token (e.g., _D2B, _D05, _D11) when evaluating suffix'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            MarkerType = 'DelaminationCodeRegex'
            Marker = '^D\d{1,2}[A-Z]?$'
            Enabled = $true
            SampleTokenIndex = -1
        }
        @{
            RuleId = 'SIM-0002'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Delimiter between base SampleID and delamination token'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            MarkerType = 'DelaminationSeparator'
            Marker = '_'
            Enabled = $true
            SampleTokenIndex = -1
        }
        @{
            RuleId = 'SIM-0003'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Valid suffix characters on Base-SampleID (X or +)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            MarkerType = 'SuffixChars'
            Marker = 'X|\\+'
            Enabled = $true
            SampleTokenIndex = -1
        }
        @{
            RuleId = 'SIM-0004'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'SampleTypeCode is token index 2 (0..5) in Sample ID split by "_"'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            MarkerType = 'SampleTypeCodeTokenIndex'
            Marker = '2'
            Enabled = $true
            SampleTokenIndex = 2
        }
        @{
            RuleId = 'SIM-0005'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'SampleNumber(+suffix) is token index 3 in Sample ID split by "_"'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            MarkerType = 'SampleNumberTokenIndex'
            Marker = '3'
            Enabled = $true
            SampleTokenIndex = 3
        }
    )
}
