# RuleBank v2 source: SampleNumberRules
@{
    SchemaVersion = 2
    Table = 'SampleNumberRules'
    Rules = @(
        @{
            RuleId = 'SNR-0001'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Resample: STC 0, BagNo=RES, 001-300'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            SampleTypeCode = '0'
            BagNoPattern = '^RES$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{3}'
            SampleNumberMin = 1
            SampleNumberMax = 300
            SampleNumberPad = 3
            Enabled = $true
            Priority = 9500
        }
        @{
            RuleId = 'SNR-0002'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Resample: STC 1, BagNo=RES, 001-300'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            SampleTypeCode = '1'
            BagNoPattern = '^RES$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{3}'
            SampleNumberMin = 1
            SampleNumberMax = 300
            SampleNumberPad = 3
            Enabled = $true
            Priority = 9500
        }
        @{
            RuleId = 'SNR-0003'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Resample: STC 2, BagNo=RES, 001-300'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            SampleTypeCode = '2'
            BagNoPattern = '^RES$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{3}'
            SampleNumberMin = 1
            SampleNumberMax = 300
            SampleNumberPad = 3
            Enabled = $true
            Priority = 9500
        }
        @{
            RuleId = 'SNR-0004'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Resample: STC 3, BagNo=RES, 001-300'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            SampleTypeCode = '3'
            BagNoPattern = '^RES$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{3}'
            SampleNumberMin = 1
            SampleNumberMax = 300
            SampleNumberPad = 3
            Enabled = $true
            Priority = 9500
        }
        @{
            RuleId = 'SNR-0005'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Resample: STC 4, BagNo=RES, 001-300'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            SampleTypeCode = '4'
            BagNoPattern = '^RES$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{3}'
            SampleNumberMin = 1
            SampleNumberMax = 300
            SampleNumberPad = 3
            Enabled = $true
            Priority = 9500
        }
        @{
            RuleId = 'SNR-0006'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Resample: STC 5, BagNo=RES, 001-300'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            SampleTypeCode = '5'
            BagNoPattern = '^RES$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{3}'
            SampleNumberMin = 1
            SampleNumberMax = 300
            SampleNumberPad = 3
            Enabled = $true
            Priority = 9500
        }
        @{
            RuleId = 'SNR-0007'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Respiratory Panel IUO'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0008'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-14'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Respiratory Panel IUO'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 14
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0009'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=15-16'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Respiratory Panel IUO'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 15
            SampleNumberMax = 16
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0010'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=17-18'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Respiratory Panel IUO'
            SampleTypeCode = '3'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 17
            SampleNumberMax = 18
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0011'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=19-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Respiratory Panel IUO'
            SampleTypeCode = '4'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 19
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0012'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'TAP Panel IUO'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0013'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'TAP Panel IUO'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0014'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 00 -> 01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'TAP Panel IUO'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0015'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert C.difficile BT'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0016'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert C.difficile BT'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0017'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert C.difficile G3'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0018'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert C.difficile G3'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0019'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=18-19'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert C.difficile G3'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 18
            SampleNumberMax = 19
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0020'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=20-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert C.difficile G3'
            SampleTypeCode = '3'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 20
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0021'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert CT_NG'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0022'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert CT_NG'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0023'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=19-19'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert CT_NG'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 19
            SampleNumberMax = 19
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0024'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=20-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert CT_NG'
            SampleTypeCode = '3'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 20
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0025'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Ebola EUA'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0026'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-18'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Ebola EUA'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 18
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0027'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=19-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Ebola EUA'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 19
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0028'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert GBS LB XC'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0029'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert GBS LB XC'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0030'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 00 -> 01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert GBS LB XC'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0031'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert GI Panel'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0032'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert GI Panel'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0033'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 00 -> 01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert GI Panel'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0034'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HBV Viral Load'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0035'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-18'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HBV Viral Load'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 18
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0036'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 00 -> 01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HBV Viral Load'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0037'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=19-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HBV Viral Load'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 19
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0038'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HCV PQC'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0039'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HCV PQC'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0040'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 00 -> 01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HCV PQC'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0041'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HCV VL Fingerstick'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0042'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-18'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HCV VL Fingerstick'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 18
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0043'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 00 -> 01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HCV VL Fingerstick'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0044'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=19-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HCV VL Fingerstick'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 19
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0045'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HIV-1 Qual XC PQC'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0046'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HIV-1 Qual XC PQC'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0047'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 00 -> 01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HIV-1 Qual XC PQC'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0048'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HIV-1 Viral Load XC'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0049'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-18'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HIV-1 Viral Load XC'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 18
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0050'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 00 -> 01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HIV-1 Viral Load XC'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0051'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=19-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HIV-1 Viral Load XC'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 19
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0052'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=01-06'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HPV HR'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 6
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0053'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 07-18'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HPV HR'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 7
            SampleNumberMax = 18
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0054'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 00 -> 01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HPV HR'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0055'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=19-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HPV HR'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 19
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0056'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA NxG'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0057'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-18'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA NxG'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 18
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0058'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=19-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA NxG'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 19
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0059'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA-SA SSTI G3'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0060'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA-SA SSTI G3'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0061'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Assay G4'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0062'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Assay G4'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0063'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0064'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-16'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 16
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0065'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=17-17'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 17
            SampleNumberMax = 17
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0066'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=18-18'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            SampleTypeCode = '3'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 18
            SampleNumberMax = 18
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0067'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=19-19'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            SampleTypeCode = '4'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 19
            SampleNumberMax = 19
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0068'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=20-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            SampleTypeCode = '5'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 20
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0069'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Ultra'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0070'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-18'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Ultra'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 18
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0071'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=19-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Ultra'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 19
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0072'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-XDR'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0073'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-18'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-XDR'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 18
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0074'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=19-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-XDR'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 19
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0075'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Norovirus'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0076'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-18'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Norovirus'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 18
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0077'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=19-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Norovirus'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 19
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0078'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert SA Nasal Complete G3'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0079'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert SA Nasal Complete G3'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0080'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress CoV-2 plus IVD'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0081'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress CoV-2 plus IVD'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0082'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress Flu-RSV'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0083'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-18'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress Flu-RSV'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 18
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0084'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=19-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress Flu-RSV'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 19
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0085'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress GBS'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0086'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress GBS'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0087'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 00 -> 01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress GBS'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0088'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress SARS-CoV-2 CE-IVD'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0089'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress SARS-CoV-2 CE-IVD'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0090'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress Strep A'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0091'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-18'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress Strep A'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 18
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0092'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=19-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress Strep A'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 19
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0093'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert vanA vanB'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0094'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert vanA vanB'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0095'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 01-14'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_Carba-R'
            SampleTypeCode = '0'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 14
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0096'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 00 -> 01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_Carba-R'
            SampleTypeCode = '0'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0097'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=15-18'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_Carba-R'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 15
            SampleNumberMax = 18
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0098'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=19-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_Carba-R'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 19
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0099'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_HCV Viral Load'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0100'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-18'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_HCV Viral Load'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 18
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0101'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 00 -> 01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_HCV Viral Load'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0102'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=19-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_HCV Viral Load'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 19
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0103'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_HIV-1 Viral Load'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0104'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 01,02,03,04,05,06,07,08,09,10 -> 11-18'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_HIV-1 Viral Load'
            SampleTypeCode = '1'
            BagNoPattern = '^(01|02|03|04|05|06|07|08|09|10)$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 18
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0105'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bag(s) 00 -> 01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_HIV-1 Viral Load'
            SampleTypeCode = '1'
            BagNoPattern = '^00$'
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9100
        }
        @{
            RuleId = 'SNR-0106'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=19-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_HIV-1 Viral Load'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 19
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0107'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress Flu IPT_EAT off'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0108'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-18'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress Flu IPT_EAT off'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 18
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0109'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=19-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress Flu IPT_EAT off'
            SampleTypeCode = '2'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 19
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0110'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=11 observed; range=01-10'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress SARS-CoV-2_Flu_RSV plus'
            SampleTypeCode = '0'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 1
            SampleNumberMax = 10
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'SNR-0111'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'From AssayFam: bags=10 observed; range=11-20'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress SARS-CoV-2_Flu_RSV plus'
            SampleTypeCode = '1'
            BagNoPattern = ''
            SampleNumberTokenIndex = 3
            SampleNumberRegex = '^\d{2}'
            SampleNumberMin = 11
            SampleNumberMax = 20
            SampleNumberPad = 2
            Enabled = $true
            Priority = 9000
        }
    )
}
