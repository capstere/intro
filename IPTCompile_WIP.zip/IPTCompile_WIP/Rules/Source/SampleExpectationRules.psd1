# RuleBank v2 source: SampleExpectationRules
@{
    SchemaVersion = 2
    Table = 'SampleExpectationRules'
    Rules = @(
        @{
            RuleId = 'EXP-0001'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Token2=0 => Negative Control (expected NEG)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            SampleIdMatchType = 'REGEX'
            SampleIdPattern = '^[^_]+_[^_]+_0_'
            ExpectedCall = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'EXP-0002'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Token2=1-5 => Positive Control (expected POS)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            SampleIdMatchType = 'REGEX'
            SampleIdPattern = '^[^_]+_[^_]+_[1-5]_'
            ExpectedCall = 'POS'
            Enabled = $true
            Priority = 8990
        }
        @{
            RuleId = 'EXP-0003'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Legacy: Sample ID starts with NEG_'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            SampleIdMatchType = 'PREFIX'
            SampleIdPattern = 'NEG_'
            ExpectedCall = 'NEG'
            Enabled = $true
            Priority = 5000
        }
        @{
            RuleId = 'EXP-0004'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Legacy: Sample ID starts with POS_'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            SampleIdMatchType = 'PREFIX'
            SampleIdPattern = 'POS_'
            ExpectedCall = 'POS'
            Enabled = $true
            Priority = 4990
        }
    )
}
