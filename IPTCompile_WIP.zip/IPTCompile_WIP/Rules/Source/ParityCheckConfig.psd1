# RuleBank v2 source: ParityCheckConfig
@{
    SchemaVersion = 2
    Table = 'ParityCheckConfig'
    Rules = @(
        @{
            RuleId = 'PAR-0001'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Use parity (odd/even) to predict expected suffix for MTB-family; fallback to majority if too many missing/invalid S/N'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Assay G4'
            Enabled = $true
            CartridgeField = 'Cartridge S/N'
            SampleTokenIndex = 3
            SuffixX = 'X'
            SuffixPlus = '+'
            DelaminationMarkerType = 'DelaminationCodeRegex'
            MinValidCartridgeSNPercent = 80
            Priority = 9000
        }
        @{
            RuleId = 'PAR-0002'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Use parity (odd/even) to predict expected suffix for MTB-family; fallback to majority if too many missing/invalid S/N'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            Enabled = $true
            CartridgeField = 'Cartridge S/N'
            SampleTokenIndex = 3
            SuffixX = 'X'
            SuffixPlus = '+'
            DelaminationMarkerType = 'DelaminationCodeRegex'
            MinValidCartridgeSNPercent = 80
            Priority = 9000
        }
        @{
            RuleId = 'PAR-0003'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Use parity (odd/even) to predict expected suffix for MTB-family; fallback to majority if too many missing/invalid S/N'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Ultra'
            Enabled = $true
            CartridgeField = 'Cartridge S/N'
            SampleTokenIndex = 3
            SuffixX = 'X'
            SuffixPlus = '+'
            DelaminationMarkerType = 'DelaminationCodeRegex'
            MinValidCartridgeSNPercent = 80
            Priority = 9000
        }
        @{
            RuleId = 'PAR-0004'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Use parity (odd/even) to predict expected suffix for MTB-family; fallback to majority if too many missing/invalid S/N'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-XDR'
            Enabled = $true
            CartridgeField = 'Cartridge S/N'
            SampleTokenIndex = 3
            SuffixX = 'X'
            SuffixPlus = '+'
            DelaminationMarkerType = 'DelaminationCodeRegex'
            MinValidCartridgeSNPercent = 80
            Priority = 9000
        }
        @{
            RuleId = 'PAR-0005'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = '(Template) Enable per-assay when X/+ naming is used and Cartridge S/N parity is meaningful'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            Enabled = $true
            CartridgeField = 'Cartridge S/N'
            SampleTokenIndex = 3
            SuffixX = 'X'
            SuffixPlus = '+'
            DelaminationMarkerType = 'DelaminationCodeRegex'
            MinValidCartridgeSNPercent = 80
            Priority = 100
        }
    )
}
