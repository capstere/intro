# RuleBank v2 source: TestTypePolicy
@{
    SchemaVersion = 2
    Table = 'TestTypePolicy'
    Rules = @(
        @{
            RuleId = 'TTP-0001'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert-C. difficile G2'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'C.DIFF G2'
        }
        @{
            RuleId = 'TTP-0002'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert C.difficile BT'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'C.DIFF BT'
        }
        @{
            RuleId = 'TTP-0003'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert C.diff-Epi'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'C.DIFF EP'
        }
        @{
            RuleId = 'TTP-0004'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert C.difficile G3'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'C.DIFF'
        }
        @{
            RuleId = 'TTP-0005'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert C.difficile G3'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'C.DIFF JP'
        }
        @{
            RuleId = 'TTP-0006'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Carba-R'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'CARBA IMP1'
        }
        @{
            RuleId = 'TTP-0007'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'CARBA-R IUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'CARBA IMP1'
        }
        @{
            RuleId = 'TTP-0008'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Carba-R BEU IUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'CARBA'
        }
        @{
            RuleId = 'TTP-0009'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'CARBA-R RUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'CARBA'
        }
        @{
            RuleId = 'TTP-0010'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Carba-R BEU RUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'CARBA'
        }
        @{
            RuleId = 'TTP-0011'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_Carba-R'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'CARBA'
        }
        @{
            RuleId = 'TTP-0012'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress SARS-CoV-2 CE-IVD'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'SARS'
        }
        @{
            RuleId = 'TTP-0013'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress SARS-CoV-2'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'SARS'
        }
        @{
            RuleId = 'TTP-0014'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'LCE009 Xpress SARS-CoV-2 plus'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'COVID plus'
        }
        @{
            RuleId = 'TTP-0015'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress CoV-2 plus IUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'COVID plus'
        }
        @{
            RuleId = 'TTP-0016'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress CoV-2 plus RUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'COVID plus'
        }
        @{
            RuleId = 'TTP-0017'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress CoV-2 plus'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'COVID plus'
        }
        @{
            RuleId = 'TTP-0018'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress CoV-2 plus IVD'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'COVID plus'
        }
        @{
            RuleId = 'TTP-0019'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'SARS-CoV-2_Flu_RSV_plus'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'FLUVID plus'
        }
        @{
            RuleId = 'TTP-0020'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'SARS-CoV-2_Flu_RSV plus IUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'FLUVID plus'
        }
        @{
            RuleId = 'TTP-0021'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'SARS-CoV-2_Flu_RSV plus RUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'FLUVID plus'
        }
        @{
            RuleId = 'TTP-0022'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress SARS-CoV-2_Flu_RSV plus'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'FLUVID plus'
        }
        @{
            RuleId = 'TTP-0023'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress SARS-CoV-2 Flu RSV plus'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'FLUVID plus'
        }
        @{
            RuleId = 'TTP-0024'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert CT_CE'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'CT'
        }
        @{
            RuleId = 'TTP-0025'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert CT_NG'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'CTNG'
        }
        @{
            RuleId = 'TTP-0026'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert CT_NG'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'CTNG JP'
        }
        @{
            RuleId = 'TTP-0027'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Ebola EUA'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'EBOLA'
        }
        @{
            RuleId = 'TTP-0028'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Ebola CE-IVD'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'EBOLA'
        }
        @{
            RuleId = 'TTP-0029'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Ebola RUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'EBOLA'
        }
        @{
            RuleId = 'TTP-0030'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress GBS IUO'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'GBS'
        }
        @{
            RuleId = 'TTP-0031'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress GBS RUO'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'GBS'
        }
        @{
            RuleId = 'TTP-0032'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress GBS RUO'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'GBS'
        }
        @{
            RuleId = 'TTP-0033'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress GBS'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'GBS'
        }
        @{
            RuleId = 'TTP-0034'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'GBS LB RUO'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'GBS'
        }
        @{
            RuleId = 'TTP-0035'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'GBS LB XC IUO'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'GBS'
        }
        @{
            RuleId = 'TTP-0036'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert GBS LB XC'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'GBS'
        }
        @{
            RuleId = 'TTP-0037'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HBV Viral Load'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HBV*'
        }
        @{
            RuleId = 'TTP-0038'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HCV VL Fingerstick'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HCV FS*'
        }
        @{
            RuleId = 'TTP-0039'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HCV VL WB RUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HCV FS*'
        }
        @{
            RuleId = 'TTP-0040'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HCV IUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HCV'
        }
        @{
            RuleId = 'TTP-0041'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HCV PQC'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HCV'
        }
        @{
            RuleId = 'TTP-0042'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_HCV Viral Load'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HCV VL*'
        }
        @{
            RuleId = 'TTP-0043'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HCV Viral Load RUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HCV VL*'
        }
        @{
            RuleId = 'TTP-0044'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_HIV-1 Viral Load'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HIV VL*'
        }
        @{
            RuleId = 'TTP-0045'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HIV-1 Viral Load RUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HIV VL*'
        }
        @{
            RuleId = 'TTP-0046'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HIV-1 Qual XC DBS RUO'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HIV QA XC'
        }
        @{
            RuleId = 'TTP-0047'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HIV-1 Qual XC DBS IUO'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HIV QA XC'
        }
        @{
            RuleId = 'TTP-0048'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HIV-1 Qual XC PQC'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HIV QA XC'
        }
        @{
            RuleId = 'TTP-0049'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HIV-1 Qual XC PQC RUO'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HIV QA XC'
        }
        @{
            RuleId = 'TTP-0050'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HIV-1 Viral Load XC IUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HIV VL XC'
        }
        @{
            RuleId = 'TTP-0051'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HIV-1 Viral Load XC RUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HIV VL XC'
        }
        @{
            RuleId = 'TTP-0052'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HIV-1 Viral Load XC'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HIV VL XC'
        }
        @{
            RuleId = 'TTP-0053'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HPV HR'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HPV'
        }
        @{
            RuleId = 'TTP-0054'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HPV v2 HR'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HPV'
        }
        @{
            RuleId = 'TTP-0055'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HPV HR AND GENOTYPE RUO ASSAY'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'HPV'
        }
        @{
            RuleId = 'TTP-0056'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA NxG'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'MRSA NxG'
        }
        @{
            RuleId = 'TTP-0057'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MRSA NxG IUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'MRSA NxG'
        }
        @{
            RuleId = 'TTP-0058'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MRSA NxG RUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'MRSA NxG'
        }
        @{
            RuleId = 'TTP-0059'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA_SA_BC'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'MRSA SA'
        }
        @{
            RuleId = 'TTP-0060'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA_SA_BC_CE'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'MRSA SA'
        }
        @{
            RuleId = 'TTP-0061'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA-SA BC G3'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'MRSA SA'
        }
        @{
            RuleId = 'TTP-0062'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA-SA SSTI G3'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'MRSA SA'
        }
        @{
            RuleId = 'TTP-0063'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert SA Nasal Complete G3'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'MRSA SA'
        }
        @{
            RuleId = 'TTP-0064'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MRSA-SA ETA'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'MRSA SA'
        }
        @{
            RuleId = 'TTP-0065'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Ultra'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'MTB U'
        }
        @{
            RuleId = 'TTP-0066'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MTB-RIF Ultra v2 RUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'MTB U'
        }
        @{
            RuleId = 'TTP-0067'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Assay G4'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'MTB'
        }
        @{
            RuleId = 'TTP-0068'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF US IVD'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'MTB'
        }
        @{
            RuleId = 'TTP-0069'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'MTB JP'
        }
        @{
            RuleId = 'TTP-0070'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-XDR'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'MTB XDR'
        }
        @{
            RuleId = 'TTP-0071'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MTB-XDR RUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'MTB XDR'
        }
        @{
            RuleId = 'TTP-0072'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MTB-XDR IUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'MTB XDR'
        }
        @{
            RuleId = 'TTP-0073'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Norovirus'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'NORO'
        }
        @{
            RuleId = 'TTP-0074'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'TAP Panel RUO'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'TAP Panel'
        }
        @{
            RuleId = 'TTP-0075'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'TAP Panel IUO'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'TAP Panel'
        }
        @{
            RuleId = 'TTP-0076'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert TAP Panel'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'TAP Panel'
        }
        @{
            RuleId = 'TTP-0077'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert vanA vanB'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'VAN AB'
        }
        @{
            RuleId = 'TTP-0078'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'XP Flu-RSV RUO'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'FLU RSV'
        }
        @{
            RuleId = 'TTP-0079'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress Flu-RSV'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'FLU RSV'
        }
        @{
            RuleId = 'TTP-0080'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress Flu IPT_EAT off'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'FLU'
        }
        @{
            RuleId = 'TTP-0081'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Respiratory Panel IUO'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'Resp Panel'
        }
        @{
            RuleId = 'TTP-0082'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Respiratory Panel RUO'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'Resp Panel'
        }
        @{
            RuleId = 'TTP-0083'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Respiratory panel'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'Resp Panel'
        }
        @{
            RuleId = 'TTP-0084'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Respiratory panel CE-IVD'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'Resp Panel'
        }
        @{
            RuleId = 'TTP-0085'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Respiratory panel UKCA-IVD'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'Resp Panel'
        }
        @{
            RuleId = 'TTP-0086'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'GI Panel RUO'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'GI Panel'
        }
        @{
            RuleId = 'TTP-0087'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'GI Panel IUO'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'GI Panel'
        }
        @{
            RuleId = 'TTP-0088'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert GI Panel'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'GI Panel'
        }
        @{
            RuleId = 'TTP-0089'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert GI Panel CE-IVD'
            AllowedTestTypes = @(
                'Specimen'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'GI Panel'
        }
        @{
            RuleId = 'TTP-0090'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress Strep A'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'STREPA'
        }
        @{
            RuleId = 'TTP-0091'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generated from Assay.csv'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress_Strep A'
            AllowedTestTypes = @(
                'Negative Control 1'
                'Positive Control 1'
                'Positive Control 2'
            )
            Enabled = $true
            Priority = 100
            AssayFamily = 'STREPA'
        }
    )
}
