# RuleBank v2 source: ResultCallPatterns
@{
    SchemaVersion = 2
    Table = 'ResultCallPatterns'
    Rules = @(
        @{
            RuleId = 'RCP-0001'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generic: Test Result = ERROR'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            MatchType = 'EQUALS'
            Pattern = 'ERROR'
            Call = 'ERROR'
            Enabled = $true
            Priority = 9500
        }
        @{
            RuleId = 'RCP-0002'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generic: NO RESULT'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            MatchType = 'CONTAINS'
            Pattern = 'NO RESULT'
            Call = 'ERROR'
            Enabled = $true
            Priority = 9500
        }
        @{
            RuleId = 'RCP-0003'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generic: Aborted'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            MatchType = 'CONTAINS'
            Pattern = 'Aborted'
            Call = 'ERROR'
            Enabled = $true
            Priority = 9500
        }
        @{
            RuleId = 'RCP-0004'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Generic: INVALID (non-HPV)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            MatchType = 'CONTAINS'
            Pattern = 'INVALID'
            Call = 'ERROR'
            Enabled = $true
            Priority = 1000
        }
        @{
            RuleId = 'RCP-0005'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'MTB family: MTB NOT DETECTED => NEG'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Assay G4'
            MatchType = 'CONTAINS'
            Pattern = 'MTB NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9400
        }
        @{
            RuleId = 'RCP-0006'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'MTB family: MTB NOT DETECTED => NEG'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-XDR'
            MatchType = 'CONTAINS'
            Pattern = 'MTB NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9400
        }
        @{
            RuleId = 'RCP-0007'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'MTB family: MTB NOT DETECTED => NEG'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Ultra'
            MatchType = 'CONTAINS'
            Pattern = 'MTB NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9400
        }
        @{
            RuleId = 'RCP-0008'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'MTB family: MTB NOT DETECTED => NEG'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            MatchType = 'CONTAINS'
            Pattern = 'MTB NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9400
        }
        @{
            RuleId = 'RCP-0009'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'MTB family: MTB Trace DETECTED => POS (even if RIF indeterminate)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-XDR'
            MatchType = 'CONTAINS'
            Pattern = 'MTB Trace DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9390
        }
        @{
            RuleId = 'RCP-0010'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'MTB family: MTB Trace DETECTED => POS (even if RIF indeterminate)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Ultra'
            MatchType = 'CONTAINS'
            Pattern = 'MTB Trace DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9390
        }
        @{
            RuleId = 'RCP-0011'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'MTB family: MTB Trace DETECTED => POS (even if RIF indeterminate)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            MatchType = 'CONTAINS'
            Pattern = 'MTB Trace DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9390
        }
        @{
            RuleId = 'RCP-0012'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'MTB family: MTB Trace DETECTED => POS (even if RIF indeterminate)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Assay G4'
            MatchType = 'CONTAINS'
            Pattern = 'MTB Trace DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9390
        }
        @{
            RuleId = 'RCP-0013'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'MTB family: MTB DETECTED => POS (covers HIGH/LOW; even if RIF indeterminate)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Assay G4'
            MatchType = 'CONTAINS'
            Pattern = 'MTB DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9380
        }
        @{
            RuleId = 'RCP-0014'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'MTB family: MTB DETECTED => POS (covers HIGH/LOW; even if RIF indeterminate)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Ultra'
            MatchType = 'CONTAINS'
            Pattern = 'MTB DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9380
        }
        @{
            RuleId = 'RCP-0015'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'MTB family: MTB DETECTED => POS (covers HIGH/LOW; even if RIF indeterminate)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            MatchType = 'CONTAINS'
            Pattern = 'MTB DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9380
        }
        @{
            RuleId = 'RCP-0016'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'MTB family: MTB DETECTED => POS (covers HIGH/LOW; even if RIF indeterminate)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-XDR'
            MatchType = 'CONTAINS'
            Pattern = 'MTB DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9380
        }
        @{
            RuleId = 'RCP-0017'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MRSA NxG SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA NxG'
            MatchType = 'EQUALS'
            Pattern = 'MRSA DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0018'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF US IVD'
            MatchType = 'EQUALS'
            Pattern = 'MTB NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0019'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HPV SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HPV HR'
            MatchType = 'EQUALS'
            Pattern = 'HR HPV POS'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0020'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB U SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Ultra'
            MatchType = 'EQUALS'
            Pattern = 'MTB NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0021'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HIV VL XC SampleType 1 (wildcard)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HIV-1 Viral Load XC'
            MatchType = 'REGEX'
            Pattern = 'HIV\-1\ DETECTED\ .*\ copies/mL\ \(log\ .*\..*\)'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0022'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB U SampleType 1 (wildcard)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Ultra'
            MatchType = 'REGEX'
            Pattern = 'MTB\ DETECTED\ .*;Rif\ Resistance\ DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0023'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB U SampleType 2 (wildcard)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Ultra'
            MatchType = 'REGEX'
            Pattern = 'MTB\ DETECTED\ .*;Rif\ Resistance\ NOT\ DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0024'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HPV SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HPV HR'
            MatchType = 'EQUALS'
            Pattern = 'INVALID'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0025'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB XDR SampleType 2'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-XDR'
            MatchType = 'EQUALS'
            Pattern = 'MTB DETECTED;INH Resistance DETECTED;FLQ Resistance DETECTED;AMK Resistance DETECTED;KAN Resistance DETECTED;CAP Resistance DETECTED;ETH Resistance DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0026'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB XDR SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-XDR'
            MatchType = 'EQUALS'
            Pattern = 'MTB DETECTED;INH Resistance NOT DETECTED;FLQ Resistance NOT DETECTED;AMK Resistance NOT DETECTED;KAN Resistance NOT DETECTED;CAP Resistance NOT DETECTED;ETH Resistance NOT DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0027'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HIV VL XC SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HIV-1 Viral Load XC'
            MatchType = 'EQUALS'
            Pattern = 'HIV-1 NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0028'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB XDR SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-XDR'
            MatchType = 'EQUALS'
            Pattern = 'MTB NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0029'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HCV FS SampleType 1 (wildcard)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HCV VL Fingerstick'
            MatchType = 'REGEX'
            Pattern = 'HCV\ DETECTED\ .*\ IU/mL\ \(log\ .*\..*\)'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0030'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec NORO SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Norovirus'
            MatchType = 'EQUALS'
            Pattern = 'NORO GI DETECTED;NORO GII DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0031'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF US IVD'
            MatchType = 'EQUALS'
            Pattern = 'MTB DETECTED;Rif Resistance NOT DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0032'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HPV SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HPV v2 HR'
            MatchType = 'EQUALS'
            Pattern = 'HR HPV POS'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0033'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB JP SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            MatchType = 'EQUALS'
            Pattern = 'MTB NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0034'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MRSA SA SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA_SA_BC_CE'
            MatchType = 'EQUALS'
            Pattern = 'MRSA NEGATIVE;SA NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0035'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MRSA SA SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA-SA BC G3'
            MatchType = 'EQUALS'
            Pattern = 'MRSA NEGATIVE;SA NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0036'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MRSA SA SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA-SA BC G3'
            MatchType = 'EQUALS'
            Pattern = 'MRSA POSITIVE;SA POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0037'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MRSA SA SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA-SA SSTI G3'
            MatchType = 'EQUALS'
            Pattern = 'MRSA NEGATIVE;SA NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0038'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MRSA SA SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA-SA SSTI G3'
            MatchType = 'EQUALS'
            Pattern = 'MRSA POSITIVE;SA POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0039'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MRSA SA SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA_SA_BC'
            MatchType = 'EQUALS'
            Pattern = 'MRSA NEGATIVE;SA NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0040'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MRSA SA SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA_SA_BC'
            MatchType = 'EQUALS'
            Pattern = 'MRSA POSITIVE;SA POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0041'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MRSA SA SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA_SA_BC_CE'
            MatchType = 'EQUALS'
            Pattern = 'MRSA POSITIVE;SA POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0042'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MRSA NxG SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MRSA NxG'
            MatchType = 'EQUALS'
            Pattern = 'MRSA NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0043'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HPV SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HPV v2 HR'
            MatchType = 'EQUALS'
            Pattern = 'INVALID'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0044'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Assay G4'
            MatchType = 'EQUALS'
            Pattern = 'MTB NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0045'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MRSA SA SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert SA Nasal Complete G3'
            MatchType = 'EQUALS'
            Pattern = 'MRSA NEGATIVE;SA NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0046'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB SampleType 1 (wildcard)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF Assay G4'
            MatchType = 'REGEX'
            Pattern = 'MTB\ DETECTED\ .*;Rif\ Resistance\ NOT\ DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0047'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB JP SampleType 2'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            MatchType = 'EQUALS'
            Pattern = 'MTB DETECTED;Rif Resistance DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0048'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB JP SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert MTB-RIF JP IVD'
            MatchType = 'EQUALS'
            Pattern = 'MTB DETECTED;Rif Resistance NOT DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0049'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec NORO SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Norovirus'
            MatchType = 'EQUALS'
            Pattern = 'NORO GI NOT DETECTED;NORO GII NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0050'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MRSA SA SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert SA Nasal Complete G3'
            MatchType = 'EQUALS'
            Pattern = 'MRSA POSITIVE;SA POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0051'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GX HCV SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HCV PQC'
            MatchType = 'EQUALS'
            Pattern = 'HCV NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0052'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec C.DIFF SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert-C. difficile G2'
            MatchType = 'EQUALS'
            Pattern = 'Toxigenic C.diff NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0053'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec CARBA SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_Carba-R'
            MatchType = 'EQUALS'
            Pattern = 'IMP1 DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0054'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec CARBA SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_Carba-R'
            MatchType = 'EQUALS'
            Pattern = 'IMP1 NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0055'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HCV VL SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_HCV Viral Load'
            MatchType = 'EQUALS'
            Pattern = 'HCV NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0056'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HCV VL SampleType 1 (wildcard)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_HCV Viral Load'
            MatchType = 'REGEX'
            Pattern = 'HCV\ DETECTED\ .*\ IU/mL\ \(log\ .*\..*\)'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0057'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HIV VL SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_HIV-1 Viral Load'
            MatchType = 'EQUALS'
            Pattern = 'HIV-1 NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0058'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HIV VL SampleType 1 (wildcard)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert_HIV-1 Viral Load'
            MatchType = 'REGEX'
            Pattern = 'HIV\-1\ DETECTED\ .*\ copies/mL\ \(log\ .*\..*\)'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0059'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Covid plus SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress CoV-2 plus IUO'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0060'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Covid plus SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress CoV-2 plus IUO'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0061'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Covid plus SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress CoV-2 plus RUO'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0062'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Covid plus SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress CoV-2 plus RUO'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0063'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec FLU RSV SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress Flu IPT_EAT off'
            MatchType = 'EQUALS'
            Pattern = 'Flu A NEGATIVE;Flu B NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0064'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec FLU RSV SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress Flu IPT_EAT off'
            MatchType = 'EQUALS'
            Pattern = 'Flu A POSITIVE;Flu B POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0065'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GBS SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress GBS IUO'
            MatchType = 'EQUALS'
            Pattern = 'GBS NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0066'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GBS SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress GBS IUO'
            MatchType = 'EQUALS'
            Pattern = 'GBS POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0067'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GBS SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress GBS RUO'
            MatchType = 'EQUALS'
            Pattern = 'GBS NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0068'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GBS SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress GBS RUO'
            MatchType = 'EQUALS'
            Pattern = 'GBS POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0069'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec FLUVID plus SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress SARS-CoV-2 Flu RSV plus'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0070'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec FLUVID plus SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress SARS-CoV-2 Flu RSV plus'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE;Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0071'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec FLUVID plus SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress SARS-CoV-2_Flu_RSV plus'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0072'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec C.DIFF SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert-C. difficile G2'
            MatchType = 'EQUALS'
            Pattern = 'Toxigenic C.diff POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0073'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec VAN AB SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert vanA vanB'
            MatchType = 'EQUALS'
            Pattern = 'vanA POSITIVE;vanB POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0074'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec TAP Panel SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert TAP Panel'
            MatchType = 'EQUALS'
            Pattern = 'Ft DETECTED;Ba DETECTED;Yp DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0075'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec VAN AB SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert vanA vanB'
            MatchType = 'EQUALS'
            Pattern = 'vanA NEGATIVE;vanB NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0076'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec TAP Panel SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert TAP Panel'
            MatchType = 'EQUALS'
            Pattern = 'Ft NOT DETECTED;Ba NOT DETECTED;Yp NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0077'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Covid plus SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress CoV-2 plus'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0078'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Covid plus SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress CoV-2 plus'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0079'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Covid plus SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress CoV-2 plus IVD'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0080'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Covid plus SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress CoV-2 plus IVD'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0081'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec FLU RSV SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress Flu-RSV'
            MatchType = 'EQUALS'
            Pattern = 'Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0082'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec FLU RSV SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress Flu-RSV'
            MatchType = 'EQUALS'
            Pattern = 'Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0083'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GBS SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress GBS'
            MatchType = 'EQUALS'
            Pattern = 'GBS NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0084'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GBS SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress GBS'
            MatchType = 'EQUALS'
            Pattern = 'GBS POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0085'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GBS SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress GBS RUO'
            MatchType = 'EQUALS'
            Pattern = 'GBS NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0086'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GBS SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress GBS RUO'
            MatchType = 'EQUALS'
            Pattern = 'GBS POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0087'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Sars SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress SARS-CoV-2'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0088'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Sars SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress SARS-CoV-2'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0089'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Sars SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress SARS-CoV-2 CE-IVD'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0090'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Sars SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress SARS-CoV-2 CE-IVD'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0091'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec STREPA SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress Strep A'
            MatchType = 'EQUALS'
            Pattern = 'Strep A DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0092'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec STREPA SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress Strep A'
            MatchType = 'EQUALS'
            Pattern = 'Strep A NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0093'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec STREPA SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress_Strep A'
            MatchType = 'EQUALS'
            Pattern = 'Strep A DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0094'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec STREPA SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Xpress_Strep A'
            MatchType = 'EQUALS'
            Pattern = 'Strep A NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0095'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HCV FS SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HCV VL Fingerstick'
            MatchType = 'EQUALS'
            Pattern = 'HCV NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0096'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GX HCV SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HCV PQC'
            MatchType = 'EQUALS'
            Pattern = 'HCV DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0097'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB XDR SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MTB-XDR IUO'
            MatchType = 'EQUALS'
            Pattern = 'MTB DETECTED;INH Resistance NOT DETECTED;FLQ Resistance NOT DETECTED;AMK Resistance NOT DETECTED;KAN Resistance NOT DETECTED;CAP Resistance NOT DETECTED;ETH Resistance NOT DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0098'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Covid plus SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'LCE009 Xpress SARS-CoV-2 plus'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0099'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HCV VL SampleType 1 (wildcard)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HCV Viral Load RUO'
            MatchType = 'REGEX'
            Pattern = 'HCV\ DETECTED\ .*\ IU/mL\ \(log\ .*\..*\)'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0100'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HIV VL SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HIV-1 Viral Load RUO'
            MatchType = 'EQUALS'
            Pattern = 'HIV-1 NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0101'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HIV VL SampleType 1 (wildcard)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HIV-1 Viral Load RUO'
            MatchType = 'REGEX'
            Pattern = 'HIV\-1\ DETECTED\ .*\ copies/mL\ \(log\ .*\..*\)'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0102'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HIV VL XC SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HIV-1 Viral Load XC IUO'
            MatchType = 'EQUALS'
            Pattern = 'HIV-1 NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0103'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HIV VL XC SampleType 1 (wildcard)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HIV-1 Viral Load XC IUO'
            MatchType = 'REGEX'
            Pattern = 'HIV\-1\ DETECTED\ .*\ copies/mL\ \(log\ .*\..*\)'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0104'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HIV VL XC SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HIV-1 Viral Load XC RUO'
            MatchType = 'EQUALS'
            Pattern = 'HIV-1 NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0105'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HIV VL XC SampleType 1 (wildcard)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HIV-1 Viral Load XC RUO'
            MatchType = 'REGEX'
            Pattern = 'HIV\-1\ DETECTED\ .*\ copies/mL\ \(log\ .*\..*\)'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0106'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HPV SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HPV HR AND GENOTYPE RUO ASSAY'
            MatchType = 'EQUALS'
            Pattern = 'HR HPV POS'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0107'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HPV SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HPV HR AND GENOTYPE RUO ASSAY'
            MatchType = 'EQUALS'
            Pattern = 'INVALID'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0108'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Covid plus SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'LCE009 Xpress SARS-CoV-2 plus'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0109'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HBV VL SampleType 1 (wildcard)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HBV Viral Load'
            MatchType = 'REGEX'
            Pattern = 'HBV\ DETECTED\ .*\ IU/mL\ \(log\ .*\..*\)'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0110'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MRSA NxG SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MRSA NxG IUO'
            MatchType = 'EQUALS'
            Pattern = 'MRSA DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0111'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MRSA NxG SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MRSA NxG IUO'
            MatchType = 'EQUALS'
            Pattern = 'MRSA NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0112'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MRSA NxG SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MRSA NxG RUO'
            MatchType = 'EQUALS'
            Pattern = 'MRSA DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0113'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MRSA NxG SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MRSA NxG RUO'
            MatchType = 'EQUALS'
            Pattern = 'MRSA NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0114'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MRSA SA SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MRSA-SA ETA'
            MatchType = 'EQUALS'
            Pattern = 'MRSA NEGATIVE;SA NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0115'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MRSA SA SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MRSA-SA ETA'
            MatchType = 'EQUALS'
            Pattern = 'MRSA POSITIVE;SA POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0116'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB U SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MTB-RIF Ultra v2 RUO'
            MatchType = 'EQUALS'
            Pattern = 'MTB NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0117'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB U SampleType 1 (wildcard)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MTB-RIF Ultra v2 RUO'
            MatchType = 'REGEX'
            Pattern = 'MTB\ DETECTED\ .*;Rif\ Resistance\ DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0118'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB U SampleType 2 (wildcard)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MTB-RIF Ultra v2 RUO'
            MatchType = 'REGEX'
            Pattern = 'MTB\ DETECTED\ .*;Rif\ Resistance\ NOT\ DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0119'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HCV VL SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HCV Viral Load RUO'
            MatchType = 'EQUALS'
            Pattern = 'HCV NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0120'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HCV FS SampleType 1 (wildcard)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HCV VL WB RUO'
            MatchType = 'REGEX'
            Pattern = 'HCV\ DETECTED\ .*\ IU/mL\ \(log\ .*\..*\)'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0121'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HCV FS SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HCV VL WB RUO'
            MatchType = 'EQUALS'
            Pattern = 'HCV NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0122'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GX HCV SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HCV IUO'
            MatchType = 'EQUALS'
            Pattern = 'HCV NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0123'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec CARBA SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'CARBA-R IUO'
            MatchType = 'EQUALS'
            Pattern = 'IMP1 DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0124'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec CARBA SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'CARBA-R IUO'
            MatchType = 'EQUALS'
            Pattern = 'IMP1 NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0125'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec CARBA SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'CARBA-R RUO'
            MatchType = 'EQUALS'
            Pattern = 'IMP DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0126'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec CARBA SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'CARBA-R RUO'
            MatchType = 'EQUALS'
            Pattern = 'IMP NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0127'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec CARBA SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Carba-R BEU IUO'
            MatchType = 'EQUALS'
            Pattern = 'IMP DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0128'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec CARBA SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Carba-R BEU IUO'
            MatchType = 'EQUALS'
            Pattern = 'IMP NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0129'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec CARBA SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Carba-R BEU RUO'
            MatchType = 'EQUALS'
            Pattern = 'IMP DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0130'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec CARBA SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Carba-R BEU RUO'
            MatchType = 'EQUALS'
            Pattern = 'IMP NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0131'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec EBOLA SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Ebola RUO'
            MatchType = 'EQUALS'
            Pattern = 'Ebola GP DETECTED;Ebola NP DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0132'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec EBOLA SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Ebola RUO'
            MatchType = 'EQUALS'
            Pattern = 'Ebola GP NOT DETECTED;Ebola NP NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0133'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GBS XC SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'GBS LB RUO'
            MatchType = 'EQUALS'
            Pattern = 'GBS NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0134'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GBS XC SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'GBS LB RUO'
            MatchType = 'EQUALS'
            Pattern = 'GBS POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0135'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GBS XC SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'GBS LB XC IUO'
            MatchType = 'EQUALS'
            Pattern = 'GBS NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0136'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GBS XC SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'GBS LB XC IUO'
            MatchType = 'EQUALS'
            Pattern = 'GBS POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0137'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GI Panel SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'GI Panel IUO'
            MatchType = 'EQUALS'
            Pattern = 'Campylobacter NEGATIVE;Salmonella NEGATIVE;STEC stx1 NEGATIVE;STEC stx2 NEGATIVE;Shigella EIEC NEGATIVE;V. cholerae NEGATIVE;V. parahaemolyticus NEGATIVE;Yersinia NEGATIVE;Cryptosporidium NEGATIVE;Giardia NEGATIVE;Norovirus NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0138'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GI Panel SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'GI Panel IUO'
            MatchType = 'EQUALS'
            Pattern = 'Campylobacter POSITIVE;Salmonella POSITIVE;STEC stx1 POSITIVE;STEC stx2 POSITIVE;Shigella EIEC POSITIVE;V. cholerae POSITIVE;V. parahaemolyticus POSITIVE;Yersinia POSITIVE;Cryptosporidium POSITIVE;Giardia POSITIVE;Norovirus POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0139'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GI Panel SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'GI Panel RUO'
            MatchType = 'EQUALS'
            Pattern = 'Campylobacter NEGATIVE;Salmonella NEGATIVE;STEC stx1 NEGATIVE;STEC stx2 NEGATIVE;Shigella EIEC NEGATIVE;V. cholerae NEGATIVE;V. parahaemolyticus NEGATIVE;Yersinia NEGATIVE;Cryptosporidium NEGATIVE;Giardia NEGATIVE;Norovirus NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0140'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GI Panel SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'GI Panel RUO'
            MatchType = 'EQUALS'
            Pattern = 'Campylobacter POSITIVE;Salmonella POSITIVE;STEC stx1 POSITIVE;STEC stx2 POSITIVE;Shigella EIEC POSITIVE;V. cholerae POSITIVE;V. parahaemolyticus POSITIVE;Yersinia POSITIVE;Cryptosporidium POSITIVE;Giardia POSITIVE;Norovirus POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0141'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GX HCV SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'HCV IUO'
            MatchType = 'EQUALS'
            Pattern = 'HCV DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0142'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB XDR SampleType 2'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MTB-XDR IUO'
            MatchType = 'EQUALS'
            Pattern = 'MTB DETECTED;INH Resistance DETECTED;FLQ Resistance DETECTED;AMK Resistance DETECTED;KAN Resistance DETECTED;CAP Resistance DETECTED;ETH Resistance DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0143'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec FLUVID plus SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpress SARS-CoV-2_Flu_RSV plus'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE;Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0144'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB XDR SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MTB-XDR IUO'
            MatchType = 'EQUALS'
            Pattern = 'MTB NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0145'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec C.DIFF SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert C.difficile BT'
            MatchType = 'EQUALS'
            Pattern = 'Toxigenic C.diff NEG;Binary Toxin NEG;027 NEG'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0146'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec C.DIFF SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert C.difficile G3'
            MatchType = 'EQUALS'
            Pattern = 'Toxigenic C.diff NEGATIVE;027 PRESUMPTIVE NEG'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0147'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec C.DIFF SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert C.difficile G3'
            MatchType = 'EQUALS'
            Pattern = 'Toxigenic C.diff POSITIVE;027 PRESUMPTIVE POS'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0148'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec CTNG SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert CT_CE'
            MatchType = 'EQUALS'
            Pattern = 'CT DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0149'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec CTNG SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert CT_CE'
            MatchType = 'EQUALS'
            Pattern = 'CT NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0150'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec CTNG SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert CT_NG'
            MatchType = 'EQUALS'
            Pattern = 'CT DETECTED;NG DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0151'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec CTNG SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert CT_NG'
            MatchType = 'EQUALS'
            Pattern = 'CT NOT DETECTED;NG NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0152'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec CARBA SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Carba-R'
            MatchType = 'EQUALS'
            Pattern = 'IMP1 DETECTED;VIM DETECTED;NDM DETECTED;KPC DETECTED;OXA48 DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0153'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec CARBA SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Carba-R'
            MatchType = 'EQUALS'
            Pattern = 'IMP1 NOT DETECTED;VIM NOT DETECTED;NDM NOT DETECTED;KPC NOT DETECTED;OXA48 NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0154'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec EBOLA SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Ebola CE-IVD'
            MatchType = 'EQUALS'
            Pattern = 'Ebola GP DETECTED;Ebola NP DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0155'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec EBOLA SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Ebola CE-IVD'
            MatchType = 'EQUALS'
            Pattern = 'Ebola GP NOT DETECTED;Ebola NP NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0156'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec EBOLA SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Ebola EUA'
            MatchType = 'EQUALS'
            Pattern = 'Ebola GP DETECTED;Ebola NP DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0157'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec EBOLA SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert Ebola EUA'
            MatchType = 'EQUALS'
            Pattern = 'Ebola GP NOT DETECTED;Ebola NP NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0158'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GBS XC SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert GBS LB XC'
            MatchType = 'EQUALS'
            Pattern = 'GBS NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0159'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GBS XC SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert GBS LB XC'
            MatchType = 'EQUALS'
            Pattern = 'GBS POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0160'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GI Panel SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert GI Panel'
            MatchType = 'EQUALS'
            Pattern = 'Campylobacter NEGATIVE;Salmonella NEGATIVE;STEC stx1 NEGATIVE;STEC stx2 NEGATIVE;Shigella EIEC NEGATIVE;V. cholerae NEGATIVE;V. parahaemolyticus NEGATIVE;Yersinia NEGATIVE;Cryptosporidium NEGATIVE;Giardia NEGATIVE;Norovirus NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0161'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GI Panel SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert GI Panel'
            MatchType = 'EQUALS'
            Pattern = 'Campylobacter POSITIVE;Salmonella POSITIVE;STEC stx1 POSITIVE;STEC stx2 POSITIVE;Shigella EIEC POSITIVE;V. cholerae POSITIVE;V. parahaemolyticus POSITIVE;Yersinia POSITIVE;Cryptosporidium POSITIVE;Giardia POSITIVE;Norovirus POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0162'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GI Panel SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert GI Panel CE-IVD'
            MatchType = 'EQUALS'
            Pattern = 'Campylobacter NEGATIVE;Salmonella NEGATIVE;STEC stx1 NEGATIVE;STEC stx2 NEGATIVE;Shigella EIEC NEGATIVE;V. cholerae NEGATIVE;V. parahaemolyticus NEGATIVE;Yersinia NEGATIVE;Cryptosporidium NEGATIVE;Giardia NEGATIVE;Norovirus NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0163'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec GI Panel SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert GI Panel CE-IVD'
            MatchType = 'EQUALS'
            Pattern = 'Campylobacter POSITIVE;Salmonella POSITIVE;STEC stx1 POSITIVE;STEC stx2 POSITIVE;Shigella EIEC POSITIVE;V. cholerae POSITIVE;V. parahaemolyticus POSITIVE;Yersinia POSITIVE;Cryptosporidium POSITIVE;Giardia POSITIVE;Norovirus POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0164'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec HBV VL SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert HBV Viral Load'
            MatchType = 'EQUALS'
            Pattern = 'HBV NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0165'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec C.DIFF SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert C.difficile BT'
            MatchType = 'EQUALS'
            Pattern = 'Toxigenic C.diff POS;Binary Toxin POS;027 PRESUMPTIVE POS'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0166'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec C.DIFF SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert C.diff-Epi'
            MatchType = 'EQUALS'
            Pattern = 'Toxigenic C.diff POSITIVE;027 PRESUMPTIVE POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0167'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB XDR SampleType 2'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MTB-XDR RUO'
            MatchType = 'EQUALS'
            Pattern = 'MTB DETECTED;INH Resistance DETECTED;FLQ Resistance DETECTED;AMK Resistance DETECTED;KAN Resistance DETECTED;CAP Resistance DETECTED;ETH Resistance DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0168'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec C.DIFF SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Xpert C.diff-Epi'
            MatchType = 'EQUALS'
            Pattern = 'Toxigenic C.diff NEGATIVE;027 PRESUMPTIVE NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0169'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB XDR SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MTB-XDR RUO'
            MatchType = 'EQUALS'
            Pattern = 'MTB DETECTED;INH Resistance NOT DETECTED;FLQ Resistance NOT DETECTED;AMK Resistance NOT DETECTED;KAN Resistance NOT DETECTED;CAP Resistance NOT DETECTED;ETH Resistance NOT DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0170'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec MTB XDR SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'MTB-XDR RUO'
            MatchType = 'EQUALS'
            Pattern = 'MTB NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0171'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Respiratory Panel SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Respiratory Panel IUO'
            MatchType = 'EQUALS'
            Pattern = 'Adenovirus NEGATIVE;Coronavirus NEGATIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza NEGATIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0172'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Respiratory Panel SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Respiratory Panel RUO'
            MatchType = 'EQUALS'
            Pattern = 'Adenovirus NEGATIVE;Coronavirus NEGATIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza NEGATIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0173'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Respiratory Panel SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Respiratory panel'
            MatchType = 'EQUALS'
            Pattern = 'Adenovirus NEGATIVE;Coronavirus NEGATIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza NEGATIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0174'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Respiratory Panel SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Respiratory panel CE-IVD'
            MatchType = 'EQUALS'
            Pattern = 'Adenovirus NEGATIVE;Coronavirus NEGATIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza NEGATIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0175'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec Respiratory Panel SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'Respiratory panel UKCA-IVD'
            MatchType = 'EQUALS'
            Pattern = 'Adenovirus NEGATIVE;Coronavirus NEGATIVE;SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;hMPV NEGATIVE;Parainfluenza NEGATIVE;Rhino-Enterovirus NEGATIVE;RSV NEGATIVE;B. parapertussis NEGATIVE;B. pertussis NEGATIVE;Chlam. pneumoniae NEGATIVE;Myco. pneumoniae NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0176'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec FLUVID plus SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'SARS-CoV-2_Flu_RSV plus IUO'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0177'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec FLUVID plus SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'SARS-CoV-2_Flu_RSV plus IUO'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE;Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0178'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec FLUVID plus SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'SARS-CoV-2_Flu_RSV plus RUO'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0179'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec FLUVID plus SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'SARS-CoV-2_Flu_RSV plus RUO'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE;Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0180'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec FLUVID plus SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'SARS-CoV-2_Flu_RSV_plus'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 NEGATIVE;Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0181'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec FLUVID plus SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'SARS-CoV-2_Flu_RSV_plus'
            MatchType = 'EQUALS'
            Pattern = 'SARS-CoV-2 POSITIVE;Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0182'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec TAP Panel SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'TAP Panel IUO'
            MatchType = 'EQUALS'
            Pattern = 'Ft DETECTED;Ba DETECTED;Yp DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0183'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec TAP Panel SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'TAP Panel IUO'
            MatchType = 'EQUALS'
            Pattern = 'Ft NOT DETECTED;Ba NOT DETECTED;Yp NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0184'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec TAP Panel SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'TAP Panel RUO'
            MatchType = 'EQUALS'
            Pattern = 'Ft DETECTED;Ba DETECTED;Yp DETECTED'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0185'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec TAP Panel SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'TAP Panel RUO'
            MatchType = 'EQUALS'
            Pattern = 'Ft NOT DETECTED;Ba NOT DETECTED;Yp NOT DETECTED'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0186'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec FLU RSV SampleType 0'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'XP Flu-RSV RUO'
            MatchType = 'EQUALS'
            Pattern = 'Flu A NEGATIVE;Flu B NEGATIVE;RSV NEGATIVE'
            Call = 'NEG'
            Enabled = $true
            Priority = 9000
        }
        @{
            RuleId = 'RCP-0187'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Spec FLU RSV SampleType 1'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = 'XP Flu-RSV RUO'
            MatchType = 'EQUALS'
            Pattern = 'Flu A POSITIVE;Flu B POSITIVE;RSV POSITIVE'
            Call = 'POS'
            Enabled = $true
            Priority = 9000
        }
    )
}
