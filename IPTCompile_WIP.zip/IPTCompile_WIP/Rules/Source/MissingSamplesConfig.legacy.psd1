# RuleBank v2 source: MissingSamplesConfig
@{
    SchemaVersion = 2
    Table = 'MissingSamplesConfig'
    Rules = @(
        @{
            RuleId = 'MSC-0001'
            Version = 1
            Source = 'legacy-import'
            LastUpdated = '2026-03-13'
            Notes = 'Default bag/sample expectation (Bag0=1..10; Bags1-10=1..20)'
            CaseInsensitive = $true
            StopProcessing = $true
            AssayPattern = '*'
            Bag0SampleMin = 1
            Bag0SampleMax = 10
            BagMin = 0
            BagMax = 10
            OtherBagSampleMin = 1
            OtherBagSampleMax = 20
            SampleNumberPad = 2
            SampleNumberRegex = '\d+'
            TokenSampleIdSplitIndex = 1
            Enabled = $false
            Priority = 100
        }
    )
}
