# RuleBank v2 metadata
@{
    SchemaVersion = 2
    RuleBankVersion = '2.0.0'
    Source = 'RuleBank v2 source'
    LastUpdated = '2026-03-13'
    Notes = @(
        'Seeded from a compiled RuleBank artifact during the consolidation pass.'
        'QuantSpecRules intentionally omitted from source schema; compiler emits empty legacy placeholder only.'
        'DELAMINATION Data Summary-evidens remains outside RuleBank and is not duplicated here.'
    )
}
