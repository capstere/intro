﻿function Find-ObservationCol { param($ws)
    $default = 13
    if (-not $ws -or -not $ws.Dimension) { return $default }
    $maxR = [Math]::Min(5, $ws.Dimension.End.Row)
    $maxC = $ws.Dimension.End.Column

    for ($r=1; $r -le $maxR; $r++) {
        for ($c=1; $c -le $maxC; $c++) {
            $t = ($ws.Cells[$r,$c].Text + '').Trim()
            if ($t -match '^(?i)\s*(obs|observation)') { return $c }
        }
    }
    return $default
}

function Test-IsWorksheetHeaderSkipSheet {
    param([string]$SheetName)
    if ([string]::IsNullOrWhiteSpace($SheetName)) { return $false }
    if ($SheetName -match '(?i)^\s*Worksheet\s*Instructions\s*$') { return $true }
    if ($SheetName -match '(?i)for reference only') { return $true }
    # QC Data saknar i vissa VL-mallar konsekvent jämförbart headerinnehåll; exkluderas explicit.
    if ($SheetName -match '(?i)^\s*QC\s+Data\s*$') { return $true }
    return $false
}

function Get-TestSummaryEquipmentFromWorksheet {
    param(
        [object]$Worksheet
    )

    $result = [pscustomobject]@{
        WorksheetName = $null
        Pipettes      = @()
        Instruments   = @()
    }

    if (-not $Worksheet -or -not $Worksheet.Dimension) {
        return $result
    }

    $result.WorksheetName = $Worksheet.Name

    $maxR = $Worksheet.Dimension.End.Row
    $maxC = $Worksheet.Dimension.End.Column
    $maxR = [Math]::Min($maxR, 350)
    $maxC = [Math]::Min($maxC, 40)
    $getCellText = {
        param(
            $Ws,
            [int]$Row,
            [int]$Col
        )
        if ($Row -le 0 -or $Col -le 0) { return '' }
        if (-not $Ws.Dimension) { return '' }
        $t = $Ws.Cells[$Row,$Col].Text
        if ($t) { return $t.Trim() }
        return ''
    }
    $excelDateBase = Get-Date '1899-12-30'
    $resolveDueCellValue = {
        param($Cell)

        if (-not $Cell) { return $null }

        $dueVal = $Cell.Value
        if ($dueVal -is [datetime]) {
            return $dueVal
        }

        if ($dueVal -is [double] -or $dueVal -is [int]) {
            try {
                return $excelDateBase.AddDays([double]$dueVal)
            } catch {
                $fallback = ($Cell.Text + '').Trim()
                if ($fallback) { return $fallback }
                return $null
            }
        }

        $txt = ($Cell.Text + '').Trim()
        if ($txt) { return $txt }
        return $null
    }
    $dedupeEquipmentById = {
        param([object[]]$Items)

        if (-not $Items -or $Items.Count -eq 0) { return @() }

        $uniq = New-Object System.Collections.Generic.List[object]
        $seen = @{}
        foreach ($item in $Items) {
            if (-not $item -or -not $item.Id) { continue }
            if ($seen.ContainsKey($item.Id)) { continue }
            $seen[$item.Id] = $true
            [void]$uniq.Add($item)
        }
        return @($uniq.ToArray())
    }

    $pipHeaderRows = New-Object 'System.Collections.Generic.List[int]'
    for ($r = 1; $r -le $maxR; $r++) {
        $txt = & $getCellText $Worksheet $r 1
        if (-not $txt) { continue }

        if ($txt -match '(?i)table\s*2\b.*pipett(e)?\b') {
            [void]$pipHeaderRows.Add($r)
        }
    }

    $pipPairs = New-Object System.Collections.Generic.List[object]

    foreach ($hdrRow in $pipHeaderRows) {
        $searchMax = [Math]::Min($maxR, $hdrRow + 12)

        for ($r = $hdrRow + 1; $r -le $searchMax; $r++) {
            $label = & $getCellText $Worksheet $r 1
            if ($label -match '(?i)cepheid\s*id') {

                $calRow = $null
                for ($cRow = $r + 1; $cRow -le [Math]::Min($maxR, $r + 6); $cRow++) {
                    $lab2 = & $getCellText $Worksheet $cRow 1
                    if ($lab2 -match '(?i)calibration\s+due\s+date') {
                        $calRow = $cRow
                        break
                    }
                }

                if ($calRow) {
                    [void]$pipPairs.Add([pscustomobject]@{
                        IdRow  = $r
                        CalRow = $calRow
                    })
                }
            }
        }
    }

    $pipettes = New-Object System.Collections.Generic.List[object]

    $pipetteIdRegex = '(?i)\b(?:nr|no)\.?\s*\d+\b'

    foreach ($pair in $pipPairs) {
        for ($c = 2; $c -le $maxC; $c += 2) {
            $idTxt = & $getCellText $Worksheet $pair.IdRow $c
            if (-not $idTxt) { continue }

            if ($idTxt -match '^(?i)N/?A$') { continue }
            if ($idTxt -notmatch $pipetteIdRegex) { continue }

            $dueOut = & $resolveDueCellValue $Worksheet.Cells[$pair.CalRow,$c]

            [void]$pipettes.Add([pscustomobject]@{
                Id                 = $idTxt
                CalibrationDueDate = $dueOut
            })
        }
    }

    $pipettes = & $dedupeEquipmentById $pipettes.ToArray()

    $result.Pipettes = $pipettes

    $instHeaderRows = New-Object 'System.Collections.Generic.List[int]'
    for ($r = 1; $r -le $maxR; $r++) {
        $txt = & $getCellText $Worksheet $r 1
        if (-not $txt) { continue }
        if ($txt -match '(?i)table\s*3\b.*(gene\s*experts?|genexperts?|genex?perts?|infinitys?)') {
            [void]$instHeaderRows.Add($r)
        }
    }

    $instPairs = New-Object System.Collections.Generic.List[object]

    foreach ($hdrRow in $instHeaderRows) {
        $searchMax = [Math]::Min($maxR, $hdrRow + 20)

        for ($r = $hdrRow + 1; $r -le $searchMax; $r++) {
            $label = & $getCellText $Worksheet $r 1
            if ($label -match '(?i)cepheid\s*id') {

                $calRow = $null
                for ($cRow = $r + 1; $cRow -le [Math]::Min($maxR, $r + 6); $cRow++) {
                    $lab2 = & $getCellText $Worksheet $cRow 1
                    if ($lab2 -match '(?i)calibration\s+due\s+date') {
                        $calRow = $cRow
                        break
                    }
                }

                if ($calRow) {
                    [void]$instPairs.Add([pscustomobject]@{
                        IdRow  = $r
                        CalRow = $calRow
                    })
                }
            }
        }
    }

    $insts = New-Object System.Collections.Generic.List[object]

    foreach ($pair in $instPairs) {
        for ($c = 2; $c -le $maxC; $c += 2) {
            $idTxt = & $getCellText $Worksheet $pair.IdRow $c
            if (-not $idTxt) { continue }
            if ($idTxt -match '^(?i)N/?A$') { continue }

            if ($idTxt -notmatch '(?i)^(infinity|gx\s*\d+|gx\d+)') {
                continue
            }

            $dueOut = & $resolveDueCellValue $Worksheet.Cells[$pair.CalRow,$c]

            [void]$insts.Add([pscustomobject]@{
                Id                 = $idTxt
                CalibrationDueDate = $dueOut
            })
        }
    }

    $insts = & $dedupeEquipmentById $insts.ToArray()

    $result.Instruments = $insts

    return $result
}

function Get-TestSummaryEquipment {
    param(
        [object]$Pkg
    )

    $empty = [pscustomobject]@{
        WorksheetName = $null
        Pipettes      = @()
        Instruments   = @()
    }

    if (-not $Pkg) { return $empty }

    $best = $null

    try {
        foreach ($ws in $Pkg.Workbook.Worksheets) {
            if (-not $ws.Dimension) { continue }
            if ($ws.Name -match '(?i)worksheet\s*instructions') { continue }

            $info = Get-TestSummaryEquipmentFromWorksheet -Worksheet $ws
            if (-not $info) { continue }

            $pipCount  = if ($info.Pipettes)   { $info.Pipettes.Count }   else { 0 }
            $instCount = if ($info.Instruments){ $info.Instruments.Count } else { 0 }

            if (-not $best) { $best = $info }

            if ($pipCount -gt 0 -or $instCount -gt 0) {
                if ($ws.Name -match '(?i)test\s*summary') {
                    return $info
                }
                $best = $info
            }
        }
    } catch {
        return $empty
    }

    if ($best) { return $best }
    return $empty
}

function Parse-WorksheetHeaderRaw {
    param(
        [string]$Raw
    )
    $obj = [pscustomobject]@{
        PartNo         = $null
        BatchNo        = $null
        CartridgeNo    = $null
        DocumentNumber = $null
        Attachment     = $null
        Rev            = $null
        Effective      = $null
    }
    if (-not $Raw) { return $obj }

    $txt = $Raw + ''
    $txt = $txt -replace '&P', ''
    $txt = $txt -replace '&N', ''
    $txt = $txt -replace '&L', ' '
    $txt = Normalize-HeaderText $txt
    $m = [regex]::Match(
        $txt,
        '(?i)\bDocument\s*Number\b\s*[:#]?\s*(D\d{5})(?:\s+Attachment[:\s]+([0-9A-Za-z\.]+))?'
    )
    if ($m.Success) {
        $obj.DocumentNumber = $m.Groups[1].Value.Trim()
        if ($m.Groups.Count -ge 3 -and $m.Groups[2].Value) {
            $obj.Attachment = $m.Groups[2].Value.Trim()
        }
    }
    if (-not $obj.Attachment) {
        $m = [regex]::Match($txt, '(?i)\bAttachment\b\s*:?\s*([0-9A-Za-z\.]+)')
        if ($m.Success) {
            $obj.Attachment = $m.Groups[1].Value.Trim()
        }
    }
		
    $m = [regex]::Match(
    $txt,
    '(?i)\bRev(?:ision)?\.?\s*[:#]?\s*([A-Z0-9]{1,3}(?:\.[0-9]+)?)\b')
    if ($m.Success) {
    $obj.Rev = $m.Groups[1].Value.Trim()
    }
			
    $m = [regex]::Match($txt, '(\d{1,2}/\d{1,2}/\d{4})')
    if ($m.Success) {
        $obj.Effective = $m.Groups[1].Value.Trim()
    }

    $m = [regex]::Match($txt, '(?i)Part\s*No\.\s*:\s*([0-9A-Z\-]+)')
    if ($m.Success) {
        $obj.PartNo = $m.Groups[1].Value.Trim()
    }
    $m = [regex]::Match($txt, '(?i)Batch\s*(?:No(?:\(s\))?|Number(?:\(s\))?)\.?\s*:\s*(\d{6,12})')
    if ($m.Success) {
        $obj.BatchNo = $m.Groups[1].Value.Trim()
    }
    $m = [regex]::Match($txt, '(?i)Cartridge\s*No\.\s*\(LSP\)\s*:\s*(\d{5,7})')
    if ($m.Success) {
        $obj.CartridgeNo = $m.Groups[1].Value.Trim()
    }
    return $obj
}

function Try-Parse-HeaderDate {
    param([object]$cellValue, [ref]$out)
    $out.Value = $null
    if ($null -eq $cellValue) { return $false }
    if ($cellValue -is [double] -or $cellValue -is [int]) {
        try { $out.Value = [DateTime]::FromOADate([double]$cellValue); return $true } catch {}
    }
    if ($cellValue -is [DateTime]) { $out.Value = [DateTime]$cellValue; return $true }
    $s = Normalize-HeaderText ([string]$cellValue)
    if ([string]::IsNullOrWhiteSpace($s)) { return $false }
    $cultures = @('sv-SE','en-US','en-GB')
    foreach ($c in $cultures) {
        try {
            $dt = [DateTime]::Parse($s, [Globalization.CultureInfo]::GetCultureInfo($c), [Globalization.DateTimeStyles]::AssumeLocal)
            $out.Value = $dt; return $true
        } catch {}
    }
    $formats = @(
        'yyyy-MM-dd','yyyy/MM/dd','dd/MM/yyyy','d/M/yyyy','MM/dd/yyyy','M/d/yyyy',
        'dd-MM-yyyy','d-M-yyyy','dd.M.yyyy','d.M.yyyy','dd-MMM-yyyy','MMM-yy'
    )
    foreach ($fmt in $formats) {
        try {
            $dt = [DateTime]::ParseExact($s, $fmt, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::AssumeLocal)
            $out.Value = $dt; return $true
        } catch {}
    }
    return $false
}

function Get-ConsensusValue {
    param(
        [string]$Ws,  [string]$Pos, [string]$Neg,
        [ValidateSet('Batch','Part','Cartridge')] [string]$Type
    )

    $nWs  = Normalize-Id $Ws  $Type
    $nPos = Normalize-Id $Pos $Type
    $nNeg = Normalize-Id $Neg $Type
    $present = @{}
    if ($nWs)  { $present['WS']  = $nWs  }
    if ($nPos) { $present['POS'] = $nPos }
    if ($nNeg) { $present['NEG'] = $nNeg }
    $chosenNorm = $null
    $sources    = New-Object System.Collections.Generic.List[string]
    $counts = @{}
    foreach ($k in $present.Keys) {
        $val = $present[$k]
        if (-not $counts.ContainsKey($val)) { $counts[$val] = 0 }
        $counts[$val] = [int]$counts[$val] + 1
    }
    $maxCount = 0; $maxVal = $null
    foreach ($kv in $counts.GetEnumerator()) {
        if ($kv.Value -gt $maxCount) { $maxCount = $kv.Value; $maxVal = $kv.Key }
    }
    if ($maxCount -ge 2) {
        $chosenNorm = $maxVal
        foreach ($k in $present.Keys) { if ($present[$k] -eq $chosenNorm) { [void]$sources.Add([string]$k) } }
    }
    if (-not $chosenNorm -and $nWs) {
        $posMatch = ($nPos -and $nPos -eq $nWs)
        $negMatch = ($nNeg -and $nNeg -eq $nWs)
        if (($posMatch -and -not $negMatch) -or ($negMatch -and -not $posMatch)) {
            $chosenNorm = $nWs
            $sources = New-Object System.Collections.Generic.List[string]
            [void]$sources.Add('WS')
            if ($posMatch) { [void]$sources.Add('POS') }
            if ($negMatch) { [void]$sources.Add('NEG') }
        }
    }
    if (-not $chosenNorm -and $nPos -and $nNeg -and $nPos -eq $nNeg) {
        $chosenNorm = $nPos
        $sources = New-Object System.Collections.Generic.List[string]
        [void]$sources.Add('POS')
        [void]$sources.Add('NEG')
    }
    if (-not $chosenNorm) {
        if ($nWs)      { $chosenNorm = $nWs;  $sources = New-Object System.Collections.Generic.List[string]; [void]$sources.Add('WS')  }
        elseif ($nPos) { $chosenNorm = $nPos; $sources = New-Object System.Collections.Generic.List[string]; [void]$sources.Add('POS') }
        elseif ($nNeg) { $chosenNorm = $nNeg; $sources = New-Object System.Collections.Generic.List[string]; [void]$sources.Add('NEG') }
    }
    $orig = @{ WS=$Ws; POS=$Pos; NEG=$Neg }
    $pretty = $null
    foreach ($pref in @('WS','POS','NEG')) {
        if ($present.ContainsKey($pref) -and $present[$pref] -eq $chosenNorm) { $pretty = $orig[$pref]; break }
    }
    $note = $null
    if ($sources -and $sources.Count -gt 0) {
        $note = "Consensus: " + (@($sources) -join '+')
        $others = New-Object System.Collections.Generic.List[string]
        foreach ($k in @('WS','POS','NEG')) {
            if ($present.ContainsKey($k) -and (@($sources) -notcontains $k)) {
                $val = $orig[$k]
                if (-not [string]::IsNullOrEmpty($val)) { [void]$others.Add(($k + '=' + $val)) }
            }
        }
        if ($others.Count -gt 0) { $note += " | Others: " + (@($others) -join ', ') }
    }
    return @{ Value=$pretty; Source=(@($sources) -join '+'); Note=$note }
}
