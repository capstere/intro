# IPTCompile handoff to Codex — v1.4.0-consolidated-safe

## Kort status
- **Senast användarverifierade stabila version:** `IPTCompile-v1.3.7-phase11-safe`
- **Nuvarande paket att skicka till Codex:** `IPTCompile-v1.4.0-consolidated-safe`
- **Vad v1.4.0 är:** en **mekanisk konsolidering** ovanpå `v1.3.7-phase11-safe` där rena shim-filer togs bort och `Main.ps1` i stället laddar de riktiga split-filerna direkt.
- **Vad Codex bör utgå från:** funktionellt tänk som i `v1.3.7-phase11-safe`, men filplacering enligt `v1.4.0-consolidated-safe`.
- **Fas 12 (`v1.3.8-phase12-safe`) sprack på path/root-regression** och ska **ignoreras** som bas.

## Vad som faktiskt gjorts i refactoren

### Fas 5
Split av Logging + SignatureHelpers, bakom shim.
- `Infrastructure/LoggingCore.ps1`
- `App/UiLogging.ps1`
- `Core/SignatureWorkflow.ps1`
- `App/UiSignatureDialogs.ps1`
- `Infrastructure/Forensics.ps1`

### Fas 6
Split av OpenXML, bakom shim.
- `Infrastructure/ExcelOpenXml.ps1`
- `Core/OpenXmlSignatureWorkflow.ps1`

### Fas 7
Split av RuleEngine, bakom shim.
- `Core/RuleEngineCore.ps1`
- `Core/RuleEngineDebug.ps1`

### Fas 8
Split av `Modules/DataHelpers.ps1`, bakom shim.
- `Infrastructure/ExcelEpplus.ps1`
- `Infrastructure/Csv.ps1`
- `Infrastructure/FileStaging.ps1`
- `Core/AssayNormalization.ps1`
- `Core/HeaderParsing.ps1`
- `Core/OutputPlanning.ps1`

### Fas 8 hotfix 1
Återställde top-level mapping/index state som hör till `Get-ControlTabName` och `Get-MinitabMacro`:
- `$AssayMap`
- `$AssayIndex`
- `$MinitabMap`
- `$MinitabIndex`
- null-guards kring `.ContainsKey(...)`

### Fas 8b hotfix 1
Viktig lärdom: vissa delar i `DataHelpers.ps1` måste flyttas som **sammanhängande block**, inte som lösa funktionsnamn.
Återställde header-/compare-blocket som en enhet i:
- `Core/HeaderComparison.ps1`

Detta block innehåller:
- `Extract-WorksheetHeader`
- `Get-WorksheetHeaderPerSheet`
- `Compare-WorksheetHeaderSet`
- `Get-SealTestHeaderPerSheet`
- `Compare-SealTestHeaderSet`
- `Extract-SealTestHeader`
- den lokala inbäddade hjälpfunktionen `_canonWorksheet` inne i `Compare-WorksheetHeaderSet`

### Fas 9
Safe slimming av `Main.ps1` — rena hjälpfunktioner lyftes ut till `App/*`, men all top-level UI/runtime lämnades kvar.
Nya/ifyllda App-filer:
- `App/UiHelpers.ps1`
- `App/Bootstrap.ps1`
- `App/UiDialogs.ps1`
- `App/BuildController.ps1`
- `App/UiTheme.ps1`

### Fas 10
Fler rena hjälpfunktioner ut ur `Main.ps1`.
Till `Core/OutputPlanning.ps1`:
- `_IsActiveSealSheet`
- `_GetPerSheetValueObjects`
- `_AggregateStatus`

Till `App/UiHelpers.ps1`:
- `Update-OverwriteVerificationUI`
- `Enable-DoubleBuffer`

### Fas 11
Sista funktionsdefinitionen ut ur `Main.ps1`.
- Ny fil: `App/EarlyGuards.ps1`
- Flyttad funktion: `Test-IsBlockedUser`

Resultat efter fas 11:
- `Main.ps1` innehåller **inga egna funktionsdefinitioner** längre.
- `Main.ps1` är i praktiken entrypoint/bootstrap + UI composition + event wiring.

### v1.4.0 consolidated-safe
Konsolidering ovanpå `v1.3.7-phase11-safe`.
- `Main.ps1` laddar nu de riktiga split-filerna direkt från `App/`, `Core/`, `Infrastructure/`
- Följande rena shim-filer togs bort från `Modules/`:
  - `Modules/Logging.ps1`
  - `Modules/DataHelpers.ps1`
  - `Modules/SignatureHelpers.ps1`
  - `Modules/OpenXmlHelpers.ps1`
  - `Modules/RuleEngine.ps1`
- Följande "riktiga" moduler blev kvar i `Modules/`:
  - `Config.ps1`
  - `SharePointClient.ps1`
  - `Splash.ps1`
  - `UiStyling.ps1`

## Aktuell filstruktur i v1.4.0-consolidated-safe

### Root
- `Main.ps1`
- `Version.txt`
- `output_template-v4.xlsx`
- `StatusBoard.psd1`
- `Rules/RuleBank.compiled.ps1`
- `Lib/EPPlus.dll`
- `Lib/DocumentFormat.OpenXml.dll`

### Modules/
Detta är kvar som "verkliga" moduler, inte shim:
- `Modules/Config.ps1`
- `Modules/SharePointClient.ps1`
- `Modules/Splash.ps1`
- `Modules/UiStyling.ps1`

### App/
UI-, bootstrap- och användarflödeshjälpare:
- `App/EarlyGuards.ps1`
- `App/UiLogging.ps1`
- `App/UiSignatureDialogs.ps1`
- `App/UiHelpers.ps1`
- `App/Bootstrap.ps1`
- `App/BuildController.ps1`
- `App/UiDialogs.ps1`
- `App/UiTheme.ps1`

### Core/
Domän- och workflownära logik:
- `Core/SignatureWorkflow.ps1`
- `Core/OpenXmlSignatureWorkflow.ps1`
- `Core/RuleEngineCore.ps1`
- `Core/RuleEngineDebug.ps1`
- `Core/AssayNormalization.ps1`
- `Core/HeaderParsing.ps1`
- `Core/HeaderComparison.ps1`
- `Core/OutputPlanning.ps1`

### Infrastructure/
IO, Excel, staging, logging, forensics:
- `Infrastructure/LoggingCore.ps1`
- `Infrastructure/Forensics.ps1`
- `Infrastructure/ExcelOpenXml.ps1`
- `Infrastructure/ExcelEpplus.ps1`
- `Infrastructure/Csv.ps1`
- `Infrastructure/FileStaging.ps1`

## Nuvarande load order i Main.ps1 (v1.4.0)
`Main.ps1` laddar i denna ordning:
1. `App/EarlyGuards.ps1`
2. `Modules/Config.ps1`
3. `Modules/Splash.ps1`
4. `Modules/SharePointClient.ps1`
5. `Modules/UiStyling.ps1`
6. `Infrastructure/LoggingCore.ps1`
7. `App/UiLogging.ps1`
8. `Infrastructure/ExcelEpplus.ps1`
9. `Infrastructure/Csv.ps1`
10. `Infrastructure/FileStaging.ps1`
11. `Core/AssayNormalization.ps1`
12. `Core/HeaderParsing.ps1`
13. `Core/HeaderComparison.ps1`
14. `Core/OutputPlanning.ps1`
15. `Core/SignatureWorkflow.ps1`
16. `App/UiSignatureDialogs.ps1`
17. `Infrastructure/Forensics.ps1`
18. `Infrastructure/ExcelOpenXml.ps1`
19. `Core/OpenXmlSignatureWorkflow.ps1`
20. `Core/RuleEngineCore.ps1`
21. `Core/RuleEngineDebug.ps1`
22. `App/UiHelpers.ps1`
23. `App/Bootstrap.ps1`
24. `App/UiDialogs.ps1`
25. `App/BuildController.ps1`
26. `App/UiTheme.ps1`

## Viktiga tekniska lärdomar för Codex
1. **Flytta inte top-level WinForms/runtime-block lättvindigt.**
   Det var därför den första stora refactor-kopian sprack.
2. **DataHelpers var inte bara en lista av rena funktioner.**
   Den innehöll:
   - top-level state/tabeller
   - sammanhängande compare/header-block
   - lokala inbäddade hjälpfunktioner
3. **Header compare-zonen måste behandlas som ett sammanhängande block.**
4. **Main.ps1 är fortfarande stor**, men efter fas 11 är den i princip fri från egna helperfunktioner; det som är kvar är främst:
   - startup/runtime
   - layout/UI composition
   - event wiring
   - build/scan orchestration som fortfarande ligger top-level
5. **v1.4.0 är mer begriplig än shim-läget**, men den underliggande logiken är i princip samma som `v1.3.7-phase11-safe`.

## Vad Codex ska veta om DELAMINATION-arbetet
Det du redan hade från Codex före moduleringen var i sak detta:
- Om `DELAMINATION` finns i kolumn C på:
  - `Data Summary`
  - `Resample Data Summary`
  - `Extra Data Summary`
- så ska det tolkas som:
  - `Minor Functional (Delamination)`

Det du fått från tidigare Codex-analys var att den logiken redan följdes i pre-modulär kod, ungefär genom:
- insamling av DS-fynd från summary-flikarna i `Main.ps1`
- matchning mellan DS-rad och CSV-rad i regelmotorn, även via förkortad/tail-baserad matchning
- promotion av korrekt CSV-rad till `Minor Functional (Delamination)`

## Var Codex bör leta i v1.4.0 för detta
Eftersom koden nu är omplacerad bör Codex primärt kontrollera dessa filer:

### 1. Main summary-insamling
- `Main.ps1`
- sök på `DELAMINATION` och på läsning av:
  - `Data Summary`
  - `Resample Data Summary`
  - `Extra Data Summary`

### 2. Global pattern config
- `Modules/Config.ps1`
  - där finns delamination-pattern med scope `All`

### 3. Rule engine / promotion
- `Core/RuleEngineCore.ps1`
  - sök på `Delam`, `Minor Functional (Delamination)`, `Get-ErrorInfo`, `Get-SampleTokenAndBase`, `Parse-SampleIdBasic`
- `Rules/RuleBank.compiled.ps1`
  - här finns globala delamination-markörer, bl.a. regex för delaminationkod i Sample ID

## Rekommenderat uppdrag till Codex
"Utgå från `IPTCompile-v1.4.0-consolidated-safe`, men tolka strukturförändringarna som filflyttar, inte som ändrad affärslogik. Implementera eller verifiera global promotion så att `DELAMINATION` i kolumn C på `Data Summary`, `Resample Data Summary` och `Extra Data Summary` ger `Minor Functional (Delamination)` på korrekt CSV-rad, inklusive tail-/förkortad SampleID-matchning. Bevara nuvarande PowerShell 5.1 + EPPlus 4.5.3.3-kompatibilitet och flytta inte top-level WinForms/event wiring ur `Main.ps1`."

## Kort sammanfattning till Codex
- Senast fullt verifierade bas: `v1.3.7-phase11-safe`
- Strukturen du får nu: `v1.4.0-consolidated-safe`
- Shim-lagret är borttaget för Logging/DataHelpers/Signature/OpenXml/RuleEngine
- Kodens riktiga hem är nu `App/`, `Core/`, `Infrastructure/`
- `Modules/` innehåller bara kvarvarande riktiga moduler
- `Main.ps1` är fortfarande runtime-navet
- Header-/compare-logik i `Core/HeaderComparison.ps1` måste behandlas varsamt som block
- `OutputPlanning.ps1` innehåller även top-level mapping/index state som inte får tappas bort
