PQC/GX Sample ID AutoNavigator v1

Purpose
-------
Proof-of-concept PowerShell 5.1 background helper.

It lets the scanner use normal plain Sample ID barcodes only.
The script detects the Sample ID in the keyboard stream and then sends the GX navigation sequence.

Default behavior
----------------
Example scanned barcode:
121725MMM_01_2_19X

Script detects:
- Sample Type 0 -> N
- Sample Type 1 -> P
- Sample Type 2 -> PP

Default SendKeys sequence after one pause:
{TAB 6}{SPACE}N/P/PP{SPACE}{TAB 4}{SPACE}

Hotkeys
-------
F8 = Toggle automation ON/OFF
F9 = Toggle SelectionMode Letters/DownArrows
Ctrl+C = Stop script

Test plan
---------
1. Start PowerShell 5.1.
2. Run:
   powershell.exe -ExecutionPolicy Bypass -File .\PQC_GX_SampleId_AutoNavigator_v1.ps1

3. First test in Notepad:
   - Temporarily change AllowedWindowTitleRegex to 'Notepad'
   - Scan a Sample ID barcode.
   - Confirm the script detects the Sample ID and sends keys.

4. Then test in GX non-critical/test environment:
   - Click in the Sample ID field.
   - Scan a normal Sample ID barcode.
   - Verify GX gets correct Sample ID and Test Type.

Important
---------
Do not use in routine/GMP work without local approval/validation.
Always verify the final Sample ID and Test Type in GX/Test Summary.
