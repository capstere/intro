# PQC_GX_SampleId_AutoNavigator_v1.ps1
# PowerShell 5.1 proof-of-concept for PQC/GX Sample ID automation.
#
# Concept:
# 1) Scanner sends a normal barcode containing ONLY Sample ID, e.g. 121725MMM_01_2_19X
# 2) GX receives the Sample ID normally.
# 3) This script detects the Sample ID in the keyboard stream.
# 4) After ONE pause, it sends the GX navigation keys.
#
# Stop script: close this PowerShell window or press Ctrl+C.
# Toggle ON/OFF while running: F8
# Toggle selection mode Letters/DownArrows while running: F9
#
# IMPORTANT:
# - Test in Notepad first, then in a non-critical GX test environment.
# - Do not use in routine/GMP work without local approval/validation.
# - Verify final Sample ID and Test Type in GX/Test Summary.

Add-Type -AssemblyName System.Windows.Forms

# =========================
# USER SETTINGS
# =========================

# Start enabled. Set to $false if you want to press F8 before testing.
$script:Enabled = $true

# Only send keys when the active window title matches this regex.
# Adjust if your GX/Infinity window title is different.
$script:AllowedWindowTitleRegex = 'GeneXpert|Infinity|Xpertise|Cepheid'

# How long to wait after the full Sample ID has been scanned before sending GX navigation.
# This is the ONE pause after Sample ID.
$script:PauseAfterSampleIdMs = 600

# SelectionMode:
# - "Letters": uses N / P / PP after opening Test Type dropdown. This matches the sequence we already tested.
# - "DownArrows": uses DOWN arrow counts. Try this if letters are unreliable.
$script:SelectionMode = "Letters"

# Regex for Sample IDs like:
# 121725MMM_01_2_19X
# 121425MMM_01_1_11+
# 101525ARMO_01_0_01X
# Allows SP with 1-2 digits, Sample Type 0/1/2, two-digit replicate, optional replacement letter, and X/+.
$script:SampleIdRegex = '(?<id>[A-Z0-9]+_\d{1,2}_[012]_\d{2}[A-Z]?[X+])$'

# GX navigation after Sample ID:
# Sample Type 0 = N
# Sample Type 1 = P
# Sample Type 2 = PP
$script:LetterMap = @{
    "0" = "N"
    "1" = "P"
    "2" = "PP"
}

# Alternative dropdown navigation.
# Assumes dropdown order:
# Specimen
# Negative Control 1
# Negative Control 2
# Negative Control 3
# Positive Control 1
# Positive Control 2
$script:DownArrowMap = @{
    "0" = "{DOWN 1}"
    "1" = "{DOWN 4}"
    "2" = "{DOWN 5}"
}

# Full navigation sequence:
# TAB x6 -> SPACE opens Test Type -> select -> SPACE confirms -> TAB x4 -> SPACE starts/continues
function Get-GxNavigationSequence {
    param(
        [Parameter(Mandatory=$true)]
        [string]$SampleCode
    )

    if ($script:SelectionMode -eq "Letters") {
        if (-not $script:LetterMap.ContainsKey($SampleCode)) { return $null }
        $select = $script:LetterMap[$SampleCode]
    }
    elseif ($script:SelectionMode -eq "DownArrows") {
        if (-not $script:DownArrowMap.ContainsKey($SampleCode)) { return $null }
        $select = $script:DownArrowMap[$SampleCode]
    }
    else {
        return $null
    }

    return "{TAB 6}{SPACE}$select{SPACE}{TAB 4}{SPACE}"
}

# =========================
# WIN32 HOOK SUPPORT
# =========================

$cs = @"
using System;
using System.Text;
using System.Diagnostics;
using System.Runtime.InteropServices;

public class KeyPressedEventArgs : EventArgs
{
    public string Text { get; private set; }
    public int VkCode { get; private set; }

    public KeyPressedEventArgs(string text, int vkCode)
    {
        Text = text;
        VkCode = vkCode;
    }
}

public delegate void KeyPressedEventHandler(object sender, KeyPressedEventArgs e);

public class KeyboardHook : IDisposable
{
    public event KeyPressedEventHandler KeyPressed;

    private const int WH_KEYBOARD_LL = 13;
    private const int WM_KEYDOWN = 0x0100;
    private const int WM_SYSKEYDOWN = 0x0104;

    private LowLevelKeyboardProc _proc;
    private IntPtr _hookID = IntPtr.Zero;

    public KeyboardHook()
    {
        _proc = HookCallback;
    }

    public void Install()
    {
        _hookID = SetHook(_proc);
    }

    public void Dispose()
    {
        Uninstall();
    }

    public void Uninstall()
    {
        if (_hookID != IntPtr.Zero)
        {
            UnhookWindowsHookEx(_hookID);
            _hookID = IntPtr.Zero;
        }
    }

    private IntPtr SetHook(LowLevelKeyboardProc proc)
    {
        using (Process curProcess = Process.GetCurrentProcess())
        using (ProcessModule curModule = curProcess.MainModule)
        {
            return SetWindowsHookEx(WH_KEYBOARD_LL, proc, GetModuleHandle(curModule.ModuleName), 0);
        }
    }

    private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

    [StructLayout(LayoutKind.Sequential)]
    private struct KBDLLHOOKSTRUCT
    {
        public uint vkCode;
        public uint scanCode;
        public uint flags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0 && (wParam == (IntPtr)WM_KEYDOWN || wParam == (IntPtr)WM_SYSKEYDOWN))
        {
            KBDLLHOOKSTRUCT kb = (KBDLLHOOKSTRUCT)Marshal.PtrToStructure(lParam, typeof(KBDLLHOOKSTRUCT));
            string text = VkToString(kb.vkCode, kb.scanCode);
            KeyPressedEventHandler handler = KeyPressed;
            if (handler != null)
            {
                handler(this, new KeyPressedEventArgs(text, (int)kb.vkCode));
            }
        }

        return CallNextHookEx(_hookID, nCode, wParam, lParam);
    }

    private string VkToString(uint vkCode, uint scanCode)
    {
        byte[] keyboardState = new byte[256];
        if (!GetKeyboardState(keyboardState))
        {
            return "";
        }

        StringBuilder sb = new StringBuilder(8);
        int result = ToUnicode(vkCode, scanCode, keyboardState, sb, sb.Capacity, 0);
        if (result > 0)
        {
            return sb.ToString();
        }

        return "";
    }

    [DllImport("user32.dll")]
    private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool UnhookWindowsHookEx(IntPtr hhk);

    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
    private static extern IntPtr GetModuleHandle(string lpModuleName);

    [DllImport("user32.dll")]
    private static extern bool GetKeyboardState(byte[] lpKeyState);

    [DllImport("user32.dll")]
    private static extern int ToUnicode(uint wVirtKey, uint wScanCode, byte[] lpKeyState,
        [Out, MarshalAs(UnmanagedType.LPWStr)] StringBuilder pwszBuff, int cchBuff, uint wFlags);
}

public static class ActiveWindow
{
    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);

    public static string GetTitle()
    {
        const int nChars = 512;
        StringBuilder buff = new StringBuilder(nChars);
        IntPtr handle = GetForegroundWindow();

        if (GetWindowText(handle, buff, nChars) > 0)
        {
            return buff.ToString();
        }

        return "";
    }
}
"@

try {
    Add-Type -TypeDefinition $cs -Language CSharp -ErrorAction Stop
}
catch {
    Write-Host "Failed to compile keyboard hook support:" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}

# =========================
# SCRIPT STATE
# =========================

$script:Buffer = ""
$script:PendingSampleId = $null
$script:SuppressUntil = [DateTime]::MinValue

function Write-Log {
    param([string]$Message, [string]$Color = "Gray")
    $stamp = Get-Date -Format "HH:mm:ss"
    Write-Host "[$stamp] $Message" -ForegroundColor $Color
}

function Test-AllowedForegroundWindow {
    $title = [ActiveWindow]::GetTitle()
    if ($title -match $script:AllowedWindowTitleRegex) {
        return $true
    }

    Write-Log "Blocked: active window title was '$title'." "Yellow"
    return $false
}

function Invoke-GxNavigationForSampleId {
    param(
        [Parameter(Mandatory=$true)]
        [string]$SampleId
    )

    if (-not $script:Enabled) {
        Write-Log "Detected $SampleId but automation is OFF." "Yellow"
        return
    }

    if (-not (Test-AllowedForegroundWindow)) {
        Write-Log "Detected $SampleId but foreground window is not allowed." "Yellow"
        return
    }

    $parts = $SampleId -split "_"
    if ($parts.Count -lt 3) {
        Write-Log "Could not parse Sample ID: $SampleId" "Red"
        return
    }

    $sampleCode = $parts[2]
    $sequence = Get-GxNavigationSequence -SampleCode $sampleCode

    if ([string]::IsNullOrEmpty($sequence)) {
        Write-Log "No sequence for Sample Type '$sampleCode' in Sample ID $SampleId." "Red"
        return
    }

    Write-Log "Detected $SampleId | Sample Type $sampleCode | Mode $script:SelectionMode | Waiting $script:PauseAfterSampleIdMs ms." "Cyan"

    Start-Sleep -Milliseconds $script:PauseAfterSampleIdMs

    # Avoid capturing our own SendKeys output.
    $script:SuppressUntil = (Get-Date).AddSeconds(3)

    try {
        [System.Windows.Forms.SendKeys]::SendWait($sequence)
        Write-Log "Sent GX sequence: $sequence" "Green"
    }
    catch {
        Write-Log "SendKeys failed: $($_.Exception.Message)" "Red"
    }
    finally {
        $script:Buffer = ""
        $script:PendingSampleId = $null
    }
}

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 250
$timer.Add_Tick({
    $timer.Stop()

    if (-not [string]::IsNullOrEmpty($script:PendingSampleId)) {
        $id = $script:PendingSampleId
        $script:PendingSampleId = $null
        Invoke-GxNavigationForSampleId -SampleId $id
    }
})

$hook = New-Object KeyboardHook

$hook.add_KeyPressed({
    param($sender, $e)

    # F8 = toggle ON/OFF
    if ($e.VkCode -eq 119) {
        $script:Enabled = -not $script:Enabled
        if ($script:Enabled) {
            Write-Log "Automation ON" "Green"
        } else {
            Write-Log "Automation OFF" "Yellow"
        }
        return
    }

    # F9 = switch mode Letters / DownArrows
    if ($e.VkCode -eq 120) {
        if ($script:SelectionMode -eq "Letters") {
            $script:SelectionMode = "DownArrows"
        } else {
            $script:SelectionMode = "Letters"
        }
        Write-Log "SelectionMode changed to $script:SelectionMode" "Cyan"
        return
    }

    if ((Get-Date) -lt $script:SuppressUntil) {
        return
    }

    $ch = $e.Text

    # Handle backspace in the detection buffer.
    if ([string]::IsNullOrEmpty($ch)) {
        if ($e.VkCode -eq 8 -and $script:Buffer.Length -gt 0) {
            $script:Buffer = $script:Buffer.Substring(0, $script:Buffer.Length - 1)
        }
        return
    }

    foreach ($c in $ch.ToCharArray()) {
        $s = [string]$c

        if ($s -match '[A-Za-z0-9_+]') {
            $script:Buffer += $s
        }

        if ($script:Buffer.Length -gt 120) {
            $script:Buffer = $script:Buffer.Substring($script:Buffer.Length - 120)
        }

        $m = [regex]::Match($script:Buffer, $script:SampleIdRegex, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
        if ($m.Success) {
            $script:PendingSampleId = $m.Groups["id"].Value
            $timer.Stop()
            $timer.Start()
        }
    }
})

try {
    Write-Host ""
    Write-Host "PQC/GX Sample ID AutoNavigator v1" -ForegroundColor Cyan
    Write-Host "---------------------------------" -ForegroundColor Cyan
    Write-Host "Automation starts: $script:Enabled"
    Write-Host "SelectionMode:     $script:SelectionMode"
    Write-Host "Allowed windows:   $script:AllowedWindowTitleRegex"
    Write-Host "Pause after ID:    $script:PauseAfterSampleIdMs ms"
    Write-Host ""
    Write-Host "F8 = ON/OFF | F9 = Letters/DownArrows | Ctrl+C = Stop" -ForegroundColor Yellow
    Write-Host ""

    $hook.Install()
    Write-Log "Keyboard hook installed. Ready." "Green"

    # WinForms message loop is required for the timer and event processing.
    [System.Windows.Forms.Application]::Run()
}
finally {
    if ($hook -ne $null) {
        $hook.Uninstall()
        $hook.Dispose()
    }
    Write-Log "Stopped." "Yellow"
}
