﻿# Safe refactor: extracted function definitions from Main.ps1

function New-ListRow {
    param([string]$labelText,[ref]$lbl,[ref]$clb,[ref]$btn)
    $lbl.Value = New-Object System.Windows.Forms.Label
    $lbl.Value.Text=$labelText
    $lbl.Value.Anchor='Left'
    $lbl.Value.AutoSize=$true
    $lbl.Value.Margin=New-Object System.Windows.Forms.Padding(0,12,6,0)
    $clb.Value = New-Object System.Windows.Forms.CheckedListBox
    $clb.Value.Dock='Fill'
    $clb.Value.Margin=New-Object System.Windows.Forms.Padding(0,6,8,6)
    $clb.Value.Height=70
    $clb.Value.IntegralHeight=$false
    $clb.Value.CheckOnClick = $true
    $clb.Value.DisplayMember = 'Name'
    # IT-policy: drag & drop ska inte vara aktiverat i IPTCompile.
    try { $clb.Value.AllowDrop = $false } catch {}

    $btn.Value = New-Object System.Windows.Forms.Button
    $btn.Value.Text='Bläddra…'
    $btn.Value.Dock='Fill'
    $btn.Value.Margin=New-Object System.Windows.Forms.Padding(0,6,0,6)
    Set-AccentButton $btn.Value
}

function Set-ClbWatermark {
    param([System.Windows.Forms.CheckedListBox]$clb, [string]$Text)
    $tag = @{ Watermark = $Text }
    $clb.Tag = $tag
    if ($clb.Items.Count -eq 0) { Show-ClbWatermark $clb }
}

function Show-ClbWatermark {
    param([System.Windows.Forms.CheckedListBox]$clb)
    if (-not $clb.Tag -or -not $clb.Tag.Watermark) { return }
    $clb.ForeColor = [System.Drawing.Color]::Silver
    $clb.Items.Clear()
    [void]$clb.Items.Add($clb.Tag.Watermark)
}

function Hide-ClbWatermark {
    param([System.Windows.Forms.CheckedListBox]$clb)
    if (-not $clb.Tag -or -not $clb.Tag.Watermark) { return }
    $wm = $clb.Tag.Watermark
    for ($wi = $clb.Items.Count - 1; $wi -ge 0; $wi--) {
        try { if (([string]$clb.Items[$wi]) -eq $wm) { $clb.Items.RemoveAt($wi) } } catch {}
    }
    $clb.ForeColor = [System.Drawing.SystemColors]::WindowText
}

function Add-CLBItems {
    param([System.Windows.Forms.CheckedListBox]$clb,[System.IO.FileInfo[]]$files,[switch]$AutoCheckFirst,[switch]$Append)
    Hide-ClbWatermark $clb
    $clb.BeginUpdate()
    if (-not $Append) { $clb.Items.Clear() }
    foreach($f in $files){
        if ($f -isnot [System.IO.FileInfo]) { try { $f = Get-Item -LiteralPath $f } catch { continue } }
        # Undvik dubbletter vid Append
        $alreadyExists = $false
        if ($Append) {
            for ($di = 0; $di -lt $clb.Items.Count; $di++) {
                try { if ([string]$clb.Items[$di].FullName -eq [string]$f.FullName) { $alreadyExists = $true; break } } catch {}
            }
        }
        if (-not $alreadyExists) { [void]$clb.Items.Add($f, $false) }
    }
    $clb.EndUpdate()
    if ($AutoCheckFirst -and $clb.Items.Count -gt 0) { $clb.SetItemChecked(0,$true) }
    if ($clb.Items.Count -eq 0) { Show-ClbWatermark $clb }
    Update-StatusBar
}

function Get-CheckedFilePath { param([System.Windows.Forms.CheckedListBox]$clb)
    if (-not $clb) { return $null }
    for($i=0;$i -lt $clb.Items.Count;$i++){
        if ($clb.GetItemChecked($i)) {
            $fi = [System.IO.FileInfo]$clb.Items[$i]
            return $fi.FullName
        }
    }
    return $null
}

function Get-AllCheckedFilePaths { param([System.Windows.Forms.CheckedListBox]$clb)
    if (-not $clb) { return @() }
    $paths = New-Object 'System.Collections.Generic.List[string]'
    for($i=0;$i -lt $clb.Items.Count;$i++){
        if ($clb.GetItemChecked($i)) {
            $fi = [System.IO.FileInfo]$clb.Items[$i]
            [void]$paths.Add($fi.FullName)
        }
    }
    return @($paths.ToArray())
}



function Get-SealTestFileRole {
    param([string]$Path)
    $leaf = ''
    try { $leaf = [System.IO.Path]::GetFileNameWithoutExtension(($Path + '')) } catch { $leaf = ($Path + '') }
    $leaf = ($leaf + '').Trim()

    # Filnamnsbaserad klassificering. Medvetet strikt men tolerant mot vanliga felskrivningar:
    # - NEG/Negative samt t.ex. NegG, Neg1, Negativ vinner alltid.
    # - POS/Positive samt t.ex. PosG, Pos1, Positiv vinner alltid.
    # - Merged/neutral får bara vara en tydlig Seal Test-fil utan NEG/POS-markör.
    # - Okänd Excel-fil får inte behandlas som Merged.
    if ($leaf -match '(?i)(^|[\s_\-#])(neg[a-z0-9åäö]*|negative)([\s_\-#\.]|$)') { return 'NEG' }
    if ($leaf -match '(?i)(^|[\s_\-#])(pos[a-z0-9åäö]*|positive)([\s_\-#\.]|$)') { return 'POS' }

    $looksLikeSealTest = ($leaf -match '(?i)seal[\s_\-]*test' -or ($leaf -match '(?i)\bseal\b' -and $leaf -match '(?i)\btest\b'))
    if ($looksLikeSealTest) { return 'MERGED' }

    return 'UNKNOWN'
}

function Resolve-SealTestSelection {
    # Säker validering: användaren väljer fil(er), scriptet avgör läge först när valet är entydigt.
    # 1 neutral/merged Seal Test-fil = Merged.
    # 2 filer = Split endast om exakt 1 NEG + exakt 1 POS.
    # 1 NEG/POS stoppas för att undvika att en halv Split-uppsättning råkar köras som Merged.
    $items = New-Object 'System.Collections.Generic.List[object]'

    foreach ($p in @(Get-AllCheckedFilePaths $clbNeg)) {
        if (-not [string]::IsNullOrWhiteSpace($p)) {
            [void]$items.Add([pscustomobject]@{ Path=$p; Source='NEG-lista'; Role=(Get-SealTestFileRole -Path $p) })
        }
    }
    foreach ($p in @(Get-AllCheckedFilePaths $clbPos)) {
        if (-not [string]::IsNullOrWhiteSpace($p)) {
            [void]$items.Add([pscustomobject]@{ Path=$p; Source='POS/Merged-lista'; Role=(Get-SealTestFileRole -Path $p) })
        }
    }

    $arr = @($items.ToArray())
    $count = $arr.Count
    if ($count -eq 0) {
        return [pscustomobject]@{ Valid=$false; Mode=''; IsMerged=$false; NegPath=$null; PosPath=$null; MergedPath=$null; Message='Välj Seal Test: antingen NEG + POS, eller en Merged Seal Test-fil.'; Count=0; Roles=@() }
    }

    $neg = @($arr | Where-Object { $_.Role -eq 'NEG' })
    $pos = @($arr | Where-Object { $_.Role -eq 'POS' })
    $merged = @($arr | Where-Object { $_.Role -eq 'MERGED' })
    $unknown = @($arr | Where-Object { $_.Role -eq 'UNKNOWN' })
    $roles = @($arr | ForEach-Object { $_.Role })

    if ($count -eq 1) {
        $one = $arr[0]
        if ($one.Role -eq 'NEG') {
            return [pscustomobject]@{ Valid=$false; Mode=''; IsMerged=$false; NegPath=$one.Path; PosPath=$null; MergedPath=$null; Message='Du har bara valt Seal Test NEG. Split kräver både NEG och POS. Välj även POS-filen, eller välj en neutral Merged Seal Test-fil.'; Count=$count; Roles=$roles }
        }
        if ($one.Role -eq 'POS') {
            return [pscustomobject]@{ Valid=$false; Mode=''; IsMerged=$false; NegPath=$null; PosPath=$one.Path; MergedPath=$null; Message='Du har bara valt Seal Test POS. Split kräver både NEG och POS. Välj även NEG-filen, eller välj en neutral Merged Seal Test-fil.'; Count=$count; Roles=$roles }
        }
        if ($one.Role -eq 'MERGED') {
            return [pscustomobject]@{ Valid=$true; Mode='Merged'; IsMerged=$true; NegPath=$null; PosPath=$one.Path; MergedPath=$one.Path; Message='Merged / en tydlig Seal Test-fil'; Count=$count; Roles=$roles }
        }
        return [pscustomobject]@{ Valid=$false; Mode=''; IsMerged=$false; NegPath=$null; PosPath=$null; MergedPath=$one.Path; Message='Den valda Seal Test-filen kunde inte klassificeras. Välj exakt NEG + POS, eller en Merged Seal Test-fil vars filnamn innehåller "Seal Test" men inte NEG/POS.'; Count=$count; Roles=$roles }
    }

    if ($count -eq 2 -and $neg.Count -eq 1 -and $pos.Count -eq 1 -and $merged.Count -eq 0) {
        return [pscustomobject]@{ Valid=$true; Mode='Split'; IsMerged=$false; NegPath=$neg[0].Path; PosPath=$pos[0].Path; MergedPath=$null; Message='Split / Seal Test NEG+POS'; Count=$count; Roles=$roles }
    }

    if ($count -eq 2 -and $merged.Count -eq 1) {
        return [pscustomobject]@{ Valid=$false; Mode=''; IsMerged=$false; NegPath=$null; PosPath=$null; MergedPath=$merged[0].Path; Message='Du har valt en Merged/neutral Seal Test-fil tillsammans med en annan Seal Test-fil. Välj antingen bara Merged-filen, eller exakt NEG + POS.'; Count=$count; Roles=$roles }
    }

    if ($unknown.Count -gt 0) {
        return [pscustomobject]@{ Valid=$false; Mode=''; IsMerged=$false; NegPath=$null; PosPath=$null; MergedPath=$null; Message='En eller flera valda Seal Test-filer kunde inte klassificeras. Filnamnet måste tydligt visa NEG, POS eller "Seal Test" utan NEG/POS för Merged.'; Count=$count; Roles=$roles }
    }

    if ($count -eq 2 -and $neg.Count -eq 2) {
        return [pscustomobject]@{ Valid=$false; Mode=''; IsMerged=$false; NegPath=$null; PosPath=$null; MergedPath=$null; Message='Du har valt två Seal Test NEG-filer. Split kräver exakt en NEG och exakt en POS.'; Count=$count; Roles=$roles }
    }
    if ($count -eq 2 -and $pos.Count -eq 2) {
        return [pscustomobject]@{ Valid=$false; Mode=''; IsMerged=$false; NegPath=$null; PosPath=$null; MergedPath=$null; Message='Du har valt två Seal Test POS-filer. Split kräver exakt en NEG och exakt en POS.'; Count=$count; Roles=$roles }
    }

    return [pscustomobject]@{ Valid=$false; Mode=''; IsMerged=$false; NegPath=$null; PosPath=$null; MergedPath=$null; Message='Ogiltigt Seal Test-val. Välj exakt NEG + POS, eller en enda tydlig Merged Seal Test-fil utan NEG/POS-markör.'; Count=$count; Roles=$roles }
}

function Get-SealTestMode {
    # Returnerar härlett läge under pågående build. Före build är Split bara säker fallback.
    try {
        $cur = (($script:SealTestModeCurrent + '').Trim())
        if ($cur -match '(?i)^merged?$') { return 'Merged' }
        if ($cur -match '(?i)^split$') { return 'Split' }
    } catch {}
    return 'Split'
}

function Test-SealTestMergedMode {
    return ((Get-SealTestMode) -eq 'Merged')
}

function Get-SealTestModeLabel {
    try {
        $r = Resolve-SealTestSelection
        if ($r.Valid) { return $r.Message }
    } catch {}
    if (Test-SealTestMergedMode) { return 'Merged / en Seal Test-fil' }
    return 'Split / Seal Test NEG+POS'
}

function Get-SealMergedInputPath {
    try {
        $r = Resolve-SealTestSelection
        if ($r.Valid -and $r.IsMerged) { return $r.MergedPath }
    } catch {}
    return $null
}

function Update-SealTestModeUI {
    # Seal Test-valet styrs av valda filer, inte av automatisk mode-växling.
    try {
        if ($lblNeg) { $lblNeg.Text = 'Seal Test NEG:' }
        if ($lblPos) { $lblPos.Text = 'Seal Test POS / Merged:' }
    } catch {}

    try {
        if ($clbNeg) { $clbNeg.Enabled = $true }
        if ($btnNegBrowse) { $btnNegBrowse.Enabled = $true }
        if ($clbPos) { $clbPos.Enabled = $true }
        if ($btnPosBrowse) { $btnPosBrowse.Enabled = $true }
    } catch {}

    try {
        if ($chkSealTest) { $chkSealTest.Text = ' Seal Test' }
        if ($grpSignSamm) { $grpSignSamm.Text = 'Signering — Seal Test' }
        if ($chkSignOverwrite) { $chkSignOverwrite.Tag = 'Skriv signatur i valda Seal Test-fil(er). Worksheet-signering är avstängd i denna version.' }
    } catch {}

    try { Update-StatusBar } catch {}
}

function Clear-GUI {
    $txtLSP.Text = ''
    $txtSammName.Text = ''; $txtSammDate.Text = ''; $txtSealTestSign.Text = ''
    $chkSealTest.Checked = $false; $chkWsSamm.Checked = $false; $chkSignOverwrite.Checked = $false
    try { $script:SealTestModeCurrent = $null; $script:SealTestMode = 'Split'; Update-SealTestModeUI } catch {}
    $txtGranskName.Text = ''; $txtGranskDate.Text = ''
    $chkWsGransk.Checked = $false; $chkGranskOverwrite.Checked = $false

    # Nollställ ALLA build-relaterade cacher (förhindra cross-kontaminering mellan körningar)
    $script:RobalDateShort          = $null
    $script:RuleEngineShadow        = $null
    $script:RuleEngineShadowRes     = $null
    $script:RuleEngineCsvObjs       = $null
    $script:RuleEngineCsvObjsRes    = $null
    $script:RuleBankCache           = $null
    $script:CsvLinesPrimary         = $null
    $script:CsvLinesResample        = $null
    $script:QcReminderB3            = $null

    Add-CLBItems -clb $clbCsv -files @()
    Add-CLBItems -clb $clbNeg -files @()
    Add-CLBItems -clb $clbPos -files @()
    Add-CLBItems -clb $clbLsp -files @()
    $outputBox.Clear()
    Update-BuildEnabled
    try { if ($script:slOpenReport) { $script:slOpenReport.Visible = $false }; if ($script:slOpenFolder) { $script:slOpenFolder.Visible = $false } } catch {}
    Gui-Log "🧹 Fönstret rensat." 'Info'
    Update-BatchLink
    try { Update-ReportCountIndicator } catch {}
    try { Apply-UserDefaults } catch {}
}

function Get-SelectedFileCount {
    $n = 0

    # CSV kan vara 1–2 filer vid resample
    try {
        if ($clbCsv -and $clbCsv.CheckedItems) { $n += [int]$clbCsv.CheckedItems.Count }
        elseif (Get-CheckedFilePath $clbCsv) { $n++ }
    } catch {
        if (Get-CheckedFilePath $clbCsv) { $n++ }
    }

    try { $n += [int](Get-CheckedItemCountSafe $clbNeg) } catch {}
    try { $n += [int](Get-CheckedItemCountSafe $clbPos) } catch {}
    if (Get-CheckedFilePath $clbLsp) { $n++ }
    return $n
}

function Update-StatusBar {
    try { $slCount.Text = "$(Get-SelectedFileCount) filer valda" } catch {}
    try { Update-ReadinessBanner } catch {}
}

function Get-CheckedItemCountSafe {
    param([System.Windows.Forms.CheckedListBox]$clb)
    try {
        if (-not $clb) { return 0 }
        $n = 0
        for ($i=0; $i -lt $clb.Items.Count; $i++) {
            try { if ($clb.GetItemChecked($i)) { $n++ } } catch {}
        }
        return $n
    } catch { return 0 }
}

function Get-ReadinessInfo {
    $missingRequired = New-Object 'System.Collections.Generic.List[string]'
    $warnings = New-Object 'System.Collections.Generic.List[string]'

    try {
        $sealInfo = Resolve-SealTestSelection
        if (-not $sealInfo.Valid) { [void]$missingRequired.Add('korrekt Seal Test-val') }
    } catch { [void]$missingRequired.Add('Seal Test') }

    try { if ((Get-CheckedItemCountSafe $clbCsv) -eq 0) { [void]$warnings.Add('CSV saknas') } } catch {}
    try { if (-not (Get-CheckedFilePath $clbLsp)) { [void]$warnings.Add('Worksheet saknas') } } catch {}

    $modeText = 'Seal Test: välj filer'
    try {
        $tmpSealInfo = Resolve-SealTestSelection
        if ($tmpSealInfo.Valid) { $modeText = $tmpSealInfo.Message }
    } catch {
        try { $modeText = Get-SealTestModeLabel } catch {}
    }

    [pscustomobject]@{
        Ready           = ($missingRequired.Count -eq 0)
        MissingRequired = @($missingRequired.ToArray())
        Warnings        = @($warnings.ToArray())
        FileCount       = (Get-SelectedFileCount)
        Mode            = $modeText
    }
}

function Update-ReadinessBanner {
    try {
        if (-not $script:lblReadiness -or -not $script:pReadinessBanner) { return }

        if ($script:BuildInProgress) {
            $msg = ($script:UiCurrentStepMessage + '').Trim()
            if (-not $msg) { $msg = 'Skapar rapport…' }
            $script:lblReadiness.Text = "$msg"
            $script:pReadinessBanner.BackColor = [System.Drawing.Color]::FromArgb(227,242,253)
            $script:lblReadiness.ForeColor = [System.Drawing.Color]::FromArgb(21,101,192)
            return
        }

        $info = Get-ReadinessInfo
        if ($info.Ready) {
            $warnText = ''
            if ($info.Warnings -and $info.Warnings.Count -gt 0) { $warnText = ' | Obs: ' + (($info.Warnings) -join ', ') }
            $script:lblReadiness.Text = "Redo att skapa rapport — $($info.FileCount) filer valda | $($info.Mode)$warnText"
            $script:pReadinessBanner.BackColor = [System.Drawing.Color]::FromArgb(232,245,233)
            $script:lblReadiness.ForeColor = [System.Drawing.Color]::FromArgb(27,94,32)
        } else {
            $missing = (($info.MissingRequired) -join ', ')
            if (-not $missing) { $missing = 'filval' }
            $script:lblReadiness.Text = "Nästan redo — välj $missing"
            $script:pReadinessBanner.BackColor = [System.Drawing.Color]::FromArgb(255,248,225)
            $script:lblReadiness.ForeColor = [System.Drawing.Color]::FromArgb(130,88,0)
        }
    } catch {}
}

function Set-SealTestModeSelection {
    param([ValidateSet('Split','Merged')][string]$Mode)
    # Kompatibilitetsstub. Användarens Seal Test-val avgörs nu av valda filer.
    try {
        $script:SealTestMode = 'Split'
        Update-SealTestModeUI
        Update-BuildEnabled
    } catch {}
}

function Invoke-SmartSealModeDetection {
    param(
        [object[]]$Neg,
        [object[]]$Pos,
        [object[]]$Merged,
        [switch]$Silent
    )

    # Seal Test mode ska vara användarstyrt.
    # Funktionen finns kvar som kompatibilitetsstub, men den får aldrig ändra Split/Merged automatiskt.
    try { return (Get-SealTestMode) } catch { return 'Split' }
}

function Refresh-SealCandidateListsFromScan {
    param([switch]$Silent)

    try {
        if (-not $script:LastScanResult) { return }

        $negFiles = @($script:LastScanResult.Neg)
        $posFiles = @($script:LastScanResult.Pos)
        $mergedFiles = @($script:LastScanResult.SealMerged)

        $posAndMerged = New-Object 'System.Collections.Generic.List[System.IO.FileInfo]'
        $seen = @{}
        foreach ($f in @($posFiles + $mergedFiles)) {
            if (-not $f) { continue }
            $key = ''
            try { $key = ($f.FullName + '').ToLowerInvariant() } catch { $key = ($f.Name + '').ToLowerInvariant() }
            if (-not $seen.ContainsKey($key)) { $seen[$key] = $true; [void]$posAndMerged.Add($f) }
        }

        Add-CLBItems -clb $clbNeg -files @($negFiles)
        Add-CLBItems -clb $clbPos -files @($posAndMerged.ToArray())

        # Default är Split: om exakt en NEG och exakt en POS hittas förikryssas de.
        # Merged/neutral förikryssas aldrig; användaren måste aktivt välja den filen.
        if (@($negFiles).Count -eq 1 -and @($posFiles).Count -eq 1) {
            try {
                if ($clbNeg.Items.Count -gt 0) { $clbNeg.SetItemChecked(0, $true) }
                $posPath = ''
                try { $posPath = ($posFiles[0].FullName + '') } catch {}
                for ($pi=0; $pi -lt $clbPos.Items.Count; $pi++) {
                    try {
                        if (($clbPos.Items[$pi].FullName + '') -eq $posPath) {
                            $clbPos.SetItemChecked($pi, $true)
                            break
                        }
                    } catch {}
                }
            } catch {}
        }

        if (-not $Silent) {
            $total = @($negFiles).Count + @($posAndMerged.ToArray()).Count
            if ($total -eq 0) {
                Gui-Log '⚠️ Inga Seal Test-filer hittades. Välj manuellt.' 'Warn'
            } elseif (@($negFiles).Count -eq 1 -and @($posFiles).Count -eq 1) {
                Gui-Log ("ℹ️ Seal Test NEG+POS hittades och förikryssades. Vid Merged: avmarkera POS/NEG och välj Merged-filen aktivt.") 'Info' 'USER'
            } else {
                Gui-Log ("ℹ️ Seal Test-kandidater listades. Välj exakt NEG+POS eller en Merged Seal Test-fil.") 'Info' 'USER'
            }
        }

        try { Update-BuildEnabled } catch {}
        try { Update-BatchLink } catch {}
        try { Update-StatusBar } catch {}
    } catch {
        try { Gui-Log ("⚠️ Kunde inte uppdatera Seal Test-listor: " + $_.Exception.Message) 'Warn' } catch {}
    }
}

function Get-BuildAuditCsvPaths {
    $paths = New-Object 'System.Collections.Generic.List[string]'
    try {
        $netRoot = ($env:IPT_NETWORK_ROOT + '').Trim()
        if ($netRoot) { [void]$paths.Add((Join-Path $netRoot 'audit\build_audit.csv')) }
    } catch {}
    try { if ($ScriptRootPath) { [void]$paths.Add((Join-Path $ScriptRootPath 'audit\build_audit.csv')) } } catch {}
    try { if ($ScriptRootPath) { [void]$paths.Add((Join-Path $ScriptRootPath 'Infrastructure\audit\build_audit.csv')) } } catch {}

    $seen = @{}
    foreach ($p in $paths) {
        if ($p -and -not $seen.ContainsKey($p)) {
            $seen[$p] = $true
            if (Test-Path -LiteralPath $p) { $p }
        }
    }
}

function Get-AuditCreatedReportCount {
    try {
        $keys = @{}
        foreach ($csvPath in @(Get-BuildAuditCsvPaths)) {
            try {
                $rows = @(Import-Csv -LiteralPath $csvPath -ErrorAction Stop)
                foreach ($r in $rows) {
                    $status = ($r.Status + '').Trim()
                    if ($status -and $status -notmatch '(?i)^(OK|Warnings)$') { continue }
                    $report = ($r.ReportPath + '').Trim()
                    $ts = ($r.Timestamp + '').Trim()
                    $user = ($r.User + '').Trim()
                    $key = if ($report) { $report.ToLowerInvariant() } else { ($ts + '|' + $user) }
                    if ($key) { $keys[$key] = $true }
                }
            } catch {}
        }
        return $keys.Count
    } catch { return 0 }
}

function Update-ReportCountIndicator {
    try {
        if (-not $script:slSession) { return }
        $total = Get-AuditCreatedReportCount
        if ($total -gt 0) {
            $script:slSession.Text = ("Totalt: {0} rapporter skapade" -f $total)
            $script:slSession.Visible = $true
        }
        elseif ($script:SessionStats -and $script:SessionStats.ReportCount -gt 0) {
            $script:slSession.Text = if ($script:SessionStats.ReportCount -eq 1) { '1 rapport skapad' } else { ("{0} rapporter skapade" -f $script:SessionStats.ReportCount) }
            $script:slSession.Visible = $true
        }
    } catch {}
}

function Invoke-UiPump {
    try { [System.Windows.Forms.Application]::DoEvents() } catch {}
}

function Set-UiBusy {
    param(
        [Parameter(Mandatory)][bool]$Busy,
        [string]$Message = ''
    )
    try {
        if ($Busy) {
            $script:UiCurrentStepMessage = $Message
            $slWork.Text = $Message
            $pbWork.Visible = $true
            $pbWork.Style   = 'Marquee'
            $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
            $btnScan.Enabled  = $false
            $btnBuild.Enabled = $false
        } else {
            $script:UiCurrentStepMessage = ''
            $pbWork.Visible = $false
            $pbWork.Style   = 'Blocks'
            $pbWork.Value   = 0
            $slWork.Text = ''
            $form.Cursor = [System.Windows.Forms.Cursors]::Default
            $btnScan.Enabled = $true
            Update-BuildEnabled
        }
        $status.Refresh()
        $form.Refresh()
        Invoke-UiPump
    } catch {}
}

function Set-UiStep {
    param(
        [Parameter(Mandatory)][int]$Percent,
        [string]$Message = ''
    )
    try {
        if ($Percent -lt 0) { $Percent = 0 }
        if ($Percent -gt 100) { $Percent = 100 }
        $script:UiCurrentStepMessage = $Message
        $slWork.Text = $Message
        try { Update-ReadinessBanner } catch {}
        $pbWork.Visible = $true
        $pbWork.Style   = 'Blocks'
        $pbWork.Minimum = 0
        $pbWork.Maximum = 100
        if ($pbWork.Value -ne $Percent) { $pbWork.Value = $Percent }
        $status.Refresh()
        $form.Refresh()
        Invoke-UiPump
    } catch {}
}

function Update-BuildEnabled {
    try {
        if ($script:BuildInProgress) {
            $btnBuild.Enabled = $false
        }
        else {
            $sealReady = $false
            try { $sealReady = [bool](Resolve-SealTestSelection).Valid } catch { $sealReady = $false }
            $btnBuild.Enabled = $sealReady
        }
    } catch {}
    Update-StatusBar
    try { Update-ReadinessBanner } catch {}
}


# Phase 10 safe refactor: moved from Main.ps1

function Update-OverwriteVerificationUI {
    # 2026-05-18: endast Seal Test POS/NEG-signering är aktiv i LIVE.
    # Worksheet Sammanställning/Granskning ska inte påverka krav på overwrite.
    $reqSamm = [bool]$chkSealTest.Checked
    $reqGransk = $false

    if ($reqSamm -and (-not $chkSignOverwrite.Checked)) {
        $chkSignOverwrite.BackColor = $script:OverwriteUiState.WarnBackColor
        $chkSignOverwrite.ForeColor = $script:OverwriteUiState.Sign.ForeColor
        $chkSignOverwrite.Font = $script:OverwriteUiState.BoldFont
        $toolTip.SetToolTip($chkSignOverwrite, 'OBLIGATORISKT: Kryssa i för att skapa rapport med signering (Sammanställning).')
    } else {
        $chkSignOverwrite.BackColor = $script:OverwriteUiState.Sign.BackColor
        $chkSignOverwrite.ForeColor = $script:OverwriteUiState.Sign.ForeColor
        $chkSignOverwrite.Font = $script:OverwriteUiState.Sign.Font
        $toolTip.SetToolTip($chkSignOverwrite, $script:OverwriteUiState.Sign.Tooltip)
    }

    if ($reqGransk -and (-not $chkGranskOverwrite.Checked)) {
        $chkGranskOverwrite.BackColor = $script:OverwriteUiState.WarnBackColor
        $chkGranskOverwrite.ForeColor = $script:OverwriteUiState.Gransk.ForeColor
        $chkGranskOverwrite.Font = $script:OverwriteUiState.BoldFont
        $toolTip.SetToolTip($chkGranskOverwrite, 'OBLIGATORISKT: Kryssa i för att skapa rapport med signering (Granskning).')
    } else {
        $chkGranskOverwrite.BackColor = $script:OverwriteUiState.Gransk.BackColor
        $chkGranskOverwrite.ForeColor = $script:OverwriteUiState.Gransk.ForeColor
        $chkGranskOverwrite.Font = $script:OverwriteUiState.Gransk.Font
        $toolTip.SetToolTip($chkGranskOverwrite, $script:OverwriteUiState.Gransk.Tooltip)
    }
}

function Enable-DoubleBuffer {
    $pi = [Windows.Forms.Control].GetProperty('DoubleBuffered',[Reflection.BindingFlags]'NonPublic,Instance')
    foreach($c in @($content,$pLog,$grpPick,$grpSignSamm,$grpSignGransk,$grpDl)) { if ($c) { $pi.SetValue($c,$true,$null) } }
}
