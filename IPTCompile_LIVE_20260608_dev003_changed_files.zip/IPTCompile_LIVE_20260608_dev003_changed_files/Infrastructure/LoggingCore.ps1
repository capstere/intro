﻿try { Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop } catch { }

function Test-HasGetConfigValue {
    try {
        if ($script:__HasGetConfigValue) { return $true }
    } catch {}

    try {
        $cmd = Get-Command Get-ConfigValue -ErrorAction SilentlyContinue
        if ($cmd) {
            $script:__HasGetConfigValue = $true
            return $true
        }
    } catch {}

    return $false
}

function Get-SafeFileNameComponent {
    param(
        [string]$Value,
        [string]$Default = 'NA'
    )

    $s = ($Value + '').Trim()
    if (-not $s) { return $Default }

    foreach ($ch in [System.IO.Path]::GetInvalidFileNameChars()) {
        $s = $s.Replace([string]$ch, '_')
    }

    $s = [regex]::Replace($s, '\s+', ' ').Trim()
    if (-not $s) { return $Default }
    return $s
}


function Resolve-IptAuditDir {
    param(
        [string[]]$CandidateDirs
    )

    $candidates = New-Object System.Collections.Generic.List[string]
    foreach ($p in @($CandidateDirs)) {
        if (-not [string]::IsNullOrWhiteSpace(($p + ''))) { [void]$candidates.Add(($p + '').Trim()) }
    }

    $envAudit = ($env:IPT_AUDIT_DIR + '').Trim()
    if ($envAudit) { [void]$candidates.Add($envAudit) }

    $netRootForAudit = ($env:IPT_NETWORK_ROOT + '').Trim()
    if ($netRootForAudit) { [void]$candidates.Add((Join-Path $netRootForAudit 'audit')) }

    try {
        if ($script:ScriptRootPath) { [void]$candidates.Add((Join-Path $script:ScriptRootPath 'audit')) }
    } catch {}

    try {
        if ($PSScriptRoot) { [void]$candidates.Add((Join-Path $PSScriptRoot 'audit')) }
    } catch {}

    $fallback = Join-Path ([System.IO.Path]::GetTempPath()) 'IPTCompile_audit'
    [void]$candidates.Add($fallback)

    foreach ($dir0 in @($candidates.ToArray() | Select-Object -Unique)) {
        $dir = ($dir0 + '').Trim()
        if (-not $dir) { continue }
        try {
            if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
            $probe = Join-Path $dir ('.write_test_' + [guid]::NewGuid().ToString('N') + '.tmp')
            'ok' | Set-Content -LiteralPath $probe -Encoding UTF8 -ErrorAction Stop
            Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
            return $dir
        } catch {
            try { Write-Host ("Audit directory not writable: {0} ({1})" -f $dir, $_.Exception.Message) } catch {}
        }
    }

    return $null
}

function Add-AuditEntry {
    param(
        [string]$Lsp,
        [string]$Assay,
        [string]$BatchNumber,
        [int]$TestCount,
        [string]$Status,
        [string]$ReportPath,
        [string]$AuditDir,
        [int]$TotalMs = 0,
        [string]$PhaseJson = ''
    )

    try {
        $auditCandidates = New-Object System.Collections.Generic.List[string]
        if ($AuditDir) {
            [void]$auditCandidates.Add($AuditDir)
        } else {
            $netRootForAudit = ($env:IPT_NETWORK_ROOT + '').Trim()
            if ($netRootForAudit) { [void]$auditCandidates.Add((Join-Path $netRootForAudit 'audit')) }
            if ($PSScriptRoot) { [void]$auditCandidates.Add((Join-Path $PSScriptRoot 'audit')) }
        }

        $AuditDir = Resolve-IptAuditDir -CandidateDirs @($auditCandidates.ToArray())
        if (-not $AuditDir) { return }

        $csvPath = Join-Path $AuditDir 'build_audit.csv'
        if (-not (Test-Path -LiteralPath $csvPath)) {
            'Timestamp,User,LSP,Assay,BatchNumber,TestCount,Status,ReportPath,TotalMs,PhaseJson' | Set-Content -LiteralPath $csvPath -Encoding UTF8
        }

        $timestamp = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
        $user = $env:USERNAME
        $safeReportPath = ($ReportPath + '').Replace('"', '""')
        $safePhaseJson  = ($PhaseJson + '').Replace('"', '""')
        $line = '"{0}","{1}","{2}","{3}","{4}",{5},"{6}","{7}",{8},"{9}"' -f `
            $timestamp, $user, ($Lsp + '').Replace('"','""'), ($Assay + '').Replace('"','""'), ($BatchNumber + '').Replace('"','""'), $TestCount, ($Status + '').Replace('"','""'), $safeReportPath, $TotalMs, $safePhaseJson
        Add-Content -LiteralPath $csvPath -Value $line -Encoding UTF8
    } catch {
        try { Write-Host "Auditloggning misslyckades: $($_.Exception.Message)" } catch {}
    }
}

function Write-StructuredLog {
    param(
        [Parameter(Mandatory=$true)][string]$Message,
        [ValidateSet('Info','Warn','Error')][string]$Severity = 'Info',
        [string]$Category = 'UI',
        [hashtable]$Context
    )

    try {
        $path = ($global:StructuredLogPath + '').Trim()
        if (-not $path) { return }

        $dir = Split-Path -Parent $path
        if ($dir -and -not (Test-Path -LiteralPath $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
        }

        $obj = [ordered]@{
            ts       = (Get-Date).ToString('o')
            user     = $env:USERNAME
            computer = $env:COMPUTERNAME
            severity = $Severity
            category = $Category
            message  = $Message
        }
        if ($Context) { $obj.context = $Context }

        $json = ($obj | ConvertTo-Json -Compress -Depth 10)
        Add-Content -LiteralPath $path -Value $json -Encoding UTF8
    } catch {}
}
