﻿# Safe refactor: extracted function definitions from Main.ps1

function New-ListRow {
    param([string]$labelText,[ref]$lbl,[ref]$clb,[ref]$btn)
    $lbl.Value = New-Object System.Windows.Forms.Label
    $lbl.Value.Text=$labelText
    $lbl.Value.Anchor='Left'
    $lbl.Value.AutoSize=$true
    $lbl.Value.Margin=New-Object System.Windows.Forms.Padding(0,12,6,0)
    $clb.Value = New-Object System.Windows.Forms.CheckedListBox
    $clb.Value.Dock='Fill'
    $clb.Value.Margin=New-Object System.Windows.Forms.Padding(0,6,8,6)
    $clb.Value.Height=70
    $clb.Value.IntegralHeight=$false
    $clb.Value.CheckOnClick = $true
    $clb.Value.DisplayMember = 'Name'
    # IT-policy: drag & drop ska inte vara aktiverat i IPTCompile.
    try { $clb.Value.AllowDrop = $false } catch {}

    $btn.Value = New-Object System.Windows.Forms.Button
    $btn.Value.Text='Bläddra…'
    $btn.Value.Dock='Fill'
    $btn.Value.Margin=New-Object System.Windows.Forms.Padding(0,6,0,6)
    Set-AccentButton $btn.Value
}

function Set-ClbWatermark {
    param([System.Windows.Forms.CheckedListBox]$clb, [string]$Text)
    $tag = @{ Watermark = $Text }
    $clb.Tag = $tag
    if ($clb.Items.Count -eq 0) { Show-ClbWatermark $clb }
}

function Show-ClbWatermark {
    param([System.Windows.Forms.CheckedListBox]$clb)
    if (-not $clb.Tag -or -not $clb.Tag.Watermark) { return }
    $clb.ForeColor = [System.Drawing.Color]::Silver
    $clb.Items.Clear()
    [void]$clb.Items.Add($clb.Tag.Watermark)
}

function Hide-ClbWatermark {
    param([System.Windows.Forms.CheckedListBox]$clb)
    if (-not $clb.Tag -or -not $clb.Tag.Watermark) { return }
    $wm = $clb.Tag.Watermark
    for ($wi = $clb.Items.Count - 1; $wi -ge 0; $wi--) {
        try { if (([string]$clb.Items[$wi]) -eq $wm) { $clb.Items.RemoveAt($wi) } } catch {}
    }
    $clb.ForeColor = [System.Drawing.SystemColors]::WindowText
}

function Add-CLBItems {
    param([System.Windows.Forms.CheckedListBox]$clb,[System.IO.FileInfo[]]$files,[switch]$AutoCheckFirst,[switch]$Append)
    Hide-ClbWatermark $clb
    $clb.BeginUpdate()
    if (-not $Append) { $clb.Items.Clear() }
    foreach($f in $files){
        if ($f -isnot [System.IO.FileInfo]) { try { $f = Get-Item -LiteralPath $f } catch { continue } }
        # Undvik dubbletter vid Append
        $alreadyExists = $false
        if ($Append) {
            for ($di = 0; $di -lt $clb.Items.Count; $di++) {
                try { if ([string]$clb.Items[$di].FullName -eq [string]$f.FullName) { $alreadyExists = $true; break } } catch {}
            }
        }
        if (-not $alreadyExists) { [void]$clb.Items.Add($f, $false) }
    }
    $clb.EndUpdate()
    if ($AutoCheckFirst -and $clb.Items.Count -gt 0) { $clb.SetItemChecked(0,$true) }
    if ($clb.Items.Count -eq 0) { Show-ClbWatermark $clb }
    Update-StatusBar
}

function Clear-ClbCheckedItems {
    param([System.Windows.Forms.CheckedListBox]$clb)
    if (-not $clb) { return }
    for ($i = 0; $i -lt $clb.Items.Count; $i++) {
        try { $clb.SetItemChecked($i, $false) } catch {}
    }
}

function Get-ClbFilePaths {
    param([System.Windows.Forms.CheckedListBox]$clb)
    if (-not $clb) { return @() }
    $paths = New-Object System.Collections.Generic.List[string]
    for ($i = 0; $i -lt $clb.Items.Count; $i++) {
        try {
            $fi = [System.IO.FileInfo]$clb.Items[$i]
            if ($fi -and $fi.FullName) { [void]$paths.Add($fi.FullName) }
        } catch {}
    }
    return @($paths.ToArray())
}

function Write-AutoSelectionWarning {
    param([string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return }
    try { Gui-Log ("⚠️ " + $Text) 'Warn' 'USER' } catch {}
}

function Set-SingleRoleAutoCheckedItems {
    param(
        [System.Windows.Forms.CheckedListBox]$clb,
        [string]$RoleLabel
    )
    if (-not $clb) { return }
    Clear-ClbCheckedItems $clb
    $count = @($clb.Items).Count
    if ($count -eq 1) {
        try { $clb.SetItemChecked(0, $true) } catch {}
    } elseif ($count -gt 1) {
        Write-AutoSelectionWarning ("Flera {0}-kandidater hittades ({1}). Ingen auto-vald. Välj rätt fil manuellt." -f $RoleLabel, $count)
    }
    try { Update-StatusBar } catch {}
}

function Set-SealSplitAutoCheckedItems {
    param(
        [System.Windows.Forms.CheckedListBox]$NegList,
        [System.Windows.Forms.CheckedListBox]$PosList
    )

    Clear-ClbCheckedItems $NegList
    Clear-ClbCheckedItems $PosList

    $negCount = if ($NegList) { @($NegList.Items).Count } else { 0 }
    $posCount = if ($PosList) { @($PosList.Items).Count } else { 0 }

    if ($negCount -eq 1 -and $posCount -eq 1) {
        try { $NegList.SetItemChecked(0, $true) } catch {}
        try { $PosList.SetItemChecked(0, $true) } catch {}
    } elseif ($negCount -gt 1 -or $posCount -gt 1) {
        Write-AutoSelectionWarning ("Flera Seal Test-kandidater hittades (NEG={0}, POS={1}). Ingen auto-vald. Välj rätt NEG och POS manuellt." -f $negCount, $posCount)
    }
    try { Update-StatusBar } catch {}
}

function Set-CsvAutoCheckedItems {
    param([System.Windows.Forms.CheckedListBox]$clb)
    if (-not $clb -or $clb.Items.Count -eq 0) { return }

    try {
        Clear-ClbCheckedItems $clb

        $paths = @(Get-ClbFilePaths $clb)

        $primaryCsvs = New-Object System.Collections.Generic.List[string]
        $resampleCsvs = New-Object System.Collections.Generic.List[string]
        foreach ($csvPath in @($paths.ToArray())) {
            if (-not $csvPath) { continue }
            $isResample = $false
            try { $isResample = Test-IsResampleCsv -Path $csvPath } catch { $isResample = $false }
            if ($isResample) {
                [void]$resampleCsvs.Add($csvPath)
            } else {
                [void]$primaryCsvs.Add($csvPath)
            }
        }

        if ($paths.Count -eq 1 -and $primaryCsvs.Count -eq 0 -and $resampleCsvs.Count -eq 1) {
            Write-AutoSelectionWarning 'Endast Resampling-CSV hittades. Välj Primary CSV manuellt.'
            return
        }

        if ($paths.Count -gt 2) {
            Write-AutoSelectionWarning ("Flera CSV-kandidater hittades ({0}; Primary={1}, Resampling={2}). Ingen auto-vald. Välj Primary CSV och eventuell Resampling CSV manuellt." -f $paths.Count, $primaryCsvs.Count, $resampleCsvs.Count)
            return
        }

        if ($primaryCsvs.Count -eq 1 -and $resampleCsvs.Count -le 1) {
            $wanted = @{}
            $wanted[($primaryCsvs[0] + '').ToLowerInvariant()] = $true
            if ($resampleCsvs.Count -eq 1) { $wanted[($resampleCsvs[0] + '').ToLowerInvariant()] = $true }

            for ($i = 0; $i -lt $clb.Items.Count; $i++) {
                try {
                    $fi = [System.IO.FileInfo]$clb.Items[$i]
                    $key = ($fi.FullName + '').ToLowerInvariant()
                    if ($wanted.ContainsKey($key)) { $clb.SetItemChecked($i, $true) }
                } catch {}
            }
        } else {
            Write-AutoSelectionWarning ("CSV-valet är tvetydigt (Primary={0}, Resampling={1}). Ingen auto-vald. Välj rätt CSV-fil(er) manuellt." -f $primaryCsvs.Count, $resampleCsvs.Count)
        }
    } catch {
        Write-AutoSelectionWarning 'CSV-kandidater kunde inte klassificeras säkert. Välj CSV-fil(er) manuellt.'
    } finally {
        try { Update-StatusBar } catch {}
    }
}

function Test-BuildSelectedFilesOrLog {
    try {
        $csvPaths = @(Get-AllCheckedFilePaths $clbCsv)
        $csvCandidates = @(Get-ClbFilePaths $clbCsv)
        if ($csvPaths.Count -eq 0 -and $csvCandidates.Count -gt 0) {
            $candPrimary = 0
            $candResample = 0
            foreach ($p in $csvCandidates) {
                $isRes = $false
                try { $isRes = Test-IsResampleCsv -Path $p } catch { $isRes = $false }
                if ($isRes) { $candResample++ } else { $candPrimary++ }
            }
            $csvAmbiguous = ($csvCandidates.Count -gt 2 -or $candPrimary -ne 1 -or $candResample -gt 1)
            if ($csvAmbiguous) {
                Gui-Log ("❌ CSV-kandidater kräver manuellt val (kandidater={0}, Primary={1}, Resampling={2}). Välj rätt CSV-fil(er) innan rapport skapas." -f $csvCandidates.Count, $candPrimary, $candResample) 'Error'
                return $false
            }
        }
        foreach ($p in $csvPaths) {
            if (-not (Test-Path -LiteralPath $p)) {
                Gui-Log ("❌ Vald CSV-fil finns inte längre: {0}" -f $p) 'Error'
                return $false
            }
        }
        $csvSelCheck = Resolve-CsvPrimaryAndResample -CsvPaths $csvPaths
        if (-not $csvSelCheck.Ok) {
            Gui-Log $csvSelCheck.ErrorMessage 'Error'
            return $false
        }

        $wsPaths = @(Get-AllCheckedFilePaths $clbLsp)
        $wsCandidates = @(Get-ClbFilePaths $clbLsp)
        if ($wsPaths.Count -eq 0 -and $wsCandidates.Count -gt 1) {
            Gui-Log ("❌ Flera Worksheet-kandidater hittades ({0}). Välj rätt Worksheet manuellt innan rapport skapas." -f $wsCandidates.Count) 'Error'
            return $false
        }
        if ($wsPaths.Count -gt 1) {
            Gui-Log "❌ Flera Worksheet-filer är valda. Välj exakt en Worksheet eller avmarkera alla." 'Error'
            return $false
        }
        foreach ($p in $wsPaths) {
            if (-not (Test-Path -LiteralPath $p)) {
                Gui-Log ("❌ Vald Worksheet-fil finns inte längre: {0}" -f $p) 'Error'
                return $false
            }
        }

        if (Test-SealTestMergedMode) {
            $mergedPaths = @((Get-AllCheckedFilePaths $clbPos) + (Get-AllCheckedFilePaths $clbNeg) | Where-Object { $_ })
            if ($mergedPaths.Count -ne 1) {
                Gui-Log "❌ Merged-läge kräver exakt en vald Seal Test-fil." 'Error'
                return $false
            }
            if (-not (Test-Path -LiteralPath $mergedPaths[0])) {
                Gui-Log ("❌ Vald Seal Test-fil finns inte längre: {0}" -f $mergedPaths[0]) 'Error'
                return $false
            }
        } else {
            $negPaths = @(Get-AllCheckedFilePaths $clbNeg)
            $posPaths = @(Get-AllCheckedFilePaths $clbPos)
            if ($negPaths.Count -ne 1 -or $posPaths.Count -ne 1) {
                Gui-Log ("❌ Split-läge kräver exakt en Seal NEG och exakt en Seal POS (valda: NEG={0}, POS={1})." -f $negPaths.Count, $posPaths.Count) 'Error'
                return $false
            }
            foreach ($p in @($negPaths + $posPaths)) {
                if (-not (Test-Path -LiteralPath $p)) {
                    Gui-Log ("❌ Vald Seal Test-fil finns inte längre: {0}" -f $p) 'Error'
                    return $false
                }
            }
        }

        return $true
    } catch {
        Gui-Log ("❌ Filvalidering misslyckades: " + $_.Exception.Message) 'Error'
        return $false
    }
}

function Get-CheckedFilePath { param([System.Windows.Forms.CheckedListBox]$clb)
    if (-not $clb) { return $null }
    for($i=0;$i -lt $clb.Items.Count;$i++){
        if ($clb.GetItemChecked($i)) {
            $fi = [System.IO.FileInfo]$clb.Items[$i]
            return $fi.FullName
        }
    }
    return $null
}

function Get-AllCheckedFilePaths { param([System.Windows.Forms.CheckedListBox]$clb)
    if (-not $clb) { return @() }
    $paths = New-Object 'System.Collections.Generic.List[string]'
    for($i=0;$i -lt $clb.Items.Count;$i++){
        if ($clb.GetItemChecked($i)) {
            $fi = [System.IO.FileInfo]$clb.Items[$i]
            [void]$paths.Add($fi.FullName)
        }
    }
    return @($paths.ToArray())
}


function Get-SealTestMode {
    # Returnerar 'Split' eller 'Merged'. Default är Split för bakåtkompatibilitet.
    try {
        if (Get-Variable -Name cmbSealMode -Scope Global -ErrorAction SilentlyContinue) {
            # no-op; variabeln brukar ligga i script scope i GUI:t
        }
    } catch {}
    try {
        if ($cmbSealMode -and $cmbSealMode.SelectedItem) {
            $txt = (($cmbSealMode.SelectedItem + '').Trim())
            if ($txt -match '(?i)^(merge|en\s+seal)') { return 'Merged' }
            if ($txt -match '(?i)^split') { return 'Split' }
        }
    } catch {}
    try {
        $m = (($script:SealTestMode + '').Trim())
        if ($m -match '(?i)^merged?$') { return 'Merged' }
        if ($m -match '(?i)^split$') { return 'Split' }
    } catch {}
    try {
        $cfgMode = (Get-ConfigValue -Name 'SealTestInputMode' -Default 'Split' -ConfigOverride $Config)
        if (($cfgMode + '') -match '(?i)^merged?$') { return 'Merged' }
    } catch {}
    return 'Split'
}

function Test-SealTestMergedMode {
    return ((Get-SealTestMode) -eq 'Merged')
}

function Get-SealTestModeLabel {
    if (Test-SealTestMergedMode) { return 'Merged / en Seal Test-fil' }
    return 'Split / Seal Test NEG+POS'
}

function Get-SealMergedInputPath {
    # I Merged-läge är POS-listan den avsedda platsen för den enda Seal Test-filen.
    # Fallback till NEG-listan finns bara för att undvika hårt stopp vid manuellt felval.
    $p = $null
    try { $p = Get-CheckedFilePath $clbPos } catch {}
    if (-not $p) { try { $p = Get-CheckedFilePath $clbNeg } catch {} }
    return $p
}

function Update-SealTestModeUI {
    $merged = Test-SealTestMergedMode
    try { $script:SealTestMode = if ($merged) { 'Merged' } else { 'Split' } } catch {}

    try {
        if ($lblNeg) { $lblNeg.Text = if ($merged) { 'Seal Test NEG (ej använd):' } else { 'Seal Test Neg:' } }
        if ($lblPos) { $lblPos.Text = if ($merged) { 'Seal Test-fil:' } else { 'Seal Test Pos:' } }
    } catch {}

    try {
        if ($clbNeg) { $clbNeg.Enabled = -not $merged }
        if ($btnNegBrowse) { $btnNegBrowse.Enabled = -not $merged }
        if ($merged -and $clbNeg) { Add-CLBItems -clb $clbNeg -files @() }
    } catch {}

    try {
        if ($chkSealTest) { $chkSealTest.Text = if ($merged) { ' Seal Test-fil' } else { ' Seal Test (NEG+POS)' } }
        if ($grpSignSamm) { $grpSignSamm.Text = if ($merged) { 'Signering — Seal Test-fil' } else { 'Signering — Seal Test NEG+POS' } }
        if ($chkSignOverwrite) { $chkSignOverwrite.Tag = if ($merged) { 'Skriv signatur i vald Seal Test-fil. Worksheet-signering är avstängd i denna version.' } else { 'Skriv signatur i Seal Test POS/NEG. Worksheet-signering är avstängd i denna version.' } }
    } catch {}

    try { Update-StatusBar } catch {}
}

function Clear-GUI {
    $txtLSP.Text = ''
    $txtSammName.Text = ''; $txtSammDate.Text = ''; $txtSealTestSign.Text = ''
    $chkSealTest.Checked = $false; $chkWsSamm.Checked = $false; $chkSignOverwrite.Checked = $false
    try { if ($cmbSealMode) { $cmbSealMode.SelectedIndex = 0 }; $script:SealTestMode = 'Split'; Update-SealTestModeUI } catch {}
    $txtGranskName.Text = ''; $txtGranskDate.Text = ''
    $chkWsGransk.Checked = $false; $chkGranskOverwrite.Checked = $false

    # Nollställ ALLA build-relaterade cacher (förhindra cross-kontaminering mellan körningar)
    $script:RobalDateShort          = $null
    $script:RuleEngineShadow        = $null
    $script:RuleEngineShadowRes     = $null
    $script:RuleEngineCsvObjs       = $null
    $script:RuleEngineCsvObjsRes    = $null
    $script:RuleBankCache           = $null
    $script:CsvLinesPrimary         = $null
    $script:CsvLinesResample        = $null
    $script:QcReminderB3            = $null

    Add-CLBItems -clb $clbCsv -files @()
    Add-CLBItems -clb $clbNeg -files @()
    Add-CLBItems -clb $clbPos -files @()
    Add-CLBItems -clb $clbLsp -files @()
    $outputBox.Clear()
    Update-BuildEnabled
    try { if ($script:slOpenReport) { $script:slOpenReport.Visible = $false }; if ($script:slOpenFolder) { $script:slOpenFolder.Visible = $false } } catch {}
    Gui-Log "🧹 Fönstret rensat." 'Info'
    Update-BatchLink
    try { Update-ReportCountIndicator } catch {}
    try { Apply-UserDefaults } catch {}
}

function Get-SelectedFileCount {
    $n = 0

    # CSV kan vara 1–2 filer vid resample
    try {
        if ($clbCsv -and $clbCsv.CheckedItems) { $n += [int]$clbCsv.CheckedItems.Count }
        elseif (Get-CheckedFilePath $clbCsv) { $n++ }
    } catch {
        if (Get-CheckedFilePath $clbCsv) { $n++ }
    }

    if (Test-SealTestMergedMode) {
        if (Get-SealMergedInputPath) { $n++ }
    } else {
        if (Get-CheckedFilePath $clbNeg) { $n++ }
        if (Get-CheckedFilePath $clbPos) { $n++ }
    }
    if (Get-CheckedFilePath $clbLsp) { $n++ }
    return $n
}

function Update-StatusBar {
    try { $slCount.Text = "$(Get-SelectedFileCount) filer valda" } catch {}
    try { Update-ReadinessBanner } catch {}
}

function Get-CheckedItemCountSafe {
    param([System.Windows.Forms.CheckedListBox]$clb)
    try {
        if (-not $clb) { return 0 }
        $n = 0
        for ($i=0; $i -lt $clb.Items.Count; $i++) {
            try { if ($clb.GetItemChecked($i)) { $n++ } } catch {}
        }
        return $n
    } catch { return 0 }
}

function Get-ReadinessInfo {
    $missingRequired = New-Object 'System.Collections.Generic.List[string]'
    $warnings = New-Object 'System.Collections.Generic.List[string]'

    try {
        if (Test-SealTestMergedMode) {
            if (-not (Get-SealMergedInputPath)) { [void]$missingRequired.Add('Seal Test-fil') }
        } else {
            if (-not (Get-CheckedFilePath $clbNeg)) { [void]$missingRequired.Add('Seal NEG') }
            if (-not (Get-CheckedFilePath $clbPos)) { [void]$missingRequired.Add('Seal POS') }
        }
    } catch { [void]$missingRequired.Add('Seal Test') }

    try { if ((Get-CheckedItemCountSafe $clbCsv) -eq 0) { [void]$warnings.Add('CSV saknas') } } catch {}
    try { if (-not (Get-CheckedFilePath $clbLsp)) { [void]$warnings.Add('Worksheet saknas') } } catch {}

    [pscustomobject]@{
        Ready           = ($missingRequired.Count -eq 0)
        MissingRequired = @($missingRequired.ToArray())
        Warnings        = @($warnings.ToArray())
        FileCount       = (Get-SelectedFileCount)
        Mode            = (Get-SealTestModeLabel)
    }
}

function Update-ReadinessBanner {
    try {
        if (-not $script:lblReadiness -or -not $script:pReadinessBanner) { return }

        if ($script:BuildInProgress) {
            $msg = ($script:UiCurrentStepMessage + '').Trim()
            if (-not $msg) { $msg = 'Skapar rapport…' }
            $script:lblReadiness.Text = "$msg"
            $script:pReadinessBanner.BackColor = [System.Drawing.Color]::FromArgb(227,242,253)
            $script:lblReadiness.ForeColor = [System.Drawing.Color]::FromArgb(21,101,192)
            return
        }

        $info = Get-ReadinessInfo
        if ($info.Ready) {
            $warnText = ''
            if ($info.Warnings -and $info.Warnings.Count -gt 0) { $warnText = ' | Obs: ' + (($info.Warnings) -join ', ') }
            $script:lblReadiness.Text = "Redo att skapa rapport — $($info.FileCount) filer valda | $($info.Mode)$warnText"
            $script:pReadinessBanner.BackColor = [System.Drawing.Color]::FromArgb(232,245,233)
            $script:lblReadiness.ForeColor = [System.Drawing.Color]::FromArgb(27,94,32)
        } else {
            $missing = (($info.MissingRequired) -join ', ')
            if (-not $missing) { $missing = 'filval' }
            $script:lblReadiness.Text = "Nästan redo — välj $missing"
            $script:pReadinessBanner.BackColor = [System.Drawing.Color]::FromArgb(255,248,225)
            $script:lblReadiness.ForeColor = [System.Drawing.Color]::FromArgb(130,88,0)
        }
    } catch {}
}

function Set-SealTestModeSelection {
    param([ValidateSet('Split','Merged')][string]$Mode)
    try {
        $script:SealTestMode = $Mode
        if ($cmbSealMode) {
            $targetIndex = if ($Mode -eq 'Merged') { 1 } else { 0 }
            if ($cmbSealMode.SelectedIndex -ne $targetIndex) { $cmbSealMode.SelectedIndex = $targetIndex }
        }
        Update-SealTestModeUI
        Update-BuildEnabled
    } catch {}
}

function Invoke-SmartSealModeDetection {
    param(
        [object[]]$Neg,
        [object[]]$Pos,
        [object[]]$Merged,
        [switch]$Silent
    )

    try {
        $negCount = @($Neg).Count
        $posCount = @($Pos).Count
        $mergedItems = @($Merged)
        $neutralMerged = @($mergedItems | Where-Object {
            try { $_.Name -notmatch '(?i)(^|[ _-])(neg|pos)([ _.-]|$)' } catch { $true }
        })

        $detected = $null
        $reason = ''
        if ($neutralMerged.Count -gt 0) {
            $detected = 'Merged'
            $reason = 'neutral Seal Test-fil hittades'
        }
        elseif ($negCount -gt 0 -and $posCount -gt 0) {
            $detected = 'Split'
            $reason = 'både NEG och POS hittades'
        }
        elseif ($mergedItems.Count -eq 1 -and $negCount -eq 0) {
            $detected = 'Merged'
            $reason = 'endast en Seal Test-fil hittades'
        }

        if (-not $detected) { return $null }

        $current = Get-SealTestMode
        if ($current -ne $detected) {
            Set-SealTestModeSelection -Mode $detected
            if (-not $Silent) {
                Gui-Log ("🔎 Seal Test mode föreslagen automatiskt: {0} ({1}). Du kan ändra manuellt." -f (Get-SealTestModeLabel), $reason) 'Info'
            }
        }
        return $detected
    } catch { return $null }
}

function Get-BuildAuditCsvPaths {
    $paths = New-Object 'System.Collections.Generic.List[string]'
    try {
        $netRoot = ($env:IPT_NETWORK_ROOT + '').Trim()
        if ($netRoot) { [void]$paths.Add((Join-Path $netRoot 'audit\build_audit.csv')) }
    } catch {}
    try { if ($ScriptRootPath) { [void]$paths.Add((Join-Path $ScriptRootPath 'audit\build_audit.csv')) } } catch {}
    try { if ($ScriptRootPath) { [void]$paths.Add((Join-Path $ScriptRootPath 'Infrastructure\audit\build_audit.csv')) } } catch {}

    $seen = @{}
    foreach ($p in $paths) {
        if ($p -and -not $seen.ContainsKey($p)) {
            $seen[$p] = $true
            if (Test-Path -LiteralPath $p) { $p }
        }
    }
}

function Get-AuditCreatedReportCount {
    try {
        $keys = @{}
        foreach ($csvPath in @(Get-BuildAuditCsvPaths)) {
            try {
                $rows = @(Import-Csv -LiteralPath $csvPath -ErrorAction Stop)
                foreach ($r in $rows) {
                    $status = ($r.Status + '').Trim()
                    if ($status -and $status -notmatch '(?i)^(OK|Warnings)$') { continue }
                    $report = ($r.ReportPath + '').Trim()
                    $ts = ($r.Timestamp + '').Trim()
                    $user = ($r.User + '').Trim()
                    $key = if ($report) { $report.ToLowerInvariant() } else { ($ts + '|' + $user) }
                    if ($key) { $keys[$key] = $true }
                }
            } catch {}
        }
        return $keys.Count
    } catch { return 0 }
}

function Update-ReportCountIndicator {
    try {
        if (-not $script:slSession) { return }
        $total = Get-AuditCreatedReportCount
        if ($total -gt 0) {
            $script:slSession.Text = ("Totalt: {0} rapporter skapade" -f $total)
            $script:slSession.Visible = $true
        }
        elseif ($script:SessionStats -and $script:SessionStats.ReportCount -gt 0) {
            $script:slSession.Text = if ($script:SessionStats.ReportCount -eq 1) { '1 rapport skapad' } else { ("{0} rapporter skapade" -f $script:SessionStats.ReportCount) }
            $script:slSession.Visible = $true
        }
    } catch {}
}

function Invoke-UiPump {
    try { [System.Windows.Forms.Application]::DoEvents() } catch {}
}

function Set-UiBusy {
    param(
        [Parameter(Mandatory)][bool]$Busy,
        [string]$Message = ''
    )
    try {
        if ($Busy) {
            $script:UiCurrentStepMessage = $Message
            $slWork.Text = $Message
            $pbWork.Visible = $true
            $pbWork.Style   = 'Marquee'
            $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
            $btnScan.Enabled  = $false
            $btnBuild.Enabled = $false
        } else {
            $script:UiCurrentStepMessage = ''
            $pbWork.Visible = $false
            $pbWork.Style   = 'Blocks'
            $pbWork.Value   = 0
            $slWork.Text = ''
            $form.Cursor = [System.Windows.Forms.Cursors]::Default
            $btnScan.Enabled = $true
            Update-BuildEnabled
        }
        $status.Refresh()
        $form.Refresh()
        Invoke-UiPump
    } catch {}
}

function Set-UiStep {
    param(
        [Parameter(Mandatory)][int]$Percent,
        [string]$Message = ''
    )
    try {
        if ($Percent -lt 0) { $Percent = 0 }
        if ($Percent -gt 100) { $Percent = 100 }
        $script:UiCurrentStepMessage = $Message
        $slWork.Text = $Message
        try { Update-ReadinessBanner } catch {}
        $pbWork.Visible = $true
        $pbWork.Style   = 'Blocks'
        $pbWork.Minimum = 0
        $pbWork.Maximum = 100
        if ($pbWork.Value -ne $Percent) { $pbWork.Value = $Percent }
        $status.Refresh()
        $form.Refresh()
        Invoke-UiPump
    } catch {}
}

function Update-BuildEnabled {
    try {
        if ($script:BuildInProgress) {
            $btnBuild.Enabled = $false
        }
        elseif (Test-SealTestMergedMode) {
            $btnBuild.Enabled = [bool](Get-SealMergedInputPath)
        } else {
            $btnBuild.Enabled = [bool]((Get-CheckedFilePath $clbNeg) -and (Get-CheckedFilePath $clbPos))
        }
    } catch {}
    Update-StatusBar
    try { Update-ReadinessBanner } catch {}
}


# Phase 10 safe refactor: moved from Main.ps1

function Update-OverwriteVerificationUI {
    # 2026-05-18: endast Seal Test POS/NEG-signering är aktiv i LIVE.
    # Worksheet Sammanställning/Granskning ska inte påverka krav på overwrite.
    $reqSamm = [bool]$chkSealTest.Checked
    $reqGransk = $false

    if ($reqSamm -and (-not $chkSignOverwrite.Checked)) {
        $chkSignOverwrite.BackColor = $script:OverwriteUiState.WarnBackColor
        $chkSignOverwrite.ForeColor = $script:OverwriteUiState.Sign.ForeColor
        $chkSignOverwrite.Font = $script:OverwriteUiState.BoldFont
        $toolTip.SetToolTip($chkSignOverwrite, 'OBLIGATORISKT: Kryssa i för att skapa rapport med signering (Sammanställning).')
    } else {
        $chkSignOverwrite.BackColor = $script:OverwriteUiState.Sign.BackColor
        $chkSignOverwrite.ForeColor = $script:OverwriteUiState.Sign.ForeColor
        $chkSignOverwrite.Font = $script:OverwriteUiState.Sign.Font
        $toolTip.SetToolTip($chkSignOverwrite, $script:OverwriteUiState.Sign.Tooltip)
    }

    if ($reqGransk -and (-not $chkGranskOverwrite.Checked)) {
        $chkGranskOverwrite.BackColor = $script:OverwriteUiState.WarnBackColor
        $chkGranskOverwrite.ForeColor = $script:OverwriteUiState.Gransk.ForeColor
        $chkGranskOverwrite.Font = $script:OverwriteUiState.BoldFont
        $toolTip.SetToolTip($chkGranskOverwrite, 'OBLIGATORISKT: Kryssa i för att skapa rapport med signering (Granskning).')
    } else {
        $chkGranskOverwrite.BackColor = $script:OverwriteUiState.Gransk.BackColor
        $chkGranskOverwrite.ForeColor = $script:OverwriteUiState.Gransk.ForeColor
        $chkGranskOverwrite.Font = $script:OverwriteUiState.Gransk.Font
        $toolTip.SetToolTip($chkGranskOverwrite, $script:OverwriteUiState.Gransk.Tooltip)
    }
}

function Enable-DoubleBuffer {
    $pi = [Windows.Forms.Control].GetProperty('DoubleBuffered',[Reflection.BindingFlags]'NonPublic,Instance')
    foreach($c in @($content,$pLog,$grpPick,$grpSignSamm,$grpSignGransk,$grpDl)) { if ($c) { $pi.SetValue($c,$true,$null) } }
}
