﻿function Get-CsvTextEncoding {
    <#
        BOM-aware reader helper for GeneXpert Test Summary CSV files.

        Important:
        - Old exports are usually ANSI/Default encoded.
        - Some newer exports may have UTF-8/UTF-16 BOM.
        - Windows PowerShell 5.1 Get-Content -Encoding Default is not safe for every case.
    #>
    param([Parameter(Mandatory)][string]$Path)

    try {
        $fs = [System.IO.File]::OpenRead($Path)
        try {
            $b0 = $fs.ReadByte()
            $b1 = $fs.ReadByte()
            $b2 = $fs.ReadByte()
            $b3 = $fs.ReadByte()

            if ($b0 -eq 0xEF -and $b1 -eq 0xBB -and $b2 -eq 0xBF) {
                return [System.Text.Encoding]::UTF8
            }
            if ($b0 -eq 0xFF -and $b1 -eq 0xFE) {
                return [System.Text.Encoding]::Unicode
            }
            if ($b0 -eq 0xFE -and $b1 -eq 0xFF) {
                return [System.Text.Encoding]::BigEndianUnicode
            }

            # Preserve legacy behavior for non-BOM files.
            return [System.Text.Encoding]::Default
        } finally {
            try { $fs.Dispose() } catch {}
        }
    } catch {
        return [System.Text.Encoding]::Default
    }
}

function Get-CsvFileLines {
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$TotalCount = 0
    )

    $lines = New-Object System.Collections.Generic.List[string]
    if (-not (Test-Path -LiteralPath $Path)) { return @() }

    $sr = $null
    try {
        $enc = Get-CsvTextEncoding -Path $Path
        $sr = New-Object System.IO.StreamReader($Path, $enc, $true)
        $n = 0
        while (($line = $sr.ReadLine()) -ne $null) {
            [void]$lines.Add($line)
            $n++
            if ($TotalCount -gt 0 -and $n -ge $TotalCount) { break }
        }
    } catch {
        try {
            if ($TotalCount -gt 0) {
                return @(Get-Content -LiteralPath $Path -Encoding Default -TotalCount $TotalCount)
            } else {
                return @(Get-Content -LiteralPath $Path -Encoding Default)
            }
        } catch {
            try { Gui-Log "⚠️ Kunde inte läsa CSV: $($_.Exception.Message)" 'Warn' } catch {}
            return @()
        }
    } finally {
        try { if ($sr) { $sr.Close() } } catch {}
        try { if ($sr) { $sr.Dispose() } } catch {}
    }

    return @($lines.ToArray())
}

function Unwrap-PackedCsvLine {
    <#
        Handles the newer GeneXpert export variant where each logical CSV row
        is written as ONE quoted field containing comma-separated content:

            "Assay,Assay Version,Sample ID,..."

        Standard CSV parsing correctly treats that as one field. For IPTCompile
        we intentionally unwrap that special "packed row" before splitting.
    #>
    param(
        [AllowNull()][string]$Line,
        [string]$PreferredDelimiter = ','
    )

    if ($null -eq $Line) { return '' }

    $s = ($Line + '').Trim()
    if ($s.Length -lt 2) { return $Line }

    if ($s.StartsWith('"') -and $s.EndsWith('"')) {
        $inner = $s.Substring(1, $s.Length - 2)

        # Only unwrap when it looks like a complete row packed into one quoted cell.
        # This avoids disturbing normal CSV rows with individual quoted fields.
        $commaCount = ([regex]::Matches($inner, ',')).Count
        $tabCount   = ([regex]::Matches($inner, "`t")).Count
        $semiCount  = ([regex]::Matches($inner, ';')).Count

        if (($commaCount -ge 3) -or ($tabCount -ge 3) -or ($semiCount -ge 3)) {
            return ($inner -replace '""','"')
        }
    }

    return $Line
}

function Get-CsvDelimiter {
    param([string]$Path)

    try {
        $lines = @(Get-CsvFileLines -Path $Path -TotalCount 40)
        if (-not $lines -or $lines.Count -eq 0) { return ',' }

        $bestDelim = ','
        $bestScore = -1

        foreach ($line in $lines) {
            if (-not $line -or -not ($line + '').Trim()) { continue }

            $probe = Unwrap-PackedCsvLine -Line $line
            $scoreComma = ([regex]::Matches($probe, ',')).Count
            $scoreSemi  = ([regex]::Matches($probe, ';')).Count
            $scoreTab   = ([regex]::Matches($probe, "`t")).Count

            # Prefer a real Test Summary header when found.
            if ($probe -imatch '\bAssay\b' -and $probe -imatch '\bSample\s*ID\b') {
                if ($scoreTab -gt $scoreComma -and $scoreTab -gt $scoreSemi) { return "`t" }
                if ($scoreSemi -gt $scoreComma) { return ';' }
                return ','
            }

            if ($scoreComma -gt $bestScore) { $bestScore = $scoreComma; $bestDelim = ',' }
            if ($scoreSemi  -gt $bestScore) { $bestScore = $scoreSemi;  $bestDelim = ';' }
            if ($scoreTab   -gt $bestScore) { $bestScore = $scoreTab;   $bestDelim = "`t" }
        }

        if ($bestScore -le 0) { return ',' }
        return $bestDelim
    } catch {
        try { Gui-Log "⚠️ Get-CsvDelimiter misslyckades: $($_.Exception.Message)" 'Warn' } catch {}
        return ','
    }
}

function ConvertTo-CsvFields {
    param(
        [Parameter(Mandatory=$true)][AllowEmptyString()][string]$Line,
        [string]$Delimiter
    )
    if ($null -eq $Line) { return @() }

    $del = $Delimiter
    if ([string]::IsNullOrWhiteSpace($del)) {
        $probe = Unwrap-PackedCsvLine -Line $Line
        $cSemi  = ([regex]::Matches($probe, ';')).Count
        $cComma = ([regex]::Matches($probe, ',')).Count
        $cTab   = ([regex]::Matches($probe, "`t")).Count

        if ($cTab -gt $cComma -and $cTab -gt $cSemi) { $del = "`t" }
        elseif ($cSemi -gt $cComma) { $del = ';' }
        else { $del = ',' }
    }

    $lineToSplit = Unwrap-PackedCsvLine -Line $Line -PreferredDelimiter $del

    $d  = [regex]::Escape($del)
    $rx = $d + '(?=(?:(?:[^"]*"){2})*[^"]*$)'
    $arr = [regex]::Split($lineToSplit, $rx)

    # If a row still parsed as one field but contains the delimiter after unquoting,
    # try once more on the unwrapped string. This catches packed whole-row CSV.
    if (($arr.Count -eq 1) -and ($lineToSplit -ne $Line) -and ($lineToSplit.IndexOf($del) -ge 0)) {
        $arr = [regex]::Split($lineToSplit, $rx)
    }

    return ,@($arr | ForEach-Object {
        $v = ($_ + '').Trim()
        if ($v.Length -ge 2 -and $v.StartsWith('"') -and $v.EndsWith('"')) {
            $v = $v.Substring(1, $v.Length - 2)
        }
        ($v -replace '""','"').Trim()
    })
}

function Test-CsvHeaderFields {
    param([object[]]$Fields)

    if (-not $Fields -or $Fields.Count -lt 3) { return $false }

    $hasAssay = $false
    $hasSampleId = $false
    foreach ($f in $Fields) {
        $h = (($f + '') -replace '^\uFEFF','').Trim()
        if ($h -ieq 'Assay') { $hasAssay = $true }
        if ($h -imatch '^Sample\s*ID$' -or $h -ieq 'SampleID' -or $h -imatch '^Sample\s*Id$') { $hasSampleId = $true }
    }

    return ($hasAssay -and $hasSampleId)
}

function Get-TestSummaryCsvLayout {
    param([Parameter(Mandatory)][string]$Path)

    $delim = Get-CsvDelimiter -Path $Path
    $lines = @(Get-CsvFileLines -Path $Path)
    if (-not $lines -or $lines.Count -eq 0) {
        return [pscustomobject]@{
            Ok             = $false
            Delimiter      = $delim
            HeaderIndex    = -1
            DataStartIndex = -1
            Headers        = @()
            Lines          = @()
            Format         = 'Unknown'
        }
    }

    $headerIndex = -1
    $headers = @()

    $maxScan = [Math]::Min($lines.Count, 40)
    for ($i = 0; $i -lt $maxScan; $i++) {
        $fields = @(ConvertTo-CsvFields -Line $lines[$i] -Delimiter $delim)
        if (Test-CsvHeaderFields -Fields $fields) {
            $headerIndex = $i
            $headers = @($fields)
            break
        }
    }

    if ($headerIndex -lt 0) {
        # Legacy fallback: old Test Summary header is normally line 8 / index 7.
        if ($lines.Count -gt 7) {
            $fields = @(ConvertTo-CsvFields -Line $lines[7] -Delimiter $delim)
            if ($fields -and $fields.Count -ge 3) {
                $headerIndex = 7
                $headers = @($fields)
            }
        }
    }

    if ($headerIndex -lt 0) {
        return [pscustomobject]@{
            Ok             = $false
            Delimiter      = $delim
            HeaderIndex    = -1
            DataStartIndex = -1
            Headers        = @()
            Lines          = @($lines)
            Format         = 'Unknown'
        }
    }

    $dataStart = $headerIndex + 1
    while ($dataStart -lt $lines.Count) {
        $ln = $lines[$dataStart]
        if ($ln -and (($ln + '').Trim().Length -gt 0)) {
            $f = @(ConvertTo-CsvFields -Line $ln -Delimiter $delim)
            if ($f -and (($f -join '').Trim().Length -gt 0)) { break }
        }
        $dataStart++
    }

    $fmt = 'Legacy'
    if ($headerIndex -eq 8) { $fmt = 'HeaderRow9_DataRow11' }
    elseif ($headerIndex -eq 7) { $fmt = 'HeaderRow8_DataRow10' }
    else { $fmt = "HeaderRow$($headerIndex + 1)" }

    return [pscustomobject]@{
        Ok             = $true
        Delimiter      = $delim
        HeaderIndex    = $headerIndex
        DataStartIndex = $dataStart
        Headers        = @($headers)
        Lines          = @($lines)
        Format         = $fmt
    }
}

function Test-IsResampleCsv {
    <# Returnerar $true om CSV:n innehåller _RES_ i Sample ID-kolumnen (>= MinHits träffar). #>
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$MinHits = 3
    )

    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    $threshold = [Math]::Max(1, [int]$MinHits)

    try {
        $layout = Get-TestSummaryCsvLayout -Path $Path
        if (-not $layout.Ok) { return $false }

        $sampleIdIdx = 2
        for ($i = 0; $i -lt $layout.Headers.Count; $i++) {
            $h = ($layout.Headers[$i] + '').Trim()
            if ($h -imatch '^Sample\s*ID$' -or $h -ieq 'SampleID' -or $h -imatch '^Sample\s*Id$') {
                $sampleIdIdx = $i
                break
            }
        }

        $resCount = 0
        for ($r = $layout.DataStartIndex; $r -lt $layout.Lines.Count; $r++) {
            $line = $layout.Lines[$r]
            if (-not $line -or ($line + '').Trim().Length -eq 0) { continue }

            $fields = @(ConvertTo-CsvFields -Line $line -Delimiter $layout.Delimiter)
            if (-not $fields -or $fields.Count -le $sampleIdIdx) { continue }

            $sid = ($fields[$sampleIdIdx] + '')
            if ($sid -imatch '_RES_') { $resCount++ }
            if ($resCount -ge $threshold) { return $true }
        }

        return $false
    } catch {
        try {
            Gui-Log ("⚠️ Test-IsResampleCsv misslyckades för '{0}': {1}" -f (Split-Path $Path -Leaf), $_.Exception.Message) 'Warn' 'DEBUG'
        } catch {}
        return $false
    }
}

function Resolve-CsvPrimaryAndResample {
    <# Klassificerar 0-2 CSV-filer till Primary + ev. Resample med samma regel som i buildflödet. #>
    param([string[]]$CsvPaths)

    $result = [pscustomobject]@{
        Ok             = $true
        PrimaryCsv     = $null
        ResampleCsv    = $null
        HasResample    = $false
        ErrorMessage   = $null
        WarningMessage = $null
    }

    $paths = @($CsvPaths | Where-Object { $_ -and (($_ + '').Trim().Length -gt 0) })

    if ($paths.Count -eq 0) { return $result }

    if ($paths.Count -eq 1) {
        if (Test-IsResampleCsv -Path $paths[0]) {
            $result.Ok = $false
            $result.ResampleCsv = $paths[0]
            $result.ErrorMessage = '❌ Enbart Resampling-CSV vald. Välj även Primary CSV innan rapport kan skapas.'
            return $result
        }
        $result.PrimaryCsv = $paths[0]
        return $result
    }

    if ($paths.Count -eq 2) {
        $isRes0 = Test-IsResampleCsv -Path $paths[0]
        $isRes1 = Test-IsResampleCsv -Path $paths[1]

        if ($isRes0 -and -not $isRes1) {
            $result.ResampleCsv = $paths[0]
            $result.PrimaryCsv = $paths[1]
        } elseif ($isRes1 -and -not $isRes0) {
            $result.PrimaryCsv = $paths[0]
            $result.ResampleCsv = $paths[1]
        } elseif (-not $isRes0 -and -not $isRes1) {
            $result.Ok = $false
            $result.ErrorMessage = '❌ Du har valt 2 CSV-filer men ingen Resampling CSV-fil. Avmarkera en fil eller välj korrekt Resampling CSV-fil.'
            return $result
        } else {
            $result.PrimaryCsv = $paths[0]
            $result.ResampleCsv = $paths[1]
            $result.WarningMessage = '⚠️ Båda CSV har _RES_ i Sample ID – autoväljer Resampling + Original.'
        }

        $result.HasResample = [bool]$result.ResampleCsv
        return $result
    }

    $result.Ok = $false
    $result.ErrorMessage = ("❌ Du har valt {0} CSV-filer. Välj max 2 (Primary + ev. Resample)." -f $paths.Count)
    return $result
}

function Get-AssayFromCsv {
    param([string]$Path,[int]$StartRow=10)

    if (-not (Test-Path -LiteralPath $Path)) { return $null }

    try {
        $layout = Get-TestSummaryCsvLayout -Path $Path
        if (-not $layout.Ok) { return $null }

        for ($i = $layout.DataStartIndex; $i -lt $layout.Lines.Count; $i++) {
            $ln = $layout.Lines[$i]
            if (-not $ln -or ($ln + '').Trim().Length -eq 0) { continue }

            $f = @(ConvertTo-CsvFields -Line $ln -Delimiter $layout.Delimiter)
            if (-not $f -or $f.Count -lt 1) { continue }

            $a = ([string]$f[0]).Trim()
            if ($a -and $a -notmatch '^(?i)\s*assay\s*$') { return $a }
        }
    } catch {
        try { Gui-Log "⚠️ Kunde inte läsa Assay från CSV: $($_.Exception.Message)" 'Warn' } catch {}
    }

    return $null
}

function Import-CsvRows {
    param([string]$Path,[int]$StartRow=10)

    if (-not (Test-Path -LiteralPath $Path)) { return @() }

    $list  = New-Object System.Collections.Generic.List[object]
    try {
        $layout = Get-TestSummaryCsvLayout -Path $Path
        if (-not $layout.Ok) { return @() }

        for ($i = $layout.DataStartIndex; $i -lt $layout.Lines.Count; $i++) {
            $ln = $layout.Lines[$i]
            if (-not $ln -or ($ln + '').Trim().Length -eq 0) { continue }

            $f = @(ConvertTo-CsvFields -Line $ln -Delimiter $layout.Delimiter)
            if (-not $f -or (($f -join '').Trim().Length -eq 0)) { continue }

            [void]$list.Add($f)
        }
    } catch {
        try { Gui-Log "⚠️ Kunde inte läsa rader från CSV: $($_.Exception.Message)" 'Warn' } catch {}
    }

    return @($list.ToArray())
}

function Get-CsvStats {
    param(
        [string]$Path,
        [string[]]$Lines
    )

    $out = [ordered]@{
        TestCount       = 0
        DupCount        = 0
        Duplicates      = @()
        LspValues       = @()
        LspOK           = $null
        InstrumentByType= [ordered]@{}
    }

    $layout = $null
    try {
        if ($Path -and (Test-Path -LiteralPath $Path)) {
            $layout = Get-TestSummaryCsvLayout -Path $Path
        } elseif ($Lines -and $Lines.Count -gt 0) {
            # Fallback for callers that only supplied lines.
            $tmpLines = @($Lines)
            $delim = ','
            $best = -1
            foreach ($l in $tmpLines | Select-Object -First 40) {
                $p = Unwrap-PackedCsvLine -Line $l
                $cc = ([regex]::Matches($p, ',')).Count
                $sc = ([regex]::Matches($p, ';')).Count
                if ($cc -gt $best) { $best = $cc; $delim = ',' }
                if ($sc -gt $best) { $best = $sc; $delim = ';' }
            }

            $headerIndex = -1
            $headers = @()
            for ($i=0; $i -lt [Math]::Min($tmpLines.Count,40); $i++) {
                $f = @(ConvertTo-CsvFields -Line $tmpLines[$i] -Delimiter $delim)
                if (Test-CsvHeaderFields -Fields $f) {
                    $headerIndex = $i
                    $headers = @($f)
                    break
                }
            }
            if ($headerIndex -ge 0) {
                $dataStart = $headerIndex + 1
                while ($dataStart -lt $tmpLines.Count -and (-not $tmpLines[$dataStart] -or ($tmpLines[$dataStart] + '').Trim().Length -eq 0)) { $dataStart++ }
                $layout = [pscustomobject]@{ Ok=$true; Delimiter=$delim; HeaderIndex=$headerIndex; DataStartIndex=$dataStart; Headers=@($headers); Lines=@($tmpLines); Format='Lines' }
            }
        }
    } catch {
        try { Gui-Log "⚠️ Kunde inte läsa CSV-statistik: $($_.Exception.Message)" 'Warn' } catch {}
    }

    if (-not $layout -or -not $layout.Ok) { return [pscustomobject]$out }

    $headerLut = @{}
    for ($i = 0; $i -lt $layout.Headers.Count; $i++) {
        $h = ($layout.Headers[$i] + '').Trim()
        if ($h -and -not $headerLut.ContainsKey($h)) { $headerLut[$h] = $i }
    }

    $idxCart = if ($headerLut.ContainsKey('Cartridge S/N')) { [int]$headerLut['Cartridge S/N'] } else { 3 }
    $idxLsp  = if ($headerLut.ContainsKey('Reagent Lot ID')) { [int]$headerLut['Reagent Lot ID'] } else { 4 }
    $idxIns  = if ($headerLut.ContainsKey('Instrument S/N')) { [int]$headerLut['Instrument S/N'] } else { 6 }

    $cartSnList = New-Object System.Collections.Generic.List[string]
    $lspList    = New-Object System.Collections.Generic.List[string]
    $instrList  = New-Object System.Collections.Generic.List[string]

    for ($r = $layout.DataStartIndex; $r -lt $layout.Lines.Count; $r++) {
        $ln = $layout.Lines[$r]
        if (-not $ln -or -not ($ln + '').Trim()) { continue }

        $f = @(ConvertTo-CsvFields -Line $ln -Delimiter $layout.Delimiter)
        if (-not $f -or $f.Count -lt 1) { continue }

        if ($f.Count -gt $idxCart) {
            $cart = ($f[$idxCart] + '').Trim()
            if ($cart) { $cartSnList.Add($cart) }
        }
        if ($f.Count -gt $idxLsp) {
            $lsp = ($f[$idxLsp] + '').Trim()
            if ($lsp) { $lspList.Add($lsp) }
        }
        if ($f.Count -gt $idxIns) {
            $ins = ($f[$idxIns] + '').Trim()
            if ($ins) { $instrList.Add($ins) }
        }
    }

    $cartSn = $cartSnList | Where-Object { $_ -and $_ -ne '' }
    $out.TestCount = @($cartSn).Count
    $dups = $cartSn | Group-Object | Where-Object { $_.Count -gt 1 }
    if ($dups) {
        $out.DupCount   = @($dups).Count
        $out.Duplicates = @($dups) | ForEach-Object { "$($_.Name) x$($_.Count)" }
    }

    $lspClean = $lspList | ForEach-Object {
        $m = [regex]::Match($_, '(?<!\d)(\d{5})(?!\d)')
        if ($m.Success) { $m.Groups[1].Value } else { $null }
    } | Where-Object { $_ } | Select-Object -Unique
    $out.LspValues = @($lspClean)
    if (@($lspClean).Count -gt 0) {
        $out.LspOK = (@($lspClean).Count -eq 1)
    }

    $lut = @{}
    try {
        foreach ($k in $script:GXINF_Map.Keys) {
            $codes = $script:GXINF_Map[$k].Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ }
            foreach ($code in $codes) { $lut[$code] = $k }
        }
    } catch {}

    foreach ($ins in ($instrList | Where-Object { $_ })) {
        $t = $null
        if ($lut.ContainsKey($ins)) { $t = $lut[$ins] } else { $t = 'Unknown' }
        if (-not $out.InstrumentByType.Contains($t)) { $out.InstrumentByType[$t] = 0 }
        $out.InstrumentByType[$t] = [int]$out.InstrumentByType[$t] + 1
    }

    return [pscustomobject]$out
}

function Import-CsvRowsStreaming {
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$StartRow = 10,
        [Parameter(Mandatory)][scriptblock]$ProcessRow
    )

    $layout = Get-TestSummaryCsvLayout -Path $Path
    if (-not $layout.Ok) { return }

    for ($r = $layout.DataStartIndex; $r -lt $layout.Lines.Count; $r++) {
        $line = $layout.Lines[$r]
        if (-not $line -or ($line + '').Trim().Length -eq 0) { continue }

        $fields = @(ConvertTo-CsvFields -Line $line -Delimiter $layout.Delimiter)
        if ($fields -and (($fields -join '').Trim().Length -gt 0)) {
            & $ProcessRow -Fields $fields -RowIndex ($r + 1)
        }
    }
}
