﻿# Ensure correct location
Set-Location "N:\QC\QC-1\IPT\Skiftspecifika dokument\Skift 4\Niklas\Mappscript PA\Template Generator"

Import-Module (Get-Item "Modules/DocumentMapping").FullName -Force

# Create target copy to allow for multiple runs
if (Test-Path "TargetFilled.xlsx") {
    Remove-Item "TargetFilled.xlsx"
}
Copy-Item "Demo Files\Target.docx" "TargetFilled.docx"

$referencePath = "Demo Files\Reference.docx"
$templatePath = "Demo Files\Template.docx"
$targetPath = "TargetFilled.docx"


Get-WordDocumentMapping -TemplatePath $templatePath -ReferencePath $referencePath -OutputJsonPath "Demo Files\Deviations_Word.json"
