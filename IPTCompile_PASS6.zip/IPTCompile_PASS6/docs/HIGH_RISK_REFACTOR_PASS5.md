# HIGH RISK REFACTOR PASS5

PASS5 keeps the PASS4 runtime strategy: `App/BuildReportFlow.ps1` concatenates build fragments into one scriptblock and wires it to the Build button.

## What changed

The largest PASS4 build phases were split into smaller, named fragments:

- `04_SealTestInfo.ps1` -> `04A_SealTestInfo_Table.ps1`, `04B_StfSummary.ps1`
- `05_RunInformationAndHeaders.ps1` -> `05A_RunInfo_CsvStats.ps1`, `05B_RunInfo_WorksheetHeader.ps1`, `05C_RunInfo_SealPosHeader.ps1`, `05D_RunInfo_SealNegHeader.ps1`
- `07_SharePointAndSheetPolish.ps1` -> `07A_SharePointInfo.ps1`, `07B_RunInfoRowHeights.ps1`, `07C_QcReminder.ps1`, `07D_ReportWatermarkAndTabs.ps1`
- `08_SaveAuditAndFinalize.ps1` -> `08A_SavePrepareAndDebugSheet.ps1`, `08B_SaveFile.ps1`, `08C_AuditSessionAndSignSummary.ps1`, `08D_FinallyCleanup.ps1`

## Intent

This is a navigation refactor, not a behavior refactor. The build-flow statements remain in the same order. No RuleEngine, OpenXML, SharePoint, file-locking, signing, or template logic was intentionally changed.

## Why this pass

PASS4 made `BuildReportFlow.ps1` small, but some individual phase files were still large. PASS5 makes the build flow easier to search by responsibility.

## Test focus

1. GUI starts.
2. Build without signing.
3. Seal Test signing.
4. Worksheet signing.
5. Locked/open Worksheet stops correctly.
6. `Statistical Process Control STF` alias still signs.
7. QC Summary / `Fel Test Type` still renders.
