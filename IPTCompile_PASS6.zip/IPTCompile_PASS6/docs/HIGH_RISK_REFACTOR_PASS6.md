# HIGH RISK REFACTOR PASS6 — Simplify within phases

PASS6 freezes the PASS5 file structure and focuses on reducing duplicated inline phase code.

## Goal

Make the existing build phases easier to read without splitting into more phase files and without changing domain behavior.

## Changes

### Core/RunInformationWriter.ps1

Added shared helpers:

- `Get-RunInfoHeaderDeviationMap`
- `Write-RunInfoSealHeaderBlock`
- `Set-RunInformationLeftPanelRowHeights`
- `Resolve-RunInformationDynamicBlockRow`
- `Write-QcReminderBlock`
- `Set-SampleReagentChecklistHighlight`

These helpers contain logic that was previously inline and duplicated in build phase fragments.

### App/BuildFlow/05C_RunInfo_SealPosHeader.ps1

Replaced inline POS Seal Test header rendering with:

- `Write-RunInfoSealHeaderBlock`

### App/BuildFlow/05D_RunInfo_SealNegHeader.ps1

Replaced inline NEG Seal Test header rendering with:

- `Write-RunInfoSealHeaderBlock`

The surrounding `try/catch` closure from the original build flow is preserved.

### App/BuildFlow/07B_RunInfoRowHeights.ps1

Replaced inline row-height setup with:

- `Set-RunInformationLeftPanelRowHeights`

Replaced inline Sample Reagent highlighting with:

- `Set-SampleReagentChecklistHighlight`

### App/BuildFlow/07C_QcReminder.ps1

Replaced inline QC reminder rendering with:

- `Write-QcReminderBlock`

## Intentionally not changed

- No RuleEngine behavior changes.
- No OpenXML/signing behavior changes.
- No SharePoint lookup changes.
- No output template changes.
- No RuleBank changes.
- No additional build phase files.

## Risk

Medium/high, because inline code has been moved into helpers and invoked by name.
The intended behavior is unchanged.

## Test focus

1. Normal build.
2. Run Information POS/NEG header status.
3. SharePoint block and Sample Reagent highlighting.
4. QC reminder placement.
5. Existing signing tests from PASS5.
