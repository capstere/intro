# PASS3 path fix

Fixar en refactor-regression där `App/BuildReportFlow.ps1` använde `$PSScriptRoot` efter att buildflödet flyttades till `App/`.

I dot-sourcade App-filer pekar `$PSScriptRoot` på `App`-mappen, inte projektroten. Därför hittades inte root-resurser som `output_template-v4.xlsx`.

Ändrat:
- `App/BuildReportFlow.ps1`: root-resurser använder `$ScriptRootPath` i stället för `$PSScriptRoot` för template/audit/equipment default.
- `App/MainWindow.ps1`: help-default använder `$ScriptRootPath`.

Ingen rapportlogik ändrad.
