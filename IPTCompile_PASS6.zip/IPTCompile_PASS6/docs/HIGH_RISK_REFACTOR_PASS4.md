# HIGH RISK REFACTOR PASS4

## Goal

Split the remaining large `App/BuildReportFlow.ps1` build body into phase files without intentionally changing report logic.

## Strategy

`App/BuildReportFlow.ps1` now acts as a loader/registrar:

1. It lists `App/BuildFlow/*.ps1` fragments in execution order.
2. It concatenates the fragments into a single scriptblock at startup.
3. It registers the Build button to invoke that single scriptblock.

This keeps the build flow as one semantic scriptblock, so existing `return` statements and `try/finally` behavior are preserved.

## New files

- `App/BuildFlow/01_InitializeAndLoad.ps1`
- `App/BuildFlow/02_Signing.ps1`
- `App/BuildFlow/03_CsvAndRuleEngine.ps1`
- `App/BuildFlow/04_SealTestInfo.ps1`
- `App/BuildFlow/05_RunInformationAndHeaders.ps1`
- `App/BuildFlow/06_EquipmentAndControls.ps1`
- `App/BuildFlow/07_SharePointAndSheetPolish.ps1`
- `App/BuildFlow/08_SaveAuditAndFinalize.ps1`

## Not intentionally changed

- RuleEngine logic
- Seal Test logic
- Worksheet signing logic
- file-lock logic
- SharePoint lookup logic
- Excel template
- config values

## Validation performed here

The concatenated fragment body was compared byte-for-byte against the original `BuildReportFlow.ps1` click-handler body before replacement.

Full Windows PowerShell 5.1 GUI/runtime testing still required.
