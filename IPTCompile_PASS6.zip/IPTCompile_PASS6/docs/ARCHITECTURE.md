# IPTCompile – Architecture

_Utkast baserat på `IPTCompile_20260505_ver6.zip`. Syftet är orientering, inte refaktorering._

## Vad händer när användaren trycker på **Build**?

`Main.ps1` äger huvudflödet. När användaren trycker **Skapa rapport / Build** startar `$btnBuild.Add_Click`. Där gör IPTCompile en kontrollerad körning: den validerar UI-val, skapar lokala snapshots av indata, öppnar Seal Test POS/NEG och rapportmallen, utför eventuell signering i originalfiler, läser CSV, bygger Data Summary/QC Summary, läser Worksheet/Seal Test-data, gör kontroller, skriver Run Information/SharePoint/utrustning/kontrollmaterial och sparar till en ny outputrapport.

Grundprincipen är:

- **Rapportbygge läser snapshots/lokala kopior när det går.**
- **Signering skriver till originalfiler.**
- **Output skrivs till separat rapportfil.**
- **RuleEngine klassar CSV-rader, men ska inte skriva till originalfiler.**

## De stora stegen

| Steg | Namn | Ägs främst av |
|---:|---|---|
| 1 | Init + UI-val | `Main.ps1`, `App/Bootstrap.ps1`, `App/UiHelpers.ps1` |
| 2 | Filval + snapshots | `Main.ps1`, `Infrastructure/FileStaging.ps1` |
| 3 | Signering | `Main.ps1`, `Core/SignatureWorkflow.ps1`, `Core/OpenXmlSignatureWorkflow.ps1`, `Infrastructure/ExcelOpenXml.ps1` |
| 4 | CSV-läsning + Data Summary | `Infrastructure/Csv.ps1`, `Main.ps1` |
| 5 | Header, Seal Test, Equipment | `Core/HeaderParsing.ps1`, `Core/HeaderComparison.ps1`, `Core/OutputPlanning.ps1`, `Main.ps1` |
| 6 | RuleEngine + QC Summary | `Core/RuleEngineCore.ps1`, `Core/RuleEngineDebug.ps1`, `Rules/RuleBank.compiled.ps1` |
| 7 | Run Information, SharePoint, Save | `Main.ps1`, `Modules/SharePointClient.ps1`, `App/BuildController.ps1`, `Infrastructure/LoggingCore.ps1` |

### 1. Init + UI-val

`Main.ps1` laddar config, moduler, EPPlus/OpenXML och bygger WinForms-GUI. Build-knappen startar huvudloopen. Här kontrolleras att appen är redo, att rätt filer är valda och att användaren inte startar en ny körning medan sökning eller rapportbygge redan pågår.

Viktiga filer:

- `Main.ps1`
- `Modules/Config.ps1`
- `App/Bootstrap.ps1`
- `App/UiHelpers.ps1`
- `App/UiLogging.ps1`

### 2. Filval + snapshots

När Build startar väljs primär CSV, eventuell resample-CSV, Seal Test NEG/POS och Worksheet. Inputfiler stage:as till lokal TEMP när staging är aktiv. Det gör rapportläsningen mindre känslig för nätverksshare och öppna filer.

Signering är undantaget: den går mot originalfilen, inte snapshoten.

Viktiga filer:

- `Main.ps1`
- `Infrastructure/FileStaging.ps1`
- `Infrastructure/Csv.ps1`

### 3. Signering

Det finns två signeringsspår.

Seal Test-signering skriver till `B47` på aktiva Seal Test-datablad. Aktivt blad avgörs av `H3`. Efter skrivning sker read-back-verifiering.

Worksheet-signering använder OpenXML och skriver sammanställnings-/granskningssignaturer i utpekade flikar. Den har extra fil-låsspärrar, exklusivt filhandtag och read-back-verifiering. Fliken `Seal Test Failure Count` har aliaset `Statistical Process Control STF`.

Viktiga filer:

- `Main.ps1`
- `App/UiSignatureDialogs.ps1`
- `App/UiDialogs.ps1`
- `Core/SignatureWorkflow.ps1`
- `Core/OpenXmlSignatureWorkflow.ps1`
- `Infrastructure/ExcelOpenXml.ps1`
- `Infrastructure/FileStaging.ps1`

### 4. CSV-läsning + Data Summary

CSV läses från rad 10. Primär/resample avgörs i `Resolve-CsvPrimaryAndResample`. CSV sorteras på Sample ID. Därefter skrivs `Data Summary`, `Extra Data Summary` och eventuell `Resample Data Summary` i outputrapporten.

Viktiga filer:

- `Infrastructure/Csv.ps1`
- `Main.ps1`

### 5. Header, Seal Test, Equipment

Worksheet- och Seal Test-headers parsas och jämförs. Seal Test-data används för att hitta pass/fail, minusvärden, saknad utvägning, ugnar, calibration due dates och Order#. Equipment och kontrollmaterial kopieras eller skrivs till outputrapporten.

Viktiga filer:

- `Core/HeaderParsing.ps1`
- `Core/HeaderComparison.ps1`
- `Core/OutputPlanning.ps1`
- `Main.ps1`
- `Modules/Config.ps1`

### 6. RuleEngine + QC Summary

RuleEngine laddar `Rules/RuleBank.compiled.ps1`, normaliserar CSV-rader och räknar fram förväntat/observerat resultat, avvikelse, noteringar och specialfall. `RuleEngineDebug.ps1` avgör vad som ska skrivas ut i QC Summary och hur kategorier visas.

Den senaste Test Type-kontrollen är en datakvalitetsflagga: den lägger till `TESTTYPE_MISMATCH`, men ska inte ändra false positive/false negative-logiken.

Viktiga filer:

- `Core/RuleEngineCore.ps1`
- `Core/RuleEngineDebug.ps1`
- `Rules/RuleBank.compiled.ps1`

### 7. Run Information, SharePoint, Save

Run Information samlar versionsinfo, datakällor, headerkontroll, SharePoint Order/Batch/LSP-kontroll och snabblänkar. SharePoint lookup ska utgå från Order# från Seal Test, medan Batch/LSP är verifiering. Output sparas som en separat rapportfil. Audit/logg skrivs efter körning.

Viktiga filer:

- `Main.ps1`
- `Modules/SharePointClient.ps1`
- `App/BuildController.ps1`
- `Infrastructure/LoggingCore.ps1`
- `output_template-v4.xlsx`

## Tre platser där bugs brukar uppstå

### 1. Signering och öppna originalfiler

Detta är den känsligaste delen eftersom den skriver till originalfiler. Riskerna finns runt fil-lås, Excel/Preview, nätverksshare, merged cells och OpenXML-save. Här ska scriptet hellre stoppa än försöka fortsätta.

Titta först i:

- `Main.ps1`
- `Core/OpenXmlSignatureWorkflow.ps1`
- `Infrastructure/ExcelOpenXml.ps1`
- `Infrastructure/FileStaging.ps1`
- `App/UiDialogs.ps1`

### 2. Excel-template och fasta cellpositioner

Många rapportdelar förutsätter specifika bladnamn, rader, kolumner och labels i `output_template-v4.xlsx`. Små templateändringar kan ge stora följdfel om koden letar efter exakt label eller skriver till fast cell.

Titta först i:

- `output_template-v4.xlsx`
- `Main.ps1`
- `Core/HeaderParsing.ps1`
- `Core/HeaderComparison.ps1`

### 3. Domänregler i CSV och RuleEngine

Edge cases uppstår ofta när Sample ID, Test Type, assay, resample, error code eller kontrollkod inte följer det vanligaste mönstret. Här ska ändringar vara små och testas mot riktiga CSV-exempel.

Titta först i:

- `Core/RuleEngineCore.ps1`
- `Core/RuleEngineDebug.ps1`
- `Rules/RuleBank.compiled.ps1`
- `Infrastructure/Csv.ps1`

## Mental modell

Om något går fel, börja med att fråga:

1. Är felet i **input/snapshot**, **signering**, **CSV/RuleEngine**, **template-output** eller **SharePoint**?
2. Skrev scriptet till originalfil, eller bara till outputrapport?
3. Är problemet en faktisk felklassning, en saknad kontroll, eller bara layout/text?

Det är oftast snabbare än att börja leta rad-för-rad i `Main.ps1`.
