# IPTCompile module map

- `App/Bootstrap.ps1`
- `App/BuildController.ps1`
- `App/EarlyGuards.ps1`
- `App/ReleaseNotes.ps1`
- `App/UiDialogs.ps1`
- `App/UiHelpers.ps1`
- `App/UiLogging.ps1`
- `App/UiSignatureDialogs.ps1`
- `App/UiTheme.ps1`
- `Core/AssayNormalization.ps1`
- `Core/HeaderComparison.ps1`
- `Core/HeaderParsing.ps1`
- `Core/OpenXmlSignatureWorkflow.ps1`
- `Core/OutputPlanning.ps1`
- `Core/RuleEngineCore.ps1`
- `Core/RuleEngineDebug.ps1`
- `Core/SealTestValidation.ps1`
- `Core/SharePointConsistency.ps1`
- `Core/SignatureWorkflow.ps1`
- `Infrastructure/Csv.ps1`
- `Infrastructure/ExcelEpplus.ps1`
- `Infrastructure/ExcelOpenXml.ps1`
- `Infrastructure/FileStaging.ps1`
- `Infrastructure/Forensics.ps1`
- `Infrastructure/LoggingCore.ps1`
- `Main.ps1`
- `Modules/Config.ps1`
- `Modules/SharePointClient.ps1`
- `Modules/Splash.ps1`
- `Modules/UiStyling.ps1`
- `Rules/Analyze-RuleBankRuntime.ps1`
- `Rules/Build-RuleBank.ps1`
- `Rules/Initialize-RuleBankV2Source.ps1`
- `Rules/RuleBank.compiled.ps1`
- `Rules/RuleBankV2.Common.ps1`
- `Rules/Test-RuleBankV2.ps1`
- `Rules/Validate-RuleBank.ps1`


## PASS5 BuildFlow fragments

`App/BuildFlow/` now contains smaller ordered fragments. `App/BuildReportFlow.ps1` owns the ordered file list and compiles them into the Build button scriptblock.
