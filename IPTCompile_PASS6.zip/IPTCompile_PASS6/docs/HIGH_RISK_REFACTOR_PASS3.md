# HIGH RISK REFACTOR PASS 3

This pass is intentionally more aggressive than pass 1–2. It still aims to preserve runtime behavior.

## Structural extraction

`Main.ps1` now dot-sources three caller-scope files:

- `App/MainWindow.ps1` — GUI construction, UI helper/event wiring outside Build.
- `App/BuildReportFlow.ps1` — the full Build button report-generation flow.
- `App/MainWindowFinalize.ps1` — tooltip setup and final UI state wiring.

This makes `Main.ps1` mostly bootstrap/orchestration. The extracted files are dot-sourced deliberately so they can use the same variables as the old top-level script.

## Removed code

Removed functions that were either unreferenced in the project or exact duplicate definitions provided by earlier-loaded modules:

- `Infrastructure/ExcelOpenXml.ps1`: `Get-MergeCellMap_OpenXml`, `Set-OpenXmlCellText`
- `Modules/Config.ps1`: `Resolve-LocalFirstFile`
- `Core/OutputPlanning.ps1`: `Is-FeatureEnabled`
- `Core/AssayNormalization.ps1`: `Is-VlAssay`
- `Infrastructure/FileStaging.ps1`: `Test-IsNetworkPath`
- `Core/SignatureWorkflow.ps1`: `UrlEncode`
- `Core/HeaderComparison.ps1`: duplicate `Get-TestSummaryEquipmentFromWorksheet`, `Get-TestSummaryEquipment`, `Normalize-Id`, `Normalize-HeaderText`

## Not touched

- RuleEngine behavior
- OpenXML signing logic
- file-lock logic
- SharePoint lookup semantics
- `output_template-v4.xlsx`
- `RuleBank.compiled.ps1`
