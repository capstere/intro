﻿# Build phase: Save, audit, cleanup-visible completion
# Extracted from App/BuildReportFlow.ps1 during PASS4.

        # ============================
        # === Spara & revision     ===
        # ============================

        $nowTs    = Get-Date -Format "yyyyMMdd_HHmmss"
        $baseName = "$($env:USERNAME)_output_${lsp}_$nowTs.xlsx"
        $saveDir  = $env:TEMP
        $SavePath = Join-Path $saveDir $baseName
        Gui-Log ("💾 Sparar rapport: {0}" -f $baseName) 'Info' 'USER'
        try {
            $pkgOut.Workbook.View.ActiveTab = 0
            $wsInitial = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
            if ($wsInitial) { $wsInitial.View.TabSelected = $true }

            # ============================
            # === RuleEngine felsökningsblad ==
            # ============================
            try {
                if ((Get-ConfigFlag -Name 'EnableRuleEngine' -Default $false -ConfigOverride $Config) -and
                    (Get-ConfigFlag -Name 'EnableRuleEngineDebugSheet' -Default $false -ConfigOverride $Config) -and
                    (($selCsv -and (Test-Path -LiteralPath $selCsv)) -or ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)))) {

                    if (-not $script:RuleEngineShadow -or -not $script:RuleEngineShadow.Rows -or $script:RuleEngineShadow.Rows.Count -eq 0) {

                        Gui-Log "🧠 Regelmotor: saknas vid Save → bygger nu..." 'Warn'

                        $rb2 = $script:RuleBankCache
                        if (-not $rb2) {
                            $rb2 = Load-RuleBank -RuleBankDir $Config.RuleBankDir
                            try {
                                $rb2 = Compile-RuleBank -RuleBank $rb2
                            } catch {
                                Gui-Log ("⚠️ Regelmotor: kunde inte kompilera RuleBank vid Save: " + $_.Exception.Message) 'Warn' 'DEBUG'
                            }
                        }

                        # Primär
                        $csvObjs2 = @()
                        if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
                            $csvObjs2 = $script:RuleEngineCsvObjs
                            if (-not $csvObjs2 -or $csvObjs2.Count -eq 0) {
                                if ($csvRows -and $csvRows.Count -gt 0) {
                                    $csvObjs2 = @($csvRows)
                                } else {
                                    try {
                                        $all = $script:CsvLinesPrimary
                                        if ($all -and $all.Count -gt 9) {
                                            $hdr = ConvertTo-CsvFields $all[7]
                                            $dl  = $all[9..($all.Count-1)] | Where-Object { $_ -and $_.Trim() }
                                            $del = Get-CsvDelimiter -Path $selCsv
                                            $csvObjs2 = @(ConvertFrom-Csv -InputObject ($dl -join "`n") -Delimiter $del -Header $hdr)
                                        }
                                    } catch {
                                        Gui-Log ("⚠️ Regelmotor: fallback-raw för CSV vid Save misslyckades: " + $_.Exception.Message) 'Warn' 'DEBUG'
                                        $csvObjs2 = @()
                                    }
                                }
                            }
                            if ($csvObjs2 -and $csvObjs2.Count -gt 0) {
                                $script:RuleEngineShadow = Invoke-RuleEngine -CsvObjects $csvObjs2 -RuleBank $rb2 -CsvPath $selCsv
                            }
                        }

                        # Resample-del
                        if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
                            $csvObjsR2 = $script:RuleEngineCsvObjsRes
                            if (-not $csvObjsR2 -or $csvObjsR2.Count -eq 0) {
                                if ($csvRowsRes -and $csvRowsRes.Count -gt 0) {
                                    $csvObjsR2 = @($csvRowsRes)
                                } else {
                                    try {
                                        $allR = $script:CsvLinesResample
                                        if ($allR -and $allR.Count -gt 9) {
                                            $hdrR = ConvertTo-CsvFields $allR[7]
                                            $dlR  = $allR[9..($allR.Count-1)] | Where-Object { $_ -and $_.Trim() }
                                            $delR = Get-CsvDelimiter -Path $selCsvRes
                                            $csvObjsR2 = @(ConvertFrom-Csv -InputObject ($dlR -join "`n") -Delimiter $delR -Header $hdrR)
                                        }
                                    } catch {
                                        Gui-Log ("⚠️ Regelmotor: fallback-raw för Resample-CSV vid Save misslyckades: " + $_.Exception.Message) 'Warn' 'DEBUG'
                                        $csvObjsR2 = @()
                                    }
                                }
                            }
                            if ($csvObjsR2 -and $csvObjsR2.Count -gt 0) {
                                $reR2 = Invoke-RuleEngine -CsvObjects $csvObjsR2 -RuleBank $rb2 -CsvPath $selCsvRes
                                if ($script:RuleEngineShadow -and $reR2) {
                                    # Sammanfogning (nytt objekt för PS 5.1-kompatibilitet)
                                    $script:RuleEngineShadow = [pscustomobject]@{
                                        Rows          = @($script:RuleEngineShadow.Rows) + @($reR2.Rows)
                                        Summary       = $script:RuleEngineShadow.Summary
                                        TopDeviations = @($script:RuleEngineShadow.TopDeviations) + @($reR2.TopDeviations)
                                        QC            = $script:RuleEngineShadow.QC
                                    }
                                } elseif ($reR2) {
                                    $script:RuleEngineShadow = $reR2
                                }
                            }
                        }

                        if (-not $script:RuleEngineShadow -or -not $script:RuleEngineShadow.Rows -or @($script:RuleEngineShadow.Rows).Count -eq 0) {
                            Gui-Log "⚠️ Regelmotor: kunde inte bygga vid Save (0 rader)." 'Warn'
                        }
                    }

                    if ($script:RuleEngineShadow -and $script:RuleEngineShadow.Rows -and $script:RuleEngineShadow.Rows.Count -gt 0) {
                        Gui-Log "🧠 Skriver CSV-Sammanfattning..." 'Info' 'PROGRESS'
                        $includeAll = Get-ConfigFlag -Name 'RuleEngineDebugIncludeAllRows' -Default $false -ConfigOverride $Config
                        $dsf = @()
                        if ($script:DataSummaryFindings) { $dsf = @($script:DataSummaryFindings) }
                        $stf = 0
                        if ($script:StfCount) { $stf = [int]$script:StfCount }
                        [void](Write-RuleEngineDebugSheet -Pkg $pkgOut -RuleEngineResult $script:RuleEngineShadow -IncludeAllRows $includeAll -DataSummaryFindings $dsf -StfCount $stf)

                        # --- Skriv använda INF/GX i QC Summary (under befintlig data) ---
                        try {
                            $wsQcs = $pkgOut.Workbook.Worksheets[$Layout.SheetQcSummary]
                            if ($wsQcs) {
                                $usedSystems = [ordered]@{}
                                if ($csvStats -and $csvStats.InstrumentByType) {
                                    foreach ($k in $csvStats.InstrumentByType.Keys) {
                                        if ($k -and $k -ne 'Unknown') { $usedSystems[$k] = $true }
                                    }
                                }
                                if ($csvStatsRes -and $csvStatsRes.InstrumentByType) {
                                    foreach ($k in $csvStatsRes.InstrumentByType.Keys) {
                                        if ($k -and $k -ne 'Unknown') { $usedSystems[$k] = $true }
                                    }
                                }
                                $names = @($usedSystems.Keys | Sort-Object)
                                if ($names.Count -gt 0) {
                                    # Hitta sista använda raden
                                    $lastRow = 3
                                    if ($wsQcs.Dimension) {
                                        for ($ri = $wsQcs.Dimension.End.Row; $ri -ge 1; $ri--) {
                                            $cv = ($wsQcs.Cells[$ri, 1].Text + '').Trim()
                                            if ($cv) { $lastRow = $ri; break }
                                        }
                                    }
                                    $hdrRow = $lastRow + 2  # 2 raders mellanrum

                                    # Rubrik (kolumn A, spänner antal system)
                                    $wsQcs.Cells[$hdrRow, 1].Value = 'Använda INF/GX'
                                    $wsQcs.Cells[$hdrRow, 1].Style.Font.Bold = $true
                                    $wsQcs.Cells[$hdrRow, 1].Style.Font.Size = 10
                                    $hdrRng = $wsQcs.Cells[$hdrRow, 1, $hdrRow, $names.Count]
                                    $hdrRng.Merge = $true
                                    $hdrRng.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                    $hdrRng.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::FromArgb(217, 225, 242))
                                    $hdrRng.Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(0, 32, 96))
                                    $hdrRng.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center

                                    $calMap = $script:CalDueMap
                                    for ($ci = 0; $ci -lt $names.Count; $ci++) {
                                        $col = 1 + $ci
                                        $sysName = $names[$ci]

                                        # Systemnamn
                                        $cName = $wsQcs.Cells[($hdrRow + 1), $col]
                                        $cName.Value = $sysName
                                        $cName.Style.Font.Bold = $true
                                        $cName.Style.Font.Size = 9
                                        $cName.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center
                                        $cName.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                        $cName.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::FromArgb(242, 242, 242))

                                        # Cal Due Date
                                        $cCal = $wsQcs.Cells[($hdrRow + 2), $col]
                                        $calVal = ''
                                        if ($calMap -and $calMap.ContainsKey($sysName)) { $calVal = $calMap[$sysName] }
                                        $cCal.Value = $calVal
                                        $cCal.Style.Font.Size = 9
                                        $cCal.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center
                                        $cCal.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                        $cCal.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::FromArgb(198, 239, 206))

                                        try { $wsQcs.Column($col).AutoFit() } catch {}
                                        try { $wsQcs.Column($col).Width = [Math]::Max($wsQcs.Column($col).Width, 14) } catch {}
                                    }
                                }
                            }
                        } catch {
                            Gui-Log ("⚠️ QC Summary INF/GX fel: " + $_.Exception.Message) 'Warn'
                        }

                        # Visa vilken CSV som klassades som primär/resample direkt i CSV Sammanfattning (rad 2)
                        try {
                            $wsDbg = $pkgOut.Workbook.Worksheets['CSV Sammanfattning']
                            if ($wsDbg) {
                                $pPath = if ($selCsvOrig) { $selCsvOrig } elseif ($selCsv) { $selCsv } else { '' }
                                $rPath = if ($selCsvResOrig) { $selCsvResOrig } elseif ($selCsvRes) { $selCsvRes } else { '' }
                                $pLeaf = Get-CleanLeaf $pPath
                                $rLeaf = Get-CleanLeaf $rPath
                                $lbl = if ($pLeaf -and $rLeaf) {
                                    "CSV: {0} | RES CSV: {1}" -f $pLeaf, $rLeaf
                                } elseif ($pLeaf) {
                                    "CSV: {0}" -f $pLeaf
                                } elseif ($rLeaf) {
                                    "Resample CSV: {0}" -f $rLeaf
                                } else { '' }
                                if ($lbl) {
                                    $rng = $wsDbg.Cells[2, 1, 2, 8]
                                    $rng.Merge = $true
                                    $rng.Style.Numberformat.Format = '@'
                                    $rng.Style.Font.Italic = $true
                                    $wsDbg.Cells[2, 1].Value = $lbl
                                }
                            }
                        } catch {
                            Gui-Log ("⚠️ Kunde inte märka CSV-Sammanfattning med vald CSV/Resample: " + $_.Exception.Message) 'Warn' 'DEBUG'
                        }
                    } else {
                        Gui-Log "⚠️ Kunde inte skriva CSV-Sammanfattning." 'Warn'
                    }
                }
            } catch {
                Gui-Log ("⚠️ Kunde inte skriva CSV-Sammanfattning: " + $_.Exception.Message) 'Warn'
            }
try {
    $wsRunInfoFinal = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if ($wsRunInfoFinal -and $script:RunInfoTemplateColumnWidths -and $script:RunInfoTemplateColumnWidths.Count -gt 0) {
        Restore-RunInformationColumnWidths -Ws $wsRunInfoFinal -Widths $script:RunInfoTemplateColumnWidths
    }
} catch {}
Set-UiStep 90 'Sparar rapport…'
Mark-Phase 'RunInfo'
# UX: Om rapportfilen redan finns och är öppen (Excel), be användaren stänga innan SaveAs
            try {
                if ($SavePath -and (Test-Path -LiteralPath $SavePath)) {
                    if (-not (Ensure-FilesClosedOrCancel -Paths @($SavePath) -Hint 'Stäng rapporten i Excel (eller stäng Preview i Explorer) och klicka Försök igen.')) {
                        Gui-Log "🛑 Avbrutet: output-filen är låst/öppen." 'Warn'
                        return
                    }
                }
            } catch {
                Gui-Log ("⚠️ Fil-låskontroll för output misslyckades: " + $_.Exception.Message) 'Warn' 'DEBUG'
            }
            try {
                $pkgOut.SaveAs($SavePath)
            } catch {
                $auditStatusText = 'Error'
                $saveErr = $_.Exception.Message
                if ($saveErr -match 'being used by another process|access.*denied|permission') {
                    Gui-Log ("❌ Kunde inte spara: filen är låst av ett annat program. Stäng Excel/Preview och försök igen.") 'Error'
                } else {
                    Gui-Log ("❌ Kunde inte spara rapporten: $saveErr") 'Error'
                }
                return
            }
            Mark-Phase 'Save'
            $buildTimer.Stop()
            $totalMs = $buildTimer.ElapsedMilliseconds
            $doneMsg = 'Klar ✅  ({0:N1}s)' -f ($totalMs / 1000)
            Set-UiStep 100 $doneMsg
            Gui-Log -Text ("Rapport sparad: {0} ({1:N1}s)" -f $SavePath, ($totalMs / 1000)) -Severity Info -Category RESULT
# Signeringssammanfattning
# Logga endast det som faktiskt skrevs och read-back-verifierades i denna körning.
$signParts = @()
if ($negSealSignatureAppliedThisRun -and $posSealSignatureAppliedThisRun) {
    $signParts += "Seal Test: NEG+POS"
} elseif ($negSealSignatureAppliedThisRun) {
    $signParts += "Seal Test: NEG"
} elseif ($posSealSignatureAppliedThisRun) {
    $signParts += "Seal Test: POS"
}
if ($wsSammSignatureVerifiedThisRun) {
    $signParts += "WS Sammanst."
}
if ($wsGranskSignatureVerifiedThisRun) {
    $signParts += "WS Granskning"
}
if ($signParts.Count -gt 0) {
    Gui-Log ("🔏 Verifierad signering: " + ($signParts -join ', ')) 'Info'
}
            $global:LastReportPath = $SavePath
            try { $form.Text = "IPTCompile – $ScriptVersion — $(Split-Path $SavePath -Leaf)" } catch {}
            try {
                $auditDir = Join-Path $ScriptRootPath 'audit'
                if (-not (Test-Path -LiteralPath $auditDir)) { New-Item -ItemType Directory -Path $auditDir -Force | Out-Null }

            # Fasdetaljerad tidsmätning (ms)
            $phaseJson = ''
            try { $phaseJson = ($phaseTimings | ConvertTo-Json -Compress) } 
            catch { $phaseJson = '' }


                $auditObj = [pscustomobject]@{
                    DatumTid        = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
                    Användare       = $env:USERNAME
                    LSP             = $lsp
                    ValdCSV         = if ($selCsv -or $selCsvRes) { (@($(if($selCsv){Get-CleanLeaf $selCsv}), $(if($selCsvRes){'(Res) '+(Get-CleanLeaf $selCsvRes)})) | Where-Object {$_}) -join ' + ' } else { '' }
                    ValdSealNEG     = Get-CleanLeaf $selNeg
                    ValdSealPOS     = Get-CleanLeaf $selPos
                    Assay           = $runAssay
                    AntalTester     = $(try { if ($csvStats) { 
                    [int]$csvStats.TestCount } else { 0 } } catch { 0 })
                    SignaturSkriven = if ($doSealTest) { 'Ja (verifierad)' } else { 'Nej' }
                    WsSammSkriven   = if ($doWsSamm) { 'Ja (verifierad)' } else { 'Nej' }
                    WsGranskSkriven = if ($doWsGransk) { 'Ja (verifierad)' } else { 'Nej' }
                    SigMismatch     = if ($sigMismatch) { 'Ja' } else { 'Nej' }
                    MismatchSheets  = if ($mismatchSheets -and $mismatchSheets.Count -gt 0) { ($mismatchSheets -join ';') } else { '' }
                    ViolationsNEG   = $violationsNeg.Count
                    ViolationsPOS   = $violationsPos.Count
                    Violations      = ($violationsNeg.Count + $violationsPos.Count)
                    TotalTid_ms     = $totalMs
                    TotalTid_s      = [math]::Round($totalMs / 1000, 1)
                    FasTider_json   = $phaseJson
                    Sparläge        = 'Temporärt'
                    OutputFile      = $SavePath
                    Kommentar       = 'UNCONTROLLED rapport, ingen källfil ändrades automatiskt.'
                    ScriptVersion   = $ScriptVersion
                }

                $auditFile = Join-Path $auditDir ("$($env:USERNAME)_audit_${nowTs}.csv")
                $auditObj | Export-Csv -Path $auditFile -NoTypeInformation -Encoding UTF8

                try {
                    $statusText = 'OK'
                    if (($violationsNeg.Count + $violationsPos.Count) -gt 0 -or $sigMismatch -or ($mismatchSheets -and $mismatchSheets.Count -gt 0)) {
                        $statusText = 'Warnings'
                    }
                    $auditStatusText = $statusText
                    $auditTests = $null
                    try {
                        if ($csvStats) { $auditTests = [int]$csvStats.TestCount }
                        if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) { $auditTests = ($auditTests + 0) + [int]$csvStatsRes.TestCount }
                    } catch {}
                    Add-AuditEntry -Lsp $lsp -Assay $runAssay -BatchNumber $batch -TestCount $auditTests -Status $statusText -ReportPath $SavePath -TotalMs $totalMs -PhaseJson $phaseJson
                    $auditWritten = $true
                } catch {
                    Gui-Log "⚠️ Kunde inte skriva audit-CSV: $($_.Exception.Message)" 'Warn'
                }
            } catch {
                Gui-Log "⚠️ Kunde inte skriva revisionsfil: $($_.Exception.Message)" 'Warn'
            }

            # ---- Sessionsspårning + tidsbesparningsuppskattning ----
            try {
                $script:SessionStats.ReportCount++
                $script:SessionStats.TotalBuildMs += $totalMs
                $buildTests = 0
                try { if ($csvStats) { $buildTests = [int]$csvStats.TestCount } } catch {}
                try { if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) { $buildTests += [int]$csvStatsRes.TestCount } } catch {}
                $script:SessionStats.TotalTestsBuilt += $buildTests

                # Uppskattad manuell tid: ~20 min per rapport (konservativt)
                $manualMinEstimate = 10
                $savedMin = $manualMinEstimate - [math]::Round($totalMs / 60000, 1)
                if ($savedMin -lt 5) { $savedMin = 5 }
                $sessionSavedMin = [math]::Round($script:SessionStats.ReportCount * $manualMinEstimate - $script:SessionStats.TotalBuildMs / 60000, 0)
                if ($sessionSavedMin -lt $script:SessionStats.ReportCount) { $sessionSavedMin = $script:SessionStats.ReportCount * 5 }

                Gui-Log ("   Uppskattad tidsbesparning: ~{0} min (manuellt ~{1} min, IPTCompile {2:N1}s)" -f [int]$savedMin, $manualMinEstimate, ($totalMs / 1000)) 'Info' 'RESULT'

                # Uppdatera statusfältets sessionsindikator
                $sessText = if ($script:SessionStats.ReportCount -eq 1) {
                    "1 rapport | ~{0} min sparad" -f [int]$savedMin
                } else {
                    "{0} rapporter | ~{1} min sparade" -f $script:SessionStats.ReportCount, [int]$sessionSavedMin
                }
                $script:slSession.Text = $sessText
                $script:slSession.Visible = $true
            } catch {}

            # Kort visuell blink på Build-knappen
            $origBack = $btnBuild.BackColor
            try {
                $btnBuild.BackColor = [System.Drawing.Color]::FromArgb(46, 125, 50)
                $btnBuild.Refresh()
                Start-Sleep -Milliseconds 600
                $btnBuild.BackColor = $origBack
                $btnBuild.Refresh()
            } catch { try { $btnBuild.BackColor = $origBack } catch {} }

            try { Start-Process -FilePath $SavePath } catch {

            # Kort ljud-notis vid klar rapport
            try { [System.Media.SystemSounds]::Exclamation.Play() } catch {}
                Gui-Log "ℹ️ Rapporten sparades men kunde inte öppnas automatiskt: $($_.Exception.Message)" 'Info' 'USER'
            }
        }
        catch {
            $auditStatusText = 'Error'
            Gui-Log "❌ Kunde inte spara rapporten: $($_.Exception.Message)" 'Error'
        }

    } finally {
        # Stoppa elapsed-timer
        try { if ($script:buildElapsedTimer) { $script:buildElapsedTimer.Stop(); $script:buildElapsedTimer.Dispose(); $script:buildElapsedTimer = $null } } catch {}
        try {
            if ($buildTimer -and $buildTimer.IsRunning) { $buildTimer.Stop() }
        } catch {}
        if (($totalMs -le 0) -and $buildTimer) {
            try { $totalMs = [int]$buildTimer.ElapsedMilliseconds } catch { $totalMs = 0 }
        }
        if (-not $phaseJson) {
            try { $phaseJson = ($phaseTimings | ConvertTo-Json -Compress) } catch { $phaseJson = '' }
        }
        if (-not $auditWritten) {
            try {
                $auditTests = $null
                if ($csvStats) { $auditTests = [int]$csvStats.TestCount }
                if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) { $auditTests = ($auditTests + 0) + [int]$csvStatsRes.TestCount }
                Add-AuditEntry -Lsp $lsp -Assay $runAssay -BatchNumber $batch -TestCount $auditTests -Status $auditStatusText -ReportPath $SavePath -TotalMs $totalMs -PhaseJson $phaseJson
                $auditWritten = $true
            } catch {
                Gui-Log "⚠️ Kunde inte skriva fallback-audit: $($_.Exception.Message)" 'Warn'
            }
        }
        try { if ($pkgNeg) { $pkgNeg.Dispose() } } catch {}
        try { if ($pkgPos) { $pkgPos.Dispose() } } catch {}
        try { if ($pkgOut) { $pkgOut.Dispose() } } catch {}
        try { if ($script:WsPkg) { $script:WsPkg.Dispose(); $script:WsPkg = $null } } catch {}
        try {
            if ($stageDir -and (Test-Path -LiteralPath $stageDir)) {
                # Säkerhet: radera bara om den ligger under TEMP-root
                $root = Get-ConfigValue -Name 'TempSnapshotRoot' -Default 'C:\IPTCompile_TEMP' -ConfigOverride $Config
                if (-not $root) { $root = 'C:\IPTCompile_TEMP' }
                $stageFull = (Resolve-Path -LiteralPath $stageDir -ErrorAction SilentlyContinue).Path
                $rootFull  = (Resolve-Path -LiteralPath $root -ErrorAction SilentlyContinue).Path
                if ($stageFull -and $rootFull -and $stageFull.StartsWith($rootFull, [System.StringComparison]::OrdinalIgnoreCase)) {
                    Remove-Item -LiteralPath $stageDir -Recurse -Force -ErrorAction SilentlyContinue
                }
            }
        } catch {}
        Set-UiBusy -Busy $false
        $script:BuildInProgress = $false
    }
    #endregion Build: Spara rapport och revision
    #endregion Build: Rapportgenerering (huvudloop)
