﻿# Build phase: Run Information and header checks
# Extracted from App/BuildReportFlow.ps1 during PASS4.

# ============================
# === Information-blad     ===
# ============================

try {
    Mark-Phase 'Kontrollmaterial'
    $wsInfo = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if (-not $wsInfo) { $wsInfo = $pkgOut.Workbook.Worksheets.Add($Layout.SheetRunInfo) }

# Säkerställ att kolumn C inte är dold (mallen styr bredd och wrap)
try { $wsInfo.Column(3).Hidden = $false } catch {}

    try {
        $csvLines = $null
        $csvStats = $null

        # ✅ Viktigt: initiera alltid, även om ingen CSV är vald
        $csvInstrumentSerials = @()

        if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
            try { $csvLines = $script:CsvLinesPrimary } catch { Gui-Log ("⚠️ Kunde inte läsa CSV: " + $_.Exception.Message) 'Warn' }
            try { $csvStats = Get-CsvStats -Path $selCsv -Lines $csvLines } catch { Gui-Log ("⚠️ Get-CsvStats: " + $_.Exception.Message) 'Warn' }

            # Hämta exakt lista med Instrument S/N från CSV (för Equipment-blad när WS-skanning är av)
            try {
                if ($csvLines -and $csvLines.Count -gt 8) {
                    $hdr = ConvertTo-CsvFields $csvLines[7]

                    $idx = -1
                    for ($ii=0; $ii -lt $hdr.Count; $ii++) {
                        $h = (($hdr[$ii] + '').Trim('\"').ToLower())
                        if ($h -eq 'instrument s/n' -or $h -match 'instrument') { $idx = $ii; break }
                    }

                    if ($idx -ge 0) {
                        $set = New-Object System.Collections.Generic.HashSet[string]
                        for ($rr=9; $rr -lt $csvLines.Count; $rr++) {
                            $ln = $csvLines[$rr]
                            if (-not $ln -or -not $ln.Trim()) { continue }
                            $f = ConvertTo-CsvFields $ln
                            if ($f.Count -gt $idx) {
                                $v = ($f[$idx] + '').Trim().Trim('\"')
                                if ($v) { $null = $set.Add($v) }
                            }
                        }

                        # HashSet[T]-enumerering (PS 5.1-säker)
                        $csvInstrumentSerials = @($set | Sort-Object)
                    }
                }
            } catch {
                Gui-Log ("⚠️ Kunde inte extrahera Instrument S/N från CSV: " + $_.Exception.Message) 'Warn'
                $csvInstrumentSerials = @()
            }
        }

        if (-not $csvStats) {
            $csvStats = [pscustomobject]@{
                TestCount    = 0
                DupCount     = 0
                Duplicates   = @()
                LspValues    = @()
                LspOK        = $null
                InstrumentByType = [ordered]@{}
            }
        }

        # Statistik för Resample-CSV
        $csvStatsRes = $null
        if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
            try {
                $csvLinesRes = $script:CsvLinesResample
                $csvStatsRes = Get-CsvStats -Path $selCsvRes -Lines $csvLinesRes
            } catch { Gui-Log ("⚠️ Resample Get-CsvStats: " + $_.Exception.Message) 'Warn' }
        }

        $infSN = @()
        if ($script:GXINF_Map) {
            foreach ($k in $script:GXINF_Map.Keys) {
                if ($k -like 'Infinity-*') {
                    $infSN += ($script:GXINF_Map[$k].Split(',') | ForEach-Object { ($_ + '').Trim() } | Where-Object { $_ })
                }
            }
        }
        $infSN = $infSN | Select-Object -Unique

        $infSummary = '—'
        try {
            if ($selCsv -and (Test-Path -LiteralPath $selCsv) -and $infSN.Count -gt 0) {
                $infSummary = Get-InfinitySpFromCsvStrict -Path $selCsv -InfinitySerials $infSN -Lines $csvLines
            }
        } catch {
            Gui-Log ("Infinity SP fel: " + $_.Exception.Message) 'Warn'
        }

        # --- Dubbletter Sample ID ---
        $dupSampleCount = 0
        $dupSampleList  = @()
        if ($csvLines -and $csvLines.Count -gt 8) {
            try {
                $headerFields = ConvertTo-CsvFields $csvLines[7]
                $sampleIdx = -1
                for ($i=0; $i -lt $headerFields.Count; $i++) {
                    $hf = ($headerFields[$i] + '').Trim().ToLower()
                    if ($hf -match 'sample') { $sampleIdx = $i; break }
                }
                if ($sampleIdx -ge 0) {
                    $samples = @()
                    for ($r=9; $r -lt $csvLines.Count; $r++) {
                        $line = $csvLines[$r]
                        if (-not $line -or -not $line.Trim()) { continue }
                        $fields = ConvertTo-CsvFields $line
                        if ($fields.Count -gt $sampleIdx) {
                            $val = ($fields[$sampleIdx] + '').Trim()
                            if ($val) { $samples += $val }
                        }
                    }
                    if ($samples.Count -gt 0) {
                        $counts = @{}
                        foreach ($s in $samples) { if (-not $counts.ContainsKey($s)) { $counts[$s] = 0 }; $counts[$s] = [int]$counts[$s] + 1 }
                        foreach ($entry in $counts.GetEnumerator()) {
                            if ($entry.Value -gt 1) { $dupSampleList += ("$($entry.Key) x$($entry.Value)") }
                        }
                        $dupSampleCount = $dupSampleList.Count
                    }
                }
            } catch {
                Gui-Log ("⚠️ Fel vid analys av Sample ID: " + $_.Exception.Message) 'Warn'
            }
        }

        $dupSampleText = if ($dupSampleCount -gt 0) {
            $show = ($dupSampleList | Select-Object -First 8) -join ', '
            "$dupSampleCount ($show)"
        } else { 'N/A' }

        $dupCartText = if ($csvStats.DupCount -gt 0) {
            $show = ($csvStats.Duplicates | Select-Object -First 8) -join ', '
            "$($csvStats.DupCount) ($show)"
        } else { 'N/A' }

        # --- LSP-summering ---
        $lspSummary = ''
        try {
            if ($csvLines -and $csvLines.Count -gt 8) {
                $counts = @{}
                for ($rr = 9; $rr -lt $csvLines.Count; $rr++) {
                    $ln = $csvLines[$rr]
                    if (-not $ln -or -not $ln.Trim()) { continue }
                    $fs = ConvertTo-CsvFields $ln
                    if ($fs.Count -gt 4) {
                        $raw = ($fs[4] + '').Trim()
                        if ($raw) {
                            $mLsp = [regex]::Match($raw,'(\d{5})')
                            $code = if ($mLsp.Success) { $mLsp.Groups[1].Value } else { $raw }
                            if (-not $counts.ContainsKey($code)) { $counts[$code] = 0 }
                            $counts[$code] = [int]$counts[$code] + 1
                        }
                    }
                }

                if ($counts.Count -gt 0) {
                    $sorted = @($counts.GetEnumerator() | Sort-Object Key)
                    $parts = @()
                    foreach ($kvp in $sorted) {
                        $parts += $(if ($kvp.Value -gt 1) { "$($kvp.Key) x$($kvp.Value)" } else { $kvp.Key })
                    }
                    if ($sorted.Count -eq 1) { $lspSummary = $sorted[0].Key }
                    else { $lspSummary = "$($sorted.Count) (" + ($parts -join ', ') + ")" }
                }
            }
        } catch {
            Gui-Log ("⚠️ Fel vid extraktion av LSP från CSV: " + $_.Exception.Message) 'Warn'
            $lspSummary = ''
        }

        $instText = if ($csvStats.InstrumentByType.Keys.Count -gt 0) {
            ($csvStats.InstrumentByType.GetEnumerator() | ForEach-Object { "$($_.Key)" } | Sort-Object) -join '; '
        } else { '' }

        # ✅ Standard: anta INTE nytt layoutläge om vi inte hittar ankaret
        $isNewLayout = $false
        try {
            $tmpRow = Find-InfoRow -Ws $wsInfo -Label 'CSV-Info'
            if ($tmpRow) { $isNewLayout = $true }
        } catch {}

        $rowCsvFile    = Find-InfoRow -Ws $wsInfo -Label 'CSV'
        $rowLsp        = Find-InfoRow -Ws $wsInfo -Label 'LSP'
        $rowBag        = Find-InfoRow -Ws $wsInfo -Label 'Infinity bags'
        if (-not $rowBag) { $rowBag = Find-InfoRow -Ws $wsInfo -Label 'Bag Numbers Tested Using Infinity' }
        if (-not $rowBag) { $rowBag = Find-InfoRow -Ws $wsInfo -Label 'Bag Numbers Tested Using Infinity:' }
        if (-not $rowBag) { $rowBag = 11 }
        $rowAntal      = Find-InfoRow -Ws $wsInfo -Label 'Antal tester'
        if (-not $rowDupSample) { $rowDupSample = Find-InfoRow -Ws $wsInfo -Label 'Dublett Sample ID' }

        $wsInfo.Cells["B$rowBag"].Style.Numberformat.Format = '@'
        $wsInfo.Cells["B$rowBag"].Value = $infSummary

        if ($isNewLayout) {
            if (-not $rowCsvFile)   { $rowCsvFile   = 8 }
            if (-not $rowLsp)       { $rowLsp       = 9 }
            if (-not $rowBag)       { $rowBag       = 10 }
            if (-not $rowAntal)     { $rowAntal     = 11 }
        }

        if ($selCsv -or $selCsvRes) {
            $wsInfo.Cells["B$rowCsvFile"].Style.Numberformat.Format = '@'
            $csvLabel = ''
            if ($selCsv -and $selCsvRes) {
                $csvLabel = "Primary: {0} | Resampling: {1}" -f (Get-CleanLeaf $selCsv), (Get-CleanLeaf $selCsvRes)
            } elseif ($selCsv) {
                $csvLabel = (Get-CleanLeaf $selCsv)
            } else {
                $csvLabel = "Resampling: {0}" -f (Get-CleanLeaf $selCsvRes)
            }
            $wsInfo.Cells["B$rowCsvFile"].Value = $csvLabel
        } else {
            $wsInfo.Cells["B$rowCsvFile"].Value = ''
        }

        $wsInfo.Cells["B$rowLsp"].Style.Numberformat.Format = '@'
        $wsInfo.Cells["B$rowLsp"].Value = $(if ($lspSummary) { $lspSummary } else { $lsp })

        # ✅ Skriv Antal tester EN gång (som text för att inte bli 1.00E+3 etc)
        $wsInfo.Cells["B$rowAntal"].Style.Numberformat.Format = '@'
        $totalTests = [int]$csvStats.TestCount
        $antalText = "$totalTests"
        if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) {
            $totalTests += [int]$csvStatsRes.TestCount
            $antalText = "$totalTests ($($csvStats.TestCount) + $($csvStatsRes.TestCount) Resample)"
        }
        $wsInfo.Cells["B$rowAntal"].Value = $antalText

        try { $wsInfo.Cells['B:B'].Style.WrapText = $false } catch {}

    } catch {
        Gui-Log ("⚠️ CSV data-fel: " + $_.Exception.Message) 'Warn'
    }

    # --- Makro / dokumentinfo ---
    $assayForMacro = ''
    if ($runAssay) { $assayForMacro = $runAssay }
    elseif ($wsOut1) { $assayForMacro = Get-CellText $wsOut1 $Layout.AssayNameCell }

    $miniVal = ''
    if (Get-Command Get-MinitabMacro -ErrorAction SilentlyContinue) {
        $miniVal = Get-MinitabMacro -AssayName $assayForMacro
    }
    if (-not $miniVal) { $miniVal = 'N/A' }

    $hdNeg = $null; $hdPos = $null
    try { $hdNeg = Get-SealHeaderDocInfo -Pkg $pkgNeg } catch {}
    try { $hdPos = Get-SealHeaderDocInfo -Pkg $pkgPos } catch {}
    if (-not $hdNeg) { $hdNeg = [pscustomobject]@{ Raw=''; DocNo=''; Rev='' } }
    if (-not $hdPos) { $hdPos = [pscustomobject]@{ Raw=''; DocNo=''; Rev='' } }

    $wsInfo.Cells['B2'].Value = $ScriptVersion
    $wsInfo.Cells['B3'].Value = $env:USERNAME
    $wsInfo.Cells['B4'].Value = (Get-Date).ToString('yyyy-MM-dd HH:mm')
    $wsInfo.Cells['B5'].Value = $miniVal

    # --- Batch + länkar ---
    $selLsp = $null
    try {
        if (Get-Variable -Name clbLsp -ErrorAction SilentlyContinue) {
            $selLsp = Get-CheckedFilePath $clbLsp
        }
    } catch {}

    # Snapshot även för Worksheet (om vald) – läsning sker från kopian
    if ($enableStaging -and $stageDir -and $selLsp -and (Test-Path -LiteralPath $selLsp)) {
        try {
            $selLspOrig = $selLsp
            $selLsp = Stage-InputFileSnapshot -Path $selLsp -StageDir $stageDir -Prefix 'Worksheet'
        } catch {}
    }
$batchInfo = Get-BatchLinkInfo -SealPosPath $selPos -SealNegPath $selNeg -Lsp $lspForLinks
$batch     = $batchInfo.Batch
$spOrder   = $batchInfo.Order
$wsInfo.Cells['A31'].Value = 'Öppna SharePoint-post'
$wsInfo.Cells['A31'].Style.Font.Bold = $true
Add-Hyperlink -Cell $wsInfo.Cells['B31'] -Text $batchInfo.LinkText -Url $batchInfo.Url

try {
    if ($batchInfo.OrderStatus -eq 'Mismatch') {
        Gui-Log ("⚠️ Seal Test Order# mismatch mellan aktiva blad: " + (($batchInfo.OrderInfo.AllOrders | Sort-Object) -join ', ')) 'Warn'
    }
    elseif ($batchInfo.OrderStatus -ne 'Unique') {
        Gui-Log "⚠️ Entydigt Order# kunde inte läsas från Seal Test. SharePoint-sökning litar inte på Batch/LSP." 'Warn'
    }
} catch {}

    $linkMap = [ordered]@{
        'IPT App'      = 'https://apps.powerapps.com/play/e/default-771c9c47-7f24-44dc-958e-34f8713a8394/a/fd340dbd-bbbf-470b-b043-d2af4cb62c83'
        'MES Login'    = 'http://mes.cepheid.pri/camstarportal/?domain=CEPHEID.COM'
        'CSV Uploader' = 'http://auw2wgxtpap01.cepaws.com/Welcome.aspx'
        'BMRAM'        = 'https://cepheid62468.coolbluecloud.com/'
        'Agile'        = 'https://agileprod.cepheid.com/Agile/default/login-cms.jsp'
    }

    $rowLink = 32
    foreach ($key in $linkMap.Keys) {
        $wsInfo.Cells["A$rowLink"].Value = $key
        Add-Hyperlink -Cell $wsInfo.Cells["B$rowLink"] -Text 'LÄNK' -Url $linkMap[$key]
        $rowLink++
    }

} catch {
    Gui-Log ("⚠️ Run Information fel: " + $_.Exception.Message) 'Warn'
}
                        
# ----------------------------------------------------------------
# WS (LSP-blad): hitta fil och skriv in i Information-bladet
# ----------------------------------------------------------------
try {
    if (-not $selLsp) {
        $probeDir = $null
        if ($selPos) { $probeDir = Split-Path -Parent $selPos }
        if (-not $probeDir -and $selNeg) { $probeDir = Split-Path -Parent $selNeg }

        if ($probeDir -and (Test-Path -LiteralPath $probeDir)) {
            $cand = Get-ChildItem -LiteralPath $probeDir -File -ErrorAction SilentlyContinue |
                    Where-Object {
                        ($_.Name -match '(?i)worksheet') -and
                        ($_.Name -match [regex]::Escape($lsp)) -and
                        ($_.Extension -match '^\.(xlsx|xlsm|xls)$')
                    } |
                    Sort-Object LastWriteTime -Descending |
                    Select-Object -First 1

            if ($cand) { $selLsp = $cand.FullName }
        }
    }

    if ($selLsp -and (Test-Path -LiteralPath $selLsp)) {
        $wsLeaf = Get-CleanLeaf $selLsp
        Gui-Log ("🔎 Worksheet: " + $wsLeaf) 'Info'
    } else {
        Gui-Log "ℹ️ Ingen WS-fil vald/hittad (LSP Worksheet). Hoppar över WS-extraktion." 'Info'
    }
} catch {
    Gui-Log ("⚠️ WS-block fel: " + $_.Exception.Message) 'Warn'
}

try {
    # Se till att dessa alltid finns (de används senare)
    $headerWs  = $null
    $headerNeg = $null
    $headerPos = $null
    # OBS: $eqInfo används senare vid Equipment-blad → initiera här
    if (-not (Get-Variable -Name eqInfo -Scope 1 -ErrorAction SilentlyContinue)) {
        $eqInfo = $null
    }

    # --- Återanvänd WS-paketet från Data Summary-skanning om möjligt ---
    $tmpPkg = $null
    $tmpPkgReused = $false
    try {
        if ($selLsp -and (Test-Path -LiteralPath $selLsp)) {
            try {
                if ($script:WsPkg -and $script:WsPkg.File -and
                    $script:WsPkg.File.FullName -ieq (Resolve-Path -LiteralPath $selLsp -ErrorAction SilentlyContinue).Path) {
                    $tmpPkg = $script:WsPkg
                    $tmpPkgReused = $true
                } else {
                    # Sökväg ändrades (borde inte hända), öppna ny
                    if ($script:WsPkg) { try { $script:WsPkg.Dispose() } catch {} }
                    $script:WsPkg = $null
                    $tmpPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selLsp))
                }

                # ==============================
                # Utrustning / TestSummary
                # ==============================
                try {
                    # "EquipmentSheet" ska endast generera själva BLADET/mallen.
                    # Det ska *inte* automatiskt hämta pipetter/instrument från Test Summary/CSV här,
                    # annars blir det en blandning (automatiskt + manuellt) som förvirrar användaren.
                    if ($Config -and $Config.Contains('EnableEquipmentSheet') -and -not $Config.EnableEquipmentSheet) {
                        $eqInfo = $null
                        Gui-Log 'ℹ️ Utrustningslista avstängt. Hoppar över.' 'Info'
                    } else {
                        $eqInfo = $null
                        Gui-Log '✅ Utrustningslista hämtad.' 'Info' 'PROGRESS'
                    }
                } catch {
                    # Utrustning ska aldrig få stoppa rapporten
                    try { Gui-Log ("⚠️ Utrustningslista: kunde inte hämtas: " + $_.Exception.Message) 'Warn' } catch {}
                    $eqInfo = $null
                }

                # ==============================
                # Bladrubrik (extrahera + jämför)
                # ==============================
                try {
                    $headerWs = Extract-WorksheetHeader -Pkg $tmpPkg
                } catch {
                    $headerWs = $null
                }

                # Reservväg om extrahering gav null: skapa tomt objekt så .PartNo osv inte kraschar
                if (-not $headerWs) {
                    $headerWs = [pscustomobject]@{
                        WorksheetName   = ''
                        PartNo          = ''
                        BatchNo         = ''
                        CartridgeNo     = ''
                        DocumentNumber  = ''
                        Rev             = ''
                        Effective       = ''
                        Attachment      = ''
                    }
                }

                # StrictMode-säker: används senare även om jämförelsen misslyckas
                $wsHeaderCheck = $null
try {
    # QC Data ska bara ingå i headerkontrollen när Additional QC Data faktiskt förväntas.
    # Samma grundlogik som QC-påminnelsen: assay + Test Summary!B3.
    $qcDataHeaderExpected = $false
    $qcDataHeaderB3       = $null
    $qcDataSheetExists    = $false
    try {
        $qcDataSheetExists = @(
            $tmpPkg.Workbook.Worksheets |
            Where-Object { ($_.Name + '') -match '(?i)^\s*QC\s+Data\s*$' }
        ).Count -gt 0
        $qcTriggerAssays = @(
            'Xpert_HIV-1 Viral Load',
            'Xpert HIV-1 Viral Load XC',
            'Xpert_HCV Viral Load',
            'Xpert HCV VL Fingerstick',
            'Xpert HBV Viral Load',
            'Xpert_HIV-1 Qual',
            'HIV-1_Qual RUO',
            'HIV-1 Qual XC DBS RUO',
            'HIV-1 Qual XC DBS IUO',
            'Xpert HIV-1 Qual XC PQC',
            'Xpert HIV-1 Qual XC PQC RUO'
        )
        $qcValidPartNos = @(
            'GXHIV-VL-CE-10',
            'GXHIV-VL-IN-10',
            'GXHIV-VL-CN-10',
            'GXHIV-VL-XC-CE-10',
            'GXHCV-VL-CE-10',
            'GXHCV-VL-IN-10',
            'GXHCV-FS-CE-10',
            'GXHBV-VL-CE-10',
            'GXHIV-QA-CE-10',
            'RHIVQ-10',
            '700-6098/HIV-1 QUAL XC, RUO',
            '700-6137/HIV-1 QUAL XC, IUO',
            '700-6793/ HIV-1 QUAL XC, CE-IVD',
            '700-6911/ HIV-1 QUAL XC, RUO'
        )

        $qcAssayMatch = $false
        if ($runAssay) {
            foreach ($_qa in $qcTriggerAssays) {
                if ($runAssay -ilike "$_qa*") {
                    $qcAssayMatch = $true
                    break
                }
            }
        }
        if ($qcAssayMatch) {
            $tsWs = $tmpPkg.Workbook.Worksheets |
                Where-Object { $_.Name -ieq 'Test Summary' } |
                Select-Object -First 1
            if ($tsWs) {
                $qcDataHeaderB3 = Get-CellText $tsWs 'B3'
                if ($qcDataHeaderB3 -and ($qcValidPartNos -contains $qcDataHeaderB3)) {
                    $qcDataHeaderExpected = $true
                }
            }
        }
    } catch {
        try { Gui-Log ("⚠️ QC Data header-gate: " + $_.Exception.Message) 'Warn' } catch {}
    }

    $wsHeaderRows  = Get-WorksheetHeaderPerSheet -Pkg $tmpPkg -IncludeQcData:$qcDataHeaderExpected
    $wsHeaderCheck = Compare-WorksheetHeaderSet   -Rows $wsHeaderRows

    try {
        if ($qcDataHeaderExpected) {
            if ($qcDataSheetExists) {
                $qcDataChecked = @(
                    $wsHeaderRows |
                    Where-Object { ($_.Sheet + '') -match '(?i)^\s*QC\s+Data\s*$' }
                ).Count -gt 0

                if ($qcDataChecked) {
                    Gui-Log ("✅ Worksheet header-kontroll inkluderar QC Data ({0})" -f $qcDataHeaderB3) 'Info'
                }
                else {
                    Gui-Log ("⚠️ Additional QC Data förväntas ({0}), men QC Data ingick inte i headerkontrollen" -f $qcDataHeaderB3) 'Warn'
                }
            }
            else {
                Gui-Log ("⚠️ Additional QC Data förväntas ({0}), men QC Data-flik saknas i Worksheet" -f $qcDataHeaderB3) 'Warn'
            }
        }
        elseif ($qcDataSheetExists) {
            Gui-Log "ℹ️ QC Data-flik finns, men Additional QC Data förväntas inte enligt Test Summary B3. QC Data exkluderas från headerkontroll." 'Info'
        }
    } catch {}
    try {
        if ($wsHeaderCheck.Issues -gt 0 -and $wsHeaderCheck.Summary) {
            Gui-Log ("⚠️ Worksheet header-avvikelser: {0} – se Run Information!" -f $wsHeaderCheck.Summary) 'Warn'
        } else {
            Gui-Log "✅ Worksheet header korrekt" 'Info' 'PROGRESS'
        }
    } catch {}
} catch {
    try { Gui-Log ("⚠️ Worksheet header-jämförelse: " + $_.Exception.Message) 'Warn' } catch {}
}

                # ==============================
                # Förstärk headerWs via etiketter (om extrahering missade)
                # ==============================
                try {
                    $wsLsp = $tmpPkg.Workbook.Worksheets | Where-Object {
                        $_.Name -ne 'Worksheet Instructions' -and
                        $_.Name -notmatch '(?i)^\s*QC\s+Data\s*$'
                    } | Select-Object -First 1
                    if (-not $wsLsp) {
                        $wsLsp = $tmpPkg.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' } | Select-Object -First 1
                    }
                    if ($wsLsp) {

                        if (-not $headerWs.PartNo) {
                            $val = $null
                            $labels = @('Part No.','Part No.:','Part No','Part Number','Part Number:','Part Number.','Part Number.:')
                            foreach ($lbl in $labels) { $val = Find-LabelValueRightward -Ws $wsLsp -Label $lbl; if ($val) { break } }
                            if ($val) { $headerWs.PartNo = $val }
                        }

                        if (-not $headerWs.BatchNo) {
                            $val = $null
                            $labels = @(
                                'Batch No(s)','Batch No(s).','Batch No(s):','Batch No(s).:',
                                'Batch No','Batch No.','Batch No:','Batch No.:',
                                'Batch Number','Batch Number.','Batch Number:','Batch Number.:'
                            )
                            foreach ($lbl in $labels) { $val = Find-LabelValueRightward -Ws $wsLsp -Label $lbl; if ($val) { break } }
                            if ($val) { $headerWs.BatchNo = $val }
                        }

                        if (-not $headerWs.CartridgeNo -or $headerWs.CartridgeNo -eq '.') {
                            $val = $null
                            $labels = @(
                                'Cartridge No. (LSP)','Cartridge No. (LSP):','Cartridge No. (LSP) :',
                                'Cartridge No (LSP)','Cartridge No (LSP):','Cartridge No (LSP) :',
                                'Cartridge Number (LSP)','Cartridge Number (LSP):','Cartridge Number (LSP) :',
                                'Cartridge No.','Cartridge No.:','Cartridge No. :','Cartridge No :',
                                'Cartridge Number','Cartridge Number:','Cartridge Number :',
                                'Cartridge No','Cartridge No:','Cartridge No :'
                            )
                            foreach ($lbl in $labels) { $val = Find-LabelValueRightward -Ws $wsLsp -Label $lbl; if ($val) { break } }

                            if (-not $val) {
                                $rxCart = [regex]::new('(?i)Cartridge.*\(LSP\)')
                                $maxCols = [Math]::Min($wsLsp.Dimension.End.Column, 100)
                                $hitCart = Find-RegexCell -Ws $wsLsp -Rx $rxCart -MaxRows 200 -MaxCols $maxCols
                                if ($hitCart) {
                                    for ($c = $hitCart.Col + 1; $c -le $wsLsp.Dimension.End.Column; $c++) {
                                        $cellVal = ($wsLsp.Cells[$hitCart.Row, $c].Text + '').Trim()
                                        if (-not $cellVal) { continue }

                                        $mCart = [regex]::Match($cellVal, '(?<![A-Za-z0-9])(\d{5})(?!\d)')
                                        if ($mCart.Success) {
                                            $val = $mCart.Groups[1].Value
                                            break
                                        }
                                    }
                                }
                            }

                            if ($val) {
                                $mCart = [regex]::Match(($val + ''), '(?<![A-Za-z0-9])(\d{5})(?!\d)')
                                if ($mCart.Success) {
                                    $headerWs.CartridgeNo = $mCart.Groups[1].Value
                                }
                            }
                        }

                        if (-not $headerWs.Effective) {
                            $val = Find-LabelValueRightward -Ws $wsLsp -Label 'Effective'
                            if (-not $val) { $val = Find-LabelValueRightward -Ws $wsLsp -Label 'Effective Date' }
                            if ($val) { $headerWs.Effective = $val }
                        }
                    }
                } catch {}

                # Ingen filnamnsfallback för Worksheet CartridgeNo.
                # Worksheet-header ska spegla faktisk header/cell-data, inte filnamn.

                # ==============================
                # QC-påminnelse – HIV/HBV/HCV-assays (läser Test Summary B3 medan $tmpPkg är öppen)
                # ==============================
                $script:QcReminderB3 = $null
                try {
                    $qcTriggerAssays = @(
                        'Xpert_HIV-1 Viral Load',
                        'Xpert HIV-1 Viral Load XC',
                        'Xpert_HCV Viral Load',
                        'Xpert HCV VL Fingerstick',
                        'Xpert HBV Viral Load',
                        'Xpert_HIV-1 Qual',
                        'HIV-1_Qual RUO',
                        'HIV-1 Qual XC DBS RUO',
                        'HIV-1 Qual XC DBS IUO',
                        'Xpert HIV-1 Qual XC PQC',
                        'Xpert HIV-1 Qual XC PQC RUO'


                    )
                    $qcValidPartNos = @(
                        'GXHIV-VL-CE-10','GXHIV-VL-IN-10','GXHIV-VL-CN-10',
                        'GXHIV-VL-XC-CE-10','GXHCV-VL-CE-10','GXHCV-VL-IN-10',
                        'GXHCV-FS-CE-10','GXHBV-VL-CE-10',
                        'GXHIV-QA-CE-10','RHIVQ-10'
                        '700-6098/HIV-1 QUAL XC, RUO','700-6137/HIV-1 QUAL XC, IUO',
                        '700-6793/ HIV-1 QUAL XC, CE-IVD','700-6911/ HIV-1 QUAL XC, RUO'
                    )

                    $qcAssayMatch = $false
                    if ($runAssay) {
                        foreach ($_qa in $qcTriggerAssays) {
                            if ($runAssay -ilike "$_qa*") { $qcAssayMatch = $true; break }
                        }
                    }

                    if ($qcAssayMatch) {
                        $tsWs = $tmpPkg.Workbook.Worksheets | Where-Object { $_.Name -ieq 'Test Summary' } | Select-Object -First 1
                        if ($tsWs) {
                            $b3Val = Get-CellText $tsWs 'B3'
                            if ($b3Val -and ($qcValidPartNos -contains $b3Val)) {
                                $script:QcReminderB3 = $b3Val
                                Gui-Log ("🔬 QC Data Påminnelse: Assay={0}, Part/Cat. No. {1} → aktiverad" -f $runAssay, $b3Val) 'Info'
                            } else {
                                Gui-Log ("ℹ️ QC Data: Assay matchar men Part/Cat. No. '{0}' ej i listan → hoppar över." -f $b3Val) 'Info'
                            }
                        } else {
                            Gui-Log "ℹ️ QC Data: Assay matchar men 'Test Summary'-blad saknas i Worksheet." 'Info'
                        }
                    }
                } catch {
                    Gui-Log ("⚠️ QC Data Påminnelse: " + $_.Exception.Message) 'Warn'
                }

            } catch {
                # Om WS öppnas men något inne fallerar: låt det inte döda hela rapporten
                Gui-Log ("⚠️ WS-fel: " + $_.Exception.Message) 'Warn'
            }
        }
    } finally {
        # Frigör WS-paketet (nollställ $script:WsPkg oavsett om det återanvändes)
        if ($tmpPkg) { try { $tmpPkg.Dispose() } catch {} }
        $script:WsPkg = $null
        $tmpPkg = $null
    }

    # SealTest-rubriker
    try { $headerNeg = Extract-SealTestHeader -Pkg $pkgNeg } catch {}
    try { $headerPos = Extract-SealTestHeader -Pkg $pkgPos } catch {}

    # Reserv för Effective i Seal POS/NEG om fält saknas
    try {
        if ($pkgPos -and $headerPos -and -not $headerPos.Effective) {
            $wsPos = $pkgPos.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' } | Select-Object -First 1
            if ($wsPos) {
                $val = Find-LabelValueRightward -Ws $wsPos -Label 'Effective'
                if (-not $val) { $val = Find-LabelValueRightward -Ws $wsPos -Label 'Effective Date' }
                if ($val) { $headerPos.Effective = $val }
            }
        }
    } catch {}

    try {
        if ($pkgNeg -and $headerNeg -and -not $headerNeg.Effective) {
            $wsNeg = $pkgNeg.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' } | Select-Object -First 1
            if ($wsNeg) {
                $val = Find-LabelValueRightward -Ws $wsNeg -Label 'Effective'
                if (-not $val) { $val = Find-LabelValueRightward -Ws $wsNeg -Label 'Effective Date' }
                if ($val) { $headerNeg.Effective = $val }
            }
        }
    } catch {}

    # --------------------------
    # Rubriksammanfattning → Information
    # --------------------------
    try {
        $wsBatch   = if ($headerWs -and $headerWs.BatchNo) { $headerWs.BatchNo } else { $null }
        $sealBatch = $batch
        if (-not $sealBatch) {
            try { if ($selPos) { $sealBatch = Get-BatchNumberFromSealFile $selPos } } catch {}
            if (-not $sealBatch) { try { if ($selNeg) { $sealBatch = Get-BatchNumberFromSealFile $selNeg } } catch {} }
        }

        $rowWsFile = Find-InfoRow -Ws $wsInfo -Label 'Worksheet'
        if (-not $rowWsFile) { $rowWsFile = 17 }
        $rowPart  = $rowWsFile + 1
        $rowBatch = $rowWsFile + 2
        $rowCart  = $rowWsFile + 3
        $rowDoc   = $rowWsFile + 4
        $rowRev   = $rowWsFile + 5
        $rowEff   = $rowWsFile + 6

        $rowPosFile = Find-InfoRow -Ws $wsInfo -Label 'Seal Test POS'
        if (-not $rowPosFile) { $rowPosFile = $rowWsFile + 7 }
        $rowPosDoc = $rowPosFile + 1
        $rowPosRev = $rowPosFile + 2
        $rowPosEff = $rowPosFile + 3

        $rowNegFile = Find-InfoRow -Ws $wsInfo -Label 'Seal Test NEG'
        if (-not $rowNegFile) { $rowNegFile = $rowPosFile + 4 }
        $rowNegDoc = $rowNegFile + 1
        $rowNegRev = $rowNegFile + 2
        $rowNegEff = $rowNegFile + 3

        if ($selLsp) {
            $wsInfo.Cells["B$rowWsFile"].Style.Numberformat.Format = '@'
            $wsInfo.Cells["B$rowWsFile"].Value = (Get-CleanLeaf $selLsp)
        } else {
            $wsInfo.Cells["B$rowWsFile"].Value = ''
        }

        $consPart  = Get-ConsensusValue -Type 'Part'      -Ws $headerWs.PartNo      -Pos $headerPos.PartNumber   -Neg $headerNeg.PartNumber
        $consBatch = Get-ConsensusValue -Type 'Batch'     -Ws $headerWs.BatchNo     -Pos $headerPos.BatchNumber  -Neg $headerNeg.BatchNumber
        $consCart  = Get-ConsensusValue -Type 'Cartridge' -Ws $headerWs.CartridgeNo -Pos $headerPos.CartridgeNo  -Neg $headerNeg.CartridgeNo
        # Ingen filnamnsfallback för Cartridge i Run Information.
        # Visat Worksheet-värde ska komma från faktisk header/cell-data.
$wsInfo.Cells["B$rowPart"].Value = if ($consPart.Value) { $consPart.Value } else { '' }
$runBatchDisplay = ''
try {
    $runBatchTokens = @(Get-BatchTokenList -Values @(
        $headerWs.BatchNo,
        $headerPos.BatchNumber,
        $headerNeg.BatchNumber,
        $batchInfo.Batch
    ))
    if ($runBatchTokens.Count -gt 0) {
        $runBatchDisplay = Join-TokenList $runBatchTokens
    }
} catch {}

if (-not $runBatchDisplay -and $consBatch.Value) {
    $runBatchDisplay = $consBatch.Value
}

$wsInfo.Cells["B$rowBatch"].Style.Numberformat.Format = '@'
$wsInfo.Cells["B$rowBatch"].Value = $runBatchDisplay
$wsInfo.Cells["B$rowCart"].Value = if ($consCart.Value) { $consCart.Value } else { '' }

        # wsHeaderCheck → skriv Match/Mismatch i C-kolumn för Part/Batch/Cartridge
        try {
            $StyleMismatchCell = {
                param($Cell, $Text)
                $Cell.Style.Numberformat.Format = '@'
                $Cell.Value = '⚠ ' + $Text
                $Cell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $Cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#FFCCCC'))
                $Cell.Style.Font.Bold = $true
                $Cell.Style.Font.Color.SetColor([System.Drawing.Color]::DarkRed)
            }

            $StyleMatchCell = {
                param($Cell)
                $Cell.Style.Numberformat.Format = '@'
                $Cell.Value = '✓ Alla flikar matchar'
                $Cell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $Cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#C6EFCE'))
                $Cell.Style.Font.Bold = $true
                $Cell.Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml('#006100'))
            }

            $devPart = $null;  $devBatch = $null;  $devCart = $null
            $missPart = $null; $missBatch = $null; $missCart = $null

            if ($wsHeaderCheck -and $wsHeaderCheck.Details) {
                $linesDev = ($wsHeaderCheck.Details -split "`r?`n")
                foreach ($ln in $linesDev) {
                    if ($ln -match '^\*Saknas\*\s*-\s*PartNo\b\s*(.*)$') {
                        $missPart = ($matches[1] + '').Trim()
                    }
                    elseif ($ln -match '^\*Saknas\*\s*-\s*BatchNo\b\s*(.*)$') {
                        $missBatch = ($matches[1] + '').Trim()
                    }
                    elseif ($ln -match '^\*Saknas\*\s*-\s*CartridgeNo\b\s*(.*)$') {
                        $missCart = ($matches[1] + '').Trim()
                    }
                    elseif ($ln -match '^-\s*PartNo[^:]*:\s*(.+)$') {
                        $devPart = $matches[1].Trim()
                    }
                    elseif ($ln -match '^-\s*BatchNo[^:]*:\s*(.+)$') {
                        $devBatch = $matches[1].Trim()
                    }
                    elseif ($ln -match '^-\s*CartridgeNo[^:]*:\s*(.+)$') {
                        $devCart = $matches[1].Trim()
                    }
                }
            }

            if ($wsHeaderCheck) {
                if ($missPart -ne $null) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowPart"]  ($(if ($missPart) { 'Header saknas: ' + $missPart } else { 'Header saknas' }))
                }
                elseif ($devPart) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowPart"]  ('Avvikande: ' + $devPart)
                }
                elseif (-not $consPart.Value) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowPart"]  'Header saknas'
                }
                else {
                    & $StyleMatchCell $wsInfo.Cells["C$rowPart"]
                }

                if ($missBatch -ne $null) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowBatch"] ($(if ($missBatch) { 'Header saknas: ' + $missBatch } else { 'Header saknas' }))
                }
                elseif ($devBatch) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowBatch"] ('Avvikande: ' + $devBatch)
                }
                elseif (-not $consBatch.Value) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowBatch"] 'Header saknas'
                }
                else {
                    & $StyleMatchCell $wsInfo.Cells["C$rowBatch"]
                }

                if ($missCart -ne $null) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowCart"]  ($(if ($missCart) { 'Header saknas: ' + $missCart } else { 'Header saknas' }))
                }
                elseif ($devCart) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowCart"]  ('Avvikande: ' + $devCart)
                }
                elseif (-not $consCart.Value) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowCart"]  'Header saknas'
                }
                else {
                    & $StyleMatchCell $wsInfo.Cells["C$rowCart"]
                }
            }
        } catch {}

        if ($headerWs) {
            $doc = $headerWs.DocumentNumber
            if ($doc) { $doc = ($doc -replace '(?i)\s+(?:Rev(?:ision)?|Effective|p\.)\b.*$', '').Trim() }
            if ($headerWs.Attachment -and ($doc -notmatch '(?i)\bAttachment\s+\w+\b')) {
                $doc = "$doc Attachment $($headerWs.Attachment)"
            }
            $wsInfo.Cells["B$rowDoc"].Value = $doc
            $wsInfo.Cells["B$rowRev"].Value = $headerWs.Rev
            $wsInfo.Cells["B$rowEff"].Value = $headerWs.Effective
            
            if ($wsHeaderCheck -and $doc) { & $StyleMatchCell $wsInfo.Cells["C$rowDoc"] }
            if ($wsHeaderCheck -and $headerWs.Rev) { & $StyleMatchCell $wsInfo.Cells["C$rowRev"] }
            if ($wsHeaderCheck -and $headerWs.Effective) { & $StyleMatchCell $wsInfo.Cells["C$rowEff"] }
        } else {
            $wsInfo.Cells["B$rowDoc"].Value = ''
            $wsInfo.Cells["B$rowRev"].Value = ''
            $wsInfo.Cells["B$rowEff"].Value = ''
        }

        if ($selPos) {
            $wsInfo.Cells["B$rowPosFile"].Style.Numberformat.Format = '@'
            $wsInfo.Cells["B$rowPosFile"].Value = (Get-CleanLeaf $selPos)
        } else { $wsInfo.Cells["B$rowPosFile"].Value = '' }

        if ($headerPos) {
            $docPos = $headerPos.DocumentNumber
            if ($docPos) { $docPos = ($docPos -replace '(?i)\s+(?:Rev(?:ision)?|Effective|p\.)\b.*$','').Trim() }
            $wsInfo.Cells["B$rowPosDoc"].Value = $docPos
            $wsInfo.Cells["B$rowPosRev"].Value = $headerPos.Rev
            $wsInfo.Cells["B$rowPosEff"].Value = if ($headerPos.EffectiveDisplay) { $headerPos.EffectiveDisplay } else { $headerPos.Effective }

            $posHeaderCheck = $null
            try { $posHeaderCheck = $headerPos.HeaderCheck } catch {}
            $devPosDoc = $null; $devPosRev = $null; $devPosEff = $null

            if ($posHeaderCheck -and $posHeaderCheck.Details) {
                $linesDev = ($posHeaderCheck.Details -split "`r?`n")
                foreach ($ln in $linesDev) {
                    if ($ln -match '^-\s*DocumentNumber[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devPosDoc = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*Rev[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devPosRev = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*Effective[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devPosEff = $matches[1].Trim() }
                }
            }

            if ($posHeaderCheck) {
                if ($docPos) {
                    if ($devPosDoc) { & $StyleMismatchCell $wsInfo.Cells["C$rowPosDoc"] ('Avvikande flikar: ' + $devPosDoc) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowPosDoc"] }
                }
                if ($headerPos.Rev) {
                    if ($devPosRev) { & $StyleMismatchCell $wsInfo.Cells["C$rowPosRev"] ('Avvikande flikar: ' + $devPosRev) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowPosRev"] }
                }
                if ($headerPos.Effective) {
                    if ($devPosEff) { & $StyleMismatchCell $wsInfo.Cells["C$rowPosEff"] ('Avvikande flikar: ' + $devPosEff) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowPosEff"] }
                }
            } else {
            }
        } else {
            $wsInfo.Cells["B$rowPosDoc"].Value = ''
            $wsInfo.Cells["B$rowPosRev"].Value = ''
            $wsInfo.Cells["B$rowPosEff"].Value = ''
        }

        if ($selNeg) {
            $wsInfo.Cells["B$rowNegFile"].Style.Numberformat.Format = '@'
            $wsInfo.Cells["B$rowNegFile"].Value = (Get-CleanLeaf $selNeg)
        } else { $wsInfo.Cells["B$rowNegFile"].Value = '' }

        if ($headerNeg) {
            $docNeg = $headerNeg.DocumentNumber
            if ($docNeg) { $docNeg = ($docNeg -replace '(?i)\s+(?:Rev(?:ision)?|Effective|p\.)\b.*$','').Trim() }
            $wsInfo.Cells["B$rowNegDoc"].Value = $docNeg
            $wsInfo.Cells["B$rowNegRev"].Value = $headerNeg.Rev
            $wsInfo.Cells["B$rowNegEff"].Value = if ($headerNeg.EffectiveDisplay) { $headerNeg.EffectiveDisplay } else { $headerNeg.Effective }
            
            $negHeaderCheck = $null
            try { $negHeaderCheck = $headerNeg.HeaderCheck } catch {}
            $devNegDoc = $null; $devNegRev = $null; $devNegEff = $null

            if ($negHeaderCheck -and $negHeaderCheck.Details) {
                $linesDev = ($negHeaderCheck.Details -split "`r?`n")
                foreach ($ln in $linesDev) {
                    if ($ln -match '^-\s*DocumentNumber[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devNegDoc = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*Rev[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devNegRev = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*Effective[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devNegEff = $matches[1].Trim() }
                }
            }

            if ($negHeaderCheck) {
                if ($docNeg) {
                    if ($devNegDoc) { & $StyleMismatchCell $wsInfo.Cells["C$rowNegDoc"] ('Avvikande flikar: ' + $devNegDoc) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowNegDoc"] }
                }
                if ($headerNeg.Rev) {
                    if ($devNegRev) { & $StyleMismatchCell $wsInfo.Cells["C$rowNegRev"] ('Avvikande flikar: ' + $devNegRev) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowNegRev"] }
                }
                if ($headerNeg.Effective) {
                    if ($devNegEff) { & $StyleMismatchCell $wsInfo.Cells["C$rowNegEff"] ('Avvikande flikar: ' + $devNegEff) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowNegEff"] }
                }
            } else {
            }
        } else {
            $wsInfo.Cells["B$rowNegDoc"].Value = ''
            $wsInfo.Cells["B$rowNegRev"].Value = ''
            $wsInfo.Cells["B$rowNegEff"].Value = ''
        }

    } catch {
        Gui-Log ("⚠️ Header summary fel: " + $_.Exception.Message) 'Warn'
    }

} catch {
    Gui-Log "⚠️ Run Information fel: $($_.Exception.Message)" 'Warn'
}

