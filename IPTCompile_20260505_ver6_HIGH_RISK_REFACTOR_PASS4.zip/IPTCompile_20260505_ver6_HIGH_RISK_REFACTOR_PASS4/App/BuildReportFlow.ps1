﻿# BuildReportFlow.ps1
# Registers Build button click handler.
#
# PASS4 note:
# The original large build body has been split into App/BuildFlow/*.ps1 fragments.
# The fragments are concatenated into one scriptblock at startup, then invoked from the
# Build button click handler. This preserves the original single-flow semantics, including
# return statements inside try/finally blocks, while making the build phases easier to find.

$buildFlowDir = Join-Path $PSScriptRoot 'BuildFlow'
$script:IPTBuildFlowFragmentFiles = @(
    (Join-Path $buildFlowDir '01_InitializeAndLoad.ps1')
    (Join-Path $buildFlowDir '02_Signing.ps1')
    (Join-Path $buildFlowDir '03_CsvAndRuleEngine.ps1')
    (Join-Path $buildFlowDir '04_SealTestInfo.ps1')
    (Join-Path $buildFlowDir '05_RunInformationAndHeaders.ps1')
    (Join-Path $buildFlowDir '06_EquipmentAndControls.ps1')
    (Join-Path $buildFlowDir '07_SharePointAndSheetPolish.ps1')
    (Join-Path $buildFlowDir '08_SaveAuditAndFinalize.ps1')
)

$missingBuildFlowFragments = @(
    $script:IPTBuildFlowFragmentFiles | Where-Object { -not (Test-Path -LiteralPath $_) }
)

if ($missingBuildFlowFragments.Count -gt 0) {
    throw ("BuildReportFlow startup error: missing build phase fragment(s): " + ($missingBuildFlowFragments -join '; '))
}

$buildFlowSource = New-Object System.Text.StringBuilder
foreach ($fragmentPath in $script:IPTBuildFlowFragmentFiles) {
    [void]$buildFlowSource.AppendLine("#region " + (Split-Path $fragmentPath -Leaf))
    [void]$buildFlowSource.AppendLine((Get-Content -LiteralPath $fragmentPath -Raw))
    [void]$buildFlowSource.AppendLine("#endregion " + (Split-Path $fragmentPath -Leaf))
}

try {
    $script:IPTBuildReportScriptBlock = [scriptblock]::Create($buildFlowSource.ToString())
} catch {
    throw ("BuildReportFlow startup error: could not compile build phase fragments. " + $_.Exception.Message)
}

$btnBuild.Add_Click({
    & $script:IPTBuildReportScriptBlock
})

#endregion Händelsehanterare (meny, knappar, tema, scan, build)
