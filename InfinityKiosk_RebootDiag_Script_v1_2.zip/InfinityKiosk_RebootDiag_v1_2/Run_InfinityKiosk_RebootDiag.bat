@echo off
setlocal EnableExtensions

title Infinity Kiosk Reboot Diagnostic v1.2
set "DAYS_BACK=120"
set "INCLUDE_EVTX=1"
set "SCRIPT_DIR=%~dp0"
set "PS_SCRIPT=%SCRIPT_DIR%Collect-InfinityKioskRebootDiag.ps1"
set "DESKTOP=%USERPROFILE%\Desktop"
set "LAUNCH_LOG=%DESKTOP%\InfinityKiosk_RebootDiag_Launcher_v1_2.log"

echo ============================================================ > "%LAUNCH_LOG%"
echo Infinity Kiosk Reboot Diagnostic Launcher v1.2             >> "%LAUNCH_LOG%"
echo Started: %DATE% %TIME%                                     >> "%LAUNCH_LOG%"
echo Computer: %COMPUTERNAME%                                   >> "%LAUNCH_LOG%"
echo User: %USERNAME%                                            >> "%LAUNCH_LOG%"
echo Script: %PS_SCRIPT%                                         >> "%LAUNCH_LOG%"
echo ============================================================ >> "%LAUNCH_LOG%"
echo.

echo ============================================================
echo  Infinity Kiosk Reboot Diagnostic v1.2
echo ============================================================
echo.
echo Output will be created on Desktop.
echo Launcher log: %LAUNCH_LOG%
echo.

if not exist "%PS_SCRIPT%" (
    echo ERROR: Missing PowerShell script: "%PS_SCRIPT%"
    echo ERROR: Missing PowerShell script: "%PS_SCRIPT%" >> "%LAUNCH_LOG%"
    pause
    exit /b 1
)

if exist "%WINDIR%\Sysnative\WindowsPowerShell\v1.0\powershell.exe" (
    set "POWERSHELL_EXE=%WINDIR%\Sysnative\WindowsPowerShell\v1.0\powershell.exe"
) else (
    set "POWERSHELL_EXE=%WINDIR%\System32\WindowsPowerShell\v1.0\powershell.exe"
)

echo Using PowerShell: %POWERSHELL_EXE%
echo Using PowerShell: %POWERSHELL_EXE% >> "%LAUNCH_LOG%"

net session >nul 2>&1
if "%ERRORLEVEL%"=="0" (
    echo Admin check: running as administrator.
    echo Admin check: running as administrator. >> "%LAUNCH_LOG%"
) else (
    echo WARNING: Not running as administrator. Some data may be incomplete.
    echo WARNING: Not running as administrator. >> "%LAUNCH_LOG%"
)

set "PS_ARGS=-NoLogo -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%" -DaysBack %DAYS_BACK%"
if "%INCLUDE_EVTX%"=="1" set "PS_ARGS=%PS_ARGS% -IncludeEvtxExport"

echo.
echo Running diagnostic collection...
echo Do not close this window until it says DONE.
echo.
echo Command: "%POWERSHELL_EXE%" %PS_ARGS% >> "%LAUNCH_LOG%"
"%POWERSHELL_EXE%" %PS_ARGS% >> "%LAUNCH_LOG%" 2>&1
set "EXIT_CODE=%ERRORLEVEL%"

echo. >> "%LAUNCH_LOG%"
echo Finished: %DATE% %TIME% >> "%LAUNCH_LOG%"
echo Exit code: %EXIT_CODE% >> "%LAUNCH_LOG%"
echo.
echo Finished. Exit code: %EXIT_CODE%
echo Check Desktop for InfinityKiosk_RebootDiag_... folder/zip.
echo.
pause
exit /b %EXIT_CODE%
