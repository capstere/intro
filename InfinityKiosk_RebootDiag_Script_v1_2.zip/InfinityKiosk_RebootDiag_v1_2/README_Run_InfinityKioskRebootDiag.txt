Infinity Kiosk Reboot Diagnostic v1.2
=====================================

Run method:
1. Copy this folder to the kiosk PC.
2. Right-click Run_InfinityKiosk_RebootDiag.bat and choose "Run as administrator" if possible.
3. The script is read-only and uses ExecutionPolicy Bypass.
4. Output is created on Desktop as a folder and ZIP.

Recommended command if running manually:
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\Collect-InfinityKioskRebootDiag.ps1 -DaysBack 120 -IncludeEvtxExport

v1.2 changes:
- Registry lookup fixed so missing HKLM:\SOFTWARE\Microsoft\Updates cannot stop the script.
- Core reboot/update event markers are collected early before later sections.
- Pending reboot indicators are interpreted more carefully.
- A top-level trap attempts to export findings/errors if a terminating error occurs.
