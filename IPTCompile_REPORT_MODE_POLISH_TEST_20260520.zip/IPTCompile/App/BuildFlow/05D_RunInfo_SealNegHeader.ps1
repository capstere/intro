﻿# Build phase: Run Information Seal Test NEG header block
# PASS6: simplified to shared Run Information helper.

        $sealMergedMode = $false
        try { $sealMergedMode = Test-SealTestMergedMode } catch { $sealMergedMode = $false }
        if ($sealMergedMode) {
            try { $wsInfo.Cells["B$rowNegFile"].Value = 'N/A - merged Seal Test file' } catch {}
            try { $wsInfo.Cells["B$rowNegDoc"].Value = 'N/A' } catch {}
            try { $wsInfo.Cells["B$rowNegRev"].Value = 'N/A' } catch {}
            try { $wsInfo.Cells["B$rowNegEff"].Value = 'N/A' } catch {}
            try {
                $wsInfo.Cells["A$rowNegFile:B$rowNegEff"].Style.Fill.PatternType = 'Solid'
                $wsInfo.Cells["A$rowNegFile:B$rowNegEff"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#E7E6E6'))
                $wsInfo.Cells["A$rowNegFile:B$rowNegEff"].Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml('#666666'))
            } catch {}
        } else {
            Write-RunInfoSealHeaderBlock `
                -WsInfo $wsInfo `
                -FilePath $selNeg `
                -Header $headerNeg `
                -FileRow $rowNegFile `
                -DocRow $rowNegDoc `
                -RevRow $rowNegRev `
                -EffRow $rowNegEff `
                -StyleMatchCell $StyleMatchCell `
                -StyleMismatchCell $StyleMismatchCell
        }

    } catch {
        Gui-Log ("⚠️ Header summary fel: " + $_.Exception.Message) 'Warn'
    }

} catch {
    Gui-Log "⚠️ Run Information fel: $($_.Exception.Message)" 'Warn'
}

