Infinity kiosk reboot diagnostics - how to run
==============================================

1. Copy Collect-InfinityKioskRebootDiag.ps1 to the Infinity kiosk computer Desktop.
2. Right-click Windows PowerShell and choose Run as administrator if possible.
   The script also works without admin, but some logs/policies may be incomplete.
3. Run:

   cd $env:USERPROFILE\Desktop
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Collect-InfinityKioskRebootDiag.ps1 -DaysBack 90

4. The script creates a folder and ZIP on Desktop named like:

   InfinityKiosk_RebootDiag_<COMPUTERNAME>_<yyyyMMdd_HHmmss>
   InfinityKiosk_RebootDiag_<COMPUTERNAME>_<yyyyMMdd_HHmmss>.zip

5. Review first:

   HTML\InfinityKiosk_RebootDiag_Report.html
   CSV\00_FINDINGS_read_this_first.csv
   CSV\65_reboot_shutdown_markers.csv
   CSV\66_timeline_windows_around_reboot_markers.csv
   CSV\63_events_restart_prompt_clues.csv

6. Upload/share the ZIP for review.

The script is read-only. It does not disable Windows Update, services, tasks, or restart behavior.
