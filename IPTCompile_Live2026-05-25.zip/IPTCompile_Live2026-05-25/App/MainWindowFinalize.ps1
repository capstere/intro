﻿# Extracted from Main.ps1. Final UI tooltip/state wiring in caller scope.
# === Verktygstips ===
$toolTip = New-Object System.Windows.Forms.ToolTip
$toolTip.SetToolTip($chkSignOverwrite, $chkSignOverwrite.Tag)
$toolTip.SetToolTip($chkGranskOverwrite, $chkGranskOverwrite.Tag)
$toolTip.AutoPopDelay = 8000
$toolTip.InitialDelay = 500
$toolTip.ReshowDelay  = 500
$toolTip.ShowAlways   = $true
$toolTip.SetToolTip($txtLSP, 'Ange LSP-numret utan och klicka på Sök filer.')
$toolTip.SetToolTip($btnScan, 'Sök efter LSP och lista tillgängliga filer.')
$toolTip.SetToolTip($clbCsv,  'Välj 1 eller 2 CSV-filer (CSV + Resampling-CSV).')
$toolTip.SetToolTip($clbNeg,  'Välj Seal Test Neg-fil.')
$toolTip.SetToolTip($clbPos,  'Välj Seal Test Pos-fil.')
$toolTip.SetToolTip($btnCsvBrowse, 'Bläddra efter en CSV-fil.')
$toolTip.SetToolTip($btnNegBrowse, 'Bläddra efter Seal Test Neg-fil.')
$toolTip.SetToolTip($btnPosBrowse, 'Bläddra efter Seal Test Pos-fil.')
$toolTip.SetToolTip($txtSammName, 'Sammanställning: Förnamn Efternamn (t.ex. Jesper Fredriksson).')
$toolTip.SetToolTip($txtSammDate, 'Sammanställning: Datum.')
$toolTip.SetToolTip($txtSealTestSign, 'Seal Test: SIGN (t.ex. JESP).')
$toolTip.SetToolTip($chkSealTest, 'Signatur appliceras på Seal Test-flikar.')
$toolTip.SetToolTip($chkWsSamm, 'Worksheet-signering är avstängd i denna version.')
$tipOverwriteSammDefault = 'Aktiverar signatur i Seal Test POS/NEG.'
$tipOverwriteGranskDefault = 'Worksheet Granskning-signering är avstängd i denna version.'
$toolTip.SetToolTip($chkSignOverwrite, $tipOverwriteSammDefault)
$toolTip.SetToolTip($chkGranskOverwrite, $tipOverwriteGranskDefault)
$toolTip.SetToolTip($txtGranskName, 'Granskning: Förnamn Efternamn (t.ex. Jesper Fredriksson).')
$toolTip.SetToolTip($txtGranskDate, 'Granskning: Datum.')
$toolTip.SetToolTip($chkWsGransk, 'Worksheet-signering är avstängd i denna version.')
$miToggleSignSamm.ToolTipText = 'Visa eller dölj signering för Seal Test POS/NEG.'
$miToggleSignGransk.ToolTipText = 'Worksheet Granskning-signering är avstängd i denna version.'
$toolTip.SetToolTip($btnBuild, 'Skapa och öppna rapporten baserat på de valda filerna.')
$toolTip.SetToolTip($clbLsp,  'Välj LSP Worksheet.')
$toolTip.SetToolTip($btnMove3, 'Flytta matchade filer från Downloads till TEST-mapp.')
$toolTip.SetToolTip($btnMove4, 'Flytta matchade filer från Downloads till mappen i KLART FÖR GRANSKNING.')

$script:OverwriteUiState = @{
    Sign = @{
        BackColor = $chkSignOverwrite.BackColor
        ForeColor = $chkSignOverwrite.ForeColor
        Font      = $chkSignOverwrite.Font
        Tooltip   = $tipOverwriteSammDefault
    }
    Gransk = @{
        BackColor = $chkGranskOverwrite.BackColor
        ForeColor = $chkGranskOverwrite.ForeColor
        Font      = $chkGranskOverwrite.Font
        Tooltip   = $tipOverwriteGranskDefault
    }
    WarnBackColor = [System.Drawing.Color]::FromArgb(255, 249, 196)
    BoldFont      = New-Object System.Drawing.Font($chkSignOverwrite.Font, ([System.Drawing.FontStyle]::Bold))
}

$chkSealTest.add_CheckedChanged({ Update-OverwriteVerificationUI })
# Worksheet-signering avstängd: checkboxen är dold, men handlern lämnas för säker UI-state.
$chkWsSamm.add_CheckedChanged({ Update-OverwriteVerificationUI })
$chkWsGransk.add_CheckedChanged({ Update-OverwriteVerificationUI })
$chkSignOverwrite.add_CheckedChanged({ Update-OverwriteVerificationUI })
$chkGranskOverwrite.add_CheckedChanged({ Update-OverwriteVerificationUI })
Update-OverwriteVerificationUI

# 2026-05-18: hård UI-spärr. Worksheet-signering ska inte kunna väljas i denna version.
try {
    $chkWsSamm.Checked = $false;   $chkWsSamm.Enabled = $false;   $chkWsSamm.Visible = $false
    $chkWsGransk.Checked = $false; $chkWsGransk.Enabled = $false; $chkWsGransk.Visible = $false
    $chkGranskOverwrite.Checked = $false; $chkGranskOverwrite.Enabled = $false
    $miToggleSignGransk.Visible = $false
} catch {}

# P3: Debounce – kör Update-BatchLink 400ms efter senaste tangenttryck (undviker Excel-IO vid varje tangent)
$script:batchLinkTimer = New-Object System.Windows.Forms.Timer
$script:batchLinkTimer.Interval = 400
$script:batchLinkTimer.add_Tick({
    $script:batchLinkTimer.Stop()
    try { Update-BatchLink } catch {}
})
$txtLSP.add_TextChanged({
    $script:batchLinkTimer.Stop()
    $script:batchLinkTimer.Start()
})

