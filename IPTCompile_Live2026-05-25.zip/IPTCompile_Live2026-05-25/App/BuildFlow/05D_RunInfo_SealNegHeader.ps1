﻿# Build phase: Run Information Seal Test NEG header block
# PASS6: simplified to shared Run Information helper.

        Write-RunInfoSealHeaderBlock `
            -WsInfo $wsInfo `
            -FilePath $selNeg `
            -Header $headerNeg `
            -FileRow $rowNegFile `
            -DocRow $rowNegDoc `
            -RevRow $rowNegRev `
            -EffRow $rowNegEff `
            -StyleMatchCell $StyleMatchCell `
            -StyleMismatchCell $StyleMismatchCell

    } catch {
        Gui-Log ("⚠️ Header summary fel: " + $_.Exception.Message) 'Warn'
    }

} catch {
    Gui-Log "⚠️ Run Information fel: $($_.Exception.Message)" 'Warn'
}

