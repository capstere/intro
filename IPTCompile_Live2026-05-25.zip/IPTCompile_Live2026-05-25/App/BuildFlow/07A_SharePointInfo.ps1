﻿# Build phase: SharePoint info and SP control block
# Extracted/split during HIGH_RISK_REFACTOR_PASS5.

# ============================
# === SharePoint Info      ===
# ============================
try {
    $skipSpInfo = -not $global:SpEnabled

    if ($skipSpInfo) {
        Gui-Log "ℹ️ SharePoint Info avstängt i konfigurationen – hoppar över." 'Info'
        try {
            $old = $pkgOut.Workbook.Worksheets["SharePoint Info"]
            if ($old) { $pkgOut.Workbook.Worksheets.Delete($old) }
        } catch {}
    } else {

        $spOk = $false
        $spStatus = Get-SPClientStatus
        if ($spStatus.Connected) { $spOk = $true }

        if (-not $spOk) {
            # Om manuell anslutning är valt: detta är normalt tills användaren klickar "🔌 Anslut SP".
            if ($global:SpEnabled -and (-not $global:SpAutoConnect)) {
                Gui-Log "ℹ️ SharePoint ej anslutet (manuellt läge). Klicka '🔌 Anslut SP' för att hämta SharePoint-data." 'Info'
            }
            else {
                $errMsg = if ($global:SpError) { $global:SpError } else { 'Okänt fel' }
                Gui-Log ("⚠️ SharePoint ej tillgängligt: $errMsg") 'Warn'
            }
        }

$batchInfo = Get-BatchLinkInfo -SealPosPath $selPos -SealNegPath $selNeg -Lsp $lspForLinks
$batch = $batchInfo.Batch
$spOrder = $batchInfo.Order

        # Startcell för SharePoint Info-blocket i bladet 'Information' (konfigurerbart)
        $spStartCell = $null
        try { $spStartCell = Get-ConfigValue -Name 'SharePointInfoStartCell' -Default $Layout.SpInfoStartCell } catch { $spStartCell = $Layout.SpInfoStartCell }
        $spRc = Convert-A1ToRowCol -A1 $spStartCell -DefaultRow 1 -DefaultCol 5
        $spStartRow = $spRc.Row
        $spStartCol = $spRc.Col
if (-not $spOrder) {
    $orderMsg = 'Entydigt Order# saknas i Seal Test B10'
    try {
        if ($batchInfo.OrderStatus -eq 'Mismatch') {
            $orderMsg = 'Order# mismatch i aktiva Seal Test-blad: ' + (($batchInfo.OrderInfo.AllOrders | Sort-Object) -join ', ')
        }
    } catch {}
    Gui-Log ("⚠️ $orderMsg – SharePoint-post hämtas inte via Batch/LSP.") 'Warn'
    $rowsOrderWarn = @(
        [pscustomobject]@{ Rubrik = 'Status'; 'Värde' = $orderMsg },
        [pscustomobject]@{ Rubrik = 'Notering'; 'Värde' = 'SharePoint-sökning avbruten. Order# krävs som unik nyckel.' }
    )
    [void](Write-SPBlockIntoInformation -Pkg $pkgOut -Rows $rowsOrderWarn -Batch '—' -TargetSheetName $Layout.SheetRunInfo -StartRow $spStartRow -StartCol $spStartCol)

            # Säkerställ att separat flik inte finns kvar (banta rapporten)
            try {
                $old = $pkgOut.Workbook.Worksheets["SharePoint Info"]
                if ($old) { $pkgOut.Workbook.Worksheets.Delete($old) }
            } catch {}
        } else {
            Gui-Log "🔎 Order# hittad i Seal Test: $spOrder" 'Info'

            $fields = @(
                'Work_x0020_Center','Title','Batch_x0023_','SAP_x0020_Batch_x0023__x0020_2',
                'LSP','Material','BBD_x002f_SLED','Actual_x0020_startdate_x002f__x0',
                'PAL_x0020__x002d__x0020_Sample_x','Sample_x0020_Reagent_x0020_P_x00',
                'Order_x0020_quantity','Total_x0020_good','ITP_x0020_Test_x0020_results',
                'IPT_x0020__x002d__x0020_Testing_0','MES_x0020__x002d__x0020_Order_x0'
            )
            $renameMap = @{
                'Work Center'            = 'Work Center'
                'Title'                  = 'Order#'
                'Batch#'                 = 'SAP Batch#'
                'SAP Batch# 2'           = 'SAP Batch# 2'
                'LSP'                    = 'LSP'
                'Material'               = 'Material'
                'BBD/SLED'               = 'BBD/SLED'
                'Actual startdate/_x0'   = 'ROBAL - Actual start date/time'
                'PAL - Sample_x'         = 'Sample Reagent use'
                'Sample Reagent P'       = 'Sample Reagent P/N'
                'Order quantity'         = 'Order quantity'
                'Total good'             = 'ROBAL - Till Packning'
                'IPT Test results'       = 'IPT Test results'
                'IPT - Testing_0'        = 'IPT - Testing Finalized'
                'MES - Order_x0'         = 'MES Order'
            }

            $desiredOrder = @(
                'Work Center','Order#','SAP Batch#','SAP Batch# 2','LSP','Material','BBD/SLED',
                'ROBAL - Actual start date/time','Sample Reagent use','Sample Reagent P/N',
                'Order quantity','ROBAL - Till Packning','IPT Test results',
                'IPT - Testing Finalized','MES Order'
            )

            $dateFields      = @('BBD/SLED','ROBAL - Actual start date/time','IPT - Testing Finalized')
            $shortDateFields = @('BBD/SLED')

            $rows = @()
            if ($spOk) {
                try {
                    # Hela PnP-frågan + fält-extraktion körs i SPClient-runspacen
                    # (PnP ListItem-objekt kan inte serialiseras korrekt över runspace-gränser)

$spResult = Invoke-SPClient -Script {
    param($listName, $fieldNames, $orderToFind)
    try {
        function _normOrder {
            param([object]$Value)
            $s = ('' + $Value)
            $s = ($s -replace '[\u00A0\t\r\n]+', ' ')
            $s = ($s -replace '\s+', ' ').Trim()
            return $s.ToUpperInvariant()
        }
        $targetOrder = _normOrder $orderToFind
        if (-not $targetOrder) {
            return @{ Ok = $true; Found = $false; Data = @{}; Reason = 'Missing Order#' }
        }
        $items = Get-PnPListItem -List $listName -Fields $fieldNames -PageSize 2000 -ErrorAction Stop
        $matches = @(
            $items | Where-Object {
                (_normOrder $_['Title']) -eq $targetOrder
            } | Select-Object -First 2
        )
        if ($matches.Count -eq 0) {
            return @{ Ok = $true; Found = $false; Data = @{}; Reason = "No SharePoint item for Order# $targetOrder" }
        }
        if ($matches.Count -gt 1) {
            return @{ Ok = $false; Err = "Mer än en SharePoint-post matchar Order# $targetOrder. Avbryter för att undvika felträff." }
        }
        $match = $matches[0]
                            if (-not $match) {
                                return @{ Ok = $true; Found = $false; Data = @{} }
                            }

                            # Extrahera alla fält som enkel hashtable (kan serialiseras)
                            $extracted = @{}
                            foreach ($fn in $fieldNames) {
                                $val = $match[$fn]
                                if ($null -ne $val -and $val -ne '') {
                                    # Konvertera LookupValue etc. till strings
                                    if ($val -is [Microsoft.SharePoint.Client.FieldLookupValue]) {
                                        $val = $val.LookupValue
                                    }
                                    $extracted[$fn] = $val
                                }
                            }
                            return @{ Ok = $true; Found = $true; Data = $extracted }
                        } catch {
                            return @{ Ok = $false; Err = $_.Exception.ToString() }
                        }
                    } -Arguments @("Cepheid | Production orders", $fields, $spOrder)

                    if (-not $spResult -or -not $spResult.Ok) {
                        $spErrMsg = if ($spResult -and $spResult.Err) { $spResult.Err } else { 'Okänt fel' }
                        Gui-Log "⚠️ SP: Get-PnPListItem misslyckades: $spErrMsg" 'Warn'
                    }
                    elseif ($spResult.Found) {
                        foreach ($f in $fields) {
                            $val = $spResult.Data[$f]
                            if ($null -eq $val -or $val -eq '') { continue }

                            $label = $f -replace '_x0020_', ' ' `
                                         -replace '_x002d_', '-' `
                                         -replace '_x0023_', '#' `
                                         -replace '_x002f_', '/' `
                                         -replace '_x2013_', '–' `
                                         -replace '_x00',''
                            $label = $label.Trim()
                            if ($renameMap.ContainsKey($label)) { $label = $renameMap[$label] }

                            if ($val -eq $true) { $val = 'JA' }
                            elseif ($val -eq $false) { $val = 'NEJ' }
$dt = $null
if ($val -is [datetime]) { $dt = [datetime]$val }
else { try { $dt = [datetime]::Parse($val) } catch { $dt = $null } }

if ($dt -ne $null -and ($dateFields -contains $label)) {
    try {
        if ($dt.Kind -eq [System.DateTimeKind]::Utc) {
            $dt = $dt.ToLocalTime()
        }
        elseif ($dt.Kind -eq [System.DateTimeKind]::Unspecified) {
            $dt = [datetime]::SpecifyKind($dt, [System.DateTimeKind]::Utc).ToLocalTime()
        }
    } catch {}

    $fmt = if ($shortDateFields -contains $label) { 'yyyy-MM-dd' } else { 'yyyy-MM-dd HH:mm' }
    $val = $dt.ToString($fmt)
}

                            $rows += [pscustomobject]@{ Rubrik = $label; 'Värde' = $val }
                        }
if ($rows.Count -gt 0) {
    $ordered = @()
    foreach ($label in $desiredOrder) {
        $hit = $rows | Where-Object { $_.Rubrik -eq $label } | Select-Object -First 1
        if ($hit) { $ordered += $hit }
    }
    if ($ordered.Count -gt 0) { $rows = $ordered }
    try {
        $spCheck = Test-SharePointBatchLspConsistency `
            -Rows $rows `
            -HeaderWs $headerWs `
            -WorksheetHeaderRows $wsHeaderRows `
            -SealPosPath $selPos `
            -SealNegPath $selNeg `
            -SearchedLsp $lspForLinks `
            -BatchInfo $batchInfo
        if ($spCheck -and $spCheck.Status -ne 'NoRef' -and $spCheck.Message) {
            $rows += @(
                [pscustomobject]@{
                    Rubrik = 'SP Kontroll'
                    'Värde' = $(if ($spCheck.SummaryText) { $spCheck.SummaryText } else { $spCheck.Message })
                }
                [pscustomobject]@{
                    Rubrik = 'SP Order#'
                    'Värde' = $(if ($spCheck.OrderMessage) { $spCheck.OrderMessage } else { '—' })
                }
                [pscustomobject]@{
                    Rubrik = 'SP Batch#'
                    'Värde' = $(if ($spCheck.BatchMessage) { $spCheck.BatchMessage } else { '—' })
                }
                [pscustomobject]@{
                    Rubrik = 'SP LSP'
                    'Värde' = $(if ($spCheck.LspMessage) { $spCheck.LspMessage } else { '—' })
                }
            )
            if ($spCheck.Status -eq 'Mismatch') {
                Gui-Log ("⚠️ SharePoint Order/Batch/LSP mismatch: " + $spCheck.Message) 'Warn'
            }
            else {
                Gui-Log "✅ SharePoint Order/Batch/LSP matchar filer/header" 'Info'
            }
        }
    } catch {
        Gui-Log ("⚠️ SharePoint Order/Batch/LSP-kontroll misslyckades: " + $_.Exception.Message) 'Warn'
    }
    # Cache ROBAL-datum för auto-population av signeringsfält
                            $robalRow = $rows | Where-Object { $_.Rubrik -eq 'ROBAL - Actual start date/time' } | Select-Object -First 1
                            if ($robalRow -and $robalRow.'Värde') {
                                $robalVal = ($robalRow.'Värde' + '').Trim()
                                if ($robalVal -match '^\d{4}-\d{2}-\d{2}') {
                                    $script:RobalDateShort = $robalVal.Substring(0,10) -replace '-',' '
                                }
                            }
                        }

                        Gui-Log "📄 SharePoint-post hittad – skriver blad." 'Info'
} else {
    $reason = if ($spResult -and $spResult.Reason) { $spResult.Reason } else { "Ingen post i SharePoint för Order#=$spOrder" }
    Gui-Log ("ℹ️ " + $reason) 'Info'
}
                } catch {
                    Gui-Log "⚠️ SP: Invoke-SPClient misslyckades: $($_.Exception.Message)" 'Warn'
                }
            }

            [void](Write-SPBlockIntoInformation -Pkg $pkgOut -Rows $rows -Batch $batch -TargetSheetName $Layout.SheetRunInfo -StartRow $spStartRow -StartCol $spStartCol)

            try {
                $old = $pkgOut.Workbook.Worksheets["SharePoint Info"]
                if ($old) { $pkgOut.Workbook.Worksheets.Delete($old) }
            } catch {}

try {
    if ($slBatchLink -and $batchInfo -and $batchInfo.OrderStatus -eq 'Unique' -and $batchInfo.Order) {
        $slBatchLink.Text = "SharePoint: Order# $($batchInfo.Order)"
        $slBatchLink.Tag  = $batchInfo.Url
        $slBatchLink.Enabled = $true
    }
    elseif ($slBatchLink) {
        $slBatchLink.Text = 'SharePoint: —'
        $slBatchLink.Tag  = $null
        $slBatchLink.Enabled = $false
    }
} catch {}

            try {
                $wsSP = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
                if ($wsSP) {
                    $labelCol = $spStartCol
                $valueCol = $spStartCol + 1
                for ($r = ($spStartRow + 1); $r -le ($spStartRow + 120); $r++) {
                        if ((Normalize-HeaderText (($wsSP.Cells[$r,$labelCol].Text + '')).Trim()) -ieq 'Sample Reagent use') {
                            $wsSP.Cells[$r,$valueCol].Style.WrapText = $true
                            $wsSP.Cells[$r,$valueCol].Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Top
                            $wsSP.Row($r).CustomHeight = $true
                            break
                        }
                    }
                }
            } catch {
                Gui-Log "⚠️ WrapText på 'Sample Reagent use' misslyckades: $($_.Exception.Message)" 'Warn'
            }
            try {
    $wsSP = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if ($wsSP) {
        $labelCol = $spStartCol
        $valueCol = $spStartCol + 1
        for ($r = ($spStartRow + 1); $r -le ($spStartRow + 120); $r++) {
            $lbl = (Normalize-HeaderText (($wsSP.Cells[$r,$labelCol].Text + '')).Trim())
if ($lbl -in @('SP Kontroll','SP Order#','SP Batch#','SP LSP')) {
    $val = ($wsSP.Cells[$r,$valueCol].Text + '').Trim()
    # Viktigt:
    # Radhöjd gäller hela Excel-raden. Om SP-blocket sätter rad 15-18 till 30,
    # blir även vänster Dokumentkontroll-raderna 15-18 höga.
    # Därför får SP Kontroll-raderna inte tvinga upp radhöjden.
    $wsSP.Cells[$r,$labelCol].Style.WrapText = $false
    $wsSP.Cells[$r,$valueCol].Style.WrapText = $false
    $wsSP.Cells[$r,$labelCol].Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
    $wsSP.Cells[$r,$valueCol].Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
    if ($lbl -ieq 'SP Kontroll') {
                    $wsSP.Cells[$r,$labelCol].Style.Font.Bold = $true
                    $wsSP.Cells[$r,$valueCol].Style.Font.Bold = $true

                    if ($val -like '⚠*') {
                        $rngSp = $wsSP.Cells[$r,$labelCol,$r,$valueCol]
                        $rngSp.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                        $rngSp.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#FFC7CE'))
                        $rngSp.Style.Font.Color.SetColor([System.Drawing.Color]::DarkRed)
                    }
                    elseif ($val -like '✓*') {
                        $rngSp = $wsSP.Cells[$r,$labelCol,$r,$valueCol]
                        $rngSp.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                        $rngSp.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#C6EFCE'))
                        $rngSp.Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml('#006100'))
                    }
                }
                elseif ($val -like '⚠*') {
                    $rngSpWarn = $wsSP.Cells[$r,$labelCol,$r,$valueCol]
                    $rngSpWarn.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                    $rngSpWarn.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#FFF2CC'))
                    $wsSP.Cells[$r,$valueCol].Style.Font.Color.SetColor([System.Drawing.Color]::DarkRed)
                }
            }
        }
    }
} catch {
    Gui-Log "⚠️ Styling av SP Order/Batch/LSP Kontroll misslyckades: $($_.Exception.Message)" 'Warn'
}
