﻿# Build phase: Seal Test Info table and signature status
# Extracted/split during HIGH_RISK_REFACTOR_PASS5.

        # ============================
        # === Läs avvikelser       ===
        # ============================

        # P2: Extraherad hjälpfunktion (ersätter duplicerad NEG/POS-loop)
$resNeg = Get-SealViolations -Pkg $pkgNeg
        $resPos = Get-SealViolations -Pkg $pkgPos
        $violationsNeg = $resNeg.Violations; $failNegCount = $resNeg.FailCount
        $violationsPos = $resPos.Violations; $failPosCount = $resPos.FailCount
        # STF-count för CSV Sammanfattning: räkna endast riktiga FAIL (Minusvärde visas fortfarande i STF Sum-bladet)
        $script:StfCount = $failNegCount + $failPosCount

        # ============================
        # === Seal Test Info (blad) ==
        # ============================
        Mark-Phase 'RuleEngine'
        $wsOut1 = $pkgOut.Workbook.Worksheets[$Layout.SheetSealTestInfo]
        if (-not $wsOut1) { Gui-Log "❌ Fliken 'Seal Test Info' saknas i mallen"; return }

        for ($row = 3; $row -le 15; $row++) {
            $wsOut1.Cells["D$row"].Value = $null
            try { $wsOut1.Cells["D$row"].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::None } catch {}
        }

        $fields = @(
            @{ Label = "ROBAL";                         Cell = "F2"  }
            @{ Label = "Part Number";                   Cell = "B2"  }
            @{ Label = "Batch Number";                  Cell = "D2"  }
            @{ Label = "Cartridge Number (LSP)";        Cell = "B6"  }
            @{ Label = "PO Number";                     Cell = "B10" }
            @{ Label = "Assay Family";                  Cell = "D10" }
            @{ Label = "Weight Loss Spec";              Cell = "F10" }
            @{ Label = "Balance ID Number";             Cell = "B14" }
            @{ Label = "Balance Cal Due Date";          Cell = "D14" }
            @{ Label = "Vacuum Oven ID Number";         Cell = "B20" }
            @{ Label = "Vacuum Oven Cal Due Date";      Cell = "D20" }
            @{ Label = "Timer ID Number";               Cell = "B25" }
            @{ Label = "Timer Cal Due Date";            Cell = "D25" }
        )

        $forceText = @("ROBAL","Part Number","Batch Number","Cartridge Number (LSP)","PO Number","Assay Family","Balance ID Number","Vacuum Oven ID Number","Timer ID Number")
        $mismatchFields = $fields[0..6] | ForEach-Object { $_.Label }


            # --- Förväntad utrustningslista (valfritt, från equipment.xml) ---
        $equip = $null
        $equipPath = $null
        try {
            $equipPath = Get-ConfigValue -Name 'EquipmentXmlPath' -Default (Join-Path $ScriptRootPath 'equipment.xml') -ConfigOverride $Config
            if ($equipPath -and -not (Test-Path -LiteralPath $equipPath)) {
                Gui-Log ("⚠️ Equipment.xml hittades inte: " + $equipPath) 'Warn'
            }
            if ($equipPath -and (Test-Path -LiteralPath $equipPath)) {
                $equip = Import-Clixml -LiteralPath $equipPath
            }
        } catch {
            $equip = $null
        }

        $equipMap = @{
            'Balance ID Number'        = @{ NegKey='SCALESNEG';       PosKey='SCALESPOS';       Mode='LIST'  }
            'Balance Cal Due Date'     = @{ NegKey='CAL_D_SCALES_NEG'; PosKey='CAL_D_SCALES_POS'; Mode='MONTH' }
            'Vacuum Oven ID Number'    = @{ NegKey='OVENSNEG';        PosKey='OVENSPOS';        Mode='LIST'  }
            'Vacuum Oven Cal Due Date' = @{ NegKey='CAL_D_OVENSNEG';  PosKey='CAL_D_OVENSPOS';  Mode='MONTH' }
            'Timer ID Number'          = @{ NegKey='TIMERSNEG';       PosKey='TIMERSPOS';       Mode='LIST'  }
            'Timer Cal Due Date'       = @{ NegKey='CAL_D_TIMERSNEG'; PosKey='CAL_D_TIMERSPOS'; Mode='MONTH' }
        }

        $row = 3
        foreach ($f in $fields) {
$valNeg=''; $valPos=''
$srcNeg=''; $srcPos=''

# För utrustningsrader: samla per flik (inte avbrott på första!)
$perNeg = $null
$perPos = $null
$isEquip = ($equip -and $equipMap -and $equipMap.ContainsKey($f.Label))

if ($isEquip) {
    $perNegObj = _GetPerSheetValueObjects $pkgNeg $f.Cell
    $perPosObj = _GetPerSheetValueObjects $pkgPos $f.Cell
    $perNeg = @($perNegObj | ForEach-Object { $_.Value })
    $perPos = @($perPosObj | ForEach-Object { $_.Value })

    # Visa i B/C: union (för LIST) eller första icke-tom (för MONTH), bara för läsbarhet
    $map = $equipMap[$f.Label]
    if ($map.Mode -eq 'MONTH') {
        $valNeg = ($perNeg | Where-Object { $_ -and $_.Trim() } | Select-Object -First 1)
        $valPos = ($perPos | Where-Object { $_ -and $_.Trim() } | Select-Object -First 1)
    } else {
        $tokN = @()
        foreach ($x in $perNeg) { $tokN += (_EquipTokens $x) }
        $tokP = @()
        foreach ($x in $perPos) { $tokP += (_EquipTokens $x) }
        $valNeg = _EquipPretty $tokN $f.Label
        $valPos = _EquipPretty $tokP $f.Label
    }
}
else {
    # Befintligt beteende för "vanliga" fält: första AKTIVA flik med värde (skippa blad 1 + inaktiva)
    foreach ($wsN in $pkgNeg.Workbook.Worksheets) {
        if (-not (_IsActiveSealSheet $wsN)) { continue }
        $cell = $wsN.Cells[$f.Cell]
        if ($cell.Value -ne $null) {
            if ($cell.Value -is [datetime]) { $valNeg = $cell.Value.ToString('MMM-yy') } else { $valNeg = $cell.Text }
            $srcNeg = $wsN.Name
            break
        }
    }

    foreach ($wsP in $pkgPos.Workbook.Worksheets) {
        if (-not (_IsActiveSealSheet $wsP)) { continue }
        $cell = $wsP.Cells[$f.Cell]
        if ($cell.Value -ne $null) {
            if ($cell.Value -is [datetime]) { $valPos = $cell.Value.ToString('MMM-yy') } else { $valPos = $cell.Text }
            $srcPos = $wsP.Name
            break
        }
    }
}

            if ($forceText -contains $f.Label) {
                $wsOut1.Cells["B$row"].Style.Numberformat.Format = '@'
                $wsOut1.Cells["C$row"].Style.Numberformat.Format = '@'
            }

            $wsOut1.Cells["B$row"].Value = $valNeg
            $wsOut1.Cells["C$row"].Value = $valPos
            try { $wsOut1.Cells["B$row"].Style.Border.Right.Style = "Medium" } catch {}
            try { $wsOut1.Cells["C$row"].Style.Border.Left.Style  = "Medium" } catch {}

        if ($mismatchFields -contains $f.Label) {
                # D3:D9: visa tydlig Match/Mismatch med symboler
                if ($valNeg -and $valPos) {
                    if ($valNeg -ne $valPos) {
                        # Spårbarhet endast vid mismatch: flik + cell för var värdet hämtades
                        $tN = if ($srcNeg) { ("NEG:{0}@{1}" -f $srcNeg, $f.Cell) } else { ("NEG@{0}" -f $f.Cell) }
                        $tP = if ($srcPos) { ("POS:{0}@{1}" -f $srcPos, $f.Cell) } else { ("POS@{0}" -f $f.Cell) }
                        $wsOut1.Cells["D$row"].Value = ("⚠ Mismatch ({0} | {1})" -f $tN, $tP)
                        try { $wsOut1.Cells["D$row"].Style.Font.Size = 9 } catch {}
                        Style-Cell $wsOut1.Cells["D$row"] $true "FF0000" "Medium" "FFFFFF"
                        Gui-Log "⚠️ Avvikelse: $($f.Label) (NEG='$valNeg' vs POS='$valPos')"
                    } else {
                        $wsOut1.Cells["D$row"].Value = "✓ Match"
                        Style-Cell $wsOut1.Cells["D$row"] $true "C6EFCE" "Medium" "006100"
                    }
                } elseif ($valNeg -or $valPos) {
                    # Bara en av filerna har värde - markera som varning
                    $wsOut1.Cells["D$row"].Value = "⚠ Saknas"
                    Style-Cell $wsOut1.Cells["D$row"] $true "FFE699" "Medium" "806000"
                }
            }

            # --- Utrustningskontroll (POS/NEG har egna tillåtna värden i equipment.xml) ---
            if ($equip -and $equipMap -and $equipMap.ContainsKey($f.Label)) {
                $map = $equipMap[$f.Label]
                $expNeg = $null; $expPos = $null
                try { if ($equip.Contains($map.NegKey)) { $expNeg = (""+$equip[$map.NegKey]).Trim() } } catch {}
                try { if ($equip.Contains($map.PosKey)) { $expPos = (""+$equip[$map.PosKey]).Trim() } } catch {}

# Utvärdera PER FLIK och summera
$stNegAll = @()
$stPosAll = @()
                $negMismatchSheets = @()
                $posMismatchSheets = @()
                $negDelvisSheets = @()
                $posDelvisSheets = @()

if ($map.Mode -eq 'MONTH') {
    for ($i = 0; $i -lt $perNegObj.Count; $i++) {
        $st = (_EquipEvalMonth $perNegObj[$i].Value $expNeg); $stNegAll += $st
        if ($st -eq 'Mismatch') { $negMismatchSheets += ("{0}@{1}" -f $perNegObj[$i].Sheet, $perNegObj[$i].Addr) }
        if ($st -eq 'Delvis')   { $negDelvisSheets   += ("{0}@{1}" -f $perNegObj[$i].Sheet, $perNegObj[$i].Addr) }
    }
    for ($i = 0; $i -lt $perPosObj.Count; $i++) {
        $st = (_EquipEvalMonth $perPosObj[$i].Value $expPos); $stPosAll += $st
        if ($st -eq 'Mismatch') { $posMismatchSheets += ("{0}@{1}" -f $perPosObj[$i].Sheet, $perPosObj[$i].Addr) }
        if ($st -eq 'Delvis')   { $posDelvisSheets   += ("{0}@{1}" -f $perPosObj[$i].Sheet, $perPosObj[$i].Addr) }
    }
} else {

    for ($i = 0; $i -lt $perNegObj.Count; $i++) {
        $st = (_EquipEvalList $perNegObj[$i].Value $expNeg); $stNegAll += $st
        if ($st -eq 'Mismatch') { $negMismatchSheets += ("{0}@{1}" -f $perNegObj[$i].Sheet, $perNegObj[$i].Addr) }
        if ($st -eq 'Delvis')   { $negDelvisSheets   += ("{0}@{1}" -f $perNegObj[$i].Sheet, $perNegObj[$i].Addr) }
    }
    for ($i = 0; $i -lt $perPosObj.Count; $i++) {
        $st = (_EquipEvalList $perPosObj[$i].Value $expPos); $stPosAll += $st
        if ($st -eq 'Mismatch') { $posMismatchSheets += ("{0}@{1}" -f $perPosObj[$i].Sheet, $perPosObj[$i].Addr) }
        if ($st -eq 'Delvis')   { $posDelvisSheets   += ("{0}@{1}" -f $perPosObj[$i].Sheet, $perPosObj[$i].Addr) }
    }
}

$sNeg = _AggregateStatus $stNegAll
$sPos = _AggregateStatus $stPosAll

                # Hjälpfunktion: plocka ut enbart bladnamn (ta bort @cellref)

                $hasMismatch = ($sNeg -eq 'Mismatch' -or $sPos -eq 'Mismatch')
                $hasDelvis   = ($sNeg -eq 'Delvis'   -or $sPos -eq 'Delvis')

                if ($hasMismatch -or $hasDelvis) {
                    # NEG → kolumn D
                    $dVal = 'NEG ' + (_Txt $sNeg)
                    if ($sNeg -eq 'Mismatch' -and $negMismatchSheets.Count -gt 0) {
                        $dVal += ': ' + (_CleanSheets $negMismatchSheets)
                    } elseif ($sNeg -eq 'Delvis' -and $negDelvisSheets.Count -gt 0) {
                        $dVal += ': ' + (_CleanSheets $negDelvisSheets)
                    }
                    $wsOut1.Cells["D$row"].Value = $dVal
                    try { $wsOut1.Cells["D$row"].Style.Font.Size = 9 } catch {}

                    # POS → kolumn E
                    $eVal = 'POS ' + (_Txt $sPos)
                    if ($sPos -eq 'Mismatch' -and $posMismatchSheets.Count -gt 0) {
                        $eVal += ': ' + (_CleanSheets $posMismatchSheets)
                    } elseif ($sPos -eq 'Delvis' -and $posDelvisSheets.Count -gt 0) {
                        $eVal += ': ' + (_CleanSheets $posDelvisSheets)
                    }
                    $wsOut1.Cells["E$row"].Value = $eVal
                    try { $wsOut1.Cells["E$row"].Style.Font.Size = 9 } catch {}
                } else {
                    $wsOut1.Cells["D$row"].Value = ('NEG ' + (_Txt $sNeg) + ' / POS ' + (_Txt $sPos))
                }

                # Formatera D+E utifrån respektive status
                $rank = @{ 'NoRef'=0; 'Match'=1; 'Delvis'=2; 'Saknas'=2; 'Mismatch'=3 }

                foreach ($pair in @(@{C='D';S=$sNeg}, @{C='E';S=$sPos})) {
                    $col = $pair.C; $st = $pair.S
                    $cellVal = ($wsOut1.Cells["$col$row"].Text + '').Trim()
                    if (-not $cellVal) { continue }
                    $r = $rank[$st]
                    if ($r -ge 3) {
                        Style-Cell $wsOut1.Cells["$col$row"] $true "FF0000" "Medium" "FFFFFF"
                    } elseif ($r -ge 2) {
                        Style-Cell $wsOut1.Cells["$col$row"] $true "FFE699" "Medium" "806000"
                    } elseif ($r -ge 1) {
                        Style-Cell $wsOut1.Cells["$col$row"] $true "C6EFCE" "Medium" "006100"
                    }
                }
            }
            $row++
        }

        $wsOut1.Cells["D:D"].Style.WrapText = $false
        $wsOut1.Cells["E:E"].Style.WrapText = $false
        $wsOut1.Column(4).AutoFit()
        $wsOut1.Column(4).Width += 1.5
        $wsOut1.Column(4).BestFit = $true
        $wsOut1.Column(5).AutoFit()
        $wsOut1.Column(5).Width += 1.5
        $wsOut1.Column(5).BestFit = $true

        # R2: Freeze panes – fryser rad 1–2 (rubrik) så data scrollas under
        try { $wsOut1.View.FreezePanes(3, 1) } catch {}

        # ============================
        # === Testare (B43)        ===
        # ============================

        $testersNeg = @(); $testersPos = @()
        $unsignedNegSheets = New-Object System.Collections.Generic.List[string]
        $unsignedPosSheets = New-Object System.Collections.Generic.List[string]
        foreach ($s in $pkgNeg.Workbook.Worksheets) {
            if (-not (_IsActiveSealSheet $s)) { continue }
            $t = (($s.Cells["B43"].Text + '')).Trim()
            if ($t) {
                $testersNeg += ($t -split ",")
            } else {
                [void]$unsignedNegSheets.Add($s.Name)
            }
        }
        foreach ($s in $pkgPos.Workbook.Worksheets) {
            if (-not (_IsActiveSealSheet $s)) { continue }
            $t = (($s.Cells["B43"].Text + '')).Trim()
            if ($t) {
                $testersPos += ($t -split ",")
            } else {
                [void]$unsignedPosSheets.Add($s.Name)
            }
        }
        $testersNeg = $testersNeg | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Sort-Object -Unique
        $testersPos = $testersPos | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Sort-Object -Unique

        $wsOut1.Cells["B16"].Value = "Name of Tester"
        $wsOut1.Cells["B16:C16"].Merge = $true
        $wsOut1.Cells["B16"].Style.HorizontalAlignment = "Center"

        $maxTesters = [Math]::Max($testersNeg.Count, $testersPos.Count)
        $initialRows = 11
        if ($maxTesters -lt $initialRows) { $wsOut1.DeleteRow(17 + $maxTesters, $initialRows - $maxTesters) }
        if ($maxTesters -gt $initialRows) {
            $rowsToAdd = $maxTesters - $initialRows
            $lastRow = 16 + $initialRows
            for ($i = 1; $i -le $rowsToAdd; $i++) { $wsOut1.InsertRow($lastRow + 1, 1, $lastRow) }
        }

        for ($i = 0; $i -lt $maxTesters; $i++) {
            $rowIndex = 17 + $i
            $wsOut1.Cells["A$rowIndex"].Value = $null
            $wsOut1.Cells["B$rowIndex"].Value = if ($i -lt $testersNeg.Count) { $testersNeg[$i] } else { "N/A" }
            $wsOut1.Cells["C$rowIndex"].Value = if ($i -lt $testersPos.Count) { $testersPos[$i] } else { "N/A" }

            $topStyle    = if ($i -eq 0) { "Medium" } else { "Thin" }
            $bottomStyle = if ($i -eq $maxTesters - 1) { "Medium" } else { "Thin" }

            foreach ($col in @("B","C")) {
                $cell = $wsOut1.Cells["$col$rowIndex"]
                $cell.Style.Border.Top.Style    = $topStyle
                $cell.Style.Border.Bottom.Style = $bottomStyle
                $cell.Style.Border.Left.Style   = "Medium"
                $cell.Style.Border.Right.Style  = "Medium"
                $cell.Style.Fill.PatternType = "Solid"
                $cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#CCFFFF"))
            }
        }

        $negUnsignedText = _BuildUnsignedSealText @($unsignedNegSheets.ToArray())
        $posUnsignedText = _BuildUnsignedSealText @($unsignedPosSheets.ToArray())
        $unsignedMsgs = @()
        if ($negUnsignedText) { $unsignedMsgs += ('NEG: ' + $negUnsignedText) }
        if ($posUnsignedText) { $unsignedMsgs += ('POS: ' + $posUnsignedText) }
        if ($unsignedMsgs.Count -gt 0) {
            $unsignedInfo = $unsignedMsgs -join ' | '
            $wsOut1.Cells['D16'].Value = 'Name of Tester (osignerat)'
            $wsOut1.Cells['D17'].Value = $unsignedInfo
            $wsOut1.Cells['D16'].Style.Font.Bold = $true
            $wsOut1.Cells['D16:D17'].Style.WrapText = $true
            Style-Cell $wsOut1.Cells['D17'] $true "FFE699" "Medium" "806000"
            try {
                $wsOut1.Column(4).AutoFit()
                if ($wsOut1.Column(4).Width -lt 42) { $wsOut1.Column(4).Width = 42 }
                $wsOut1.Column(4).BestFit = $true
            } catch {}
            Gui-Log ("⚠️ Name of Tester saknas på aktiva datasheets: {0}" -f $unsignedInfo) 'Warn'
        }
        # ============================
        # === Signatur-jämförelse  ===
        # ============================
$negSigSet = Get-SignatureSetForDataSheets -Pkg $pkgNeg -SignatureCell $Layout.SignatureCell -ActiveCheckCell $Layout.SealActiveCheckCell
$posSigSet = Get-SignatureSetForDataSheets -Pkg $pkgPos -SignatureCell $Layout.SignatureCell -ActiveCheckCell $Layout.SealActiveCheckCell
$negSet = New-Object 'System.Collections.Generic.HashSet[string]'
$posSet = New-Object 'System.Collections.Generic.HashSet[string]'
foreach ($n in $negSigSet.NormSet) { [void]$negSet.Add($n) }
foreach ($p in $posSigSet.NormSet) { [void]$posSet.Add($p) }
# Om denna körning har skrivit och verifierat signaturen i en fil,
# är den skrivna/verifierade signaturen mer pålitlig än gammal inläst B47-data.
# Detta löser fallet där rapportpaketet lästes in före signeringen.
if ($negSealSignatureAppliedThisRun -and $signToWrite) {
    $negSet.Clear()
    [void]$negSet.Add((Normalize-Signature $signToWrite))
}
if ($posSealSignatureAppliedThisRun -and $signToWrite) {
    $posSet.Clear()
    [void]$posSet.Add((Normalize-Signature $signToWrite))
}
$hasNeg = ($negSet.Count -gt 0)
$hasPos = ($posSet.Count -gt 0)
# Räkna aktiva blad och saknade signaturer per fil.
# Detta behövs för att skilja på:
# 1) helt osignerade Seal Test-filer
# 2) delvis signerade filer där något aktivt blad saknar B47
$negActiveCount = 0
$posActiveCount = 0
$negMissingRawCount = 0
$posMissingRawCount = 0
if ($negSigSet -and $negSigSet.PSObject.Properties['ActiveSheets']) {
    $negActiveCount = @($negSigSet.ActiveSheets | Where-Object { $_ }).Count
}
if ($posSigSet -and $posSigSet.PSObject.Properties['ActiveSheets']) {
    $posActiveCount = @($posSigSet.ActiveSheets | Where-Object { $_ }).Count
}
if ($negSigSet -and $negSigSet.PSObject.Properties['Missing']) {
    $negMissingRawCount = @($negSigSet.Missing | Where-Object { $_ }).Count
}
if ($posSigSet -and $posSigSet.PSObject.Properties['Missing']) {
    $posMissingRawCount = @($posSigSet.Missing | Where-Object { $_ }).Count
}
# En fil räknas som helt osignerad endast om:
# - den har aktiva blad
# - ingen signatur hittades
# - alla aktiva blad saknar signatur
# - denna körning har inte precis skrivit/verifierat signatur i filen
$negAllUnsigned = (
    (-not $negSealSignatureAppliedThisRun) -and
    ($negActiveCount -gt 0) -and
    ($negSet.Count -eq 0) -and
    ($negMissingRawCount -eq $negActiveCount)
)
$posAllUnsigned = (
    (-not $posSealSignatureAppliedThisRun) -and
    ($posActiveCount -gt 0) -and
    ($posSet.Count -eq 0) -and
    ($posMissingRawCount -eq $posActiveCount)
)
# Specialfall:
# Om både NEG och POS är helt osignerade ska detta inte loggas som avvikelse.
# Rapporten ska i stället visa "Seal Test blad ej signerade".
$sealSheetsUnsigned = ($negAllUnsigned -and $posAllUnsigned)
$missingNegSheets = @()
$missingPosSheets = @()
if (-not $sealSheetsUnsigned) {
    if (-not $negSealSignatureAppliedThisRun) {
        if ($negSigSet -and $negSigSet.PSObject.Properties['Missing']) {
            $missingNegSheets = @($negSigSet.Missing | Where-Object { $_ })
        }
    }
    if (-not $posSealSignatureAppliedThisRun) {
        if ($posSigSet -and $posSigSet.PSObject.Properties['Missing']) {
            $missingPosSheets = @($posSigSet.Missing | Where-Object { $_ })
        }
    }
}
$sigMissing = ((-not $sealSheetsUnsigned) -and (($missingNegSheets.Count + $missingPosSheets.Count) -gt 0))
$onlyNeg = @()
$onlyPos = @()
$sigMismatch = $false
if ($sealSheetsUnsigned) {
    $sigMismatch = $false
}
elseif ($hasNeg -and $hasPos) {
    foreach ($n in $negSet) {
        if (-not $posSet.Contains($n)) { $onlyNeg += $n }
    }
    foreach ($p in $posSet) {
        if (-not $negSet.Contains($p)) { $onlyPos += $p }
    }
    $sigMismatch = ($onlyNeg.Count -gt 0 -or $onlyPos.Count -gt 0)
} else {
    $sigMismatch = $false
}
$sigIssue = ((-not $sealSheetsUnsigned) -and ($sigMismatch -or $sigMissing))
$mismatchSheets = @()
if ($sigMissing -and -not $sealSheetsUnsigned) {
    foreach ($sheetName in $missingNegSheets) {
        $mismatchSheets += ("NEG: SIGNATUR SAKNAS  [Blad: " + $sheetName + "]")
    }
    foreach ($sheetName in $missingPosSheets) {
        $mismatchSheets += ("POS: SIGNATUR SAKNAS  [Blad: " + $sheetName + "]")
    }
    $missingParts = @()
    if ($missingNegSheets.Count -gt 0) { $missingParts += ("NEG: " + ($missingNegSheets -join ', ')) }
    if ($missingPosSheets.Count -gt 0) { $missingParts += ("POS: " + ($missingPosSheets -join ', ')) }
}
if ($sigMismatch) {
            foreach ($k in $onlyNeg) {
                $raw = if ($negSigSet.RawByNorm.ContainsKey($k)) { $negSigSet.RawByNorm[$k] } else { $k }
                $where = if ($negSigSet.Occ.ContainsKey($k)) { ($negSigSet.Occ[$k] -join ', ') } else { '—' }
                $mismatchSheets += ("NEG: " + $raw + "  [Blad: " + $where + "]")
            }
            foreach ($k in $onlyPos) {
                $raw = if ($posSigSet.RawByNorm.ContainsKey($k)) { $posSigSet.RawByNorm[$k] } else { $k }
                $where = if ($posSigSet.Occ.ContainsKey($k)) { ($posSigSet.Occ[$k] -join ', ') } else { '—' }
                $mismatchSheets += ("POS: " + $raw + "  [Blad: " + $where + "]")
            }
            Gui-Log "⚠️ Avvikelse: Print Full Name, Sign, and Date (NEG vs POS)"
        }
        $signRow = 17 + $maxTesters + 3
        $displaySignNeg = $null; $displaySignPos = $null
if ($negSealSignatureAppliedThisRun -and $signToWrite) {
    $displaySignNeg = $signToWrite
} else {
    $displaySignNeg = if ($negSigSet.RawFirst) { $negSigSet.RawFirst } else { '—' }
}
if ($posSealSignatureAppliedThisRun -and $signToWrite) {
    $displaySignPos = $signToWrite
} else {
    $displaySignPos = if ($posSigSet.RawFirst) { $posSigSet.RawFirst } else { '—' }
}

        $wsOut1.Cells["B$signRow"].Style.Numberformat.Format = '@'
        $wsOut1.Cells["C$signRow"].Style.Numberformat.Format = '@'
        $wsOut1.Cells["B$signRow"].Value = $displaySignNeg
        $wsOut1.Cells["C$signRow"].Value = $displaySignPos

        foreach ($col in @('B','C')) {
            $cell = $wsOut1.Cells["${col}$signRow"]
            Style-Cell $cell $false 'CCFFFF' 'Medium' $null
            $cell.Style.HorizontalAlignment = 'Center'
        }

        try { $wsOut1.Column(2).Width = 40; $wsOut1.Column(3).Width = 40 } catch {}
if ($sigIssue) {
    # === SIGNATURAVVIKELSE: mismatch och/eller saknad signatur ===
    $mismatchCell = $wsOut1.Cells["D$signRow"]
    if ($sigMissing -and $sigMismatch) {
        $mismatchCell.Value = ([char]0x26A0 + ' Mismatch / saknas')
    }
    elseif ($sigMissing) {
        $mismatchCell.Value = ([char]0x26A0 + ' Signatur saknas')
    }
    else {
        $mismatchCell.Value = ([char]0x26A0 + ' Mismatch')
    }
    Style-Cell $mismatchCell $true 'FF0000' 'Medium' 'FFFFFF'

            if ($mismatchSheets.Count -gt 0) {
                # Bygg kompakt detaljtext: en rad per avvikande signatur
                $detailLines = New-Object System.Collections.Generic.List[string]
                foreach ($text in $mismatchSheets) {
                    $filType = ''; $sigVal = ''; $bladVal = ''
                    if ($text -match '^(NEG|POS):\s*(.+?)\s*\[Blad:\s*(.+?)\]$') {
                        $filType = $matches[1]
                        $sigVal  = $matches[2].Trim()
                        $bladVal = $matches[3].Trim()
                        [void]$detailLines.Add("$filType : $sigVal  ($bladVal)")
                    } else {
                        [void]$detailLines.Add($text)
                    }
                }
                $detailRow = $signRow + 1
                $detailText = ($detailLines -join [char]10)
                $detailCell = $wsOut1.Cells["D$detailRow"]
                $detailCell.Value = $detailText
                $detailCell.Style.WrapText = $true
                $detailCell.Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Top
                $detailCell.Style.Font.Size = 9
                $detailCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $detailCell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#FFE699'))
                $detailCell.Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml('#806000'))
                $detailCell.Style.Border.Top.Style    = 'Medium'
                $detailCell.Style.Border.Bottom.Style = 'Medium'
                $detailCell.Style.Border.Left.Style   = 'Medium'
                $detailCell.Style.Border.Right.Style  = 'Medium'

                # Dynamisk radhöjd baserat på antal rader
                try {
                    $lineCount = [Math]::Max(1, $detailLines.Count)
                    $targetHeight = [Math]::Max(20, $lineCount * 16)
                    $wsOut1.Row($detailRow).Height = $targetHeight
                    $wsOut1.Row($detailRow).CustomHeight = $true
                } catch {}
            }
} elseif ($sealSheetsUnsigned) {
    # === INFO: Seal Test-bladen är medvetet/osignerat läge ===
    # Detta är inte en mismatch och ska inte loggas som avvikelse.
    $unsignedCell = $wsOut1.Cells["D$signRow"]
    $unsignedCell.Value = 'Seal Test blad ej signerade'
    Style-Cell $unsignedCell $true 'D9EAF7' 'Medium' '1F4E79'
} else {
    # === MATCH: grön markering endast när signaturer finns och stämmer ===
    if ($hasNeg -and $hasPos -and -not $sigMissing) {
        $matchCell = $wsOut1.Cells["D$signRow"]
        $matchCell.Value = '✓ Match'
        Style-Cell $matchCell $true 'C6EFCE' 'Medium' '006100'
    }
}
