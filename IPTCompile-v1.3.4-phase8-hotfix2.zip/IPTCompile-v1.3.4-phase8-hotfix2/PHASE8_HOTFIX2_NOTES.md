# Phase 8 hotfix 2

Fixed missing worksheet-header helper functions after the phase 8 DataHelpers split.

## Root cause
`Get-WorksheetHeaderPerSheet` and `Extract-WorksheetHeader` were still called from `Main.ps1` but were not moved into the split `Core/HeaderParsing.ps1` file.

## Fix
- restored the original guarded definitions of `Extract-WorksheetHeader`
- restored the original guarded definitions of `Get-WorksheetHeaderPerSheet`
- placed them in `Core/HeaderParsing.ps1`, which is already loaded by the `Modules/DataHelpers.ps1` shim
- bumped `Version.txt` to `1.3.4-phase8-hotfix2`

## Scope
No runtime/UI/event code changed.
