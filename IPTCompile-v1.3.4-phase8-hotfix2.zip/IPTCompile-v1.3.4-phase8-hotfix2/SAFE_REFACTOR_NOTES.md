# SAFE_REFACTOR_NOTES.md

Phase 8 safely splits `Modules/DataHelpers.ps1` behind a shim.

What was actually done:
- Used the working `IPTCompile-v1.3.3-phase7-safe` as the base.
- Extracted only complete, existing function definitions from `Modules/DataHelpers.ps1`.
- Left runtime load behavior intact by keeping `Modules/DataHelpers.ps1` as a shim that dot-sources the new files.
- Did not move any top-level WinForms code or event wiring.

New files:
- `Infrastructure/ExcelEpplus.ps1`
- `Infrastructure/Csv.ps1`
- `Infrastructure/FileStaging.ps1`
- `Core/AssayNormalization.ps1`
- `Core/HeaderParsing.ps1`
- `Core/OutputPlanning.ps1`

Function grouping used:

## Infrastructure/ExcelEpplus.ps1
- Ensure-EPPlus
- Load-EPPlus
- Set-RowBorder
- Style-Cell
- Safe-AutoFitColumns
- Get-SafeCellText
- Get-CellText

## Infrastructure/Csv.ps1
- Get-CsvDelimiter
- Test-IsResampleCsv
- Resolve-CsvPrimaryAndResample
- Get-AssayFromCsv
- Import-CsvRows
- ConvertTo-CsvFields
- Get-CsvStats
- Import-CsvRowsStreaming

## Infrastructure/FileStaging.ps1
- Test-FileLocked
- Test-IsNetworkPath
- Stage-InputFileSnapshot

## Core/AssayNormalization.ps1
- Normalize-Assay
- Normalize-Id
- Normalize-HeaderText
- Is-VlAssay

## Core/HeaderParsing.ps1
- Find-ObservationCol
- Test-IsWorksheetHeaderSkipSheet
- Get-TestSummaryEquipmentFromWorksheet
- Get-TestSummaryEquipment
- Parse-WorksheetHeaderRaw
- Try-Parse-HeaderDate
- Get-ConsensusValue

## Core/OutputPlanning.ps1
- Format-SpPresenceGrandTotalStrict
- Get-InfinitySpFromCsvStrict
- Get-ControlTabName
- Get-MinitabMacro
- Get-OutSheetName
- Get-Threshold
- Is-FeatureEnabled

What was not changed:
- `Main.ps1` runtime flow
- WinForms construction
- Event handlers
- `Application.Run(...)`
- Any other module behavior
