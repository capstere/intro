﻿﻿function Format-SpPresenceGrandTotalStrict {
    param([hashtable]$Counts) 
    if (-not $Counts -or $Counts.Count -eq 0) { return '—' }
    $present = @(
        $Counts.GetEnumerator() |
        Where-Object { $_.Value -gt 0 } |
        ForEach-Object { [int]$_.Key } |
        Sort-Object
    )
    if ($present.Count -eq 0) { return '—' }
    $parts = New-Object System.Collections.Generic.List[string]
    $i = 0
    while ($i -lt $present.Count) {
        $start = $present[$i]; $end = $start
        $j = $i + 1
        while ($j -lt $present.Count -and $present[$j] -eq $end + 1) {
            $end = $present[$j]; $j++
        }
        if ($start -eq $end) { $parts.Add( ('#{0:00}' -f $start) ) }
        else { $parts.Add( ('#{0:00}-{1:00}' -f $start, $end) ) }
        $i = $j
    }
    $total = (
        $Counts.GetEnumerator() |
        Where-Object { $_.Value -gt 0 } |
        Measure-Object -Property Value -Sum
    ).Sum
    return ( ($parts -join '+') + (' x{0}' -f $total) )
}

function Get-InfinitySpFromCsvStrict {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Alias('InfinitySerials')][string[]]$InstrumentSerials,
        [string[]]$Lines
    )
    if (-not $Lines -and -not (Test-Path -LiteralPath $Path)) { return '—' }
    $useConvertFn = $false
    try { $useConvertFn = [bool](Get-Command ConvertTo-CsvFields -ErrorAction Stop) } catch {}
    function Split-CsvSmart([string]$ln) {
        if ($ln -like '*;*' -and $ln -notlike '*,*') {
            return [regex]::Split($ln, ';(?=(?:[^"]*"[^"]*")*[^"]*$)')
        } else {
            return [regex]::Split($ln, ',(?=(?:[^"]*"[^"]*")*[^"]*$)')
        }
    }

    $serSet = New-Object System.Collections.Generic.HashSet[string]([StringComparer]::OrdinalIgnoreCase)
    foreach ($s in ($InstrumentSerials | Where-Object { $_ })) { $null = $serSet.Add( ($s + '').Trim().Trim('"') ) }
    if ($serSet.Count -eq 0) { return '—' } 

    $lines = $Lines
    if (-not $lines) {
        try { $lines = Get-Content -LiteralPath $Path } catch { Gui-Log "⚠️ Kunde inte läsa Infinity SP från CSV: $($_.Exception.Message)" 'Warn'; return '—' }
    }
    if (-not $lines -or $lines.Count -lt 10) { return '—' }

    $headerIndex = 7
    $dataStart   = 9

    $hdr = if ($useConvertFn) { ConvertTo-CsvFields $lines[$headerIndex] } else { Split-CsvSmart $lines[$headerIndex] }
    $colCount = $hdr.Count

    $idxInstr = -1
    for ($i=0; $i -lt $colCount; $i++) {
        $h = (($hdr[$i] + '') -replace '[\uFEFF\u200B]','').Trim().ToLowerInvariant()
        if ($h -match 'instrument' -and ($h -match 's/?n' -or $h -match 'serial')) { $idxInstr = $i; break }
    }
    if ($idxInstr -lt 0) { $idxInstr = 6 }  # G
    $idxSample = 2
    $counts = @{}

    for ($r = $dataStart; $r -lt $lines.Count; $r++) {
        $ln = $lines[$r]; if (-not $ln -or -not $ln.Trim()) { continue }
        $f = if ($useConvertFn) { ConvertTo-CsvFields $ln } else { Split-CsvSmart $ln }
        if ($f.Count -le [Math]::Max($idxInstr,$idxSample)) { continue }

        $instr  = ($f[$idxInstr] + '').Trim().Trim('"')
        if (-not $serSet.Contains($instr)) { continue }  # inte Infinity → skippa

        $sample = ($f[$idxSample] + '').Trim().Trim('"')
        if (-not $sample) { continue }

        $m = [regex]::Match($sample, '_(\d{2})_')
         if ($m.Success) {
             $nRaw = 0
             if ([int]::TryParse($m.Groups[1].Value, [ref]$nRaw)) {

                $sp = $nRaw 
                if ($sp -ge 0 -and $sp -le 10) {
                     if (-not $counts.ContainsKey($sp)) { $counts[$sp] = 0 }
                     $counts[$sp] = [int]$counts[$sp] + 1
                 }
             }
         }
    }

    if ($counts.Count -eq 0) { return '—' }
    return (Format-SpPresenceGrandTotalStrict -Counts $counts)
 }

function Get-ControlTabName {
    param([string]$AssayName)
    $k = Normalize-Assay $AssayName
    if ($k -and $AssayIndex.ContainsKey($k)) { return $AssayIndex[$k] }

    if (Test-Path -LiteralPath $SlangAssayPath) {
        $mapPkg = $null
        try {
            $mapPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($SlangAssayPath))
            $ws = $mapPkg.Workbook.Worksheets['Slang till Assay']; if (-not $ws) { $ws = $mapPkg.Workbook.Worksheets[1] }
            if ($ws -and $ws.Dimension) {
                for ($r=2; $r -le $ws.Dimension.End.Row; $r++){
                    $sheet=$ws.Cells[$r,1].Text.Trim()
                    $aliases=@($ws.Cells[$r,2].Text,$ws.Cells[$r,3].Text,$ws.Cells[$r,4].Text) | Where-Object { $_ -and $_.Trim() }
                    foreach($al in $aliases){ if ($k -and $k -eq (Normalize-Assay $al)) { return $sheet } }
                }
            }
        } catch {
            Gui-Log "Get-ControlTabName: $($_.Exception.Message)" 'Warn'
        } finally {
            if ($mapPkg) {
                try { $mapPkg.Dispose() } catch {}
            }
        }
    }
    return $null
}

function Get-MinitabMacro { param([string]$AssayName)
    if ([string]::IsNullOrWhiteSpace($AssayName)) { return $null }
    $k = Normalize-Assay $AssayName
    if ($k -and $MinitabIndex.ContainsKey($k)) { return $MinitabIndex[$k] }
    return $null
}

function Get-OutSheetName {
    <# Returnerar fliknamn från centrala konstanter. Reservvärde är $Default. #>
    param([Parameter(Mandatory)][string]$Key, [string]$Default = '')
    try {
        if ($global:IPTConstants -and $global:IPTConstants.OutSheetNames.ContainsKey($Key)) {
            return $global:IPTConstants.OutSheetNames[$Key]
        }
    } catch {}
    return $Default
}

function Get-Threshold {
    <# Returnerar tröskelvärde från centrala konstanter. Reservvärde är $Default. #>
    param([Parameter(Mandatory)][string]$Key, $Default = $null)
    try {
        if ($global:IPTConstants -and $global:IPTConstants.Thresholds.ContainsKey($Key)) {
            return $global:IPTConstants.Thresholds[$Key]
        }
    } catch {}
    return $Default
}

function Is-FeatureEnabled {
    <# Kollar funktionsflagga: $Config först, annars IPTConstants, annars $Default. #>
    param([Parameter(Mandatory)][string]$Name, [bool]$Default = $false, [object]$ConfigOverride = $null)
    # Prioritet 1: Config (körning)
    try {
        $val = Get-ConfigFlag -Name $Name -Default $null -ConfigOverride $ConfigOverride
        if ($val -ne $null) { return [bool]$val }
    } catch {}
    # Prioritet 2: IPTConstants (standard vid uppstart)
    try {
        if ($global:IPTConstants -and $global:IPTConstants.FeatureFlags.ContainsKey($Name)) {
            return [bool]$global:IPTConstants.FeatureFlags[$Name]
        }
    } catch {}
    return $Default
}
