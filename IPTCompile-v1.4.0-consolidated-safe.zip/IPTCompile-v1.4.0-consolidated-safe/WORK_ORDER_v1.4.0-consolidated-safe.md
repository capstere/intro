Objective: consolidate `v1.3.7-phase11-safe` by removing obsolete shim-only modules while preserving runtime behavior.

Actions performed:
1. Used `v1.3.7-phase11-safe` as the baseline.
2. Updated `Main.ps1` to load the real split files directly from `App/`, `Core/`, and `Infrastructure/`.
3. Kept only genuine non-shim files in `Modules/`.
4. Removed historical work-order / hotfix note clutter from the project root.
5. Updated `Version.txt` to `1.4.0-consolidated-safe`.

Explicit non-goals:
- No new split of WinForms top-level runtime.
- No movement of event wiring.
- No behavior rewrite.
