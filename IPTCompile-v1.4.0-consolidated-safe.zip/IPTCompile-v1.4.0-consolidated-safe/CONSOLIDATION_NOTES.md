# IPTCompile v1.4.0-consolidated-safe

Base: `v1.3.7-phase11-safe`

What changed:
- `Main.ps1` now dot-sources the real split files directly from `App/`, `Core/`, and `Infrastructure/`.
- Removed obsolete shim-only module files:
  - `Modules/Logging.ps1`
  - `Modules/DataHelpers.ps1`
  - `Modules/SignatureHelpers.ps1`
  - `Modules/OpenXmlHelpers.ps1`
  - `Modules/RuleEngine.ps1`
- Kept non-shim modules in `Modules/`:
  - `Config.ps1`
  - `SharePointClient.ps1`
  - `Splash.ps1`
  - `UiStyling.ps1`
- Removed historical refactor note clutter from the project root to reduce file count/noise.

Why this is a consolidation and not a new risky refactor:
- No event handlers were moved.
- No WinForms top-level runtime blocks were moved.
- No business logic was rewritten.
- Load order was kept equivalent to the previous working shim chain.

Expected benefit:
- Fewer files.
- No double-indirection for the already-split modules.
- Easier to see where code actually lives.
