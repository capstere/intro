﻿@{
    LastUpdated = '2026-04-09'

    Notes = @(
        'Upptäcker du något som är knas eller kan bli bättre?'
        'Skriv på teams eller skicka meddelande under "Instruktioner → Hjälp"'
	'Det är dina idéer och behov som formar verktyget. :) / Jesper'

    )

    Done = @(
        'Uppdaterat så blank header upptäcks'
    )

    Ongoing = @(
        'Bygga Power App för Equipment + CM'
        'Samla feedback'

    )

    TBD = @(
        'Fixa - SharePoint Lists'
        'Dra-och-släpp implementerat för alla filer - KLART - men ej IT-PASS'
    )

}