﻿function Normalize-Assay { param([string]$s)
    if ([string]::IsNullOrWhiteSpace($s)) { return $null }
    $x=$s.ToLowerInvariant(); $x=[regex]::Replace($x,'[^a-z0-9]+',' '); $x=$x.Trim() -replace '\s+',' '; return $x
}

function Normalize-Id {
    param([string]$Value, [ValidateSet('Batch','Part','Cartridge')] [string]$Type)
    if ([string]::IsNullOrWhiteSpace($Value)) { return $null }
    $v = $Value.Trim()
    switch ($Type) {
        'Batch'     { return ($v -replace '[^\d]', '') }                      
        'Part'      { return (($v -replace '[^0-9A-Za-z\-]', '')).ToUpper() } 
        'Cartridge' { return ($v -replace '[^\d]', '') }                      
        default     { return $v }
    }
}

function Normalize-HeaderText {
    param([string]$s)

    if ([string]::IsNullOrWhiteSpace($s)) { return '' }
    $s = $s -replace '(?i)_x000D_', ' '
    $s = $s -replace '(?i)_x000A_', ' '
    $s = $s -replace "[\uFEFF\u200B\u2060]", ""
    $s = $s -replace "[\u00A0\u2007\u202F]", " "
    $s = $s -replace "[\u2013\u2014\u2212]", "-"
    $s = $s -replace '&P', ''
    $s = $s -replace '&N', ''
    $s = $s -replace '&L', ' '
    $s = $s -replace '&C', ' '
    $s = $s -replace '&R', ' '
    $s = ($s -replace "\s+", " ").Trim()
    return $s
}

function Is-VlAssay {
    <# Returnerar $true om assaynamn matchar en VL-analys (skiftlägesokänsligt, delsträng). #>
    param([Parameter(Mandatory)][string]$AssayName)
    $list = @()
    try {
        if ($global:IPTConstants -and $global:IPTConstants.VlAssays) {
            $list = @($global:IPTConstants.VlAssays)
        }
    } catch {}
    if ($list.Count -eq 0) { return $false }
    foreach ($vl in $list) {
        if ($AssayName -imatch [regex]::Escape($vl)) { return $true }
    }
    return $false
}
