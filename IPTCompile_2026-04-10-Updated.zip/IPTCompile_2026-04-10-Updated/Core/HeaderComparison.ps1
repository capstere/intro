﻿# Header compare/parsing block extracted as a unit in phase 8b safe refactor.
# Source: original Modules/DataHelpers.ps1 contiguous block.

if (-not (Get-Command Extract-WorksheetHeader -ErrorAction SilentlyContinue)) {
    function Extract-WorksheetHeader {
        param([object]$Pkg)
        $result = [pscustomobject]@{
            PartNo         = $null
            BatchNo        = $null
            CartridgeNo    = $null
            DocumentNumber = $null
            Attachment     = $null
            Rev            = $null
            Effective      = $null
        }
        if (-not $Pkg) { return $result }
        try {
            foreach ($ws in $Pkg.Workbook.Worksheets) {
                if (-not $ws.Dimension) { continue }
                if (Test-IsWorksheetHeaderSkipSheet -SheetName $ws.Name) { continue }
                $left  = (($ws.HeaderFooter.OddHeader.LeftAlignedText  + '') -replace '\r?\n',' ')
                if (-not $left)  { $left  = (($ws.HeaderFooter.EvenHeader.LeftAlignedText  + '') -replace '\r?\n',' ') }
                $right = (($ws.HeaderFooter.OddHeader.RightAlignedText + '') -replace '\r?\n',' ')
                if (-not $right) { $right = (($ws.HeaderFooter.EvenHeader.RightAlignedText + '') -replace '\r?\n',' ') }
                $raw = (($left + ' ' + $right) + '').Trim()
                if (-not $raw) { continue }
                $parsed = Parse-WorksheetHeaderRaw -Raw $raw
                if (-not $result.PartNo         -and $parsed.PartNo)         { $result.PartNo         = $parsed.PartNo }
                if (-not $result.BatchNo        -and $parsed.BatchNo)        { $result.BatchNo        = $parsed.BatchNo }
                if (-not $result.CartridgeNo    -and $parsed.CartridgeNo)    { $result.CartridgeNo    = $parsed.CartridgeNo }
                if (-not $result.DocumentNumber -and $parsed.DocumentNumber) { $result.DocumentNumber = $parsed.DocumentNumber }
                if (-not $result.Attachment     -and $parsed.Attachment)     { $result.Attachment     = $parsed.Attachment }
                if (-not $result.Rev            -and $parsed.Rev)            { $result.Rev            = $parsed.Rev }
                if (-not $result.Effective      -and $parsed.Effective)      { $result.Effective      = $parsed.Effective }
            }
        } catch { Gui-Log "⚠️ Kunde inte läsa Worksheet-header: $($_.Exception.Message)" 'Warn' }
        if (-not $result.CartridgeNo) {
            foreach ($ws in $Pkg.Workbook.Worksheets) {
                if (-not $ws.Dimension) { continue }
                if (Test-IsWorksheetHeaderSkipSheet -SheetName $ws.Name) { continue }
                $left  = (($ws.HeaderFooter.OddHeader.LeftAlignedText  + '') -replace '\r?\n',' ').Trim()
                $right = (($ws.HeaderFooter.OddHeader.RightAlignedText + '') -replace '\r?\n',' ').Trim()
                $m  = [regex]::Match($left,  '(?<!\d)(\d{5})(?!\d)')
                $m2 = if (-not $m.Success) { [regex]::Match($right,'(?<!\d)(\d{5})(?!\d)') } else { $null }
                if ($m.Success) { $result.CartridgeNo = $m.Groups[1].Value; break }
                if ($m2 -and $m2.Success) { $result.CartridgeNo = $m2.Groups[1].Value; break }
            }
        }
        return $result
    }
}

if (-not (Get-Command Get-WorksheetHeaderPerSheet -ErrorAction SilentlyContinue)) {
    function Get-WorksheetHeaderPerSheet {
        param([object]$Pkg)

        $rxPart      = '(?i)^\s*Part\s*(?:No|Number)\.?\s*(?:\(s\))?\s*$'
        $rxBatch     = '(?i)^\s*Batch\s*(?:No|Number)(?:\s*\(s\))?\.?\s*$'
        $rxCartridge = '(?i)^\s*Cartridge\s*(?:No|Number)?\s*(?:\(?LSP\)?)?\.?\s*$'
        $rxDoc       = '(?i)^\s*Document\s*(?:No|Number|#)\s*$'
        $rxRev       = '(?i)^\s*Rev(?:ision)?\.?\s*$'
        $rxEff       = '(?i)^\s*Effective(?:\s*Date)?\s*$'
        function Get-HeaderFooterText([Object]$ws) {
            $left  = Normalize-HeaderText ((($ws.HeaderFooter.OddHeader.LeftAlignedText  + '') -replace '\r?\n',' '))
            if (-not $left)  { $left  = Normalize-HeaderText ((($ws.HeaderFooter.EvenHeader.LeftAlignedText  + '') -replace '\r?\n',' ')) }
            $right = Normalize-HeaderText ((($ws.HeaderFooter.OddHeader.RightAlignedText + '') -replace '\r?\n',' '))
            if (-not $right) { $right = Normalize-HeaderText ((($ws.HeaderFooter.EvenHeader.RightAlignedText + '') -replace '\r?\n',' ')) }
            return @($left,$right)
        }

        function Try-FromHeaderFooter([string[]]$lr, [string]$kind) {
            $left,$right = $lr
            $raw = (($left + ' ' + $right) + '').Trim()
            if (-not $raw) {
                return @{ Has = $false; Val = $null }
            }
            $parsed = Parse-WorksheetHeaderRaw -Raw $raw
            $has = $false
            $val = $null

            switch ($kind) {
                'Part' {
                    $has = ($raw -match '(?i)\bPart\b')
                    $val = $parsed.PartNo
                }
                'Batch' {
                    $has = ($raw -match '(?i)\bBatch\b')
                    $val = $parsed.BatchNo
                }
                'Cartridge' {
                    $has = ($raw -match '(?i)\bCartridge\b')
                    $val = $parsed.CartridgeNo
                }
                'Doc' {
                    $has = ($raw -match '(?i)Document\s*Number')
                    $val = $parsed.DocumentNumber
                }
                'REV' {
                    $has = ($raw -match '(?i)\bRev(?:ision)?\b')
                    $val = $parsed.Rev
                }
                'EFF' {
                    $has = ($raw -match '(?i)\bEffective(\s*Date)?\b')
                    $val = $parsed.Effective
                }
            }
            return @{ Has = [bool]$has; Val = $val }
        }

        function Try-FromCells([Object]$ws, [string]$rxLabel, [int]$maxR=30, [int]$maxC=20, [string]$canon='') {
            $has=$false; $val=$null
            for($r=1;$r -le $maxR;$r++){
                for($c=1;$c -le $maxC;$c++){
                    $t     = Normalize-HeaderText (""+$ws.Cells[$r,$c].Text)
                    if([string]::IsNullOrWhiteSpace($t)){ continue }
                    if($t -match $rxLabel){
                        $has=$true
$right = Normalize-HeaderText (""+$ws.Cells[$r,[Math]::Min($c+1,$maxC)].Text)
$down  = Normalize-HeaderText (""+$ws.Cells[[Math]::Min($r+1,$maxR),$c].Text)
                        $val = if($right){$right}elseif($down){$down}else{''}
                        if($canon -eq 'Cartridge' -and $val){
                            $m=[regex]::Match($val,'(?<!\d)(\d{5})(?!\d)'); if($m.Success){$val=$m.Groups[1].Value}
                        }
                        elseif ($canon -eq 'EFF' -and $val) {
                            $dt = $null
                            if (Try-Parse-HeaderDate $val ([ref]$dt)) { $val = $dt.ToString('yyyy-MM-dd') }
                        }
                        return @{Has=$has; Val=$val}
                    }
                }
            }
            return @{Has=$has; Val=$val}
        }
        $rows = New-Object System.Collections.Generic.List[object]
        if(-not $Pkg){ return @() }

foreach ($ws in $Pkg.Workbook.Worksheets) {
    if (Test-IsWorksheetHeaderSkipSheet -SheetName $ws.Name) {
        continue
    }

            $partLabel=$false; $batchLabel=$false; $cartLabel=$false; $docLabel=$false; $revLabel=$false; $effLabel=$false
            $part=$null; $batch=$null; $cart=$null; $doc=$null; $rev=$null; $eff=$null
            $lr = Get-HeaderFooterText $ws
            $r1 = Try-FromHeaderFooter $lr 'Part';      $partLabel=$partLabel -or $r1.Has; if($r1.Val){$part=$r1.Val}
            $r2 = Try-FromHeaderFooter $lr 'Batch';     $batchLabel=$batchLabel -or $r2.Has; if($r2.Val){$batch=$r2.Val}
            $r3 = Try-FromHeaderFooter $lr 'Cartridge'; $cartLabel=$cartLabel -or $r3.Has; if($r3.Val){$cart=$r3.Val}
            $r4 = Try-FromHeaderFooter $lr 'Doc';       $docLabel=$docLabel -or $r4.Has; if($r4.Val){$doc=$r4.Val}
            $r5 = Try-FromHeaderFooter $lr 'REV';       $revLabel=$revLabel -or $r5.Has; if($r5.Val){$rev=$r5.Val}
            $r6 = Try-FromHeaderFooter $lr 'EFF';       $effLabel=$effLabel -or $r6.Has; if($r6.Val){$eff=$r6.Val}
            if(-not $part){  $c=Try-FromCells $ws $rxPart      30 20 'Part';      $partLabel=$partLabel -or $c.Has; if($c.Val){$part=$c.Val} }
            if(-not $batch){ $c=Try-FromCells $ws $rxBatch     30 20 'Batch';     $batchLabel=$batchLabel -or $c.Has; if($c.Val){$batch=$c.Val} }
            if(-not $cart){  $c=Try-FromCells $ws $rxCartridge 30 20 'Cartridge'; $cartLabel=$cartLabel -or $c.Has; if($c.Val){$cart=$c.Val} }
            if(-not $doc){   $c=Try-FromCells $ws $rxDoc       30 20;             $docLabel=$docLabel -or $c.Has; if($c.Val){$doc=$c.Val} }
            if(-not $rev){   $c=Try-FromCells $ws $rxRev       30 20;             $revLabel=$revLabel -or $c.Has; if($c.Val){$rev=$c.Val} }
            if(-not $eff){   $c=Try-FromCells $ws $rxEff       30 20 'EFF';       $effLabel=$effLabel -or $c.Has; if($c.Val){$eff=$c.Val} }
            [void]$rows.Add([pscustomobject]@{
                Sheet              = $ws.Name
                PartNo             = $part
                BatchNo            = $batch
                CartridgeNo        = $cart
                DocumentNumber     = $doc
                Rev                = $rev
                Effective          = $eff
                HasPartNoLabel     = [bool]$partLabel
                HasBatchNoLabel    = [bool]$batchLabel
                HasCartridgeLabel  = [bool]$cartLabel
                HasDocumentLabel   = [bool]$docLabel
                HasRevLabel        = [bool]$revLabel
                HasEffectiveLabel  = [bool]$effLabel
            })
        }
        return @($rows.ToArray())
    }
}

function Get-TestSummaryEquipmentFromWorksheet {
    param(
        [object]$Worksheet
    )

    $result = [pscustomobject]@{
        WorksheetName = $null
        Pipettes      = @()
        Instruments   = @()
    }

    if (-not $Worksheet -or -not $Worksheet.Dimension) {
        return $result
    }

    $result.WorksheetName = $Worksheet.Name

    $maxR = $Worksheet.Dimension.End.Row
    $maxC = $Worksheet.Dimension.End.Column
    $maxR = [Math]::Min($maxR, 350)
    $maxC = [Math]::Min($maxC, 40)
    $getCellText = {
        param(
            $Ws,
            [int]$Row,
            [int]$Col
        )
        if ($Row -le 0 -or $Col -le 0) { return '' }
        if (-not $Ws.Dimension) { return '' }
        $t = $Ws.Cells[$Row,$Col].Text
        if ($t) { return $t.Trim() }
        return ''
    }
    $excelDateBase = Get-Date '1899-12-30'
    $resolveDueCellValue = {
        param($Cell)

        if (-not $Cell) { return $null }

        $dueVal = $Cell.Value
        if ($dueVal -is [datetime]) {
            return $dueVal
        }

        if ($dueVal -is [double] -or $dueVal -is [int]) {
            try {
                return $excelDateBase.AddDays([double]$dueVal)
            } catch {
                $fallback = ($Cell.Text + '').Trim()
                if ($fallback) { return $fallback }
                return $null
            }
        }

        $txt = ($Cell.Text + '').Trim()
        if ($txt) { return $txt }
        return $null
    }
    $dedupeEquipmentById = {
        param([object[]]$Items)

        if (-not $Items -or $Items.Count -eq 0) { return @() }

        $uniq = New-Object System.Collections.Generic.List[object]
        $seen = @{}
        foreach ($item in $Items) {
            if (-not $item -or -not $item.Id) { continue }
            if ($seen.ContainsKey($item.Id)) { continue }
            $seen[$item.Id] = $true
            [void]$uniq.Add($item)
        }
        return @($uniq.ToArray())
    }

    $pipHeaderRows = New-Object 'System.Collections.Generic.List[int]'
    for ($r = 1; $r -le $maxR; $r++) {
        $txt = & $getCellText $Worksheet $r 1
        if (-not $txt) { continue }

        if ($txt -match '(?i)table\s*2\b.*pipett(e)?\b') {
            [void]$pipHeaderRows.Add($r)
        }
    }

    $pipPairs = New-Object System.Collections.Generic.List[object]

    foreach ($hdrRow in $pipHeaderRows) {
        $searchMax = [Math]::Min($maxR, $hdrRow + 12)

        for ($r = $hdrRow + 1; $r -le $searchMax; $r++) {
            $label = & $getCellText $Worksheet $r 1
            if ($label -match '(?i)cepheid\s*id') {

                $calRow = $null
                for ($cRow = $r + 1; $cRow -le [Math]::Min($maxR, $r + 6); $cRow++) {
                    $lab2 = & $getCellText $Worksheet $cRow 1
                    if ($lab2 -match '(?i)calibration\s+due\s+date') {
                        $calRow = $cRow
                        break
                    }
                }

                if ($calRow) {
                    [void]$pipPairs.Add([pscustomobject]@{
                        IdRow  = $r
                        CalRow = $calRow
                    })
                }
            }
        }
    }

    $pipettes = New-Object System.Collections.Generic.List[object]

    $pipetteIdRegex = '(?i)\b(?:nr|no)\.?\s*\d+\b'

    foreach ($pair in $pipPairs) {
        for ($c = 2; $c -le $maxC; $c += 2) {
            $idTxt = & $getCellText $Worksheet $pair.IdRow $c
            if (-not $idTxt) { continue }

            if ($idTxt -match '^(?i)N/?A$') { continue }
            if ($idTxt -notmatch $pipetteIdRegex) { continue }

            $dueOut = & $resolveDueCellValue $Worksheet.Cells[$pair.CalRow,$c]

            [void]$pipettes.Add([pscustomobject]@{
                Id                 = $idTxt
                CalibrationDueDate = $dueOut
            })
        }
    }

    $pipettes = & $dedupeEquipmentById $pipettes.ToArray()

    $result.Pipettes = $pipettes

    $instHeaderRows = New-Object 'System.Collections.Generic.List[int]'
    for ($r = 1; $r -le $maxR; $r++) {
        $txt = & $getCellText $Worksheet $r 1
        if (-not $txt) { continue }
        if ($txt -match '(?i)table\s*3\b.*(gene\s*experts?|genexperts?|genex?perts?|infinitys?)') {
            [void]$instHeaderRows.Add($r)
        }
    }

    $instPairs = New-Object System.Collections.Generic.List[object]

    foreach ($hdrRow in $instHeaderRows) {
        $searchMax = [Math]::Min($maxR, $hdrRow + 20)

        for ($r = $hdrRow + 1; $r -le $searchMax; $r++) {
            $label = & $getCellText $Worksheet $r 1
            if ($label -match '(?i)cepheid\s*id') {

                $calRow = $null
                for ($cRow = $r + 1; $cRow -le [Math]::Min($maxR, $r + 6); $cRow++) {
                    $lab2 = & $getCellText $Worksheet $cRow 1
                    if ($lab2 -match '(?i)calibration\s+due\s+date') {
                        $calRow = $cRow
                        break
                    }
                }

                if ($calRow) {
                    [void]$instPairs.Add([pscustomobject]@{
                        IdRow  = $r
                        CalRow = $calRow
                    })
                }
            }
        }
    }

    $insts = New-Object System.Collections.Generic.List[object]

    foreach ($pair in $instPairs) {
        for ($c = 2; $c -le $maxC; $c += 2) {
            $idTxt = & $getCellText $Worksheet $pair.IdRow $c
            if (-not $idTxt) { continue }
            if ($idTxt -match '^(?i)N/?A$') { continue }

            if ($idTxt -notmatch '(?i)^(infinity|gx\s*\d+|gx\d+)') {
                continue
            }

            $dueOut = & $resolveDueCellValue $Worksheet.Cells[$pair.CalRow,$c]

            [void]$insts.Add([pscustomobject]@{
                Id                 = $idTxt
                CalibrationDueDate = $dueOut
            })
        }
    }

    $insts = & $dedupeEquipmentById $insts.ToArray()

    $result.Instruments = $insts

    return $result
}

function Get-TestSummaryEquipment {
    param(
        [object]$Pkg
    )

    $empty = [pscustomobject]@{
        WorksheetName = $null
        Pipettes      = @()
        Instruments   = @()
    }

    if (-not $Pkg) { return $empty }

    $best = $null

    try {
        foreach ($ws in $Pkg.Workbook.Worksheets) {
            if (-not $ws.Dimension) { continue }
            if ($ws.Name -match '(?i)worksheet\s*instructions') { continue }

            $info = Get-TestSummaryEquipmentFromWorksheet -Worksheet $ws
            if (-not $info) { continue }

            $pipCount  = if ($info.Pipettes)   { $info.Pipettes.Count }   else { 0 }
            $instCount = if ($info.Instruments){ $info.Instruments.Count } else { 0 }

            if (-not $best) { $best = $info }

            if ($pipCount -gt 0 -or $instCount -gt 0) {
                if ($ws.Name -match '(?i)test\s*summary') {
                    return $info
                }
                $best = $info
            }
        }
    } catch {
        return $empty
    }

    if ($best) { return $best }
    return $empty
}

if (-not (Get-Command Compare-WorksheetHeaderSet -ErrorAction SilentlyContinue)) {
    function Compare-WorksheetHeaderSet {
        param([Parameter(Mandatory)][object[]]$Rows)

        $devIssues  = 0
        $reqIssues  = 0
        $detailsLst = New-Object System.Collections.Generic.List[string]

function _canonWorksheet([string]$raw, [string]$type) {
    if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
    $txt = Normalize-HeaderText $raw
            switch ($type) {
                'Part'      { $m=[regex]::Match($txt,'(?i)\b(\d{3}-\d{4})\b'); return $(if($m.Success){$m.Groups[1].Value}else{$txt.ToUpper()}) }
                'Batch'     { $m=[regex]::Match($txt,'(?<!\d)(\d{10})(?!\d)');  return $(if($m.Success){$m.Groups[1].Value}else{$txt.ToUpper()}) }
                'Cartridge' { $m=[regex]::Match($txt,'(?<!\d)(\d{5})(?!\d)');   return $(if($m.Success){$m.Groups[1].Value}else{$txt.ToUpper()}) }
                'Doc'       { $m=[regex]::Match($txt,'(?i)\b(D\d+)\b');         return $(if($m.Success){$m.Groups[1].Value.ToUpper()}else{$txt.ToUpper()}) }
                'REV'       { return $txt.ToUpper() }
                'EFF' {
    $dt = $null
    if (Try-Parse-HeaderDate $txt ([ref]$dt)) { return $dt.ToString('yyyy-MM-dd') }
    return $txt
}
                default     { return $txt }
            }
        }
        $keys = @(

            @{K='PartNo';         T='Part';      Required=$true;  Label='HasPartNoLabel'    },
            @{K='BatchNo';        T='Batch';     Required=$true;  Label='HasBatchNoLabel'   },
            @{K='CartridgeNo';    T='Cartridge'; Required=$true;  Label='HasCartridgeLabel' },
            @{K='DocumentNumber'; T='Doc';       Required=$false; Label='HasDocumentLabel'  },
            @{K='Rev';            T='REV';       Required=$false; Label='HasRevLabel'       },
            @{K='Effective';      T='EFF';       Required=$false; Label='HasEffectiveLabel' }
        )

        foreach ($entry in $keys) {
            $k=$entry.K; $t=$entry.T; $req=$entry.Required; $labelProp=$entry.Label
            $vals = foreach($r in $Rows){
                [pscustomobject]@{
                    Sheet  = $r.Sheet
                    Canon  = _canonWorksheet ($r.$k) $t
                    Raw    = if([string]::IsNullOrWhiteSpace($r.$k)){ $null } else { $r.$k.Trim() }
                    HasLbl = [bool]($r.$labelProp)
                }
            }
            $nonEmpty = @($vals | Where-Object { $_.Canon })
            $useSet   = if(@($nonEmpty).Count -gt 0){$nonEmpty}else{$vals}
            $byVal    = @($useSet | Group-Object Canon | Sort-Object Count -Descending)
            $major    = if(@($byVal).Count -gt 0){ $byVal[0].Name } else { $null }
            $deviants = @()
            if($major){
                $deviants = @($vals | Where-Object { $_.Canon -and ($_.Canon -ne $major) } | Select-Object -ExpandProperty Sheet -Unique)
            }

            if(@($deviants).Count -gt 0){
                $devIssues++
                $majShow = if($major){"'$major'"}else{'(empty)'}
                $line = "- $k majoritet=$majShow | avvikande flikar: " + ($deviants -join ', ')
                [void]$detailsLst.Add($line)
            }

            if($req){
                $missingSheets = @($vals | Where-Object { $_.HasLbl -and -not $_.Canon } | Select-Object -ExpandProperty Sheet -Unique)
                if(@($missingSheets).Count -gt 0){
                    $reqIssues++
                    $line = "*Saknas* - $k " + ($missingSheets -join ', ')
                    [void]$detailsLst.Add($line)
                }
            }
        }
        $issuesTotal = $devIssues + $reqIssues
        $summary = if($issuesTotal -eq 0){ 'OK' } else { "Avvikelser: $issuesTotal (avvikare=$devIssues, saknas=$reqIssues)" }

        return [pscustomobject]@{
            Issues  = $issuesTotal
            Summary = $summary
            Details = ($detailsLst -join "`r`n")
        }
    }
}

if (-not (Get-Command Get-SealTestHeaderPerSheet -ErrorAction SilentlyContinue)) {
    function Get-SealTestHeaderPerSheet {
        param([object]$Pkg)

        $rows = New-Object System.Collections.Generic.List[object]
        if (-not $Pkg) { return @() }

        $rxDoc = '(?i)^\s*Document\s*(?:No|Number|#)\s*$'
        $rxRev = '(?i)^\s*Rev(?:ision)?\.?\s*$'
        $rxEff = '(?i)^\s*Effective(?:\s*Date)?\s*$'

        function _getRightHeader([object]$ws) {
            $right = (($ws.HeaderFooter.OddHeader.RightAlignedText + '') -replace '\r?\n',' ').Trim()
            if (-not $right) { $right = (($ws.HeaderFooter.EvenHeader.RightAlignedText + '') -replace '\r?\n',' ').Trim() }
            return (Normalize-HeaderText $right)
        }

        function _tryFromCells([object]$ws, [string]$rxLabel, [int]$maxR=30, [int]$maxC=20, [string]$canon='') {
            $has=$false; $val=$null; $displayVal=$null
            for($r=1;$r -le $maxR;$r++){
                for($c=1;$c -le $maxC;$c++){
                    $t = Normalize-HeaderText (""+$ws.Cells[$r,$c].Text)
                    if([string]::IsNullOrWhiteSpace($t)){ continue }
                    if($t -match $rxLabel){
                        $has=$true
                        $right = Normalize-HeaderText (""+$ws.Cells[$r,[Math]::Min($c+1,$maxC)].Text)
                        $down  = Normalize-HeaderText (""+$ws.Cells[[Math]::Min($r+1,$maxR),$c].Text)
                        $val = if($right){$right}elseif($down){$down}else{''}
                        $displayVal = $val

                        if($canon -eq 'Doc' -and $val){
                            $m=[regex]::Match($val,'(?i)\b(D\d+)\b'); if($m.Success){$val=$m.Groups[1].Value.ToUpper()}
                        }
                        elseif($canon -eq 'EFF' -and $val){
                            $dt=$null
                            if(Try-Parse-HeaderDate $val ([ref]$dt)) { $val = $dt.ToString('yyyy-MM-dd') }
                        }
                        elseif($canon -eq 'REV' -and $val){
                            $val = (Normalize-HeaderText $val).ToUpper()
                        }

                        return @{Has=$has; Val=$val; DisplayVal=$displayVal}
                    }
                }
            }
            return @{Has=$has; Val=$val; DisplayVal=$displayVal}
        }

        foreach ($ws in $Pkg.Workbook.Worksheets) {
            if ($ws.Name -eq 'Worksheet Instructions' -or $ws.Name -match '(?i)for reference only') { continue }

            $doc=$null; $rev=$null; $eff=$null; $effDisplay=$null
            $docLbl=$false; $revLbl=$false; $effLbl=$false

            $right = _getRightHeader $ws

            if ($right) {
                if ($right -match '(?i)\bDocument\s*(?:No|Number|#)\s*[:#]?\s*(D\d+)\b') { $doc = $matches[1].ToUpper() }
                if ($right -match '(?i)\bRev(?:ision)?\.?\s*[:#]?\s*([A-Z]{1,3}(?:\.\d+)?)\b') { $rev = $matches[1].ToUpper() }
                if ($right -match '(?i)\bEffective\s*[:#]?\s*([0-9]{1,2}[\/\-][0-9]{1,2}[\/\-][0-9]{4}|[0-9]{4}[\/\-][0-9]{2}[\/\-][0-9]{2})') {
                    $val = $matches[1]
                    $effDisplay = $val
                    $dt=$null
                    if (Try-Parse-HeaderDate $val ([ref]$dt)) { $eff = $dt.ToString('yyyy-MM-dd') } else { $eff = $val }
                }
            }

            # Cellfallback (för mallar utan högerheader)
            if (-not $doc) { $c=_tryFromCells $ws $rxDoc 30 20 'Doc'; $docLbl=$docLbl -or $c.Has; if($c.Val){$doc=$c.Val} }
            if (-not $rev) { $c=_tryFromCells $ws $rxRev 30 20 'REV'; $revLbl=$revLbl -or $c.Has; if($c.Val){$rev=$c.Val} }
            if (-not $eff) {
                $c=_tryFromCells $ws $rxEff 30 20 'EFF'
                $effLbl=$effLbl -or $c.Has
                if($c.Val){$eff=$c.Val}
                if($c.DisplayVal){$effDisplay=$c.DisplayVal}
            }

            [void]$rows.Add([pscustomobject]@{
                Sheet            = $ws.Name
                DocumentNumber   = $doc
                Rev              = $rev
                Effective        = $eff
                EffectiveDisplay = $effDisplay
                HasDocumentLabel = [bool]$docLbl
                HasRevLabel      = [bool]$revLbl
                HasEffectiveLabel= [bool]$effLbl
            })
        }
        return @($rows.ToArray())
    }
}

if (-not (Get-Command Compare-SealTestHeaderSet -ErrorAction SilentlyContinue)) {
    function Compare-SealTestHeaderSet {
        param([Parameter(Mandatory)][object[]]$Rows)

        $devIssues  = 0
        $detailsLst = New-Object System.Collections.Generic.List[string]

        function _canonSealHeader([string]$raw, [string]$type) {
            if ([string]::IsNullOrWhiteSpace($raw)) { return $null }
            $txt = Normalize-HeaderText $raw
            switch ($type) {
                'Doc' { $m=[regex]::Match($txt,'(?i)\b(D\d+)\b'); return $(if($m.Success){$m.Groups[1].Value.ToUpper()}else{$txt.ToUpper()}) }
                'REV' { return $txt.ToUpper() }
                'EFF' {
                    $dt = $null
                    if (Try-Parse-HeaderDate $txt ([ref]$dt)) { return $dt.ToString('yyyy-MM-dd') }
                    return $txt
                }
                default { return $txt }
            }
        }

        $keys = @(
            @{K='DocumentNumber'; T='Doc' },
            @{K='Rev';            T='REV' },
            @{K='Effective';      T='EFF' }
        )

        foreach ($entry in $keys) {
            $k=$entry.K; $t=$entry.T
            $vals = foreach($r in $Rows){
                [pscustomobject]@{
                    Sheet = $r.Sheet
                    Canon = _canonSealHeader ($r.$k) $t
                }
            }
            $nonEmpty = @($vals | Where-Object { $_.Canon })
            $useSet   = if(@($nonEmpty).Count -gt 0){$nonEmpty}else{$vals}
            $byVal    = @($useSet | Group-Object Canon | Sort-Object Count -Descending)
            $major    = if(@($byVal).Count -gt 0){ $byVal[0].Name } else { $null }
            $deviants = @()
            if($major){
                $deviants = @($vals | Where-Object { $_.Canon -and ($_.Canon -ne $major) } | Select-Object -ExpandProperty Sheet -Unique)
            }
            if(@($deviants).Count -gt 0){
                $devIssues++
                $majShow = if($major){"'$major'"}else{'(empty)'}
                $detailsLst.Add(("- {0} majoritet={1} | avvikande flikar: {2}" -f $k,$majShow,($deviants -join ', ')))
            }
        }

        $summary = if($devIssues -eq 0){ '✓ Alla flikar matchar' } else { ('⚠ {0} fält avviker mellan flikar' -f $devIssues) }

        return [pscustomobject]@{
            Deviations = $devIssues
            Summary    = $summary
            Details    = ($detailsLst -join "`r`n")
        }
    }
}

if (-not (Get-Command Extract-SealTestHeader -ErrorAction SilentlyContinue)) {
    function Extract-SealTestHeader {
        param([object]$Pkg)

        $result = [pscustomobject]@{
            DocumentNumber = $null
            Rev            = $null
            Effective      = $null
            EffectiveDisplay = $null
            PartNumber     = $null
            BatchNumber    = $null
            CartridgeNo    = $null
            HeaderCheck    = $null
            PerSheet       = @()
        }

        if (-not $Pkg) { return $result }

        $rows = @()
        try { $rows = Get-SealTestHeaderPerSheet -Pkg $Pkg } catch { $rows = @() }
        if ($rows) {
            $result.PerSheet = $rows
            try { $result.HeaderCheck = Compare-SealTestHeaderSet -Rows $rows } catch { $result.HeaderCheck = $null }

            function _pickMajor([object[]]$rws, [string]$prop) {
                $vals = @($rws | ForEach-Object { $_.$prop } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
                if (-not $vals -or $vals.Count -eq 0) { return $null }
                $g = $vals | Group-Object | Sort-Object Count -Descending
                return $g[0].Name
            }

            $result.DocumentNumber = _pickMajor $rows 'DocumentNumber'
            $result.Rev            = _pickMajor $rows 'Rev'
            $result.Effective      = _pickMajor $rows 'Effective'
            $result.EffectiveDisplay = _pickMajor $rows 'EffectiveDisplay'
            return $result
        }

        # Reservväg: äldre logik (om per blad misslyckas helt)
        foreach ($ws in $Pkg.Workbook.Worksheets) {
            if ($ws.Name -eq 'Worksheet Instructions') { continue }
            $right = (($ws.HeaderFooter.OddHeader.RightAlignedText + '') -replace '\r?\n',' ').Trim()
            if (-not $right) { $right = (($ws.HeaderFooter.EvenHeader.RightAlignedText + '') -replace '\r?\n',' ').Trim() }
            if (-not $result.DocumentNumber -and $right -match '(?i)\bDocument\s*(?:No|Number|#)\s*[:#]?\s*(D\d+)\b') { $result.DocumentNumber = $matches[1] }
            if (-not $result.Rev            -and $right -match '(?i)\bRev(?:ision)?\.?\s*[:#]?\s*([A-Z]{1,3}(?:\.\d+)?)\b') { $result.Rev = $matches[1] }
            if (-not $result.Effective      -and $right -match '(?i)\bEffective\s*[:#]?\s*([0-9]{1,2}[\/\-][0-9]{1,2}[\/\-][0-9]{4}|[0-9]{4}[\/\-][0-9]{2}[\/\-][0-9]{2})') { $result.Effective = $matches[1] }
            if ($result.DocumentNumber -and $result.Rev -and $result.Effective) { break }
        }
        return $result
    }
}

function Normalize-Id {
    param([string]$Value, [ValidateSet('Batch','Part','Cartridge')] [string]$Type)
    if ([string]::IsNullOrWhiteSpace($Value)) { return $null }
    $v = $Value.Trim()
    switch ($Type) {
        'Batch'     { return ($v -replace '[^\d]', '') }                      
        'Part'      { return (($v -replace '[^0-9A-Za-z\-]', '')).ToUpper() } 
        'Cartridge' { return ($v -replace '[^\d]', '') }                      
        default     { return $v }
    }
}

function Normalize-HeaderText {
    param([string]$s)

    if ([string]::IsNullOrWhiteSpace($s)) { return '' }
    $s = $s -replace '(?i)_x000D_', ' '
    $s = $s -replace '(?i)_x000A_', ' '
    $s = $s -replace "[\uFEFF\u200B\u2060]", ""
    $s = $s -replace "[\u00A0\u2007\u202F]", " "
    $s = $s -replace "[\u2013\u2014\u2212]", "-"
    $s = $s -replace '&P', ''
    $s = $s -replace '&N', ''
    $s = $s -replace '&L', ' '
    $s = $s -replace '&C', ' '
    $s = $s -replace '&R', ' '
    $s = ($s -replace "\s+", " ").Trim()
    return $s
}
