﻿function Get-CsvTextLines {
    <#
        Läser GeneXpert Test Summary-filer BOM-medvetet.
        Behövs för nya exporter där filen kan vara UTF-8 BOM/UTF-16 och där Get-Content -Encoding Default
        annars kan ge fel header/data i Windows PowerShell 5.1.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$TotalCount = 0
    )

    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    try {
        $bytes = [System.IO.File]::ReadAllBytes($Path)
        if (-not $bytes -or $bytes.Length -eq 0) { return @() }

        $offset = 0
        $enc = [System.Text.Encoding]::Default

        if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
            $enc = New-Object System.Text.UTF8Encoding($false, $true)
            $offset = 3
        } elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
            $enc = [System.Text.Encoding]::Unicode
            $offset = 2
        } elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF) {
            $enc = [System.Text.Encoding]::BigEndianUnicode
            $offset = 2
        }

        $text = $enc.GetString($bytes, $offset, ($bytes.Length - $offset))
        $text = $text -replace "`r`n", "`n"
        $text = $text -replace "`r", "`n"
        $arr = @($text -split "`n", -1)
        if ($arr.Count -gt 0 -and $arr[$arr.Count-1] -eq '') { $arr = @($arr[0..($arr.Count-2)]) }
        if ($TotalCount -gt 0 -and $arr.Count -gt $TotalCount) { return @($arr[0..($TotalCount-1)]) }
        return @($arr)
    } catch {
        try { Gui-Log "⚠️ Kunde inte läsa CSV text: $($_.Exception.Message)" 'Warn' } catch {}
        return @()
    }
}

function Normalize-CsvPhysicalLine {
    param([AllowNull()][string]$Line)
    if ($null -eq $Line) { return '' }
    $s = ($Line + '') -replace "^\uFEFF", ''
    $t = $s.Trim()

    # Ny GeneXpert-export kan lägga en hel logisk CSV-rad som ett enda citerat fält:
    # "Assay,Assay Version,Sample ID,..."
    # Då måste yttre citattecken bort innan vanlig CSV-split, annars blir raden 1 kolumn.
    if ($t.Length -ge 2 -and $t.Substring(0,1) -eq '"' -and $t.Substring($t.Length-1,1) -eq '"') {
        $inner = $t.Substring(1, $t.Length - 2)
        if (($inner -notmatch '"') -and (($inner -like '*,*') -or ($inner -like "*`t*") -or ($inner -like '*;*'))) {
            return $inner
        }
    }
    return $s
}

function ConvertTo-CsvFields {
    param(
        [Parameter(Mandatory=$true)][AllowEmptyString()][string]$Line,
        [string]$Delimiter
    )
    if ($null -eq $Line) { return @() }

    $line2 = Normalize-CsvPhysicalLine -Line $Line

    $del = $Delimiter
    if ([string]::IsNullOrWhiteSpace($del)) {
        $cSemi  = ([regex]::Matches($line2, ';')).Count
        $cComma = ([regex]::Matches($line2, ',')).Count
        $cTab   = ([regex]::Matches($line2, "`t")).Count
        if ($cTab -gt 0 -and $cComma -gt 0) { $del = 'TABCOMMA' }
        elseif ($cTab -gt $cComma -and $cTab -gt $cSemi) { $del = "`t" }
        elseif ($cSemi -gt $cComma) { $del = ';' }
        else { $del = ',' }
    }

    if ($del -eq 'TABCOMMA') {
        $rx = '(?:,|\t)(?=(?:(?:[^"]*"){2})*[^"]*$)'
    } else {
        $d  = [regex]::Escape($del)
        $rx = $d + '(?=(?:(?:[^"]*"){2})*[^"]*$)'
    }

    $arr = [regex]::Split($line2, $rx)
    return ,@($arr | ForEach-Object { (($_ + '') -replace '^"|"$','').Trim() })
}

function Get-CsvDelimiter {
    param([string]$Path)
    try {
        $lines = @(Get-CsvTextLines -Path $Path -TotalCount 40)
        if (-not $lines -or $lines.Count -eq 0) { return ',' }

        $bestComma = 0; $bestSemi = 0; $bestTab = 0
        foreach ($ln0 in $lines) {
            if (-not $ln0 -or -not $ln0.Trim()) { continue }
            $ln = Normalize-CsvPhysicalLine -Line $ln0
            $bestComma = [Math]::Max($bestComma, ([regex]::Matches($ln, ',')).Count)
            $bestSemi  = [Math]::Max($bestSemi,  ([regex]::Matches($ln, ';')).Count)
            $bestTab   = [Math]::Max($bestTab,   ([regex]::Matches($ln, "`t")).Count)
        }

        if ($bestTab -gt 0 -and $bestComma -gt 0) { return 'TABCOMMA' }
        if ($bestTab -gt $bestComma -and $bestTab -gt $bestSemi) { return "`t" }
        if ($bestSemi -gt $bestComma -and $bestSemi -ge 2) { return ';' }
        return ','
    } catch {
        try { Gui-Log "⚠️ Get-CsvDelimiter misslyckades: $($_.Exception.Message)" 'Warn' } catch {}
        return ','
    }
}

function Get-TestSummaryCsvLayout {
    <#
        Hittar faktisk header och datastart i GeneXpert Test Summary.
        Stödjer både gammal layout (header rad 8/data rad 10) och ny export
        (hel rad citerad, header rad 9/data rad 11).
    #>
    [CmdletBinding()]
    param(
        [string]$Path,
        [string[]]$Lines
    )

    $lines = @($Lines)
    if ($lines.Count -eq 1 -and -not $lines[0]) { $lines = @() }
    if ($lines.Count -eq 0 -and $Path) { $lines = @(Get-CsvTextLines -Path $Path) }

    $delim = ','
    if ($Path) { try { $delim = Get-CsvDelimiter -Path $Path } catch {} }
    elseif ($lines.Count -gt 0) {
        $probe = ($lines | Where-Object { $_ -and $_.Trim() } | Select-Object -First 20) -join "`n"
        $cComma = ([regex]::Matches($probe, ',')).Count
        $cSemi  = ([regex]::Matches($probe, ';')).Count
        $cTab   = ([regex]::Matches($probe, "`t")).Count
        if ($cTab -gt 0 -and $cComma -gt 0) { $delim = 'TABCOMMA' }
        elseif ($cTab -gt $cComma -and $cTab -gt $cSemi) { $delim = "`t" }
        elseif ($cSemi -gt $cComma) { $delim = ';' }
    }

    $headerIndex = -1
    $headers = @()
    $maxScan = [Math]::Min([Math]::Max($lines.Count - 1, 0), 40)
    for ($i = 0; $i -le $maxScan; $i++) {
        $ln = $lines[$i]
        if (-not $ln -or -not $ln.Trim()) { continue }
        $f = @(ConvertTo-CsvFields -Line $ln -Delimiter $delim)
        if (-not $f -or $f.Count -lt 5) { continue }
        $clean = @($f | ForEach-Object { (($_ + '') -replace '^\uFEFF','').Trim().Trim('"') })
        $hasAssay = $false; $hasSample = $false; $hasCart = $false
        foreach ($h in $clean) {
            if ($h -ieq 'Assay') { $hasAssay = $true }
            if ($h -imatch '^Sample\s*ID$' -or $h -ieq 'SampleID') { $hasSample = $true }
            if ($h -imatch '^Cartridge\s*S/?N$') { $hasCart = $true }
        }
        if ($hasAssay -and $hasSample -and $hasCart) {
            $headerIndex = $i
            $headers = $clean
            break
        }
    }

    $dataStart = -1
    if ($headerIndex -ge 0) {
        for ($r = $headerIndex + 1; $r -lt $lines.Count; $r++) {
            $ln = $lines[$r]
            if (-not $ln -or -not $ln.Trim()) { continue }
            $f = @(ConvertTo-CsvFields -Line $ln -Delimiter $delim)
            if (-not $f -or $f.Count -lt 3) { continue }
            $first = (($f[0] + '') -replace '^\uFEFF','').Trim().Trim('"')
            $sid   = if ($f.Count -gt 2) { (($f[2] + '').Trim().Trim('"')) } else { '' }
            if ($first -and $first -ine 'Assay' -and $sid) { $dataStart = $r; break }
        }
    }

    return [pscustomobject]@{
        Lines       = @($lines)
        Delimiter   = $delim
        HeaderIndex = $headerIndex
        DataStart   = $dataStart
        Headers     = @($headers)
    }
}

function Get-CsvColumnIndex {
    param([object[]]$Headers, [string[]]$Names, [int]$Default = -1)
    if (-not $Headers) { return $Default }
    for ($i = 0; $i -lt $Headers.Count; $i++) {
        $h = (($Headers[$i] + '') -replace '^\uFEFF','').Trim().Trim('"')
        foreach ($n in $Names) {
            if ($h -ieq $n) { return $i }
        }
    }
    return $Default
}

function Test-IsResampleCsv {
    <# Returnerar $true om CSV:n innehåller _RES_ i Sample ID-kolumnen (>= MinHits träffar). #>
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$MinHits = 3
    )

    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    $threshold = [Math]::Max(1, [int]$MinHits)

    try {
        $layout = Get-TestSummaryCsvLayout -Path $Path
        if (-not $layout -or $layout.HeaderIndex -lt 0 -or $layout.DataStart -lt 0) { return $false }
        $sampleIdIdx = Get-CsvColumnIndex -Headers $layout.Headers -Names @('Sample ID','SampleID') -Default 2

        $resCount = 0
        for ($r = $layout.DataStart; $r -lt $layout.Lines.Count; $r++) {
            $line = $layout.Lines[$r]
            if (-not $line -or $line.Trim().Length -eq 0) { continue }
            $fields = @(ConvertTo-CsvFields -Line $line -Delimiter $layout.Delimiter)
            if (-not $fields -or $fields.Count -le $sampleIdIdx) { continue }
            $sid = ($fields[$sampleIdIdx] + '')
            if ($sid -imatch '_RES_') { $resCount++ }
        }
        return ($resCount -ge $threshold)
    } catch {
        try { Gui-Log ("⚠️ Test-IsResampleCsv misslyckades för '{0}': {1}" -f (Split-Path $Path -Leaf), $_.Exception.Message) 'Warn' 'DEBUG' } catch {}
        return $false
    }
}

function Resolve-CsvPrimaryAndResample {
    <# Klassificerar 0-2 CSV-filer till Primary + ev. Resample med samma regel som i buildflödet. #>
    param([string[]]$CsvPaths)

    $result = [pscustomobject]@{
        Ok             = $true
        PrimaryCsv     = $null
        ResampleCsv    = $null
        HasResample    = $false
        ErrorMessage   = $null
        WarningMessage = $null
    }

    $paths = @($CsvPaths | Where-Object { $_ -and (($_ + '').Trim().Length -gt 0) })

    if ($paths.Count -eq 0) { return $result }

    if ($paths.Count -eq 1) {
        if (Test-IsResampleCsv -Path $paths[0]) {
            $result.Ok = $false
            $result.ResampleCsv = $paths[0]
            $result.ErrorMessage = '❌ Enbart Resampling-CSV vald. Välj även Primary CSV innan rapport kan skapas.'
            return $result
        }
        $result.PrimaryCsv = $paths[0]
        return $result
    }

    if ($paths.Count -eq 2) {
        $isRes0 = Test-IsResampleCsv -Path $paths[0]
        $isRes1 = Test-IsResampleCsv -Path $paths[1]

        if ($isRes0 -and -not $isRes1) {
            $result.ResampleCsv = $paths[0]
            $result.PrimaryCsv = $paths[1]
        } elseif ($isRes1 -and -not $isRes0) {
            $result.PrimaryCsv = $paths[0]
            $result.ResampleCsv = $paths[1]
        } elseif (-not $isRes0 -and -not $isRes1) {
            $result.Ok = $false
            $result.ErrorMessage = '❌ Du har valt 2 CSV-filer men ingen Resampling CSV-fil. Avmarkera en fil eller välj korrekt Resampling CSV-fil.'
            return $result
        } else {
            $result.PrimaryCsv = $paths[0]
            $result.ResampleCsv = $paths[1]
            $result.WarningMessage = '⚠️ Båda CSV har _RES_ i Sample ID – autoväljer Resampling + Original.'
        }

        $result.HasResample = [bool]$result.ResampleCsv
        return $result
    }

    $result.Ok = $false
    $result.ErrorMessage = ("❌ Du har valt {0} CSV-filer. Välj max 2 (Primary + ev. Resample)." -f $paths.Count)
    return $result
}

function Get-AssayFromCsv {
    param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    try {
        $layout = Get-TestSummaryCsvLayout -Path $Path
        if (-not $layout -or $layout.DataStart -lt 0) { return $null }
        for ($i = $layout.DataStart; $i -lt $layout.Lines.Count; $i++) {
            $ln = $layout.Lines[$i]
            if (-not $ln -or $ln.Trim().Length -eq 0) { continue }
            $f = @(ConvertTo-CsvFields -Line $ln -Delimiter $layout.Delimiter)
            if (-not $f -or $f.Length -lt 1) { continue }
            $a = ([string]$f[0]).Trim()
            if ($a -and $a -notmatch '^(?i)\s*assay\s*$') { return $a }
        }
    } catch {
        try { Gui-Log "⚠️ Kunde inte läsa Assay från CSV: $($_.Exception.Message)" 'Warn' } catch {}
    }
    return $null
}

function Import-CsvRows {
    param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    $list  = New-Object System.Collections.Generic.List[object]
    try {
        $layout = Get-TestSummaryCsvLayout -Path $Path
        if (-not $layout -or $layout.DataStart -lt 0) { return @() }
        for ($i = $layout.DataStart; $i -lt $layout.Lines.Count; $i++) {
            $ln = $layout.Lines[$i]
            if (-not $ln -or $ln.Trim().Length -eq 0) { continue }
            $f = @(ConvertTo-CsvFields -Line $ln -Delimiter $layout.Delimiter)
            if (-not $f -or ($f -join '').Trim().Length -eq 0) { continue }
            [void]$list.Add($f)
        }
    } catch {
        try { Gui-Log "⚠️ Kunde inte läsa rader från CSV: $($_.Exception.Message)" 'Warn' } catch {}
    }
    return @($list.ToArray())
}

function Get-CsvStats {
    param(
        [string]$Path,
        [string[]]$Lines
    )
    $out = [ordered]@{
        TestCount       = 0
        DupCount        = 0
        Duplicates      = @()
        LspValues       = @()
        LspOK           = $null
        InstrumentByType= [ordered]@{}
    }

    try {
        $layout = Get-TestSummaryCsvLayout -Path $Path -Lines $Lines
        if (-not $layout -or $layout.HeaderIndex -lt 0 -or $layout.DataStart -lt 0) { return [pscustomobject]$out }

        $idxCart = Get-CsvColumnIndex -Headers $layout.Headers -Names @('Cartridge S/N','Cartridge SN') -Default 3
        $idxLsp  = Get-CsvColumnIndex -Headers $layout.Headers -Names @('Reagent Lot ID','Reagent Lot') -Default 4
        $idxIns  = Get-CsvColumnIndex -Headers $layout.Headers -Names @('Instrument S/N','Instrument SN') -Default 6

        $cartSnList = New-Object System.Collections.Generic.List[string]
        $lspList    = New-Object System.Collections.Generic.List[string]
        $instrList  = New-Object System.Collections.Generic.List[string]

        for ($r = $layout.DataStart; $r -lt $layout.Lines.Count; $r++) {
            $ln = $layout.Lines[$r]
            if (-not $ln -or -not $ln.Trim()) { continue }
            $f = @(ConvertTo-CsvFields -Line $ln -Delimiter $layout.Delimiter)
            if ($f.Count -gt $idxCart) { $v = ($f[$idxCart] + '').Trim(); if ($v) { $cartSnList.Add($v) } }
            if ($f.Count -gt $idxLsp)  { $v = ($f[$idxLsp]  + '').Trim(); if ($v) { $lspList.Add($v) } }
            if ($f.Count -gt $idxIns)  { $v = ($f[$idxIns]  + '').Trim(); if ($v) { $instrList.Add($v) } }
        }

        $cartSn = $cartSnList | Where-Object { $_ -and $_ -ne '' }
        $out.TestCount = @($cartSn).Count
        $dups = $cartSn | Group-Object | Where-Object { $_.Count -gt 1 }
        if ($dups) {
            $out.DupCount   = @($dups).Count
            $out.Duplicates = @($dups) | ForEach-Object { "$($_.Name) x$($_.Count)" }
        }

        $lspClean = $lspList | ForEach-Object {
            $m = [regex]::Match($_, '(?<!\d)(\d{5})(?!\d)')
            if ($m.Success) { $m.Groups[1].Value } else { $null }
        } | Where-Object { $_ } | Select-Object -Unique
        $out.LspValues = @($lspClean)
        if (@($lspClean).Count -gt 0) { $out.LspOK = (@($lspClean).Count -eq 1) }

        $lut = @{}
        try {
            foreach ($k in $script:GXINF_Map.Keys) {
                $codes = $script:GXINF_Map[$k].Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ }
                foreach ($code in $codes) { $lut[$code] = $k }
            }
        } catch {}
        foreach ($ins in ($instrList | Where-Object { $_ })) {
            $t = $null
            if ($lut.ContainsKey($ins)) { $t = $lut[$ins] } else { $t = 'Unknown' }
            if (-not $out.InstrumentByType.Contains($t)) { $out.InstrumentByType[$t] = 0 }
            $out.InstrumentByType[$t] = [int]$out.InstrumentByType[$t] + 1
        }
    } catch {
        try { Gui-Log "⚠️ Kunde inte läsa CSV-statistik: $($_.Exception.Message)" 'Warn' } catch {}
    }
    return [pscustomobject]$out
}

function Import-CsvRowsStreaming {
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$StartRow = 10,
        [Parameter(Mandatory)][scriptblock]$ProcessRow
    )
    # För kompatibilitet: använd samma robusta layout/import som normal väg och streama resultatet till callback.
    $rows = @(Import-CsvRows -Path $Path -StartRow $StartRow)
    $r = 0
    foreach ($fields in $rows) {
        $r++
        & $ProcessRow -Fields $fields -RowIndex $r
    }
}
