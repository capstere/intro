﻿# Build phase: Run Information CSV/statistics block
# Extracted/split during HIGH_RISK_REFACTOR_PASS5.

try { Set-UiStep 60 'Skriver Run Information…' } catch {}
# ============================
# === Information-blad     ===
# ============================

try {
    Mark-Phase 'Kontrollmaterial'
    $wsInfo = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if (-not $wsInfo) { $wsInfo = $pkgOut.Workbook.Worksheets.Add($Layout.SheetRunInfo) }

# Säkerställ att kolumn C inte är dold (mallen styr bredd och wrap)
try { $wsInfo.Column(3).Hidden = $false } catch {}

    try {
        $csvLines = $null
        $csvStats = $null

        # ✅ Viktigt: initiera alltid, även om ingen CSV är vald
        $csvInstrumentSerials = @()

        if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
            try { $csvLines = $script:CsvLinesPrimary } catch { Gui-Log ("⚠️ Kunde inte läsa CSV: " + $_.Exception.Message) 'Warn' }
            try { $csvStats = Get-CsvStats -Path $selCsv -Lines $csvLines } catch { Gui-Log ("⚠️ Get-CsvStats: " + $_.Exception.Message) 'Warn' }

            # Hämta exakt lista med Instrument S/N från CSV (för Equipment-blad när WS-skanning är av)
            try {
                if ($csvLines -and $csvLines.Count -gt 8) {
                    $hdr = ConvertTo-CsvFields $csvLines[7]

                    $idx = -1
                    for ($ii=0; $ii -lt $hdr.Count; $ii++) {
                        $h = (($hdr[$ii] + '').Trim('\"').ToLower())
                        if ($h -eq 'instrument s/n' -or $h -match 'instrument') { $idx = $ii; break }
                    }

                    if ($idx -ge 0) {
                        $set = New-Object System.Collections.Generic.HashSet[string]
                        for ($rr=9; $rr -lt $csvLines.Count; $rr++) {
                            $ln = $csvLines[$rr]
                            if (-not $ln -or -not $ln.Trim()) { continue }
                            $f = ConvertTo-CsvFields $ln
                            if ($f.Count -gt $idx) {
                                $v = ($f[$idx] + '').Trim().Trim('\"')
                                if ($v) { $null = $set.Add($v) }
                            }
                        }

                        # HashSet[T]-enumerering (PS 5.1-säker)
                        $csvInstrumentSerials = @($set | Sort-Object)
                    }
                }
            } catch {
                Gui-Log ("⚠️ Kunde inte extrahera Instrument S/N från CSV: " + $_.Exception.Message) 'Warn'
                $csvInstrumentSerials = @()
            }
        }

        if (-not $csvStats) {
            $csvStats = [pscustomobject]@{
                TestCount    = 0
                DupCount     = 0
                Duplicates   = @()
                LspValues    = @()
                LspOK        = $null
                InstrumentByType = [ordered]@{}
            }
        }

        # Statistik för Resample-CSV
        $csvStatsRes = $null
        if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
            try {
                $csvLinesRes = $script:CsvLinesResample
                $csvStatsRes = Get-CsvStats -Path $selCsvRes -Lines $csvLinesRes
            } catch { Gui-Log ("⚠️ Resample Get-CsvStats: " + $_.Exception.Message) 'Warn' }
        }

        $infSN = @()
        if ($script:GXINF_Map) {
            foreach ($k in $script:GXINF_Map.Keys) {
                if ($k -like 'Infinity-*') {
                    $infSN += ($script:GXINF_Map[$k].Split(',') | ForEach-Object { ($_ + '').Trim() } | Where-Object { $_ })
                }
            }
        }
        $infSN = $infSN | Select-Object -Unique

        $infSummary = '—'
        try {
            if ($selCsv -and (Test-Path -LiteralPath $selCsv) -and $infSN.Count -gt 0) {
                $infSummary = Get-InfinitySpFromCsvStrict -Path $selCsv -InfinitySerials $infSN -Lines $csvLines
            }
        } catch {
            Gui-Log ("Infinity SP fel: " + $_.Exception.Message) 'Warn'
        }

        # --- Dubbletter Sample ID ---
        $dupSampleCount = 0
        $dupSampleList  = @()
        if ($csvLines -and $csvLines.Count -gt 8) {
            try {
                $headerFields = ConvertTo-CsvFields $csvLines[7]
                $sampleIdx = -1
                for ($i=0; $i -lt $headerFields.Count; $i++) {
                    $hf = ($headerFields[$i] + '').Trim().ToLower()
                    if ($hf -match 'sample') { $sampleIdx = $i; break }
                }
                if ($sampleIdx -ge 0) {
                    $samples = @()
                    for ($r=9; $r -lt $csvLines.Count; $r++) {
                        $line = $csvLines[$r]
                        if (-not $line -or -not $line.Trim()) { continue }
                        $fields = ConvertTo-CsvFields $line
                        if ($fields.Count -gt $sampleIdx) {
                            $val = ($fields[$sampleIdx] + '').Trim()
                            if ($val) { $samples += $val }
                        }
                    }
                    if ($samples.Count -gt 0) {
                        $counts = @{}
                        foreach ($s in $samples) { if (-not $counts.ContainsKey($s)) { $counts[$s] = 0 }; $counts[$s] = [int]$counts[$s] + 1 }
                        foreach ($entry in $counts.GetEnumerator()) {
                            if ($entry.Value -gt 1) { $dupSampleList += ("$($entry.Key) x$($entry.Value)") }
                        }
                        $dupSampleCount = $dupSampleList.Count
                    }
                }
            } catch {
                Gui-Log ("⚠️ Fel vid analys av Sample ID: " + $_.Exception.Message) 'Warn'
            }
        }

        $dupSampleText = if ($dupSampleCount -gt 0) {
            $show = ($dupSampleList | Select-Object -First 8) -join ', '
            "$dupSampleCount ($show)"
        } else { 'N/A' }

        $dupCartText = if ($csvStats.DupCount -gt 0) {
            $show = ($csvStats.Duplicates | Select-Object -First 8) -join ', '
            "$($csvStats.DupCount) ($show)"
        } else { 'N/A' }

        # --- LSP-summering ---
        $lspSummary = ''
        try {
            if ($csvLines -and $csvLines.Count -gt 8) {
                $counts = @{}
                for ($rr = 9; $rr -lt $csvLines.Count; $rr++) {
                    $ln = $csvLines[$rr]
                    if (-not $ln -or -not $ln.Trim()) { continue }
                    $fs = ConvertTo-CsvFields $ln
                    if ($fs.Count -gt 4) {
                        $raw = ($fs[4] + '').Trim()
                        if ($raw) {
                            $mLsp = [regex]::Match($raw,'(\d{5})')
                            $code = if ($mLsp.Success) { $mLsp.Groups[1].Value } else { $raw }
                            if (-not $counts.ContainsKey($code)) { $counts[$code] = 0 }
                            $counts[$code] = [int]$counts[$code] + 1
                        }
                    }
                }

                if ($counts.Count -gt 0) {
                    $sorted = @($counts.GetEnumerator() | Sort-Object Key)
                    $parts = @()
                    foreach ($kvp in $sorted) {
                        $parts += $(if ($kvp.Value -gt 1) { "$($kvp.Key) x$($kvp.Value)" } else { $kvp.Key })
                    }
                    if ($sorted.Count -eq 1) { $lspSummary = $sorted[0].Key }
                    else { $lspSummary = "$($sorted.Count) (" + ($parts -join ', ') + ")" }
                }
            }
        } catch {
            Gui-Log ("⚠️ Fel vid extraktion av LSP från CSV: " + $_.Exception.Message) 'Warn'
            $lspSummary = ''
        }

        $instText = if ($csvStats.InstrumentByType.Keys.Count -gt 0) {
            ($csvStats.InstrumentByType.GetEnumerator() | ForEach-Object { "$($_.Key)" } | Sort-Object) -join '; '
        } else { '' }

        # ✅ Standard: anta INTE nytt layoutläge om vi inte hittar ankaret
        $isNewLayout = $false
        try {
            $tmpRow = Find-InfoRow -Ws $wsInfo -Label 'CSV-Info'
            if ($tmpRow) { $isNewLayout = $true }
        } catch {}

        $rowCsvFile    = Find-InfoRow -Ws $wsInfo -Label 'CSV'
        $rowLsp        = Find-InfoRow -Ws $wsInfo -Label 'LSP'
        $rowBag        = Find-InfoRow -Ws $wsInfo -Label 'Infinity bags'
        if (-not $rowBag) { $rowBag = Find-InfoRow -Ws $wsInfo -Label 'Bag Numbers Tested Using Infinity' }
        if (-not $rowBag) { $rowBag = Find-InfoRow -Ws $wsInfo -Label 'Bag Numbers Tested Using Infinity:' }
        if (-not $rowBag) { $rowBag = 11 }
        $rowAntal      = Find-InfoRow -Ws $wsInfo -Label 'Antal tester'
        if (-not $rowDupSample) { $rowDupSample = Find-InfoRow -Ws $wsInfo -Label 'Dublett Sample ID' }

        $wsInfo.Cells["B$rowBag"].Style.Numberformat.Format = '@'
        $wsInfo.Cells["B$rowBag"].Value = $infSummary

        if ($isNewLayout) {
            if (-not $rowCsvFile)   { $rowCsvFile   = 8 }
            if (-not $rowLsp)       { $rowLsp       = 9 }
            if (-not $rowBag)       { $rowBag       = 10 }
            if (-not $rowAntal)     { $rowAntal     = 11 }
        }

        if ($selCsv -or $selCsvRes) {
            $wsInfo.Cells["B$rowCsvFile"].Style.Numberformat.Format = '@'
            $csvLabel = ''
            if ($selCsv -and $selCsvRes) {
                $csvLabel = "Primary: {0} | Resampling: {1}" -f (Get-CleanLeaf $selCsv), (Get-CleanLeaf $selCsvRes)
            } elseif ($selCsv) {
                $csvLabel = (Get-CleanLeaf $selCsv)
            } else {
                $csvLabel = "Resampling: {0}" -f (Get-CleanLeaf $selCsvRes)
            }
            $wsInfo.Cells["B$rowCsvFile"].Value = $csvLabel
        } else {
            $wsInfo.Cells["B$rowCsvFile"].Value = ''
        }

        $wsInfo.Cells["B$rowLsp"].Style.Numberformat.Format = '@'
        $wsInfo.Cells["B$rowLsp"].Value = $(if ($lspSummary) { $lspSummary } else { $lsp })

        # ✅ Skriv Antal tester EN gång (som text för att inte bli 1.00E+3 etc)
        $wsInfo.Cells["B$rowAntal"].Style.Numberformat.Format = '@'
        $totalTests = [int]$csvStats.TestCount
        $antalText = "$totalTests"
        if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) {
            $totalTests += [int]$csvStatsRes.TestCount
            $antalText = "$totalTests ($($csvStats.TestCount) + $($csvStatsRes.TestCount) Resample)"
        }
        $wsInfo.Cells["B$rowAntal"].Value = $antalText

        try { $wsInfo.Cells['B:B'].Style.WrapText = $false } catch {}

    } catch {
        Gui-Log ("⚠️ CSV data-fel: " + $_.Exception.Message) 'Warn'
    }

    # --- Makro / dokumentinfo ---
    $assayForMacro = ''
    if ($runAssay) { $assayForMacro = $runAssay }
    elseif ($wsOut1) { $assayForMacro = Get-CellText $wsOut1 $Layout.AssayNameCell }

    $miniVal = ''
    if (Get-Command Get-MinitabMacro -ErrorAction SilentlyContinue) {
        $miniVal = Get-MinitabMacro -AssayName $assayForMacro
    }
    if (-not $miniVal) { $miniVal = 'N/A' }

    $hdNeg = $null; $hdPos = $null
    try { $hdNeg = Get-SealHeaderDocInfo -Pkg $pkgNeg } catch {}
    try { $hdPos = Get-SealHeaderDocInfo -Pkg $pkgPos } catch {}
    if (-not $hdNeg) { $hdNeg = [pscustomobject]@{ Raw=''; DocNo=''; Rev='' } }
    if (-not $hdPos) { $hdPos = [pscustomobject]@{ Raw=''; DocNo=''; Rev='' } }

    $wsInfo.Cells['B2'].Value = $ScriptVersion
    $wsInfo.Cells['B3'].Value = $env:USERNAME
    $wsInfo.Cells['B4'].Value = (Get-Date).ToString('yyyy-MM-dd HH:mm')
    $wsInfo.Cells['B5'].Value = $miniVal

    # --- Batch + länkar ---
    $selLsp = $null
    try {
        if (Get-Variable -Name clbLsp -ErrorAction SilentlyContinue) {
            $selLsp = Get-CheckedFilePath $clbLsp
        }
    } catch {}

    # Snapshot även för Worksheet (om vald) – läsning sker från kopian
    if ($enableStaging -and $stageDir -and $selLsp -and (Test-Path -LiteralPath $selLsp)) {
        try {
            $selLspOrig = $selLsp
            $selLsp = Stage-InputFileSnapshot -Path $selLsp -StageDir $stageDir -Prefix 'Worksheet'
        } catch {}
    }
$batchInfo = Get-BatchLinkInfo -SealPosPath $selPos -SealNegPath $selNeg -Lsp $lspForLinks
$batch     = $batchInfo.Batch
$spOrder   = $batchInfo.Order
$wsInfo.Cells['A31'].Value = 'Öppna SharePoint-post'
$wsInfo.Cells['A31'].Style.Font.Bold = $true
Add-Hyperlink -Cell $wsInfo.Cells['B31'] -Text $batchInfo.LinkText -Url $batchInfo.Url

try {
    if ($batchInfo.OrderStatus -eq 'Mismatch') {
        Gui-Log ("⚠️ Seal Test Order# mismatch mellan aktiva blad: " + (($batchInfo.OrderInfo.AllOrders | Sort-Object) -join ', ')) 'Warn'
    }
    elseif ($batchInfo.OrderStatus -ne 'Unique') {
        Gui-Log "⚠️ Entydigt Order# kunde inte läsas från Seal Test. SharePoint-sökning litar inte på Batch/LSP." 'Warn'
    }
} catch {}

    $linkMap = [ordered]@{
        'IPT App'      = 'https://apps.powerapps.com/play/e/default-771c9c47-7f24-44dc-958e-34f8713a8394/a/fd340dbd-bbbf-470b-b043-d2af4cb62c83'
        'MES Login'    = 'http://mes.cepheid.pri/camstarportal/?domain=CEPHEID.COM'
        'CSV Uploader' = 'http://auw2wgxtpap01.cepaws.com/Welcome.aspx'
        'BMRAM'        = 'https://cepheid62468.coolbluecloud.com/'
        'Agile'        = 'https://agileprod.cepheid.com/Agile/default/login-cms.jsp'
    }

    $rowLink = 32
    foreach ($key in $linkMap.Keys) {
        $wsInfo.Cells["A$rowLink"].Value = $key
        Add-Hyperlink -Cell $wsInfo.Cells["B$rowLink"] -Text 'LÄNK' -Url $linkMap[$key]
        $rowLink++
    }

} catch {
    Gui-Log ("⚠️ Run Information fel: " + $_.Exception.Message) 'Warn'
}
                        
