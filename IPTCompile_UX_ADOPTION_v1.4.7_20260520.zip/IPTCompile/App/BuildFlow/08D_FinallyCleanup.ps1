﻿# Build phase: finally cleanup and temp cleanup
# Extracted/split during HIGH_RISK_REFACTOR_PASS5.

    } finally {
        # Stoppa elapsed-timer
        try { if ($script:buildElapsedTimer) { $script:buildElapsedTimer.Stop(); $script:buildElapsedTimer.Dispose(); $script:buildElapsedTimer = $null } } catch {}
        try {
            if ($buildTimer -and $buildTimer.IsRunning) { $buildTimer.Stop() }
        } catch {}
        if (($totalMs -le 0) -and $buildTimer) {
            try { $totalMs = [int]$buildTimer.ElapsedMilliseconds } catch { $totalMs = 0 }
        }
        if (-not $phaseJson) {
            try { $phaseJson = ($phaseTimings | ConvertTo-Json -Compress) } catch { $phaseJson = '' }
        }
        if (-not $auditWritten) {
            try {
                $auditTests = $null
                if ($csvStats) { $auditTests = [int]$csvStats.TestCount }
                if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) { $auditTests = ($auditTests + 0) + [int]$csvStatsRes.TestCount }
                Add-AuditEntry -Lsp $lsp -Assay $runAssay -BatchNumber $batch -TestCount $auditTests -Status $auditStatusText -ReportPath $SavePath -TotalMs $totalMs -PhaseJson $phaseJson
                $auditWritten = $true
            } catch {
                Gui-Log "⚠️ Kunde inte skriva fallback-audit: $($_.Exception.Message)" 'Warn'
            }
        }
        try { if ($pkgNeg) { $pkgNeg.Dispose() } } catch {}
        try { if ($pkgPos) { $pkgPos.Dispose() } } catch {}
        try { if ($pkgOut) { $pkgOut.Dispose() } } catch {}
        try { if ($script:WsPkg) { $script:WsPkg.Dispose(); $script:WsPkg = $null } } catch {}
        try {
            if ($stageDir -and (Test-Path -LiteralPath $stageDir)) {
                # Säkerhet: radera bara om den ligger under TEMP-root
                $root = Get-ConfigValue -Name 'TempSnapshotRoot' -Default 'C:\IPTCompile_TEMP' -ConfigOverride $Config
                if (-not $root) { $root = 'C:\IPTCompile_TEMP' }
                $stageFull = (Resolve-Path -LiteralPath $stageDir -ErrorAction SilentlyContinue).Path
                $rootFull  = (Resolve-Path -LiteralPath $root -ErrorAction SilentlyContinue).Path
                if ($stageFull -and $rootFull -and $stageFull.StartsWith($rootFull, [System.StringComparison]::OrdinalIgnoreCase)) {
                    Remove-Item -LiteralPath $stageDir -Recurse -Force -ErrorAction SilentlyContinue
                }
            }
        } catch {}
        Set-UiBusy -Busy $false
        $script:BuildInProgress = $false
        try { Update-BuildEnabled } catch {}
        try { Update-ReadinessBanner } catch {}
        try { Update-ReportCountIndicator } catch {}
    }
    #endregion Build: Spara rapport och revision
    #endregion Build: Rapportgenerering (huvudloop)
