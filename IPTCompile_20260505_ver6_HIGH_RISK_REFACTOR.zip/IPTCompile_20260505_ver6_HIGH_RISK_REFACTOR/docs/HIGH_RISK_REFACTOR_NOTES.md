# IPTCompile high-risk refactor notes

This package is a refactor candidate based on `IPTCompile_20260505_ver6.zip`.

## What changed

`Main.ps1` was reduced by moving helper functions into focused modules:

- `App/ReleaseNotes.ps1`
  - `Get-ReleaseNotesCachePath`
  - `Get-ReleaseNotesForVersion`
  - `Show-ReleaseNotesIfNewVersion`

- `Core/SharePointConsistency.ps1`
  - token extraction helpers
  - `Test-SharePointBatchLspConsistency`

- `Core/SealTestValidation.ps1`
  - `Get-SealViolations`

`Main.ps1` still owns the GUI and the large build orchestration flow.

## Why this is high risk

The moved functions are intended to be behavior-preserving, but the project uses PowerShell dot-sourcing and runtime GUI/event flow. This package should be tested as a refactor branch, not dropped directly into production.

## What was not changed

No intentional changes were made to:

- RuleEngine logic
- OpenXML signing logic
- file-locking logic
- SharePoint lookup logic
- output template
- EPPlus/OpenXML DLLs

## Recommended smoke tests

1. Start GUI.
2. Build a normal report without signing.
3. Build with Seal Test signing.
4. Build with Worksheet signing.
5. Verify locked/open Worksheet blocks signing before any write.
6. Verify Worksheet with `Statistical Process Control STF` alias signs correctly.
7. Verify QC Summary still flags deterministic `Fel Test Type`.
