Kontrollprovsfil Log Dashboard - v1.1 layoutfix

Ändring:
- Headern är mindre och använder ellipsis för lång loggfilssökväg.
- Fönstret är lite högre och bredare.
- Översta raderna använder Auto-höjd i stället för hårt låsta höjder.
- Sök/Action/Status-raden har mer utrymme för Status.
- Statusrad och loggfilssökväg visas som enradstext med tooltip för full text.

Körning:
Lägg ps1-filen i samma mapp som UpdateLog_Kontrollprovsfil.csv och kör:

  .\Kontrollprovsfil_LogDashboard_XAML_v1_1_layoutfix.ps1

Eller ange loggens sökväg:

  .\Kontrollprovsfil_LogDashboard_XAML_v1_1_layoutfix.ps1 -LogPath "N:\...\UpdateLog_Kontrollprovsfil.csv"
