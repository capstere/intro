﻿# Forensic snapshot helper extracted from Modules\SignatureHelpers.ps1
# Safe refactor: function body preserved.

function Save-ForensicSnapshot {
    param(
        [Parameter(Mandatory=$true)][string]$SourcePath,
        [Parameter(Mandatory=$true)][string]$Reason,
        [Parameter(Mandatory=$false)][string]$AuditDir,
        [Parameter(Mandatory=$false)][hashtable]$Details = @{}
    )
    try {
        if (-not $AuditDir) { $AuditDir = Join-Path $PSScriptRoot 'audit' }
        $forensicDir = Join-Path $AuditDir 'forensics'
        if (-not (Test-Path -LiteralPath $forensicDir)) {
            New-Item -ItemType Directory -Path $forensicDir -Force | Out-Null
        }

        $ts = (Get-Date).ToString('yyyyMMdd_HHmmss')
        $leaf = Split-Path $SourcePath -Leaf
        $snapName = "${ts}_${env:USERNAME}_${leaf}"
        $snapPath = Join-Path $forensicDir $snapName

        if (Test-Path -LiteralPath $SourcePath) {
            Copy-Item -LiteralPath $SourcePath -Destination $snapPath -Force -ErrorAction Stop
        }

        $logPath = Join-Path $forensicDir "${ts}_${env:USERNAME}_fail.log"
        $logLines = @(
            'SIGNATURE LOG'
            '======================'
            "Tidpunkt:    $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
            "Användare:   $env:USERNAME"
            "Dator:       $env:COMPUTERNAME"
            "Källfil:     $SourcePath"
            "Snapshot:    $snapPath"
            "Orsak:       $Reason"
        )
        foreach ($k in $Details.Keys) {
            $logLines += "${k}: $($Details[$k])"
        }
        Set-Content -LiteralPath $logPath -Value ($logLines -join "`r`n") -Encoding UTF8

        return $snapPath
    } catch {
        try { Gui-Log "⚠️ Kunde inte spara snapshot: $($_.Exception.Message)" 'Warn' } catch {}
        return $null
    }
}
