﻿function Ensure-EPPlus {
    param(
        [string] $Version = "4.5.3.3",
        [string] $SourceDllPath = "",
        [string] $LocalFolder = "$env:TEMP\EPPlus"
    )
    try {
        $candidatePaths = New-Object 'System.Collections.Generic.List[string]'
        try {
            if ($global:Config -and $global:Config.EpplusDllPath) {
                [void]$candidatePaths.Add(($global:Config.EpplusDllPath + ''))
            }
        } catch {}
        $localModuleDll = $null
        try {
            if ($global:LibRoot) {
                $localModuleDll = Join-Path $global:LibRoot 'EPPlus.dll'
            }
        } catch {}
        if (-not $localModuleDll) { $localModuleDll = Join-Path $PSScriptRoot 'EPPlus.dll' }
        [void]$candidatePaths.Add($localModuleDll)
        if ($SourceDllPath) {
            $defaultRoot = 'N:\QC\QC-1\IPT'
            if ($env:IPT_ROOT -and $SourceDllPath -like "$defaultRoot\*") {
                $SourceDllPath = ($env:IPT_ROOT.TrimEnd('\') + $SourceDllPath.Substring($defaultRoot.Length))
            }
            [void]$candidatePaths.Add($SourceDllPath)
        }
        $userModRoot = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'WindowsPowerShell\Modules'
        if (Test-Path -LiteralPath $userModRoot) {
            Get-ChildItem -Path (Join-Path $userModRoot 'EPPlus') -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                [void]$candidatePaths.Add((Join-Path $_.FullName 'lib\net45\EPPlus.dll'))
                [void]$candidatePaths.Add((Join-Path $_.FullName 'lib\net40\EPPlus.dll'))
                [void]$candidatePaths.Add((Join-Path $_.FullName 'lib\net35\EPPlus.dll'))
            }
        }
        $progFiles = $env:ProgramFiles
        $systemModRoot = Join-Path $progFiles 'WindowsPowerShell\Modules'
        if (Test-Path -LiteralPath $systemModRoot) {
            Get-ChildItem -Path (Join-Path $systemModRoot 'EPPlus') -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                [void]$candidatePaths.Add((Join-Path $_.FullName 'lib\net45\EPPlus.dll'))
                [void]$candidatePaths.Add((Join-Path $_.FullName 'lib\net40\EPPlus.dll'))
                [void]$candidatePaths.Add((Join-Path $_.FullName 'lib\net35\EPPlus.dll'))
            }
        }
        foreach ($cand in $candidatePaths) {
            if (-not [string]::IsNullOrWhiteSpace($cand) -and (Test-Path -LiteralPath $cand)) { return $cand }
        }
        $allowOnline = $false
        try {
            if (Get-Command Get-ConfigValue -ErrorAction SilentlyContinue) {
                $allowOnline = [bool](Get-ConfigValue -Name 'AllowNuGetDownload' -Default $false)
            } elseif ($global:Config -and $global:Config.AllowNuGetDownload) {
                $allowOnline = [bool]$global:Config.AllowNuGetDownload
            }
        } catch { $allowOnline = $false }
        if ($allowOnline) {
            $nugetUrl = "https://www.nuget.org/api/v2/package/EPPlus/$Version"
            try {
                $guid = [Guid]::NewGuid().ToString()
                $tempDir = Join-Path $env:TEMP "EPPlus_$guid"
                New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
                $zipPath  = Join-Path $tempDir 'EPPlus.zip'
                $reqParams = @{ Uri = $nugetUrl; OutFile = $zipPath; UseBasicParsing = $true; Headers = @{ 'User-Agent' = 'DocMerge/1.0' } }
                Invoke-WebRequest @reqParams -ErrorAction Stop | Out-Null

                if (-not ([System.AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GetName().Name -eq 'System.IO.Compression.FileSystem' })) {
                    Add-Type -AssemblyName 'System.IO.Compression.FileSystem' -ErrorAction SilentlyContinue
                }
                [System.IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $tempDir)
                $extractedRoot = Join-Path $tempDir 'lib'
                if (Test-Path -LiteralPath $extractedRoot) {
                    $dllCandidate = Get-ChildItem -Path (Join-Path $extractedRoot 'net45'), (Join-Path $extractedRoot 'net40'), (Join-Path $extractedRoot 'net35') -Filter 'EPPlus.dll' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
                    if ($dllCandidate) {
                        try {
                            if (-not (Test-Path -LiteralPath $localModuleDll)) {
                                Copy-Item -Path $dllCandidate.FullName -Destination $localModuleDll -Force -ErrorAction SilentlyContinue
                            }
                        } catch { Gui-Log "⚠️ Kunde inte kopiera EPPlus.dll: $($_.Exception.Message)" 'Warn' }
                        if (Test-Path -LiteralPath $localModuleDll) { return $localModuleDll }
                        return $dllCandidate.FullName
                    }
                }
            } catch {
                Gui-Log "❌ EPPlus: Kunde inte hämta EPPlus ($Version): $($_.Exception.Message)" 'Error'
            }
        }
    } catch {
        Gui-Log "❌ Ensure-EPPlus fel: $($_.Exception.Message)" 'Error'
    }

    Gui-Log "❌ EPPlus.dll hittades inte. Lägg EPPlus.dll lokalt i Lib\ (rekommenderat) eller Modules\ (bakåtkompatibilitet) eller installera EPPlus $Version." 'Error'
    return $null
}

function Load-EPPlus {
    if ([System.AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GetName().Name -eq 'EPPlus' }) { return $true }
    $dllPath = Ensure-EPPlus -Version '4.5.3.3'
    if (-not $dllPath) { return $false }
    try {
        $bytes = [System.IO.File]::ReadAllBytes($dllPath)
        [System.Reflection.Assembly]::Load($bytes) | Out-Null
        return $true
    } catch {
        Gui-Log "❌ EPPlus-fel: $($_.Exception.Message)" 'Error'
        return $false
    }
}

function Set-RowBorder {
    param ($ws, [int] $row, [int] $firstRow, [int] $lastRow)
    foreach ($col in 'B','C','D','E','F','G','H') {
        $ws.Cells["$col$row"].Style.Border.Left.Style   = "None"
        $ws.Cells["$col$row"].Style.Border.Right.Style  = "None"
        $ws.Cells["$col$row"].Style.Border.Top.Style    = "None"
        $ws.Cells["$col$row"].Style.Border.Bottom.Style = "None"
    }
    $ws.Cells["B$row"].Style.Border.Left.Style  = "Medium"
    $ws.Cells["H$row"].Style.Border.Right.Style = "Medium"
    foreach ($col in 'B','C','D','E','F','G') { $ws.Cells["$col$row"].Style.Border.Right.Style = "Thin" }
    $topStyle = if ($row -eq $firstRow) { "Medium" } else { "Thin" }
    $bottomStyle = if ($row -eq $lastRow)  { "Medium" } else { "Thin" }
    foreach ($col in 'B','C','D','E','F','G','H') {
        $ws.Cells["$col$row"].Style.Border.Top.Style    = $topStyle
        $ws.Cells["$col$row"].Style.Border.Bottom.Style = $bottomStyle
    }
}

function Style-Cell { param($cell,$bold,$bg,$border,$fontColor)
    if ($bold) { $cell.Style.Font.Bold = $true }
    if ($bg)   { $cell.Style.Fill.PatternType = "Solid"; $cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#$bg")) }
    if ($fontColor) { $cell.Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#$fontColor")) }
    if ($border) { $cell.Style.Border.Top.Style=$border; $cell.Style.Border.Bottom.Style=$border; $cell.Style.Border.Left.Style=$border; $cell.Style.Border.Right.Style=$border }
}

function Safe-AutoFitColumns {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object]$Ws,
        [Parameter(Mandatory=$false)][object]$Range,
        [Parameter(Mandatory=$false)][ValidateSet('OFF','ON','SMART')][string]$Mode,
        [Parameter(Mandatory=$false)][int]$MaxRows,
        [Parameter(Mandatory=$false)][string]$Context
    )
    if (-not $Mode) {
        try {
            if ($global:Config -and ($global:Config -is [hashtable]) -and $global:Config.ContainsKey('EpplusAutoFitMode')) {
                $Mode = (($global:Config['EpplusAutoFitMode'] + '')).Trim().ToUpperInvariant()
            }
        } catch {}
    }
    if (-not $Mode) { $Mode = 'SMART' }

    if ($MaxRows -le 0) {
        try {
            if ($global:Config -and ($global:Config -is [hashtable]) -and $global:Config.ContainsKey('EpplusAutoFitMaxRows')) {
                $MaxRows = [int]$global:Config['EpplusAutoFitMaxRows']
            }
        } catch {}
    }
    if ($MaxRows -le 0) { $MaxRows = 500 }

    switch ($Mode) {
        'OFF' { return }
        default { }
    }

    $rng = $Range
    if (-not $rng) {
        try { if ($Ws.Dimension) { $rng = $Ws.Cells[$Ws.Dimension.Address] } } catch { $rng = $null }
    }
    if (-not $rng) { return }

    if ($Mode -eq 'SMART') {
        $rows = 0
        try {
            $rows = [int]($rng.End.Row - $rng.Start.Row + 1)
        } catch { $rows = 0 }

        if ($rows -gt 0 -and $rows -gt $MaxRows) {
            try {
                if ($Context) {
                    Gui-Log ("⏩ AutoFit hoppad över ({0} rader > {1}) [{2}]" -f $rows, $MaxRows, $Context) 'Info'
                }
            } catch {}
            return
        }
    }

    try { $rng.AutoFitColumns() | Out-Null } catch {}
}

function Get-SafeCellText {
    <# Läser celltext: .Text först, .Value som reserv. Aldrig .Formula. Returnerar trimmat.
       Stödjer båda anropsformer:
         Get-SafeCellText -Ws $ws -Row 3 -Col 8
         Get-SafeCellText -Ws $ws -Addr 'H3'
    #>
    param(
        [Parameter(Mandatory)][object]$Ws,
        [Parameter(Mandatory=$false)][int]$Row,
        [Parameter(Mandatory=$false)][int]$Col,
        [Parameter(Mandatory=$false)][string]$Addr
    )
    try {
        $cell = $null
        if ($Addr) {
            $cell = $Ws.Cells[$Addr]
        } else {
            $cell = $Ws.Cells[$Row, $Col]
        }
        $txt = ($cell.Text + '').Trim()
        if ($txt) { return $txt }
        return ($cell.Value + '').Trim()
    } catch { return '' }
}

function Get-CellText {
    <#
    .SYNOPSIS  Säker cellläsning med A1-notation. Returnerar alltid trimmat string, aldrig $null.
    .EXAMPLE   Get-CellText $ws 'B3'            → celltext
    .EXAMPLE   Get-CellText $ws 'H3' -Raw       → cell.Value (utan Text-konvertering)
    #>
    param(
        [Parameter(Mandatory)][object]$Ws,
        [Parameter(Mandatory)][string]$Address,
        [switch]$Raw
    )
    try {
        $cell = $Ws.Cells[$Address]
        if (-not $cell) { return '' }
        if ($Raw) { return ($cell.Value + '').Trim() }
        $txt = ($cell.Text + '').Trim()
        if ($txt) { return $txt }
        return ($cell.Value + '').Trim()
    } catch { return '' }
}
