﻿# Safe refactor: early startup guard functions extracted from Main.ps1

function Test-IsBlockedUser {
    param([string[]]$DenyList)

    $u1 = (($env:USERNAME + '').Trim()).ToLowerInvariant()
    $u2 = ((($env:USERDOMAIN + '') + '\' + ($env:USERNAME + '')).Trim()).ToLowerInvariant()

    $deny = @($DenyList | ForEach-Object { (($_ + '').Trim()).ToLowerInvariant() }) | Where-Object { $_ }
    return ($deny -contains $u1) -or ($deny -contains $u2)
}
