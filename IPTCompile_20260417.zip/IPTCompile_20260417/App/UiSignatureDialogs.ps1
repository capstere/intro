﻿# UI-only signature dialogs extracted from Modules\SignatureHelpers.ps1
# Safe refactor: function bodies preserved, no top-level runtime code introduced.

function Confirm-SignatureInput { param([string]$Text)
    $info = Test-SignatureFormat $Text
    $hint = @()
    if (-not $info.Name) { $hint += 'Namn verkar saknas' }
    if (-not $info.Sign) { $hint += 'Signatur verkar saknas' }
    $hasWarning = ($hint.Count -gt 0)

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text            = 'Seal Test — Bekräfta signatur'
    $dlg.StartPosition   = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox     = $false
    $dlg.MinimizeBox     = $false
    $dlg.Size            = New-Object System.Drawing.Size(480, 340)
    $dlg.Font            = New-Object System.Drawing.Font('Segoe UI', 10)

    $pHead = New-Object System.Windows.Forms.Panel
    $pHead.Dock      = 'Top'
    $pHead.Height    = 52
    $pHead.BackColor = [System.Drawing.Color]::SteelBlue
    $lblHead = New-Object System.Windows.Forms.Label
    $lblHead.Text      = [char]0x270F + '  Seal Test — Signatur'
    $lblHead.ForeColor = [System.Drawing.Color]::White
    $lblHead.Font      = New-Object System.Drawing.Font('Segoe UI Semibold', 13)
    $lblHead.AutoSize  = $false
    $lblHead.Dock      = 'Fill'
    $lblHead.Padding   = New-Object System.Windows.Forms.Padding(12, 0, 0, 0)
    $lblHead.TextAlign = 'MiddleLeft'
    $pHead.Controls.Add($lblHead)

    $pContent = New-Object System.Windows.Forms.Panel
    $pContent.Dock    = 'Fill'
    $pContent.Padding = New-Object System.Windows.Forms.Padding(24, 16, 24, 8)

    $nl = [Environment]::NewLine
    $lblInfo = New-Object System.Windows.Forms.Label
    $lblInfo.Dock     = 'Top'
    $lblInfo.AutoSize = $false
    $lblInfo.Height   = 100
    $lblInfo.Font     = New-Object System.Drawing.Font('Segoe UI', 10)
    $lblInfo.Text     = "Namn:           $($info.Name)${nl}Signatur:      $($info.Sign)${nl}Datum:          $($info.Date)"

    $lblStatus = New-Object System.Windows.Forms.Label
    $lblStatus.Dock     = 'Top'
    $lblStatus.AutoSize = $false
    $lblStatus.Height   = 36
    $lblStatus.Font     = New-Object System.Drawing.Font('Segoe UI', 9.5)
    if ($hasWarning) {
        $lblStatus.Text      = [char]0x26A0 + '  ' + ($hint -join ', ')
        $lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(180, 80, 80)
    } else {
        $lblStatus.Text      = [char]0x2705 + '  Ser bra ut.'
        $lblStatus.ForeColor = [System.Drawing.Color]::FromArgb(40, 120, 40)
    }

    $lblQuestion = New-Object System.Windows.Forms.Label
    $lblQuestion.Dock     = 'Top'
    $lblQuestion.AutoSize = $false
    $lblQuestion.Height   = 30
    $lblQuestion.Text     = 'Vill du skriva denna signatur i alla aktiva Seal Test-blad?'
    $lblQuestion.Font     = New-Object System.Drawing.Font('Segoe UI', 9.5, [System.Drawing.FontStyle]::Italic)

    $pContent.Controls.Add($lblQuestion)
    $pContent.Controls.Add($lblStatus)
    $pContent.Controls.Add($lblInfo)

    $pBtn = New-Object System.Windows.Forms.FlowLayoutPanel
    $pBtn.Dock          = 'Bottom'
    $pBtn.Height        = 52
    $pBtn.FlowDirection = 'RightToLeft'
    $pBtn.Padding       = New-Object System.Windows.Forms.Padding(16, 8, 16, 8)
    $pBtn.WrapContents  = $false

    $btnNo = New-Object System.Windows.Forms.Button
    $btnNo.Text         = 'Avbryt'
    $btnNo.Width        = 100
    $btnNo.Height       = 34
    $btnNo.Margin       = New-Object System.Windows.Forms.Padding(0)
    $btnNo.DialogResult = [System.Windows.Forms.DialogResult]::No

    $btnYes = New-Object System.Windows.Forms.Button
    $btnYes.Text         = 'Ja, signera'
    $btnYes.Width        = 120
    $btnYes.Height       = 34
    $btnYes.Margin       = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
    $btnYes.DialogResult = [System.Windows.Forms.DialogResult]::Yes
    try { Set-AccentButton $btnYes -Primary } catch {
        $btnYes.BackColor = [System.Drawing.Color]::SteelBlue
        $btnYes.ForeColor = [System.Drawing.Color]::White
        $btnYes.FlatStyle = 'Flat'
    }

    $pBtn.Controls.Add($btnNo)
    $pBtn.Controls.Add($btnYes)

    $dlg.AcceptButton = $btnYes
    $dlg.CancelButton = $btnNo
    $dlg.Controls.Add($pContent)
    $dlg.Controls.Add($pBtn)
    $dlg.Controls.Add($pHead)

    $res = $dlg.ShowDialog()
    return ($res -eq [System.Windows.Forms.DialogResult]::Yes)
}

function Confirm-WorksheetSignInput {
    param([string]$FullName, [string]$SignDate, [string[]]$Targets)
    $safeTargets = @()
    if ($Targets) {
        foreach ($t in $Targets) {
            $line = ($t + '').Trim()
            if (-not [string]::IsNullOrWhiteSpace($line)) { $safeTargets += $line }
        }
    }

    $dlg = New-Object System.Windows.Forms.Form
    $dlg.Text            = 'Worksheet — Bekräfta signatur'
    $dlg.StartPosition   = 'CenterParent'
    $dlg.FormBorderStyle = 'FixedDialog'
    $dlg.MaximizeBox     = $false
    $dlg.MinimizeBox     = $false
    $dlg.Font            = New-Object System.Drawing.Font('Segoe UI', 10)

    $tabCount  = [Math]::Max($safeTargets.Count, 1)
    $dlgHeight = [Math]::Min(520, 260 + ($tabCount * 22))
    $dlg.Size  = New-Object System.Drawing.Size(520, $dlgHeight)

    $pHead = New-Object System.Windows.Forms.Panel
    $pHead.Dock      = 'Top'
    $pHead.Height    = 52
    $pHead.BackColor = [System.Drawing.Color]::SteelBlue
    $lblHead = New-Object System.Windows.Forms.Label
    $lblHead.Text      = [char]0x2611 + '  Worksheet — Signatur'
    $lblHead.ForeColor = [System.Drawing.Color]::White
    $lblHead.Font      = New-Object System.Drawing.Font('Segoe UI Semibold', 13)
    $lblHead.AutoSize  = $false
    $lblHead.Dock      = 'Fill'
    $lblHead.Padding   = New-Object System.Windows.Forms.Padding(12, 0, 0, 0)
    $lblHead.TextAlign = 'MiddleLeft'
    $pHead.Controls.Add($lblHead)

    $pContent = New-Object System.Windows.Forms.Panel
    $pContent.Dock    = 'Fill'
    $pContent.Padding = New-Object System.Windows.Forms.Padding(24, 16, 24, 8)

    $nl = [Environment]::NewLine
    $lblInfo = New-Object System.Windows.Forms.Label
    $lblInfo.Dock     = 'Top'
    $lblInfo.AutoSize = $false
    $lblInfo.Height   = 56
    $lblInfo.Font     = New-Object System.Drawing.Font('Segoe UI', 10)
    $lblInfo.Text     = "Namn:      $FullName${nl}Datum:     $SignDate"

    $lblTabsLabel = New-Object System.Windows.Forms.Label
    $lblTabsLabel.Dock     = 'Top'
    $lblTabsLabel.AutoSize = $false
    $lblTabsLabel.Height   = 26
    $lblTabsLabel.Font     = New-Object System.Drawing.Font('Segoe UI Semibold', 9.5)
    $lblTabsLabel.Text     = 'Flikar som kommer signeras:'

    $lblTabs = New-Object System.Windows.Forms.Label
    $lblTabs.Dock     = 'Top'
    $lblTabs.AutoSize = $false
    $lblTabs.Font     = New-Object System.Drawing.Font('Segoe UI', 9.5)
    $lblTabs.Padding  = New-Object System.Windows.Forms.Padding(12, 0, 0, 0)

    if ($safeTargets.Count -eq 0) {
        $lblTabs.Height    = 26
        $lblTabs.Text      = '(inga flikar identifierade)'
        $lblTabs.ForeColor = [System.Drawing.Color]::FromArgb(180, 80, 80)
    } else {
        $tabLines = @()
        foreach ($t in $safeTargets) {
            $tabLines += [char]0x2713 + "  $t"
        }
        $lblTabs.Height = [Math]::Max(26, $safeTargets.Count * 22)
        $lblTabs.Text   = ($tabLines -join $nl)
        $lblTabs.ForeColor = [System.Drawing.Color]::FromArgb(40, 120, 40)
    }

    $pContent.Controls.Add($lblTabs)
    $pContent.Controls.Add($lblTabsLabel)
    $pContent.Controls.Add($lblInfo)

    $pBtn = New-Object System.Windows.Forms.FlowLayoutPanel
    $pBtn.Dock          = 'Bottom'
    $pBtn.Height        = 52
    $pBtn.FlowDirection = 'RightToLeft'
    $pBtn.Padding       = New-Object System.Windows.Forms.Padding(16, 8, 16, 8)
    $pBtn.WrapContents  = $false

    $btnNo = New-Object System.Windows.Forms.Button
    $btnNo.Text         = 'Avbryt'
    $btnNo.Width        = 100
    $btnNo.Height       = 34
    $btnNo.Margin       = New-Object System.Windows.Forms.Padding(0)
    $btnNo.DialogResult = [System.Windows.Forms.DialogResult]::No

    $btnYes = New-Object System.Windows.Forms.Button
    $btnYes.Text         = 'Ja, signera'
    $btnYes.Width        = 120
    $btnYes.Height       = 34
    $btnYes.Margin       = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
    $btnYes.DialogResult = [System.Windows.Forms.DialogResult]::Yes
    try { Set-AccentButton $btnYes -Primary } catch {
        $btnYes.BackColor = [System.Drawing.Color]::SteelBlue
        $btnYes.ForeColor = [System.Drawing.Color]::White
        $btnYes.FlatStyle = 'Flat'
    }

    $pBtn.Controls.Add($btnNo)
    $pBtn.Controls.Add($btnYes)

    $dlg.AcceptButton = $btnYes
    $dlg.CancelButton = $btnNo
    $dlg.Controls.Add($pContent)
    $dlg.Controls.Add($pBtn)
    $dlg.Controls.Add($pHead)

    $res = $dlg.ShowDialog()
    return ($res -eq [System.Windows.Forms.DialogResult]::Yes)
}
