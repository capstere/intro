﻿Set-StrictMode -Version 2.0

function Resolve-RuleBankV2ProjectRoot {
    param([string]$ProjectRoot)

    if ($ProjectRoot) {
        return [System.IO.Path]::GetFullPath($ProjectRoot)
    }

    $base = if ($PSScriptRoot) { $PSScriptRoot } elseif ($PSCommandPath) { Split-Path -Parent $PSCommandPath } else { (Get-Location).Path }
    return [System.IO.Path]::GetFullPath((Join-Path $base '..'))
}

function Get-RuleBankV2Paths {
    param([string]$ProjectRoot)

    $root = Resolve-RuleBankV2ProjectRoot -ProjectRoot $ProjectRoot
    $rulesRoot = Join-Path $root 'Rules'
    [pscustomobject]@{
        ProjectRoot = $root
        RulesRoot = $rulesRoot
        SourceRoot = Join-Path $rulesRoot 'Source'
        DocsRoot = Join-Path $rulesRoot 'docs'
        TestsRoot = Join-Path $rulesRoot 'tests'
        MetaPath = Join-Path $rulesRoot 'Source/RuleBank.meta.psd1'
        CanonicalCompiledPath = Join-Path $rulesRoot 'RuleBank.compiled.ps1'
        RuntimeRuleBankDir = $rulesRoot
        RuntimeCompiledPath = Join-Path $rulesRoot 'RuleBank.compiled.ps1'
        SnapshotsRoot = Join-Path $rulesRoot 'tests/snapshots'
    }
}

function Get-RuleBankV2TableSpecs {
    @(
        [pscustomobject]@{ Table='ResultCallPatterns';     SourceFile='ResultCallPatterns.psd1';        Legacy=$false }
        [pscustomobject]@{ Table='ErrorCodes';             SourceFile='ErrorCodes.psd1';                Legacy=$false }
        [pscustomobject]@{ Table='SampleExpectationRules'; SourceFile='SampleExpectationRules.psd1';    Legacy=$false }
        [pscustomobject]@{ Table='SampleIdMarkers';        SourceFile='SampleIdMarkers.psd1';           Legacy=$false }
        [pscustomobject]@{ Table='ParityCheckConfig';      SourceFile='ParityCheckConfig.psd1';         Legacy=$false }
        [pscustomobject]@{ Table='SampleNumberRules';      SourceFile='SampleNumberRules.psd1';         Legacy=$false }
        [pscustomobject]@{ Table='TestTypePolicy';         SourceFile='TestTypePolicy.psd1';            Legacy=$false }
        [pscustomobject]@{ Table='MissingSamplesConfig';   SourceFile='MissingSamplesConfig.legacy.psd1'; Legacy=$true }
    )
}

function Test-RuleBankV2DateString {
    param([string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) { return $false }
    try {
        [void][datetime]::ParseExact($Value.Trim(), 'yyyy-MM-dd', [System.Globalization.CultureInfo]::InvariantCulture, [System.Globalization.DateTimeStyles]::None)
        return $true
    } catch {
        return $false
    }
}

function Assert-RuleBankV2FieldPresent {
    param(
        [hashtable]$Rule,
        [string[]]$FieldNames,
        [string]$Context
    )
    foreach ($field in $FieldNames) {
        if (-not $Rule.ContainsKey($field)) {
            throw ("{0}: saknar fält '{1}'" -f $Context, $field)
        }
        if ($null -eq $Rule[$field]) {
            throw ("{0}: fält '{1}' är null" -f $Context, $field)
        }
    }
}

function Convert-RuleBankV2Bool {
    param($Value, [string]$Context)
    if ($Value -is [bool]) { return [bool]$Value }
    throw ("{0}: väntade bool, fick '{1}'" -f $Context, ($Value.GetType().FullName))
}

function Convert-RuleBankV2Int {
    param($Value, [string]$Context)
    if ($Value -is [int]) { return [int]$Value }
    if ($Value -is [long]) { return [int]$Value }
    if ($Value -is [short]) { return [int]$Value }
    throw ("{0}: väntade heltal, fick '{1}'" -f $Context, ($Value.GetType().FullName))
}

function Convert-RuleBankV2String {
    param($Value)
    if ($null -eq $Value) { return '' }
    return ($Value + '')
}

function Convert-RuleBankV2StringArray {
    param($Value, [string]$Context)
    if ($null -eq $Value) { return @() }
    if ($Value -is [string]) { return @($Value) }
    if ($Value -is [System.Collections.IEnumerable] -and $Value -isnot [string]) {
        return @($Value | ForEach-Object { ($_ + '') })
    }
    throw ("{0}: väntade string[] eller string" -f $Context)
}

function New-RuleBankV2Context {
    param([string]$Table, [int]$Index, [hashtable]$Rule)
    $rid = ''
    try { $rid = ($Rule['RuleId'] + '') } catch { $rid = '' }
    if ($rid) { return ("{0}[{1}] ({2})" -f $Table, $Index, $rid) }
    return ("{0}[{1}]" -f $Table, $Index)
}

function Normalize-RuleBankV2BaseRule {
    param([hashtable]$Rule, [string]$Table, [int]$Index)

    $ctx = New-RuleBankV2Context -Table $Table -Index $Index -Rule $Rule
    Assert-RuleBankV2FieldPresent -Rule $Rule -FieldNames @('RuleId','Version','Source','LastUpdated') -Context $ctx

    $ruleId = Convert-RuleBankV2String $Rule['RuleId']
    $version = Convert-RuleBankV2Int -Value $Rule['Version'] -Context ($ctx + '.Version')
    $source = Convert-RuleBankV2String $Rule['Source']
    $lastUpdated = Convert-RuleBankV2String $Rule['LastUpdated']
    if (-not (Test-RuleBankV2DateString -Value $lastUpdated)) {
        throw ("{0}.LastUpdated måste vara yyyy-MM-dd" -f $ctx)
    }

    [ordered]@{
        RuleId = $ruleId
        Version = $version
        Source = $source
        LastUpdated = $lastUpdated
        Notes = Convert-RuleBankV2String $(if ($Rule.ContainsKey('Notes')) { $Rule['Notes'] } else { '' })
        CaseInsensitive = $(if ($Rule.ContainsKey('CaseInsensitive')) { Convert-RuleBankV2Bool -Value $Rule['CaseInsensitive'] -Context ($ctx + '.CaseInsensitive') } else { $true })
        StopProcessing = $(if ($Rule.ContainsKey('StopProcessing')) { Convert-RuleBankV2Bool -Value $Rule['StopProcessing'] -Context ($ctx + '.StopProcessing') } else { $true })
    }
}

function Normalize-RuleBankV2Rule {
    param([string]$Table, [hashtable]$Rule, [int]$Index)

    $base = Normalize-RuleBankV2BaseRule -Rule $Rule -Table $Table -Index $Index
    $ctx = New-RuleBankV2Context -Table $Table -Index $Index -Rule $Rule

    switch ($Table) {
        'ResultCallPatterns' {
            Assert-RuleBankV2FieldPresent -Rule $Rule -FieldNames @('AssayPattern','MatchType','Pattern','Call','Enabled','Priority') -Context $ctx
            $base['AssayPattern'] = Convert-RuleBankV2String $Rule['AssayPattern']
            $base['MatchType'] = (Convert-RuleBankV2String $Rule['MatchType']).Trim().ToUpperInvariant()
            if ($base['MatchType'] -notin @('CONTAINS','EQUALS','PREFIX','SUFFIX','REGEX')) {
                throw ("{0}.MatchType '{1}' stöds inte" -f $ctx, $base['MatchType'])
            }
            $base['Pattern'] = Convert-RuleBankV2String $Rule['Pattern']
            $base['Call'] = (Convert-RuleBankV2String $Rule['Call']).Trim().ToUpperInvariant()
            $base['Enabled'] = Convert-RuleBankV2Bool -Value $Rule['Enabled'] -Context ($ctx + '.Enabled')
            $base['Priority'] = Convert-RuleBankV2Int -Value $Rule['Priority'] -Context ($ctx + '.Priority')
            return [pscustomobject]$base
        }
        'ErrorCodes' {
            Assert-RuleBankV2FieldPresent -Rule $Rule -FieldNames @('ErrorCode','Name','GeneratesRetest') -Context $ctx
            $base['ErrorCode'] = Convert-RuleBankV2String $Rule['ErrorCode']
            $base['Name'] = Convert-RuleBankV2String $Rule['Name']
            $base['GeneratesRetest'] = Convert-RuleBankV2String $Rule['GeneratesRetest']
            return [pscustomobject]$base
        }
        'SampleExpectationRules' {
            Assert-RuleBankV2FieldPresent -Rule $Rule -FieldNames @('AssayPattern','SampleIdMatchType','SampleIdPattern','ExpectedCall','Enabled','Priority') -Context $ctx
            $base['AssayPattern'] = Convert-RuleBankV2String $Rule['AssayPattern']
            $base['SampleIdMatchType'] = (Convert-RuleBankV2String $Rule['SampleIdMatchType']).Trim().ToUpperInvariant()
            if ($base['SampleIdMatchType'] -notin @('CONTAINS','EQUALS','PREFIX','SUFFIX','REGEX')) {
                throw ("{0}.SampleIdMatchType '{1}' stöds inte" -f $ctx, $base['SampleIdMatchType'])
            }
            $base['SampleIdPattern'] = Convert-RuleBankV2String $Rule['SampleIdPattern']
            $base['ExpectedCall'] = (Convert-RuleBankV2String $Rule['ExpectedCall']).Trim().ToUpperInvariant()
            $base['Enabled'] = Convert-RuleBankV2Bool -Value $Rule['Enabled'] -Context ($ctx + '.Enabled')
            $base['Priority'] = Convert-RuleBankV2Int -Value $Rule['Priority'] -Context ($ctx + '.Priority')
            return [pscustomobject]$base
        }
        'SampleIdMarkers' {
            Assert-RuleBankV2FieldPresent -Rule $Rule -FieldNames @('AssayPattern','MarkerType','Marker','Enabled') -Context $ctx
            $base['AssayPattern'] = Convert-RuleBankV2String $Rule['AssayPattern']
            $base['MarkerType'] = Convert-RuleBankV2String $Rule['MarkerType']
            $base['Marker'] = Convert-RuleBankV2String $Rule['Marker']
            $base['Enabled'] = Convert-RuleBankV2Bool -Value $Rule['Enabled'] -Context ($ctx + '.Enabled')
            if ($Rule.ContainsKey('SampleTokenIndex') -and $Rule['SampleTokenIndex'] -ne $null -and ($Rule['SampleTokenIndex'] + '') -ne '') {
                $base['SampleTokenIndex'] = Convert-RuleBankV2Int -Value $Rule['SampleTokenIndex'] -Context ($ctx + '.SampleTokenIndex')
            }
            if ($Rule.ContainsKey('Priority') -and $Rule['Priority'] -ne $null -and ($Rule['Priority'] + '') -ne '') {
                $base['Priority'] = Convert-RuleBankV2Int -Value $Rule['Priority'] -Context ($ctx + '.Priority')
            }
            return [pscustomobject]$base
        }
        'ParityCheckConfig' {
            Assert-RuleBankV2FieldPresent -Rule $Rule -FieldNames @('AssayPattern','Enabled','CartridgeField','SampleTokenIndex','SuffixX','SuffixPlus','MinValidCartridgeSNPercent','Priority') -Context $ctx
            $base['AssayPattern'] = Convert-RuleBankV2String $Rule['AssayPattern']
            $base['Enabled'] = Convert-RuleBankV2Bool -Value $Rule['Enabled'] -Context ($ctx + '.Enabled')
            $base['CartridgeField'] = Convert-RuleBankV2String $Rule['CartridgeField']
            $base['SampleTokenIndex'] = Convert-RuleBankV2Int -Value $Rule['SampleTokenIndex'] -Context ($ctx + '.SampleTokenIndex')
            $base['SuffixX'] = Convert-RuleBankV2String $Rule['SuffixX']
            $base['SuffixPlus'] = Convert-RuleBankV2String $Rule['SuffixPlus']
            $base['MinValidCartridgeSNPercent'] = Convert-RuleBankV2Int -Value $Rule['MinValidCartridgeSNPercent'] -Context ($ctx + '.MinValidCartridgeSNPercent')
            $base['Priority'] = Convert-RuleBankV2Int -Value $Rule['Priority'] -Context ($ctx + '.Priority')
            $base['DelaminationMarkerType'] = Convert-RuleBankV2String $(if ($Rule.ContainsKey('DelaminationMarkerType')) { $Rule['DelaminationMarkerType'] } else { '' })
            return [pscustomobject]$base
        }
        'SampleNumberRules' {
            Assert-RuleBankV2FieldPresent -Rule $Rule -FieldNames @('AssayPattern','SampleTypeCode','BagNoPattern','SampleNumberTokenIndex','SampleNumberRegex','SampleNumberMin','SampleNumberMax','SampleNumberPad','Enabled','Priority') -Context $ctx
            $base['AssayPattern'] = Convert-RuleBankV2String $Rule['AssayPattern']
            $base['SampleTypeCode'] = Convert-RuleBankV2String $Rule['SampleTypeCode']
            $base['BagNoPattern'] = Convert-RuleBankV2String $Rule['BagNoPattern']
            $base['SampleNumberTokenIndex'] = Convert-RuleBankV2Int -Value $Rule['SampleNumberTokenIndex'] -Context ($ctx + '.SampleNumberTokenIndex')
            $base['SampleNumberRegex'] = Convert-RuleBankV2String $Rule['SampleNumberRegex']
            $base['SampleNumberMin'] = Convert-RuleBankV2Int -Value $Rule['SampleNumberMin'] -Context ($ctx + '.SampleNumberMin')
            $base['SampleNumberMax'] = Convert-RuleBankV2Int -Value $Rule['SampleNumberMax'] -Context ($ctx + '.SampleNumberMax')
            $base['SampleNumberPad'] = Convert-RuleBankV2Int -Value $Rule['SampleNumberPad'] -Context ($ctx + '.SampleNumberPad')
            $base['Enabled'] = Convert-RuleBankV2Bool -Value $Rule['Enabled'] -Context ($ctx + '.Enabled')
            $base['Priority'] = Convert-RuleBankV2Int -Value $Rule['Priority'] -Context ($ctx + '.Priority')
            return [pscustomobject]$base
        }
        'TestTypePolicy' {
            Assert-RuleBankV2FieldPresent -Rule $Rule -FieldNames @('AssayPattern','AllowedTestTypes','Enabled','Priority') -Context $ctx
            $base['AssayPattern'] = Convert-RuleBankV2String $Rule['AssayPattern']
            $base['AllowedTestTypes'] = @(Convert-RuleBankV2StringArray -Value $Rule['AllowedTestTypes'] -Context ($ctx + '.AllowedTestTypes'))
            $base['Enabled'] = Convert-RuleBankV2Bool -Value $Rule['Enabled'] -Context ($ctx + '.Enabled')
            $base['Priority'] = Convert-RuleBankV2Int -Value $Rule['Priority'] -Context ($ctx + '.Priority')
            $base['AssayFamily'] = Convert-RuleBankV2String $(if ($Rule.ContainsKey('AssayFamily')) { $Rule['AssayFamily'] } else { '' })
            return [pscustomobject]$base
        }
        'MissingSamplesConfig' {
            Assert-RuleBankV2FieldPresent -Rule $Rule -FieldNames @('AssayPattern','Bag0SampleMin','Bag0SampleMax','BagMin','BagMax','OtherBagSampleMin','OtherBagSampleMax','SampleNumberPad','SampleNumberRegex','TokenSampleIdSplitIndex','Enabled','Priority') -Context $ctx
            $base['AssayPattern'] = Convert-RuleBankV2String $Rule['AssayPattern']
            $base['Bag0SampleMin'] = Convert-RuleBankV2Int -Value $Rule['Bag0SampleMin'] -Context ($ctx + '.Bag0SampleMin')
            $base['Bag0SampleMax'] = Convert-RuleBankV2Int -Value $Rule['Bag0SampleMax'] -Context ($ctx + '.Bag0SampleMax')
            $base['BagMin'] = Convert-RuleBankV2Int -Value $Rule['BagMin'] -Context ($ctx + '.BagMin')
            $base['BagMax'] = Convert-RuleBankV2Int -Value $Rule['BagMax'] -Context ($ctx + '.BagMax')
            $base['OtherBagSampleMin'] = Convert-RuleBankV2Int -Value $Rule['OtherBagSampleMin'] -Context ($ctx + '.OtherBagSampleMin')
            $base['OtherBagSampleMax'] = Convert-RuleBankV2Int -Value $Rule['OtherBagSampleMax'] -Context ($ctx + '.OtherBagSampleMax')
            $base['SampleNumberPad'] = Convert-RuleBankV2Int -Value $Rule['SampleNumberPad'] -Context ($ctx + '.SampleNumberPad')
            $base['SampleNumberRegex'] = Convert-RuleBankV2String $Rule['SampleNumberRegex']
            $base['TokenSampleIdSplitIndex'] = Convert-RuleBankV2Int -Value $Rule['TokenSampleIdSplitIndex'] -Context ($ctx + '.TokenSampleIdSplitIndex')
            $base['Enabled'] = Convert-RuleBankV2Bool -Value $Rule['Enabled'] -Context ($ctx + '.Enabled')
            $base['Priority'] = Convert-RuleBankV2Int -Value $Rule['Priority'] -Context ($ctx + '.Priority')
            return [pscustomobject]$base
        }
        default { throw ("Okänd RuleBank v2-tabell: {0}" -f $Table) }
    }
}

function Import-RuleBankV2SourceFile {
    param([string]$Path, [string]$ExpectedTable)

    if (-not (Test-Path -LiteralPath $Path)) {
        throw ("Sourcefil saknas: {0}" -f $Path)
    }
    $tokens = $null
    $parseErrors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($Path, [ref]$tokens, [ref]$parseErrors)
    if ($parseErrors.Count -gt 0) {
        throw ("Sourcefil har parserfel: {0} (första fel: {1})" -f $Path, $parseErrors[0].Message)
    }
    $content = Get-Content -LiteralPath $Path -Raw -ErrorAction Stop
    $data = [scriptblock]::Create($content).InvokeReturnAsIs()
    if (-not ($data -is [System.Collections.IDictionary] -or $data -is [hashtable])) {
        throw ("Sourcefil returnerade inte hashtable: {0}" -f $Path)
    }
    if (($data['Table'] + '') -ne $ExpectedTable) {
        throw ("Sourcefil {0} har Table='{1}', väntade '{2}'" -f $Path, ($data['Table'] + ''), $ExpectedTable)
    }
    if (-not $data.Contains('Rules')) {
        throw ("Sourcefil {0} saknar Rules" -f $Path)
    }
    return $data
}

function Import-RuleBankV2Meta {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        throw ("Metafil saknas: {0}" -f $Path)
    }
    $tokens = $null
    $parseErrors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile($Path, [ref]$tokens, [ref]$parseErrors)
    if ($parseErrors.Count -gt 0) {
        throw ("Metafil har parserfel: {0} (första fel: {1})" -f $Path, $parseErrors[0].Message)
    }
    $content = Get-Content -LiteralPath $Path -Raw -ErrorAction Stop
    $data = [scriptblock]::Create($content).InvokeReturnAsIs()
    if (-not ($data -is [System.Collections.IDictionary] -or $data -is [hashtable])) {
        throw ("Metafil returnerade inte hashtable: {0}" -f $Path)
    }
    return $data
}

function Get-RuleBankV2SourceBundle {
    param([string]$ProjectRoot)

    $paths = Get-RuleBankV2Paths -ProjectRoot $ProjectRoot
    $meta = Import-RuleBankV2Meta -Path $paths.MetaPath
    $tables = [ordered]@{}

    foreach ($spec in Get-RuleBankV2TableSpecs) {
        $filePath = Join-Path $paths.SourceRoot $spec.SourceFile
        $data = Import-RuleBankV2SourceFile -Path $filePath -ExpectedTable $spec.Table
        $normalized = New-Object System.Collections.Generic.List[object]
        $i = 0
        foreach ($rule in @($data['Rules'])) {
            if (-not ($rule -is [System.Collections.IDictionary] -or $rule -is [hashtable])) {
                throw ("{0}: varje rule måste vara hashtable" -f $spec.Table)
            }
            $normalized.Add((Normalize-RuleBankV2Rule -Table $spec.Table -Rule ([hashtable]$rule) -Index $i))
            $i++
        }
        $tables[$spec.Table] = @($normalized.ToArray())
    }

    [pscustomobject]@{
        Meta = $meta
        Tables = [pscustomobject]$tables
        Paths = $paths
    }
}

function Get-RuleBankV2SourceFilesForHash {
    param([string]$ProjectRoot)
    $paths = Get-RuleBankV2Paths -ProjectRoot $ProjectRoot
    $files = New-Object System.Collections.Generic.List[string]
    $files.Add($paths.MetaPath)
    foreach ($spec in Get-RuleBankV2TableSpecs) {
        $files.Add((Join-Path $paths.SourceRoot $spec.SourceFile))
    }
    return @($files.ToArray())
}

function Get-RuleBankV2SourceHash {
    param([string[]]$Paths)
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        foreach ($p in ($Paths | Sort-Object)) {
            $full = [System.IO.Path]::GetFullPath($p)
            $bytes = [System.IO.File]::ReadAllBytes($full)
            [void]$sha.TransformBlock($bytes, 0, $bytes.Length, $bytes, 0)
            $nameBytes = [System.Text.Encoding]::UTF8.GetBytes($full)
            [void]$sha.TransformBlock($nameBytes, 0, $nameBytes.Length, $nameBytes, 0)
        }
        [void]$sha.TransformFinalBlock(@(), 0, 0)
        return ([BitConverter]::ToString($sha.Hash)).Replace('-', '').ToLowerInvariant()
    } finally {
        $sha.Dispose()
    }
}

function Convert-RuleBankV2EnabledToCompiled {
    param([bool]$Enabled)
    if ($Enabled) { return 'TRUE' }
    return 'FALSE'
}

function Convert-RuleBankV2IntToCompiled {
    param([int]$Value)
    return ([string]$Value)
}

function Convert-RuleBankV2CompiledRow {
    param([string]$Table, [pscustomobject]$Rule)

    switch ($Table) {
        'ResultCallPatterns' {
            return [ordered]@{
                Assay = ($Rule.AssayPattern + '')
                Call = ($Rule.Call + '')
                MatchType = ($Rule.MatchType + '')
                Pattern = ($Rule.Pattern + '')
                Enabled = (Convert-RuleBankV2EnabledToCompiled $Rule.Enabled)
                Priority = (Convert-RuleBankV2IntToCompiled $Rule.Priority)
                Note = ($Rule.Notes + '')
            }
        }
        'ErrorCodes' {
            return [ordered]@{
                ErrorCode = ($Rule.ErrorCode + '')
                Name = ($Rule.Name + '')
                GeneratesRetest = ($Rule.GeneratesRetest + '')
            }
        }
        'SampleExpectationRules' {
            return [ordered]@{
                Assay = ($Rule.AssayPattern + '')
                SampleIdMatchType = ($Rule.SampleIdMatchType + '')
                SampleIdPattern = ($Rule.SampleIdPattern + '')
                Expected = ($Rule.ExpectedCall + '')
                Enabled = (Convert-RuleBankV2EnabledToCompiled $Rule.Enabled)
                Priority = (Convert-RuleBankV2IntToCompiled $Rule.Priority)
                Note = ($Rule.Notes + '')
            }
        }
        'SampleIdMarkers' {
            $row = [ordered]@{
                AssayPattern = ($Rule.AssayPattern + '')
                MarkerType = ($Rule.MarkerType + '')
                Marker = ($Rule.Marker + '')
                Enabled = (Convert-RuleBankV2EnabledToCompiled $Rule.Enabled)
                Note = ($Rule.Notes + '')
            }
            if ($Rule.PSObject.Properties.Name -contains 'SampleTokenIndex') {
                $row['SampleTokenIndex'] = (Convert-RuleBankV2IntToCompiled $Rule.SampleTokenIndex)
            }
            if ($Rule.PSObject.Properties.Name -contains 'Priority') {
                $row['Priority'] = (Convert-RuleBankV2IntToCompiled $Rule.Priority)
            }
            return $row
        }
        'ParityCheckConfig' {
            return [ordered]@{
                AssayPattern = ($Rule.AssayPattern + '')
                Enabled = (Convert-RuleBankV2EnabledToCompiled $Rule.Enabled)
                CartridgeField = ($Rule.CartridgeField + '')
                SampleTokenIndex = (Convert-RuleBankV2IntToCompiled $Rule.SampleTokenIndex)
                SuffixX = ($Rule.SuffixX + '')
                SuffixPlus = ($Rule.SuffixPlus + '')
                DelaminationMarkerType = ($Rule.DelaminationMarkerType + '')
                MinValidCartridgeSNPercent = (Convert-RuleBankV2IntToCompiled $Rule.MinValidCartridgeSNPercent)
                Note = ($Rule.Notes + '')
                Priority = (Convert-RuleBankV2IntToCompiled $Rule.Priority)
            }
        }
        'SampleNumberRules' {
            return [ordered]@{
                AssayPattern = ($Rule.AssayPattern + '')
                SampleTypeCode = ($Rule.SampleTypeCode + '')
                BagNoPattern = ($Rule.BagNoPattern + '')
                SampleNumberTokenIndex = (Convert-RuleBankV2IntToCompiled $Rule.SampleNumberTokenIndex)
                SampleNumberRegex = ($Rule.SampleNumberRegex + '')
                SampleNumberMin = (Convert-RuleBankV2IntToCompiled $Rule.SampleNumberMin)
                SampleNumberMax = (Convert-RuleBankV2IntToCompiled $Rule.SampleNumberMax)
                SampleNumberPad = (Convert-RuleBankV2IntToCompiled $Rule.SampleNumberPad)
                Enabled = (Convert-RuleBankV2EnabledToCompiled $Rule.Enabled)
                Priority = (Convert-RuleBankV2IntToCompiled $Rule.Priority)
                Note = ($Rule.Notes + '')
            }
        }
        'TestTypePolicy' {
            $allowed = @($Rule.AllowedTestTypes)
            return [ordered]@{
                AssayPattern = ($Rule.AssayPattern + '')
                AllowedTestTypes = ($allowed -join '|')
                Enabled = (Convert-RuleBankV2EnabledToCompiled $Rule.Enabled)
                Priority = (Convert-RuleBankV2IntToCompiled $Rule.Priority)
                AssayFamily = ($Rule.AssayFamily + '')
                Note = ($Rule.Notes + '')
            }
        }
        'MissingSamplesConfig' {
            return [ordered]@{
                AssayPattern = ($Rule.AssayPattern + '')
                Bag0SampleMin = (Convert-RuleBankV2IntToCompiled $Rule.Bag0SampleMin)
                Bag0SampleMax = (Convert-RuleBankV2IntToCompiled $Rule.Bag0SampleMax)
                BagMin = (Convert-RuleBankV2IntToCompiled $Rule.BagMin)
                BagMax = (Convert-RuleBankV2IntToCompiled $Rule.BagMax)
                OtherBagSampleMin = (Convert-RuleBankV2IntToCompiled $Rule.OtherBagSampleMin)
                OtherBagSampleMax = (Convert-RuleBankV2IntToCompiled $Rule.OtherBagSampleMax)
                SampleNumberPad = (Convert-RuleBankV2IntToCompiled $Rule.SampleNumberPad)
                SampleNumberRegex = ($Rule.SampleNumberRegex + '')
                Token_SampleID_SplitIndex = (Convert-RuleBankV2IntToCompiled $Rule.TokenSampleIdSplitIndex)
                Enabled = (Convert-RuleBankV2EnabledToCompiled $Rule.Enabled)
                Priority = (Convert-RuleBankV2IntToCompiled $Rule.Priority)
                Notes = ($Rule.Notes + '')
            }
        }
        default { throw ("Okänd tabell för compiled-export: {0}" -f $Table) }
    }
}

function New-RuleBankV2CompiledArtifact {
    param([pscustomobject]$Bundle)

    $sourceFiles = Get-RuleBankV2SourceFilesForHash -ProjectRoot $Bundle.Paths.ProjectRoot
    $meta = $Bundle.Meta
    $generatedOn = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ssK')
    $sourceHash = Get-RuleBankV2SourceHash -Paths $sourceFiles

    $artifact = [ordered]@{}
    $artifact['Meta'] = [ordered]@{
        SchemaVersion = 2
        RuleBankVersion = (Convert-RuleBankV2String $(if ($meta.Contains('RuleBankVersion')) { $meta['RuleBankVersion'] } else { '2.0.0' }))
        RuntimeCompiledFormatVersion = 1
        Source = (Convert-RuleBankV2String $(if ($meta.Contains('Source')) { $meta['Source'] } else { 'RuleBank v2 source' }))
        LastUpdated = (Convert-RuleBankV2String $(if ($meta.Contains('LastUpdated')) { $meta['LastUpdated'] } else { '' }))
        GeneratedOn = $generatedOn
        SourceHash = $sourceHash
        QuantSpecRulesStatus = 'legacy-empty-compiled-placeholder'
        Counts = [ordered]@{}
    }

    foreach ($spec in Get-RuleBankV2TableSpecs) {
        $rows = @($Bundle.Tables.$($spec.Table))
        $artifact[$spec.Table] = @($rows | ForEach-Object { Convert-RuleBankV2CompiledRow -Table $spec.Table -Rule $_ })
        $artifact['Meta']['Counts'][$spec.Table] = @($artifact[$spec.Table]).Count
    }

    $artifact['QuantSpecRules'] = @()
    $artifact['Meta']['Counts']['QuantSpecRules'] = 0

    $ordered = [ordered]@{
        Meta = $artifact['Meta']
        ParityCheckConfig = $artifact['ParityCheckConfig']
        QuantSpecRules = $artifact['QuantSpecRules']
        TestTypePolicy = $artifact['TestTypePolicy']
        ErrorCodes = $artifact['ErrorCodes']
        ResultCallPatterns = $artifact['ResultCallPatterns']
        SampleNumberRules = $artifact['SampleNumberRules']
        SampleIdMarkers = $artifact['SampleIdMarkers']
        MissingSamplesConfig = $artifact['MissingSamplesConfig']
        SampleExpectationRules = $artifact['SampleExpectationRules']
    }

    return $ordered
}

function ConvertTo-RuleBankPsLiteral {
    param($Value, [int]$Indent = 0)

    $pad = (' ' * $Indent)
    $childPad = (' ' * ($Indent + 4))

    if ($null -eq $Value) { return '$null' }
    if ($Value -is [bool]) { if ($Value) { return '$true' } else { return '$false' } }
    if ($Value -is [int] -or $Value -is [long] -or $Value -is [double] -or $Value -is [decimal]) { return ([string]$Value) }
    if ($Value -is [string]) {
        return "'" + ($Value -replace "'", "''") + "'"
    }
    if ($Value -is [System.Collections.IDictionary] -or $Value -is [hashtable]) {
        $lines = New-Object System.Collections.Generic.List[string]
        $lines.Add('[ordered]@{')
        foreach ($key in $Value.Keys) {
            $literal = ConvertTo-RuleBankPsLiteral -Value $Value[$key] -Indent ($Indent + 4)
            $lines.Add(($childPad + $key + ' = ' + $literal))
        }
        $lines.Add($pad + '}')
        return ($lines -join "`n")
    }
    if ($Value -is [System.Collections.IEnumerable] -and $Value -isnot [string]) {
        $items = @($Value)
        if ($items.Count -eq 0) { return '@()' }
        $lines = New-Object System.Collections.Generic.List[string]
        $lines.Add('@(')
        foreach ($item in $items) {
            $literal = ConvertTo-RuleBankPsLiteral -Value $item -Indent ($Indent + 4)
            $lines.Add($childPad + $literal)
        }
        $lines.Add($pad + ')')
        return ($lines -join "`n")
    }
    $psProps = @()
    try { $psProps = @($Value.PSObject.Properties) } catch { $psProps = @() }
    if ($psProps.Count -gt 0 -and $Value -isnot [string]) {
        $objMap = [ordered]@{}
        foreach ($prop in $psProps) {
            $objMap[$prop.Name] = $prop.Value
        }
        return (ConvertTo-RuleBankPsLiteral -Value $objMap -Indent $Indent)
    }
    return "'" + (($Value + '') -replace "'", "''") + "'"
}

function Write-RuleBankCompiledPs1 {
    param(
        [Parameter(Mandatory)][System.Collections.IDictionary]$Artifact,
        [Parameter(Mandatory)][string]$Path
    )

    $dir = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $dir)) {
        New-Item -Path $dir -ItemType Directory -Force | Out-Null
    }

    $literal = ConvertTo-RuleBankPsLiteral -Value $Artifact -Indent 0
    $literal = $literal -replace '\[ordered\]@{', '@{'

    $content = @(
        '# Generated by Rules/Build-RuleBank.ps1. Do not edit compiled output manually.'
        ('return ' + $literal)
        ''
    ) -join "`n"

    [System.IO.File]::WriteAllText($Path, $content, [System.Text.UTF8Encoding]::new($false))
}

function Write-RuleBankSourceDataFile {
    param(
        [Parameter(Mandatory)][System.Collections.IDictionary]$Data,
        [Parameter(Mandatory)][string]$Path,
        [string]$HeaderComment = ''
    )

    $dir = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $dir)) {
        New-Item -Path $dir -ItemType Directory -Force | Out-Null
    }

    $literal = ConvertTo-RuleBankPsLiteral -Value $Data -Indent 0
    $literal = $literal -replace '\[ordered\]@{', '@{'

    $lines = New-Object System.Collections.Generic.List[string]
    if ($HeaderComment) {
        $lines.Add('# ' + $HeaderComment)
    }
    $lines.Add($literal)
    $lines.Add('')

    [System.IO.File]::WriteAllText($Path, ($lines -join "`n"), [System.Text.UTF8Encoding]::new($false))
}

function Load-RuleBankCompiledArtifact {
    param([string]$Path)
    return (& $Path)
}

function Convert-RuleBankArtifactRowToComparable {
    param([string]$Table, [object]$Row)

    $h = [ordered]@{}
    if ($Row -is [System.Collections.IDictionary] -or $Row -is [hashtable]) {
        foreach ($k in @($Row.Keys | Sort-Object)) { $h[$k] = ($Row[$k] + '') }
    } else {
        foreach ($p in @($Row.PSObject.Properties.Name | Sort-Object)) { $h[$p] = ($Row.$p + '') }
    }

    if ($Table -eq 'QuantSpecRules') { return $h }
    return $h
}

function Get-RuleBankComparableSnapshot {
    param([System.Collections.IDictionary]$Artifact)
    $tables = @('ResultCallPatterns','SampleExpectationRules','ErrorCodes','SampleIdMarkers','ParityCheckConfig','SampleNumberRules','TestTypePolicy','MissingSamplesConfig','QuantSpecRules')
    $snap = [ordered]@{}
    foreach ($table in $tables) {
        $snap[$table] = @($Artifact[$table] | ForEach-Object { Convert-RuleBankArtifactRowToComparable -Table $table -Row $_ })
    }
    return $snap
}

function Get-RuleBankV2ScriptContent {
    param([Parameter(Mandatory)][string]$Path)

    $bytes = [System.IO.File]::ReadAllBytes($Path)
    while ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        if ($bytes.Length -eq 3) {
            $bytes = @()
            break
        }
        $bytes = $bytes[3..($bytes.Length - 1)]
    }

    $content = [System.Text.Encoding]::UTF8.GetString($bytes)
    while ($content.Length -gt 0 -and [int][char]$content[0] -eq 0xFEFF) {
        $content = $content.Substring(1)
    }
    return $content
}
