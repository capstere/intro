﻿param(
    [string]$ProjectRoot,
    [switch]$SkipRuntimeLoad
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

. (Join-Path $PSScriptRoot 'RuleBankV2.Common.ps1')

$paths = Get-RuleBankV2Paths -ProjectRoot $ProjectRoot
$bundle = Get-RuleBankV2SourceBundle -ProjectRoot $paths.ProjectRoot
$artifact = New-RuleBankV2CompiledArtifact -Bundle $bundle
Write-RuleBankCompiledPs1 -Artifact $artifact -Path $paths.CanonicalCompiledPath

$expectedTopLevel = @('Meta','ParityCheckConfig','QuantSpecRules','TestTypePolicy','ErrorCodes','ResultCallPatterns','SampleNumberRules','SampleIdMarkers','MissingSamplesConfig','SampleExpectationRules')
$activeTables = @('ResultCallPatterns','SampleExpectationRules','ErrorCodes','SampleIdMarkers','ParityCheckConfig','SampleNumberRules','TestTypePolicy','MissingSamplesConfig')
$errors = New-Object System.Collections.Generic.List[string]
$notes = New-Object System.Collections.Generic.List[string]

$quantSourceFiles = @(Get-ChildItem -LiteralPath $paths.SourceRoot -File | Where-Object { $_.Name -match '(?i)QuantSpec' })
$quantSourceFilePaths = @($quantSourceFiles | ForEach-Object { $_.FullName })
if ($quantSourceFiles.Count -gt 0) {
    foreach ($file in $quantSourceFiles) {
        $errors.Add(('Unexpected QuantSpec source file: {0}' -f $file.FullName))
    }
}

foreach ($key in $expectedTopLevel) {
    if (-not $artifact.Contains($key)) {
        $errors.Add(('Compiled artifact missing top-level key: {0}' -f $key))
    }
}

if (@($artifact['QuantSpecRules']).Count -ne 0) {
    $errors.Add('Compiled artifact must emit QuantSpecRules as an empty legacy placeholder.')
}

foreach ($table in $activeTables) {
    foreach ($row in @($artifact[$table])) {
        foreach ($key in $row.Keys) {
            $value = $row[$key]
            if ($null -ne $value -and $value -isnot [string]) {
                $errors.Add(('Compiled table {0} has non-string field {1} ({2})' -f $table, $key, $value.GetType().FullName))
                break
            }
        }
    }
}

$runtimeLoaded = $false
$runtimeCounts = [ordered]@{}
if (-not $SkipRuntimeLoad) {
    . ([scriptblock]::Create((Get-RuleBankV2ScriptContent -Path (Join-Path $paths.ProjectRoot 'Infrastructure/Csv.ps1'))))
    . ([scriptblock]::Create((Get-RuleBankV2ScriptContent -Path (Join-Path $paths.ProjectRoot 'Core/RuleEngineCore.ps1'))))
    $rb = Load-RuleBank -RuleBankDir $paths.RulesRoot
    $runtimeLoaded = $true
    foreach ($table in @('ResultCallPatterns','QuantSpecRules','SampleExpectationRules','ErrorCodes','MissingSamplesConfig','SampleIdMarkers','ParityCheckConfig','SampleNumberRules','TestTypePolicy')) {
        $runtimeCounts[$table] = @($rb.$table).Count
    }
    if (@($rb.QuantSpecRules).Count -ne 0) {
        $errors.Add('Runtime-loaded RuleBank from Rules/ unexpectedly has non-empty QuantSpecRules.')
    }
}

$noteArray = @($notes.ToArray())
$errorArray = @($errors.ToArray())

$report = @{}
$report['ProjectRoot'] = $paths.ProjectRoot
$report['RuntimeRuleBankDirInApp'] = $paths.RuntimeRuleBankDir
$report['CanonicalCompiledPath'] = $paths.CanonicalCompiledPath
$report['GeneratedOn'] = ($artifact['Meta']['GeneratedOn'] + '')
$report['SourceHash'] = ($artifact['Meta']['SourceHash'] + '')
$report['QuantSpecSourceFiles'] = $quantSourceFilePaths
$report['QuantSpecCompiledCount'] = @($artifact['QuantSpecRules']).Count
$report['TopLevelKeys'] = @($artifact.Keys)
$report['ActiveTableCounts'] = @{}

$runtimeLoad = @{}
$runtimeLoad['Performed'] = (-not $SkipRuntimeLoad)
$runtimeLoad['Loaded'] = $runtimeLoaded
$runtimeLoad['Counts'] = $runtimeCounts
$report['RuntimeLoad'] = $runtimeLoad

$report['Notes'] = $noteArray
$report['Errors'] = $errorArray

foreach ($table in $activeTables) {
    $report['ActiveTableCounts'][$table] = @($artifact[$table]).Count
}

$reportPath = Join-Path $paths.DocsRoot 'RuleBankV2.validation.report.json'
$report | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $reportPath -Encoding UTF8

if ($errors.Count -gt 0) {
    if ($errors.Count -gt 0) {
        foreach ($line in $errors) { Write-Host ('FAIL ' + $line) }
    }
    Write-Host ('Validation report: {0}' -f $reportPath)
    exit 1
}

Write-Host ('PASS validate RuleBank v2 source and canonical runtime compatibility')
Write-Host ('Canonical runtime artifact: {0}' -f $paths.CanonicalCompiledPath)
Write-Host ('Validation report: {0}' -f $reportPath)
