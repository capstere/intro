﻿param(
    [string]$ProjectRoot
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

. (Join-Path $PSScriptRoot 'RuleBankV2.Common.ps1')

$paths = Get-RuleBankV2Paths -ProjectRoot $ProjectRoot
$artifact = Load-RuleBankCompiledArtifact -Path $paths.RuntimeCompiledPath

$tableContract = @(
    [ordered]@{ Table='ResultCallPatterns'; Required=@('Assay','Call','MatchType','Pattern','Enabled','Priority'); Optional=@('Note'); Legacy=@(); ApparentlyUnused=@() }
    [ordered]@{ Table='SampleExpectationRules'; Required=@('Assay','SampleIdMatchType','SampleIdPattern','Expected','Enabled','Priority'); Optional=@('Note'); Legacy=@(); ApparentlyUnused=@() }
    [ordered]@{ Table='ErrorCodes'; Required=@('ErrorCode','Name','GeneratesRetest'); Optional=@(); Legacy=@(); ApparentlyUnused=@() }
    [ordered]@{ Table='SampleIdMarkers'; Required=@('AssayPattern','MarkerType','Marker','Enabled'); Optional=@('Note','Priority'); Legacy=@(); ApparentlyUnused=@('SampleTokenIndex') }
    [ordered]@{ Table='ParityCheckConfig'; Required=@('AssayPattern','Enabled','CartridgeField','SampleTokenIndex','SuffixX','SuffixPlus','MinValidCartridgeSNPercent','Priority'); Optional=@('Note','DelaminationMarkerType'); Legacy=@(); ApparentlyUnused=@() }
    [ordered]@{ Table='SampleNumberRules'; Required=@('AssayPattern','SampleTypeCode','BagNoPattern','SampleNumberTokenIndex','SampleNumberRegex','SampleNumberMin','SampleNumberMax','SampleNumberPad','Enabled','Priority'); Optional=@('Note'); Legacy=@(); ApparentlyUnused=@() }
    [ordered]@{ Table='TestTypePolicy'; Required=@('AssayPattern','AllowedTestTypes','Enabled','Priority'); Optional=@('Note'); Legacy=@('AssayFamily'); ApparentlyUnused=@() }
    [ordered]@{ Table='MissingSamplesConfig'; Required=@(); Optional=@(); Legacy=@('AssayPattern','Bag0SampleMin','Bag0SampleMax','BagMin','BagMax','OtherBagSampleMin','OtherBagSampleMax','SampleNumberPad','SampleNumberRegex','Token_SampleID_SplitIndex','Enabled','Priority','Notes'); ApparentlyUnused=@('All fields are apparently unused by current runtime beyond load/integrity surface') }
    [ordered]@{ Table='QuantSpecRules'; Required=@(); Optional=@(); Legacy=@('AssayPattern','MatchType','Call','ControlCode','Metric','Min','Max','FailMode','OnFailErrorCode','OnFailDeviation','Enabled','Priority','CtMin','CtMax','AvgLogMin','AvgLogMax','SDMax','OnFailErrorName','OnFailGeneratesRetest','Note'); ApparentlyUnused=@('All fields are apparently unused by current runtime beyond load/integrity surface') }
    [ordered]@{ Table='Meta'; Required=@(); Optional=@('Counts','GeneratedOn','SourceHash'); Legacy=@('Schema/report metadata only'); ApparentlyUnused=@('All fields are apparently unused by current runtime') }
)

$tableInventory = New-Object System.Collections.Generic.List[object]
foreach ($key in @($artifact.Keys)) {
    $rows = @($artifact[$key])
    $fields = @()
    if ($rows.Count -gt 0) {
        $row = $rows[0]
        if ($row -is [System.Collections.IDictionary] -or $row -is [hashtable]) {
            $fields = @($row.Keys | Sort-Object)
        } else {
            $fields = @($row.PSObject.Properties.Name | Sort-Object)
        }
    }
    $tableInventory.Add([pscustomobject]@{
        Table = $key
        Count = $rows.Count
        Fields = $fields
    })
}

$report = [ordered]@{
    ProjectRoot = $paths.ProjectRoot
    ActualRuntimeRuleBankDir = $paths.RuntimeRuleBankDir
    RuntimeCompiledPath = $paths.RuntimeCompiledPath
    Note = 'App runtime points to Rules/RuleBank.compiled.ps1 as the only active RuleBank artifact.'
    PrioritySemantics = 'Higher numeric priority wins. Tables are sorted descending before first-match evaluation.'
    EnabledSemantics = 'Blank or missing Enabled is treated as enabled. FALSE/0/NO/N disables.'
    AssayMatching = 'ResultCallPatterns and SampleExpectationRules use Assay. Other active tables use AssayPattern. Matching is wildcard-like, exact insensitive, then cautious contains fallback.'
    MatchTypesSupported = @('CONTAINS','EQUALS','PREFIX','SUFFIX','REGEX')
    CompiledFieldTypes = 'Active runtime tables currently use strings for booleans and integers in compiled rows.'
    QuantSpecRulesAssessment = 'Legacy load-contract surface only; no active decision logic found in current runtime. Keep as empty compiled placeholder in v2 until controlled removal.'
    MissingSamplesAssessment = 'Legacy load-contract surface only; no active decision logic found in current runtime.'
    DelaminationNote = 'DELAMINATION evidence from Data Summary / Resample Data Summary / Extra Data Summary remains outside RuleBank and must not be duplicated in v2 source.'
    PathUsage = @(
        [ordered]@{ File='Modules/Config.ps1'; RuleBankPath='Rules/'; Usage='direct'; Status='canonical'; RecommendedAction='Keep as primary runtime load path.' }
        [ordered]@{ File='Core/RuleEngineCore.ps1'; RuleBankPath='Caller-provided RuleBankDir'; Usage='direct'; Status='active runtime loader'; RecommendedAction='Keep generic; avoid adding competing hardcoded roots.' }
        [ordered]@{ File='Main.ps1'; RuleBankPath='Config.RuleBankDir'; Usage='direct'; Status='canonical through config'; RecommendedAction='No additional path logic needed.' }
    )
    TopLevelKeys = @($artifact.Keys)
    TableInventory = @($tableInventory.ToArray())
    TableContract = $tableContract
}

$outPath = Join-Path $paths.DocsRoot 'RuleBankRuntimeContract.report.json'
$report | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $outPath -Encoding UTF8
Write-Host ('Wrote runtime analysis report: {0}' -f $outPath)
