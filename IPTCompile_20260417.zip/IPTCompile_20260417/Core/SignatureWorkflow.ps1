﻿# Core signature workflow helpers extracted from Modules\SignatureHelpers.ps1
# Safe refactor: function bodies preserved, no top-level runtime code introduced.

function Get-DataSheets { param([OfficeOpenXml.ExcelPackage]$Pkg)
    $all = @($Pkg.Workbook.Worksheets | Where-Object { $_.Name -ne "Worksheet Instructions" })
    if ($all.Count -gt 1) { return $all | Select-Object -Skip 1 } else { return @() }
}

function Test-SignatureFormat {
    param([string]$Text)
    $raw = ($Text + '')
    $trim = $raw.Trim()
    $parts = $trim -split '\s*,\s*'
    $name = if ($parts.Count -ge 1) { $parts[0] } else { '' }
    $sign = if ($parts.Count -ge 2) { $parts[1] } else { '' }
    $date = if ($parts.Count -ge 3) { $parts[2] } else { '' }
    $dateOk = $false
    if ($date) { if ($date -match '^\d{4}-\d{2}-\d{2}$' -or $date -match '^\d{8}$') { $dateOk = $true } }
    [pscustomobject]@{ Raw=$raw; Name=$name; Sign=$sign; Date=$date; Parts=$parts.Count; DateOk=$dateOk; LooksOk=($name -ne '' -and $sign -ne '') }
}

function Normalize-Signature {
    param([string]$s)
    if (-not $s) { return '' }
    $x = $s.Trim().ToLowerInvariant()
    $x = [regex]::Replace($x, '\s+', ' ')
    $x = $x -replace '\s*,\s*', ','
    return $x
}
 
function Get-SignatureSetForDataSheets {
    param([OfficeOpenXml.ExcelPackage]$Pkg)
    $result = [pscustomobject]@{
        RawFirst  = $null
        NormSet   = New-Object 'System.Collections.Generic.HashSet[string]'
        Occ       = @{}
        RawByNorm = @{} 
    }
    if (-not $Pkg) { return $result }

    foreach ($ws in ($Pkg.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' })) {
        $h3 = ($ws.Cells['H3'].Text + '').Trim()
        if ($h3 -match '^[0-9]') {
            $raw = ($ws.Cells['B47'].Text + '').Trim()
            if ($raw) {
                $norm = Normalize-Signature $raw
                [void]$result.NormSet.Add($norm)
                if (-not $result.RawFirst) { $result.RawFirst = $raw }
                if (-not $result.Occ.ContainsKey($norm)) {
                    $result.Occ[$norm] = New-Object 'System.Collections.Generic.List[string]'
                }
                if (-not $result.RawByNorm.ContainsKey($norm)) {
                    $result.RawByNorm[$norm] = $raw
                }
                [void]$result.Occ[$norm].Add($ws.Name)
            }
        } elseif ([string]::IsNullOrWhiteSpace($h3) -or $h3 -match '^(?i)(N\/?A|NA|Tomt( innehåll)?)$') {
            break
        }
    }
    return $result
}

function UrlEncode([string]$s){ try { [System.Uri]::EscapeDataString($s) } catch { $s } }

function Get-BatchNumberFromSealFile([string]$Path){
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    if (-not (Load-EPPlus)) { return $null }
    $pkg = $null
    try {
        $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($Path))
        foreach ($ws in (Get-DataSheets $pkg)) {
            $txt = ($ws.Cells['D2'].Text + '').Trim()
            if ($txt) { return $txt }
        }
    } catch {
        Gui-Log "⚠️ Kunde inte läsa Batch # från Seal-fil: $($_.Exception.Message)" 'Warn'
    } finally { if ($pkg) { try { $pkg.Dispose() } catch {} } }
    return $null
}

function Update-BatchLink {
    if (-not (Get-Variable -Name slBatchLink -Scope Script -ErrorAction SilentlyContinue) -and -not (Get-Variable -Name slBatchLink -Scope Global -ErrorAction SilentlyContinue)) { return }
    try {
        $selNeg = Get-CheckedFilePath $clbNeg
        $selPos = Get-CheckedFilePath $clbPos
        $bnNeg  = if ($selNeg) { Get-BatchNumberFromSealFile $selNeg } else { $null }
        $bnPos  = if ($selPos) { Get-BatchNumberFromSealFile $selPos } else { $null }
        $lsp    = $txtLSP.Text.Trim()
        $mismatch = ($bnNeg -and $bnPos -and ($bnNeg -ne $bnPos))
        if ($mismatch) {
            $slBatchLink.Text        = 'SharePoint: mismatch'
            $slBatchLink.Enabled     = $false
            $slBatchLink.Tag         = $null
            $slBatchLink.ToolTipText = "NEG: $bnNeg  |  POS: $bnPos"
            return
        }
        $batch = if ($bnPos) { $bnPos } elseif ($bnNeg) { $bnNeg } else { $null }
        if ($batch) {
            $url = $SharePointBatchLinkTemplate -replace '\{BatchNumber\}', (UrlEncode $batch) -replace '\{LSP\}', (UrlEncode $lsp)

            $slBatchLink.Text        = "SharePoint: $batch"
            $slBatchLink.Enabled     = $true
            $slBatchLink.Tag         = $url
            $slBatchLink.ToolTipText = $url
        } else {
            $slBatchLink.Text        = 'SharePoint: —'
            $slBatchLink.Enabled     = $false
            $slBatchLink.Tag         = $null
            $slBatchLink.ToolTipText = 'Direktlänk aktiveras när Batch# hittas i sökt LSP.'
        }
    } catch {
        Gui-Log "⚠️ Kunde inte uppdatera SharePoint-länk: $($_.Exception.Message)" 'Warn'
    }
}

function Verify-SealTestSignatures {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$ExpectedText,
        [Parameter(Mandatory=$true)][string]$SignatureCell,
        [Parameter(Mandatory=$true)][string]$ActiveCheckCell,
        [Parameter(Mandatory=$true)][int]$ExpectedWritten
    )

    $result = [pscustomobject]@{
        OK             = $false
        SheetsChecked  = 0
        SheetsVerified = 0
        Mismatches     = New-Object System.Collections.Generic.List[string]
        Error          = $null
    }

    if (-not (Test-Path -LiteralPath $Path)) {
        $result.Error = "Filen finns inte: $Path"
        return $result
    }

    $pkg = $null
    try {
        $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($Path))
        foreach ($ws in $pkg.Workbook.Worksheets) {
            if ($ws.Name -eq 'Worksheet Instructions') { continue }
            $h3 = ($ws.Cells[$ActiveCheckCell].Text + '').Trim()
            if ($h3 -match '^[0-9]') {
                $result.SheetsChecked++
                $actual = ($ws.Cells[$SignatureCell].Text + '').Trim()
                if ($actual -eq $ExpectedText) {
                    $result.SheetsVerified++
                } else {
                    [void]$result.Mismatches.Add("$($ws.Name): Förväntade='$ExpectedText' Faktisk='$actual'")
                }
            }
            elseif ([string]::IsNullOrWhiteSpace($h3) -or $h3 -match '^(?i)(N\/?A|NA|Tomt( innehåll)?)$') {
                break
            }
        }

        if ($result.Mismatches.Count -eq 0 -and $result.SheetsVerified -ge $ExpectedWritten) {
            $result.OK = $true
        }
    } catch {
        $result.Error = $_.Exception.Message
    } finally {
        try { if ($pkg) { $pkg.Dispose() } } catch {}
    }
    return $result
}

function Verify-WorksheetSignatures {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][object[]]$WrittenCells
    )

    $result = [pscustomobject]@{
        OK             = $false
        CellsChecked   = 0
        CellsVerified  = 0
        Mismatches     = New-Object System.Collections.Generic.List[string]
        Error          = $null
    }

    if (-not $WrittenCells -or $WrittenCells.Count -eq 0) {
        $result.OK = $true
        return $result
    }

    if (-not (Test-Path -LiteralPath $Path)) {
        $result.Error = "Filen finns inte: $Path"
        return $result
    }

    $pkg = $null
    try {
        $pkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($Path))

        foreach ($wc in $WrittenCells) {
            $result.CellsChecked++
            $ws = $pkg.Workbook.Worksheets[$wc.Sheet]
            if (-not $ws) {
                [void]$result.Mismatches.Add("$($wc.Sheet) $($wc.Col)$($wc.Row): Fliken hittades inte")
                continue
            }

            $cellAddr = "$($wc.Col)$($wc.Row)"
            $actual = ($ws.Cells[$cellAddr].Text + '').Trim()
            $expected = ($wc.Value + '').Trim()

            if ($actual -eq $expected) {
                $result.CellsVerified++
            } else {
                [void]$result.Mismatches.Add("$($wc.Sheet) ${cellAddr}: Förväntade='$expected' Faktisk='$actual'")
            }
        }

        $result.OK = ($result.Mismatches.Count -eq 0 -and $result.CellsVerified -eq $WrittenCells.Count)
    } catch {
        $result.Error = $_.Exception.Message
    } finally {
        try { if ($pkg) { $pkg.Dispose() } } catch {}
    }
    return $result
}
