# SAFE_REFACTOR_NOTES.md

Version: 1.3.2-phase6-safe

Detta är fas 6 som en säker refactor ovanpå originalets runtime-struktur.

Vad som faktiskt gjordes:
- Fas 5 behölls oförändrad:
  - `Modules/Logging.ps1` är fortsatt shim till `Infrastructure/LoggingCore.ps1` och `App/UiLogging.ps1`
  - `Modules/SignatureHelpers.ps1` är fortsatt shim till `Core/SignatureWorkflow.ps1`, `App/UiSignatureDialogs.ps1` och `Infrastructure/Forensics.ps1`
- `Modules/OpenXmlHelpers.ps1` delades säkert till:
  - `Infrastructure/ExcelOpenXml.ps1`
  - `Core/OpenXmlSignatureWorkflow.ps1`
- `Modules/OpenXmlHelpers.ps1` ersattes med shim som dot-sourcar de två filerna ovan
- `Version.txt` uppdaterades till `1.3.2-phase6-safe`

Hur delningen gjordes:
- Endast hela verifierade funktionsdefinitioner flyttades
- Ingen top-level runtime-kod flyttades ut
- Alla publika funktionsnamn behölls oförändrade
- Ursprungsmodulens laddningsväg behölls via shim

Funktionsfördelning i fas 6:

## Infrastructure/ExcelOpenXml.ps1
- `Resolve-OpenXmlDllPath`
- `Import-OpenXmlSdk`
- `Normalize-OpenXmlText`
- `Get-OpenXmlChildrenOfType`
- `Get-OpenXmlDescendantsOfType`
- `Convert-ColLetterToIndex`
- `Convert-ColIndexToLetter`
- `Split-OpenXmlCellRef`
- `Get-MergeIndexes_OpenXml`
- `Get-MergeCellMap_OpenXml`
- `Get-OpenXmlCellText`
- `Ensure-OpenXmlCell`
- `Test-OpenXmlTreatAsBlankText`
- `Get-OpenXmlCellSafe`
- `Clear-OpenXmlCellContent`
- `Set-OpenXmlCellInlineText`
- `Resolve-OpenXmlMergeOwner`
- `Get-OpenXmlMergeGroupOwnerRowRefs`
- `Write-OpenXmlCellText_DeterministicMerge`
- `Set-OpenXmlCellText`
- `Find-FirstRowByContains_OpenXml`
- `Find-FirstRowByContains_FromRow_OpenXml`
- `Test-OpenXmlDataSummaryHasData`
- `Write-OpenXmlSignDebug`
- `Find-OpenXmlCell`

## Core/OpenXmlSignatureWorkflow.ps1
- `Get-WorksheetSignatureTargets_OpenXml`
- `Resolve-WorksheetSignatureRows_OpenXml`
- `Get-WorksheetSignaturePlan_OpenXml`
- `Invoke-WorksheetSignature_OpenXml`
- `Verify-WorksheetSignatures_OpenXml`

Vad som medvetet inte ändrades:
- `Main.ps1` runtime-flöde
- modulernas laddningsordning i `Main.ps1`
- top-level WinForms-kod
- `.Add_Click(...)`, `.Controls.Add(...)`, `Application.Run(...)`
- `DataHelpers.ps1`, `RuleEngine.ps1`

Syftet med fas 6:
- fortsätta refactorera utan att röra startup-kritisk runtime-kod
- separera generisk OpenXML-infrastruktur från worksheet-signaturworkflow
- behålla exakt samma publik yta via shim-modulen
