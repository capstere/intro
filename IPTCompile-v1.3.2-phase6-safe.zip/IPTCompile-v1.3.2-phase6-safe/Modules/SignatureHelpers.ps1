﻿# Write-WorksheetSignatures (EPPlus) har ersatts av Invoke-WorksheetSignature_OpenXml i OpenXmlHelpers.ps1!!!!!
$__iptSignatureRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $__iptSignatureRoot 'Core\SignatureWorkflow.ps1')
. (Join-Path $__iptSignatureRoot 'App\UiSignatureDialogs.ps1')
. (Join-Path $__iptSignatureRoot 'Infrastructure\Forensics.ps1')
