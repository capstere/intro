﻿$__iptLoggingRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path $__iptLoggingRoot 'Infrastructure\LoggingCore.ps1')
. (Join-Path $__iptLoggingRoot 'App\UiLogging.ps1')
