﻿﻿# Safe shim for phase 6. Keeps original module path/runtime contract intact.
$__iptShimRoot = if ($PSScriptRoot) { Split-Path -Parent $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
. (Join-Path $__iptShimRoot 'Infrastructure\ExcelOpenXml.ps1')
. (Join-Path $__iptShimRoot 'Core\OpenXmlSignatureWorkflow.ps1')
Remove-Variable __iptShimRoot -ErrorAction SilentlyContinue
