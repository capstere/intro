﻿# WORK_ORDER_v1.3.1-phase5-safe.md

## Mål
Genomför fas 5 som en låg-risk refactor där endast rena funktionsdefinitioner delas upp, utan att förändra startup eller WinForms runtime-beteende.

## Genomfört
1. Skapa mappar:
   - `App`
   - `Core`
   - `Infrastructure`
2. Dela Logging i:
   - `Infrastructure/LoggingCore.ps1`
   - `App/UiLogging.ps1`
3. Ersätt `Modules/Logging.ps1` med shim som dot-sourcar de två filerna ovan.
4. Dela SignatureHelpers i:
   - `Core/SignatureWorkflow.ps1`
   - `App/UiSignatureDialogs.ps1`
   - `Infrastructure/Forensics.ps1`
5. Ersätt `Modules/SignatureHelpers.ps1` med shim som dot-sourcar de tre filerna ovan.
6. Uppdatera `Version.txt` till `1.3.1-phase5-safe`.

## Smoke test att köra i riktig miljö
1. Starta `Main.ps1`
2. Verifiera att appen öppnas
3. Verifiera att GUI-loggning fungerar
4. Verifiera att signaturdialog för Seal Test öppnas
5. Verifiera att worksheet-signaturdialog öppnas
6. Verifiera att `Update-BatchLink` fortfarande fungerar
7. Verifiera att forensic snapshot fortfarande kan skapas vid signaturfel

## Riskprofil
Låg.

Skäl:
- inga block klipptes ur top-level runtime i `Main.ps1`
- alla publika funktionsnamn behölls
- ursprungliga modulnamn behölls genom shim-filer
