﻿@{
    LastUpdated = '2026-03-11'

    Notes = @(
        'Upptäcker du något som är knas eller kan bli bättre?'
        'Skriv på teams eller skicka meddelande under "Instruktioner → Hjälp"'
	'Det är dina idéer och behov som formar verktyget. :) / Jesper'

    )

    Done = @(
        'Kontroll av datumtolkning från olika källor'
    )

    Ongoing = @(
        'Granskning av fler små visuella mismatchar i rapporten'
        'Kontroll av datumtolkning från olika källor'

    )

    Todo = @(
        'Se över Sample Reagent P/N-matchning för små formatavvikelser'
        'Dra-och-släpp implementerat för alla filer - KLART - men ej IT-PASS'
    )

}