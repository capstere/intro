# WORK_ORDER_v1.3.2-phase6-safe.md

## Mål
Genomför fas 6 som en låg-risk refactor där endast rena funktionsdefinitioner från `Modules/OpenXmlHelpers.ps1` delas upp, utan att förändra startup eller WinForms runtime-beteende.

## Genomfört
1. Behåll fas 5-strukturen oförändrad.
2. Skapa:
   - `Infrastructure/ExcelOpenXml.ps1`
   - `Core/OpenXmlSignatureWorkflow.ps1`
3. Flytta endast hela verifierade funktionsdefinitioner från `Modules/OpenXmlHelpers.ps1`.
4. Lägg generiska OpenXML-funktioner i `Infrastructure/ExcelOpenXml.ps1`.
5. Lägg worksheet-signaturrelaterade OpenXML-funktioner i `Core/OpenXmlSignatureWorkflow.ps1`.
6. Ersätt `Modules/OpenXmlHelpers.ps1` med shim som dot-sourcar de två filerna ovan.
7. Uppdatera `Version.txt` till `1.3.2-phase6-safe`.

## Smoke test att köra i riktig miljö
1. Starta `Main.ps1`
2. Verifiera att appen öppnas
3. Verifiera att GUI-loggning fungerar
4. Verifiera att worksheet-signering fortfarande fungerar
5. Verifiera att read-back/verify av worksheet-signatur fortfarande fungerar
6. Verifiera att OpenXML-baserad skrivning till workbook fortfarande fungerar
7. Verifiera att Data Summary-detektion fortfarande fungerar där den används

## Riskprofil
Låg.

Skäl:
- inga block klipptes ur top-level runtime i `Main.ps1`
- inga event handlers flyttades
- alla publika funktionsnamn behölls
- ursprungligt modulnamn behölls genom shim-fil
- `Modules/OpenXmlHelpers.ps1` innehöll endast funktionsdefinitioner, ingen top-level runtime-kod
