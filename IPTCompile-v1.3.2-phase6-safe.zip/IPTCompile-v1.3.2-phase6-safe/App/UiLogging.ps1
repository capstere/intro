﻿try { Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop } catch { }

function Get-GuiAppendAction {
    try {
        if ($script:__GuiAppendAction) { return $script:__GuiAppendAction }
    } catch {}

    $script:__GuiAppendAction = [System.Action[System.Windows.Forms.TextBox,string]]{
        param($tbox, $text)
        $tbox.AppendText("$text`r`n")
        $tbox.SelectionStart = $tbox.TextLength
        $tbox.ScrollToCaret()
        $tbox.Refresh()
    }
    return $script:__GuiAppendAction
}

function Get-OutputBox {
    try { return $script:outputBox } catch { return $null }
}

function Set-LogOutputControl {
    param([System.Windows.Forms.TextBox]$Control)
    $script:outputBox = $Control
}

function Get-GuiLogVerbosity {
    try {
        $v = $null
        if (Test-HasGetConfigValue) {
            $v = Get-ConfigValue -Name 'GuiLogVerbosity' -Default $null
        } elseif ($global:Config) {
            $v = $global:Config['GuiLogVerbosity']
        }
        $v = ($v + '').Trim().ToUpperInvariant()
        if ($v) { return $v }
    } catch { }
    return 'DEV'
}

function Get-GuiLogList {
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [string[]]$Default
    )
    $v = $null
    try {
        if (Test-HasGetConfigValue) {
            $v = Get-ConfigValue -Name $Name -Default $Default
        } elseif ($global:Config) {
            $v = $global:Config[$Name]
        }
    } catch { $v = $null }

    if ($null -eq $v) { return @($Default) }
    if ($v -is [string]) { return @($v) }
    return @($v)
}

function Should-LogToGui {
    param(
        [ValidateSet('Info','Warn','Error')][string]$Severity,
        [string]$Category = 'UI'
    )
    $v = Get-GuiLogVerbosity
    $cat = ($Category + '').Trim().ToUpperInvariant()

    if ($v -eq 'DEV') { return $true }

    if ($v -eq 'QUIET') {
        if ($Severity -eq 'Error') { return $true }
        if ($Severity -eq 'Warn') { return $true }
        $allow = Get-GuiLogList -Name 'GuiLogInfoCategoriesQuiet' -Default @('SUMMARY','RESULT','USER') |
            ForEach-Object { (($_ + '').Trim()).ToUpperInvariant() }
        return ($allow -contains $cat)
    }

    if ($Severity -eq 'Error') { return $true }
    if ($Severity -eq 'Warn')  { return $true }
    $hide = Get-GuiLogList -Name 'GuiLogInfoHiddenCategoriesNormal' -Default @('DEBUG','SANITY','PROGRESS','RuleEngineStats','RuleEngineDev') |
        ForEach-Object { (($_ + '').Trim()).ToUpperInvariant() }
    return ($hide -notcontains $cat)
}

function Gui-Log {
    param(
        [string]$Text,
        [ValidateSet('Info', 'Warn', 'Error')]
        [string]$Severity = 'Info',
        [string]$Category = 'UI',
        [hashtable]$Data,
        [switch]$Immediate
    )

    $prefix = switch ($Severity) {
        'Warn'  { '' }
        'Error' { '' }
        default { '' }
    }

    $timestamp = (Get-Date).ToString('HH:mm:ss')
    $line = "[$timestamp] $prefix $Text"

    $showToGui = $true
    try { $showToGui = (Should-LogToGui -Severity $Severity -Category $Category) } catch { $showToGui = $true }

    if ($showToGui) {
        $outputBox = Get-OutputBox

        if ($outputBox) {
            try {
                if ($outputBox.IsDisposed -or -not $outputBox.IsHandleCreated) {
                    $outputBox = $null
                }
            } catch {
                $outputBox = $null
            }
        }

        if ($outputBox) {
            try {
                $tb  = $outputBox
                $msg = $line
                $append = Get-GuiAppendAction

                if ($tb.InvokeRequired) {
                    $null = $tb.BeginInvoke($append, @($tb, $msg))
                } else {
                    $append.Invoke($tb, $msg)
                }

                if ($Immediate) {
                    [System.Windows.Forms.Application]::DoEvents()
                }
            } catch {
                Write-Host $line
            }
        } else {
            Write-Host $line
        }
    }

    try {
        Write-StructuredLog -Message $Text -Severity $Severity -Category $Category -Context $Data
    } catch {}

    if ($global:LogPath) {
        try {
            Add-Content -LiteralPath $global:LogPath -Value $line -Encoding UTF8
        } catch {
            Write-Host "Loggning misslyckades: $($_.Exception.Message)"
        }
    }
}
