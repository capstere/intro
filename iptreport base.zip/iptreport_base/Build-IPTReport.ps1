﻿# Build-IPTReport.ps1
#
# Genererar en IPT-rapport som JSON + HTML från en hashtable.
# PS 5.1-kompatibel. Inga externa beroenden.
#
# Användning:
#
#     . .\Build-IPTReport.ps1
#
#     $report = New-IPTReportObject `
#         -ScriptVersion 'v1.4.3' `
#         -GeneratedBy 'jesper.fredriksson' `
#         -CsvFile 'C03FEB25A_QC.csv' `
#         -Lsp '12345' `
#         -TestCount 80
#
#     # Fyll på fler sektioner via egenskaper på $report
#     # ...
#
#     $paths = Save-IPTReport `
#         -Report $report `
#         -OutputDir 'C:\Output' `
#         -BaseName 'C03FEB25A_QC_2026-05-08' `
#         -TemplatePath '.\report_template.html'
#
#     # $paths.Json = path till .json
#     # $paths.Html = path till .html

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

# -----------------------------------------------------------------------------
# Schema-helpers
# -----------------------------------------------------------------------------

function New-IPTField {
    <#
    .SYNOPSIS
        Bygger ett field-objekt: { value, expected, status, displayValue (frivilligt) }
    .DESCRIPTION
        Status räknas ut automatiskt om Expected anges:
          - value tom + expected angivet → "missing"
          - value == expected → "match"
          - värdena skiljer sig → "mismatch"
        Status kan överstyras med -Status.
    #>
    param(
        [string]$Value = '',
        [string]$Expected = '',
        [string]$DisplayValue,
        [ValidateSet('match','mismatch','missing','warning','')]
        [string]$Status = ''
    )

    if (-not $Status) {
        if ([string]::IsNullOrWhiteSpace($Value)) {
            $Status = 'missing'
        } elseif ([string]::IsNullOrWhiteSpace($Expected)) {
            $Status = 'match'
        } elseif ($Value.Trim() -eq $Expected.Trim()) {
            $Status = 'match'
        } else {
            $Status = 'mismatch'
        }
    }

    $obj = [ordered]@{
        value    = $Value
        expected = if ([string]::IsNullOrWhiteSpace($Expected)) { $null } else { $Expected }
        status   = $Status
    }

    if ($PSBoundParameters.ContainsKey('DisplayValue') -and $DisplayValue) {
        $obj['displayValue'] = $DisplayValue
    }

    return [pscustomobject]$obj
}

function New-IPTReportObject {
    <#
    .SYNOPSIS
        Bygger toppnivåskelettet för en rapport. Sektioner som inte fylls får default-tomma värden.
    #>
    param(
        [Parameter(Mandatory)][string]$ScriptVersion,
        [string]$ScriptVersionDate = (Get-Date -Format 'yyyy-MM-dd'),
        [Parameter(Mandatory)][string]$GeneratedBy,
        [string]$FullName = '',
        [string]$MinitabMacro = '',
        [Parameter(Mandatory)][string]$CsvFile,
        [string]$CsvFileResample = '',
        [Parameter(Mandatory)][string]$Lsp,
        [int]$TestCount = 0,
        [string]$InfinityBags = ''
    )

    $now = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ssK')

    return [pscustomobject][ordered]@{
        schemaVersion = '1.0'
        metadata = [pscustomobject][ordered]@{
            scriptVersion     = $ScriptVersion
            scriptVersionDate = $ScriptVersionDate
            generatedAt       = $now
            generatedBy       = $GeneratedBy
            fullName          = $FullName
            minitabMacro      = $MinitabMacro
        }
        run = [pscustomobject][ordered]@{
            csvFile            = $CsvFile
            csvFileResample    = if ([string]::IsNullOrWhiteSpace($CsvFileResample)) { $null } else { $CsvFileResample }
            lsp                = $Lsp
            testCount          = $TestCount
            infinityBags       = $InfinityBags
            duplicateSampleIds = @()
        }
        documentControl = [pscustomobject][ordered]@{
            worksheet   = $null
            sealTestPos = $null
            sealTestNeg = $null
        }
        summaries = [pscustomobject][ordered]@{
            data = $null
            qc   = $null
            stf  = $null
        }
        equipment = @()
        links = [pscustomobject][ordered]@{
            sharepoint  = $null
            iptApp      = $null
            mesLogin    = $null
            csvUploader = $null
            bmram       = $null
            agile       = $null
        }
        signatures = [pscustomobject][ordered]@{
            sealTestPos      = $null
            sealTestNeg      = $null
            worksheet        = $null
            sammanstallning  = $null
            granskning       = $null
        }
    }
}

function New-IPTSignature {
    param(
        [string]$SignedBy,
        [string]$Initials,
        [string]$SignedAt = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ssK')
    )

    if ([string]::IsNullOrWhiteSpace($SignedBy)) { return $null }

    return [pscustomobject][ordered]@{
        signedBy = $SignedBy
        initials = $Initials
        signedAt = $SignedAt
    }
}

function New-IPTQcRow {
    param(
        [string]$SampleId,
        [string]$Assay,
        [string]$TestType,
        [string]$ExpectedCall,
        [string]$ObservedCall,
        [string]$Deviation,
        [string]$Category,
        [string[]]$RuleFlags = @(),
        [string]$Notering = '',
        [string]$ErrorCode
    )

    return [pscustomobject][ordered]@{
        sampleId     = $SampleId
        assay        = $Assay
        testType     = $TestType
        expectedCall = $ExpectedCall
        observedCall = $ObservedCall
        deviation    = if ([string]::IsNullOrWhiteSpace($Deviation)) { $null } else { $Deviation }
        category     = $Category
        ruleFlags    = $RuleFlags
        notering     = $Notering
        errorCode    = if ([string]::IsNullOrWhiteSpace($ErrorCode)) { $null } else { $ErrorCode }
    }
}

# -----------------------------------------------------------------------------
# Serialisering + filskrivning
# -----------------------------------------------------------------------------

function ConvertTo-IPTReportJson {
    <#
    .SYNOPSIS
        Serialiserar en rapport-PSObject till en JSON-sträng.
    .DESCRIPTION
        Använder ConvertTo-Json med tillräckligt depth för nested arrays/objects.
        Returnerar en sträng — anroparen sparar/visar.
    #>
    param(
        [Parameter(Mandatory, ValueFromPipeline)]$Report
    )

    return ($Report | ConvertTo-Json -Depth 12)
}

function Build-IPTReportHtml {
    <#
    .SYNOPSIS
        Bygger HTML-strängen genom att läsa mallen och bädda in JSON.
    .DESCRIPTION
        Mallen ska innehålla en placeholder __REPORT_DATA__ inuti
        <script id="report-data" type="application/json">.
        Den ersätts med JSON-strängen.
    #>
    param(
        [Parameter(Mandatory)]$Report,
        [Parameter(Mandatory)][string]$TemplatePath
    )

    if (-not (Test-Path -LiteralPath $TemplatePath)) {
        throw "Mall hittas inte: $TemplatePath"
    }

    $tpl = [System.IO.File]::ReadAllText($TemplatePath, [System.Text.Encoding]::UTF8)

    if ($tpl -notmatch '__REPORT_DATA__') {
        throw "Mallen saknar placeholder __REPORT_DATA__: $TemplatePath"
    }

    $json = ConvertTo-IPTReportJson -Report $Report

    # </script> i JSON måste escapas så HTML-parsern inte stänger script-blocket tidigt.
    # Standardlösning: ersätt </ med <\/.
    $jsonSafe = $json -replace '</', '<\/'

    # Direkt sträng-ersättning (inte regex — JSON-data kan innehålla $-tecken som
    # PowerShell-regex skulle tolka som backreferenser).
    return $tpl.Replace('__REPORT_DATA__', $jsonSafe)
}

function Save-IPTReport {
    <#
    .SYNOPSIS
        Sparar rapporten som .json + .html bredvid varandra.
    .OUTPUTS
        PSObject med Json och Html paths.
    #>
    param(
        [Parameter(Mandatory)]$Report,
        [Parameter(Mandatory)][string]$OutputDir,
        [Parameter(Mandatory)][string]$BaseName,
        [Parameter(Mandatory)][string]$TemplatePath
    )

    if (-not (Test-Path -LiteralPath $OutputDir)) {
        New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
    }

    $jsonPath = Join-Path $OutputDir ($BaseName + '.json')
    $htmlPath = Join-Path $OutputDir ($BaseName + '.html')

    $utf8Bom = New-Object System.Text.UTF8Encoding($true)

    $json = ConvertTo-IPTReportJson -Report $Report
    [System.IO.File]::WriteAllText($jsonPath, $json, $utf8Bom)

    $html = Build-IPTReportHtml -Report $Report -TemplatePath $TemplatePath
    [System.IO.File]::WriteAllText($htmlPath, $html, $utf8Bom)

    return [pscustomobject]@{
        Json = $jsonPath
        Html = $htmlPath
    }
}

# -----------------------------------------------------------------------------
# Demo: körs bara om scriptet anropas direkt (inte dot-source:as)
# -----------------------------------------------------------------------------
if ($MyInvocation.InvocationName -ne '.' -and $MyInvocation.Line -notmatch '^\.\s+') {
    Write-Host 'Build-IPTReport.ps1 — demo-körning' -ForegroundColor Cyan
    Write-Host ''

    $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
    $template  = Join-Path $scriptDir 'report_template.html'
    $outDir    = Join-Path $scriptDir 'demo_output'

    $report = New-IPTReportObject `
        -ScriptVersion 'v1.4.3' `
        -ScriptVersionDate '2026-05-05' `
        -GeneratedBy 'jesper.fredriksson' `
        -FullName 'Jesper Fredriksson' `
        -MinitabMacro 'MiniTab Macro vs2.1' `
        -CsvFile 'C03FEB25A_QC.csv' `
        -Lsp '12345' `
        -TestCount 80 `
        -InfinityBags 'Bag-A4123, Bag-A4124'

    $report.documentControl.worksheet = [pscustomobject][ordered]@{
        partNo         = New-IPTField -Value '111-2222' -Expected '111-2222'
        cartridgeNo    = New-IPTField -Value '12345'    -Expected '12345'
        batchNumbers   = New-IPTField -Value 'B5523001, B5523002' -Expected 'B5523001, B5523002'
        documentNumber = New-IPTField -Value 'WS-1234'  -Expected 'WS-1234'
        rev            = New-IPTField -Value 'Rev 5'    -Expected 'Rev 5'
        effective      = New-IPTField -Value '2026-01-15' -DisplayValue '01/15/2026' -Expected '2026-01-15'
    }

    $report.documentControl.sealTestPos = [pscustomobject][ordered]@{
        documentNumber = New-IPTField -Value 'ST-POS-001' -Expected 'ST-POS-001'
        rev            = New-IPTField -Value 'Rev 3' -Expected 'Rev 3'
        effective      = New-IPTField -Value '2025-11-20' -DisplayValue '11/20/2025' -Expected '2025-11-20'
    }

    $report.documentControl.sealTestNeg = [pscustomobject][ordered]@{
        documentNumber = New-IPTField -Value 'ST-NEG-001' -Expected 'ST-NEG-001'
        rev            = New-IPTField -Value 'Rev 3' -Expected 'Rev 4'
        effective      = New-IPTField -Value '2025-11-20' -DisplayValue '11/20/2025' -Expected '2026-02-01'
    }

    $report.summaries.data = [pscustomobject][ordered]@{
        delaminationCount = 1
        replacementCount  = 2
        findings = @(
            [pscustomobject]@{ sampleId='C03FEB25A_04_0_11+'; type='Delamination'; details='Delam token: D2' }
            [pscustomobject]@{ sampleId='C03FEB25A_05_1_07';  type='Replacement';  details='Replacement level 1' }
            [pscustomobject]@{ sampleId='C03FEB25A_06_2_03';  type='Replacement';  details='Replacement level 1' }
        )
    }

    $report.summaries.qc = [pscustomobject][ordered]@{
        totalRows = 80
        rows = @(
            New-IPTQcRow -SampleId 'C03FEB25A_04_0_11+' -Assay 'Xpert Carba-R' -TestType 'Positive Control 1' `
                -ExpectedCall 'MTB DETECTED' -ObservedCall 'MTB NOT DETECTED' `
                -Deviation 'False Negative' -Category 'Major Functional' `
                -RuleFlags @('TESTTYPE_MISMATCH') -Notering 'Fel Test Type' -ErrorCode 'INVALID'

            New-IPTQcRow -SampleId 'C03FEB25A_07_3_22' -Assay 'Xpert Carba-R' -TestType 'Specimen' `
                -ExpectedCall 'Negative' -ObservedCall 'Positive' `
                -Deviation 'False Positive' -Category 'Major Functional'

            New-IPTQcRow -SampleId 'C03FEB25A_12_4_08' -Assay 'Xpert Carba-R' -TestType 'Specimen' `
                -ExpectedCall 'Detected' -ObservedCall 'Indeterminate' `
                -Deviation 'Minor Functional' -Category 'Minor Functional' -ErrorCode 'Indeterminate'
        )
    }

    $report.summaries.stf = [pscustomobject][ordered]@{
        totalSheets   = 8
        totalFailures = 1
        perSheet = @(
            [pscustomobject]@{ sheet='Data 1'; failures=0 }
            [pscustomobject]@{ sheet='Data 2'; failures=0 }
            [pscustomobject]@{ sheet='Data 3'; failures=1 }
            [pscustomobject]@{ sheet='Data 4'; failures=0 }
            [pscustomobject]@{ sheet='Data 5'; failures=0 }
            [pscustomobject]@{ sheet='Data 6'; failures=0 }
            [pscustomobject]@{ sheet='Data 7'; failures=0 }
            [pscustomobject]@{ sheet='Data 8'; failures=0 }
        )
    }

    $report.equipment = @(
        [pscustomobject]@{ system='GX-001'; polarity='POS'; calDue='Mar-26'; calDueDate='2026-03-31'; status='valid' }
        [pscustomobject]@{ system='GX-002'; polarity='POS'; calDue='Apr-26'; calDueDate='2026-04-30'; status='valid' }
        [pscustomobject]@{ system='GX-003'; polarity='NEG'; calDue='Jun-26'; calDueDate='2026-06-30'; status='valid' }
        [pscustomobject]@{ system='GX-005'; polarity='NEG'; calDue='Jan-25'; calDueDate='2025-01-31'; status='expired' }
    )

    $report.links.sharepoint  = 'https://danaher.sharepoint.com/sites/CEP-Sweden-Production-Management/Lists/.../ROBAL.aspx?q=12345'
    $report.links.iptApp      = 'https://iptapp.example.com/order/12345'
    $report.links.mesLogin    = 'https://mes.example.com/login'
    $report.links.csvUploader = 'https://csvupload.example.com/upload'
    $report.links.bmram       = 'https://bmram.example.com/order/12345'
    $report.links.agile       = 'https://agile.example.com/doc/WS-1234'

    $report.signatures.sealTestPos = New-IPTSignature -SignedBy 'Jesper Fredriksson' -Initials 'JF'
    $report.signatures.sealTestNeg = New-IPTSignature -SignedBy 'Jesper Fredriksson' -Initials 'JF'

    $paths = Save-IPTReport `
        -Report $report `
        -OutputDir $outDir `
        -BaseName 'demo_report' `
        -TemplatePath $template

    Write-Host ('JSON: ' + $paths.Json) -ForegroundColor Green
    Write-Host ('HTML: ' + $paths.Html) -ForegroundColor Green
    Write-Host ''
    Write-Host 'Öppna HTML-filen i webbläsaren för att se resultatet.'
}
