# IPT Report — JSON Schema (v1.0)

Detta är **kontraktet** mellan IPTCompile och alla framtida viewers.
Om schemat ändras → bumpa `schemaVersion`. Visa-sidan kollar versionen och kan
varna om den är inkompatibel.

## Designprinciper

1. **Status är ett enum, inte en sträng.** `"match" | "mismatch" | "missing" | "warning"` —
   inte "Match" eller "OK" eller "✓". Renderingen översätter till svenska/engelska/färg
   beroende på viewer.
2. **Visningsformat och kanoniskt format separeras.** Datum lagras som ISO 8601 i `value`,
   och originalformatet i `displayValue`. Viewer väljer vad den vill visa.
3. **Inget HTML, ingen Excel-styling i JSON.** JSON är ren data. Presentationsval görs
   av viewern.
4. **Kompatibel addition är OK utan version-bump.** Att lägga till nya frivilliga fält
   är bakåtkompatibelt. Att ta bort fält eller ändra semantik kräver version-bump.
5. **Tomma sektioner anges explicit som `null` eller `[]`.** Inte saknade nycklar — det
   gör viewern enklare ("om det finns en QC summary, rendera; annars sektionen visas inte").

## Toppnivåstruktur

```json
{
  "schemaVersion": "1.0",
  "metadata": { ... },
  "run": { ... },
  "documentControl": { ... },
  "summaries": { ... },
  "equipment": [ ... ],
  "links": { ... },
  "signatures": { ... }
}
```

## metadata

Vem byggde rapporten, när, med vilken version.

```json
"metadata": {
  "scriptVersion": "v1.4.3",
  "scriptVersionDate": "2026-05-05",
  "generatedAt": "2026-05-08T14:23:00+02:00",
  "generatedBy": "jesper.fredriksson",
  "fullName": "Jesper Fredriksson",
  "minitabMacro": "MiniTab Macro vs2.1"
}
```

`generatedAt` är ISO 8601 med tidszon. Viewer kan visa lokal tid.

## run

Vad körningen handlar om.

```json
"run": {
  "csvFile": "C03FEB25A_QC.csv",
  "csvFileResample": null,
  "lsp": "12345",
  "testCount": 80,
  "infinityBags": "Bag123, Bag456",
  "duplicateSampleIds": []
}
```

`csvFileResample` är `null` när det inte finns en resample-CSV. `duplicateSampleIds` är
array — tom om inga dubletter.

## documentControl

Header-jämförelser. Varje fält har samma struktur.

```json
"documentControl": {
  "worksheet": {
    "partNo":         { "value": "111-2222", "expected": "111-2222", "status": "match" },
    "cartridgeNo":    { "value": "12345",    "expected": "12345",    "status": "match" },
    "batchNumbers":   { "value": "B001, B002", "expected": "B001, B002", "status": "match" },
    "documentNumber": { "value": "DOC-1234", "expected": "DOC-1234", "status": "match" },
    "rev":            { "value": "Rev 5",    "expected": "Rev 5",    "status": "match" },
    "effective":      { "value": "2026-01-15", "displayValue": "01/15/2026", "expected": "2026-01-15", "status": "match" }
  },
  "sealTestPos": { ... },
  "sealTestNeg": { ... }
}
```

**Status-värden:**
- `"match"` — `value` matchar `expected`
- `"mismatch"` — värdena skiljer sig
- `"missing"` — `value` saknas helt (ex: tom Cartridge No-cell)
- `"warning"` — finns ett värde, men något är konstigt (ex: ovanligt format)

`expected` får vara `null` om inget förväntat värde finns att jämföra mot. Viewern kan då
visa `value` utan färgkodning.

`displayValue` är frivillig — bara för fält där det kanoniska och visade formatet skiljer
sig (typ datum). Om frånvarande, visa `value`.

## summaries

Tre sub-summaries: Data Summary, QC Summary, STF Summary.

```json
"summaries": {
  "data": {
    "delaminationCount": 0,
    "replacementCount": 2,
    "findings": [
      { "sampleId": "...", "type": "Replacement", "details": "..." }
    ]
  },
  "qc": {
    "totalRows": 80,
    "rows": [
      {
        "sampleId": "C03FEB25A_04_0_11+",
        "assay": "Xpert Carba-R",
        "testType": "Positive Control 1",
        "expectedCall": "MTB DETECTED",
        "observedCall": "MTB NOT DETECTED",
        "deviation": "False Negative",
        "category": "Major Functional",
        "ruleFlags": ["TESTTYPE_MISMATCH"],
        "notering": "Fel Test Type",
        "errorCode": "INVALID"
      }
    ]
  },
  "stf": {
    "totalSheets": 8,
    "totalFailures": 1,
    "perSheet": [
      { "sheet": "Data 1", "failures": 0 },
      { "sheet": "Data 2", "failures": 1 }
    ]
  }
}
```

Notera: `qc.rows` innehåller bara avvikelser, inte alla 80 testrader. `totalRows` är
antalet i CSV — inte antalet rader i `rows`-arrayen.

`deviation`-värden från regelmotorn:
`"False Positive"`, `"False Negative"`, `"Mismatch"`, `"Minor Functional"`,
`"Major Functional"`, `"Instrument Error"`, `"Other"`, eller `null`.

`category` följer samma terminologi.

`ruleFlags` är en array av maskinläsbara flaggor från regelmotorn (`TESTTYPE_MISMATCH`,
`DQ_ASSAY_OUTLIER`, etc.). `notering` är den svenska visningstexten som annars hade
hamnat i Notering-kolumnen i Excel.

## equipment

Lista över instrument som användes och deras kalibreringsstatus.

```json
"equipment": [
  {
    "system": "GX-001",
    "polarity": "POS",
    "calDue": "Mar-26",
    "calDueDate": "2026-03-31",
    "status": "valid"
  },
  {
    "system": "GX-005",
    "polarity": "NEG",
    "calDue": "Jan-25",
    "calDueDate": "2025-01-31",
    "status": "expired"
  }
]
```

`calDue` är display-format. `calDueDate` är kanoniskt (sista dagen i månaden). `status`
är en av `"valid" | "expired" | "unknown"`.

## links

Snabblänkar — samma som "Snabblänkar"-sektionen i Excel-rapporten.

```json
"links": {
  "sharepoint":   "https://danaher.sharepoint.com/...",
  "iptApp":       "https://...",
  "mesLogin":     "https://...",
  "csvUploader":  "https://...",
  "bmram":        "https://...",
  "agile":        "https://..."
}
```

Värden får vara `null` om länken inte finns/inte är tillgänglig. Viewern visar då bara
inte den specifika länken.

## signatures

Vem som signerat vad.

```json
"signatures": {
  "sealTestPos":  { "signedBy": "Jesper Fredriksson", "initials": "JF", "signedAt": "2026-05-08T14:20:00+02:00" },
  "sealTestNeg":  { "signedBy": "Jesper Fredriksson", "initials": "JF", "signedAt": "2026-05-08T14:21:00+02:00" },
  "worksheet":    null,
  "sammanstallning": null,
  "granskning":      null
}
```

`null` betyder "ej signerad". Frånvaro av nyckel betyder "stöds inte / inte tillämpligt".

---

## Versionshantering

**Bakåtkompatibla ändringar (samma `schemaVersion`):**
- Lägga till nya valfria fält
- Lägga till nya `status`-värden om viewern har en fallback för okända

**Inkompatibla ändringar (bumpa `schemaVersion`):**
- Ändra fältsemantik
- Ta bort fält
- Byta typ på ett fält (sträng → tal etc.)
- Förändra status-enum så att gamla värden inte längre stöds

Viewern bör kolla `schemaVersion` vid laddning och visa varning vid major-mismatch.

## Att tänka på framöver

- **Aggregering över rapporter** — om du senare vill ha en historik-vy, är det här
  schemat redan queryable. Du kan ladda 100 JSON-filer i en SQLite-databas eller
  Power Query.
- **Diffning** — två rapporter med samma struktur kan jämföras programmatiskt
  (t.ex. `Compare-Object` på flatten:ade JSON).
- **Validering** — det här schemat kan formaliseras som JSON Schema (json-schema.org)
  vid behov, men det är inte nödvändigt nu.
