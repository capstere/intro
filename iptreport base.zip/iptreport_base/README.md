# IPT Report — HTML/JSON-bas

En lättviktig bas för att generera IPT-rapporter som **strukturerad data + visning**
istället för (eller parallellt med) Excel.

Det här är inte en färdig produkt. Det är ett experiment-underlag du kan ta och växa.

## Filer

| Fil | Vad |
|---|---|
| `SCHEMA.md` | Kontraktet — beskriver JSON-strukturen med exempel och designprinciper |
| `sample_report.json` | Exempelfil med realistisk data (kan användas direkt för att testa viewern) |
| `report_template.html` | Single-file HTML-mall (CSS+JS embedded). Innehåller en placeholder för JSON. |
| `Build-IPTReport.ps1` | PowerShell-generator som producerar JSON och HTML från ett PSObject |
| `demo_output/` | Skapas av Build-IPTReport.ps1 vid demo-körning. Innehåller `demo_report.json` + `demo_report.html` |

## Snabbstart

### Bara titta på vad det blir

Öppna `report_template.html` i en texteditor, ersätt `__REPORT_DATA__` med innehållet
i `sample_report.json`, spara som något annat, dubbelklicka. Klart.

Eller — kör PS-scriptet:

```powershell
.\Build-IPTReport.ps1
```

Det skapar `demo_output\demo_report.html` och `demo_output\demo_report.json`. Öppna
HTML-filen i webbläsaren.

### Använd från eget script

```powershell
. .\Build-IPTReport.ps1   # dot-source (laddar funktionerna utan att köra demo)

$report = New-IPTReportObject `
    -ScriptVersion 'v1.4.3' `
    -GeneratedBy 'jesper.fredriksson' `
    -CsvFile 'C03FEB25A_QC.csv' `
    -Lsp '12345' `
    -TestCount 80

# Fyll på data
$report.documentControl.worksheet = [pscustomobject][ordered]@{
    partNo      = New-IPTField -Value '111-2222' -Expected '111-2222'
    cartridgeNo = New-IPTField -Value '12345'    -Expected '12345'
    # ...
}

# Spara båda formaten
$paths = Save-IPTReport `
    -Report $report `
    -OutputDir 'C:\Output' `
    -BaseName 'C03FEB25A_QC' `
    -TemplatePath '.\report_template.html'

# $paths.Json och $paths.Html innehåller sökvägarna
```

## Designval (varför det ser ut som det gör)

### Single-file HTML utan externa beroenden
HTML-mallen har all CSS och JS inbäddad. Ingen CDN, ingen Google Fonts, ingen jQuery.
Filen fungerar offline, dubbelklickad direkt från Utforskaren. Det är vad du vill för
en rapport som ska ligga i en projektmapp, mailas, eller sparas i ett arkiv i 5 år.

### Endast Windows-default-fonter
Cambria (serif body), Segoe UI (sans headers), Consolas (mono data values). Alla
finns på alla Windows 10/11. Inga "saknad font"-fallbacks som ger fel utseende.

### Lab report-estetik, inte dashboard
Smal kolumn (~820px), generös whitespace, tunna avdelare, status som diskret
färg-pillar — inte stora färgade kort. Det är en QC-rapport, inte en marknadsförings-
slide. En senior analytiker ska känna att det är skrivet i samma genre som ett
peer-reviewed-artikel.

### Print-vänlig som standard
`@media print`-regler är inbyggda. Sökrutan döljs vid utskrift, länkarna visar sina
URL:er i parentes, A4-marginaler. Du kan göra "Skriv ut → Spara som PDF" och få
en arkivvänlig version.

### Status som enum, inte sträng
JSON använder `"match" | "mismatch" | "missing" | "warning"` — viewern översätter till
visningstext. Att lägga till en svensk översättning, byta till engelska, eller använda
andra färger görs på ett ställe.

### Kanonisk + display-format separat
Datum lagras som ISO 8601 (`"2026-01-15"`) i `value`, originalet i `displayValue`
(`"01/15/2026"`). Det betyder att en framtida historik-databas kan sortera/filtrera på
faktiska datum samtidigt som rapporter visar formatet användaren förväntar sig.

## Hur du integrerar med IPTCompile

Inte direkt — det finns ingen integration än. Tanken är att du kan börja experimentera
i lugn och ro. När/om du bestämmer dig för att gå vidare:

**Förslag som stegplan:**

1. **Steg A — generera JSON som biprodukt vid varje bygge.** Kräver inga viewer-beslut.
   I `App/BuildFlow/08B_SaveFile.ps1` kan du efter Excel-saven anropa `Save-IPTReport`
   med samma BaseName men en ny outputmapp. JSON-filen blir en sidoutput utan att
   påverka Excel-flödet.

2. **Steg B — generera HTML parallellt.** Samma sak, samma anrop. Du har båda formaten
   under en testperiod. Validerare/användare kan jämföra.

3. **Steg C — bestäm vad som blir kanoniskt.** Utvärdera efter ~20-50 byggen. Om HTML
   håller, kan Excel slås av eller bara genereras på begäran.

För att göra steg A behöver du en **mapping-funktion** som tar de data-objekt
IPTCompile redan har (Summary, RuleEngineResult, headers, etc.) och bygger ett
`$report`-objekt. Det är ~100-200 rader PS-kod, kan ligga i `Core/ReportExport.ps1`.

## Vad basen INTE löser

- **Aggregat över rapporter.** Visar en rapport, inte historik. Om du vill jämföra
  10 rapporter behöver du en separat viewer som indexerar JSON-filerna.
- **Editerbarhet efter bygge.** HTML-rapporten är skrivskyddad. Om en granskare vill
  lägga till anteckningar måste de göra det någon annanstans (SharePoint, separat
  anteckningsfil).
- **Compliance-stämpel/digital signatur.** För regulatorisk arkivering krävs ofta
  en digital signering (timestamping, X.509). Det är ett separat lager — du kan
  fortfarande använda Excel-rapporten med signering, och låta JSON/HTML vara intern
  arbetsversion.

## Schemaversionering

`schemaVersion` är 1.0 just nu. Bakåtkompatibla tillägg (nya valfria fält) kan göras
utan version-bump. Brytande ändringar bumpar major-versionen.

Viewern kollar `schemaVersion` vid laddning och visar varning vid major-mismatch.
Det betyder att gamla viewers kan öppna nyare data och tvärtom — med en tydlig
disclaimer när semantiken kan ha ändrats.

Se `SCHEMA.md` för fullständig dokumentation.

## Begränsningar att veta om

- **Inga externa fonter.** Estetiken är därför "konservativ" — om du senare vill ha
  tex Inter eller IBM Plex får du embedda dem som base64 (~30-50KB) eller acceptera
  CDN-beroende.
- **Ingen JS-validering av schema.** Viewern visar vad som finns, hoppar över sektioner
  som saknas. Om du producerar trasig JSON ser du blanka sektioner istället för fel.
  För strikt validering kan du bygga ett separat `Test-IPTReport.ps1`.
- **Sortering är text-baserad** för icke-numeriska kolumner. För svenska tecken används
  `localeCompare(av, 'sv')`. Om någon kolumn behöver custom-sortering måste viewern
  utökas.

## Filer du säkert kan röra/anpassa

- **HTML-mallen:** Allt utseende ligger där. Lek med färger, fonter, layouten. JS-logiken
  (`init`, `renderRun`, `renderQc`, etc.) är liten och läsbar.
- **`Build-IPTReport.ps1`:** Lägg till nya helpers (`New-IPTField`-varianter etc.)
  efter behov.
- **`SCHEMA.md`:** Uppdatera vid ändringar. Den ska alltid matcha verkligheten.

## Filer du inte ska röra utan att tänka

- **JSON-schemats fältnamn** — när du börjat producera produktionsrapporter måste
  fältnamnen vara stabila för att gamla rapporter ska kunna läsas av framtida
  viewers. Bumpa `schemaVersion` istället.
- **`schemaVersion`-värdet** — bara bumpa vid faktiska brytande ändringar.
