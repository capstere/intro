﻿function Resolve-OpenXmlDllPath {
    param(
        [Parameter(Mandatory=$true)][string]$ModulesRoot
    )

    $candidates = New-Object System.Collections.Generic.List[string]

    try {
        if ($global:LibRoot -and ($global:LibRoot -ne $ModulesRoot)) {
            $lib = ($global:LibRoot + '')
            if ($lib) {
                $candidates.Add((Join-Path $lib 'DocumentFormat.OpenXml.dll')) | Out-Null
            }
        }
    } catch {}

    $candidates.Add((Join-Path $ModulesRoot 'DocumentFormat.OpenXml.dll'))

    $candidates.Add((Join-Path $ModulesRoot 'OpenXMLSDK\DocumentFormat.OpenXml.2.20.0\lib\net46\DocumentFormat.OpenXml.dll'))
    $candidates.Add((Join-Path $ModulesRoot 'OpenXMLSDK\DocumentFormat.OpenXml.2.20.0\lib\net40\DocumentFormat.OpenXml.dll'))

    $candidates.Add((Join-Path $ModulesRoot 'OpenXMLSDK\lib\net46\DocumentFormat.OpenXml.dll'))
    $candidates.Add((Join-Path $ModulesRoot 'OpenXMLSDK\lib\net40\DocumentFormat.OpenXml.dll'))

    foreach ($p in $candidates) {
        if (Test-Path -LiteralPath $p) { return $p }
    }
    return $null
}

function Import-OpenXmlSdk {
    param(
        [Parameter(Mandatory=$true)][string]$ModulesRoot
    )

    if ([AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GetName().Name -eq 'DocumentFormat.OpenXml' }) {
        return $true
    }

    $dllPath = Resolve-OpenXmlDllPath -ModulesRoot $ModulesRoot
    if ($dllPath -and (Test-Path -LiteralPath $dllPath)) {
        try {
            $bytes = [System.IO.File]::ReadAllBytes($dllPath)
            [void][System.Reflection.Assembly]::Load($bytes)
            return $true
        } catch {
            throw "Kunde inte ladda OpenXML DLL: $dllPath`n$($_.Exception.Message)"
        }
    }

    $b64Path = $null
    try { if ($global:LibRoot) { $b64Path = Join-Path $global:LibRoot 'OpenXMLAssembly.txt' } } catch {}
    if (-not $b64Path) { $b64Path = Join-Path $ModulesRoot 'OpenXMLAssembly.txt' }
    if (Test-Path -LiteralPath $b64Path) {
        try {
            $base64 = Get-Content -LiteralPath $b64Path -Raw
            $bytes  = [Convert]::FromBase64String($base64)
            [void][System.Reflection.Assembly]::Load($bytes)
            return $true
        } catch {
            throw "Kunde inte ladda OpenXML DLL från Base64 ($b64Path):`n$($_.Exception.Message)"
        }
    }

    throw "DocumentFormat.OpenXml.dll hittades inte i Lib/Modules (eller Base64-fallback). Lägg den i Modules eller i Modules\OpenXMLSDK\... (net46 föredras, net40 fallback) eller placera OpenXMLAssembly.txt."
}

function Normalize-OpenXmlText {
    param([string]$Text)
    $t = ($Text + '')
    $t = $t -replace [char]0x00A0,' '
    $t = $t.Trim()
    $t = [regex]::Replace($t,'\s+',' ')
    return $t
}

function Get-OpenXmlChildrenOfType {
    param(
        [Parameter(Mandatory=$false)]$Parent,
        [Parameter(Mandatory=$true)][Type]$Type
    )
    if (-not $Parent) { return @() }
    $out = New-Object System.Collections.Generic.List[object]
    try {
        foreach ($ch in $Parent.ChildElements) {
            if ($ch -is $Type) { $out.Add($ch) }
        }
    } catch {}
    return $out
}

function Get-OpenXmlDescendantsOfType {
    param(
        [Parameter(Mandatory=$false)]$Parent,
        [Parameter(Mandatory=$true)][Type]$Type
    )
    if (-not $Parent) { return @() }
    $out = New-Object System.Collections.Generic.List[object]
    try {
        foreach ($d in $Parent.Descendants()) {
            if ($d -is $Type) { $out.Add($d) }
        }
    } catch {}
    return $out
}

function Convert-ColLetterToIndex {
    param([string]$Col)
    $c = ($Col + '').Trim().ToUpperInvariant()
    if (-not $c) { return 0 }
    $sum = 0
    foreach ($ch in $c.ToCharArray()) {
        if ($ch -lt 'A' -or $ch -gt 'Z') { return 0 }
        $sum = ($sum * 26) + ([int][char]$ch - [int][char]'A' + 1)
    }
    return $sum
}

function Convert-ColIndexToLetter {
    param([int]$Index)
    if ($Index -le 0) { return '' }
    $i = $Index
    $letters = New-Object System.Text.StringBuilder
    while ($i -gt 0) {
        $i--  # 1-based
        $rem = ($i % 26)
        [void]$letters.Insert(0, [char]([int][char]'A' + $rem))
        $i = [int][math]::Floor($i / 26)
    }
    return $letters.ToString()
}

function Split-OpenXmlCellRef {
    param([string]$CellRef)
    $ref = ($CellRef + '').Trim().ToUpperInvariant()
    if ($ref -notmatch '^([A-Z]+)(\d+)$') { return $null }
    return [pscustomobject]@{
        Ref = $ref
        Col = $matches[1]
        Row = [int]$matches[2]
    }
}

function Get-MergeIndexes_OpenXml {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart
    )

    $forward = @{}
    $reverse = @{}

    $ws = $WorksheetPart.Worksheet
    if (-not $ws) { return @{ Forward = $forward; Reverse = $reverse } }

    $mergeCells = (Get-OpenXmlChildrenOfType -Parent $ws -Type ([DocumentFormat.OpenXml.Spreadsheet.MergeCells]))[0]
    if (-not $mergeCells) { return @{ Forward = $forward; Reverse = $reverse } }

    $mergeCellItems = Get-OpenXmlChildrenOfType -Parent $mergeCells -Type ([DocumentFormat.OpenXml.Spreadsheet.MergeCell])
    foreach ($mc in $mergeCellItems) {
        if (-not $mc.Reference) { continue }
        $ref = ($mc.Reference.Value + '').Trim()
        if (-not $ref) { continue }

        $parts = $ref -split ':'
        $a = ($parts[0] + '').Trim().ToUpperInvariant()
        $b = if ($parts.Count -ge 2) { ($parts[1] + '').Trim().ToUpperInvariant() } else { $a }

        $pA = Split-OpenXmlCellRef -CellRef $a
        $pB = Split-OpenXmlCellRef -CellRef $b
        if (-not $pA -or -not $pB) { continue }

        $c1 = Convert-ColLetterToIndex -Col $pA.Col
        $c2 = Convert-ColLetterToIndex -Col $pB.Col
        $rowA = [int]$pA.Row
        $rowB = [int]$pB.Row
        if ($c1 -le 0 -or $c2 -le 0 -or $rowA -le 0 -or $rowB -le 0) { continue }

        $cMin = [math]::Min($c1, $c2)
        $cMax = [math]::Max($c1, $c2)
        $rMin = [math]::Min($rowA, $rowB)
        $rMax = [math]::Max($rowA, $rowB)

        $owner = ("{0}{1}" -f (Convert-ColIndexToLetter -Index $cMin), $rMin)
        if (-not $reverse.ContainsKey($owner)) {
            $reverse[$owner] = New-Object System.Collections.Generic.List[string]
        }

        for ($r = $rMin; $r -le $rMax; $r++) {
            for ($c = $cMin; $c -le $cMax; $c++) {
                $cellRef = ("{0}{1}" -f (Convert-ColIndexToLetter -Index $c), $r)
                if (-not $forward.ContainsKey($cellRef)) { $forward[$cellRef] = $owner }
                if (-not $reverse[$owner].Contains($cellRef)) { [void]$reverse[$owner].Add($cellRef) }
            }
        }
    }

    $reverseFrozen = @{}
    foreach ($k in $reverse.Keys) {
        $reverseFrozen[$k] = @($reverse[$k].ToArray())
    }
    return @{ Forward = $forward; Reverse = $reverseFrozen }
}
function Get-OpenXmlCellText {
    param(
        [Parameter(Mandatory=$true)]$WorkbookPart,
        [Parameter(Mandatory=$true)]$Cell
    )
    if ($null -eq $Cell) { return '' }

    $val = $Cell.CellValue
    if ($null -eq $val) {
        if ($Cell.InlineString -and $Cell.InlineString.Text) { return ($Cell.InlineString.Text.Text + '') }
        return ''
    }

    $raw = ($val.Text + '')
    if (-not $raw) { return '' }

    if ($Cell.DataType -and $Cell.DataType.Value -eq [DocumentFormat.OpenXml.Spreadsheet.CellValues]::SharedString) {
        $sst = $WorkbookPart.SharedStringTablePart
        if (-not $sst -or -not $sst.SharedStringTable) { return '' }
        $idx = 0
        if (-not [int]::TryParse($raw, [ref]$idx)) { return '' }

        $items = Get-OpenXmlChildrenOfType -Parent $sst.SharedStringTable -Type ([DocumentFormat.OpenXml.Spreadsheet.SharedStringItem])
        if ($idx -lt 0 -or $idx -ge $items.Count) { return '' }
        $item = $items[$idx]

        if ($item.Text) { return ($item.Text.Text + '') }

        $sb = New-Object System.Text.StringBuilder
        foreach ($t in (Get-OpenXmlDescendantsOfType -Parent $item -Type ([DocumentFormat.OpenXml.Spreadsheet.Text]))) {
            [void]$sb.Append(($t.Text + ''))
        }
        return $sb.ToString()
    }

    return $raw
}

function Ensure-OpenXmlCell {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)][int]$RowIndex,
        [Parameter(Mandatory=$true)][string]$ColLetter
    )
    $ws = $WorksheetPart.Worksheet
    if (-not $ws) { return $null }
    $sheetData = (Get-OpenXmlChildrenOfType -Parent $ws -Type ([DocumentFormat.OpenXml.Spreadsheet.SheetData]))[0]
    if (-not $sheetData) {
        $sheetData = New-Object DocumentFormat.OpenXml.Spreadsheet.SheetData
        $ws.AppendChild($sheetData) | Out-Null
    }

    $rows = Get-OpenXmlChildrenOfType -Parent $sheetData -Type ([DocumentFormat.OpenXml.Spreadsheet.Row])
    $row = @($rows | Where-Object { $_.RowIndex -and $_.RowIndex.Value -eq $RowIndex })[0]
    if (-not $row) {
        $row = New-Object DocumentFormat.OpenXml.Spreadsheet.Row
        $row.RowIndex = [uint32]$RowIndex

        $ref = @($rows | Where-Object { $_.RowIndex -and $_.RowIndex.Value -gt $RowIndex })[0]
        if ($ref) { $sheetData.InsertBefore($row, $ref) | Out-Null } else { $sheetData.AppendChild($row) | Out-Null }
    }

    $cellRef = "$ColLetter$RowIndex"
    $cells = Get-OpenXmlChildrenOfType -Parent $row -Type ([DocumentFormat.OpenXml.Spreadsheet.Cell])
    $cell  = @($cells | Where-Object { $_.CellReference -and $_.CellReference.Value -eq $cellRef })[0]
    if ($null -ne $cell) { return ,$cell }

    $cell = New-Object DocumentFormat.OpenXml.Spreadsheet.Cell
    $cell.CellReference = $cellRef

    $targetIdx = Convert-ColLetterToIndex -Col $ColLetter
    $refCell = @($cells | Where-Object {
        $_.CellReference -and (Convert-ColLetterToIndex -Col (($_.CellReference.Value -replace '\d+$',''))) -gt $targetIdx
    })[0]

    if ($null -ne $refCell) { $row.InsertBefore($cell, $refCell) | Out-Null } else { $row.AppendChild($cell) | Out-Null }
    return ,$cell
}

function Test-OpenXmlTreatAsBlankText {
    param([string]$Text)
    $t = Normalize-OpenXmlText $Text
    if (-not $t) { return $true }
    if ($t -match '^(?i)(Recorded By:|Performed By:|PQC Reviewed By:|Date:)$') { return $true }
    if ($t -match '^(?i)(N\/?A|NA)$') { return $true }
    return $false
}

function Get-OpenXmlCellSafe {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)][int]$RowIndex,
        [Parameter(Mandatory=$true)][string]$ColLetter
    )

    if ($RowIndex -lt 1) { return $null }
    $col = ($ColLetter + '').Trim().ToUpperInvariant()
    if (-not $col) { return $null }

    $cell = $null
    try {
        $cell = Ensure-OpenXmlCell -WorksheetPart $WorksheetPart -RowIndex $RowIndex -ColLetter $col
    } catch {
        $cell = $null
    }

    if ($cell -is [DocumentFormat.OpenXml.Spreadsheet.CellValue]) { $cell = $cell.Parent }
    if ($cell -is [DocumentFormat.OpenXml.Spreadsheet.InlineString]) { $cell = $cell.Parent }
    if ($cell -is [DocumentFormat.OpenXml.Spreadsheet.Cell]) { return ,$cell }

    $cell = Find-OpenXmlCell -WorksheetPart $WorksheetPart -RowIndex $RowIndex -ColLetter $col
    if ($cell -is [DocumentFormat.OpenXml.Spreadsheet.CellValue]) { $cell = $cell.Parent }
    if ($cell -is [DocumentFormat.OpenXml.Spreadsheet.InlineString]) { $cell = $cell.Parent }
    if ($cell -is [DocumentFormat.OpenXml.Spreadsheet.Cell]) { return ,$cell }

    return $null
}

function Clear-OpenXmlCellContent {
    param([Parameter(Mandatory=$true)]$Cell)
    if (-not ($Cell -is [DocumentFormat.OpenXml.Spreadsheet.Cell])) { return $false }
    $Cell.CellFormula  = $null
    $Cell.CellValue    = $null
    $Cell.InlineString = $null
    $Cell.DataType     = $null
    return $true
}

function Set-OpenXmlCellInlineText {
    param(
        [Parameter(Mandatory=$true)]$Cell,
        [Parameter(Mandatory=$true)][string]$Value
    )
    if (-not ($Cell -is [DocumentFormat.OpenXml.Spreadsheet.Cell])) { return $false }
    [void](Clear-OpenXmlCellContent -Cell $Cell)
    $Cell.DataType = [DocumentFormat.OpenXml.Spreadsheet.CellValues]::InlineString
    $Cell.InlineString = New-Object DocumentFormat.OpenXml.Spreadsheet.InlineString
    $Cell.InlineString.Text = New-Object DocumentFormat.OpenXml.Spreadsheet.Text
    $Cell.InlineString.Text.Text = ($Value + '')
    return $true
}

function Resolve-OpenXmlMergeOwner {
    param(
        [Parameter(Mandatory=$true)][int]$RowIndex,
        [Parameter(Mandatory=$true)][string]$ColLetter,
        [hashtable]$ForwardMap
    )
    $col = ($ColLetter + '').Trim().ToUpperInvariant()
    $targetRef = ("{0}{1}" -f $col, $RowIndex)
    $ownerRef = $targetRef
    if ($ForwardMap -and $ForwardMap.ContainsKey($targetRef)) {
        $ownerRef = (($ForwardMap[$targetRef] + '').Trim().ToUpperInvariant())
    }

    $ownerInfo = Split-OpenXmlCellRef -CellRef $ownerRef
    if (-not $ownerInfo) { $ownerInfo = Split-OpenXmlCellRef -CellRef $targetRef }
    if (-not $ownerInfo) { return $null }

    return [pscustomobject]@{
        TargetRef = $targetRef
        OwnerRef  = $ownerInfo.Ref
        OwnerCol  = $ownerInfo.Col
        OwnerRow  = [int]$ownerInfo.Row
    }
}

function Get-OpenXmlMergeGroupOwnerRowRefs {
    param(
        [Parameter(Mandatory=$true)][string]$OwnerRef,
        [Parameter(Mandatory=$true)][int]$OwnerRow,
        [hashtable]$ReverseMap
    )

    $refs = New-Object System.Collections.Generic.List[string]
    if ($ReverseMap -and $ReverseMap.ContainsKey($OwnerRef)) {
        foreach ($r in @($ReverseMap[$OwnerRef])) {
            $info = Split-OpenXmlCellRef -CellRef $r
            if ($info -and ([int]$info.Row -eq [int]$OwnerRow)) {
                if (-not $refs.Contains($info.Ref)) { [void]$refs.Add($info.Ref) }
            }
        }
    }
    if (-not $refs.Contains($OwnerRef)) { [void]$refs.Add($OwnerRef) }
    return @($refs.ToArray())
}

function Write-OpenXmlCellText_DeterministicMerge {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)]$WorkbookPart,
        [Parameter(Mandatory=$true)][int]$RowIndex,
        [Parameter(Mandatory=$true)][string]$ColLetter,
        [Parameter(Mandatory=$true)][string]$Value,
        [bool]$Overwrite = $false,
        [hashtable]$ForwardMap,
        [hashtable]$ReverseMap,
        [string]$TailValue
    )

    $result = [pscustomobject]@{
        Written     = $false
        TargetRef   = $null
        OwnerRef    = $null
        OwnerRow    = $null
        OwnerCol    = $null
        GroupRefs   = @()
        Reason      = $null
        BlockedBy   = $null
    }

    if ($RowIndex -lt 1) {
        $result.Reason = 'invalid row'
        return $result
    }

    $owner = Resolve-OpenXmlMergeOwner -RowIndex $RowIndex -ColLetter $ColLetter -ForwardMap $ForwardMap
    if (-not $owner) {
        $result.Reason = 'could not resolve owner'
        return $result
    }

    $result.TargetRef = $owner.TargetRef
    $result.OwnerRef = $owner.OwnerRef
    $result.OwnerRow = [int]$owner.OwnerRow
    $result.OwnerCol = $owner.OwnerCol

    $groupRefs = Get-OpenXmlMergeGroupOwnerRowRefs -OwnerRef $owner.OwnerRef -OwnerRow $owner.OwnerRow -ReverseMap $ReverseMap
    $result.GroupRefs = @($groupRefs)

    if (-not $Overwrite) {
        foreach ($ref in $groupRefs) {
            $ri = Split-OpenXmlCellRef -CellRef $ref
            if (-not $ri) { continue }
            $existingCell = Find-OpenXmlCell -WorksheetPart $WorksheetPart -RowIndex ([int]$ri.Row) -ColLetter $ri.Col
            if ($null -eq $existingCell) { continue }
            $existingRaw = Get-OpenXmlCellText -WorkbookPart $WorkbookPart -Cell $existingCell
            if (-not (Test-OpenXmlTreatAsBlankText -Text $existingRaw)) {
                $result.Reason = 'already filled'
                $result.BlockedBy = $ri.Ref
                return $result
            }
        }
    } else {
        foreach ($ref in $groupRefs) {
            $ri = Split-OpenXmlCellRef -CellRef $ref
            if (-not $ri) { continue }
            $clearCell = Get-OpenXmlCellSafe -WorksheetPart $WorksheetPart -RowIndex ([int]$ri.Row) -ColLetter $ri.Col
            if ($clearCell) { [void](Clear-OpenXmlCellContent -Cell $clearCell) }
        }
    }

    $ownerCell = Get-OpenXmlCellSafe -WorksheetPart $WorksheetPart -RowIndex $owner.OwnerRow -ColLetter $owner.OwnerCol
    if ($null -eq $ownerCell) {
        $result.Reason = 'owner cell missing'
        return $result
    }
    if (-not (Set-OpenXmlCellInlineText -Cell $ownerCell -Value $Value)) {
        $result.Reason = 'owner write failed'
        return $result
    }

    $tail = Normalize-OpenXmlText $TailValue
    if ($Overwrite -and $tail) {
        foreach ($ref in $groupRefs) {
            if ($ref -eq $owner.OwnerRef) { continue }
            $ri = Split-OpenXmlCellRef -CellRef $ref
            if (-not $ri) { continue }
            $tailCell = Get-OpenXmlCellSafe -WorksheetPart $WorksheetPart -RowIndex ([int]$ri.Row) -ColLetter $ri.Col
            if ($null -eq $tailCell) { continue }
            [void](Set-OpenXmlCellInlineText -Cell $tailCell -Value $tail)
        }
    }

    $result.Written = $true
    $result.Reason = 'written'
    return $result
}


# ============================================================
# Pre-sign compact for high-risk Worksheet tabs
# Purpose:
#   Some Worksheet files contain >500k empty/styled cell nodes in
#   "Seal Test Failure Count" / SPC tabs. Loading/saving those tabs via
#   OpenXML DOM can be very slow or crash on weaker clients.
#
#   This function compacts the XLSX package as ZIP/XML before OpenXML DOM
#   opens it. It removes empty self-closing cell nodes outside A:N150 and
#   trims inflated column metadata for the known high-risk tabs only.
# ============================================================
function Get-IPTPreSignCompactTargetSheetNames_OpenXml {
    return @(
        'Seal Test Failure Count',
        'Statistical Process Control STF',
        'Statistical Process Control'
    )
}

function Test-IPTPreSignCompactTargetSheetName_OpenXml {
    param([string]$SheetName)
    $n = (($SheetName + '').Trim())
    if (-not $n) { return $false }
    foreach ($t in (Get-IPTPreSignCompactTargetSheetNames_OpenXml)) {
        if ([string]::Equals($n, $t, [System.StringComparison]::OrdinalIgnoreCase)) {
            return $true
        }
    }
    return $false
}

function Read-IPTZipEntryText_OpenXml {
    param(
        [Parameter(Mandatory=$true)]$ZipArchive,
        [Parameter(Mandatory=$true)][string]$EntryName
    )
    $entry = $ZipArchive.GetEntry($EntryName)
    if (-not $entry) { return $null }

    $stream = $null
    $reader = $null
    try {
        $stream = $entry.Open()
        $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::UTF8, $true)
        return $reader.ReadToEnd()
    } finally {
        try { if ($reader) { $reader.Dispose() } } catch {}
        try { if ($stream) { $stream.Dispose() } } catch {}
    }
}

function Convert-IPTRelTargetToZipEntry_OpenXml {
    param([string]$Target)
    $t = (($Target + '').Trim() -replace '\\','/')
    if (-not $t) { return $null }
    if ($t.StartsWith('/')) {
        return $t.TrimStart('/')
    }
    if ($t.StartsWith('xl/')) {
        return $t
    }
    return ('xl/' + $t)
}

function Get-IPTXlsxSheetEntryMap_OpenXml {
    param([Parameter(Mandatory=$true)]$ZipArchive)

    $wbXmlText = Read-IPTZipEntryText_OpenXml -ZipArchive $ZipArchive -EntryName 'xl/workbook.xml'
    $relsXmlText = Read-IPTZipEntryText_OpenXml -ZipArchive $ZipArchive -EntryName 'xl/_rels/workbook.xml.rels'
    if (-not $wbXmlText -or -not $relsXmlText) { return @() }

    [xml]$wbXml = $wbXmlText
    [xml]$relsXml = $relsXmlText

    $relMap = @{}
    $relNs = New-Object System.Xml.XmlNamespaceManager($relsXml.NameTable)
    $relNs.AddNamespace('rel','http://schemas.openxmlformats.org/package/2006/relationships')
    foreach ($rel in $relsXml.SelectNodes('//rel:Relationship', $relNs)) {
        $id = ($rel.GetAttribute('Id') + '')
        $target = ($rel.GetAttribute('Target') + '')
        if ($id -and $target) {
            $relMap[$id] = Convert-IPTRelTargetToZipEntry_OpenXml -Target $target
        }
    }

    $wbNs = New-Object System.Xml.XmlNamespaceManager($wbXml.NameTable)
    $wbNs.AddNamespace('x','http://schemas.openxmlformats.org/spreadsheetml/2006/main')
    $wbNs.AddNamespace('r','http://schemas.openxmlformats.org/officeDocument/2006/relationships')

    $out = New-Object System.Collections.Generic.List[object]
    foreach ($sheet in $wbXml.SelectNodes('//x:sheets/x:sheet', $wbNs)) {
        $name = ($sheet.GetAttribute('name') + '')
        $rid = ($sheet.GetAttribute('id','http://schemas.openxmlformats.org/officeDocument/2006/relationships') + '')
        if (-not $rid) { continue }
        if (-not $relMap.ContainsKey($rid)) { continue }
        [void]$out.Add([pscustomobject]@{
            Name      = $name
            RelId     = $rid
            EntryName = ($relMap[$rid] + '')
        })
    }
    return @($out.ToArray())
}

function Split-IPTCellReference_OpenXml {
    param([string]$CellReference)
    $r = (($CellReference + '').Trim().ToUpperInvariant())
    if ($r -notmatch '^([A-Z]+)([0-9]+)$') { return $null }
    return [pscustomobject]@{
        Col = $matches[1]
        Row = [int]$matches[2]
        ColIndex = [int](Convert-ColLetterToIndex -Col $matches[1])
    }
}

function Get-IPTWorksheetXmlCellTagCount_OpenXml {
    param([string]$Xml)
    if (-not $Xml) { return 0 }
    return ([regex]::Matches($Xml, '<(?:(?:[A-Za-z_][\w\.-]*):)?c\b')).Count
}

function Get-IPTWorksheetDimensionMaxCol_OpenXml {
    param([string]$Xml)
    if (-not $Xml) { return 0 }
    $m = [regex]::Match($Xml, '<(?:(?:[A-Za-z_][\w\.-]*):)?dimension\b[^>]*\bref\s*=\s*["''](?<ref>[^"'']+)["'']')
    if (-not $m.Success) { return 0 }
    $ref = ($m.Groups['ref'].Value + '').Trim()
    if (-not $ref) { return 0 }
    $last = $ref
    if ($ref.Contains(':')) { $last = ($ref -split ':')[-1] }
    $ci = Split-IPTCellReference_OpenXml -CellReference $last
    if (-not $ci) { return 0 }
    return [int]$ci.ColIndex
}

function Set-IPTWorksheetDimension_OpenXml {
    param(
        [string]$Xml,
        [Parameter(Mandatory=$true)][string]$Ref
    )
    if (-not $Xml) { return $Xml }
    $rx = [regex]'<(?:(?:[A-Za-z_][\w\.-]*):)?dimension\b[^>]*\bref\s*=\s*["''](?<ref>[^"'']+)["'']'
    $m = $rx.Match($Xml)
    if (-not $m.Success) { return $Xml }

    $g = $m.Groups['ref']
    return ($Xml.Substring(0, $g.Index) + $Ref + $Xml.Substring($g.Index + $g.Length))
}

function Remove-IPTEmptyCellTagsOutsideBounds_OpenXml {
    param(
        [Parameter(Mandatory=$true)][string]$Xml,
        [Parameter(Mandatory=$true)][int]$MaxColIndex,
        [Parameter(Mandatory=$true)][int]$MaxRow,
        [ref]$RemovedCount
    )

    if ($RemovedCount) { $RemovedCount.Value = 0 }
    if (-not $Xml) { return $Xml }

    # Handles common inflated Excel output like:
    # <x:c r="O2" s="96" />
    $rx = [regex]'<(?:(?:[A-Za-z_][\w\.-]*):)?c\b(?<attrs>[^>]*)/>'
    $matches = $rx.Matches($Xml)
    if ($matches.Count -eq 0) { return $Xml }

    $sb = New-Object System.Text.StringBuilder
    $last = 0
    $removed = 0

    foreach ($m in $matches) {
        [void]$sb.Append($Xml.Substring($last, $m.Index - $last))

        $attrs = ($m.Groups['attrs'].Value + '')
        $rm = [regex]::Match($attrs, '\br\s*=\s*["''](?<ref>[A-Z]+[0-9]+)["'']')
        $remove = $false
        if ($rm.Success) {
            $cellRef = $rm.Groups['ref'].Value
            $ci = Split-IPTCellReference_OpenXml -CellReference $cellRef
            if ($ci) {
                if (([int]$ci.Row -gt $MaxRow) -or ([int]$ci.ColIndex -gt $MaxColIndex)) {
                    $remove = $true
                }
            }
        }

        if ($remove) {
            $removed++
        } else {
            [void]$sb.Append($m.Value)
        }

        $last = $m.Index + $m.Length
    }

    [void]$sb.Append($Xml.Substring($last))
    if ($RemovedCount) { $RemovedCount.Value = $removed }
    return $sb.ToString()
}

function Remove-IPTEmptyExpandedCellTagsOutsideBounds_OpenXml {
    param(
        [Parameter(Mandatory=$true)][string]$Xml,
        [Parameter(Mandatory=$true)][int]$MaxColIndex,
        [Parameter(Mandatory=$true)][int]$MaxRow,
        [ref]$RemovedCount
    )

    if ($RemovedCount) { $RemovedCount.Value = 0 }
    if (-not $Xml) { return $Xml }

    # Conservative: only removes truly empty expanded cell tags:
    # <x:c r="O2" s="96"></x:c>
    $rx = [regex]'<(?:(?:[A-Za-z_][\w\.-]*):)?c\b(?<attrs>[^>]*)>\s*</(?:(?:[A-Za-z_][\w\.-]*):)?c>'
    $matches = $rx.Matches($Xml)
    if ($matches.Count -eq 0) { return $Xml }

    $sb = New-Object System.Text.StringBuilder
    $last = 0
    $removed = 0

    foreach ($m in $matches) {
        [void]$sb.Append($Xml.Substring($last, $m.Index - $last))

        $attrs = ($m.Groups['attrs'].Value + '')
        $rm = [regex]::Match($attrs, '\br\s*=\s*["''](?<ref>[A-Z]+[0-9]+)["'']')
        $remove = $false
        if ($rm.Success) {
            $ci = Split-IPTCellReference_OpenXml -CellReference $rm.Groups['ref'].Value
            if ($ci) {
                if (([int]$ci.Row -gt $MaxRow) -or ([int]$ci.ColIndex -gt $MaxColIndex)) {
                    $remove = $true
                }
            }
        }

        if ($remove) {
            $removed++
        } else {
            [void]$sb.Append($m.Value)
        }

        $last = $m.Index + $m.Length
    }

    [void]$sb.Append($Xml.Substring($last))
    if ($RemovedCount) { $RemovedCount.Value = $removed }
    return $sb.ToString()
}

function Compact-IPTColumnDefinitions_OpenXml {
    param(
        [Parameter(Mandatory=$true)][string]$Xml,
        [Parameter(Mandatory=$true)][int]$MaxColIndex,
        [ref]$RemovedCount,
        [ref]$AdjustedCount
    )

    if ($RemovedCount) { $RemovedCount.Value = 0 }
    if ($AdjustedCount) { $AdjustedCount.Value = 0 }
    if (-not $Xml) { return $Xml }

    $rx = [regex]'<(?:(?:[A-Za-z_][\w\.-]*):)?col\b(?<attrs>[^>]*)/>'
    $matches = $rx.Matches($Xml)
    if ($matches.Count -eq 0) { return $Xml }

    $sb = New-Object System.Text.StringBuilder
    $last = 0
    $removed = 0
    $adjusted = 0

    foreach ($m in $matches) {
        [void]$sb.Append($Xml.Substring($last, $m.Index - $last))
        $tag = $m.Value
        $attrs = ($m.Groups['attrs'].Value + '')
        $minM = [regex]::Match($attrs, '\bmin\s*=\s*["''](?<n>[0-9]+)["'']')
        $maxM = [regex]::Match($attrs, '\bmax\s*=\s*["''](?<n>[0-9]+)["'']')

        $remove = $false
        if ($minM.Success -and $maxM.Success) {
            $min = [int]$minM.Groups['n'].Value
            $max = [int]$maxM.Groups['n'].Value
            if ($min -gt $MaxColIndex) {
                $remove = $true
            } elseif ($max -gt $MaxColIndex) {
                $replacement = ('${1}' + ([string]$MaxColIndex) + '${3}')
                $tag = [regex]::Replace($tag, '(\bmax\s*=\s*["''])([0-9]+)(["''])', $replacement)
                $adjusted++
            }
        }

        if ($remove) {
            $removed++
        } else {
            [void]$sb.Append($tag)
        }

        $last = $m.Index + $m.Length
    }

    [void]$sb.Append($Xml.Substring($last))
    if ($RemovedCount) { $RemovedCount.Value = $removed }
    if ($AdjustedCount) { $AdjustedCount.Value = $adjusted }
    return $sb.ToString()
}

function Optimize-IPTHighRiskWorksheetXml_OpenXml {
    param(
        [Parameter(Mandatory=$true)][string]$Xml,
        [int]$MaxColIndex = 14,
        [int]$MaxRow = 150,
        [int]$CellCountThreshold = 50000
    )

    $beforeCells = Get-IPTWorksheetXmlCellTagCount_OpenXml -Xml $Xml
    $dimensionMaxCol = Get-IPTWorksheetDimensionMaxCol_OpenXml -Xml $Xml

    $looksBloated = $false
    if ($beforeCells -gt $CellCountThreshold) { $looksBloated = $true }
    if ($dimensionMaxCol -gt ($MaxColIndex + 50)) { $looksBloated = $true }

    $result = [pscustomobject]@{
        Changed            = $false
        BeforeCells        = [int]$beforeCells
        AfterCells         = [int]$beforeCells
        RemovedCells       = 0
        RemovedColumns     = 0
        AdjustedColumns    = 0
        DimensionMaxCol    = [int]$dimensionMaxCol
        SkippedReason      = $null
        Xml                = $Xml
    }

    if (-not $looksBloated) {
        $result.SkippedReason = 'not bloated'
        return $result
    }

    $maxColLetter = Convert-ColIndexToLetter -Index $MaxColIndex
    $newRef = ('A1:{0}{1}' -f $maxColLetter, $MaxRow)

    $removedA = 0
    $tmp = Remove-IPTEmptyCellTagsOutsideBounds_OpenXml -Xml $Xml -MaxColIndex $MaxColIndex -MaxRow $MaxRow -RemovedCount ([ref]$removedA)

    $removedB = 0
    $tmp = Remove-IPTEmptyExpandedCellTagsOutsideBounds_OpenXml -Xml $tmp -MaxColIndex $MaxColIndex -MaxRow $MaxRow -RemovedCount ([ref]$removedB)

    $removedCols = 0
    $adjustedCols = 0
    $tmp = Compact-IPTColumnDefinitions_OpenXml -Xml $tmp -MaxColIndex $MaxColIndex -RemovedCount ([ref]$removedCols) -AdjustedCount ([ref]$adjustedCols)

    $tmp = Set-IPTWorksheetDimension_OpenXml -Xml $tmp -Ref $newRef
    $tmp = [regex]::Replace($tmp, '\bspans\s*=\s*["''][^"'']+["'']', ('spans="1:{0}"' -f $MaxColIndex))

    $afterCells = Get-IPTWorksheetXmlCellTagCount_OpenXml -Xml $tmp

    $result.Changed = (($removedA + $removedB + $removedCols + $adjustedCols) -gt 0)
    $result.AfterCells = [int]$afterCells
    $result.RemovedCells = [int]($removedA + $removedB)
    $result.RemovedColumns = [int]$removedCols
    $result.AdjustedColumns = [int]$adjustedCols
    $result.Xml = $tmp
    return $result
}

function Invoke-IPTWorksheetPreSignCompact_OpenXml {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [int]$MaxColIndex = 14,
        [int]$MaxRow = 150,
        [int]$CellCountThreshold = 50000,
        [switch]$NoBackup
    )

    $result = [pscustomobject]@{
        Path          = $Path
        Changed       = $false
        BackupPath    = $null
        Sheets        = New-Object System.Collections.Generic.List[object]
        Error         = $null
    }

    if (-not (Test-Path -LiteralPath $Path)) {
        throw "Worksheet-filen saknas: $Path"
    }

    try {
        Add-Type -AssemblyName System.IO.Compression | Out-Null
        Add-Type -AssemblyName System.IO.Compression.FileSystem | Out-Null
    } catch {
        throw "Kunde inte ladda System.IO.Compression för pre-sign compact: $($_.Exception.Message)"
    }

    $zipRead = $null
    $targetEntries = @{}
    try {
        $zipRead = [System.IO.Compression.ZipFile]::OpenRead($Path)
        $map = @(Get-IPTXlsxSheetEntryMap_OpenXml -ZipArchive $zipRead)
        foreach ($m in $map) {
            if (Test-IPTPreSignCompactTargetSheetName_OpenXml -SheetName $m.Name) {
                $entryName = (($m.EntryName + '') -replace '\\','/')
                if ($entryName) {
                    $targetEntries[$entryName] = ($m.Name + '')
                }
            }
        }
    } finally {
        try { if ($zipRead) { $zipRead.Dispose() } } catch {}
    }

    if ($targetEntries.Count -eq 0) {
        return $result
    }

    $dir = Split-Path -LiteralPath $Path -Parent
    if (-not $dir) { $dir = (Get-Location).Path }
    $base = [System.IO.Path]::GetFileNameWithoutExtension($Path)
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
    $tmpPath = Join-Path $dir ("{0}.presigncompact.{1}.{2}.tmp.xlsx" -f $base, $stamp, ([guid]::NewGuid().ToString('N').Substring(0,8)))
    $backupPath = Join-Path $dir ("{0}.precompact_backup_{1}.xlsx" -f $base, $stamp)

    $changedAny = $false
    $zipIn = $null
    $zipOut = $null

    try {
        $zipIn = [System.IO.Compression.ZipFile]::OpenRead($Path)
        $zipOut = [System.IO.Compression.ZipFile]::Open($tmpPath, [System.IO.Compression.ZipArchiveMode]::Create)

        foreach ($entry in $zipIn.Entries) {
            $entryName = (($entry.FullName + '') -replace '\\','/')
            $outEntry = $zipOut.CreateEntry($entry.FullName, [System.IO.Compression.CompressionLevel]::Optimal)

            $inStream = $null
            $outStream = $null
            $reader = $null
            $writer = $null
            try {
                $inStream = $entry.Open()
                $outStream = $outEntry.Open()

                if ($targetEntries.ContainsKey($entryName)) {
                    $reader = New-Object System.IO.StreamReader($inStream, [System.Text.Encoding]::UTF8, $true)
                    $xml = $reader.ReadToEnd()
                    try { $reader.Dispose(); $reader = $null } catch {}
                    try { $inStream.Dispose(); $inStream = $null } catch {}

                    $opt = Optimize-IPTHighRiskWorksheetXml_OpenXml -Xml $xml -MaxColIndex $MaxColIndex -MaxRow $MaxRow -CellCountThreshold $CellCountThreshold

                    [void]$result.Sheets.Add([pscustomobject]@{
                        SheetName       = ($targetEntries[$entryName] + '')
                        EntryName       = $entryName
                        Changed         = [bool]$opt.Changed
                        BeforeCells     = [int]$opt.BeforeCells
                        AfterCells      = [int]$opt.AfterCells
                        RemovedCells    = [int]$opt.RemovedCells
                        RemovedColumns  = [int]$opt.RemovedColumns
                        AdjustedColumns = [int]$opt.AdjustedColumns
                        SkippedReason   = ($opt.SkippedReason + '')
                    })

                    if ($opt.Changed) { $changedAny = $true }

                    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
                    $writer = New-Object System.IO.StreamWriter($outStream, $utf8NoBom)
                    $writer.Write($opt.Xml)
                } else {
                    $inStream.CopyTo($outStream)
                }
            } finally {
                try { if ($writer) { $writer.Dispose() } } catch {}
                try { if ($reader) { $reader.Dispose() } } catch {}
                try { if ($outStream) { $outStream.Dispose() } } catch {}
                try { if ($inStream) { $inStream.Dispose() } } catch {}
            }
        }
    } catch {
        $result.Error = $_.Exception.Message
        throw "Pre-sign compact misslyckades: $($_.Exception.Message)"
    } finally {
        try { if ($zipOut) { $zipOut.Dispose() } } catch {}
        try { if ($zipIn) { $zipIn.Dispose() } } catch {}
    }

    if ($changedAny) {
        if (-not $NoBackup) {
            Copy-Item -LiteralPath $Path -Destination $backupPath -Force
            $result.BackupPath = $backupPath
        }
        Move-Item -LiteralPath $tmpPath -Destination $Path -Force
        $result.Changed = $true
    } else {
        try { Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue } catch {}
    }

    return $result
}

function Find-FirstRowByContainsBounded_OpenXml {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)]$WorkbookPart,
        [Parameter(Mandatory=$true)][string]$ColLetter,
        [Parameter(Mandatory=$true)][string]$Needle,
        [int]$MinRow = 1,
        [int]$MaxRow = 150
    )

    $needleNorm = (Normalize-OpenXmlText $Needle).ToLowerInvariant()
    if (-not $needleNorm) { return $null }

    $targetCol = (($ColLetter + '').Trim().ToUpperInvariant())
    if (-not $targetCol) { return $null }
    $targetRefColIndex = Convert-ColLetterToIndex -Col $targetCol

    $sheetData = (Get-OpenXmlChildrenOfType -Parent $WorksheetPart.Worksheet -Type ([DocumentFormat.OpenXml.Spreadsheet.SheetData]))[0]
    if (-not $sheetData) { return $null }

    foreach ($row in (Get-OpenXmlChildrenOfType -Parent $sheetData -Type ([DocumentFormat.OpenXml.Spreadsheet.Row]))) {
        $r = 0
        if ($row.RowIndex) { $r = [int]$row.RowIndex.Value }
        if ($r -lt $MinRow -or $r -gt $MaxRow) { continue }

        $cellRef = "$targetCol$r"
        $cell = $null
        foreach ($ch in $row.ChildElements) {
            if (-not ($ch -is [DocumentFormat.OpenXml.Spreadsheet.Cell])) { continue }
            if (-not $ch.CellReference) { continue }

            $cr = ($ch.CellReference.Value + '').ToUpperInvariant()
            if ($cr -eq $cellRef) {
                $cell = $ch
                break
            }

            # Cells are normally ordered left-to-right. Break once past target col.
            $ci = Split-OpenXmlCellRef -CellRef $cr
            if ($ci -and ([int](Convert-ColLetterToIndex -Col $ci.Col) -gt $targetRefColIndex)) {
                break
            }
        }

        if ($null -eq $cell) { continue }
        $txt = Normalize-OpenXmlText (Get-OpenXmlCellText -WorkbookPart $WorkbookPart -Cell $cell)
        if (-not $txt) { continue }
        if ($txt.ToLowerInvariant().Contains($needleNorm)) { return $r }
    }

    return $null
}

function Find-FirstRowByContains_OpenXml {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)]$WorkbookPart,
        [Parameter(Mandatory=$true)][string]$ColLetter,
        [Parameter(Mandatory=$true)][string]$Needle
    )
    $needleNorm = (Normalize-OpenXmlText $Needle).ToLowerInvariant()
    $sheetData = (Get-OpenXmlChildrenOfType -Parent $WorksheetPart.Worksheet -Type ([DocumentFormat.OpenXml.Spreadsheet.SheetData]))[0]
    if (-not $sheetData) { return $null }

    foreach ($row in (Get-OpenXmlChildrenOfType -Parent $sheetData -Type ([DocumentFormat.OpenXml.Spreadsheet.Row]))) {
        $r = 0
        if ($row.RowIndex) { $r = [int]$row.RowIndex.Value }
        if ($r -le 0) { continue }
        $cellRef = "$ColLetter$r"

        $cell = @(
            Get-OpenXmlChildrenOfType -Parent $row -Type ([DocumentFormat.OpenXml.Spreadsheet.Cell]) |
            Where-Object { $_.CellReference -and $_.CellReference.Value -eq $cellRef }
        )[0]

        if ($null -eq $cell) { continue }
        $txt = Normalize-OpenXmlText (Get-OpenXmlCellText -WorkbookPart $WorkbookPart -Cell $cell)
        if (-not $txt) { continue }
        if ($txt.ToLowerInvariant().Contains($needleNorm)) { return $r }
    }
    return $null
}

function Find-FirstRowByContains_FromRow_OpenXml {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)]$WorkbookPart,
        [Parameter(Mandatory=$true)][string]$ColLetter,
        [Parameter(Mandatory=$true)][string]$Needle,
        [Parameter(Mandatory=$true)][int]$StartRow
    )
    $needleNorm = (Normalize-OpenXmlText $Needle).ToLowerInvariant()
    $sheetData = (Get-OpenXmlChildrenOfType -Parent $WorksheetPart.Worksheet -Type ([DocumentFormat.OpenXml.Spreadsheet.SheetData]))[0]
    if (-not $sheetData) { return $null }

    $fromRow = $StartRow
    if ($fromRow -lt 1) { $fromRow = 1 }

    foreach ($row in (Get-OpenXmlChildrenOfType -Parent $sheetData -Type ([DocumentFormat.OpenXml.Spreadsheet.Row]))) {
        $r = 0
        if ($row.RowIndex) { $r = [int]$row.RowIndex.Value }
        if ($r -lt $fromRow) { continue }
        if ($r -le 0) { continue }
        $cellRef = "$ColLetter$r"

        $cell = @(
            Get-OpenXmlChildrenOfType -Parent $row -Type ([DocumentFormat.OpenXml.Spreadsheet.Cell]) |
            Where-Object { $_.CellReference -and $_.CellReference.Value -eq $cellRef }
        )[0]

        if ($null -eq $cell) { continue }
        $txt = Normalize-OpenXmlText (Get-OpenXmlCellText -WorkbookPart $WorkbookPart -Cell $cell)
        if (-not $txt) { continue }
        if ($txt.ToLowerInvariant().Contains($needleNorm)) { return $r }
    }
    return $null
}

function Test-OpenXmlDataSummaryHasData {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)]$WorkbookPart,
        [string]$DataColLetter = 'C',
        [hashtable]$MergeMap
    )
    $sheetData = (Get-OpenXmlChildrenOfType -Parent $WorksheetPart.Worksheet -Type ([DocumentFormat.OpenXml.Spreadsheet.SheetData]))[0]
    if (-not $sheetData) { return $false }

    foreach ($row in (Get-OpenXmlChildrenOfType -Parent $sheetData -Type ([DocumentFormat.OpenXml.Spreadsheet.Row]))) {
        $r = 0
        if ($row.RowIndex) { $r = [int]$row.RowIndex.Value }
        if ($r -le 0) { continue }
        $cellRef = "$DataColLetter$r"
        if ($MergeMap -and $MergeMap.ContainsKey($cellRef)) {
            $cellRef = ($MergeMap[$cellRef] + '')
        }

        $cell = @(
            Get-OpenXmlChildrenOfType -Parent $row -Type ([DocumentFormat.OpenXml.Spreadsheet.Cell]) |
            Where-Object { $_.CellReference -and $_.CellReference.Value -eq $cellRef }
        )[0]

        if ($null -eq $cell) { continue }
        $txt = Normalize-OpenXmlText (Get-OpenXmlCellText -WorkbookPart $WorkbookPart -Cell $cell)
        if (-not $txt) { continue }
        if ($txt -match '^(?i)(Performed By:|Recorded By:|PQC Reviewed By:|Date:)$') { continue }
        return $true
    }
    return $false
}

function Write-OpenXmlSignDebug {
    param(
        [bool]$Enabled,
        [System.Collections.Generic.List[string]]$Events,
        [string]$Message
    )
    $msg = ($Message + '')
    if ($null -ne $Events) { [void]$Events.Add($msg) }
    if ($Enabled) { Write-Verbose ("[OpenXML] $msg") -Verbose }
}

function Find-OpenXmlCell {
    param(
        [Parameter(Mandatory=$true)]$WorksheetPart,
        [Parameter(Mandatory=$true)][int]$RowIndex,
        [Parameter(Mandatory=$true)][string]$ColLetter
    )
    $ws = $WorksheetPart.Worksheet
    $sheetData = (Get-OpenXmlChildrenOfType -Parent $ws -Type ([DocumentFormat.OpenXml.Spreadsheet.SheetData]))[0]
    if (-not $sheetData) { return $null }

    $rows = Get-OpenXmlChildrenOfType -Parent $sheetData -Type ([DocumentFormat.OpenXml.Spreadsheet.Row])
    $row = @($rows | Where-Object { $_.RowIndex -and $_.RowIndex.Value -eq $RowIndex })[0]
    if (-not $row) { return $null }

    $cellRef = "$ColLetter$RowIndex"
    $cells = Get-OpenXmlChildrenOfType -Parent $row -Type ([DocumentFormat.OpenXml.Spreadsheet.Cell])
    $cell = @($cells | Where-Object { $_.CellReference -and $_.CellReference.Value -eq $cellRef })[0]
    return ,$cell
}
