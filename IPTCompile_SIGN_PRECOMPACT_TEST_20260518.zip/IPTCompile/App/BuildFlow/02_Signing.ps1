﻿# Build phase: Seal Test and Worksheet signing
# Extracted from App/BuildReportFlow.ps1 during PASS4.

        # ============================
        # === SIGNATUR I NEG/POS  ====
        # ============================

        $doSealTest = $chkSealTest.Checked
        $doWsSamm   = $chkWsSamm.Checked
        $doWsGransk = $chkWsGransk.Checked
        $doOverwrite      = $chkSignOverwrite.Checked
        $doOverwriteGransk = $chkGranskOverwrite.Checked
        if (($doSealTest -or $doWsSamm) -and (-not $doOverwrite)) {
            Gui-Log "❌ Overwrite måste kryssas i för att skapa rapport med signering (Sammanställning)." 'Error'
            return
        }
        if ($doWsGransk -and (-not $doOverwriteGransk)) {
            Gui-Log "❌ Overwrite måste kryssas i för att skapa rapport med signering (Granskning)." 'Error'
            return
        }

        # --- Sammanställnings-fält (delat av Seal Test + Worksheet Sammanställning) ---
        $sammName = ($txtSammName.Text + '').Trim()
        $sammDate = ($txtSammDate.Text + '').Trim()
        $sammSign = ($txtSealTestSign.Text + '').Trim()

        if ($doSealTest) {
            if (-not $sammName) { Gui-Log "❌ Sammanställning: Full Name saknas." 'Error'; return }
            if (-not $sammSign) { Gui-Log "❌ Sammanställning: SIGN saknas." 'Error'; return }
            if (-not $sammDate) { Gui-Log "❌ Sammanställning: Date saknas." 'Error'; return }
        }
        if ($doWsSamm) {
            if (-not $sammName) { Gui-Log "❌ Sammanställning: Full Name saknas." 'Error'; return }
            if (-not $sammDate) { Gui-Log "❌ Sammanställning: Date saknas." 'Error'; return }
        }
        if ($doWsGransk) {
            $granskName = ($txtGranskName.Text + '').Trim()
            $granskDate = ($txtGranskDate.Text + '').Trim()
            if (-not $granskName) { Gui-Log "❌ Granskning: Full Name saknas." 'Error'; return }
            if (-not $granskDate) { Gui-Log "❌ Granskning: Date saknas." 'Error'; return }
        }
# ============================================================
# === Global spärr före signering                          ===
# ============================================================
# Om användaren har valt flera signeringar ska ALLA filer vara stängda
# innan någon originalfil skrivs. Annars kan Seal Test hinna signeras
# innan Worksheet stoppas.
try {
    $allSignaturePaths = New-Object System.Collections.Generic.List[string]
    if ($doSealTest) {
        $negPreSignPath = if ($selNegOrig) { $selNegOrig } else { $selNeg }
        $posPreSignPath = if ($selPosOrig) { $selPosOrig } else { $selPos }
        if ($negPreSignPath -and (Test-Path -LiteralPath $negPreSignPath)) {
            [void]$allSignaturePaths.Add($negPreSignPath)
        }
        if ($posPreSignPath -and (Test-Path -LiteralPath $posPreSignPath)) {
            [void]$allSignaturePaths.Add($posPreSignPath)
        }
    }
    if ($doWsSamm -or $doWsGransk) {
        $wsPreSignPath = $null
        try { $wsPreSignPath = Get-CheckedFilePath $clbLsp } catch {}
        if ($wsPreSignPath -and (Test-Path -LiteralPath $wsPreSignPath)) {
            [void]$allSignaturePaths.Add($wsPreSignPath)
        } else {
            Gui-Log "⚠️ Worksheet-signering vald men ingen Worksheet-fil hittades." 'Warn'
        }
    }
    $allSignaturePathsClean = @($allSignaturePaths.ToArray() | Where-Object { $_ } | Select-Object -Unique)
    if ($allSignaturePathsClean.Count -gt 0) {
        if (-not (Ensure-SignatureFilesClosedOrCancel -Paths $allSignaturePathsClean -Hint 'Stäng alla filer som ska signeras: Seal Test POS, Seal Test NEG och Worksheet. Signering kan inte starta om någon av filerna är öppen eller låst.')) {
            Gui-Log "🛑 Signering avbruten: en eller flera signeringsfiler är öppna/låsta. Inga nya signaturer skrevs i denna körning." 'Error'
            return
        }
    }
} catch {
    Gui-Log "🛑 Signering avbruten: kunde inte verifiera att signeringsfilerna är stängda. $($_.Exception.Message)" 'Error'
    return
}

# ============================================================
# === Pre-sign compact av riskflikar i Worksheet           ===
# ============================================================
# Körs före Seal Test-signering så att flödet inte kan halvsignera
# Seal Test-filer och därefter krascha på ett uppblåst Worksheet.
try {
    if ($doWsSamm -or $doWsGransk) {
        $wsPreCompactPath = $null
        try { $wsPreCompactPath = Get-CheckedFilePath $clbLsp } catch {}
        if ($wsPreCompactPath -and (Test-Path -LiteralPath $wsPreCompactPath)) {
            $pc = Invoke-IPTWorksheetPreSignCompact_OpenXml -Path $wsPreCompactPath
            if ($pc -and $pc.Changed) {
                $pcParts = @()
                try {
                    foreach ($s in @($pc.Sheets)) {
                        if ($s.Changed) {
                            $pcParts += ("{0}: {1}→{2} cellnoder" -f $s.SheetName, $s.BeforeCells, $s.AfterCells)
                        }
                    }
                } catch {}
                $pcText = ($pcParts -join '; ')
                if (-not $pcText) { $pcText = (Split-Path $wsPreCompactPath -Leaf) }
                Gui-Log ("🧹 Worksheet optimerad före signering: {0}" -f $pcText) 'Info'
                if ($pc.BackupPath) {
                    Gui-Log ("↩️ Backup före optimering: {0}" -f $pc.BackupPath) -Severity 'Info' -Category 'DEBUG'
                }
            }
        }
    }
} catch {
    Gui-Log ("🛑 Worksheet-optimering före signering misslyckades. Inga signaturer skrevs. " + $_.Exception.Message) 'Error'
    return
}

# Seal Test B47 = "Full name, SIGN, Date"
$signToWrite = ''
# Sätts per fil när denna körning faktiskt har skrivit signatur
# och read-back verifieringen har passerat.
# Då ska gammal inläst tom B47 inte flaggas som "Signatur saknas".
$negSealSignatureAppliedThisRun = $false
$posSealSignatureAppliedThisRun = $false
# Slutlogg ska baseras på faktisk verifierad signering, inte bara checkbox-val.
$wsSammSignatureVerifiedThisRun   = $false
$wsGranskSignatureVerifiedThisRun = $false
if ($doSealTest) {
            $signToWrite = "$sammName, $sammSign, $sammDate"
            if (-not (Confirm-SignatureInput -Text $signToWrite)) { Gui-Log "🛑 Seal Test-signatur ej bekräftad. Avbryter."; return }

            # Signera ORIGINAL om möjligt (snapshot används endast för läsning)
            $negPathForSign = if ($selNegOrig) { $selNegOrig } else { $selNeg }
            $posPathForSign = if ($selPosOrig) { $selPosOrig } else { $selPos }
            $pkgNegSign = $null
            $pkgPosSign = $null
            try {
                if ($negWritable) { $pkgNegSign = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($negPathForSign)) }
                if ($posWritable) { $pkgPosSign = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($posPathForSign)) }
            } catch {
                Gui-Log ("⚠️ Kunde inte öppna filen för signering: " + $_.Exception.Message) 'Warn'
            }
            }
            $negWritten = 0; $posWritten = 0; $negSkipped = 0; $posSkipped = 0

            # Hjälpfunktion: skriver signatur i alla aktiva datablad

            $resNeg = _SignSealTestSheets $pkgNegSign $signToWrite $Layout.SignatureCell $doOverwrite
            $resPos = _SignSealTestSheets $pkgPosSign $signToWrite $Layout.SignatureCell $doOverwrite
            $negWritten = $resNeg.Written; $negSkipped = $resNeg.Skipped
            $posWritten = $resPos.Written; $posSkipped = $resPos.Skipped

            # GDP A1: Ingen silent fail — Save-fel stoppar hela flödet
            if ($negWritten -eq 0 -and $negSkipped -eq 0 -and $posWritten -eq 0 -and $posSkipped -eq 0) {
            } else {
                try {
                    if ($negWritten -gt 0 -and $pkgNegSign) { $pkgNegSign.Save() }
                    if ($posWritten -gt 0 -and $pkgPosSign) { $pkgPosSign.Save() }
                } catch {
                    Gui-Log "❌ SIGNERINGSFEL: Kunde inte spara Seal Test: $($_.Exception.Message)" 'Error'
                    try { Save-ForensicSnapshot -SourcePath $(if($negPathForSign){$negPathForSign}else{$posPathForSign}) -Reason "Save() misslyckades: $($_.Exception.Message)" -AuditDir (Join-Path $ScriptRootPath 'audit') -Details @{ SignText=$signToWrite; NEG_Written=$negWritten; POS_Written=$posWritten } } catch {}
                    try { if ($pkgNegSign) { $pkgNegSign.Dispose() } } catch {}
                    try { if ($pkgPosSign) { $pkgPosSign.Dispose() } } catch {}
                    return
                }
                Gui-Log "🖊️ Signatur satt: NEG $negWritten blad (överhoppade $negSkipped), POS $posWritten blad (överhoppade $posSkipped)."
            }
            try { if ($pkgNegSign) { $pkgNegSign.Dispose() } } catch {}
            try { if ($pkgPosSign) { $pkgPosSign.Dispose() } } catch {}

            # GDP A2: Write → Save → Read-back verifiering
            $sealVerifyFailed = $false
            foreach ($vEntry in @(
                @{ Label='NEG'; Path=$negPathForSign; Written=$negWritten },
                @{ Label='POS'; Path=$posPathForSign; Written=$posWritten }
            )) {
                if ($vEntry.Written -gt 0 -and $vEntry.Path -and (Test-Path -LiteralPath $vEntry.Path)) {
                    $vr = Verify-SealTestSignatures -Path $vEntry.Path -ExpectedText $signToWrite -SignatureCell $Layout.SignatureCell -ActiveCheckCell $Layout.SealActiveCheckCell -ExpectedWritten $vEntry.Written
if ($vr.OK) {
    if ($vEntry.Label -eq 'NEG') { $negSealSignatureAppliedThisRun = $true }
    if ($vEntry.Label -eq 'POS') { $posSealSignatureAppliedThisRun = $true }
    Gui-Log "✅ Seal Test $($vEntry.Label) verifierad: $($vr.SheetsVerified)/$($vr.SheetsChecked) blad OK." 'Info'
} else {
                        $sealVerifyFailed = $true
                        $reason = if ($vr.Error) { $vr.Error } else { ($vr.Mismatches -join '; ') }
                        Gui-Log "❌ VERIFIERINGSFEL Seal Test $($vEntry.Label): $reason" 'Error'
                        # GDP A4: Forensisk snapshot
                        try { Save-ForensicSnapshot -SourcePath $vEntry.Path -Reason "Read-back mismatch: $reason" -AuditDir (Join-Path $ScriptRootPath 'audit') -Details @{ SignText=$signToWrite; Expected=$vEntry.Written; Verified=$vr.SheetsVerified; Mismatches=($vr.Mismatches -join '|') } } catch {}
                    }
                }
            }
if ($sealVerifyFailed) {
    Gui-Log "🛑 Seal Test-signatur ej verifierad. Rapport stoppas." 'Error'
    return

}

        # ==========================================
        # === SIGNATUR I WORKSHEET              ====
        # ==========================================

        if ($doWsSamm -or $doWsGransk) {
            $wsSignPath = $null
            try { $wsSignPath = Get-CheckedFilePath $clbLsp } catch {}
if (-not $wsSignPath -or -not (Test-Path -LiteralPath $wsSignPath)) {
    Gui-Log "⚠️ Ingen Worksheet vald – hoppar över Worksheet-signatur." 'Warn'
} else {
    # Hård spärr före signeringsplan.
    # Worksheet får inte vara öppen/låst när signering ska planeras eller skrivas.
    if (-not (Ensure-SignatureFilesClosedOrCancel -Paths @($wsSignPath) -Hint 'Stäng Worksheet-filen i Excel och klicka Försök igen. Signering kan inte genomföras mot en öppen eller låst fil.')) {
        Gui-Log "🛑 Worksheet-signatur avbruten: filen är öppen/låst." 'Error'
        return
    }
    # Bekräftelse
    $hasResample = [bool]$hasResampleCsv
                $wsTargets = New-Object System.Collections.Generic.List[string]
                if ($doWsSamm) {
                    try {
                        $planS = Get-WorksheetSignaturePlan_OpenXml -Path $wsSignPath -Mode 'Sammanstallning' -HasResample $hasResample -ModulesRoot $modulesRoot
                        if ($planS -and $planS.Planned) {
                            foreach ($p in $planS.Planned) { [void]$wsTargets.Add("Sammanställning: $p") }
                        }
                    } catch {
                        Gui-Log ("⚠️ Kunde inte läsa signeringsplan (Sammanställning): " + $_.Exception.Message) 'Warn'
                    }
                }
                if ($doWsGransk) {
                    try {
                        $planG = Get-WorksheetSignaturePlan_OpenXml -Path $wsSignPath -Mode 'Granskning' -HasResample $hasResample -ModulesRoot $modulesRoot
                        if ($planG -and $planG.Planned) {
                            foreach ($p in $planG.Planned) { [void]$wsTargets.Add("Granskning: $p") }
                        }
                    } catch {
                        Gui-Log ("⚠️ Kunde inte läsa signeringsplan (Granskning): " + $_.Exception.Message) 'Warn'
                    }
                }
                $wsConfirmed = Confirm-WorksheetSignInput -FullName $(if ($doWsSamm) { $sammName } else { $granskName }) -SignDate $(if ($doWsSamm) { $sammDate } else { $granskDate }) -Targets @($wsTargets.ToArray())
                if (-not $wsConfirmed) {
                    Gui-Log "🛑 Worksheet-signatur ej bekräftad." 'Info'
} elseif (-not (Ensure-SignatureFilesClosedOrCancel -Paths @($wsSignPath) -Hint 'Stäng Worksheet-filen i Excel och klicka Försök igen. Signering kan inte genomföras mot en öppen eller låst fil.')) {
    # Extra spärr precis före OpenXML-skrivning.
    Gui-Log "🛑 Worksheet-signatur avbruten: filen är öppen/låst." 'Error'
    return
} else {
$wsAllWrittenCells = New-Object System.Collections.Generic.List[pscustomobject]
$wsWrittenModes = New-Object System.Collections.Generic.HashSet[string]
try {
    $hasResample = [bool]$hasResampleCsv

                        # Konsoliderad loop: kör varje signerings-mode
                        $wsModes = @()
                        if ($doWsSamm)   { $wsModes += @{ Mode='Sammanstallning'; Label='Sammanställning'; Name=$sammName; Date=$sammDate; Overwrite=$doOverwrite } }
                        if ($doWsGransk) { $wsModes += @{ Mode='Granskning';      Label='Granskning';      Name=$granskName; Date=$granskDate; Overwrite=$doOverwriteGransk } }

                        foreach ($m in $wsModes) {
                            $wsRes = Invoke-WorksheetSignature_OpenXml -Path $wsSignPath -FullName $m.Name -SignDateYmd $m.Date -Mode $m.Mode -HasResample:$hasResample -Overwrite ([bool]$m.Overwrite) -ModulesRoot $modulesRoot
                            if ($wsRes.Written.Count -gt 0) {
                                Gui-Log ("🖊️ WS $($m.Label): " + ($wsRes.Written -join ', ')) 'Info'
                            }
                            if ($wsRes.Skipped.Count -gt 0) {
                                Gui-Log ("WS $($m.Label) – överhoppade: " + ($wsRes.Skipped -join ', ')) -Severity 'Info' -Category 'DEBUG'
                            }
# Samla skrivna celler för verifiering
if ($wsRes.WrittenCells -and $wsRes.WrittenCells.Count -gt 0) {
    [void]$wsWrittenModes.Add(($m.Mode + ''))
    foreach ($wc in $wsRes.WrittenCells) { [void]$wsAllWrittenCells.Add($wc) }
}
                        }
                        # GDP A2: Write → Save → Read-back verifiering
                        if ($wsAllWrittenCells.Count -gt 0) {
                            $wsVerify = Verify-WorksheetSignatures -Path $wsSignPath -WrittenCells @($wsAllWrittenCells.ToArray())
                            if ($wsVerify.OK) {
    if ($wsWrittenModes.Contains('Sammanstallning')) {
        $wsSammSignatureVerifiedThisRun = $true
    }
    if ($wsWrittenModes.Contains('Granskning')) {
        $wsGranskSignatureVerifiedThisRun = $true
    }
    Gui-Log "✅ Worksheet-signatur verifierad: $($wsVerify.CellsVerified)/$($wsVerify.CellsChecked) celler OK. $(Split-Path $wsSignPath -Leaf)" 'Info'
} else {
                                $reason = if ($wsVerify.Error) { $wsVerify.Error } else { ($wsVerify.Mismatches -join '; ') }
                                Gui-Log "❌ VERIFIERINGSFEL Worksheet: $reason" 'Error'
                                # GDP A4: Forensisk snapshot
                                try { Save-ForensicSnapshot -SourcePath $wsSignPath -Reason "WS read-back mismatch: $reason" -AuditDir (Join-Path $ScriptRootPath 'audit') -Details @{ Checked=$wsVerify.CellsChecked; Verified=$wsVerify.CellsVerified; Mismatches=($wsVerify.Mismatches -join '|') } } catch {}
                                Gui-Log "🛑 Worksheet-signatur ej verifierad. Rapport stoppas." 'Error'
                                return
                            }
                        } else {
                            Gui-Log "✅ Worksheet-signatur sparad (inga nya celler skrivna — redan ifyllda): $(Split-Path $wsSignPath -Leaf)" 'Info'
                        }
                    } catch {
                        # GDP A1: Ingen silent fail — Exception stoppar flödet
                        Gui-Log ("❌ SIGNERINGSFEL Worksheet: " + $_.Exception.Message) 'Error'
                        try { Save-ForensicSnapshot -SourcePath $wsSignPath -Reason "Exception: $($_.Exception.Message)" -AuditDir (Join-Path $ScriptRootPath 'audit') } catch {}
                        return
                    }
                }
            }
        }

        Mark-Phase 'Signering'

