﻿#region Importering och config
if ([Threading.Thread]::CurrentThread.ApartmentState -ne 'STA') {
    $exe = Join-Path $PSHome 'powershell.exe'
    $scriptPath = if ($PSCommandPath) { $PSCommandPath } else { $MyInvocation.MyCommand.Path }
    Start-Process -FilePath $exe -ArgumentList "-NoProfile -STA -ExecutionPolicy Bypass -File `"$scriptPath`""
    exit
}

# ---- Soft spärr ---
$scriptPath = if ($PSCommandPath) { $PSCommandPath } else { $MyInvocation.MyCommand.Path }
$ScriptRootPath = [System.IO.Path]::GetDirectoryName([System.IO.Path]::GetFullPath($scriptPath))
. (Join-Path $ScriptRootPath 'App\EarlyGuards.ps1')

$BlockedUsers = @(
    # Lägg in i lower-case:
    # 'jesper.fredriksson'
    # 'namn.efternamn',
    # 'domain\namn.efternamn'
)

if (Test-IsBlockedUser -DenyList $BlockedUsers) {
    try {
        [System.Windows.Forms.MessageBox]::Show(
            "Tyvärr – skriptet är avstängt för dig.",
            "IPTCompile",
            [System.Windows.Forms.MessageBoxButtons]::OK,
            [System.Windows.Forms.MessageBoxIcon]::Stop
        ) | Out-Null
    } catch {
        Write-Host "Tyvärr – skriptet är avstängt för dig." -ForegroundColor Red
    }
    exit 1
}

Add-Type -AssemblyName System.Windows.Forms
try { [System.Windows.Forms.Application]::EnableVisualStyles() } catch {}
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.ComponentModel
try {
    Add-Type -AssemblyName 'Microsoft.VisualBasic' -ErrorAction SilentlyContinue
} catch {}

$installLock = Join-Path $ScriptRootPath '.install.lock'
if (Test-Path -LiteralPath $installLock) {
    $msg = "Install/uppdatering pågår (lock-fil finns): $installLock`nStarta om IPTCompile när uppdateringen är klar."
    try { [System.Windows.Forms.MessageBox]::Show($msg,'IPTCompile') | Out-Null } catch { Write-Host $msg }
    exit 2
}
$PSScriptRoot = $ScriptRootPath
try {
    $cwd = (Get-Location).Path
    Write-Host ("[EXEC] Script={0} | ScriptRoot={1} | CWD={2}" -f $scriptPath, $ScriptRootPath, $cwd)
} catch {}
$modulesRoot = Join-Path $ScriptRootPath 'Modules'

$libRoot = Join-Path $ScriptRootPath 'Lib'
$global:ModulesRoot = $modulesRoot
$global:LibRoot     = $libRoot
# Konstanter: bladnamn, cellreferenser.
# Om jag ändrar i mallen!
$Layout = @{
    # Cellreferenser
    SignatureCell        = 'B47'       # Seal Test signaturcell
    SealActiveCheckCell  = 'H3'        # Cell som avgör om Seal-flik är aktiv
    AssayNameCell        = 'D10'       # Assay-namn i output
    SpInfoStartCell      = 'E1'        # SharePoint info start i Run Information

    # Bladnamn i output-mallen
    SheetRunInfo         = 'Run Information'
    SheetDataSummary     = 'Data Summary'
    SheetExtraSummary    = 'Extra Data Summary'
    SheetResampleSummary = 'Resample Data Summary'
    SheetSealTestInfo    = 'Seal Test Info'
    SheetStfSummary      = 'STF Summary'
    SheetQcSummary       = 'QC Summary'
    SheetKontrollmaterial= 'Kontrollmaterial'
    SheetUtrustning      = 'Utrustningslista'
}

. (Join-Path $modulesRoot 'Config.ps1') -ScriptRoot $ScriptRootPath
. (Join-Path $modulesRoot 'Splash.ps1')
. (Join-Path $modulesRoot 'SharePointClient.ps1')
. (Join-Path $modulesRoot 'UiStyling.ps1')

# Consolidated direct loads (former shim-backed modules)
. (Join-Path $ScriptRootPath 'Infrastructure\LoggingCore.ps1')
. (Join-Path $ScriptRootPath 'App\UiLogging.ps1')

try {
    $netRoot = ($env:IPT_NETWORK_ROOT + '').Trim()
    $iptRoot = ($global:IPT_ROOT_EFFECTIVE + '').Trim()
    $iptSrc  = ($global:IPT_ROOT_SOURCE + '').Trim()
    $logPath = ($global:LogPath + '').Trim()
    $jsonl   = ($global:StructuredLogPath + '').Trim()

    if (-not $netRoot) { $netRoot = '<empty>' }
    if (-not $iptRoot) { $iptRoot = '<empty>' }
    if (-not $iptSrc)  { $iptSrc  = '<empty>' }
    if (-not $logPath) { $logPath = '<empty>' }
    if (-not $jsonl)   { $jsonl   = '<empty>' }

    $msg = "Sanity: IPT_NETWORK_ROOT=$netRoot | IPT_ROOT_EFFECTIVE=$iptRoot | IPT_ROOT_SOURCE=$iptSrc | LogPath=$logPath | StructuredLogPath=$jsonl"
    try { Gui-Log -Text $msg -Severity 'Info' -Category 'SANITY' } catch { Write-Host $msg }
} catch { }

. (Join-Path $ScriptRootPath 'Infrastructure\ExcelEpplus.ps1')
. (Join-Path $ScriptRootPath 'Infrastructure\Csv.ps1')
. (Join-Path $ScriptRootPath 'Infrastructure\FileStaging.ps1')
. (Join-Path $ScriptRootPath 'Core\AssayNormalization.ps1')
. (Join-Path $ScriptRootPath 'Core\HeaderParsing.ps1')
. (Join-Path $ScriptRootPath 'Core\HeaderComparison.ps1')
. (Join-Path $ScriptRootPath 'Core\OutputPlanning.ps1')
if (-not (Get-Command Get-CellText -ErrorAction SilentlyContinue)) {
    throw "Consolidated direct load misslyckades: Get-CellText saknas efter ExcelEpplus/Header/Csv-load."
}

. (Join-Path $ScriptRootPath 'Core\SignatureWorkflow.ps1')
. (Join-Path $ScriptRootPath 'App\UiSignatureDialogs.ps1')
. (Join-Path $ScriptRootPath 'Infrastructure\Forensics.ps1')
. (Join-Path $ScriptRootPath 'Infrastructure\ExcelOpenXml.ps1')
. (Join-Path $ScriptRootPath 'Core\OpenXmlSignatureWorkflow.ps1')
. (Join-Path $ScriptRootPath 'Core\RuleEngineCore.ps1')
. (Join-Path $ScriptRootPath 'Core\RuleEngineDebug.ps1')
. (Join-Path $ScriptRootPath 'App\UiHelpers.ps1')
. (Join-Path $ScriptRootPath 'App\Bootstrap.ps1')
. (Join-Path $ScriptRootPath 'App\UiDialogs.ps1')
. (Join-Path $ScriptRootPath 'App\BuildController.ps1')
. (Join-Path $ScriptRootPath 'App\UiTheme.ps1')


$global:SpEnabled = Get-ConfigFlag -Name 'EnableSharePoint' -Default $true -ConfigOverride $Config
$global:SpAutoConnect = if ($global:SpEnabled) {
    Get-ConfigFlag -Name 'EnableSharePointAutoConnect' -Default $true -ConfigOverride $Config
} else { $false }

$global:StartupReady = $true
$configStatus = $null

try {

    $configStatus = Test-Config
    if ($configStatus) {
        foreach ($err in $configStatus.Errors) { Gui-Log "❌ Konfig-fel: $err" 'Error' }
        foreach ($warn in $configStatus.Warnings) { Gui-Log "⚠️ Konfig-varning: $warn" 'Warn' }
        if (-not $configStatus.Ok) {
            $global:StartupReady = $false
            try { [System.Windows.Forms.MessageBox]::Show("Startkontroll misslyckades. Se logg för detaljer.","Startkontroll") | Out-Null } catch {}
        }
    }
} catch { Gui-Log "❌ Test-Config misslyckades: $($_.Exception.Message)" 'Error'; $global:StartupReady = $false }

$Host.UI.RawUI.WindowTitle = "Startar…"
Show-Splash "Laddar PowerShell…"
$env:PNPPOWERSHELL_UPDATECHECK = 'Off'

$global:SpConnected = $false
$global:SpError     = $null

if ($global:SpAutoConnect) {
    # Autokoppling: starta SPClient-runspace + importera PnP + anslut (synkront under splash)
    $spStartOk = Start-SPClient -ProgressCallback { param($m) Update-Splash $m }
    if ($spStartOk) {
        Update-Splash 'Ansluter till SharePoint…'
        $spConnOk = Connect-SPClient -ProgressCallback { param($m) Update-Splash $m }
        if ($spConnOk) {
            $global:SpConnected = $true
        } else {
            $msg = "Connect-PnPOnline misslyckades: $($global:SpError)"
            Update-Splash $msg
        }
    } else {
        $msg = "PnP-import misslyckades: $($global:SpError)"
        Update-Splash $msg
    }
} elseif (-not $global:SpEnabled) {
    $global:SpError = 'SharePoint avstängt i Config'
    try { Gui-Log "ℹ️ SharePoint är avstängt i konfigurationen." 'Info' } catch {}
} else {
    # SpEnabled = true men AutoConnect = false → snabbstart, SPClient startas vid knapptryck
    $global:SpError = $null
    try { Gui-Log "ℹ️ SharePoint: manuell anslutning (klicka '🔌 Anslut SP' vid behov)." 'Info' } catch {}
}
try { $null = Ensure-EPPlus -Version '4.5.3.3' } catch { Gui-Log "⚠️ EPPlus-förkontroll misslyckades: $($_.Exception.Message)" 'Warn' }
#endregion Importering och config

#region GUI 

Update-Splash "Startar…"
Close-Splash

# ---- Sessionsspårning ----
$script:SessionStats = @{
    ReportCount     = 0
    TotalBuildMs    = 0
    TotalTestsBuilt = 0
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "IPTCompile – $ScriptVersion"
$form.AutoScaleMode = 'Dpi'
$form.Size = New-Object System.Drawing.Size(980,860)
$form.MinimumSize = New-Object System.Drawing.Size(980,860)
$form.StartPosition = 'CenterScreen'
$form.BackColor = [System.Drawing.Color]::WhiteSmoke
$form.AutoScroll  = $false
$form.MaximizeBox = $false
$form.Padding     = New-Object System.Windows.Forms.Padding(8)
$form.Font        = New-Object System.Drawing.Font('Segoe UI',10)

function Get-ReleaseNotesCachePath {
    try {
        $base = [Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)
        if ([string]::IsNullOrWhiteSpace($base)) { $base = $env:TEMP }
        $dir = Join-Path $base 'IPTCompile'
        if (-not (Test-Path -LiteralPath $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
        }
        return (Join-Path $dir 'last_release_notes_version.txt')
    } catch {
        return (Join-Path $env:TEMP 'IPTCompile_last_release_notes_version.txt')
    }
}
function Get-ReleaseNotesForVersion {
    param(
        [string]$Version,
        [string]$RootPath
    )
    if ([string]::IsNullOrWhiteSpace($Version)) { return '' }
    $notesPath = Join-Path $RootPath 'ReleaseNotes.psd1'
    if (-not (Test-Path -LiteralPath $notesPath)) { return '' }
    try {
        $map = Import-PowerShellDataFile -Path $notesPath
        if (-not $map) { return '' }
        $key = $Version.Trim()
        if (-not $map.ContainsKey($key)) { return '' }
        $notes = $map[$key]
        if ($notes -is [array]) {
            return (($notes | ForEach-Object { '' + $_ }) -join [Environment]::NewLine)
        }
        return ('' + $notes).Trim()
    } catch {
        try { Gui-Log ("⚠️ Kunde inte läsa ReleaseNotes.psd1: " + $_.Exception.Message) 'Warn' } catch {}
        return ''
    }
}
function Show-ReleaseNotesIfNewVersion {
    param(
        [string]$Version,
        [string]$RootPath
    )
    if ([string]::IsNullOrWhiteSpace($Version)) { return }
    $notes = Get-ReleaseNotesForVersion -Version $Version -RootPath $RootPath
    if ([string]::IsNullOrWhiteSpace($notes)) { return }
    $cachePath = Get-ReleaseNotesCachePath
    $seen = ''
    try {
        if (Test-Path -LiteralPath $cachePath) {
            $seen = ((Get-Content -LiteralPath $cachePath -Raw -ErrorAction Stop) + '').Trim()
        }
    } catch {
        $seen = ''
    }
    if ($seen -eq $Version.Trim()) { return }
    try {
        Show-StyledInfoDialog `
            -Title "Ny version - visas endast när skriptet uppdaterats" `
            -HeaderText ("Ny version – " + $Version) `
            -Body $notes `
            -Width 620 `
            -Height 460
        Set-Content -LiteralPath $cachePath -Value $Version.Trim() -Encoding UTF8
    } catch {
        try { Gui-Log ("⚠️ Kunde inte visa versionsnyheter: " + $_.Exception.Message) 'Warn' } catch {}
    }
}
$form.Add_Shown({
    try {
        Show-ReleaseNotesIfNewVersion -Version $ScriptVersion -RootPath $ScriptRootPath
    } catch {}
})
$form.KeyPreview = $true
$form.add_KeyDown({
    # F5 → Skapa rapport (samma som att klicka Build-knappen)
    if ($_.KeyCode -eq [System.Windows.Forms.Keys]::F5) {
        $_.Handled = $true
        if ($btnBuild.Enabled -and -not $script:BuildInProgress) {
            $btnBuild.PerformClick()
        }
        return
    }
    # Ctrl+L → Rensa logg
    if ($_.Control -and $_.KeyCode -eq [System.Windows.Forms.Keys]::L) {
        $_.Handled = $true
        try { $outputBox.Text = ''; $outputBox.ForeColor = [System.Drawing.SystemColors]::WindowText; $script:_logPlaceholderActive = $false } catch {}
        return
    }
    # Ctrl+N → Nytt (rensa alla filer)
    if ($_.Control -and $_.KeyCode -eq [System.Windows.Forms.Keys]::N) {
        $_.Handled = $true
        if (-not $script:BuildInProgress) { try { Clear-GUI } catch {} }
        return
    }
    # Ctrl+O → Öppna senaste rapport
    if ($_.Control -and $_.KeyCode -eq [System.Windows.Forms.Keys]::O) {
        $_.Handled = $true
        if ($global:LastReportPath -and (Test-Path -LiteralPath $global:LastReportPath)) {
            try { Start-Process -FilePath $global:LastReportPath } catch {}
        }
        return
    }
    if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Escape) {
        if ($script:BuildInProgress) {
            $_.Handled = $true
            Gui-Log '⚠️ Rapportgenerering pågår – avbryt inte.' 'Warn'
            return
        }
        $form.Close(); return
    }
    # Hemlig dev-toggle: Ctrl + Alt + T
    try {
        if ($_.Control -and $_.Alt -and ($_.KeyCode -eq [System.Windows.Forms.Keys]::T)) {
            if ($script:btnMove3) {
                $script:btnMove3.Visible = -not $script:btnMove3.Visible
                try {
                    if ($script:btnMove3.Visible) { Gui-Log "TEST-knapp synlig." 'Info' }
                    else                          { Gui-Log "TEST-knapp dold." 'Info' }
                } catch {}
            }
            $_.Handled = $true
        }
    } catch {}
})

# ---------- Menyrad ----------
$menuStrip = New-Object System.Windows.Forms.MenuStrip
$menuStrip.Dock='Top'; $menuStrip.GripStyle='Hidden'
$menuStrip.ImageScalingSize = New-Object System.Drawing.Size(20,20)
$menuStrip.Padding = New-Object System.Windows.Forms.Padding(8,6,0,6)
$menuStrip.Font = New-Object System.Drawing.Font('Segoe UI',10)
$miArkiv   = New-Object System.Windows.Forms.ToolStripMenuItem('🗂️ Arkiv')
$miVerktyg = New-Object System.Windows.Forms.ToolStripMenuItem('🛠️ Verktyg')
$miHelp    = New-Object System.Windows.Forms.ToolStripMenuItem('📖 Instruktioner')
$miAbout   = New-Object System.Windows.Forms.ToolStripMenuItem('ℹ️ Om')
$miCopyLog = New-Object System.Windows.Forms.ToolStripMenuItem('📋 Kopiera logg')
$miCopyLog.ShortcutKeyDisplayString = 'Ctrl+L rensa'
$miScan  = New-Object System.Windows.Forms.ToolStripMenuItem('🔍 Sök filer')
$miBuild = New-Object System.Windows.Forms.ToolStripMenuItem('✅ Skapa rapport')
$miBuild.ShortcutKeyDisplayString = 'F5'
$miExit  = New-Object System.Windows.Forms.ToolStripMenuItem('❌ Avsluta')

# Rensa ev. gamla undermenyer
$miArkiv.DropDownItems.Clear()
$miVerktyg.DropDownItems.Clear()
$miHelp.DropDownItems.Clear()

# ----- Arkiv -----
$miNew         = New-Object System.Windows.Forms.ToolStripMenuItem('🆕 Nytt')
$miNew.ShortcutKeyDisplayString = 'Ctrl+N'
$miOpenRecent  = New-Object System.Windows.Forms.ToolStripMenuItem('📂 Öppna senaste rapport')
$miOpenRecent.ShortcutKeyDisplayString = 'Ctrl+O'
$miArkiv.DropDownItems.AddRange(@(
    $miNew,
    $miOpenRecent,
    (New-Object System.Windows.Forms.ToolStripSeparator),
    $miExit
))

$miCopyLog.add_Click({
    try {
        $logText = ''
        foreach ($item in $logBox.Items) { $logText += "$item`r`n" }
        if ($logText) {
            [System.Windows.Forms.Clipboard]::SetText($logText)
            Gui-Log "📋 Logg kopierad till urklipp ($($logBox.Items.Count) rader)." 'Info'
        }
    } catch { Gui-Log "⚠️ Kunde inte kopiera logg: $($_.Exception.Message)" 'Warn' }
})

# ----- Verktyg -----
$miScript1   = New-Object System.Windows.Forms.ToolStripMenuItem('📜 Kontrollprovsfil-skript')
$miScript2   = New-Object System.Windows.Forms.ToolStripMenuItem('📜 Aktivera Kontrollprovsfil')
$miScript3   = New-Object System.Windows.Forms.ToolStripMenuItem('📅 Ändra datum på filer')
$miScript4   = New-Object System.Windows.Forms.ToolStripMenuItem('🗂️ AutoMappscript Control')
$miScript5   = New-Object System.Windows.Forms.ToolStripMenuItem('📄 AutoMappscript Dashboard')
$miToggleSignSamm   = New-Object System.Windows.Forms.ToolStripMenuItem('✅ Aktivera signering (Sammanställning)')
$miToggleSignGransk = New-Object System.Windows.Forms.ToolStripMenuItem('✅ Aktivera signering (Granskning)')
$miVerktyg.DropDownItems.AddRange(@(
    $miScript1,
    $miScript2,
    $miScript3,
    $miScript4,
    $miScript5,
    (New-Object System.Windows.Forms.ToolStripSeparator),
    $miToggleSignSamm,
    $miToggleSignGransk
))

# Config-gated: dölj signeringsmenyval om avstängt i Config
$miToggleSignSamm.Visible   = (Get-ConfigFlag -Name 'EnableSignSammanstallning' -Default $true)
$miToggleSignGransk.Visible = (Get-ConfigFlag -Name 'EnableSignGranskning' -Default $true)

# Config-gated: dölj avancerade skript (Kontrollprovsfil + AutoMappscript)
$showAdvScripts = (Get-ConfigFlag -Name 'ShowAdvancedScripts' -Default $false)
$miScript1.Visible = $showAdvScripts
$miScript2.Visible = $showAdvScripts
$miScript4.Visible = $showAdvScripts
$miScript5.Visible = $showAdvScripts

# ----- Instruktioner -----
$miShowInstr   = New-Object System.Windows.Forms.ToolStripMenuItem('📖 Visa instruktioner')
$miFAQ         = New-Object System.Windows.Forms.ToolStripMenuItem('❓ FAQ')
$miHelpDlg     = New-Object System.Windows.Forms.ToolStripMenuItem('🆘 Hjälp')
$miStatus      = New-Object System.Windows.Forms.ToolStripMenuItem('📌 Status (Done / Todo)')
$miHelp.DropDownItems.AddRange(@($miShowInstr,$miFAQ,$miHelpDlg,$miStatus))

$miGenvagar = New-Object System.Windows.Forms.ToolStripMenuItem('🔗 Genvägar')
$ShortcutGroups = Get-ConfigValue -Name 'ShortcutGroups' -Default $null -ConfigOverride $Config
if (-not $ShortcutGroups) {
    # Reservväg om config saknar genvägar
    $ShortcutGroups = @{
        '🗂️ IPT-mappar' = @(
            @{ Text='📂 IPT - PÅGÅENDE KÖRNINGAR';        Target='N:\QC\QC-1\IPT\2. IPT - PÅGÅENDE KÖRNINGAR' },
            @{ Text='📂 IPT - KLART FÖR SAMMANSTÄLLNING'; Target='N:\QC\QC-1\IPT\3. IPT - KLART FÖR SAMMANSTÄLLNING' },
            @{ Text='📂 IPT - KLART FÖR GRANSKNING';      Target='N:\QC\QC-1\IPT\4. IPT - KLART FÖR GRANSKNING' },
            @{ Text='📂 SPT Macro Assay';                 Target='N:\QC\QC-0\SPT\SPT macros\Assay' }
        )
        '📄 Dokument' = @(
            @{ Text='🧰 Utrustningslista';    Target=$UtrustningListPath },
            @{ Text='🧪 Kontrollprovsfil';    Target=$RawDataPath }
        )
        '🌐 Länkar' = @(
            @{ Text='⚡ IPT App';              Target='https://apps.powerapps.com/play/e/default-771c9c47-7f24-44dc-958e-34f8713a8394/a/fd340dbd-bbbf-470b-b043-d2af4cb62c83' },
            @{ Text='🌐 MES';                  Target='http://mes.cepheid.pri/camstarportal/?domain=CEPHEID.COM' },
            @{ Text='🌐 CSV Uploader';         Target='http://auw2wgxtpap01.cepaws.com/Welcome.aspx' },
            @{ Text='🌐 BMRAM';                Target='https://cepheid62468.coolbluecloud.com/' },
            @{ Text='🌐 Agile';                Target='https://agileprod.cepheid.com/Agile/default/login-cms.jsp' }
        )
    }
}

foreach ($grp in $ShortcutGroups.GetEnumerator()) {

    $grpMenu = New-Object System.Windows.Forms.ToolStripMenuItem($grp.Key)
    foreach ($entry in $grp.Value) { Add-ShortcutItem -Parent $grpMenu -Text $entry.Text -Target $entry.Target }
    [void]$miGenvagar.DropDownItems.Add($grpMenu)

}

$miOm = New-Object System.Windows.Forms.ToolStripMenuItem('ℹ️ Om det här verktyget'); [void]$miAbout.DropDownItems.Add($miOm)
$menuStrip.Items.AddRange(@($miArkiv,$miVerktyg,$miGenvagar,$miHelp,$miAbout))
$form.MainMenuStrip=$menuStrip

# ---------- Rubrik ----------
$panelHeader = New-Object System.Windows.Forms.Panel
$panelHeader.Dock='Top'; $panelHeader.Height=82
$panelHeader.BackColor=[System.Drawing.Color]::SteelBlue
$panelHeader.Padding = New-Object System.Windows.Forms.Padding(10,8,10,8)

$picLogo = New-Object System.Windows.Forms.PictureBox
$picLogo.Dock = 'Left'
$picLogo.Width = 50
$picLogo.BorderStyle = 'FixedSingle'
$picLogo.SizeMode = 'Zoom'
if (Test-Path -LiteralPath $ikonSokvag) { $picLogo.Image = [System.Drawing.Image]::FromFile($ikonSokvag) }

$panelText = New-Object System.Windows.Forms.Panel
$panelText.Dock = 'Fill'
$panelText.BackColor = $panelHeader.BackColor

$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = "IPTCompile – $ScriptVersion"
$lblTitle.ForeColor = [System.Drawing.Color]::White
$lblTitle.Font = New-Object System.Drawing.Font('Segoe UI Semibold',13)
$lblTitle.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$lblTitle.Dock = 'Top'
$lblTitle.Height = 30
$lblTitle.Padding = New-Object System.Windows.Forms.Padding(8,0,0,0)

$lblUpdate = New-Object System.Windows.Forms.Label
$lblUpdate.Text      = 'Hjälpmedel vid IPT dokumentation'
$lblUpdate.ForeColor = [System.Drawing.Color]::White
$lblUpdate.Font      = New-Object System.Drawing.Font('Segoe UI Semibold',10)
$lblUpdate.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$lblUpdate.Dock      = 'Top'
$lblUpdate.Height    = 16
$lblUpdate.Padding   = New-Object System.Windows.Forms.Padding(8,0,0,0)

$lblExtra = New-Object System.Windows.Forms.Label
$lblExtra.Text = 'Läs "Instruktioner"'
$lblExtra.ForeColor = [System.Drawing.Color]::White
$lblExtra.Font = New-Object System.Drawing.Font('Segoe UI Semibold',10)
$lblExtra.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$lblExtra.Dock = 'Top'
$lblExtra.Height = 14
$lblExtra.Padding = New-Object System.Windows.Forms.Padding(8,1,0,0)

$panelText.Controls.Add($lblExtra)
$panelText.Controls.Add($lblUpdate)
$panelText.Controls.Add($lblTitle)

$panelHeader.Controls.Add($panelText)
$panelHeader.Controls.Add($picLogo)

$panelHeader.Add_Resize({
    $innerH = $panelHeader.Height - $panelHeader.Padding.Top - $panelHeader.Padding.Bottom
    $picLogo.Height = $innerH
    $picLogo.Width  = $innerH 
})

$form.add_FormClosed({ try { if ($picLogo.Image) { $picLogo.Image.Dispose() } } catch {} })
$form.add_Shown({
    try {
        if ($script:btnMove3) { $script:btnMove3.Visible = $false }
        $form.Top -= 70
    } catch {}
    try { Apply-UserDefaults } catch {}
})

# ---------- Sök-rad ----------
$tlSearch = New-Object System.Windows.Forms.TableLayoutPanel
$tlSearch.Dock='Top'; $tlSearch.AutoSize=$true; $tlSearch.AutoSizeMode='GrowAndShrink'
$tlSearch.Padding = New-Object System.Windows.Forms.Padding(0,10,0,8)
$tlSearch.ColumnCount=3
[void]$tlSearch.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$tlSearch.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
[void]$tlSearch.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute,130)))

$lblLSP = New-Object System.Windows.Forms.Label
$lblLSP.Text='LSP:'; $lblLSP.Anchor='Left'; $lblLSP.AutoSize=$true
$lblLSP.Margin = New-Object System.Windows.Forms.Padding(0,6,8,0)
$txtLSP = New-Object System.Windows.Forms.TextBox
$txtLSP.Dock='Fill'
$txtLSP.Margin = New-Object System.Windows.Forms.Padding(0,2,10,2)
# G2: Placeholder/cue-banner så användaren ser förväntat format
try {
    $null = Add-Type -Name 'WinUser_CueBanner' -Namespace 'IPT' -PassThru -MemberDefinition '
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, string lParam);
    '
    $txtLSP.add_HandleCreated({
        [IPT.WinUser_CueBanner]::SendMessage($this.Handle, 0x1501, [IntPtr]::Zero, 'T.ex. 38401') | Out-Null
    })
} catch {}
$btnScan = New-Object System.Windows.Forms.Button
$btnScan.Text='Sök filer'; $btnScan.Dock='Fill'; Set-AccentButton $btnScan -Primary
$btnScan.Margin= New-Object System.Windows.Forms.Padding(0,2,0,2)

$tlSearch.Controls.Add($lblLSP,0,0)
$tlSearch.Controls.Add($txtLSP,1,0)

# ---------- Flytta nedladdade filer (Camstar -> Downloads -> N:) ----------
$grpDl = New-Object System.Windows.Forms.GroupBox
$grpDl.Text = 'Flytta nedladdade filer från "Downloads" vid granskning'
$grpDl.Dock = 'Top'
$grpDl.Padding = New-Object System.Windows.Forms.Padding(10,8,10,10)
$grpDl.AutoSize = $true
$grpDl.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink

$tlDl = New-Object System.Windows.Forms.TableLayoutPanel
$tlDl.Dock = 'Top'
$tlDl.AutoSize = $true
$tlDl.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
$tlDl.ColumnCount = 3
$tlDl.RowCount = 1
$tlDl.Margin = New-Object System.Windows.Forms.Padding(0,0,0,0)
$tlDl.Padding = New-Object System.Windows.Forms.Padding(0,0,0,0)

# Kolumner: [Text tar allt] [KLART normal] [TEST liten]
[void]$tlDl.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
[void]$tlDl.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 240)))
[void]$tlDl.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 90)))
[void]$tlDl.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))

$lblDl = New-Object System.Windows.Forms.Label
$lblDl.Text = 'Matchar LSP i filnamn och flyttar från Downloads till rätt granskningsmapp.'
$lblDl.Dock = 'Fill'
$lblDl.AutoSize = $false
$lblDl.AutoEllipsis = $true
$lblDl.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$lblDl.Margin = New-Object System.Windows.Forms.Padding(0,0,10,0)

# KLART först (närmast texten)
$btnMove4 = New-Object System.Windows.Forms.Button
$btnMove4.Text = 'KLART FÖR GRANSKNING'
$btnMove4.Width = 240
$btnMove4.Height = 30
$btnMove4.Anchor = [System.Windows.Forms.AnchorStyles]::Right
$btnMove4.Margin = New-Object System.Windows.Forms.Padding(0,0,6,0)
Set-AccentButton $btnMove4

# TEST längst till höger (liten + dold)
$btnMove3 = New-Object System.Windows.Forms.Button
$btnMove3.Text = 'TEST'
$btnMove3.Width = 90
$btnMove3.Height = 30
$btnMove3.Anchor = [System.Windows.Forms.AnchorStyles]::Right
$btnMove3.Margin = New-Object System.Windows.Forms.Padding(0,0,0,0)
$btnMove3.Visible = $false
Set-AccentButton $btnMove3
$script:btnMove3 = $btnMove3

$tlDl.Controls.Add($lblDl, 0, 0)
$tlDl.Controls.Add($btnMove4, 1, 0)
$tlDl.Controls.Add($btnMove3, 2, 0)

$grpDl.Controls.Add($tlDl)
$tlSearch.Controls.Add($btnScan,2,0)

$pLog = New-Object System.Windows.Forms.Panel
$pLog.Dock='Top'; $pLog.Height=100; $pLog.Padding=New-Object System.Windows.Forms.Padding(0,0,0,8)

$outputBox = New-Object System.Windows.Forms.TextBox
$outputBox.Multiline=$true; $outputBox.ScrollBars='Vertical'; $outputBox.ReadOnly=$true
$outputBox.BackColor='White'; $outputBox.Dock='Fill'
$outputBox.Font = New-Object System.Drawing.Font('Segoe UI',9)
$pLog.Controls.Add($outputBox)
try { Set-LogOutputControl -Control $outputBox } catch {}
$outputBox.ForeColor = [System.Drawing.Color]::Silver
$outputBox.Text = ""
$script:_logPlaceholderActive = $true

$grpPick = New-Object System.Windows.Forms.GroupBox
$grpPick.Text='Välj filer för rapport'
$grpPick.Dock='Top'
$grpPick.Padding = New-Object System.Windows.Forms.Padding(10,12,10,14)
$grpPick.AutoSize=$false
$grpPick.Height = (78*3) + $grpPick.Padding.Top + $grpPick.Padding.Bottom +15

$tlPick = New-Object System.Windows.Forms.TableLayoutPanel
$tlPick.Dock='Fill'; $tlPick.ColumnCount=3; $tlPick.RowCount=3
$tlPick.GrowStyle=[System.Windows.Forms.TableLayoutPanelGrowStyle]::FixedSize
[void]$tlPick.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$tlPick.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
[void]$tlPick.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute,100)))
for($i=0;$i -lt 3;$i++){ [void]$tlPick.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,78))) }


$lblCsv=$null;$clbCsv=$null;$btnCsvBrowse=$null
New-ListRow -labelText 'CSV-fil:' -lbl ([ref]$lblCsv) -clb ([ref]$clbCsv) -btn ([ref]$btnCsvBrowse)
$lblNeg=$null;$clbNeg=$null;$btnNegBrowse=$null
New-ListRow -labelText 'Seal Test Neg:' -lbl ([ref]$lblNeg) -clb ([ref]$clbNeg) -btn ([ref]$btnNegBrowse)
$lblPos=$null;$clbPos=$null;$btnPosBrowse=$null
New-ListRow -labelText 'Seal Test Pos:' -lbl ([ref]$lblPos) -clb ([ref]$clbPos) -btn ([ref]$btnPosBrowse)

try {
    if ($tlPick.RowCount -lt 4) {
        $tlPick.RowCount = 4
        for ($i=$tlPick.RowStyles.Count; $i -lt 4; $i++) {
            $null = $tlPick.RowStyles.Add( (New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, 78)) )
        }
        $grpPick.Height = (78*4) + $grpPick.Padding.Top + $grpPick.Padding.Bottom + 15
    }
} catch {}

$lblLsp = $null; $clbLsp = $null; $btnLspBrowse = $null
New-ListRow -labelText 'Worksheet:' -lbl ([ref]$lblLsp) -clb ([ref]$clbLsp) -btn ([ref]$btnLspBrowse)

$tlPick.Controls.Add($lblLsp,  0, 3)
$tlPick.Controls.Add($clbLsp,  1, 3)
$tlPick.Controls.Add($btnLspBrowse, 2, 3)

$clbLsp.add_ItemCheck({
    param($s,$e)
    if ($e.NewValue -eq [System.Windows.Forms.CheckState]::Checked) {
        for ($i=0; $i -lt $s.Items.Count; $i++) {
            if ($i -ne $e.Index) { $s.SetItemChecked($i, $false) }
        }
    }
})

$btnLspBrowse.Add_Click({
    try {
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = "Excel|*.xlsx;*.xlsm|Alla filer|*.*"
        $dlg.Title  = "Välj LSP Worksheet"
        if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $f = Get-Item -LiteralPath $dlg.FileName
            Add-CLBItems -clb $clbLsp -files @($f) -AutoCheckFirst
            if (Get-Command Update-StatusBar -ErrorAction SilentlyContinue) { Update-StatusBar }
        }
    } catch {
        Gui-Log ("⚠️ LSP-browse fel: " + $_.Exception.Message) 'Warn'
    }
})

# Lägg in i tabellen
$tlPick.Controls.Add($lblCsv,0,0); $tlPick.Controls.Add($clbCsv,1,0); $tlPick.Controls.Add($btnCsvBrowse,2,0)
$tlPick.Controls.Add($lblNeg,0,1); $tlPick.Controls.Add($clbNeg,1,1); $tlPick.Controls.Add($btnNegBrowse,2,1)
$tlPick.Controls.Add($lblPos,0,2); $tlPick.Controls.Add($clbPos,1,2); $tlPick.Controls.Add($btnPosBrowse,2,2)
$grpPick.Controls.Add($tlPick)

# ── Watermark/placeholder för tomma listor ──

<# Watermarks för tomma listor
Set-ClbWatermark -clb $clbCsv -Text 'Dra CSV-fil hit eller använd Bläddra...'
Set-ClbWatermark -clb $clbNeg -Text 'Dra Seal Test NEG-fil hit...'
Set-ClbWatermark -clb $clbPos -Text 'Dra Seal Test POS-fil hit...'
Set-ClbWatermark -clb $clbLsp -Text 'Dra Worksheet-fil hit...
#>

# ---------- Signering: Sammanställning ----------
$grpSignSamm = New-Object System.Windows.Forms.GroupBox
$grpSignSamm.Text = 'Signering — Sammanställning'
$grpSignSamm.Dock = 'Top'
$grpSignSamm.Padding = New-Object System.Windows.Forms.Padding(10,8,10,10)
$grpSignSamm.AutoSize = $false
$grpSignSamm.Height = 140

$tlSignSamm = New-Object System.Windows.Forms.TableLayoutPanel
$tlSignSamm.Dock = 'Fill'; $tlSignSamm.ColumnCount = 2; $tlSignSamm.RowCount = 4
[void]$tlSignSamm.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$tlSignSamm.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
for ($i = 0; $i -lt 4; $i++) {
    [void]$tlSignSamm.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,26)))
}

$lblSammName = New-Object System.Windows.Forms.Label
$lblSammName.Text = 'Full Name:'; $lblSammName.Anchor = 'Left'; $lblSammName.AutoSize = $true
$txtSammName = New-Object System.Windows.Forms.TextBox
$txtSammName.Dock = 'Fill'; $txtSammName.Margin = New-Object System.Windows.Forms.Padding(6,2,0,2)

$lblSammDate = New-Object System.Windows.Forms.Label
$lblSammDate.Text = 'Date:'; $lblSammDate.Anchor = 'Left'; $lblSammDate.AutoSize = $true
$txtSammDate = New-Object System.Windows.Forms.TextBox
$txtSammDate.Dock = 'Fill'; $txtSammDate.Margin = New-Object System.Windows.Forms.Padding(6,2,0,2)

$lblSealTestSign = New-Object System.Windows.Forms.Label
$lblSealTestSign.Text = 'SIGN:'; $lblSealTestSign.Anchor = 'Left'; $lblSealTestSign.AutoSize = $true
$txtSealTestSign = New-Object System.Windows.Forms.TextBox
$txtSealTestSign.Dock = 'Fill'; $txtSealTestSign.Margin = New-Object System.Windows.Forms.Padding(6,2,0,2)

$chkSealTest = New-Object System.Windows.Forms.CheckBox
$chkSealTest.Text = ' Seal Test (NEG+POS)'; $chkSealTest.AutoSize = $true; $chkSealTest.Margin = New-Object System.Windows.Forms.Padding(0,2,12,2)
$chkWsSamm = New-Object System.Windows.Forms.CheckBox
$chkWsSamm.Text = ' Worksheet (Sammanst.)'; $chkWsSamm.AutoSize = $true; $chkWsSamm.Margin = New-Object System.Windows.Forms.Padding(0,2,12,2)
$chkSignOverwrite = New-Object System.Windows.Forms.CheckBox
$chkSignOverwrite.Text = ' Aktivera Signering'; $chkSignOverwrite.AutoSize = $true; $chkSignOverwrite.Margin = New-Object System.Windows.Forms.Padding(0,2,0,2)
$chkSignOverwrite.ForeColor = [System.Drawing.Color]::FromArgb(180,80,80)
$chkSignOverwrite.Tag = 'Skriv signatur + datum i Seal Test + Worksheet (Sammanställning)'

$flpSammChk = New-Object System.Windows.Forms.FlowLayoutPanel
$flpSammChk.Dock = 'Fill'; $flpSammChk.FlowDirection = 'LeftToRight'; $flpSammChk.WrapContents = $false
$flpSammChk.AutoSize = $true; $flpSammChk.Margin = New-Object System.Windows.Forms.Padding(0)
$flpSammChk.Controls.Add($chkSealTest)
$flpSammChk.Controls.Add($chkWsSamm)
$flpSammChk.Controls.Add($chkSignOverwrite)

$tlSignSamm.Controls.Add($lblSammName,0,0);    $tlSignSamm.Controls.Add($txtSammName,1,0)
$tlSignSamm.Controls.Add($lblSammDate,0,1);    $tlSignSamm.Controls.Add($txtSammDate,1,1)
$tlSignSamm.Controls.Add($lblSealTestSign,0,2);$tlSignSamm.Controls.Add($txtSealTestSign,1,2)
$tlSignSamm.Controls.Add($flpSammChk,0,3);     $tlSignSamm.SetColumnSpan($flpSammChk,2)
$grpSignSamm.Controls.Add($tlSignSamm)
$grpSignSamm.Visible = $false

# ---------- Signering: Granskning ----------
$grpSignGransk = New-Object System.Windows.Forms.GroupBox
$grpSignGransk.Text = 'Signering — Granskning'
$grpSignGransk.Dock = 'Top'
$grpSignGransk.Padding = New-Object System.Windows.Forms.Padding(10,8,10,10)
$grpSignGransk.AutoSize = $false
$grpSignGransk.Height = 110

$tlSignGransk = New-Object System.Windows.Forms.TableLayoutPanel
$tlSignGransk.Dock = 'Fill'; $tlSignGransk.ColumnCount = 2; $tlSignGransk.RowCount = 3
[void]$tlSignGransk.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$tlSignGransk.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
for ($i = 0; $i -lt 3; $i++) {
    [void]$tlSignGransk.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,26)))
}

$lblGranskName = New-Object System.Windows.Forms.Label
$lblGranskName.Text = 'Full Name:'; $lblGranskName.Anchor = 'Left'; $lblGranskName.AutoSize = $true
$txtGranskName = New-Object System.Windows.Forms.TextBox
$txtGranskName.Dock = 'Fill'; $txtGranskName.Margin = New-Object System.Windows.Forms.Padding(6,2,0,2)

$lblGranskDate = New-Object System.Windows.Forms.Label
$lblGranskDate.Text = 'Date:'; $lblGranskDate.Anchor = 'Left'; $lblGranskDate.AutoSize = $true
$txtGranskDate = New-Object System.Windows.Forms.TextBox
$txtGranskDate.Dock = 'Fill'; $txtGranskDate.Margin = New-Object System.Windows.Forms.Padding(6,2,0,2)

$chkWsGransk = New-Object System.Windows.Forms.CheckBox
$chkWsGransk.Text = ' Worksheet (Granskning)'; $chkWsGransk.AutoSize = $true; $chkWsGransk.Margin = New-Object System.Windows.Forms.Padding(0,2,12,2)
$chkGranskOverwrite = New-Object System.Windows.Forms.CheckBox
$chkGranskOverwrite.Text = ' Aktivera överskrivning'; $chkGranskOverwrite.AutoSize = $true; $chkGranskOverwrite.Margin = New-Object System.Windows.Forms.Padding(0,2,0,2)
$chkGranskOverwrite.Tag = 'Skriv signatur + datum i Worksheet (Granskning)'
$chkGranskOverwrite.ForeColor = [System.Drawing.Color]::FromArgb(180,80,80)

$flpGranskChk = New-Object System.Windows.Forms.FlowLayoutPanel
$flpGranskChk.Dock = 'Fill'; $flpGranskChk.FlowDirection = 'LeftToRight'; $flpGranskChk.WrapContents = $false
$flpGranskChk.AutoSize = $true; $flpGranskChk.Margin = New-Object System.Windows.Forms.Padding(0)
$flpGranskChk.Controls.Add($chkWsGransk)
$flpGranskChk.Controls.Add($chkGranskOverwrite)

$tlSignGransk.Controls.Add($lblGranskName,0,0); $tlSignGransk.Controls.Add($txtGranskName,1,0)
$tlSignGransk.Controls.Add($lblGranskDate,0,1); $tlSignGransk.Controls.Add($txtGranskDate,1,1)
$tlSignGransk.Controls.Add($flpGranskChk,0,2);  $tlSignGransk.SetColumnSpan($flpGranskChk,2)
$grpSignGransk.Controls.Add($tlSignGransk)
$grpSignGransk.Visible = $false

$baseHeight = $form.Height

# ---------- Primärknapp ----------

$btnBuild = New-Object System.Windows.Forms.Button
$btnBuild.Text='Skapa rapport (F5)'; $btnBuild.Dock='Top'; $btnBuild.Height=40
$btnBuild.Margin = New-Object System.Windows.Forms.Padding(0,16,0,8)
$btnBuild.Enabled=$false; Set-AccentButton $btnBuild -Primary

# ---------- Statusrad ----------
$status = New-Object System.Windows.Forms.StatusStrip
$status.SizingGrip=$false; $status.Dock='Bottom'; $status.Font=New-Object System.Drawing.Font('Segoe UI',9)
$status.ShowItemToolTips = $true
$slCount = New-Object System.Windows.Forms.ToolStripStatusLabel; $slCount.Text='0 filer valda'; $slCount.Spring=$false
$slWork  = New-Object System.Windows.Forms.ToolStripStatusLabel
$slWork.Text   = ''
$slWork.Spring = $true

$pbWork = New-Object System.Windows.Forms.ToolStripProgressBar
$pbWork.Visible = $false
$pbWork.Style   = 'Marquee'
$pbWork.MarqueeAnimationSpeed = 30
$pbWork.AutoSize = $false
$pbWork.Width    = 140

$slSpacer= New-Object System.Windows.Forms.ToolStripStatusLabel; $slSpacer.Spring=$true

# --- Sessionsstatus (rapporter + tidsbesparning) ---
$script:slSession = New-Object System.Windows.Forms.ToolStripStatusLabel
$script:slSession.Text = ''
$script:slSession.Visible = $false
$script:slSession.ForeColor = [System.Drawing.Color]::FromArgb(0, 100, 0)
$script:slSession.Font = New-Object System.Drawing.Font('Segoe UI', 8.5, [System.Drawing.FontStyle]::Bold)
$script:slSession.BorderSides = 'Left'
$script:slSession.BorderStyle = 'Raised'
$script:slSession.Padding = New-Object System.Windows.Forms.Padding(6, 0, 4, 0)

# --- Klickbar SharePoint-länk ---
$slBatchLink = New-Object System.Windows.Forms.ToolStripStatusLabel
$slBatchLink.IsLink   = $true
$slBatchLink.Text     = 'SharePoint: —'
$slBatchLink.Enabled  = $false
$slBatchLink.Tag      = $null
$slBatchLink.ToolTipText = 'Direktlänk aktiveras när entydigt Order# hittas i Seal Test B10.'
$slBatchLink.add_Click({
    if ($this.Enabled -and $this.Tag) {
        try { Start-Process -FilePath ([string]$this.Tag) } catch {
            [System.Windows.Forms.MessageBox]::Show("Kunde inte öppna:`n$($this.Tag)`n$($_.Exception.Message)","Länk") | Out-Null
        }
    }
})

# --- SharePoint On-Demand Connect-knapp ---
$script:btnSpConnect = New-Object System.Windows.Forms.ToolStripButton
$script:btnSpConnect.DisplayStyle = 'Text'
$script:btnSpConnect.Font = New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold)

if ($global:SpConnected) {
    $script:btnSpConnect.Text = '✅ SP'
    $script:btnSpConnect.ToolTipText = 'SharePoint är anslutet.'
    $script:btnSpConnect.Enabled = $false
} elseif ($global:SpEnabled) {
    $script:btnSpConnect.Text = '🔌 Anslut SP'
    $script:btnSpConnect.ToolTipText = 'Klicka för att ansluta till SharePoint (tar ~10–15 sek).'
    $script:btnSpConnect.Enabled = $true
} else {
    $script:btnSpConnect.Text = '⛔ SP av'
    $script:btnSpConnect.ToolTipText = 'SharePoint är avstängt i konfigurationen.'
    $script:btnSpConnect.Enabled = $false
}

$script:btnSpConnect.add_Click({
    if (-not $global:SpEnabled) { return }
    if ($global:SpConnected) { return }
    if ($global:SpConnecting) { return }

    # Uppdatera knappen
    $this.Text        = '⏳ Ansluter…'
    $this.Enabled     = $false
    $this.ToolTipText = 'Ansluter till SharePoint – vänta…'

    Show-Splash 'Förbereder SharePoint…'

    # Steg 1: Starta SPClient-runspace synkront (snabbt, ~1-2 sek)
    #         PnP import sker här; om det misslyckas avbryt direkt.
    $startOk = Start-SPClient -ProgressCallback { param($m) Update-Splash $m }
    if (-not $startOk) {
        Close-Splash
        $script:btnSpConnect.Text        = '❌ SP – retry?'
        $script:btnSpConnect.ToolTipText = "Misslyckades: $($global:SpError)`nKlicka för att försöka igen."
        $script:btnSpConnect.Enabled     = $true
        Gui-Log ("⚠️ SharePoint-förberedelse misslyckades: " + $global:SpError) 'Warn'
        return
    }

    # Steg 2: Starta Connect-PnPOnline asynkront (kör i SPClient-runspacen)
    Update-Splash 'Loggar in…'
    $asyncOk = Connect-SPClientAsync
    if (-not $asyncOk) {
        Close-Splash
        $script:btnSpConnect.Text        = '❌ SP – retry?'
        $script:btnSpConnect.ToolTipText = "Misslyckades: $($global:SpError)`nKlicka för att försöka igen."
        $script:btnSpConnect.Enabled     = $true
        Gui-Log ("⚠️ Kunde inte starta SP-anslutning: " + $global:SpError) 'Warn'
        return
    }

    # Steg 3: Timer som pollar var 200 ms tills async är klart
    $script:spPollTimer = New-Object System.Windows.Forms.Timer
    $script:spPollTimer.Interval = 200
    $script:spPollTimer.add_Tick({
        $result = Poll-SPClientAsync
        if ($null -eq $result) { return }   # Fortfarande igång

        # Klart — stoppa timer och splash
        $script:spPollTimer.Stop()
        $script:spPollTimer.Dispose()
        $script:spPollTimer = $null
        Close-Splash

        if ($result.Ok) {
            $script:btnSpConnect.Text        = '✅ SP'
            $script:btnSpConnect.ToolTipText = 'SharePoint anslutet.'
            $script:btnSpConnect.Enabled     = $false
            Gui-Log '✅ SharePoint anslutet.' 'Info'
        } else {
            $script:btnSpConnect.Text        = '❌ SP – retry?'
            $script:btnSpConnect.ToolTipText = "Misslyckades: $($global:SpError)`nKlicka för att försöka igen."
            $script:btnSpConnect.Enabled     = $true
            Gui-Log ("⚠️ SharePoint-anslutning misslyckades: " + $global:SpError) 'Warn'
        }
    })
    $script:spPollTimer.Start()
})

$status.Items.AddRange(@($slCount,$slWork,$pbWork,$script:slSession,$script:btnSpConnect,$slBatchLink))
$tsc = New-Object System.Windows.Forms.ToolStripContainer
$tsc.Dock = 'Fill'
$tsc.LeftToolStripPanelVisible  = $false
$tsc.RightToolStripPanelVisible = $false

$form.SuspendLayout()
$form.Controls.Clear()
$form.Controls.Add($tsc)

# Meny högst upp
$tsc.TopToolStripPanel.Controls.Add($menuStrip)
$form.MainMenuStrip = $menuStrip

# Status längst ner
$tsc.BottomToolStripPanel.Controls.Add($status)

# Content i mitten
$content = New-Object System.Windows.Forms.Panel
$content.Dock='Fill'
$content.BackColor = $form.BackColor
$tsc.ContentPanel.Controls.Add($content)

# Dock=Top: nedersta först
$content.SuspendLayout()
$content.Controls.Add($btnBuild)
$content.Controls.Add($grpSignGransk)
$content.Controls.Add($grpSignSamm)
$content.Controls.Add($grpPick)
$content.Controls.Add($grpDl)
$content.Controls.Add($pLog)
$content.Controls.Add($tlSearch)
$content.Controls.Add($panelHeader)
$content.ResumeLayout()
$form.ResumeLayout()
$form.PerformLayout()
$form.AcceptButton = $btnScan

#endregion GUI-bygge

#region Hjälpfunktioner (UI-logik, filval, validering)

$onExclusive = {
    $clb = $this
    if ($_.NewValue -eq [System.Windows.Forms.CheckState]::Checked) {
        for ($i=0; $i -lt $clb.Items.Count; $i++) {
            if ($i -ne $_.Index -and $clb.GetItemChecked($i)) { $clb.SetItemChecked($i, $false) }
        }
    }
    $clb.BeginInvoke([Action]{ Update-BuildEnabled }) | Out-Null
}

# CSV: tillåt max 2 valda (primär + resample)
$onCsvMax2 = {
    $clb = $this
    if ($_.NewValue -eq [System.Windows.Forms.CheckState]::Checked) {
        $checkedCount = 0
        for ($i=0; $i -lt $clb.Items.Count; $i++) {
            if ($i -ne $_.Index -and $clb.GetItemChecked($i)) { $checkedCount++ }
        }
        if ($checkedCount -ge 2) {
            # Redan 2 valda → avmarkera äldsta (första hittade)
            for ($i=0; $i -lt $clb.Items.Count; $i++) {
                if ($i -ne $_.Index -and $clb.GetItemChecked($i)) { $clb.SetItemChecked($i, $false); break }
            }
        }
    }
    $clb.BeginInvoke([Action]{ Update-BuildEnabled }) | Out-Null
}
$clbCsv.add_ItemCheck($onCsvMax2)
$clbNeg.add_ItemCheck($onExclusive)
$clbPos.add_ItemCheck($onExclusive)

$script:LastScanResult = $null
$script:RobalDateShort = $null   # Auto-populated from SP 'ROBAL - Actual start date/time' during build

# Skydd mot återinträde (DoEvents kan annars ge nästlade klick)
$script:ScanInProgress  = $false
$script:BuildInProgress = $false

#endregion Hjälpfunktioner

#region Händelsehanterare (meny, knappar, tema, scan, build)
$miScan.add_Click({ $btnScan.PerformClick() })
$miBuild.add_Click({ if ($btnBuild.Enabled) { $btnBuild.PerformClick() } })
$miExit.add_Click({ $form.Close() })
$miNew.add_Click({ Clear-GUI })

$miOpenRecent.add_Click({
    if ($global:LastReportPath -and (Test-Path -LiteralPath $global:LastReportPath)) {
        try { Start-Process -FilePath $global:LastReportPath } catch {
            [System.Windows.Forms.MessageBox]::Show("Kunde inte öppna rapporten:\n$($_.Exception.Message)","Öppna senaste rapport") | Out-Null
        }
    } else {
        [System.Windows.Forms.MessageBox]::Show("Ingen rapport har genererats i denna session.","Öppna senaste rapport") | Out-Null
    }
})

# Skript1..5 – gemensam startfunktion
$miScript1.add_Click({ Invoke-ExternalScript -Path $Script1Path -Label 'Skript 1' })
$miScript2.add_Click({ Invoke-ExternalScript -Path $Script2Path -Label 'Skript 2' })
$miScript3.add_Click({ Invoke-ExternalScript -Path $Script3Path -Label 'Skript 3' })
$miScript4.add_Click({ Invoke-ExternalScript -Path $Script4Path -Label 'Skript 4' })
$miScript5.add_Click({ Invoke-ExternalScript -Path $Script5Path -Label 'Skript 5' })

$miToggleSignSamm.add_Click({
    $lsp = $txtLSP.Text.Trim()
    if (-not $lsp) {
        Gui-Log "⚠️ Ange och sök ett LSP först innan du aktiverar signering." 'Warn'
        return
    }
    $grpSignSamm.Visible = -not $grpSignSamm.Visible
    if ($grpSignSamm.Visible) {
        $miToggleSignSamm.Text = '❌ Dölj signering (Sammanställning)'
        # Dölj Granskning automatiskt
        if ($grpSignGransk.Visible) {
            $grpSignGransk.Visible = $false
            $chkWsGransk.Checked = $false; $chkGranskOverwrite.Checked = $false
            $miToggleSignGransk.Text = '✅ Aktivera signering (Granskning)'
        }
        # Auto-populate Date från ROBAL om tillgänglig och fältet är tomt
        if (-not $txtSammDate.Text.Trim() -and $script:RobalDateShort) {
            $txtSammDate.Text = $script:RobalDateShort
        }
    } else {
        # Nollställ allt för att förhindra oavsiktlig signering vid nästa build
        $chkSealTest.Checked = $false; $chkWsSamm.Checked = $false; $chkSignOverwrite.Checked = $false
        $miToggleSignSamm.Text = '✅ Aktivera signering (Sammanställning)'
    }
    # Räkna om formulärhöjd
    $extra = 0
    if ($grpSignSamm.Visible)   { $extra += $grpSignSamm.Height + 10 }
    if ($grpSignGransk.Visible) { $extra += $grpSignGransk.Height + 10 }
    $form.Height = $baseHeight + $extra
})

$miToggleSignGransk.add_Click({
    $lsp = $txtLSP.Text.Trim()
    if (-not $lsp) {
        Gui-Log "⚠️ Ange och sök ett LSP först innan du aktiverar signering." 'Warn'
        return
    }
    $grpSignGransk.Visible = -not $grpSignGransk.Visible
    if ($grpSignGransk.Visible) {
        $miToggleSignGransk.Text = '❌ Dölj signering (Granskning)'
        # Dölj Sammanställning automatiskt
        if ($grpSignSamm.Visible) {
            $grpSignSamm.Visible = $false
            $chkSealTest.Checked = $false; $chkWsSamm.Checked = $false; $chkSignOverwrite.Checked = $false
            $miToggleSignSamm.Text = '✅ Aktivera signering (Sammanställning)'
        }
    } else {
        $chkWsGransk.Checked = $false; $chkGranskOverwrite.Checked = $false
        $miToggleSignGransk.Text = '✅ Aktivera signering (Granskning)'
    }
    $extra = 0
    if ($grpSignSamm.Visible)   { $extra += $grpSignSamm.Height + 10 }
    if ($grpSignGransk.Visible) { $extra += $grpSignGransk.Height + 10 }
    $form.Height = $baseHeight + $extra
})

# Enter-tangent i signeringsfält → trigga "Skapa rapport"
$_enterHandler = {
    if ($_.KeyCode -eq 'Return') {
        $_.SuppressKeyPress = $true
        $btnBuild.PerformClick()
    }
}
$txtSammName.add_KeyDown($_enterHandler)
$txtSammDate.add_KeyDown($_enterHandler)
$txtSealTestSign.add_KeyDown($_enterHandler)
$txtGranskName.add_KeyDown($_enterHandler)
$txtGranskDate.add_KeyDown($_enterHandler)


# Instruktioner
$miShowInstr.add_Click({
    $msg = @"
SNABBGUIDE

SAMMANSTÄLLNING

Förberedelse: skapa "Stort Test Summary".

1) Ange LSP och klicka på "Sök filer" eller använd "Bläddra...".
   OBS: LSP-mappen ska ligga i: 3. IPT – KLART FÖR SAMMANSTÄLLNING

2) Klicka på "Skapa rapport".

GRANSKNING

Förberedelse: ladda ned dokument från MES.

1) Klicka på "KLART FÖR GRANSKNING". Filerna flyttas och läses in automatiskt.
   OBS: LSP-mappen ska ligga i: 4. IPT – KLART FÖR GRANSKNING

2) Klicka på "Skapa rapport".

"@
    Show-StyledInfoDialog -Title 'Instruktioner' -HeaderText ([char]0x2139 + '  Instruktioner') -Body $msg -Width 560 -Height 440
})

$miFAQ.Add_Click({
    $faq = @"
VANLIGA FRÅGOR (FAQ)

Vanliga fel och åtgärder
• "Hittar inte LSP" / "Inga filer funna" → Kontrollera att mappen finns i:
    2. IPT - KLART FÖR SAMMANSTÄLLNING
    3. IPT - KLART FÖR GRANSKNING

• Använd "Bläddra..." om du vill ladda filer manuellt.


Vad gör skriptet?
• Skapar en Excel‑rapport för det LSP du söker.

Vilka indata krävs?
• LSP och korrekt placering av mappar.

Vilka flikar finns i Excel‑rapporten?
• Run Information
    - Kort info om batch
    - Jämförelse av excelfilers "header"
    - SharePoint info

• Seal Test‑info
    - Jämförelse av data mellan POS och NEG

• STF Summary
    - Listar alla eventuella STF

• Utrustningslista

• Kontrollmaterial

• QC Summary
    - Summering av fel från alla filer

Var sparas rapporten?
• Endast temporärt i din:
$env:TEMP
Du kan stänga utan att spara efteråt.

Version: $ScriptVersion
"@
    Show-StyledInfoDialog -Title ('Vanliga fr' + [char]0x00E5 + 'gor') -HeaderText ([char]0x2753 + '  Vanliga fr' + [char]0x00E5 + 'gor') -Body $faq -Width 620 -Height 520
})

$miHelpDlg.add_Click({
    $helpForm = New-Object System.Windows.Forms.Form
    $helpForm.Text            = 'Skicka meddelande'
    $helpForm.Size            = New-Object System.Drawing.Size(480, 340)
    $helpForm.StartPosition   = 'CenterParent'
    $helpForm.FormBorderStyle = 'FixedDialog'
    $helpForm.MaximizeBox     = $false
    $helpForm.MinimizeBox     = $false
    $helpForm.Font            = New-Object System.Drawing.Font('Segoe UI', 10)

    $pHead = New-Object System.Windows.Forms.Panel
    $pHead.Dock      = 'Top'
    $pHead.Height    = 52
    $pHead.BackColor = [System.Drawing.Color]::SteelBlue
    $lblH = New-Object System.Windows.Forms.Label
    $lblH.Text      = [char]0x2709 + '  Skicka meddelande'
    $lblH.ForeColor = [System.Drawing.Color]::White
    $lblH.Font      = New-Object System.Drawing.Font('Segoe UI Semibold', 13)
    $lblH.AutoSize  = $false
    $lblH.Dock      = 'Fill'
    $lblH.Padding   = New-Object System.Windows.Forms.Padding(16, 0, 0, 0)
    $lblH.TextAlign = 'MiddleLeft'
    $pHead.Controls.Add($lblH)

    $helpBox = New-Object System.Windows.Forms.TextBox
    $helpBox.Multiline  = $true
    $helpBox.ScrollBars = 'Vertical'
    $helpBox.Dock       = 'Fill'
    $helpBox.Font       = New-Object System.Drawing.Font('Segoe UI', 10)

    $panelButtons = New-Object System.Windows.Forms.FlowLayoutPanel
    $panelButtons.Dock          = 'Bottom'
    $panelButtons.Height        = 52
    $panelButtons.FlowDirection = 'RightToLeft'
    $panelButtons.Padding       = New-Object System.Windows.Forms.Padding(16, 8, 16, 8)
    $panelButtons.WrapContents  = $false

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text   = 'Avbryt'
    $btnCancel.Width  = 100
    $btnCancel.Height = 34
    $btnCancel.Margin = New-Object System.Windows.Forms.Padding(0)

    $btnSend = New-Object System.Windows.Forms.Button
    $btnSend.Text   = 'Skicka'
    $btnSend.Width  = 100
    $btnSend.Height = 34
    $btnSend.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
    try { Set-AccentButton $btnSend -Primary } catch {}

    $panelButtons.Controls.Add($btnCancel)
    $panelButtons.Controls.Add($btnSend)
    $helpForm.Controls.Add($helpBox)
    $helpForm.Controls.Add($panelButtons)
    $helpForm.Controls.Add($pHead)
    $btnSend.Add_Click({
        $msg = $helpBox.Text.Trim()
        if (-not $msg) { [System.Windows.Forms.MessageBox]::Show('Skriv ett meddelande innan du skickar.','Hjälp') | Out-Null; return }
        try {
            $helpDir = (Get-ConfigValue -Name 'HelpFeedbackDir' -Default (Join-Path $PSScriptRoot 'help') -ConfigOverride $null)
            if (-not (Test-Path -LiteralPath $helpDir)) { New-Item -ItemType Directory -Path $helpDir -Force | Out-Null }
            $ts   = (Get-Date).ToString('yyyyMMdd_HHmmss')
            $user = ($env:USERNAME + '').Trim()
            if (-not $user) { $user = 'unknown' }
            $file = Join-Path $helpDir ("help_{0}_{1}.txt" -f $user, $ts)

            $body = @(
                "User: $user"
                "Computer: $($env:COMPUTERNAME)"
                "Time: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
                ''
                $msg
            ) -join "`r`n"
             Set-Content -Path $file -Value $body -Encoding UTF8
             [System.Windows.Forms.MessageBox]::Show('Meddelandet skickades. Tack!','Hjälp') | Out-Null
             $helpForm.Close()
         } catch {
            [System.Windows.Forms.MessageBox]::Show("Kunde inte skicka meddelandet:\n$($_.Exception.Message)",'Hjälp') | Out-Null
        }
    })
    $btnCancel.Add_Click({ $helpForm.Close() })
    $helpForm.ShowDialog() | Out-Null
})

$miStatus.add_Click({
    Show-ProjectStatusDialog
})

# Om
$miOm.add_Click({
    $nl = [Environment]::NewLine
    $omBody = "IPTCompile $ScriptVersion" + $nl + $nl +
              "Rapportgenerator för IPT-dokumentation." + $nl +
              "Detta är endast ett hjälpmedel och" + $nl +
              "ersätter inte någon IPT-process." + $nl + $nl +
              "Av: JESP"
    Show-StyledInfoDialog -Title 'Om IPTCompile' -HeaderText ([char]0x2139 + '  Om IPTCompile') -Body $omBody -Width 460 -Height 300
})

# Flytta nedladdade filer (LSP##### i filnamn)
$script:DevUnlocked = $false
$script:DevUnlockPassword = 'jesper'


$btnMove3.Add_Click({
    if (-not (Assert-DevUnlocked)) { return }
    Move-DownloadedLspFiles -TargetStage '3'
})
$btnMove4.Add_Click({ Move-DownloadedLspFiles -TargetStage '4' })

$btnScan.Add_Click({
    if ($script:_logPlaceholderActive) { $outputBox.Text = ''; $outputBox.ForeColor = [System.Drawing.SystemColors]::WindowText; $script:_logPlaceholderActive = $false }
    if (-not (Assert-StartupReady)) { return }

    $lspInput = ($txtLSP.Text + '').Trim()
    if (-not $lspInput) { Gui-Log "⚠️ Ange ett LSP-nummer" 'Warn'; return }

    # Normalisera: använd endast siffrorna som nyckel (tillåt '#38401', 'LSP 38401' osv.)
    $lsp = ($lspInput -replace '\D', '')
    if (-not $lsp) { Gui-Log "⚠️ Ange ett giltigt LSP-nummer (siffror)" 'Warn'; return }

    if ($script:BuildInProgress) { Gui-Log "⚠️ Rapportgenerering pågår – vänta tills den är klar." 'Warn'; return }
    if ($script:ScanInProgress)  { Gui-Log "⚠️ Sökning pågår redan – vänta." 'Warn'; return }
    $script:ScanInProgress = $true

    Gui-Log -Text ("🔎 Söker filer för {0}…" -f $lsp) -Severity Info -Category USER -Immediate

    try {
        # Återanvänd cache om LSP + mappen fortfarande finns
        if ($script:LastScanResult -and $script:LastScanResult.Lsp -eq $lsp -and
            $script:LastScanResult.Folder -and (Test-Path -LiteralPath $script:LastScanResult.Folder)) {

            Gui-Log -Text ("♻️ Återanvänder senaste sökresultatet för {0}." -f $lsp) -Severity Info -Category USER
            Add-CLBItems -clb $clbCsv -files $script:LastScanResult.Csv -AutoCheckFirst
            Add-CLBItems -clb $clbNeg -files $script:LastScanResult.Neg -AutoCheckFirst
            Add-CLBItems -clb $clbPos -files $script:LastScanResult.Pos -AutoCheckFirst
            Add-CLBItems -clb $clbLsp -files $script:LastScanResult.LspFiles -AutoCheckFirst
            Update-BuildEnabled
            Update-BatchLink
            return
        }

        $folder = Find-LspFolder -Lsp $lsp -Roots $RootPaths
        if (-not $folder) {
            Gui-Log "❌ Ingen LSP-mapp hittad för $lsp" 'Warn'
            if ($env:IPT_ROOT) { Gui-Log "ℹ️ IPT_ROOT=$($env:IPT_ROOT)" 'Info' 'DEBUG' }
            $rootInfo = $RootPaths | ForEach-Object { "{0} ({1})" -f $_, $(if (Test-Path -LiteralPath $_) { "OK" } else { "MISSING" }) }
            Gui-Log -Text ("Sökvägar som provats: " + ($rootInfo -join " | ")) -Severity Info -Category USER
            return
        }

        if (-not (Test-Path -LiteralPath $folder.FullName)) {
            Gui-Log "❌ LSP-mappen hittades men finns inte längre: $($folder.FullName)" 'Warn'
            $rootInfo = $RootPaths | ForEach-Object { "{0} ({1})" -f $_, $(if (Test-Path -LiteralPath $_) { "OK" } else { "MISSING" }) }
            Gui-Log -Text ("Sökvägar som provats: " + ($rootInfo -join " | ")) -Severity Info -Category USER
            return
        }
        Gui-Log -Text ("📂 Mapp: {0}" -f $folder.Name) -Severity Info -Category USER

        # Plocka filer EN gång
        $files = Get-ChildItem -LiteralPath $folder.FullName -File -ErrorAction SilentlyContinue

        $candCsv = @($files | Where-Object { $_.Extension -ieq '.csv' -and ( $_.Name -match [regex]::Escape($lsp) -or $_.Length -gt 100kb ) } | Sort-Object LastWriteTime -Descending)
        $candNeg = @($files | Where-Object { $_.Name -match '(?i)Neg.*\.xls[xm]$' -and $_.Name -match [regex]::Escape($lsp) } | Sort-Object LastWriteTime -Descending)
        $candPos = @($files | Where-Object { $_.Name -match '(?i)Pos.*\.xls[xm]$' -and $_.Name -match [regex]::Escape($lsp) } | Sort-Object LastWriteTime -Descending)
        $candLsp = @($files | Where-Object {
            ($_.Name -match '(?i)worksheet') -and ($_.Name -match [regex]::Escape($lsp)) -and ($_.Extension -match '^(\.xlsx|\.xlsm|\.xls)$')
        } | Sort-Object LastWriteTime -Descending)

        Add-CLBItems -clb $clbCsv -files $candCsv -AutoCheckFirst
        Add-CLBItems -clb $clbNeg -files $candNeg -AutoCheckFirst
        Add-CLBItems -clb $clbPos -files $candPos -AutoCheckFirst
        Add-CLBItems -clb $clbLsp -files $candLsp -AutoCheckFirst

        if ($candCsv.Count -eq 0) { Gui-Log "ℹ️ Ingen CSV hittad (endast .csv visas)." 'Info' }
        if ($candNeg.Count -eq 0) { Gui-Log "⚠️ Ingen Seal NEG hittad." 'Warn' }
        if ($candPos.Count -eq 0) { Gui-Log "⚠️ Ingen Seal POS hittad." 'Warn' }
        if ($candLsp.Count -eq 0) { Gui-Log "ℹ️ Ingen LSP Worksheet hittad." 'Info' }

        Update-BuildEnabled
        Update-BatchLink

        # Cachea FileInfo-objekt
        $script:LastScanResult = [pscustomobject]@{
            Lsp      = $lsp
            Folder   = $folder.FullName
            Csv      = @($candCsv)
            Neg      = @($candNeg)
            Pos      = @($candPos)
            LspFiles = @($candLsp)
        }

        Gui-Log -Text "✅ Filer laddade." -Severity Info -Category USER
    }
    catch {
        Gui-Log ("❌ Filsökning misslyckades: " + $_.Exception.Message) 'Error'
    }
    finally {
        $script:ScanInProgress = $false
    }
})

$btnCsvBrowse.Add_Click({
    $dlg = $null
    try {
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = "CSV|*.csv|Alla filer|*.*"
        $dlg.Multiselect = $true
        if ($dlg.ShowDialog() -eq 'OK') {
            $paths = @($dlg.FileNames)  # kan vara 1 eller flera
            if ($paths.Count -gt 2) {
                Gui-Log "⚠️ Du valde $($paths.Count) CSV-filer. Endast de 2 första används (CSV + ev. Resample)." 'Warn'
                $paths = $paths[0..1]
            }

            $files = New-Object 'System.Collections.Generic.List[System.IO.FileInfo]'
            foreach ($p in $paths) {
                if (-not [string]::IsNullOrWhiteSpace($p)) {
                    [void]$files.Add((Get-Item -LiteralPath $p))
                }
            }

            if ($files.Count -gt 0) {
                Add-CLBItems -clb $clbCsv -files @($files.ToArray()) -AutoCheckFirst
            }
            Update-BuildEnabled
            Update-BatchLink
        }
    } finally { if ($dlg) { try { $dlg.Dispose() } catch {} } }
})

$btnNegBrowse.Add_Click({
    $dlg = $null
    try {
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = "Excel|*.xlsx;*.xlsm|Alla filer|*.*"
        if ($dlg.ShowDialog() -eq 'OK') {
            $f = Get-Item -LiteralPath $dlg.FileName
            Add-CLBItems -clb $clbNeg -files @($f) -AutoCheckFirst
            Update-BuildEnabled
            Update-BatchLink
        }
    } finally { if ($dlg) { try { $dlg.Dispose() } catch {} } }
})

$btnPosBrowse.Add_Click({
    $dlg = $null
    try {
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = "Excel|*.xlsx;*.xlsm|Alla filer|*.*"
        if ($dlg.ShowDialog() -eq 'OK') {
            $f = Get-Item -LiteralPath $dlg.FileName
            Add-CLBItems -clb $clbPos -files @($f) -AutoCheckFirst
            Update-BuildEnabled
            Update-BatchLink
        }
    } finally { if ($dlg) { try { $dlg.Dispose() } catch {} } }
})

# --- Hjälp: Konvertera A1-adress (t.ex. 'E1') till rad/kolumn (EPPlus-säkert) ---
if (-not (Get-Command Convert-A1ToRowCol -ErrorAction SilentlyContinue)) {
    function Convert-A1ToRowCol {
        param(
            [string]$A1,
            [int]$DefaultRow = 1,
            [int]$DefaultCol = 5
        )

        if ([string]::IsNullOrWhiteSpace($A1)) {
            return [pscustomobject]@{ Row = $DefaultRow; Col = $DefaultCol }
        }

        $s = ($A1 + '').Trim().ToUpper()
        # Tillåt valfritt bladprefix som 'Information!E1' (vi använder bara adressdelen)
        if ($s -match '^(?:[^!]+!)?([A-Z]+)(\d+)$') {
            $letters = $matches[1]
            $row = [int]$matches[2]
            $col = 0
            foreach ($ch in $letters.ToCharArray()) {
                $col = ($col * 26) + ([int][char]$ch - [int][char]'A' + 1)
            }
            if ($row -lt 1) { $row = $DefaultRow }
            if ($col -lt 1) { $col = $DefaultCol }
            return [pscustomobject]@{ Row = $row; Col = $col }
        }

        return [pscustomobject]@{ Row = $DefaultRow; Col = $DefaultCol }
    }
}

# --- Hjälp: Skanna Data Summary-blad efter alla konfigurerade statusmönster ---
if (-not (Get-Command Get-DataSummaryFindings -ErrorAction SilentlyContinue)) {
    function Get-DataSummaryFindings {
        param(
            [Parameter(Mandatory=$true)][object[]]$ExcelPackages,
            [Parameter(Mandatory=$false)][string]$AssayName = '',
            [Parameter(Mandatory=$false)][string]$SheetName = 'Data Summary'
        )

        # --- Bygg aktiv regeluppsättning utifrån assay ---
        $rules = New-Object System.Collections.Generic.List[object]
        try {
            if ($global:IPTConstants -and $global:IPTConstants.DataSummaryRules) {
                foreach ($rule in $global:IPTConstants.DataSummaryRules) {
                    $scope = ($rule.Scope + '').Trim()
                    if ($scope -ieq 'All') {
                        [void]$rules.Add($rule); continue
                    }
                    # Assay-specifikt scope: kontrollera matchande lista
                    if ($AssayName) {
                        $scopeKey = $scope + 'Assays'   # t.ex. 'Hpv' → 'HpvAssays'
                        $assayList = @()
                        if ($global:IPTConstants.ContainsKey($scopeKey)) {
                            $assayList = @($global:IPTConstants[$scopeKey])
                        }
                        $matched = $false
                        foreach ($a in $assayList) {
                            if ($AssayName -imatch [regex]::Escape($a)) { $matched = $true; break }
                        }
                        if ($matched) { [void]$rules.Add($rule) }
                    }
                }
            }
        } catch {}

        # Reservväg: om inga regler laddades, använd universella mönster
        if ($rules.Count -eq 0) {
            foreach ($fallbackRule in @(
                @{ Pattern = '*MINOR VISUAL*';      Severity = 'Minor'; Label = 'Minor Functional (Visual)' }
                @{ Pattern = '*MAJOR VISUAL*';      Severity = 'Major'; Label = 'Major Functional (Visual)' }
                @{ Pattern = '*BARCODE FAIL*';      Severity = 'Major'; Label = 'Major Functional (Barcode Scan)' }
                @{ Pattern = '*DELAMINATION*';      Severity = 'Minor'; Label = 'Minor Functional (Delamination)' }
                @{ Pattern = '*MISQUANTITATION*';   Severity = 'Major'; Label = 'Misquantitation' }
                @{ Pattern = '*MAJOR FUNCTIONAL*';  Severity = 'Major'; Label = 'Major Functional' }
                @{ Pattern = '*MINOR FUNCTIONAL*';  Severity = 'Minor'; Label = 'Minor Functional' }
            )) { [void]$rules.Add($fallbackRule) }
        }

        $results = New-Object System.Collections.Generic.List[object]
        $rowMin = 10; $rowMax = 340
        try { $rowMin = Get-Threshold -Key 'DataSummaryRowMin' -Default 10 } catch {}
        try { $rowMax = Get-Threshold -Key 'DataSummaryRowMax' -Default 340 } catch {}

        foreach ($pkg in $ExcelPackages) {
            if (-not $pkg -or -not $pkg.Workbook) { continue }
            $dataSummaryWs = $null
            foreach ($ws in $pkg.Workbook.Worksheets) {
                if ($ws.Name -ieq $SheetName) { $dataSummaryWs = $ws; break }
            }
            if (-not $dataSummaryWs) { continue }

            for ($row = $rowMin; $row -le $rowMax; $row++) {
                try {
                    $status = Get-SafeCellText -Ws $dataSummaryWs -Row $row -Col 3
                    if (-not $status) { continue }

                    # Matcha mot aktiva regler (första träff vinner)
                    $matchedRule = $null
                    foreach ($rule in $rules) {
                        if ($status -ilike $rule.Pattern) { $matchedRule = $rule; break }
                    }
                    if (-not $matchedRule) { continue }

                    $sampleId = Get-SafeCellText -Ws $dataSummaryWs -Row $row -Col 1
                    $comment  = Get-SafeCellText -Ws $dataSummaryWs -Row $row -Col 5
                    if (-not $sampleId) { continue }

                    [void]$results.Add([pscustomobject]@{
                        SampleId = $sampleId
                        Type     = $matchedRule.Label       # t.ex. 'Major Functional (Visual)'
                        Severity = $matchedRule.Severity    # 'Major' eller 'Minor'
                        Comment  = $comment
                        Source   = $SheetName               # 'Data Summary' eller 'Resample Data Summary'
                    })
                } catch {}
            }
        }
        return @($results.ToArray())
    }
}

if (-not (Get-Command Write-SPBlockIntoInformation -ErrorAction SilentlyContinue)) {
    function Write-SPBlockIntoInformation {
        param(
            [Parameter(Mandatory)][OfficeOpenXml.ExcelPackage]$Pkg,
            [Parameter()][object[]]$Rows,
            [Parameter()][string]$Batch,
            [Parameter()][string]$TargetSheetName = 'Run Information',
            [Parameter()][int]$StartRow = 1,
            [Parameter()][int]$StartCol = 5 # E = 5
        )

        if (-not $Pkg) { return $false }
        $Rows = @($Rows)

        $ws = $Pkg.Workbook.Worksheets[$TargetSheetName]
        if (-not $ws) { return $false }

        $labelCol = $StartCol
        $valueCol = $StartCol + 1

        # Harmoniserade färger (matchar CSV Sammanfattning)
        $HeaderBg   = [System.Drawing.Color]::FromArgb(68, 84, 106)    # Mörkblå
        $HeaderFg   = [System.Drawing.Color]::White
        $SectionBg  = [System.Drawing.Color]::FromArgb(217, 225, 242)  # Ljusblå
        $SectionFg  = [System.Drawing.Color]::FromArgb(0, 32, 96)      # Mörkblå text
        $BorderColor = [System.Drawing.Color]::FromArgb(68, 84, 106)

        # Rensa tidigare block (bara i block-ytan, påverkar inte A-D)
        try {
            $clearRows = 120
            $rngClear = $ws.Cells[$StartRow, $labelCol, ($StartRow + $clearRows - 1), $valueCol]
            $rngClear.Clear()
        } catch {}

        # Huvudrubrik
        $ws.Cells[$StartRow, $labelCol].Value = "SharePoint Info"
        $ws.Cells[$StartRow, $valueCol].Value = ""
        $ws.Cells[$StartRow, $labelCol, $StartRow, $valueCol].Merge = $true
        $ws.Cells[$StartRow, $labelCol].Style.Font.Bold = $true
        $ws.Cells[$StartRow, $labelCol].Style.Font.Size = 14
        $ws.Cells[$StartRow, $labelCol].Style.Font.Name = "Calibri"
        $ws.Cells[$StartRow, $labelCol].Style.Font.Color.SetColor($HeaderFg)
        $ws.Cells[$StartRow, $labelCol].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $ws.Cells[$StartRow, $labelCol].Style.Fill.BackgroundColor.SetColor($HeaderBg)
        $ws.Cells[$StartRow, $labelCol].Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Left
        $ws.Cells[$StartRow, $labelCol].Style.VerticalAlignment   = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
        $ws.Row($StartRow).Height = 22

        $r = $StartRow + 1

        if (-not $Rows -or $Rows.Count -eq 0 -or $Rows[0] -eq $null) {
            # Tom data
            $ws.Cells[$r, $labelCol].Value = "Batch"
            $ws.Cells[$r, $valueCol].Value = $Batch
            $r++
            $ws.Cells[$r, $labelCol].Value = "Status"
            $ws.Cells[$r, $valueCol].Value = "SharePoint avstängt för optimering."
            $lastRow = $r
        } else {
            foreach ($row in $Rows) {
                $ws.Cells[$r, $labelCol].Value = $row.Rubrik
                # Normalisera värdet (tar bort NBSP/tabbar/extra whitespace som kan få kolumnen att se "bred" ut)
                $val = $row.'Värde'
                $valN = Normalize-HeaderText (($val + ''))
                $valN = ($valN -replace '\s+', ' ').Trim()
                $ws.Cells[$r, $valueCol].Value = $valN
                $r++
            }
            $lastRow = $r - 1
        }

        # Styling rubrik-kolumn
        try {
            $labelRange = $ws.Cells[($StartRow + 1), $labelCol, $lastRow, $labelCol]
            $labelRange.Style.Font.Bold = $true
            $labelRange.Style.Font.Name = "Calibri"
            $labelRange.Style.Font.Size = 10
            $labelRange.Style.Font.Color.SetColor($SectionFg)
            $labelRange.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $labelRange.Style.Fill.BackgroundColor.SetColor($SectionBg)

            # Styling värde-kolumn
            $valueRange = $ws.Cells[($StartRow + 1), $valueCol, $lastRow, $valueCol]
            $valueRange.Style.Font.Name = "Calibri"
            $valueRange.Style.Font.Size = 10
            $valueRange.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $valueRange.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::White)
            $valueRange.Style.WrapText = $true
            $valueRange.Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Top
            $valueRange.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Left

            # Borders kring block
            $rng = $ws.Cells[$StartRow, $labelCol, $lastRow, $valueCol]
            $rng.Style.Border.Top.Style    = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Left.Style   = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Right.Style  = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Top.Color.SetColor($BorderColor)
            $rng.Style.Border.Bottom.Color.SetColor($BorderColor)
            $rng.Style.Border.Left.Color.SetColor($BorderColor)
            $rng.Style.Border.Right.Color.SetColor($BorderColor)
        } catch {}

# Run Information: template styr kolumnbredder.
# Koden får inte skriva över E/F-bredd.
try { $ws.Column($valueCol).Style.ShrinkToFit = $false } catch {}
        try {
            $script:RunInfoSpBlockStartRow = $StartRow
            $script:RunInfoSpBlockLastRow  = $lastRow
            $script:RunInfoSpBlockStartCol = $StartCol
        } catch {}
        return $true
    }
}
##
if (-not (Get-Command Get-RunInformationColumnWidths -ErrorAction SilentlyContinue)) {
    function Get-RunInformationColumnWidths {
        param(
            [Parameter(Mandatory=$true)]$Ws,
            [int[]]$Columns = @(1,2,3,4,5,6,7,8)
        )
        $map = @{}
        if (-not $Ws) { return $map }
        foreach ($c in $Columns) {
            try {
                $map[[int]$c] = [double]$Ws.Column([int]$c).Width
            } catch {}
        }
        return $map
    }
}

if (-not (Get-Command Restore-RunInformationColumnWidths -ErrorAction SilentlyContinue)) {
    function Restore-RunInformationColumnWidths {
        param(
            [Parameter(Mandatory=$true)]$Ws,
            [Parameter(Mandatory=$true)][hashtable]$Widths
        )
        if (-not $Ws -or -not $Widths) { return }
        foreach ($key in @($Widths.Keys)) {
            try {
                $col = [int]$key
                $Ws.Column($col).Width = [double]$Widths[$key]
                $Ws.Column($col).BestFit = $false
            } catch {}
        }
        try { $Ws.Column(6).Style.ShrinkToFit = $false } catch {}
        try { $Ws.Column(6).Style.WrapText = $false } catch {}
    }
}
###
function Get-UniqueRegexTokens {
    param(
        [object[]]$Values,
        [string]$Regex
    )
    $seen = @{}
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($v0 in @($Values)) {
        $s = ('' + $v0)
        if ([string]::IsNullOrWhiteSpace($s)) { continue }
        foreach ($m in [regex]::Matches($s, $Regex)) {
            $tok = ''
            if ($m.Groups.Count -gt 1) { $tok = $m.Groups[1].Value }
            else { $tok = $m.Value }
            $tok = ($tok + '').Trim()
            if (-not $tok) { continue }
            if (-not $seen.ContainsKey($tok)) {
                $seen[$tok] = $true
                [void]$out.Add($tok)
            }
        }
    }
    return @($out.ToArray())
}
function Get-BatchTokenList {
    param([object[]]$Values)
    return @(Get-UniqueRegexTokens -Values $Values -Regex '(?<!\d)(\d{10})(?!\d)')
}
function Get-LspTokenList {
    param([object[]]$Values)
    return @(Get-UniqueRegexTokens -Values $Values -Regex '(?<![A-Za-z0-9])(\d{5})(?!\d)')
}

function Join-TokenList {
    param([object[]]$Tokens)
    $t = @($Tokens | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    if ($t.Count -eq 0) { return '—' }
    return ($t -join ', ')
}

function Get-SpRowValue {
    param(
        [object[]]$Rows,
        [string]$Label
    )
    foreach ($r in @($Rows)) {
        if (-not $r) { continue }
        if ((($r.Rubrik + '').Trim()) -eq $Label) {
            return (($r.'Värde' + '').Trim())
        }
    }
    return ''
}
function Compare-TokenSetExact {
    param(
        [object[]]$Expected,
        [object[]]$Actual
    )
    $exp = @($Expected | Where-Object { $_ } | Sort-Object -Unique)
    $act = @($Actual   | Where-Object { $_ } | Sort-Object -Unique)
    if ($exp.Count -eq 0 -and $act.Count -eq 0) {
        return [pscustomobject]@{
            Status  = 'NoData'
            Missing = @()
            Extra   = @()
        }
    }
    if ($exp.Count -eq 0) {
        return [pscustomobject]@{
            Status  = 'NoRef'
            Missing = @()
            Extra   = $act
        }
    }
    if ($act.Count -eq 0) {
        return [pscustomobject]@{
            Status  = 'MissingActual'
            Missing = $exp
            Extra   = @()
        }
    }
    $missing = @($exp | Where-Object { $act -notcontains $_ })
    $extra   = @($act | Where-Object { $exp -notcontains $_ })
    if ($missing.Count -eq 0 -and $extra.Count -eq 0) {
        return [pscustomobject]@{
            Status  = 'Match'
            Missing = @()
            Extra   = @()
        }
    }
    return [pscustomobject]@{
        Status  = 'Mismatch'
        Missing = $missing
        Extra   = $extra
    }
}
function Test-SharePointBatchLspConsistency {
    param(
        [object[]]$Rows,
        [object]$HeaderWs,
        [object[]]$WorksheetHeaderRows,
        [string]$SealPosPath,
        [string]$SealNegPath,
        [string]$SearchedLsp,
        [object]$BatchInfo
    )
    if (-not $Rows -or @($Rows).Count -eq 0) {
        return [pscustomobject]@{
            Status  = 'NoRef'
            Message = ''
        }
    }
    $spOrderRaw = Get-SpRowValue -Rows $Rows -Label 'Order#'
    $spBatch1   = Get-SpRowValue -Rows $Rows -Label 'SAP Batch#'
    $spBatch2   = Get-SpRowValue -Rows $Rows -Label 'SAP Batch# 2'
    $spLspRaw   = Get-SpRowValue -Rows $Rows -Label 'LSP'
    $expectedOrder = ''
    try { if ($BatchInfo -and $BatchInfo.Order) { $expectedOrder = Normalize-OrderNumber $BatchInfo.Order } } catch {}
    $spOrder = Normalize-OrderNumber $spOrderRaw
    $spBatchTokens = @(Get-BatchTokenList -Values @($spBatch1, $spBatch2))
    $spLspTokens   = @(Get-LspTokenList   -Values @($spLspRaw))
    $wsBatchVals = @()
    $wsLspVals   = @()
    try {
        if ($HeaderWs) {
            $wsBatchVals += $HeaderWs.BatchNo
            $wsLspVals   += $HeaderWs.CartridgeNo
        }
    } catch {}
    try {
        foreach ($r in @($WorksheetHeaderRows)) {
            if (-not $r) { continue }
            $wsBatchVals += $r.BatchNo
            $wsLspVals   += $r.CartridgeNo
        }
    } catch {}
    $sealPosBatch = ''
    $sealNegBatch = ''
    try { if ($SealPosPath) { $sealPosBatch = Get-BatchNumberFromSealFile $SealPosPath } } catch {}
    try { if ($SealNegPath) { $sealNegBatch = Get-BatchNumberFromSealFile $SealNegPath } } catch {}
    $batchInfoBatch = ''
    try { if ($BatchInfo -and $BatchInfo.Batch) { $batchInfoBatch = $BatchInfo.Batch } } catch {}
    $fileBatchTokens = @(Get-BatchTokenList -Values @($wsBatchVals + $sealPosBatch + $sealNegBatch + $batchInfoBatch))
    $fileLspTokens   = @(Get-LspTokenList   -Values @($wsLspVals + $SearchedLsp))
    $batchCmp = Compare-TokenSetExact -Expected $spBatchTokens -Actual $fileBatchTokens
    $lspCmp   = Compare-TokenSetExact -Expected $spLspTokens   -Actual $fileLspTokens
    $parts = New-Object System.Collections.Generic.List[string]
    $status = 'Match'
    $orderMessage = ''
    $batchMessage = ''
    $lspMessage = ''
    if ($expectedOrder -and $spOrder -and $expectedOrder -eq $spOrder) {
        $orderMessage = ("✓ SP=[{0}] Seal=[{1}]" -f $spOrder, $expectedOrder)
        [void]$parts.Add(("Order# {0}" -f $orderMessage))
    }
    else {
        $status = 'Mismatch'
        $orderMessage = ("⚠ SP=[{0}] Seal=[{1}]" -f $(if($spOrder){$spOrder}else{'—'}), $(if($expectedOrder){$expectedOrder}else{'—'}))
        [void]$parts.Add(("Order# {0}" -f $orderMessage))
    }
    if ($batchCmp.Status -eq 'Match') {
        $batchMessage = ("✓ SP=[{0}] Filer=[{1}]" -f (Join-TokenList $spBatchTokens), (Join-TokenList $fileBatchTokens))
        [void]$parts.Add(("Batch {0}" -f $batchMessage))
    }
    else {
        $status = 'Mismatch'
        $batchMessage = ("⚠ SP=[{0}] Filer=[{1}]" -f (Join-TokenList $spBatchTokens), (Join-TokenList $fileBatchTokens))
        [void]$parts.Add(("Batch {0}" -f $batchMessage))
    }
    if ($lspCmp.Status -eq 'Match') {
        $lspMessage = ("✓ SP=[{0}] Filer/Sökning=[{1}]" -f (Join-TokenList $spLspTokens), (Join-TokenList $fileLspTokens))
        [void]$parts.Add(("LSP {0}" -f $lspMessage))
    }
    else {
        $status = 'Mismatch'
        $lspMessage = ("⚠ SP=[{0}] Filer/Sökning=[{1}]" -f (Join-TokenList $spLspTokens), (Join-TokenList $fileLspTokens))
        [void]$parts.Add(("LSP {0}" -f $lspMessage))
    }
    $prefix = if ($status -eq 'Match') { '✓ Match' } else { '⚠ Mismatch' }
    return [pscustomobject]@{
        Status       = $status
        Message      = ($prefix + ' — ' + (@($parts.ToArray()) -join ' / '))
        SummaryText  = $prefix
        OrderStatus  = if ($orderMessage -like '⚠*') { 'Mismatch' } else { 'Match' }
        OrderMessage = $orderMessage
        BatchStatus  = if ($batchMessage -like '⚠*') { 'Mismatch' } else { 'Match' }
        BatchMessage = $batchMessage
        LspStatus    = if ($lspMessage -like '⚠*') { 'Mismatch' } else { 'Match' }
        LspMessage   = $lspMessage
    }
}

# ============================
# ===== RAPPORTLOGIK =========
# ============================

$btnBuild.Add_Click({
    if ($script:_logPlaceholderActive) { $outputBox.Text = ''; $outputBox.ForeColor = [System.Drawing.SystemColors]::WindowText; $script:_logPlaceholderActive = $false }
    #region Build: Rapportgenerering (huvudloop)
    if (-not (Assert-StartupReady)) { return }

    # Hjälpfunktion: ta bort TEMP-prefix (CSV_Primary__, SealNEG__, etc.) från filnamn för ren visning
    function Get-CleanLeaf([string]$Path) {
        if (-not $Path) { return '' }
        $leaf = Split-Path $Path -Leaf
        $leaf -replace '^(CSV_Primary|CSV_Resample|SealNEG|SealPOS|Worksheet)__', ''
    }

    if ($script:ScanInProgress) { Gui-Log "⚠️ Sökning pågår – vänta innan du skapar rapport." 'Warn'; return }
    if ($script:BuildInProgress) { Gui-Log "⚠️ Rapportgenerering kör redan – vänta." 'Warn'; return }
    $script:BuildInProgress = $true

 # --- Tidsmätning (metrics) ---
 $buildTimer = [System.Diagnostics.Stopwatch]::StartNew()
 $phaseTimings = [ordered]@{}
 $lastPhaseMs = 0
 function Mark-Phase([string]$Name) {
 $now = $buildTimer.ElapsedMilliseconds
 $phaseTimings[$Name] = ($now - $lastPhaseMs)
 Set-Variable -Name lastPhaseMs -Value $now -Scope 1
 }

    Gui-Log -Text '🔃 Skapar rapport…' -Severity Info -Category USER -Immediate
    Set-UiBusy -Busy $true -Message 'Skapar rapport…'
    Set-UiStep 5 'Initierar…'

    # --- Levande elapsed-timer i statusfältet (uppdateras varje sekund) ---
    $script:buildElapsedTimer = New-Object System.Windows.Forms.Timer
    $script:buildElapsedTimer.Interval = 1000
    $script:buildElapsedTimer.add_Tick({
        try {
            $elapsed = $buildTimer.Elapsed
            $slWork.Text = ('Bygger… {0:mm\:ss}' -f $elapsed)
            $status.Refresh()
        } catch {}
    })
    $script:buildElapsedTimer.Start()

    $pkgNeg = $null
    $pkgPos = $null
    $pkgOut = $null
    $stageDir = $null

    # Original paths (används för transparens + ev. signering)
    $selNegOrig = $null
    $selPosOrig = $null
    $selCsvOrig = $null
    $selCsvResOrig = $null
    $selLspOrig = $null

    # Regelmotor-cache (per körning)
    $script:RuleEngineShadow     = $null
    $script:RuleEngineShadowRes  = $null
    $script:RuleEngineCsvObjs    = $null
    $script:RuleEngineCsvObjsRes = $null
    $script:RuleBankCache        = $null

    # Guard rails för audit/finally (även vid tidiga return)
    $selCsv = $null
    $selCsvRes = $null
    $hasResampleCsv = $false
    $runAssay = $null
    $batch = $null
    $csvStats = $null
    $csvStatsRes = $null
    $sigMismatch = $false
    $mismatchSheets = @()
    $violationsNeg = @()
    $violationsPos = @()
    $granskName = ''
    $granskDate = ''
    $lsp = ''
    $SavePath = $null
    $totalMs = 0
    $phaseJson = ''
    $auditStatusText = 'Aborted'
    $auditWritten = $false

    try {
        if (-not (Load-EPPlus)) { Gui-Log "❌ EPPlus kunde inte laddas – avbryter." 'Error'; return }

        Set-UiStep 10 '🔃 Läser in Seal Test-filer…'
        Mark-Phase 'Init'

        $allCsvPaths = @(Get-AllCheckedFilePaths $clbCsv)
        $csvSel = Resolve-CsvPrimaryAndResample -CsvPaths $allCsvPaths
        if (-not $csvSel.Ok) {
            Gui-Log $csvSel.ErrorMessage 'Error'
            return
        }
        if ($csvSel.WarningMessage) {
            Gui-Log $csvSel.WarningMessage 'Warn'
        }
        $selCsv = $csvSel.PrimaryCsv
        $selCsvRes = $csvSel.ResampleCsv
        $hasResampleCsv = [bool]$csvSel.HasResample

        $selNeg = Get-CheckedFilePath $clbNeg
        $selPos = Get-CheckedFilePath $clbPos

        if (-not $selNeg -or -not $selPos) { Gui-Log "❌ Du måste välja en Seal NEG och en Seal POS." 'Error'; return }

        $lspRaw    = ($txtLSP.Text + '').Trim()
        $lspDigits = ($lspRaw -replace '\D','')
        $hasLsp    = -not [string]::IsNullOrWhiteSpace($lspDigits)

        if ($hasLsp) {
            $lsp = $lspDigits
        } else {
            $lsp = 'Manuell'
            Gui-Log "ℹ️ Filval via Bläddra." 'Warn'
        }

        $lspForLinks = if ($hasLsp) { $lsp } else { '' }

        # ---- TEMP snapshot av valda filer (för att inte stanna om någon har filen öppen) ----
        $enableStaging = Get-ConfigFlag -Name 'EnableLocalStaging' -Default $true -ConfigOverride $Config
        if ($enableStaging) {
            try {

                # Standard: C:\IPTCompile_TEMP\... (kan styras via Config: TempSnapshotRoot)
                $root = Get-ConfigValue -Name 'TempSnapshotRoot' -Default 'C:\IPTCompile_TEMP' -ConfigOverride $Config
                if (-not $root) { $root = 'C:\IPTCompile_TEMP' }
                if (-not (Test-Path -LiteralPath $root)) { New-Item -ItemType Directory -Path $root -Force | Out-Null }
                $stageDir = Join-Path $root ("IPTCompile_" + $lsp + "_" + (Get-Date -Format 'yyyyMMdd_HHmmss') + "_" + ([guid]::NewGuid().ToString('N')))
                New-Item -ItemType Directory -Path $stageDir -Force | Out-Null
                # Spara original paths
                $selNegOrig = $selNeg
                $selPosOrig = $selPos
                if ($selCsv) { $selCsvOrig = $selCsv }
                if ($selCsvRes) { $selCsvResOrig = $selCsvRes }

                # Snapshot paths används för all läsning/rapportbygge
                $selNeg = Stage-InputFileSnapshot -Path $selNeg -StageDir $stageDir -Prefix 'SealNEG'
                $selPos = Stage-InputFileSnapshot -Path $selPos -StageDir $stageDir -Prefix 'SealPOS'
                if ($selCsv) { $selCsv = Stage-InputFileSnapshot -Path $selCsv -StageDir $stageDir -Prefix 'CSV_Primary' }
                if ($selCsvRes) { $selCsvRes = Stage-InputFileSnapshot -Path $selCsvRes -StageDir $stageDir -Prefix 'CSV_Resample' }

            } catch {
                Gui-Log ("⚠️ Kunde inte skapa arbetskopia: " + $_.Exception.Message) 'Warn'
            }
        }

        # Logg: visa originalfilnamn (utan TEMP-prefix)
        $negLeaf = Get-CleanLeaf $selNeg
        $posLeaf = Get-CleanLeaf $selPos
        Gui-Log "📄 Neg: $negLeaf" 'Info'
        Gui-Log "📄 Pos: $posLeaf" 'Info'
        if ($selCsv) {
            $csvLeaf = Get-CleanLeaf $selCsv
            Gui-Log "📄 CSV: $csvLeaf" 'Info'
        } else { Gui-Log "ℹ️ Ingen CSV vald." 'Info' }
        if ($selCsvRes) {
            $csvResLeaf = Get-CleanLeaf $selCsvRes
            Gui-Log "📄 CSV (Resample): $csvResLeaf" 'Info'
        }

        # =====================================================
        # === CSV-RADCACHE (läs varje fil max en gång)      ===
        # =====================================================
        Mark-Phase 'SealTestLoad'
        $script:CsvLinesPrimary  = $null
        $script:CsvLinesResample = $null
        if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
            try { $script:CsvLinesPrimary = Get-Content -LiteralPath $selCsv } catch { Gui-Log ("⚠️ Kunde inte läsa CSV: " + $_.Exception.Message) 'Warn' }
        }
        if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
            try { $script:CsvLinesResample = Get-Content -LiteralPath $selCsvRes } catch { Gui-Log ("⚠️ Kunde inte läsa Resample CSV: " + $_.Exception.Message) 'Warn' }
        }

        $negWritable = $true; $posWritable = $true
        if ($chkSealTest.Checked) {
            # GDP A5: Fil-lås med Retry-dialog för originalfiler (signering)
            $negLockPath = if ($selNegOrig) { $selNegOrig } else { $selNeg }
            $posLockPath = if ($selPosOrig) { $selPosOrig } else { $selPos }
            $signPaths = @($negLockPath, $posLockPath) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
            if ($signPaths.Count -gt 0) {
                if (-not (Ensure-FilesClosedOrCancel -Paths $signPaths -Hint 'Stäng Seal Test-filen i Excel och klicka Försök igen. Signering kan inte genomföras mot en låst fil.')) {
                    Gui-Log "🛑 Seal Test-signatur avbruten: fil(er) låsta." 'Error'
                    return
                }
            }
        }

        # UX: Om någon vald fil är öppen/låst – be användaren stänga den och Försök igen.
        $pathsToCheck = @($selNeg, $selPos)
        if (-not (Ensure-FilesClosedOrCancel -Paths $pathsToCheck)) {
            Gui-Log "🛑 Avbrutet: en eller flera filer var öppna/låsta." 'Warn'
            return
        }

        # ----------------------------
        # Öppna paket
        # ----------------------------
        try {
            $pkgNeg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selNeg))
            $pkgPos = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selPos))
        } catch {
            Gui-Log "❌ Kunde inte öppna NEG/POS: $($_.Exception.Message)" 'Error'
            return
        }

        $templatePath = Join-Path $PSScriptRoot "output_template-v4.xlsx"
        if (-not (Test-Path -LiteralPath $templatePath)) { Gui-Log "❌ Mallfilen 'output_template-v4.xlsx' saknas!" 'Error'; return }
        # UX: Mallfilen kan vara låst om någon har den öppen (t.ex. förhandsvisning/Excel).
        if (-not (Ensure-FilesClosedOrCancel -Paths @($templatePath))) {
            Gui-Log "🛑 Avbrutet: mallfilen är öppen/låst." 'Warn'
            return
        }
try {
    $pkgOut = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($templatePath))
} catch {
    Gui-Log "❌ Kunde inte läsa mall: $($_.Exception.Message)" 'Error'
    return
}

$script:RunInfoTemplateColumnWidths = @{}
try {
    $wsTemplateRunInfo = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if ($wsTemplateRunInfo) {
        $script:RunInfoTemplateColumnWidths = Get-RunInformationColumnWidths -Ws $wsTemplateRunInfo
    }
} catch {}

        # ============================
        # === SIGNATUR I NEG/POS  ====
        # ============================

        $doSealTest = $chkSealTest.Checked
        $doWsSamm   = $chkWsSamm.Checked
        $doWsGransk = $chkWsGransk.Checked
        $doOverwrite      = $chkSignOverwrite.Checked
        $doOverwriteGransk = $chkGranskOverwrite.Checked
        if (($doSealTest -or $doWsSamm) -and (-not $doOverwrite)) {
            Gui-Log "❌ Overwrite måste kryssas i för att skapa rapport med signering (Sammanställning)." 'Error'
            return
        }
        if ($doWsGransk -and (-not $doOverwriteGransk)) {
            Gui-Log "❌ Overwrite måste kryssas i för att skapa rapport med signering (Granskning)." 'Error'
            return
        }

        # --- Sammanställnings-fält (delat av Seal Test + Worksheet Sammanställning) ---
        $sammName = ($txtSammName.Text + '').Trim()
        $sammDate = ($txtSammDate.Text + '').Trim()
        $sammSign = ($txtSealTestSign.Text + '').Trim()

        if ($doSealTest) {
            if (-not $sammName) { Gui-Log "❌ Sammanställning: Full Name saknas." 'Error'; return }
            if (-not $sammSign) { Gui-Log "❌ Sammanställning: SIGN saknas." 'Error'; return }
            if (-not $sammDate) { Gui-Log "❌ Sammanställning: Date saknas." 'Error'; return }
        }
        if ($doWsSamm) {
            if (-not $sammName) { Gui-Log "❌ Sammanställning: Full Name saknas." 'Error'; return }
            if (-not $sammDate) { Gui-Log "❌ Sammanställning: Date saknas." 'Error'; return }
        }
        if ($doWsGransk) {
            $granskName = ($txtGranskName.Text + '').Trim()
            $granskDate = ($txtGranskDate.Text + '').Trim()
            if (-not $granskName) { Gui-Log "❌ Granskning: Full Name saknas." 'Error'; return }
            if (-not $granskDate) { Gui-Log "❌ Granskning: Date saknas." 'Error'; return }
        }

# Seal Test B47 = "Full name, SIGN, Date"
$signToWrite = ''
# Sätts till true endast när denna körning faktiskt har skrivit över
# Seal Test-signaturer och read-back verifieringen har passerat.
# Då ska gamla saknade B47-värden i redan inlästa paket inte flaggas i rapporten.
$sealSignatureOverwriteAppliedThisRun = $false
if ($doSealTest) {
            $signToWrite = "$sammName, $sammSign, $sammDate"
            if (-not (Confirm-SignatureInput -Text $signToWrite)) { Gui-Log "🛑 Seal Test-signatur ej bekräftad. Avbryter."; return }

            # Signera ORIGINAL om möjligt (snapshot används endast för läsning)
            $negPathForSign = if ($selNegOrig) { $selNegOrig } else { $selNeg }
            $posPathForSign = if ($selPosOrig) { $selPosOrig } else { $selPos }
            $pkgNegSign = $null
            $pkgPosSign = $null
            try {
                if ($negWritable) { $pkgNegSign = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($negPathForSign)) }
                if ($posWritable) { $pkgPosSign = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($posPathForSign)) }
            } catch {
                Gui-Log ("⚠️ Kunde inte öppna filen för signering: " + $_.Exception.Message) 'Warn'
            }
            }
            $negWritten = 0; $posWritten = 0; $negSkipped = 0; $posSkipped = 0

            # Hjälpfunktion: skriver signatur i alla aktiva datablad
            function _SignSealTestSheets([object]$pkg, [string]$sigText, [string]$sigCell, [bool]$overwrite) {
                $written = 0; $skipped = 0
                if (-not $pkg) { return @{ Written = 0; Skipped = 0 } }
                foreach ($ws in $pkg.Workbook.Worksheets) {
                    if ($ws.Name -eq 'Worksheet Instructions') { continue }
                    $h3 = Get-CellText $ws $Layout.SealActiveCheckCell
                    if ($h3 -match '^[0-9]') {
                        $existing = Get-CellText $ws $sigCell
                        if ($existing -and -not $overwrite) { $skipped++; continue }
                        $ws.Cells[$sigCell].Style.Numberformat.Format = '@'
                        $ws.Cells[$sigCell].Value = $sigText
                        $written++
                    }
                    elseif ([string]::IsNullOrWhiteSpace($h3) -or $h3 -match '^(?i)(N\/\?A|NA|Tomt( innehåll)?)$') {
                        break
                    }
                }
                return @{ Written = $written; Skipped = $skipped }
            }

            $resNeg = _SignSealTestSheets $pkgNegSign $signToWrite $Layout.SignatureCell $doOverwrite
            $resPos = _SignSealTestSheets $pkgPosSign $signToWrite $Layout.SignatureCell $doOverwrite
            $negWritten = $resNeg.Written; $negSkipped = $resNeg.Skipped
            $posWritten = $resPos.Written; $posSkipped = $resPos.Skipped

            # GDP A1: Ingen silent fail — Save-fel stoppar hela flödet
            if ($negWritten -eq 0 -and $negSkipped -eq 0 -and $posWritten -eq 0 -and $posSkipped -eq 0) {
                Gui-Log "ℹ️ Inga databladsflikar efter flik 1 att sätta signatur i (ingen åtgärd)."
            } else {
                try {
                    if ($negWritten -gt 0 -and $pkgNegSign) { $pkgNegSign.Save() }
                    if ($posWritten -gt 0 -and $pkgPosSign) { $pkgPosSign.Save() }
                } catch {
                    Gui-Log "❌ SIGNERINGSFEL: Kunde inte spara Seal Test: $($_.Exception.Message)" 'Error'
                    try { Save-ForensicSnapshot -SourcePath $(if($negPathForSign){$negPathForSign}else{$posPathForSign}) -Reason "Save() misslyckades: $($_.Exception.Message)" -AuditDir (Join-Path $PSScriptRoot 'audit') -Details @{ SignText=$signToWrite; NEG_Written=$negWritten; POS_Written=$posWritten } } catch {}
                    try { if ($pkgNegSign) { $pkgNegSign.Dispose() } } catch {}
                    try { if ($pkgPosSign) { $pkgPosSign.Dispose() } } catch {}
                    return
                }
                Gui-Log "🖊️ Signatur satt: NEG $negWritten blad (överhoppade $negSkipped), POS $posWritten blad (överhoppade $posSkipped)."
            }
            try { if ($pkgNegSign) { $pkgNegSign.Dispose() } } catch {}
            try { if ($pkgPosSign) { $pkgPosSign.Dispose() } } catch {}

            # GDP A2: Write → Save → Read-back verifiering
            $sealVerifyFailed = $false
            foreach ($vEntry in @(
                @{ Label='NEG'; Path=$negPathForSign; Written=$negWritten },
                @{ Label='POS'; Path=$posPathForSign; Written=$posWritten }
            )) {
                if ($vEntry.Written -gt 0 -and $vEntry.Path -and (Test-Path -LiteralPath $vEntry.Path)) {
                    $vr = Verify-SealTestSignatures -Path $vEntry.Path -ExpectedText $signToWrite -SignatureCell $Layout.SignatureCell -ActiveCheckCell $Layout.SealActiveCheckCell -ExpectedWritten $vEntry.Written
                    if ($vr.OK) {
                        Gui-Log "✅ Seal Test $($vEntry.Label) verifierad: $($vr.SheetsVerified)/$($vr.SheetsChecked) blad OK." 'Info'
                    } else {
                        $sealVerifyFailed = $true
                        $reason = if ($vr.Error) { $vr.Error } else { ($vr.Mismatches -join '; ') }
                        Gui-Log "❌ VERIFIERINGSFEL Seal Test $($vEntry.Label): $reason" 'Error'
                        # GDP A4: Forensisk snapshot
                        try { Save-ForensicSnapshot -SourcePath $vEntry.Path -Reason "Read-back mismatch: $reason" -AuditDir (Join-Path $PSScriptRoot 'audit') -Details @{ SignText=$signToWrite; Expected=$vEntry.Written; Verified=$vr.SheetsVerified; Mismatches=($vr.Mismatches -join '|') } } catch {}
                    }
                }
            }
if ($sealVerifyFailed) {
    Gui-Log "🛑 Seal Test-signatur ej verifierad. Rapport stoppas." 'Error'
    return

}
# Om overwrite-signering lyckades och minst ett aktivt blad skrevs,
# ska rapportens senare signaturkontroll inte varna för gamla tomma B47-värden
# från paket som kan ha lästs in före signeringen.
if ($doOverwrite -and $signToWrite -and (($negWritten + $posWritten) -gt 0)) {
    $sealSignatureOverwriteAppliedThisRun = $true
}

        # ==========================================
        # === SIGNATUR I WORKSHEET              ====
        # ==========================================

        if ($doWsSamm -or $doWsGransk) {
            $wsSignPath = $null
            try { $wsSignPath = Get-CheckedFilePath $clbLsp } catch {}
            if (-not $wsSignPath -or -not (Test-Path -LiteralPath $wsSignPath)) {
                Gui-Log "⚠️ Ingen Worksheet vald – hoppar över Worksheet-signatur." 'Warn'
            } else {
                # Bekräftelse
                $hasResample = [bool]$hasResampleCsv
                $wsTargets = New-Object System.Collections.Generic.List[string]
                if ($doWsSamm) {
                    try {
                        $planS = Get-WorksheetSignaturePlan_OpenXml -Path $wsSignPath -Mode 'Sammanstallning' -HasResample $hasResample -ModulesRoot $modulesRoot
                        if ($planS -and $planS.Planned) {
                            foreach ($p in $planS.Planned) { [void]$wsTargets.Add("Sammanställning: $p") }
                        }
                    } catch {
                        Gui-Log ("⚠️ Kunde inte läsa signeringsplan (Sammanställning): " + $_.Exception.Message) 'Warn'
                    }
                }
                if ($doWsGransk) {
                    try {
                        $planG = Get-WorksheetSignaturePlan_OpenXml -Path $wsSignPath -Mode 'Granskning' -HasResample $hasResample -ModulesRoot $modulesRoot
                        if ($planG -and $planG.Planned) {
                            foreach ($p in $planG.Planned) { [void]$wsTargets.Add("Granskning: $p") }
                        }
                    } catch {
                        Gui-Log ("⚠️ Kunde inte läsa signeringsplan (Granskning): " + $_.Exception.Message) 'Warn'
                    }
                }
                $wsConfirmed = Confirm-WorksheetSignInput -FullName $(if ($doWsSamm) { $sammName } else { $granskName }) -SignDate $(if ($doWsSamm) { $sammDate } else { $granskDate }) -Targets @($wsTargets.ToArray())
                if (-not $wsConfirmed) {
                    Gui-Log "🛑 Worksheet-signatur ej bekräftad." 'Info'
                } elseif (-not (Ensure-FilesClosedOrCancel -Paths @($wsSignPath) -Hint 'Stäng Worksheet-filen i Excel och klicka Försök igen. Signering kan inte genomföras mot en låst fil.')) {
                    # GDP A5: Fil-lås med Retry-dialog
                    Gui-Log "🛑 Worksheet-signatur avbruten: filen är låst." 'Error'
                    return
                } else {
                    $wsAllWrittenCells = New-Object System.Collections.Generic.List[pscustomobject]
                    try {
                        $hasResample = [bool]$hasResampleCsv

                        # Konsoliderad loop: kör varje signerings-mode
                        $wsModes = @()
                        if ($doWsSamm)   { $wsModes += @{ Mode='Sammanstallning'; Label='Sammanställning'; Name=$sammName; Date=$sammDate; Overwrite=$doOverwrite } }
                        if ($doWsGransk) { $wsModes += @{ Mode='Granskning';      Label='Granskning';      Name=$granskName; Date=$granskDate; Overwrite=$doOverwriteGransk } }

                        foreach ($m in $wsModes) {
                            $wsRes = Invoke-WorksheetSignature_OpenXml -Path $wsSignPath -FullName $m.Name -SignDateYmd $m.Date -Mode $m.Mode -HasResample:$hasResample -Overwrite ([bool]$m.Overwrite) -ModulesRoot $modulesRoot
                            if ($wsRes.Written.Count -gt 0) {
                                Gui-Log ("🖊️ WS $($m.Label): " + ($wsRes.Written -join ', ')) 'Info'
                            }
                            if ($wsRes.Skipped.Count -gt 0) {
                                Gui-Log ("WS $($m.Label) – överhoppade: " + ($wsRes.Skipped -join ', ')) -Severity 'Info' -Category 'DEBUG'
                            }
                            # Samla skrivna celler för verifiering
                            if ($wsRes.WrittenCells -and $wsRes.WrittenCells.Count -gt 0) {
                                foreach ($wc in $wsRes.WrittenCells) { [void]$wsAllWrittenCells.Add($wc) }
                            }
                        }

                        # GDP A2: Write → Save → Read-back verifiering
                        if ($wsAllWrittenCells.Count -gt 0) {
                            $wsVerify = Verify-WorksheetSignatures -Path $wsSignPath -WrittenCells @($wsAllWrittenCells.ToArray())
                            if ($wsVerify.OK) {
                                Gui-Log "✅ Worksheet-signatur verifierad: $($wsVerify.CellsVerified)/$($wsVerify.CellsChecked) celler OK. $(Split-Path $wsSignPath -Leaf)" 'Info'
                            } else {
                                $reason = if ($wsVerify.Error) { $wsVerify.Error } else { ($wsVerify.Mismatches -join '; ') }
                                Gui-Log "❌ VERIFIERINGSFEL Worksheet: $reason" 'Error'
                                # GDP A4: Forensisk snapshot
                                try { Save-ForensicSnapshot -SourcePath $wsSignPath -Reason "WS read-back mismatch: $reason" -AuditDir (Join-Path $PSScriptRoot 'audit') -Details @{ Checked=$wsVerify.CellsChecked; Verified=$wsVerify.CellsVerified; Mismatches=($wsVerify.Mismatches -join '|') } } catch {}
                                Gui-Log "🛑 Worksheet-signatur ej verifierad. Rapport stoppas." 'Error'
                                return
                            }
                        } else {
                            Gui-Log "✅ Worksheet-signatur sparad (inga nya celler skrivna — redan ifyllda): $(Split-Path $wsSignPath -Leaf)" 'Info'
                        }
                    } catch {
                        # GDP A1: Ingen silent fail — Exception stoppar flödet
                        Gui-Log ("❌ SIGNERINGSFEL Worksheet: " + $_.Exception.Message) 'Error'
                        try { Save-ForensicSnapshot -SourcePath $wsSignPath -Reason "Exception: $($_.Exception.Message)" -AuditDir (Join-Path $PSScriptRoot 'audit') } catch {}
                        return
                    }
                }
            }
        }

        Mark-Phase 'Signering'

        #region Build: CSV-inläsning och RuleEngine
        # ============================
        # === CSV (Info/Control)  ====
        # ============================

        $csvRows = @()
        $runAssay = $null

        if ($selCsv) {
            try {
                $csvInfo = Get-Item -LiteralPath $selCsv -ErrorAction Stop
                $thresholdMb = 25
                try {
                    if ($Config -and ($Config -is [System.Collections.IDictionary]) -and $Config.Contains('CsvStreamingThresholdMB')) {
                        $thresholdMb = [int]$Config['CsvStreamingThresholdMB']
                    }
                } catch {
                    Gui-Log "⚠️ Kunde inte läsa CsvStreamingThresholdMB från konfigurationen." 'Warn'
                }

                $useStreaming = ($csvInfo.Length -ge ($thresholdMb * 1MB))
                if ($useStreaming) {
                    Gui-Log ("⏳ CSV är stor ({0:N1} MB) – använder streaming-import…" -f ($csvInfo.Length / 1MB)) 'Info'
                    Set-UiStep 35 "Läser CSV (streaming)…"
                    $list = New-Object System.Collections.Generic.List[object]
                    Import-CsvRowsStreaming -Path $selCsv -StartRow 10 -ProcessRow {
                        param($Fields,$RowIndex)
                        [void]$list.Add($Fields)
                        if (($RowIndex % 2000) -eq 0) { Invoke-UiPump }
                    }
                    $csvRows = @($list.ToArray())
                } else {
                    Set-UiStep 35 "Läser CSV…"
                    $csvRows = Import-CsvRows -Path $selCsv -StartRow 10
                }

                # --- Robusthet: Sortera på kolumn C (Sample ID) innan vidare bearbetning.
                # Många efterföljande steg (gruppering/skrivning) förutsätter att raderna är konsekvent sorterade.
                try {
                    if ($csvRows -and $csvRows.Count -gt 1) {
                        if ($csvRows[0] -is [object[]]) {
                            # Import-CsvRows* returnerar fält-arrayer: kolumn C = index 2
                            $csvRows = @($csvRows | Sort-Object { [string]($_[2]) })
                        } else {
                            # Om vi i framtiden får PSCustomObject-rader
                            $csvRows = @($csvRows | Sort-Object { [string]($_.'Sample ID') })
                        }
                        Gui-Log ("🔃 CSV sorterad på kolumn C (Sample ID). Rader: {0}" -f $csvRows.Count) 'Info' 'PROGRESS'
                    }
                } catch {
                    Gui-Log "⚠️ Kunde inte sortera CSV på kolumn C (Sample ID)." 'Warn'
                }
            } catch {
                Gui-Log "⚠️ CSV-import misslyckades: $($_.Exception.Message)" 'Warn'
                $csvRows = @()
            }
            try { $runAssay = Get-AssayFromCsv -Path $selCsv -StartRow 10 } catch {}
            if ($runAssay) { Gui-Log "🔎 Assay från CSV: $runAssay" }
        }

        # --- Import av Resample-CSV ---
        $csvRowsRes = @()
        $runAssayRes = $null
        if ($selCsvRes) {
            try {
                Set-UiStep 37 "Läser Resample-CSV…"
                $csvRowsRes = Import-CsvRows -Path $selCsvRes -StartRow 10
                try {
                    if ($csvRowsRes -and $csvRowsRes.Count -gt 1) {
                        if ($csvRowsRes[0] -is [object[]]) {
                            $csvRowsRes = @($csvRowsRes | Sort-Object { [string]($_[2]) })
                        } else {
                            $csvRowsRes = @($csvRowsRes | Sort-Object { [string]($_.'Sample ID') })
                        }
                        Gui-Log ("🔃 Resample-CSV sorterad. Rader: {0}" -f $csvRowsRes.Count) 'Info' 'PROGRESS'
                    }
                } catch {
                    Gui-Log "⚠️ Kunde inte sortera Resample-CSV på kolumn C (Sample ID)." 'Warn'
                }
            } catch {
                Gui-Log "⚠️ Resample-CSV-import misslyckades: $($_.Exception.Message)" 'Warn'
                $csvRowsRes = @()
            }
            try { $runAssayRes = Get-AssayFromCsv -Path $selCsvRes -StartRow 10 } catch {}
            if (-not $runAssayRes -and $runAssay) { $runAssayRes = $runAssay }  # Fallback till primary assay
        }

        # =====================================================
        # === SKANNING AV DATA SUMMARY-BLAD (fynd)
        # === Primär → 'Data Summary' + 'Extra Data Summary', Resample → 'Resample Data Summary'
        # =====================================================
        Mark-Phase 'CsvRead'
        $dataSummaryFindings     = @()
        $dataSummaryFindingsExtra = @()
        $dataSummaryFindingsRes  = @()
        $script:WsPkg            = $null  # Återanvänds av Equipment/Header/QC-sektionerna

        $effectiveAssay = if ($runAssay) { $runAssay } elseif ($runAssayRes) { $runAssayRes } else { $null }
        if ($effectiveAssay) {
            try {
                $selLspDs = $null
                try { $selLspDs = Get-CheckedFilePath $clbLsp } catch { $selLspDs = $null }

                if ($selLspDs -and (Test-Path -LiteralPath $selLspDs)) {
                    $script:WsPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selLspDs))

                    # --- Primär CSV → 'Data Summary' ---
                    if ($selCsv) {
                        $dataSummaryFindings = @(Get-DataSummaryFindings -ExcelPackages @($script:WsPkg) -AssayName $effectiveAssay -SheetName $Layout.SheetDataSummary)
                        $dataSummaryFindingsExtra = @(Get-DataSummaryFindings -ExcelPackages @($script:WsPkg) -AssayName $effectiveAssay -SheetName $Layout.SheetExtraSummary)
                    }

                    # --- Resample-CSV → 'Resample Data Summary' ---
                    if ($selCsvRes) {
                        $resSheetName = 'Resample Data Summary'
                        $dataSummaryFindingsRes = @(Get-DataSummaryFindings -ExcelPackages @($script:WsPkg) -AssayName $effectiveAssay -SheetName $resSheetName)
                        if ($dataSummaryFindingsRes.Count -gt 0) {
                        }
                    }
                }
            } catch {
                Gui-Log ("⚠️ Data Summary scan fel: " + $_.Exception.Message) 'Warn'
                $dataSummaryFindings     = @()
                $dataSummaryFindingsExtra = @()
                $dataSummaryFindingsRes  = @()
                if ($script:WsPkg) { try { $script:WsPkg.Dispose() } catch {} }
                $script:WsPkg = $null
            }
        }
        # Kombinerat DataSummaryFindings (primär + resample) för CSV Sammanfattning
        $allDataSummaryFindings = @($dataSummaryFindings) + @($dataSummaryFindingsExtra) + @($dataSummaryFindingsRes)
        $script:DataSummaryFindings = $allDataSummaryFindings

        # ============================
        # === RuleEngine (skuggresultat) ===
        # ============================
        Mark-Phase 'DataSummary'
        $script:RuleEngineShadowRes = $null   # Resample-resultat (separat)
        try {
            if ((Get-ConfigFlag -Name 'EnableRuleEngine' -Default $false -ConfigOverride $Config) -and
                ($selCsv -or $selCsvRes)) {

                # Ladda rulebank en gång
                $rb = Load-RuleBank -RuleBankDir $Config.RuleBankDir
                try {
                    $rb = Compile-RuleBank -RuleBank $rb
                } catch {
                    Gui-Log ("⚠️ Regelmotor: kunde inte kompilera RuleBank: " + $_.Exception.Message) 'Warn' 'DEBUG'
                }
                $script:RuleBankCache = $rb

                # ======================================
                # PRIMÄR CSV → RuleEngine
                # ======================================
                if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
                    $csvObjs = @()
                    if ($csvRows -and $csvRows.Count -gt 0) {
                        $csvObjs = @($csvRows)
                        Gui-Log ("🧠 Regelmotor: CSV-källa: Import-CsvRows ({0})" -f $csvObjs.Count) 'Info' 'PROGRESS'
                    } else {
                        try {
                            $all = $script:CsvLinesPrimary
                            if ($all -and $all.Count -gt 9) {
                                $del = Get-CsvDelimiter -Path $selCsv
                                $hdr = ConvertTo-CsvFields $all[7]
                                $dl  = $all[9..($all.Count-1)] | Where-Object { $_ -and $_.Trim() }
                                $csvObjs = @(ConvertFrom-Csv -InputObject ($dl -join "`n") -Delimiter $del -Header $hdr)
                            }
                        } catch {
                            Gui-Log ("⚠️ Regelmotor: fallback-raw för CSV misslyckades: " + $_.Exception.Message) 'Warn' 'DEBUG'
                            $csvObjs = @()
                        }
                        Gui-Log ("🧠 Regelmotor: CSV-källa: Fallback-raw ({0})" -f ($csvObjs.Count)) 'Info' 'PROGRESS'
                    }
                    $script:RuleEngineCsvObjs = $csvObjs

                    if (-not $csvObjs -or $csvObjs.Count -eq 0) {
                        Gui-Log "⚠️ Regelmotor: CSV-objekt saknas (0 rader) – hoppar över." 'Warn'
                        $script:RuleEngineShadow = $null
                    } else {
                        $re = Invoke-RuleEngine -CsvObjects $csvObjs -RuleBank $rb -CsvPath $selCsv
                        $script:RuleEngineShadow = $re
                    }
                }

                # ======================================
                # RESAMPLE-CSV → RuleEngine
                # ======================================
                if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
                    $csvObjsRes = @()
                    if ($csvRowsRes -and $csvRowsRes.Count -gt 0) {
                        $csvObjsRes = @($csvRowsRes)
                        Gui-Log ("🧠 Regelmotor (Resample): Import-CsvRows ({0})" -f $csvObjsRes.Count) 'Info' 'PROGRESS'
                    } else {
                        try {
                            $allR = $script:CsvLinesResample
                            if ($allR -and $allR.Count -gt 9) {
                                $delR = Get-CsvDelimiter -Path $selCsvRes
                                $hdrR = ConvertTo-CsvFields $allR[7]
                                $dlR  = $allR[9..($allR.Count-1)] | Where-Object { $_ -and $_.Trim() }
                                $csvObjsRes = @(ConvertFrom-Csv -InputObject ($dlR -join "`n") -Delimiter $delR -Header $hdrR)
                            }
                        } catch {
                            Gui-Log ("⚠️ Regelmotor: fallback-raw för Resample-CSV misslyckades: " + $_.Exception.Message) 'Warn' 'DEBUG'
                            $csvObjsRes = @()
                        }
                    }
                    $script:RuleEngineCsvObjsRes = $csvObjsRes

                    if ($csvObjsRes -and $csvObjsRes.Count -gt 0) {
                        $reRes = Invoke-RuleEngine -CsvObjects $csvObjsRes -RuleBank $rb -CsvPath $selCsvRes
                        $script:RuleEngineShadowRes = $reRes
                    }
                }

                # ======================================
                # KOMBINERAD SUMMERING (primär + resample)
                # ======================================
                $rePrimary = $script:RuleEngineShadow
                $reResamp  = $script:RuleEngineShadowRes

                # Sammanfogning: bygg nytt kombinerat resultat (undvik PS 5.1-bugg med readonly NoteProperty)
                if ($rePrimary -and $reResamp) {
                    try {
                        # Rader
                        $mergedRows = @($rePrimary.Rows) + @($reResamp.Rows)

                        # DeviationCounts — kopiera primär, addera resample
                        $mergedDev = @{}
                        if ($rePrimary.Summary.DeviationCounts) {
                            foreach ($dk in $rePrimary.Summary.DeviationCounts.Keys) { $mergedDev[$dk] = [int]$rePrimary.Summary.DeviationCounts[$dk] }
                        }
                        if ($reResamp.Summary.DeviationCounts) {
                            foreach ($dk in $reResamp.Summary.DeviationCounts.Keys) {
                                if ($mergedDev.ContainsKey($dk)) { $mergedDev[$dk] = [int]$mergedDev[$dk] + [int]$reResamp.Summary.DeviationCounts[$dk] }
                                else { $mergedDev[$dk] = [int]$reResamp.Summary.DeviationCounts[$dk] }
                            }
                        }

                        # ObservedCounts
                        $mergedObs = @{}
                        if ($rePrimary.Summary.ObservedCounts) {
                            foreach ($ok2 in $rePrimary.Summary.ObservedCounts.Keys) { $mergedObs[$ok2] = [int]$rePrimary.Summary.ObservedCounts[$ok2] }
                        }
                        if ($reResamp.Summary.ObservedCounts) {
                            foreach ($ok2 in $reResamp.Summary.ObservedCounts.Keys) {
                                if ($mergedObs.ContainsKey($ok2)) { $mergedObs[$ok2] = [int]$mergedObs[$ok2] + [int]$reResamp.Summary.ObservedCounts[$ok2] }
                                else { $mergedObs[$ok2] = [int]$reResamp.Summary.ObservedCounts[$ok2] }
                            }
                        }

                        # Enkla räknare
                        $mergedInstErr  = ($rePrimary.Summary.InstrumentError + 0) + ($reResamp.Summary.InstrumentError + 0)
                        $mergedMinFunc  = ($rePrimary.Summary.MinorFunctionalError + 0) + ($reResamp.Summary.MinorFunctionalError + 0)
                        $mergedTotal    = ($rePrimary.Summary.Total + 0) + ($reResamp.Summary.Total + 0)
                        $mergedRetest   = ($rePrimary.Summary.RetestYes + 0) + ($reResamp.Summary.RetestYes + 0)

                        # TopDeviations
                        $mergedTop = @($rePrimary.TopDeviations) + @($reResamp.TopDeviations)

                        # QC (behåll primär)
                        $mergedQC = $rePrimary.QC

                        # Bygg nytt resultatobjekt
                        $mergedSummary = [pscustomobject]@{
                            Total                = $mergedTotal
                            ObservedCounts       = $mergedObs
                            DeviationCounts      = $mergedDev
                            RetestYes            = $mergedRetest
                            InstrumentError      = $mergedInstErr
                            MinorFunctionalError = $mergedMinFunc
                        }
                        $script:RuleEngineShadow = [pscustomobject]@{
                            Rows          = $mergedRows
                            Summary       = $mergedSummary
                            TopDeviations = $mergedTop
                            QC            = $mergedQC
                        }
                        Gui-Log ("✅ Merge CSV + Resampling CSV: {0} rader totalt" -f $mergedRows.Count) 'Info'
                    } catch {
                        Gui-Log "⚠️ Merge CSV + Resampling CSV resultat: $($_.Exception.Message)" 'Warn'
                    }
                } elseif (-not $rePrimary -and $reResamp) {
                    # Endast resample
                    $script:RuleEngineShadow = $reResamp
                }

                $re = $script:RuleEngineShadow
                if ($re -and $re.Summary) {
                    try {
                        $pos = 0; $neg = 0; $err = 0
                        if ($re.Summary.ObservedCounts) {
                            if ($re.Summary.ObservedCounts.ContainsKey('POS'))   { $pos = [int]$re.Summary.ObservedCounts['POS'] }
                            if ($re.Summary.ObservedCounts.ContainsKey('NEG'))   { $neg = [int]$re.Summary.ObservedCounts['NEG'] }
                            if ($re.Summary.ObservedCounts.ContainsKey('ERROR')) { $err = [int]$re.Summary.ObservedCounts['ERROR'] }
                        }

                        $ok = 0; $fp = 0; $fn = 0; $derr = 0; $ie = 0
                        if ($re.Summary.DeviationCounts) {
                            if ($re.Summary.DeviationCounts.ContainsKey('OK'))    { $ok   = [int]$re.Summary.DeviationCounts['OK'] }
                            if ($re.Summary.DeviationCounts.ContainsKey('FP'))    { $fp   = [int]$re.Summary.DeviationCounts['FP'] }
                            if ($re.Summary.DeviationCounts.ContainsKey('FN'))    { $fn   = [int]$re.Summary.DeviationCounts['FN'] }
                            if ($re.Summary.DeviationCounts.ContainsKey('ERROR')) { $derr = [int]$re.Summary.DeviationCounts['ERROR'] }
                        }
                        $ie = 0; if ($re.Summary.InstrumentError -ne $null) { $ie = [int]$re.Summary.InstrumentError }
                        $mf = 0; if ($re.Summary.MinorFunctionalError -ne $null) { $mf = [int]$re.Summary.MinorFunctionalError }

                        $resTag = if ($hasResampleCsv) { ' [+Resample]' } else { '' }
                        $sum = "🧠 Regelkontroll$resTag`: POS=$pos, NEG=$neg, Error=$err | OK=$ok, FP=$fp, FN=$fn, Minor Func=$mf | Instrument Error=$ie"
                        # Regelkontroll-detaljer döljs i GUI (kan stressa användare)
                        # Gui-Log -Text $sum -Severity Info -Category SUMMARY
                    } catch { }

                    if ((Get-ConfigFlag -Name 'EnableShadowCompare' -Default $false -ConfigOverride $Config) -and $re.TopDeviations) {
                        $n = 0
                        foreach ($d in $re.TopDeviations) {
                            $n++; if ($n -gt 20) { break }
                            $msg = "⚠️ RuleEngine dev: " + ($d.Deviation + '') + " | " + ($d.SampleId + '') + " | Exp=" + ($d.ExpectedCall + '') + " | Obs=" + ($d.ObservedCall + '')
                            if (($d.ErrorCode + '').Trim()) { $msg += " | Err=" + ($d.ErrorCode + '') }
                            Gui-Log -Text $msg -Severity Info -Category RuleEngineDev
                        }
                    }
                }
            }
        } catch {
            Gui-Log ("⚠️ RuleEngine (shadow) fel: " + $_.Exception.Message) 'Warn'
        }

        $controlTab = $null
        if ($runAssay) { $controlTab = Get-ControlTabName -AssayName $runAssay }
        if ($controlTab) { Gui-Log "🧪 Kontrollmaterial-flik: $controlTab" } else { Gui-Log "ℹ️ Ingen Kontrollmaterialsflik (fortsätter utan)." }

        # ============================
        # === Läs avvikelser       ===
        # ============================

        # P2: Extraherad hjälpfunktion (ersätter duplicerad NEG/POS-loop)
function Get-SealViolations {
    param(
        [Parameter(Mandatory)][OfficeOpenXml.ExcelPackage]$Pkg,
        [double]$MinusThreshold = -3.0
    )
    function _IsSealNA([string]$s) {
        $t = (($s + '') -replace '\s+', '').Trim().ToUpperInvariant()
        return ($t -in @('', 'N/A', 'NA', 'N.A.', '#N/A', '-'))
    }
    function _TrySealDouble {
        param(
            [object]$Value,
            [string]$Text
        )
        if ($Value -ne $null -and $Value -is [double]) {
            return [pscustomobject]@{ Ok = $true; Value = [double]$Value }
        }
        if ($Value -ne $null -and $Value -is [int]) {
            return [pscustomobject]@{ Ok = $true; Value = [double]$Value }
        }
        if ($Value -ne $null -and $Value -is [decimal]) {
            return [pscustomobject]@{ Ok = $true; Value = [double]$Value }
        }
        $raw = (($Text + '').Trim())
        if (-not $raw -and $Value -ne $null) { $raw = (($Value + '').Trim()) }
        if (_IsSealNA $raw) {
            return [pscustomobject]@{ Ok = $false; Value = $null }
        }
        $norm = ($raw -replace '\s+', '')
        $norm = $norm -replace ',', '.'
        $d = 0.0
        if ([double]::TryParse(
                $norm,
                [System.Globalization.NumberStyles]::Float,
                [System.Globalization.CultureInfo]::InvariantCulture,
                [ref]$d
            )) {
            return [pscustomobject]@{ Ok = $true; Value = $d }
        }
        return [pscustomobject]@{ Ok = $false; Value = $null }
    }
    $violations = New-Object System.Collections.Generic.List[object]
    $failCount  = 0
    foreach ($ws in $Pkg.Workbook.Worksheets) {
        if ($ws.Name -eq "Worksheet Instructions") { continue }
        if (-not $ws.Dimension) { continue }
        $obsC = Find-ObservationCol $ws
        for ($r = 3; $r -le 45; $r++) {
            $cartTxt = ($ws.Cells["H$r"].Text + '').Trim()
            $initVal = $ws.Cells["I$r"].Value
            $initTxt = ($ws.Cells["I$r"].Text + '').Trim()
            $finalVal = $ws.Cells["J$r"].Value
            $finalTxt = ($ws.Cells["J$r"].Text + '').Trim()
            $valK  = $ws.Cells["K$r"].Value
            $textL = ($ws.Cells["L$r"].Text + '').Trim()
            $initParsed  = _TrySealDouble -Value $initVal  -Text $initTxt
            $finalParsed = _TrySealDouble -Value $finalVal -Text $finalTxt
            # Säker varning:
            # Endast om faktisk numerisk invägning finns.
            # N/A, NA, blank och placeholders ska inte räknas som invägning.
            if ($initParsed.Ok -and -not $finalParsed.Ok -and [string]::IsNullOrWhiteSpace($textL)) {
                $obsTxt = $ws.Cells[$r, $obsC].Text
                [void]$violations.Add([PSCustomObject]@{
                    Sheet      = $ws.Name
                    Cartridge  = $cartTxt
                    InitialW   = $initParsed.Value
                    FinalW     = $null
                    WeightLoss = $null
                    Status     = 'Saknar utvägning'
                    Obs        = $obsTxt
                })
                continue
            }
            if ($valK -ne $null -and $valK -is [double]) {
                if ($textL -eq "FAIL" -or $valK -le $MinusThreshold) {
                    $obsTxt = $ws.Cells[$r, $obsC].Text
                    [void]$violations.Add([PSCustomObject]@{
                        Sheet      = $ws.Name
                        Cartridge  = $cartTxt
                        InitialW   = $initVal
                        FinalW     = $finalVal
                        WeightLoss = $valK
                        Status     = if ($textL -eq "FAIL") { "FAIL" } else { "Minusvärde" }
                        Obs        = $obsTxt
                    })
                    if ($textL -eq "FAIL") { $failCount++ }
                }
            }
        }
    }
    return [pscustomobject]@{
        Violations = @($violations.ToArray())
        FailCount  = $failCount
    }
}

        $resNeg = Get-SealViolations -Pkg $pkgNeg
        $resPos = Get-SealViolations -Pkg $pkgPos
        $violationsNeg = $resNeg.Violations; $failNegCount = $resNeg.FailCount
        $violationsPos = $resPos.Violations; $failPosCount = $resPos.FailCount
        # STF-count för CSV Sammanfattning: räkna endast riktiga FAIL (Minusvärde visas fortfarande i STF Sum-bladet)
        $script:StfCount = $failNegCount + $failPosCount

        # ============================
        # === Seal Test Info (blad) ==
        # ============================
        Mark-Phase 'RuleEngine'
        $wsOut1 = $pkgOut.Workbook.Worksheets[$Layout.SheetSealTestInfo]
        if (-not $wsOut1) { Gui-Log "❌ Fliken 'Seal Test Info' saknas i mallen"; return }

        for ($row = 3; $row -le 15; $row++) {
            $wsOut1.Cells["D$row"].Value = $null
            try { $wsOut1.Cells["D$row"].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::None } catch {}
        }

        $fields = @(
            @{ Label = "ROBAL";                         Cell = "F2"  }
            @{ Label = "Part Number";                   Cell = "B2"  }
            @{ Label = "Batch Number";                  Cell = "D2"  }
            @{ Label = "Cartridge Number (LSP)";        Cell = "B6"  }
            @{ Label = "PO Number";                     Cell = "B10" }
            @{ Label = "Assay Family";                  Cell = "D10" }
            @{ Label = "Weight Loss Spec";              Cell = "F10" }
            @{ Label = "Balance ID Number";             Cell = "B14" }
            @{ Label = "Balance Cal Due Date";          Cell = "D14" }
            @{ Label = "Vacuum Oven ID Number";         Cell = "B20" }
            @{ Label = "Vacuum Oven Cal Due Date";      Cell = "D20" }
            @{ Label = "Timer ID Number";               Cell = "B25" }
            @{ Label = "Timer Cal Due Date";            Cell = "D25" }
        )

        $forceText = @("ROBAL","Part Number","Batch Number","Cartridge Number (LSP)","PO Number","Assay Family","Balance ID Number","Vacuum Oven ID Number","Timer ID Number")
        $mismatchFields = $fields[0..6] | ForEach-Object { $_.Label }


            # --- Förväntad utrustningslista (valfritt, från equipment.xml) ---
        $equip = $null
        $equipPath = $null
        try {
            $equipPath = Get-ConfigValue -Name 'EquipmentXmlPath' -Default (Join-Path $PSScriptRoot 'equipment.xml') -ConfigOverride $Config
            if ($equipPath -and -not (Test-Path -LiteralPath $equipPath)) {
                Gui-Log ("⚠️ Equipment.xml hittades inte: " + $equipPath) 'Warn'
            }
            if ($equipPath -and (Test-Path -LiteralPath $equipPath)) {
                $equip = Import-Clixml -LiteralPath $equipPath
            }
        } catch {
            $equip = $null
        }

        function _EquipTokens([string]$s) {
            if ([string]::IsNullOrWhiteSpace($s)) { return @() }
            $parts = $s -split '[,;]' |
                ForEach-Object { ($_ -replace '\s+', ' ').Trim() } |
                Where-Object { $_ }
            $tok  = New-Object System.Collections.Generic.List[string]
            $seen = @{}
            foreach ($p in $parts) {
                $v = (Normalize-HeaderText $p).Trim().ToUpper()
                $v = $v -replace '^(NR\.?|NO\.?)\s*', ''
                $v = $v -replace '[^A-Z0-9_-]', ''
                if ($v -and -not $seen.ContainsKey($v)) {
                    $seen[$v] = $true
                    [void]$tok.Add($v)
                }
            }
            return @($tok.ToArray())
        }

        function _EquipPretty([string[]]$tokens, [string]$label) {
            # StrictMode-säker: $tokens kan vara $null eller ett enstaka värde beroende på källa
            if (@($tokens).Count -eq 0) { return '' }
            $seen = @{}
            $t = New-Object System.Collections.Generic.List[string]
            foreach ($item in @($tokens)) {
                $v = ('' + $item).Trim()
                if (-not $v) { continue }
                if (-not $seen.ContainsKey($v)) {
                    $seen[$v] = $true
                    [void]$t.Add($v)
                }
            }
            $out = @($t.ToArray())
            if ($label -ieq 'Timer ID Number') {
                # Visa som "Nr. 24, Nr. 25"
                return (($out | ForEach-Object {
                    if (('' + $_) -match '^(?i)NR\.') { $_ } else { "Nr. $_" }
                }) -join ', ')
            }
            return ($out -join ', ')
        }

        function _FixMonthText([string]$s) {
            if ([string]::IsNullOrWhiteSpace($s)) { return '' }
            $t = (Normalize-HeaderText $s).Trim()
            # Byt ut kyrillisk A (А/а) mot latin A – vanligt i "Аpr-26"
            $t = $t -replace '[Аа]', 'A'
            $t = ($t -replace '\s+', ' ').Trim()
            return $t
        }

        function _EquipMonthTokens([string]$s) {
            if ([string]::IsNullOrWhiteSpace($s)) { return @() }
            $parts = $s -split '[,;]' |
                ForEach-Object { _FixMonthText $_ } |
                Where-Object { $_ }
            $tok  = New-Object System.Collections.Generic.List[string]
            $seen = @{}
            foreach ($p in $parts) {
                $v = ('' + $p).Trim().ToUpper()
                if ($v -and -not $seen.ContainsKey($v)) {
                    $seen[$v] = $true
                    [void]$tok.Add($v)
                }
            }
            return @($tok.ToArray())
        }

        function _EquipEvalList([string]$actual, [string]$expected) {
            # Returnerar: Match | Delvis | Saknas | Mismatch | Ingen referens
            if ([string]::IsNullOrWhiteSpace($expected)) { return 'NoRef' }
            $aT = _EquipTokens $actual
            $eT = _EquipTokens $expected
            # StrictMode-säker: Count på $null kastar i StrictMode
            if (@($aT).Count -eq 0) { return 'Saknas' }
            foreach ($a in $aT) { if (-not ($eT -contains $a)) { return 'Mismatch' } }
            foreach ($e in $eT) { if (-not ($aT -contains $e)) { return 'Delvis' } }
            return 'Match'
        }

        function _EquipEvalMonth([string]$actual, [string]$expected) {
            # Returnerar: Match | Delvis | Saknas | Mismatch | NoRef
            if ([string]::IsNullOrWhiteSpace($expected)) { return 'NoRef' }
            $aT = _EquipMonthTokens $actual
            $eT = _EquipMonthTokens $expected
            if (@($aT).Count -eq 0) { return 'Saknas' }
            foreach ($a in $aT) {
                if (-not ($eT -contains $a)) { return 'Mismatch' }
            }
            foreach ($e in $eT) {
                if (-not ($aT -contains $e)) { return 'Delvis' }
            }
            return 'Match'
        }

        $equipMap = @{
            'Balance ID Number'        = @{ NegKey='SCALESNEG';       PosKey='SCALESPOS';       Mode='LIST'  }
            'Balance Cal Due Date'     = @{ NegKey='CAL_D_SCALES_NEG'; PosKey='CAL_D_SCALES_POS'; Mode='MONTH' }
            'Vacuum Oven ID Number'    = @{ NegKey='OVENSNEG';        PosKey='OVENSPOS';        Mode='LIST'  }
            'Vacuum Oven Cal Due Date' = @{ NegKey='CAL_D_OVENSNEG';  PosKey='CAL_D_OVENSPOS';  Mode='MONTH' }
            'Timer ID Number'          = @{ NegKey='TIMERSNEG';       PosKey='TIMERSPOS';       Mode='LIST'  }
            'Timer Cal Due Date'       = @{ NegKey='CAL_D_TIMERSNEG'; PosKey='CAL_D_TIMERSPOS'; Mode='MONTH' }
        }

        $row = 3
        foreach ($f in $fields) {
$valNeg=''; $valPos=''
$srcNeg=''; $srcPos=''

# För utrustningsrader: samla per flik (inte avbrott på första!)
$perNeg = $null
$perPos = $null
$isEquip = ($equip -and $equipMap -and $equipMap.ContainsKey($f.Label))

if ($isEquip) {
    $perNegObj = _GetPerSheetValueObjects $pkgNeg $f.Cell
    $perPosObj = _GetPerSheetValueObjects $pkgPos $f.Cell
    $perNeg = @($perNegObj | ForEach-Object { $_.Value })
    $perPos = @($perPosObj | ForEach-Object { $_.Value })

    # Visa i B/C: union (för LIST) eller första icke-tom (för MONTH), bara för läsbarhet
    $map = $equipMap[$f.Label]
    if ($map.Mode -eq 'MONTH') {
        $valNeg = ($perNeg | Where-Object { $_ -and $_.Trim() } | Select-Object -First 1)
        $valPos = ($perPos | Where-Object { $_ -and $_.Trim() } | Select-Object -First 1)
    } else {
        $tokN = @()
        foreach ($x in $perNeg) { $tokN += (_EquipTokens $x) }
        $tokP = @()
        foreach ($x in $perPos) { $tokP += (_EquipTokens $x) }
        $valNeg = _EquipPretty $tokN $f.Label
        $valPos = _EquipPretty $tokP $f.Label
    }
}
else {
    # Befintligt beteende för "vanliga" fält: första AKTIVA flik med värde (skippa blad 1 + inaktiva)
    foreach ($wsN in $pkgNeg.Workbook.Worksheets) {
        if (-not (_IsActiveSealSheet $wsN)) { continue }
        $cell = $wsN.Cells[$f.Cell]
        if ($cell.Value -ne $null) {
            if ($cell.Value -is [datetime]) { $valNeg = $cell.Value.ToString('MMM-yy') } else { $valNeg = $cell.Text }
            $srcNeg = $wsN.Name
            break
        }
    }

    foreach ($wsP in $pkgPos.Workbook.Worksheets) {
        if (-not (_IsActiveSealSheet $wsP)) { continue }
        $cell = $wsP.Cells[$f.Cell]
        if ($cell.Value -ne $null) {
            if ($cell.Value -is [datetime]) { $valPos = $cell.Value.ToString('MMM-yy') } else { $valPos = $cell.Text }
            $srcPos = $wsP.Name
            break
        }
    }
}

            if ($forceText -contains $f.Label) {
                $wsOut1.Cells["B$row"].Style.Numberformat.Format = '@'
                $wsOut1.Cells["C$row"].Style.Numberformat.Format = '@'
            }

            $wsOut1.Cells["B$row"].Value = $valNeg
            $wsOut1.Cells["C$row"].Value = $valPos
            try { $wsOut1.Cells["B$row"].Style.Border.Right.Style = "Medium" } catch {}
            try { $wsOut1.Cells["C$row"].Style.Border.Left.Style  = "Medium" } catch {}

        if ($mismatchFields -contains $f.Label) {
                # D3:D9: visa tydlig Match/Mismatch med symboler
                if ($valNeg -and $valPos) {
                    if ($valNeg -ne $valPos) {
                        # Spårbarhet endast vid mismatch: flik + cell för var värdet hämtades
                        $tN = if ($srcNeg) { ("NEG:{0}@{1}" -f $srcNeg, $f.Cell) } else { ("NEG@{0}" -f $f.Cell) }
                        $tP = if ($srcPos) { ("POS:{0}@{1}" -f $srcPos, $f.Cell) } else { ("POS@{0}" -f $f.Cell) }
                        $wsOut1.Cells["D$row"].Value = ("⚠ Mismatch ({0} | {1})" -f $tN, $tP)
                        try { $wsOut1.Cells["D$row"].Style.Font.Size = 9 } catch {}
                        Style-Cell $wsOut1.Cells["D$row"] $true "FF0000" "Medium" "FFFFFF"
                        Gui-Log "⚠️ Avvikelse: $($f.Label) (NEG='$valNeg' vs POS='$valPos')"
                    } else {
                        $wsOut1.Cells["D$row"].Value = "✓ Match"
                        Style-Cell $wsOut1.Cells["D$row"] $true "C6EFCE" "Medium" "006100"
                    }
                } elseif ($valNeg -or $valPos) {
                    # Bara en av filerna har värde - markera som varning
                    $wsOut1.Cells["D$row"].Value = "⚠ Saknas"
                    Style-Cell $wsOut1.Cells["D$row"] $true "FFE699" "Medium" "806000"
                }
            }

            # --- Utrustningskontroll (POS/NEG har egna tillåtna värden i equipment.xml) ---
            if ($equip -and $equipMap -and $equipMap.ContainsKey($f.Label)) {
                $map = $equipMap[$f.Label]
                $expNeg = $null; $expPos = $null
                try { if ($equip.Contains($map.NegKey)) { $expNeg = (""+$equip[$map.NegKey]).Trim() } } catch {}
                try { if ($equip.Contains($map.PosKey)) { $expPos = (""+$equip[$map.PosKey]).Trim() } } catch {}

# Utvärdera PER FLIK och summera
$stNegAll = @()
$stPosAll = @()
                $negMismatchSheets = @()
                $posMismatchSheets = @()
                $negDelvisSheets = @()
                $posDelvisSheets = @()

if ($map.Mode -eq 'MONTH') {
    for ($i = 0; $i -lt $perNegObj.Count; $i++) {
        $st = (_EquipEvalMonth $perNegObj[$i].Value $expNeg); $stNegAll += $st
        if ($st -eq 'Mismatch') { $negMismatchSheets += ("{0}@{1}" -f $perNegObj[$i].Sheet, $perNegObj[$i].Addr) }
        if ($st -eq 'Delvis')   { $negDelvisSheets   += ("{0}@{1}" -f $perNegObj[$i].Sheet, $perNegObj[$i].Addr) }
    }
    for ($i = 0; $i -lt $perPosObj.Count; $i++) {
        $st = (_EquipEvalMonth $perPosObj[$i].Value $expPos); $stPosAll += $st
        if ($st -eq 'Mismatch') { $posMismatchSheets += ("{0}@{1}" -f $perPosObj[$i].Sheet, $perPosObj[$i].Addr) }
        if ($st -eq 'Delvis')   { $posDelvisSheets   += ("{0}@{1}" -f $perPosObj[$i].Sheet, $perPosObj[$i].Addr) }
    }
} else {

    for ($i = 0; $i -lt $perNegObj.Count; $i++) {
        $st = (_EquipEvalList $perNegObj[$i].Value $expNeg); $stNegAll += $st
        if ($st -eq 'Mismatch') { $negMismatchSheets += ("{0}@{1}" -f $perNegObj[$i].Sheet, $perNegObj[$i].Addr) }
        if ($st -eq 'Delvis')   { $negDelvisSheets   += ("{0}@{1}" -f $perNegObj[$i].Sheet, $perNegObj[$i].Addr) }
    }
    for ($i = 0; $i -lt $perPosObj.Count; $i++) {
        $st = (_EquipEvalList $perPosObj[$i].Value $expPos); $stPosAll += $st
        if ($st -eq 'Mismatch') { $posMismatchSheets += ("{0}@{1}" -f $perPosObj[$i].Sheet, $perPosObj[$i].Addr) }
        if ($st -eq 'Delvis')   { $posDelvisSheets   += ("{0}@{1}" -f $perPosObj[$i].Sheet, $perPosObj[$i].Addr) }
    }
}

$sNeg = _AggregateStatus $stNegAll
$sPos = _AggregateStatus $stPosAll

                function _Txt($s) {
                    switch ($s) {
                        'Match'   { '✓ Match' }
                        'Delvis'  { '✓ Delvis' }
                        'Saknas'  { '⚠ Saknas' }
                        'Mismatch'{ '⚠ Mismatch' }
                        default   { '?' }
                    }
                }

                # Hjälpfunktion: plocka ut enbart bladnamn (ta bort @cellref)
                function _CleanSheets([string[]]$arr) {
                    ($arr | ForEach-Object { ($_ -replace '@.*$','').Trim() } | Select-Object -Unique) -join ', '
                }

                $hasMismatch = ($sNeg -eq 'Mismatch' -or $sPos -eq 'Mismatch')
                $hasDelvis   = ($sNeg -eq 'Delvis'   -or $sPos -eq 'Delvis')

                if ($hasMismatch -or $hasDelvis) {
                    # NEG → kolumn D
                    $dVal = 'NEG ' + (_Txt $sNeg)
                    if ($sNeg -eq 'Mismatch' -and $negMismatchSheets.Count -gt 0) {
                        $dVal += ': ' + (_CleanSheets $negMismatchSheets)
                    } elseif ($sNeg -eq 'Delvis' -and $negDelvisSheets.Count -gt 0) {
                        $dVal += ': ' + (_CleanSheets $negDelvisSheets)
                    }
                    $wsOut1.Cells["D$row"].Value = $dVal
                    try { $wsOut1.Cells["D$row"].Style.Font.Size = 9 } catch {}

                    # POS → kolumn E
                    $eVal = 'POS ' + (_Txt $sPos)
                    if ($sPos -eq 'Mismatch' -and $posMismatchSheets.Count -gt 0) {
                        $eVal += ': ' + (_CleanSheets $posMismatchSheets)
                    } elseif ($sPos -eq 'Delvis' -and $posDelvisSheets.Count -gt 0) {
                        $eVal += ': ' + (_CleanSheets $posDelvisSheets)
                    }
                    $wsOut1.Cells["E$row"].Value = $eVal
                    try { $wsOut1.Cells["E$row"].Style.Font.Size = 9 } catch {}
                } else {
                    $wsOut1.Cells["D$row"].Value = ('NEG ' + (_Txt $sNeg) + ' / POS ' + (_Txt $sPos))
                }

                # Formatera D+E utifrån respektive status
                $rank = @{ 'NoRef'=0; 'Match'=1; 'Delvis'=2; 'Saknas'=2; 'Mismatch'=3 }

                foreach ($pair in @(@{C='D';S=$sNeg}, @{C='E';S=$sPos})) {
                    $col = $pair.C; $st = $pair.S
                    $cellVal = ($wsOut1.Cells["$col$row"].Text + '').Trim()
                    if (-not $cellVal) { continue }
                    $r = $rank[$st]
                    if ($r -ge 3) {
                        Style-Cell $wsOut1.Cells["$col$row"] $true "FF0000" "Medium" "FFFFFF"
                    } elseif ($r -ge 2) {
                        Style-Cell $wsOut1.Cells["$col$row"] $true "FFE699" "Medium" "806000"
                    } elseif ($r -ge 1) {
                        Style-Cell $wsOut1.Cells["$col$row"] $true "C6EFCE" "Medium" "006100"
                    }
                }
            }
            $row++
        }

        $wsOut1.Cells["D:D"].Style.WrapText = $false
        $wsOut1.Cells["E:E"].Style.WrapText = $false
        $wsOut1.Column(4).AutoFit()
        $wsOut1.Column(4).Width += 1.5
        $wsOut1.Column(4).BestFit = $true
        $wsOut1.Column(5).AutoFit()
        $wsOut1.Column(5).Width += 1.5
        $wsOut1.Column(5).BestFit = $true

        # R2: Freeze panes – fryser rad 1–2 (rubrik) så data scrollas under
        try { $wsOut1.View.FreezePanes(3, 1) } catch {}

        # ============================
        # === Testare (B43)        ===
        # ============================

        $testersNeg = @(); $testersPos = @()
        $unsignedNegSheets = New-Object System.Collections.Generic.List[string]
        $unsignedPosSheets = New-Object System.Collections.Generic.List[string]
        foreach ($s in $pkgNeg.Workbook.Worksheets) {
            if (-not (_IsActiveSealSheet $s)) { continue }
            $t = (($s.Cells["B43"].Text + '')).Trim()
            if ($t) {
                $testersNeg += ($t -split ",")
            } else {
                [void]$unsignedNegSheets.Add($s.Name)
            }
        }
        foreach ($s in $pkgPos.Workbook.Worksheets) {
            if (-not (_IsActiveSealSheet $s)) { continue }
            $t = (($s.Cells["B43"].Text + '')).Trim()
            if ($t) {
                $testersPos += ($t -split ",")
            } else {
                [void]$unsignedPosSheets.Add($s.Name)
            }
        }
        $testersNeg = $testersNeg | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Sort-Object -Unique
        $testersPos = $testersPos | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Sort-Object -Unique

        $wsOut1.Cells["B16"].Value = "Name of Tester"
        $wsOut1.Cells["B16:C16"].Merge = $true
        $wsOut1.Cells["B16"].Style.HorizontalAlignment = "Center"

        $maxTesters = [Math]::Max($testersNeg.Count, $testersPos.Count)
        $initialRows = 11
        if ($maxTesters -lt $initialRows) { $wsOut1.DeleteRow(17 + $maxTesters, $initialRows - $maxTesters) }
        if ($maxTesters -gt $initialRows) {
            $rowsToAdd = $maxTesters - $initialRows
            $lastRow = 16 + $initialRows
            for ($i = 1; $i -le $rowsToAdd; $i++) { $wsOut1.InsertRow($lastRow + 1, 1, $lastRow) }
        }

        for ($i = 0; $i -lt $maxTesters; $i++) {
            $rowIndex = 17 + $i
            $wsOut1.Cells["A$rowIndex"].Value = $null
            $wsOut1.Cells["B$rowIndex"].Value = if ($i -lt $testersNeg.Count) { $testersNeg[$i] } else { "N/A" }
            $wsOut1.Cells["C$rowIndex"].Value = if ($i -lt $testersPos.Count) { $testersPos[$i] } else { "N/A" }

            $topStyle    = if ($i -eq 0) { "Medium" } else { "Thin" }
            $bottomStyle = if ($i -eq $maxTesters - 1) { "Medium" } else { "Thin" }

            foreach ($col in @("B","C")) {
                $cell = $wsOut1.Cells["$col$rowIndex"]
                $cell.Style.Border.Top.Style    = $topStyle
                $cell.Style.Border.Bottom.Style = $bottomStyle
                $cell.Style.Border.Left.Style   = "Medium"
                $cell.Style.Border.Right.Style  = "Medium"
                $cell.Style.Fill.PatternType = "Solid"
                $cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#CCFFFF"))
            }
        }

        function _BuildUnsignedSealText([string[]]$sheetNames) {
            $arr = @($sheetNames | Where-Object { $_ })
            if ($arr.Count -eq 0) { return '' }
            $arr = @($arr | Select-Object -Unique)
            if ($arr.Count -eq 1) { return ($arr[0] + ' osignerat') }
            return (($arr -join ', ') + ' osignerade')
        }

        $negUnsignedText = _BuildUnsignedSealText @($unsignedNegSheets.ToArray())
        $posUnsignedText = _BuildUnsignedSealText @($unsignedPosSheets.ToArray())
        $unsignedMsgs = @()
        if ($negUnsignedText) { $unsignedMsgs += ('NEG: ' + $negUnsignedText) }
        if ($posUnsignedText) { $unsignedMsgs += ('POS: ' + $posUnsignedText) }
        if ($unsignedMsgs.Count -gt 0) {
            $unsignedInfo = $unsignedMsgs -join ' | '
            $wsOut1.Cells['D16'].Value = 'Name of Tester (osignerat)'
            $wsOut1.Cells['D17'].Value = $unsignedInfo
            $wsOut1.Cells['D16'].Style.Font.Bold = $true
            $wsOut1.Cells['D16:D17'].Style.WrapText = $true
            Style-Cell $wsOut1.Cells['D17'] $true "FFE699" "Medium" "806000"
            try {
                $wsOut1.Column(4).AutoFit()
                if ($wsOut1.Column(4).Width -lt 42) { $wsOut1.Column(4).Width = 42 }
                $wsOut1.Column(4).BestFit = $true
            } catch {}
            Gui-Log ("⚠️ Name of Tester saknas på aktiva datasheets: {0}" -f $unsignedInfo) 'Warn'
        }
        # ============================
        # === Signatur-jämförelse  ===
        # ============================
$negSigSet = Get-SignatureSetForDataSheets -Pkg $pkgNeg -SignatureCell $Layout.SignatureCell -ActiveCheckCell $Layout.SealActiveCheckCell
$posSigSet = Get-SignatureSetForDataSheets -Pkg $pkgPos -SignatureCell $Layout.SignatureCell -ActiveCheckCell $Layout.SealActiveCheckCell
        $negSet = New-Object 'System.Collections.Generic.HashSet[string]'
        $posSet = New-Object 'System.Collections.Generic.HashSet[string]'
        foreach ($n in $negSigSet.NormSet) { [void]$negSet.Add($n) }
        foreach ($p in $posSigSet.NormSet) { [void]$posSet.Add($p) }
$hasNeg = ($negSet.Count -gt 0)
$hasPos = ($posSet.Count -gt 0)
$missingNegSheets = @()
$missingPosSheets = @()
if (-not $sealSignatureOverwriteAppliedThisRun) {
    if ($negSigSet -and $negSigSet.PSObject.Properties['Missing']) {
        $missingNegSheets = @($negSigSet.Missing | Where-Object { $_ })
    }
    if ($posSigSet -and $posSigSet.PSObject.Properties['Missing']) {
        $missingPosSheets = @($posSigSet.Missing | Where-Object { $_ })
    }
}
$sigMissing = (($missingNegSheets.Count + $missingPosSheets.Count) -gt 0)
$onlyNeg = @(); $onlyPos = @(); $sigMismatch = $false
if ($sealSignatureOverwriteAppliedThisRun) {

    # Denna körning har precis skrivit över signaturen på aktiva Seal Test-blad
    # och verifieringen har passerat. Då ska äldre inläst signaturdata inte
    # skapa falsk mismatch i rapporten.
    $sigMismatch = $false
    $hasNeg = $true
    $hasPos = $true
}
elseif ($hasNeg -and $hasPos) {
    foreach ($n in $negSet) { if (-not $posSet.Contains($n)) { $onlyNeg += $n } }
    foreach ($p in $posSet) { if (-not $negSet.Contains($p)) { $onlyPos += $p } }
    $sigMismatch = ($onlyNeg.Count -gt 0 -or $onlyPos.Count -gt 0)
} else {
    $sigMismatch = $false
}
$sigIssue = ($sigMismatch -or $sigMissing)
$mismatchSheets = @()
if ($sigMissing) {
    foreach ($sheetName in $missingNegSheets) {
        $mismatchSheets += ("NEG: SIGNATUR SAKNAS  [Blad: " + $sheetName + "]")
    }
    foreach ($sheetName in $missingPosSheets) {
        $mismatchSheets += ("POS: SIGNATUR SAKNAS  [Blad: " + $sheetName + "]")
    }
    $missingParts = @()
    if ($missingNegSheets.Count -gt 0) { $missingParts += ("NEG: " + ($missingNegSheets -join ', ')) }
    if ($missingPosSheets.Count -gt 0) { $missingParts += ("POS: " + ($missingPosSheets -join ', ')) }
    Gui-Log ("⚠️ Avvikelse: Print Full Name, Sign, and Date saknas på aktivt Seal Test-datasheet: {0}" -f ($missingParts -join ' | ')) 'Warn'
}
if ($sigMismatch) {
            foreach ($k in $onlyNeg) {
                $raw = if ($negSigSet.RawByNorm.ContainsKey($k)) { $negSigSet.RawByNorm[$k] } else { $k }
                $where = if ($negSigSet.Occ.ContainsKey($k)) { ($negSigSet.Occ[$k] -join ', ') } else { '—' }
                $mismatchSheets += ("NEG: " + $raw + "  [Blad: " + $where + "]")
            }
            foreach ($k in $onlyPos) {
                $raw = if ($posSigSet.RawByNorm.ContainsKey($k)) { $posSigSet.RawByNorm[$k] } else { $k }
                $where = if ($posSigSet.Occ.ContainsKey($k)) { ($posSigSet.Occ[$k] -join ', ') } else { '—' }
                $mismatchSheets += ("POS: " + $raw + "  [Blad: " + $where + "]")
            }
            Gui-Log "⚠️ Avvikelse: Print Full Name, Sign, and Date (NEG vs POS)"
        }

        if (-not (Get-Command Set-MergedWrapAutoHeight -ErrorAction SilentlyContinue)) {
            function Set-MergedWrapAutoHeight {
                param([OfficeOpenXml.ExcelWorksheet]$Sheet,[int]$RowIndex,[int]$ColStart=2,[int]$ColEnd=3,[string]$Text)
                $rng = $Sheet.Cells[$RowIndex, $ColStart, $RowIndex, $ColEnd]
                $rng.Style.WrapText = $true
                $rng.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::None
                $Sheet.Row($RowIndex).CustomHeight = $false
                try {
                    $wChars = [Math]::Floor(($Sheet.Column($ColStart).Width + $Sheet.Column($ColEnd).Width) - 2); if ($wChars -lt 1) { $wChars = 1 }
                    $segments = $Text -split "(\r\n|\n|\r)"; $lineCount = 0
                    foreach ($seg in $segments) { if (-not $seg) { $lineCount++ } else { $lineCount += [Math]::Ceiling($seg.Length / $wChars) } }
                    if ($lineCount -lt 1) { $lineCount = 1 }
                    $targetHeight = [Math]::Max(15, [Math]::Ceiling(15 * $lineCount * 2.15))
                    if ($Sheet.Row($RowIndex).Height -lt $targetHeight) {
                        $Sheet.Row($RowIndex).Height = $targetHeight
                        $Sheet.Row($RowIndex).CustomHeight = $true
                    }
                } catch { $Sheet.Row($RowIndex).CustomHeight = $false }
            }
        }

        $signRow = 17 + $maxTesters + 3
        $displaySignNeg = $null; $displaySignPos = $null

        if ($signToWrite) {
            $displaySignNeg = $signToWrite
            $displaySignPos = $signToWrite
        } else {
            $displaySignNeg = if ($negSigSet.RawFirst) { $negSigSet.RawFirst } else { '—' }
            $displaySignPos = if ($posSigSet.RawFirst) { $posSigSet.RawFirst } else { '—' }
        }

        $wsOut1.Cells["B$signRow"].Style.Numberformat.Format = '@'
        $wsOut1.Cells["C$signRow"].Style.Numberformat.Format = '@'
        $wsOut1.Cells["B$signRow"].Value = $displaySignNeg
        $wsOut1.Cells["C$signRow"].Value = $displaySignPos

        foreach ($col in @('B','C')) {
            $cell = $wsOut1.Cells["${col}$signRow"]
            Style-Cell $cell $false 'CCFFFF' 'Medium' $null
            $cell.Style.HorizontalAlignment = 'Center'
        }

        try { $wsOut1.Column(2).Width = 40; $wsOut1.Column(3).Width = 40 } catch {}
if ($sigIssue) {
    # === SIGNATURAVVIKELSE: mismatch och/eller saknad signatur ===
    $mismatchCell = $wsOut1.Cells["D$signRow"]
    if ($sigMissing -and $sigMismatch) {
        $mismatchCell.Value = ([char]0x26A0 + ' Mismatch / saknas')
    }
    elseif ($sigMissing) {
        $mismatchCell.Value = ([char]0x26A0 + ' Signatur saknas')
    }
    else {
        $mismatchCell.Value = ([char]0x26A0 + ' Mismatch')
    }
    Style-Cell $mismatchCell $true 'FF0000' 'Medium' 'FFFFFF'

            if ($mismatchSheets.Count -gt 0) {
                # Bygg kompakt detaljtext: en rad per avvikande signatur
                $detailLines = New-Object System.Collections.Generic.List[string]
                foreach ($text in $mismatchSheets) {
                    $filType = ''; $sigVal = ''; $bladVal = ''
                    if ($text -match '^(NEG|POS):\s*(.+?)\s*\[Blad:\s*(.+?)\]$') {
                        $filType = $matches[1]
                        $sigVal  = $matches[2].Trim()
                        $bladVal = $matches[3].Trim()
                        [void]$detailLines.Add("$filType : $sigVal  ($bladVal)")
                    } else {
                        [void]$detailLines.Add($text)
                    }
                }
                $detailRow = $signRow + 1
                $detailText = ($detailLines -join [char]10)
                $detailCell = $wsOut1.Cells["D$detailRow"]
                $detailCell.Value = $detailText
                $detailCell.Style.WrapText = $true
                $detailCell.Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Top
                $detailCell.Style.Font.Size = 9
                $detailCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $detailCell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#FFE699'))
                $detailCell.Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml('#806000'))
                $detailCell.Style.Border.Top.Style    = 'Medium'
                $detailCell.Style.Border.Bottom.Style = 'Medium'
                $detailCell.Style.Border.Left.Style   = 'Medium'
                $detailCell.Style.Border.Right.Style  = 'Medium'

                # Dynamisk radhöjd baserat på antal rader
                try {
                    $lineCount = [Math]::Max(1, $detailLines.Count)
                    $targetHeight = [Math]::Max(20, $lineCount * 16)
                    $wsOut1.Row($detailRow).Height = $targetHeight
                    $wsOut1.Row($detailRow).CustomHeight = $true
                } catch {}
            }
} else {
    # === MATCH: grön markering endast när signaturer finns och stämmer ===
    if ($hasNeg -and $hasPos -and -not $sigMissing) {
        $matchCell = $wsOut1.Cells["D$signRow"]
        $matchCell.Value = '✓ Match'
        Style-Cell $matchCell $true 'C6EFCE' 'Medium' '006100'
    }
}

        # ============================
        # === STF Sum              ===
        # ============================

        $wsOut2 = $pkgOut.Workbook.Worksheets[$Layout.SheetStfSummary]
        if (-not $wsOut2) { Gui-Log "❌ Fliken 'STF Summary' saknas i mallen!"; return }

        $totalRows = $violationsNeg.Count + $violationsPos.Count
        $currentRow = 2

        if ($totalRows -eq 0) {
            Gui-Log "✅ Seal Test hittades"
            $wsOut2.Cells["B1:H1"].Value = $null
            $wsOut2.Cells["A1"].Value = "Inga STF hittades!"
            Style-Cell $wsOut2.Cells["A1"] $true "D9EAD3" "Medium" "006100"
            $wsOut2.Cells["A1"].Style.HorizontalAlignment = "Left"
            if ($wsOut2.Dimension -and $wsOut2.Dimension.End.Row -gt 1) { $wsOut2.DeleteRow(2, $wsOut2.Dimension.End.Row - 1) }
        }
        else {

            $oldDataRows = 0
            if ($wsOut2.Dimension) {
                $oldDataRows = $wsOut2.Dimension.End.Row - 1
                if ($oldDataRows -lt 0) { $oldDataRows = 0 }
            }

            if ($totalRows -lt $oldDataRows) {
                $wsOut2.DeleteRow(2 + $totalRows, $oldDataRows - $totalRows)
            }
            elseif ($totalRows -gt $oldDataRows) {
                $wsOut2.InsertRow(2 + $oldDataRows, $totalRows - $oldDataRows, 1 + $oldDataRows)
            }

            $currentRow = 2
            foreach ($v in $violationsNeg) {
                $wsOut2.Cells["A$currentRow"].Value = "NEG"
                $wsOut2.Cells["B$currentRow"].Value = $v.Sheet
                $wsOut2.Cells["C$currentRow"].Value = $v.Cartridge
                $wsOut2.Cells["D$currentRow"].Value = $v.InitialW
                $wsOut2.Cells["E$currentRow"].Value = $v.FinalW
                if ($v.WeightLoss -ne $null) {
    $wsOut2.Cells["F$currentRow"].Value = [Math]::Round([double]$v.WeightLoss, 1)
} else {
    $wsOut2.Cells["F$currentRow"].Value = $null
}
                $wsOut2.Cells["G$currentRow"].Value = $v.Status
                $wsOut2.Cells["H$currentRow"].Value = if ([string]::IsNullOrWhiteSpace($v.Obs)) { 'NA' } else { $v.Obs }

                Style-Cell $wsOut2.Cells["A$currentRow"] $true "B5E6A2" "Medium" $null
                $wsOut2.Cells["C$currentRow:E$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["C$currentRow:E$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#CCFFFF"))
                $wsOut2.Cells["F$currentRow:G$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["F$currentRow:G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFFF99"))
                $wsOut2.Cells["H$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["H$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#D9D9D9"))

if ($v.Status -in @("FAIL","Minusvärde")) {
    $wsOut2.Cells["F$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["F$currentRow"].Style.Font.Color.SetColor([System.Drawing.Color]::Red)
    $wsOut2.Cells["G$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["G$currentRow"].Style.Font.Color.SetColor([System.Drawing.Color]::Red)
    # Röd bakgrund på riktig FAIL
    if ($v.Status -eq "FAIL") {
        $wsOut2.Cells["G$currentRow"].Style.Fill.PatternType = "Solid"
        $wsOut2.Cells["G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFC7CE"))
    }
}
elseif ($v.Status -eq "Saknar utvägning") {
    $wsOut2.Cells["E$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["E$currentRow"].Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#806000"))
    $wsOut2.Cells["G$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["G$currentRow"].Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#806000"))
    $wsOut2.Cells["G$currentRow"].Style.Fill.PatternType = "Solid"
    $wsOut2.Cells["G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFE699"))
}

                Set-RowBorder -ws $wsOut2 -row $currentRow -firstRow 2 -lastRow ($totalRows + 1)
                $currentRow++
            }

            foreach ($v in $violationsPos) {
                $wsOut2.Cells["A$currentRow"].Value = "POS"
                $wsOut2.Cells["B$currentRow"].Value = $v.Sheet
                $wsOut2.Cells["C$currentRow"].Value = $v.Cartridge
                $wsOut2.Cells["D$currentRow"].Value = $v.InitialW
                $wsOut2.Cells["E$currentRow"].Value = $v.FinalW
                if ($v.WeightLoss -ne $null) {
    $wsOut2.Cells["F$currentRow"].Value = [Math]::Round([double]$v.WeightLoss, 1)
} else {
    $wsOut2.Cells["F$currentRow"].Value = $null
}
                $wsOut2.Cells["G$currentRow"].Value = $v.Status
                $wsOut2.Cells["H$currentRow"].Value = if ($v.Obs) { $v.Obs } else { 'NA' }

                Style-Cell $wsOut2.Cells["A$currentRow"] $true "FFB3B3" "Medium" $null
                $wsOut2.Cells["C$currentRow:E$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["C$currentRow:E$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#CCFFFF"))
                $wsOut2.Cells["F$currentRow:G$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["F$currentRow:G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFFF99"))
                $wsOut2.Cells["H$currentRow"].Style.Fill.PatternType = "Solid"
                $wsOut2.Cells["H$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#D9D9D9"))

if ($v.Status -in @("FAIL","Minusvärde")) {
    $wsOut2.Cells["F$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["F$currentRow"].Style.Font.Color.SetColor([System.Drawing.Color]::Red)
    $wsOut2.Cells["G$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["G$currentRow"].Style.Font.Color.SetColor([System.Drawing.Color]::Red)
    # Röd bakgrund på riktig FAIL
    if ($v.Status -eq "FAIL") {
        $wsOut2.Cells["G$currentRow"].Style.Fill.PatternType = "Solid"
        $wsOut2.Cells["G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFC7CE"))
    }
}
elseif ($v.Status -eq "Saknar utvägning") {
    $wsOut2.Cells["E$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["E$currentRow"].Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#806000"))
    $wsOut2.Cells["G$currentRow"].Style.Font.Bold = $true
    $wsOut2.Cells["G$currentRow"].Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml("#806000"))
    $wsOut2.Cells["G$currentRow"].Style.Fill.PatternType = "Solid"
    $wsOut2.Cells["G$currentRow"].Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml("#FFE699"))
}

                Set-RowBorder -ws $wsOut2 -row $currentRow -firstRow 2 -lastRow ($totalRows + 1)
                $currentRow++
            }

            $wsOut2.Cells.Style.WrapText = $false
            $wsOut2.Cells["A1"].Style.HorizontalAlignment = "Left"
            try { $wsOut2.Cells[2,6,([Math]::Max($currentRow-1,2)),6].Style.Numberformat.Format = '0.0' } catch {}
            if ($wsOut2.Dimension) {
                try {
                    if (Get-Command Safe-AutoFitColumns -ErrorAction SilentlyContinue) {
                        Safe-AutoFitColumns -Ws $wsOut2 -Context 'OutputSheet'
                    } else {
                        $wsOut2.Cells[$wsOut2.Dimension.Address].AutoFitColumns() | Out-Null
                    }
                } catch {}
            }
        }


        #endregion Build: CSV-inläsning och RuleEngine
        #region Build: Output-flikar (Information, Utrustning, Kontrollmaterial, SP, QC)
# ============================
# === Information-blad     ===
# ============================

try {
    if (-not (Get-Command Add-Hyperlink -ErrorAction SilentlyContinue)) {
        function Add-Hyperlink {
            param(
                [OfficeOpenXml.ExcelRange]$Cell,
                [string]$Text,
                [string]$Url
            )
            try {
                $Cell.Value = $Text
                $Cell.Hyperlink = [Uri]$Url
                $Cell.Style.Font.UnderLine = $true
                $Cell.Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(0,102,204))
            } catch {}
        }
    }

    if (-not (Get-Command Find-RegexCell -ErrorAction SilentlyContinue)) {
        function Find-RegexCell {
            param(
                [OfficeOpenXml.ExcelWorksheet]$Ws,
                [regex]$Rx,
                [int]$MaxRows = 200,
                [int]$MaxCols = 40
            )
            if (-not $Ws -or -not $Ws.Dimension) { return $null }

            $rMax = [Math]::Min($Ws.Dimension.End.Row, $MaxRows)
            $cMax = [Math]::Min($Ws.Dimension.End.Column, $MaxCols)

            for ($r = 1; $r -le $rMax; $r++) {
                for ($c = 1; $c -le $cMax; $c++) {
                    $t = Normalize-HeaderText ($Ws.Cells[$r,$c].Text + '')
                    if ($t -and $Rx.IsMatch($t)) {
                        return @{ Row = $r; Col = $c; Text = $t }
                    }
                }
            }
            return $null
        }
    }

    if (-not (Get-Command Get-SealHeaderDocInfo -ErrorAction SilentlyContinue)) {
        function Get-SealHeaderDocInfo {
            param([OfficeOpenXml.ExcelPackage]$Pkg)

            $result = [pscustomobject]@{ Raw=''; DocNo=''; Rev='' }
            if (-not $Pkg) { return $result }

            $ws = $Pkg.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' } | Select-Object -First 1
            if (-not $ws) { return $result }

            try {
                $lt = ($ws.HeaderFooter.OddHeader.LeftAlignedText + '').Trim()
                if (-not $lt) { $lt = ($ws.HeaderFooter.EvenHeader.LeftAlignedText + '').Trim() }

                $result.Raw = $lt

                $rx = [regex]'(?i)(?:document\s*(?:no|nr|#|number)\s*[:#]?\s*([A-Z0-9\-_\.\/]+))?.*?(?:rev(?:ision)?\.?\s*[:#]?\s*([A-Z0-9\-_\.]+))?'
                $m = $rx.Match($lt)
                if ($m.Success) {
                    if ($m.Groups[1].Value) { $result.DocNo = $m.Groups[1].Value.Trim() }
                    if ($m.Groups[2].Value) { $result.Rev   = $m.Groups[2].Value.Trim() }
                }
            } catch {}

            return $result
        }
    }
    Mark-Phase 'Kontrollmaterial'
    $wsInfo = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if (-not $wsInfo) { $wsInfo = $pkgOut.Workbook.Worksheets.Add($Layout.SheetRunInfo) }

# Säkerställ att kolumn C inte är dold (mallen styr bredd och wrap)
try { $wsInfo.Column(3).Hidden = $false } catch {}

    try {
        $csvLines = $null
        $csvStats = $null

        # ✅ Viktigt: initiera alltid, även om ingen CSV är vald
        $csvInstrumentSerials = @()

        if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
            try { $csvLines = $script:CsvLinesPrimary } catch { Gui-Log ("⚠️ Kunde inte läsa CSV: " + $_.Exception.Message) 'Warn' }
            try { $csvStats = Get-CsvStats -Path $selCsv -Lines $csvLines } catch { Gui-Log ("⚠️ Get-CsvStats: " + $_.Exception.Message) 'Warn' }

            # Hämta exakt lista med Instrument S/N från CSV (för Equipment-blad när WS-skanning är av)
            try {
                if ($csvLines -and $csvLines.Count -gt 8) {
                    $hdr = ConvertTo-CsvFields $csvLines[7]

                    $idx = -1
                    for ($ii=0; $ii -lt $hdr.Count; $ii++) {
                        $h = (($hdr[$ii] + '').Trim('\"').ToLower())
                        if ($h -eq 'instrument s/n' -or $h -match 'instrument') { $idx = $ii; break }
                    }

                    if ($idx -ge 0) {
                        $set = New-Object System.Collections.Generic.HashSet[string]
                        for ($rr=9; $rr -lt $csvLines.Count; $rr++) {
                            $ln = $csvLines[$rr]
                            if (-not $ln -or -not $ln.Trim()) { continue }
                            $f = ConvertTo-CsvFields $ln
                            if ($f.Count -gt $idx) {
                                $v = ($f[$idx] + '').Trim().Trim('\"')
                                if ($v) { $null = $set.Add($v) }
                            }
                        }

                        # HashSet[T]-enumerering (PS 5.1-säker)
                        $csvInstrumentSerials = @($set | Sort-Object)
                    }
                }
            } catch {
                Gui-Log ("⚠️ Kunde inte extrahera Instrument S/N från CSV: " + $_.Exception.Message) 'Warn'
                $csvInstrumentSerials = @()
            }
        }

        if (-not $csvStats) {
            $csvStats = [pscustomobject]@{
                TestCount    = 0
                DupCount     = 0
                Duplicates   = @()
                LspValues    = @()
                LspOK        = $null
                InstrumentByType = [ordered]@{}
            }
        }

        # Statistik för Resample-CSV
        $csvStatsRes = $null
        if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
            try {
                $csvLinesRes = $script:CsvLinesResample
                $csvStatsRes = Get-CsvStats -Path $selCsvRes -Lines $csvLinesRes
            } catch { Gui-Log ("⚠️ Resample Get-CsvStats: " + $_.Exception.Message) 'Warn' }
        }

        $infSN = @()
        if ($script:GXINF_Map) {
            foreach ($k in $script:GXINF_Map.Keys) {
                if ($k -like 'Infinity-*') {
                    $infSN += ($script:GXINF_Map[$k].Split(',') | ForEach-Object { ($_ + '').Trim() } | Where-Object { $_ })
                }
            }
        }
        $infSN = $infSN | Select-Object -Unique

        $infSummary = '—'
        try {
            if ($selCsv -and (Test-Path -LiteralPath $selCsv) -and $infSN.Count -gt 0) {
                $infSummary = Get-InfinitySpFromCsvStrict -Path $selCsv -InfinitySerials $infSN -Lines $csvLines
            }
        } catch {
            Gui-Log ("Infinity SP fel: " + $_.Exception.Message) 'Warn'
        }

        # --- Dubbletter Sample ID ---
        $dupSampleCount = 0
        $dupSampleList  = @()
        if ($csvLines -and $csvLines.Count -gt 8) {
            try {
                $headerFields = ConvertTo-CsvFields $csvLines[7]
                $sampleIdx = -1
                for ($i=0; $i -lt $headerFields.Count; $i++) {
                    $hf = ($headerFields[$i] + '').Trim().ToLower()
                    if ($hf -match 'sample') { $sampleIdx = $i; break }
                }
                if ($sampleIdx -ge 0) {
                    $samples = @()
                    for ($r=9; $r -lt $csvLines.Count; $r++) {
                        $line = $csvLines[$r]
                        if (-not $line -or -not $line.Trim()) { continue }
                        $fields = ConvertTo-CsvFields $line
                        if ($fields.Count -gt $sampleIdx) {
                            $val = ($fields[$sampleIdx] + '').Trim()
                            if ($val) { $samples += $val }
                        }
                    }
                    if ($samples.Count -gt 0) {
                        $counts = @{}
                        foreach ($s in $samples) { if (-not $counts.ContainsKey($s)) { $counts[$s] = 0 }; $counts[$s] = [int]$counts[$s] + 1 }
                        foreach ($entry in $counts.GetEnumerator()) {
                            if ($entry.Value -gt 1) { $dupSampleList += ("$($entry.Key) x$($entry.Value)") }
                        }
                        $dupSampleCount = $dupSampleList.Count
                    }
                }
            } catch {
                Gui-Log ("⚠️ Fel vid analys av Sample ID: " + $_.Exception.Message) 'Warn'
            }
        }

        $dupSampleText = if ($dupSampleCount -gt 0) {
            $show = ($dupSampleList | Select-Object -First 8) -join ', '
            "$dupSampleCount ($show)"
        } else { 'N/A' }

        $dupCartText = if ($csvStats.DupCount -gt 0) {
            $show = ($csvStats.Duplicates | Select-Object -First 8) -join ', '
            "$($csvStats.DupCount) ($show)"
        } else { 'N/A' }

        # --- LSP-summering ---
        $lspSummary = ''
        try {
            if ($csvLines -and $csvLines.Count -gt 8) {
                $counts = @{}
                for ($rr = 9; $rr -lt $csvLines.Count; $rr++) {
                    $ln = $csvLines[$rr]
                    if (-not $ln -or -not $ln.Trim()) { continue }
                    $fs = ConvertTo-CsvFields $ln
                    if ($fs.Count -gt 4) {
                        $raw = ($fs[4] + '').Trim()
                        if ($raw) {
                            $mLsp = [regex]::Match($raw,'(\d{5})')
                            $code = if ($mLsp.Success) { $mLsp.Groups[1].Value } else { $raw }
                            if (-not $counts.ContainsKey($code)) { $counts[$code] = 0 }
                            $counts[$code] = [int]$counts[$code] + 1
                        }
                    }
                }

                if ($counts.Count -gt 0) {
                    $sorted = @($counts.GetEnumerator() | Sort-Object Key)
                    $parts = @()
                    foreach ($kvp in $sorted) {
                        $parts += $(if ($kvp.Value -gt 1) { "$($kvp.Key) x$($kvp.Value)" } else { $kvp.Key })
                    }
                    if ($sorted.Count -eq 1) { $lspSummary = $sorted[0].Key }
                    else { $lspSummary = "$($sorted.Count) (" + ($parts -join ', ') + ")" }
                }
            }
        } catch {
            Gui-Log ("⚠️ Fel vid extraktion av LSP från CSV: " + $_.Exception.Message) 'Warn'
            $lspSummary = ''
        }

        $instText = if ($csvStats.InstrumentByType.Keys.Count -gt 0) {
            ($csvStats.InstrumentByType.GetEnumerator() | ForEach-Object { "$($_.Key)" } | Sort-Object) -join '; '
        } else { '' }

        function Find-InfoRow {
            param([OfficeOpenXml.ExcelWorksheet]$Ws, [string]$Label)
            if (-not $Ws -or -not $Ws.Dimension) { return $null }
            $maxRow = [Math]::Min($Ws.Dimension.End.Row, 300)
            for ($ri=1; $ri -le $maxRow; $ri++) {
                $txt = (($Ws.Cells[$ri,1].Text) + '').Trim()
                if (-not $txt) { continue }
                if ($txt.ToLowerInvariant() -eq $Label.ToLowerInvariant()) { return $ri }
            }
            return $null
        }

        # ✅ Standard: anta INTE nytt layoutläge om vi inte hittar ankaret
        $isNewLayout = $false
        try {
            $tmpRow = Find-InfoRow -Ws $wsInfo -Label 'CSV-Info'
            if ($tmpRow) { $isNewLayout = $true }
        } catch {}

        $rowCsvFile    = Find-InfoRow -Ws $wsInfo -Label 'CSV'
        $rowLsp        = Find-InfoRow -Ws $wsInfo -Label 'LSP'
        $rowBag        = Find-InfoRow -Ws $wsInfo -Label 'Infinity bags'
        if (-not $rowBag) { $rowBag = Find-InfoRow -Ws $wsInfo -Label 'Bag Numbers Tested Using Infinity' }
        if (-not $rowBag) { $rowBag = Find-InfoRow -Ws $wsInfo -Label 'Bag Numbers Tested Using Infinity:' }
        if (-not $rowBag) { $rowBag = 11 }
        $rowAntal      = Find-InfoRow -Ws $wsInfo -Label 'Antal tester'
        if (-not $rowDupSample) { $rowDupSample = Find-InfoRow -Ws $wsInfo -Label 'Dublett Sample ID' }

        $wsInfo.Cells["B$rowBag"].Style.Numberformat.Format = '@'
        $wsInfo.Cells["B$rowBag"].Value = $infSummary

        if ($isNewLayout) {
            if (-not $rowCsvFile)   { $rowCsvFile   = 8 }
            if (-not $rowLsp)       { $rowLsp       = 9 }
            if (-not $rowBag)       { $rowBag       = 10 }
            if (-not $rowAntal)     { $rowAntal     = 11 }
        }

        if ($selCsv -or $selCsvRes) {
            $wsInfo.Cells["B$rowCsvFile"].Style.Numberformat.Format = '@'
            $csvLabel = ''
            if ($selCsv -and $selCsvRes) {
                $csvLabel = "Primary: {0} | Resampling: {1}" -f (Get-CleanLeaf $selCsv), (Get-CleanLeaf $selCsvRes)
            } elseif ($selCsv) {
                $csvLabel = (Get-CleanLeaf $selCsv)
            } else {
                $csvLabel = "Resampling: {0}" -f (Get-CleanLeaf $selCsvRes)
            }
            $wsInfo.Cells["B$rowCsvFile"].Value = $csvLabel
        } else {
            $wsInfo.Cells["B$rowCsvFile"].Value = ''
        }

        $wsInfo.Cells["B$rowLsp"].Style.Numberformat.Format = '@'
        $wsInfo.Cells["B$rowLsp"].Value = $(if ($lspSummary) { $lspSummary } else { $lsp })

        # ✅ Skriv Antal tester EN gång (som text för att inte bli 1.00E+3 etc)
        $wsInfo.Cells["B$rowAntal"].Style.Numberformat.Format = '@'
        $totalTests = [int]$csvStats.TestCount
        $antalText = "$totalTests"
        if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) {
            $totalTests += [int]$csvStatsRes.TestCount
            $antalText = "$totalTests ($($csvStats.TestCount) + $($csvStatsRes.TestCount) Resample)"
        }
        $wsInfo.Cells["B$rowAntal"].Value = $antalText

        try { $wsInfo.Cells['B:B'].Style.WrapText = $false } catch {}

    } catch {
        Gui-Log ("⚠️ CSV data-fel: " + $_.Exception.Message) 'Warn'
    }

    # --- Makro / dokumentinfo ---
    $assayForMacro = ''
    if ($runAssay) { $assayForMacro = $runAssay }
    elseif ($wsOut1) { $assayForMacro = Get-CellText $wsOut1 $Layout.AssayNameCell }

    $miniVal = ''
    if (Get-Command Get-MinitabMacro -ErrorAction SilentlyContinue) {
        $miniVal = Get-MinitabMacro -AssayName $assayForMacro
    }
    if (-not $miniVal) { $miniVal = 'N/A' }

    $hdNeg = $null; $hdPos = $null
    try { $hdNeg = Get-SealHeaderDocInfo -Pkg $pkgNeg } catch {}
    try { $hdPos = Get-SealHeaderDocInfo -Pkg $pkgPos } catch {}
    if (-not $hdNeg) { $hdNeg = [pscustomobject]@{ Raw=''; DocNo=''; Rev='' } }
    if (-not $hdPos) { $hdPos = [pscustomobject]@{ Raw=''; DocNo=''; Rev='' } }

    $wsInfo.Cells['B2'].Value = $ScriptVersion
    $wsInfo.Cells['B3'].Value = $env:USERNAME
    $wsInfo.Cells['B4'].Value = (Get-Date).ToString('yyyy-MM-dd HH:mm')
    $wsInfo.Cells['B5'].Value = $miniVal

    # --- Batch + länkar ---
    $selLsp = $null
    try {
        if (Get-Variable -Name clbLsp -ErrorAction SilentlyContinue) {
            $selLsp = Get-CheckedFilePath $clbLsp
        }
    } catch {}

    # Snapshot även för Worksheet (om vald) – läsning sker från kopian
    if ($enableStaging -and $stageDir -and $selLsp -and (Test-Path -LiteralPath $selLsp)) {
        try {
            $selLspOrig = $selLsp
            $selLsp = Stage-InputFileSnapshot -Path $selLsp -StageDir $stageDir -Prefix 'Worksheet'
        } catch {}
    }
$batchInfo = Get-BatchLinkInfo -SealPosPath $selPos -SealNegPath $selNeg -Lsp $lspForLinks
$batch     = $batchInfo.Batch
$spOrder   = $batchInfo.Order
$wsInfo.Cells['A31'].Value = 'Öppna SharePoint-post'
$wsInfo.Cells['A31'].Style.Font.Bold = $true
Add-Hyperlink -Cell $wsInfo.Cells['B31'] -Text $batchInfo.LinkText -Url $batchInfo.Url

try {
    if ($batchInfo.OrderStatus -eq 'Mismatch') {
        Gui-Log ("⚠️ Seal Test Order# mismatch mellan aktiva blad: " + (($batchInfo.OrderInfo.AllOrders | Sort-Object) -join ', ')) 'Warn'
    }
    elseif ($batchInfo.OrderStatus -ne 'Unique') {
        Gui-Log "⚠️ Entydigt Order# kunde inte läsas från Seal Test. SharePoint-sökning litar inte på Batch/LSP." 'Warn'
    }
} catch {}

    $linkMap = [ordered]@{
        'IPT App'      = 'https://apps.powerapps.com/play/e/default-771c9c47-7f24-44dc-958e-34f8713a8394/a/fd340dbd-bbbf-470b-b043-d2af4cb62c83'
        'MES Login'    = 'http://mes.cepheid.pri/camstarportal/?domain=CEPHEID.COM'
        'CSV Uploader' = 'http://auw2wgxtpap01.cepaws.com/Welcome.aspx'
        'BMRAM'        = 'https://cepheid62468.coolbluecloud.com/'
        'Agile'        = 'https://agileprod.cepheid.com/Agile/default/login-cms.jsp'
    }

    $rowLink = 32
    foreach ($key in $linkMap.Keys) {
        $wsInfo.Cells["A$rowLink"].Value = $key
        Add-Hyperlink -Cell $wsInfo.Cells["B$rowLink"] -Text 'LÄNK' -Url $linkMap[$key]
        $rowLink++
    }

} catch {
    Gui-Log ("⚠️ Run Information fel: " + $_.Exception.Message) 'Warn'
}
                        
# ----------------------------------------------------------------
# WS (LSP-blad): hitta fil och skriv in i Information-bladet
# ----------------------------------------------------------------
try {
    if (-not $selLsp) {
        $probeDir = $null
        if ($selPos) { $probeDir = Split-Path -Parent $selPos }
        if (-not $probeDir -and $selNeg) { $probeDir = Split-Path -Parent $selNeg }

        if ($probeDir -and (Test-Path -LiteralPath $probeDir)) {
            $cand = Get-ChildItem -LiteralPath $probeDir -File -ErrorAction SilentlyContinue |
                    Where-Object {
                        ($_.Name -match '(?i)worksheet') -and
                        ($_.Name -match [regex]::Escape($lsp)) -and
                        ($_.Extension -match '^\.(xlsx|xlsm|xls)$')
                    } |
                    Sort-Object LastWriteTime -Descending |
                    Select-Object -First 1

            if ($cand) { $selLsp = $cand.FullName }
        }
    }

    if (-not (Get-Command Find-LabelValueRightward -ErrorAction SilentlyContinue)) {
        function Find-LabelValueRightward {
            param(
                [OfficeOpenXml.ExcelWorksheet]$Ws,
                [string]$Label,
                [int]$MaxRows = 200,
                [int]$MaxCols = 40
            )
            if (-not $Ws -or -not $Ws.Dimension) { return $null }

            $normLbl = Normalize-HeaderText $Label
            $pat = '^(?i)\s*' + [regex]::Escape($normLbl).Replace('\ ', '\s*') + '\s*[:\.]*\s*$'
            $rx  = [regex]::new($pat, [Text.RegularExpressions.RegexOptions]::IgnoreCase)

            $hit = Find-RegexCell -Ws $Ws -Rx $rx -MaxRows $MaxRows -MaxCols $MaxCols
            if (-not $hit) { return $null }

            $cMax = [Math]::Min($Ws.Dimension.End.Column, $MaxCols)
            for ($c = $hit.Col + 1; $c -le $cMax; $c++) {
                $t = Normalize-HeaderText ($Ws.Cells[$hit.Row,$c].Text + '')
                if ($t) { return $t }
            }
            return $null
        }
    }

    if ($selLsp -and (Test-Path -LiteralPath $selLsp)) {
        $wsLeaf = Get-CleanLeaf $selLsp
        Gui-Log ("🔎 Worksheet: " + $wsLeaf) 'Info'
    } else {
        Gui-Log "ℹ️ Ingen WS-fil vald/hittad (LSP Worksheet). Hoppar över WS-extraktion." 'Info'
    }
} catch {
    Gui-Log ("⚠️ WS-block fel: " + $_.Exception.Message) 'Warn'
}

try {
    # Se till att dessa alltid finns (de används senare)
    $headerWs  = $null
    $headerNeg = $null
    $headerPos = $null
    # OBS: $eqInfo används senare vid Equipment-blad → initiera här
    if (-not (Get-Variable -Name eqInfo -Scope 1 -ErrorAction SilentlyContinue)) {
        $eqInfo = $null
    }

    # --- Återanvänd WS-paketet från Data Summary-skanning om möjligt ---
    $tmpPkg = $null
    $tmpPkgReused = $false
    try {
        if ($selLsp -and (Test-Path -LiteralPath $selLsp)) {
            try {
                if ($script:WsPkg -and $script:WsPkg.File -and
                    $script:WsPkg.File.FullName -ieq (Resolve-Path -LiteralPath $selLsp -ErrorAction SilentlyContinue).Path) {
                    $tmpPkg = $script:WsPkg
                    $tmpPkgReused = $true
                } else {
                    # Sökväg ändrades (borde inte hända), öppna ny
                    if ($script:WsPkg) { try { $script:WsPkg.Dispose() } catch {} }
                    $script:WsPkg = $null
                    $tmpPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($selLsp))
                }

                # ==============================
                # Utrustning / TestSummary
                # ==============================
                try {
                    # "EquipmentSheet" ska endast generera själva BLADET/mallen.
                    # Det ska *inte* automatiskt hämta pipetter/instrument från Test Summary/CSV här,
                    # annars blir det en blandning (automatiskt + manuellt) som förvirrar användaren.
                    if ($Config -and $Config.Contains('EnableEquipmentSheet') -and -not $Config.EnableEquipmentSheet) {
                        $eqInfo = $null
                        Gui-Log 'ℹ️ Utrustningslista avstängt. Hoppar över.' 'Info'
                    } else {
                        $eqInfo = $null
                        Gui-Log '✅ Utrustningslista hämtad.' 'Info' 'PROGRESS'
                    }
                } catch {
                    # Utrustning ska aldrig få stoppa rapporten
                    try { Gui-Log ("⚠️ Utrustningslista: kunde inte hämtas: " + $_.Exception.Message) 'Warn' } catch {}
                    $eqInfo = $null
                }

                # ==============================
                # Bladrubrik (extrahera + jämför)
                # ==============================
                try {
                    $headerWs = Extract-WorksheetHeader -Pkg $tmpPkg
                } catch {
                    $headerWs = $null
                }

                # Reservväg om extrahering gav null: skapa tomt objekt så .PartNo osv inte kraschar
                if (-not $headerWs) {
                    $headerWs = [pscustomobject]@{
                        WorksheetName   = ''
                        PartNo          = ''
                        BatchNo         = ''
                        CartridgeNo     = ''
                        DocumentNumber  = ''
                        Rev             = ''
                        Effective       = ''
                        Attachment      = ''
                    }
                }

                # StrictMode-säker: används senare även om jämförelsen misslyckas
                $wsHeaderCheck = $null
try {
    # QC Data ska bara ingå i headerkontrollen när Additional QC Data faktiskt förväntas.
    # Samma grundlogik som QC-påminnelsen: assay + Test Summary!B3.
    $qcDataHeaderExpected = $false
    $qcDataHeaderB3       = $null
    $qcDataSheetExists    = $false
    try {
        $qcDataSheetExists = @(
            $tmpPkg.Workbook.Worksheets |
            Where-Object { ($_.Name + '') -match '(?i)^\s*QC\s+Data\s*$' }
        ).Count -gt 0
        $qcTriggerAssays = @(
            'Xpert_HIV-1 Viral Load',
            'Xpert HIV-1 Viral Load XC',
            'Xpert_HCV Viral Load',
            'Xpert HCV VL Fingerstick',
            'Xpert HBV Viral Load',
            'Xpert_HIV-1 Qual',
            'HIV-1_Qual RUO',
            'HIV-1 Qual XC DBS RUO',
            'HIV-1 Qual XC DBS IUO',
            'Xpert HIV-1 Qual XC PQC',
            'Xpert HIV-1 Qual XC PQC RUO'
        )
        $qcValidPartNos = @(
            'GXHIV-VL-CE-10',
            'GXHIV-VL-IN-10',
            'GXHIV-VL-CN-10',
            'GXHIV-VL-XC-CE-10',
            'GXHCV-VL-CE-10',
            'GXHCV-VL-IN-10',
            'GXHCV-FS-CE-10',
            'GXHBV-VL-CE-10',
            'GXHIV-QA-CE-10',
            'RHIVQ-10',
            '700-6098/HIV-1 QUAL XC, RUO',
            '700-6137/HIV-1 QUAL XC, IUO',
            '700-6793/ HIV-1 QUAL XC, CE-IVD',
            '700-6911/ HIV-1 QUAL XC, RUO'
        )

        $qcAssayMatch = $false
        if ($runAssay) {
            foreach ($_qa in $qcTriggerAssays) {
                if ($runAssay -ilike "$_qa*") {
                    $qcAssayMatch = $true
                    break
                }
            }
        }
        if ($qcAssayMatch) {
            $tsWs = $tmpPkg.Workbook.Worksheets |
                Where-Object { $_.Name -ieq 'Test Summary' } |
                Select-Object -First 1
            if ($tsWs) {
                $qcDataHeaderB3 = Get-CellText $tsWs 'B3'
                if ($qcDataHeaderB3 -and ($qcValidPartNos -contains $qcDataHeaderB3)) {
                    $qcDataHeaderExpected = $true
                }
            }
        }
    } catch {
        try { Gui-Log ("⚠️ QC Data header-gate: " + $_.Exception.Message) 'Warn' } catch {}
    }

    $wsHeaderRows  = Get-WorksheetHeaderPerSheet -Pkg $tmpPkg -IncludeQcData:$qcDataHeaderExpected
    $wsHeaderCheck = Compare-WorksheetHeaderSet   -Rows $wsHeaderRows

    try {
        if ($qcDataHeaderExpected) {
            if ($qcDataSheetExists) {
                $qcDataChecked = @(
                    $wsHeaderRows |
                    Where-Object { ($_.Sheet + '') -match '(?i)^\s*QC\s+Data\s*$' }
                ).Count -gt 0

                if ($qcDataChecked) {
                    Gui-Log ("✅ Worksheet header-kontroll inkluderar QC Data ({0})" -f $qcDataHeaderB3) 'Info'
                }
                else {
                    Gui-Log ("⚠️ Additional QC Data förväntas ({0}), men QC Data ingick inte i headerkontrollen" -f $qcDataHeaderB3) 'Warn'
                }
            }
            else {
                Gui-Log ("⚠️ Additional QC Data förväntas ({0}), men QC Data-flik saknas i Worksheet" -f $qcDataHeaderB3) 'Warn'
            }
        }
        elseif ($qcDataSheetExists) {
            Gui-Log "ℹ️ QC Data-flik finns, men Additional QC Data förväntas inte enligt Test Summary B3. QC Data exkluderas från headerkontroll." 'Info'
        }
    } catch {}
    try {
        if ($wsHeaderCheck.Issues -gt 0 -and $wsHeaderCheck.Summary) {
            Gui-Log ("⚠️ Worksheet header-avvikelser: {0} – se Run Information!" -f $wsHeaderCheck.Summary) 'Warn'
        } else {
            Gui-Log "✅ Worksheet header korrekt" 'Info' 'PROGRESS'
        }
    } catch {}
} catch {
    try { Gui-Log ("⚠️ Worksheet header-jämförelse: " + $_.Exception.Message) 'Warn' } catch {}
}

                # ==============================
                # Förstärk headerWs via etiketter (om extrahering missade)
                # ==============================
                try {
                    $wsLsp = $tmpPkg.Workbook.Worksheets | Where-Object {
                        $_.Name -ne 'Worksheet Instructions' -and
                        $_.Name -notmatch '(?i)^\s*QC\s+Data\s*$'
                    } | Select-Object -First 1
                    if (-not $wsLsp) {
                        $wsLsp = $tmpPkg.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' } | Select-Object -First 1
                    }
                    if ($wsLsp) {

                        if (-not $headerWs.PartNo) {
                            $val = $null
                            $labels = @('Part No.','Part No.:','Part No','Part Number','Part Number:','Part Number.','Part Number.:')
                            foreach ($lbl in $labels) { $val = Find-LabelValueRightward -Ws $wsLsp -Label $lbl; if ($val) { break } }
                            if ($val) { $headerWs.PartNo = $val }
                        }

                        if (-not $headerWs.BatchNo) {
                            $val = $null
                            $labels = @(
                                'Batch No(s)','Batch No(s).','Batch No(s):','Batch No(s).:',
                                'Batch No','Batch No.','Batch No:','Batch No.:',
                                'Batch Number','Batch Number.','Batch Number:','Batch Number.:'
                            )
                            foreach ($lbl in $labels) { $val = Find-LabelValueRightward -Ws $wsLsp -Label $lbl; if ($val) { break } }
                            if ($val) { $headerWs.BatchNo = $val }
                        }

                        if (-not $headerWs.CartridgeNo -or $headerWs.CartridgeNo -eq '.') {
                            $val = $null
                            $labels = @(
                                'Cartridge No. (LSP)','Cartridge No. (LSP):','Cartridge No. (LSP) :',
                                'Cartridge No (LSP)','Cartridge No (LSP):','Cartridge No (LSP) :',
                                'Cartridge Number (LSP)','Cartridge Number (LSP):','Cartridge Number (LSP) :',
                                'Cartridge No.','Cartridge No.:','Cartridge No. :','Cartridge No :',
                                'Cartridge Number','Cartridge Number:','Cartridge Number :',
                                'Cartridge No','Cartridge No:','Cartridge No :'
                            )
                            foreach ($lbl in $labels) { $val = Find-LabelValueRightward -Ws $wsLsp -Label $lbl; if ($val) { break } }

                            if (-not $val) {
                                $rxCart = [regex]::new('(?i)Cartridge.*\(LSP\)')
                                $maxCols = [Math]::Min($wsLsp.Dimension.End.Column, 100)
                                $hitCart = Find-RegexCell -Ws $wsLsp -Rx $rxCart -MaxRows 200 -MaxCols $maxCols
                                if ($hitCart) {
                                    for ($c = $hitCart.Col + 1; $c -le $wsLsp.Dimension.End.Column; $c++) {
                                        $cellVal = ($wsLsp.Cells[$hitCart.Row, $c].Text + '').Trim()
                                        if (-not $cellVal) { continue }

                                        $mCart = [regex]::Match($cellVal, '(?<![A-Za-z0-9])(\d{5})(?!\d)')
                                        if ($mCart.Success) {
                                            $val = $mCart.Groups[1].Value
                                            break
                                        }
                                    }
                                }
                            }

                            if ($val) {
                                $mCart = [regex]::Match(($val + ''), '(?<![A-Za-z0-9])(\d{5})(?!\d)')
                                if ($mCart.Success) {
                                    $headerWs.CartridgeNo = $mCart.Groups[1].Value
                                }
                            }
                        }

                        if (-not $headerWs.Effective) {
                            $val = Find-LabelValueRightward -Ws $wsLsp -Label 'Effective'
                            if (-not $val) { $val = Find-LabelValueRightward -Ws $wsLsp -Label 'Effective Date' }
                            if ($val) { $headerWs.Effective = $val }
                        }
                    }
                } catch {}

                # Ingen filnamnsfallback för Worksheet CartridgeNo.
                # Worksheet-header ska spegla faktisk header/cell-data, inte filnamn.

                # ==============================
                # QC-påminnelse – HIV/HBV/HCV-assays (läser Test Summary B3 medan $tmpPkg är öppen)
                # ==============================
                $script:QcReminderB3 = $null
                try {
                    $qcTriggerAssays = @(
                        'Xpert_HIV-1 Viral Load',
                        'Xpert HIV-1 Viral Load XC',
                        'Xpert_HCV Viral Load',
                        'Xpert HCV VL Fingerstick',
                        'Xpert HBV Viral Load',
                        'Xpert_HIV-1 Qual',
                        'HIV-1_Qual RUO',
                        'HIV-1 Qual XC DBS RUO',
                        'HIV-1 Qual XC DBS IUO',
                        'Xpert HIV-1 Qual XC PQC',
                        'Xpert HIV-1 Qual XC PQC RUO'


                    )
                    $qcValidPartNos = @(
                        'GXHIV-VL-CE-10','GXHIV-VL-IN-10','GXHIV-VL-CN-10',
                        'GXHIV-VL-XC-CE-10','GXHCV-VL-CE-10','GXHCV-VL-IN-10',
                        'GXHCV-FS-CE-10','GXHBV-VL-CE-10',
                        'GXHIV-QA-CE-10','RHIVQ-10'
                        '700-6098/HIV-1 QUAL XC, RUO','700-6137/HIV-1 QUAL XC, IUO',
                        '700-6793/ HIV-1 QUAL XC, CE-IVD','700-6911/ HIV-1 QUAL XC, RUO'
                    )

                    $qcAssayMatch = $false
                    if ($runAssay) {
                        foreach ($_qa in $qcTriggerAssays) {
                            if ($runAssay -ilike "$_qa*") { $qcAssayMatch = $true; break }
                        }
                    }

                    if ($qcAssayMatch) {
                        $tsWs = $tmpPkg.Workbook.Worksheets | Where-Object { $_.Name -ieq 'Test Summary' } | Select-Object -First 1
                        if ($tsWs) {
                            $b3Val = Get-CellText $tsWs 'B3'
                            if ($b3Val -and ($qcValidPartNos -contains $b3Val)) {
                                $script:QcReminderB3 = $b3Val
                                Gui-Log ("🔬 QC Data Påminnelse: Assay={0}, Part/Cat. No. {1} → aktiverad" -f $runAssay, $b3Val) 'Info'
                            } else {
                                Gui-Log ("ℹ️ QC Data: Assay matchar men Part/Cat. No. '{0}' ej i listan → hoppar över." -f $b3Val) 'Info'
                            }
                        } else {
                            Gui-Log "ℹ️ QC Data: Assay matchar men 'Test Summary'-blad saknas i Worksheet." 'Info'
                        }
                    }
                } catch {
                    Gui-Log ("⚠️ QC Data Påminnelse: " + $_.Exception.Message) 'Warn'
                }

            } catch {
                # Om WS öppnas men något inne fallerar: låt det inte döda hela rapporten
                Gui-Log ("⚠️ WS-fel: " + $_.Exception.Message) 'Warn'
            }
        }
    } finally {
        # Frigör WS-paketet (nollställ $script:WsPkg oavsett om det återanvändes)
        if ($tmpPkg) { try { $tmpPkg.Dispose() } catch {} }
        $script:WsPkg = $null
        $tmpPkg = $null
    }

    # SealTest-rubriker
    try { $headerNeg = Extract-SealTestHeader -Pkg $pkgNeg } catch {}
    try { $headerPos = Extract-SealTestHeader -Pkg $pkgPos } catch {}

    # Reserv för Effective i Seal POS/NEG om fält saknas
    try {
        if ($pkgPos -and $headerPos -and -not $headerPos.Effective) {
            $wsPos = $pkgPos.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' } | Select-Object -First 1
            if ($wsPos) {
                $val = Find-LabelValueRightward -Ws $wsPos -Label 'Effective'
                if (-not $val) { $val = Find-LabelValueRightward -Ws $wsPos -Label 'Effective Date' }
                if ($val) { $headerPos.Effective = $val }
            }
        }
    } catch {}

    try {
        if ($pkgNeg -and $headerNeg -and -not $headerNeg.Effective) {
            $wsNeg = $pkgNeg.Workbook.Worksheets | Where-Object { $_.Name -ne 'Worksheet Instructions' } | Select-Object -First 1
            if ($wsNeg) {
                $val = Find-LabelValueRightward -Ws $wsNeg -Label 'Effective'
                if (-not $val) { $val = Find-LabelValueRightward -Ws $wsNeg -Label 'Effective Date' }
                if ($val) { $headerNeg.Effective = $val }
            }
        }
    } catch {}

    # --------------------------
    # Rubriksammanfattning → Information
    # --------------------------
    try {
        $wsBatch   = if ($headerWs -and $headerWs.BatchNo) { $headerWs.BatchNo } else { $null }
        $sealBatch = $batch
        if (-not $sealBatch) {
            try { if ($selPos) { $sealBatch = Get-BatchNumberFromSealFile $selPos } } catch {}
            if (-not $sealBatch) { try { if ($selNeg) { $sealBatch = Get-BatchNumberFromSealFile $selNeg } } catch {} }
        }

        $rowWsFile = Find-InfoRow -Ws $wsInfo -Label 'Worksheet'
        if (-not $rowWsFile) { $rowWsFile = 17 }
        $rowPart  = $rowWsFile + 1
        $rowBatch = $rowWsFile + 2
        $rowCart  = $rowWsFile + 3
        $rowDoc   = $rowWsFile + 4
        $rowRev   = $rowWsFile + 5
        $rowEff   = $rowWsFile + 6

        $rowPosFile = Find-InfoRow -Ws $wsInfo -Label 'Seal Test POS'
        if (-not $rowPosFile) { $rowPosFile = $rowWsFile + 7 }
        $rowPosDoc = $rowPosFile + 1
        $rowPosRev = $rowPosFile + 2
        $rowPosEff = $rowPosFile + 3

        $rowNegFile = Find-InfoRow -Ws $wsInfo -Label 'Seal Test NEG'
        if (-not $rowNegFile) { $rowNegFile = $rowPosFile + 4 }
        $rowNegDoc = $rowNegFile + 1
        $rowNegRev = $rowNegFile + 2
        $rowNegEff = $rowNegFile + 3

        if ($selLsp) {
            $wsInfo.Cells["B$rowWsFile"].Style.Numberformat.Format = '@'
            $wsInfo.Cells["B$rowWsFile"].Value = (Get-CleanLeaf $selLsp)
        } else {
            $wsInfo.Cells["B$rowWsFile"].Value = ''
        }

        $consPart  = Get-ConsensusValue -Type 'Part'      -Ws $headerWs.PartNo      -Pos $headerPos.PartNumber   -Neg $headerNeg.PartNumber
        $consBatch = Get-ConsensusValue -Type 'Batch'     -Ws $headerWs.BatchNo     -Pos $headerPos.BatchNumber  -Neg $headerNeg.BatchNumber
        $consCart  = Get-ConsensusValue -Type 'Cartridge' -Ws $headerWs.CartridgeNo -Pos $headerPos.CartridgeNo  -Neg $headerNeg.CartridgeNo
        # Ingen filnamnsfallback för Cartridge i Run Information.
        # Visat Worksheet-värde ska komma från faktisk header/cell-data.
$wsInfo.Cells["B$rowPart"].Value = if ($consPart.Value) { $consPart.Value } else { '' }
$runBatchDisplay = ''
try {
    $runBatchTokens = @(Get-BatchTokenList -Values @(
        $headerWs.BatchNo,
        $headerPos.BatchNumber,
        $headerNeg.BatchNumber,
        $batchInfo.Batch
    ))
    if ($runBatchTokens.Count -gt 0) {
        $runBatchDisplay = Join-TokenList $runBatchTokens
    }
} catch {}

if (-not $runBatchDisplay -and $consBatch.Value) {
    $runBatchDisplay = $consBatch.Value
}

$wsInfo.Cells["B$rowBatch"].Style.Numberformat.Format = '@'
$wsInfo.Cells["B$rowBatch"].Value = $runBatchDisplay
$wsInfo.Cells["B$rowCart"].Value = if ($consCart.Value) { $consCart.Value } else { '' }

        # wsHeaderCheck → skriv Match/Mismatch i C-kolumn för Part/Batch/Cartridge
        try {
            $StyleMismatchCell = {
                param($Cell, $Text)
                $Cell.Style.Numberformat.Format = '@'
                $Cell.Value = '⚠ ' + $Text
                $Cell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $Cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#FFCCCC'))
                $Cell.Style.Font.Bold = $true
                $Cell.Style.Font.Color.SetColor([System.Drawing.Color]::DarkRed)
            }

            $StyleMatchCell = {
                param($Cell)
                $Cell.Style.Numberformat.Format = '@'
                $Cell.Value = '✓ Alla flikar matchar'
                $Cell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $Cell.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#C6EFCE'))
                $Cell.Style.Font.Bold = $true
                $Cell.Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml('#006100'))
            }

            $devPart = $null;  $devBatch = $null;  $devCart = $null
            $missPart = $null; $missBatch = $null; $missCart = $null

            if ($wsHeaderCheck -and $wsHeaderCheck.Details) {
                $linesDev = ($wsHeaderCheck.Details -split "`r?`n")
                foreach ($ln in $linesDev) {
                    if ($ln -match '^\*Saknas\*\s*-\s*PartNo\b\s*(.*)$') {
                        $missPart = ($matches[1] + '').Trim()
                    }
                    elseif ($ln -match '^\*Saknas\*\s*-\s*BatchNo\b\s*(.*)$') {
                        $missBatch = ($matches[1] + '').Trim()
                    }
                    elseif ($ln -match '^\*Saknas\*\s*-\s*CartridgeNo\b\s*(.*)$') {
                        $missCart = ($matches[1] + '').Trim()
                    }
                    elseif ($ln -match '^-\s*PartNo[^:]*:\s*(.+)$') {
                        $devPart = $matches[1].Trim()
                    }
                    elseif ($ln -match '^-\s*BatchNo[^:]*:\s*(.+)$') {
                        $devBatch = $matches[1].Trim()
                    }
                    elseif ($ln -match '^-\s*CartridgeNo[^:]*:\s*(.+)$') {
                        $devCart = $matches[1].Trim()
                    }
                }
            }

            if ($wsHeaderCheck) {
                if ($missPart -ne $null) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowPart"]  ($(if ($missPart) { 'Header saknas: ' + $missPart } else { 'Header saknas' }))
                }
                elseif ($devPart) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowPart"]  ('Avvikande: ' + $devPart)
                }
                elseif (-not $consPart.Value) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowPart"]  'Header saknas'
                }
                else {
                    & $StyleMatchCell $wsInfo.Cells["C$rowPart"]
                }

                if ($missBatch -ne $null) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowBatch"] ($(if ($missBatch) { 'Header saknas: ' + $missBatch } else { 'Header saknas' }))
                }
                elseif ($devBatch) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowBatch"] ('Avvikande: ' + $devBatch)
                }
                elseif (-not $consBatch.Value) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowBatch"] 'Header saknas'
                }
                else {
                    & $StyleMatchCell $wsInfo.Cells["C$rowBatch"]
                }

                if ($missCart -ne $null) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowCart"]  ($(if ($missCart) { 'Header saknas: ' + $missCart } else { 'Header saknas' }))
                }
                elseif ($devCart) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowCart"]  ('Avvikande: ' + $devCart)
                }
                elseif (-not $consCart.Value) {
                    & $StyleMismatchCell $wsInfo.Cells["C$rowCart"]  'Header saknas'
                }
                else {
                    & $StyleMatchCell $wsInfo.Cells["C$rowCart"]
                }
            }
        } catch {}

        if ($headerWs) {
            $doc = $headerWs.DocumentNumber
            if ($doc) { $doc = ($doc -replace '(?i)\s+(?:Rev(?:ision)?|Effective|p\.)\b.*$', '').Trim() }
            if ($headerWs.Attachment -and ($doc -notmatch '(?i)\bAttachment\s+\w+\b')) {
                $doc = "$doc Attachment $($headerWs.Attachment)"
            }
            $wsInfo.Cells["B$rowDoc"].Value = $doc
            $wsInfo.Cells["B$rowRev"].Value = $headerWs.Rev
            $wsInfo.Cells["B$rowEff"].Value = $headerWs.Effective
            
            if ($wsHeaderCheck -and $doc) { & $StyleMatchCell $wsInfo.Cells["C$rowDoc"] }
            if ($wsHeaderCheck -and $headerWs.Rev) { & $StyleMatchCell $wsInfo.Cells["C$rowRev"] }
            if ($wsHeaderCheck -and $headerWs.Effective) { & $StyleMatchCell $wsInfo.Cells["C$rowEff"] }
        } else {
            $wsInfo.Cells["B$rowDoc"].Value = ''
            $wsInfo.Cells["B$rowRev"].Value = ''
            $wsInfo.Cells["B$rowEff"].Value = ''
        }

        if ($selPos) {
            $wsInfo.Cells["B$rowPosFile"].Style.Numberformat.Format = '@'
            $wsInfo.Cells["B$rowPosFile"].Value = (Get-CleanLeaf $selPos)
        } else { $wsInfo.Cells["B$rowPosFile"].Value = '' }

        if ($headerPos) {
            $docPos = $headerPos.DocumentNumber
            if ($docPos) { $docPos = ($docPos -replace '(?i)\s+(?:Rev(?:ision)?|Effective|p\.)\b.*$','').Trim() }
            $wsInfo.Cells["B$rowPosDoc"].Value = $docPos
            $wsInfo.Cells["B$rowPosRev"].Value = $headerPos.Rev
            $wsInfo.Cells["B$rowPosEff"].Value = if ($headerPos.EffectiveDisplay) { $headerPos.EffectiveDisplay } else { $headerPos.Effective }

            $posHeaderCheck = $null
            try { $posHeaderCheck = $headerPos.HeaderCheck } catch {}
            $devPosDoc = $null; $devPosRev = $null; $devPosEff = $null

            if ($posHeaderCheck -and $posHeaderCheck.Details) {
                $linesDev = ($posHeaderCheck.Details -split "`r?`n")
                foreach ($ln in $linesDev) {
                    if ($ln -match '^-\s*DocumentNumber[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devPosDoc = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*Rev[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devPosRev = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*Effective[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devPosEff = $matches[1].Trim() }
                }
            }

            if ($posHeaderCheck) {
                if ($docPos) {
                    if ($devPosDoc) { & $StyleMismatchCell $wsInfo.Cells["C$rowPosDoc"] ('Avvikande flikar: ' + $devPosDoc) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowPosDoc"] }
                }
                if ($headerPos.Rev) {
                    if ($devPosRev) { & $StyleMismatchCell $wsInfo.Cells["C$rowPosRev"] ('Avvikande flikar: ' + $devPosRev) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowPosRev"] }
                }
                if ($headerPos.Effective) {
                    if ($devPosEff) { & $StyleMismatchCell $wsInfo.Cells["C$rowPosEff"] ('Avvikande flikar: ' + $devPosEff) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowPosEff"] }
                }
            } else {
            }
        } else {
            $wsInfo.Cells["B$rowPosDoc"].Value = ''
            $wsInfo.Cells["B$rowPosRev"].Value = ''
            $wsInfo.Cells["B$rowPosEff"].Value = ''
        }

        if ($selNeg) {
            $wsInfo.Cells["B$rowNegFile"].Style.Numberformat.Format = '@'
            $wsInfo.Cells["B$rowNegFile"].Value = (Get-CleanLeaf $selNeg)
        } else { $wsInfo.Cells["B$rowNegFile"].Value = '' }

        if ($headerNeg) {
            $docNeg = $headerNeg.DocumentNumber
            if ($docNeg) { $docNeg = ($docNeg -replace '(?i)\s+(?:Rev(?:ision)?|Effective|p\.)\b.*$','').Trim() }
            $wsInfo.Cells["B$rowNegDoc"].Value = $docNeg
            $wsInfo.Cells["B$rowNegRev"].Value = $headerNeg.Rev
            $wsInfo.Cells["B$rowNegEff"].Value = if ($headerNeg.EffectiveDisplay) { $headerNeg.EffectiveDisplay } else { $headerNeg.Effective }
            
            $negHeaderCheck = $null
            try { $negHeaderCheck = $headerNeg.HeaderCheck } catch {}
            $devNegDoc = $null; $devNegRev = $null; $devNegEff = $null

            if ($negHeaderCheck -and $negHeaderCheck.Details) {
                $linesDev = ($negHeaderCheck.Details -split "`r?`n")
                foreach ($ln in $linesDev) {
                    if ($ln -match '^-\s*DocumentNumber[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devNegDoc = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*Rev[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devNegRev = $matches[1].Trim() }
                    elseif ($ln -match '^-\s*Effective[^|]*\|\s*avvikande flikar:\s*(.+)$') { $devNegEff = $matches[1].Trim() }
                }
            }

            if ($negHeaderCheck) {
                if ($docNeg) {
                    if ($devNegDoc) { & $StyleMismatchCell $wsInfo.Cells["C$rowNegDoc"] ('Avvikande flikar: ' + $devNegDoc) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowNegDoc"] }
                }
                if ($headerNeg.Rev) {
                    if ($devNegRev) { & $StyleMismatchCell $wsInfo.Cells["C$rowNegRev"] ('Avvikande flikar: ' + $devNegRev) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowNegRev"] }
                }
                if ($headerNeg.Effective) {
                    if ($devNegEff) { & $StyleMismatchCell $wsInfo.Cells["C$rowNegEff"] ('Avvikande flikar: ' + $devNegEff) }
                    else { & $StyleMatchCell $wsInfo.Cells["C$rowNegEff"] }
                }
            } else {
            }
        } else {
            $wsInfo.Cells["B$rowNegDoc"].Value = ''
            $wsInfo.Cells["B$rowNegRev"].Value = ''
            $wsInfo.Cells["B$rowNegEff"].Value = ''
        }

    } catch {
        Gui-Log ("⚠️ Header summary fel: " + $_.Exception.Message) 'Warn'
    }

} catch {
    Gui-Log "⚠️ Run Information fel: $($_.Exception.Message)" 'Warn'
}

# ============================
# === Utrustningsblad      ===
# ============================
Mark-Phase 'SealTestInfo'
# OBS: Endast mall kopieras - ingen automatisk ifyllning av pipetter/instrument.
# Användaren fyller i manuellt i output-filen.
if ($Config -and $Config.Contains('EnableEquipmentSheet') -and -not $Config.EnableEquipmentSheet) {
    Gui-Log 'ℹ️ Utrustningslista avstängt. Hoppar över.' 'Info'
} else {
    try {
        if (Test-Path -LiteralPath $UtrustningListPath) {
            $srcPkg = $null
            try {
                $srcPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($UtrustningListPath))

                $srcWs = $srcPkg.Workbook.Worksheets['Sheet1']
                if (-not $srcWs) { $srcWs = $srcPkg.Workbook.Worksheets[1] }

                if ($srcWs) {
                    # Ta bort befintlig flik om den finns
                    $wsEq = $pkgOut.Workbook.Worksheets[$Layout.SheetUtrustning]
                    if ($wsEq) { $pkgOut.Workbook.Worksheets.Delete($wsEq) }

                    # Kopiera mallen som en ny flik
                    $wsEq = $pkgOut.Workbook.Worksheets.Add($Layout.SheetUtrustning, $srcWs)

                    # Ta bort formler och behåll bara värden
                    if ($wsEq.Dimension) {
                        foreach ($cell in $wsEq.Cells[$wsEq.Dimension.Address]) {
                            if ($cell.Formula -or $cell.FormulaR1C1) {
                                $val = $cell.Value
                                $cell.Formula     = $null
                                $cell.FormulaR1C1 = $null
                                $cell.Value       = $val
                            }
                        }
                        # Kopiera kolumnbredder
                        $colCount = $srcWs.Dimension.End.Column
                        for ($c = 1; $c -le $colCount; $c++) {
                            try { $wsEq.Column($c).Width = $srcWs.Column($c).Width } catch {}
                        }
                    }
                    Gui-Log "✅ Utrustningslista kopierad." 'Info' 'PROGRESS'
                }
            } finally {
                if ($srcPkg) { try { $srcPkg.Dispose() } catch {} }
            }
        } else {
            Gui-Log ("ℹ️ Utrustningslista saknas: $UtrustningListPath") 'Info'
        }
    } catch {
        Gui-Log "⚠️ Kunde inte skapa Utrustningslista-flik: $($_.Exception.Message)" 'Warn'
    }
}

# ============================
# === Kontrollmaterial     ===
# ============================
Mark-Phase 'Equipment'

try {
    if ($controlTab -and (Test-Path -LiteralPath $RawDataPath)) {
        $srcPkg = $null
        try {
            $srcPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($RawDataPath))
            try { $srcPkg.Workbook.Calculate() } catch {}

            $candidates = if ($controlTab -match '\|') {
                $controlTab -split '\|' | ForEach-Object { $_.Trim() } | Where-Object { $_ }
            } else { @($controlTab) }

            $srcWs = $null
            foreach ($cand in $candidates) {
                $srcWs = $srcPkg.Workbook.Worksheets | Where-Object { $_.Name -eq $cand } | Select-Object -First 1
                if ($srcWs) { break }
                $srcWs = $srcPkg.Workbook.Worksheets | Where-Object { $_.Name -like "*$cand*" } | Select-Object -First 1
                if ($srcWs) { break }
            }

            if ($srcWs) {
                $safeName = if ($srcWs.Name.Length -gt 31) { $srcWs.Name.Substring(0,31) } else { $srcWs.Name }
                $destName = $safeName; $n = 1
                while ($pkgOut.Workbook.Worksheets[$destName]) {
                    $base = if ($safeName.Length -gt 27) { $safeName.Substring(0,27) } else { $safeName }
                    $destName = "$base($n)"; $n++
                }

                $wsCM = $pkgOut.Workbook.Worksheets.Add($destName, $srcWs)
                if ($wsCM.Dimension) {
                    foreach ($cell in $wsCM.Cells[$wsCM.Dimension.Address]) {
                        if ($cell.Formula -or $cell.FormulaR1C1) {
                            $v = $cell.Value
                            $cell.Formula = $null
                            $cell.FormulaR1C1 = $null
                            $cell.Value = $v
                        }
                    }
                    try {
                        if (Get-Command Safe-AutoFitColumns -ErrorAction SilentlyContinue) {
                            Safe-AutoFitColumns -Ws $wsCM -Context 'ControlMaterial'
                        } else {
                            $wsCM.Cells[$wsCM.Dimension.Address].AutoFitColumns() | Out-Null
                        }
                    } catch {}
                }

                if ($srcWs.Name -ne $destName) {
                    Gui-Log "✅ Kontrollmaterial: '$($srcWs.Name)' → '$destName'" 'Info'
                if ($srcWs.Name -ne $destName) {
                    Gui-Log "✅ Kontrollmaterial: '$($srcWs.Name)' → '$destName'" 'Info'
                } else {
                    Gui-Log "✅ Kontrollmaterial: '$destName'" 'Info' 'PROGRESS'
                }
                } else {
                    Gui-Log "✅ Kontrollmaterial: '$destName'" 'Info' 'PROGRESS'
                }
            } else {
                Gui-Log "ℹ️ Hittade inget blad i kontrollfilen som matchar '$controlTab'." 'Info'
            }
        } finally {
            if ($srcPkg) { try { $srcPkg.Dispose() } catch {} }
        }
    } else {
        Gui-Log "ℹ️ Ingen Control-flik skapad (saknar mappning eller kontrollfil)." 'Info'
    }
} catch {
    Gui-Log "⚠️ Control Material-fel: $($_.Exception.Message)" 'Warn'
}

# ============================
# === SharePoint Info      ===
# ============================
try {
    $skipSpInfo = -not $global:SpEnabled

    if ($skipSpInfo) {
        Gui-Log "ℹ️ SharePoint Info avstängt i konfigurationen – hoppar över." 'Info'
        try {
            $old = $pkgOut.Workbook.Worksheets["SharePoint Info"]
            if ($old) { $pkgOut.Workbook.Worksheets.Delete($old) }
        } catch {}
    } else {

        $spOk = $false
        $spStatus = Get-SPClientStatus
        if ($spStatus.Connected) { $spOk = $true }

        if (-not $spOk) {
            # Om manuell anslutning är valt: detta är normalt tills användaren klickar "🔌 Anslut SP".
            if ($global:SpEnabled -and (-not $global:SpAutoConnect)) {
                Gui-Log "ℹ️ SharePoint ej anslutet (manuellt läge). Klicka '🔌 Anslut SP' för att hämta SharePoint-data." 'Info'
            }
            else {
                $errMsg = if ($global:SpError) { $global:SpError } else { 'Okänt fel' }
                Gui-Log ("⚠️ SharePoint ej tillgängligt: $errMsg") 'Warn'
            }
        }

$batchInfo = Get-BatchLinkInfo -SealPosPath $selPos -SealNegPath $selNeg -Lsp $lspForLinks
$batch = $batchInfo.Batch
$spOrder = $batchInfo.Order

        # Startcell för SharePoint Info-blocket i bladet 'Information' (konfigurerbart)
        $spStartCell = $null
        try { $spStartCell = Get-ConfigValue -Name 'SharePointInfoStartCell' -Default $Layout.SpInfoStartCell } catch { $spStartCell = $Layout.SpInfoStartCell }
        $spRc = Convert-A1ToRowCol -A1 $spStartCell -DefaultRow 1 -DefaultCol 5
        $spStartRow = $spRc.Row
        $spStartCol = $spRc.Col
if (-not $spOrder) {
    $orderMsg = 'Entydigt Order# saknas i Seal Test B10'
    try {
        if ($batchInfo.OrderStatus -eq 'Mismatch') {
            $orderMsg = 'Order# mismatch i aktiva Seal Test-blad: ' + (($batchInfo.OrderInfo.AllOrders | Sort-Object) -join ', ')
        }
    } catch {}
    Gui-Log ("⚠️ $orderMsg – SharePoint-post hämtas inte via Batch/LSP.") 'Warn'
    $rowsOrderWarn = @(
        [pscustomobject]@{ Rubrik = 'Status'; 'Värde' = $orderMsg },
        [pscustomobject]@{ Rubrik = 'Notering'; 'Värde' = 'SharePoint-sökning avbruten. Order# krävs som unik nyckel.' }
    )
    [void](Write-SPBlockIntoInformation -Pkg $pkgOut -Rows $rowsOrderWarn -Batch '—' -TargetSheetName $Layout.SheetRunInfo -StartRow $spStartRow -StartCol $spStartCol)

            # Säkerställ att separat flik inte finns kvar (banta rapporten)
            try {
                $old = $pkgOut.Workbook.Worksheets["SharePoint Info"]
                if ($old) { $pkgOut.Workbook.Worksheets.Delete($old) }
            } catch {}
        } else {
            Gui-Log "🔎 Order# hittad i Seal Test: $spOrder" 'Info'

            $fields = @(
                'Work_x0020_Center','Title','Batch_x0023_','SAP_x0020_Batch_x0023__x0020_2',
                'LSP','Material','BBD_x002f_SLED','Actual_x0020_startdate_x002f__x0',
                'PAL_x0020__x002d__x0020_Sample_x','Sample_x0020_Reagent_x0020_P_x00',
                'Order_x0020_quantity','Total_x0020_good','ITP_x0020_Test_x0020_results',
                'IPT_x0020__x002d__x0020_Testing_0','MES_x0020__x002d__x0020_Order_x0'
            )
            $renameMap = @{
                'Work Center'            = 'Work Center'
                'Title'                  = 'Order#'
                'Batch#'                 = 'SAP Batch#'
                'SAP Batch# 2'           = 'SAP Batch# 2'
                'LSP'                    = 'LSP'
                'Material'               = 'Material'
                'BBD/SLED'               = 'BBD/SLED'
                'Actual startdate/_x0'   = 'ROBAL - Actual start date/time'
                'PAL - Sample_x'         = 'Sample Reagent use'
                'Sample Reagent P'       = 'Sample Reagent P/N'
                'Order quantity'         = 'Order quantity'
                'Total good'             = 'ROBAL - Till Packning'
                'IPT Test results'       = 'IPT Test results'
                'IPT - Testing_0'        = 'IPT - Testing Finalized'
                'MES - Order_x0'         = 'MES Order'
            }

            $desiredOrder = @(
                'Work Center','Order#','SAP Batch#','SAP Batch# 2','LSP','Material','BBD/SLED',
                'ROBAL - Actual start date/time','Sample Reagent use','Sample Reagent P/N',
                'Order quantity','ROBAL - Till Packning','IPT Test results',
                'IPT - Testing Finalized','MES Order'
            )

            $dateFields      = @('BBD/SLED','ROBAL - Actual start date/time','IPT - Testing Finalized')
            $shortDateFields = @('BBD/SLED')

            $rows = @()
            if ($spOk) {
                try {
                    # Hela PnP-frågan + fält-extraktion körs i SPClient-runspacen
                    # (PnP ListItem-objekt kan inte serialiseras korrekt över runspace-gränser)

$spResult = Invoke-SPClient -Script {
    param($listName, $fieldNames, $orderToFind)
    try {
        function _normOrder {
            param([object]$Value)
            $s = ('' + $Value)
            $s = ($s -replace '[\u00A0\t\r\n]+', ' ')
            $s = ($s -replace '\s+', ' ').Trim()
            return $s.ToUpperInvariant()
        }
        $targetOrder = _normOrder $orderToFind
        if (-not $targetOrder) {
            return @{ Ok = $true; Found = $false; Data = @{}; Reason = 'Missing Order#' }
        }
        $items = Get-PnPListItem -List $listName -Fields $fieldNames -PageSize 2000 -ErrorAction Stop
        $matches = @(
            $items | Where-Object {
                (_normOrder $_['Title']) -eq $targetOrder
            } | Select-Object -First 2
        )
        if ($matches.Count -eq 0) {
            return @{ Ok = $true; Found = $false; Data = @{}; Reason = "No SharePoint item for Order# $targetOrder" }
        }
        if ($matches.Count -gt 1) {
            return @{ Ok = $false; Err = "Mer än en SharePoint-post matchar Order# $targetOrder. Avbryter för att undvika felträff." }
        }
        $match = $matches[0]
                            if (-not $match) {
                                return @{ Ok = $true; Found = $false; Data = @{} }
                            }

                            # Extrahera alla fält som enkel hashtable (kan serialiseras)
                            $extracted = @{}
                            foreach ($fn in $fieldNames) {
                                $val = $match[$fn]
                                if ($null -ne $val -and $val -ne '') {
                                    # Konvertera LookupValue etc. till strings
                                    if ($val -is [Microsoft.SharePoint.Client.FieldLookupValue]) {
                                        $val = $val.LookupValue
                                    }
                                    $extracted[$fn] = $val
                                }
                            }
                            return @{ Ok = $true; Found = $true; Data = $extracted }
                        } catch {
                            return @{ Ok = $false; Err = $_.Exception.ToString() }
                        }
                    } -Arguments @("Cepheid | Production orders", $fields, $spOrder)

                    if (-not $spResult -or -not $spResult.Ok) {
                        $spErrMsg = if ($spResult -and $spResult.Err) { $spResult.Err } else { 'Okänt fel' }
                        Gui-Log "⚠️ SP: Get-PnPListItem misslyckades: $spErrMsg" 'Warn'
                    }
                    elseif ($spResult.Found) {
                        foreach ($f in $fields) {
                            $val = $spResult.Data[$f]
                            if ($null -eq $val -or $val -eq '') { continue }

                            $label = $f -replace '_x0020_', ' ' `
                                         -replace '_x002d_', '-' `
                                         -replace '_x0023_', '#' `
                                         -replace '_x002f_', '/' `
                                         -replace '_x2013_', '–' `
                                         -replace '_x00',''
                            $label = $label.Trim()
                            if ($renameMap.ContainsKey($label)) { $label = $renameMap[$label] }

                            if ($val -eq $true) { $val = 'JA' }
                            elseif ($val -eq $false) { $val = 'NEJ' }
$dt = $null
if ($val -is [datetime]) { $dt = [datetime]$val }
else { try { $dt = [datetime]::Parse($val) } catch { $dt = $null } }

if ($dt -ne $null -and ($dateFields -contains $label)) {
    try {
        if ($dt.Kind -eq [System.DateTimeKind]::Utc) {
            $dt = $dt.ToLocalTime()
        }
        elseif ($dt.Kind -eq [System.DateTimeKind]::Unspecified) {
            $dt = [datetime]::SpecifyKind($dt, [System.DateTimeKind]::Utc).ToLocalTime()
        }
    } catch {}

    $fmt = if ($shortDateFields -contains $label) { 'yyyy-MM-dd' } else { 'yyyy-MM-dd HH:mm' }
    $val = $dt.ToString($fmt)
}

                            $rows += [pscustomobject]@{ Rubrik = $label; 'Värde' = $val }
                        }
if ($rows.Count -gt 0) {
    $ordered = @()
    foreach ($label in $desiredOrder) {
        $hit = $rows | Where-Object { $_.Rubrik -eq $label } | Select-Object -First 1
        if ($hit) { $ordered += $hit }
    }
    if ($ordered.Count -gt 0) { $rows = $ordered }
    try {
        $spCheck = Test-SharePointBatchLspConsistency `
            -Rows $rows `
            -HeaderWs $headerWs `
            -WorksheetHeaderRows $wsHeaderRows `
            -SealPosPath $selPos `
            -SealNegPath $selNeg `
            -SearchedLsp $lspForLinks `
            -BatchInfo $batchInfo
        if ($spCheck -and $spCheck.Status -ne 'NoRef' -and $spCheck.Message) {
            $rows += @(
                [pscustomobject]@{
                    Rubrik = 'SP Kontroll'
                    'Värde' = $(if ($spCheck.SummaryText) { $spCheck.SummaryText } else { $spCheck.Message })
                }
                [pscustomobject]@{
                    Rubrik = 'SP Order#'
                    'Värde' = $(if ($spCheck.OrderMessage) { $spCheck.OrderMessage } else { '—' })
                }
                [pscustomobject]@{
                    Rubrik = 'SP Batch#'
                    'Värde' = $(if ($spCheck.BatchMessage) { $spCheck.BatchMessage } else { '—' })
                }
                [pscustomobject]@{
                    Rubrik = 'SP LSP'
                    'Värde' = $(if ($spCheck.LspMessage) { $spCheck.LspMessage } else { '—' })
                }
            )
            if ($spCheck.Status -eq 'Mismatch') {
                Gui-Log ("⚠️ SharePoint Order/Batch/LSP mismatch: " + $spCheck.Message) 'Warn'
            }
            else {
                Gui-Log "✅ SharePoint Order/Batch/LSP matchar filer/header" 'Info'
            }
        }
    } catch {
        Gui-Log ("⚠️ SharePoint Order/Batch/LSP-kontroll misslyckades: " + $_.Exception.Message) 'Warn'
    }
    # Cache ROBAL-datum för auto-population av signeringsfält
                            $robalRow = $rows | Where-Object { $_.Rubrik -eq 'ROBAL - Actual start date/time' } | Select-Object -First 1
                            if ($robalRow -and $robalRow.'Värde') {
                                $robalVal = ($robalRow.'Värde' + '').Trim()
                                if ($robalVal -match '^\d{4}-\d{2}-\d{2}') {
                                    $script:RobalDateShort = $robalVal.Substring(0,10) -replace '-',' '
                                }
                            }
                        }

                        Gui-Log "📄 SharePoint-post hittad – skriver blad." 'Info'
} else {
    $reason = if ($spResult -and $spResult.Reason) { $spResult.Reason } else { "Ingen post i SharePoint för Order#=$spOrder" }
    Gui-Log ("ℹ️ " + $reason) 'Info'
}
                } catch {
                    Gui-Log "⚠️ SP: Invoke-SPClient misslyckades: $($_.Exception.Message)" 'Warn'
                }
            }

            [void](Write-SPBlockIntoInformation -Pkg $pkgOut -Rows $rows -Batch $batch -TargetSheetName $Layout.SheetRunInfo -StartRow $spStartRow -StartCol $spStartCol)

            try {
                $old = $pkgOut.Workbook.Worksheets["SharePoint Info"]
                if ($old) { $pkgOut.Workbook.Worksheets.Delete($old) }
            } catch {}

try {
    if ($slBatchLink -and $batchInfo -and $batchInfo.OrderStatus -eq 'Unique' -and $batchInfo.Order) {
        $slBatchLink.Text = "SharePoint: Order# $($batchInfo.Order)"
        $slBatchLink.Tag  = $batchInfo.Url
        $slBatchLink.Enabled = $true
    }
    elseif ($slBatchLink) {
        $slBatchLink.Text = 'SharePoint: —'
        $slBatchLink.Tag  = $null
        $slBatchLink.Enabled = $false
    }
} catch {}

            try {
                $wsSP = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
                if ($wsSP) {
                    $labelCol = $spStartCol
                $valueCol = $spStartCol + 1
                for ($r = ($spStartRow + 1); $r -le ($spStartRow + 120); $r++) {
                        if ((Normalize-HeaderText (($wsSP.Cells[$r,$labelCol].Text + '')).Trim()) -ieq 'Sample Reagent use') {
                            $wsSP.Cells[$r,$valueCol].Style.WrapText = $true
                            $wsSP.Cells[$r,$valueCol].Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Top
                            $wsSP.Row($r).CustomHeight = $true
                            break
                        }
                    }
                }
            } catch {
                Gui-Log "⚠️ WrapText på 'Sample Reagent use' misslyckades: $($_.Exception.Message)" 'Warn'
            }
            try {
    $wsSP = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if ($wsSP) {
        $labelCol = $spStartCol
        $valueCol = $spStartCol + 1
        for ($r = ($spStartRow + 1); $r -le ($spStartRow + 120); $r++) {
            $lbl = (Normalize-HeaderText (($wsSP.Cells[$r,$labelCol].Text + '')).Trim())
if ($lbl -in @('SP Kontroll','SP Order#','SP Batch#','SP LSP')) {
    $val = ($wsSP.Cells[$r,$valueCol].Text + '').Trim()
    # Viktigt:
    # Radhöjd gäller hela Excel-raden. Om SP-blocket sätter rad 15-18 till 30,
    # blir även vänster Dokumentkontroll-raderna 15-18 höga.
    # Därför får SP Kontroll-raderna inte tvinga upp radhöjden.
    $wsSP.Cells[$r,$labelCol].Style.WrapText = $false
    $wsSP.Cells[$r,$valueCol].Style.WrapText = $false
    $wsSP.Cells[$r,$labelCol].Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
    $wsSP.Cells[$r,$valueCol].Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
    if ($lbl -ieq 'SP Kontroll') {
                    $wsSP.Cells[$r,$labelCol].Style.Font.Bold = $true
                    $wsSP.Cells[$r,$valueCol].Style.Font.Bold = $true

                    if ($val -like '⚠*') {
                        $rngSp = $wsSP.Cells[$r,$labelCol,$r,$valueCol]
                        $rngSp.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                        $rngSp.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#FFC7CE'))
                        $rngSp.Style.Font.Color.SetColor([System.Drawing.Color]::DarkRed)
                    }
                    elseif ($val -like '✓*') {
                        $rngSp = $wsSP.Cells[$r,$labelCol,$r,$valueCol]
                        $rngSp.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                        $rngSp.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#C6EFCE'))
                        $rngSp.Style.Font.Color.SetColor([System.Drawing.ColorTranslator]::FromHtml('#006100'))
                    }
                }
                elseif ($val -like '⚠*') {
                    $rngSpWarn = $wsSP.Cells[$r,$labelCol,$r,$valueCol]
                    $rngSpWarn.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                    $rngSpWarn.Style.Fill.BackgroundColor.SetColor([System.Drawing.ColorTranslator]::FromHtml('#FFF2CC'))
                    $wsSP.Cells[$r,$valueCol].Style.Font.Color.SetColor([System.Drawing.Color]::DarkRed)
                }
            }
        }
    }
} catch {
    Gui-Log "⚠️ Styling av SP Order/Batch/LSP Kontroll misslyckades: $($_.Exception.Message)" 'Warn'
}
# ============================================================
# === Run Information: fasta radhöjder vänsterpanel        ===
# ============================================================
try {
    $wsRI = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if ($wsRI) {
        # Vanliga datarader i vänsterpanelen.
        # Dessa ska vara visuellt lika höga även om högerpanelen använder samma radnummer.
        $runInfoDataRows = @(
            2,3,4,5,        # Körningsinfo
            8,9,10,11,      # Datakällor
            14,15,16,17,18,19,20,  # Worksheet / Dokumentkontroll
            21,22,23,24,    # Seal Test POS
            25,26,27,28,    # Seal Test NEG
            31,32,33,34,35,36 # Snabblänkar
        )
        foreach ($rr in $runInfoDataRows) {
            try {
                $wsRI.Row($rr).Height = 15
                $wsRI.Row($rr).CustomHeight = $true
                # Vänsterpanelens dataceller ska inte driva upp radhöjden.
                $wsRI.Cells[$rr,1,$rr,3].Style.WrapText = $false
                $wsRI.Cells[$rr,1,$rr,3].Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
            } catch {}
        }
        # Rubrik-/sektionsrader får vara lite högre men ska också vara konsekventa.
        foreach ($rr in @(1,7,13,30)) {
            try {
                $wsRI.Row($rr).Height = 22
                $wsRI.Row($rr).CustomHeight = $true
                $wsRI.Cells[$rr,1,$rr,3].Style.VerticalAlignment = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
            } catch {}
        }
    }
} catch {
    Gui-Log "⚠️ Run Information radhöjdsjustering misslyckades: $($_.Exception.Message)" 'Warn'
}

            # ============================================================
            # === Sample Reagent Checklist-markering (additiv)         ===
            # ============================================================
            try {
                $_srhPNs = @()
                try { $_srhPNs = @(Get-ConfigValue -Name 'SampleReagentChecklistPNs' -Default @()) } catch {}

                if ($_srhPNs.Count -gt 0) {
                    $_srhWs = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
                    if ($_srhWs -and $_srhWs.Dimension) {
                        $_srhLabelCol = $spStartCol
                        $_srhValueCol = $spStartCol + 1
                        $_srhPNRow  = -1; $_srhUseRow = -1
                        $_srhPNVal  = ''; $_srhUseVal = ''

                        for ($_sr = ($spStartRow + 1); $_sr -le ($spStartRow + 120); $_sr++) {
                            $_srhLabel = (Normalize-HeaderText ($_srhWs.Cells[$_sr, $_srhLabelCol].Text + '')).Trim()
                            if ($_srhLabel -ieq 'Sample Reagent P/N') {
                                $_srhPNRow = $_sr
                                $_srhPNVal = ($_srhWs.Cells[$_sr, $_srhValueCol].Text + '').Trim()
                            }
                            if ($_srhLabel -ieq 'Sample Reagent use') {
                                $_srhUseRow = $_sr
                                $_srhUseVal = ($_srhWs.Cells[$_sr, $_srhValueCol].Text + '').Trim()
                            }
                        }

                        $_srhMatch = $false
                        if ($_srhPNVal) {
                            foreach ($_pn in $_srhPNs) {
                                if ($_srhPNVal -eq ($_pn + '').Trim()) { $_srhMatch = $true; break }
                            }
                        }

                        if ($_srhMatch) {
                            $_srhHighlightBg = [System.Drawing.Color]::FromArgb(255, 255, 200)
                            $_srhWarningBg   = [System.Drawing.Color]::FromArgb(255, 235, 156)
                            $_srhWarningFg   = [System.Drawing.Color]::FromArgb(156, 101, 0)
                            $_srhOkBg        = [System.Drawing.Color]::FromArgb(198, 239, 206)
                            $_srhOkFg        = [System.Drawing.Color]::FromArgb(0, 97, 0)

                            if ($_srhPNRow -gt 0) {
                                $_srhWs.Cells[$_srhPNRow, $_srhValueCol].Style.Fill.PatternType = 'Solid'
                                $_srhWs.Cells[$_srhPNRow, $_srhValueCol].Style.Fill.BackgroundColor.SetColor($_srhHighlightBg)
                                $_srhWs.Cells[$_srhPNRow, $_srhValueCol].Style.Font.Bold = $true
                            }

                            if ($_srhUseRow -gt 0) {
                                if ($_srhUseVal) {
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.PatternType = 'Solid'
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.BackgroundColor.SetColor($_srhOkBg)
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Color.SetColor($_srhOkFg)
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Bold = $true
                                } else {
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Value = '⚠ SAKNAS'
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.PatternType = 'Solid'
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Fill.BackgroundColor.SetColor($_srhWarningBg)
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Color.SetColor($_srhWarningFg)
                                    $_srhWs.Cells[$_srhUseRow, $_srhValueCol].Style.Font.Bold = $true
                                    Gui-Log '⚠️ Sample Reagent Saknas' 'Warn'
                                }
                            }
                        }
                    }
                }
            } catch {
                Gui-Log "⚠️ Sample Reagent highlight: $($_.Exception.Message)" 'Warn'
            }

        }
    }
} catch {
    Gui-Log "⚠️ SP-blad: $($_.Exception.Message)" 'Warn'
}

# ============================
# === QC-påminnelse (HIV/HBV/HCV) → Information E16:F18 ===
# ============================
try {
    if ($script:QcReminderB3) {
        $wsInfo = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
        if ($wsInfo) {
$eCol  = 5   # E
$fCol  = 6   # F
# Radhöjd gäller hela Excel-raden.
# Därför ska QC-påminnelsen inte placeras mitt i vänster Run Information-panel,
# eftersom den annars kan göra Dokumentkontroll-/Snabblänksrader ojämnt höga.
# Vänsterpanelen använder rad 1-36, så QC börjar tidigast på rad 38.
$qcRow = 38
try {
    if ($script:RunInfoSpBlockLastRow -and [int]$script:RunInfoSpBlockLastRow -ge ($qcRow - 1)) {
        $qcRow = [int]$script:RunInfoSpBlockLastRow + 2
    }
} catch {
    $qcRow = 38
}

            # Färger (samma som SharePoint Info-rubriken)
            $HeaderBg  = [System.Drawing.Color]::FromArgb(68, 84, 106)
            $HeaderFg  = [System.Drawing.Color]::White
            $SectionBg = [System.Drawing.Color]::FromArgb(217, 225, 242)
            $SectionFg = [System.Drawing.Color]::FromArgb(0, 32, 96)
            $BorderClr = [System.Drawing.Color]::FromArgb(68, 84, 106)

            # --- Rad 16: rubrik (sammanfogad E16:F16) ---
            $wsInfo.Cells[$qcRow, $eCol, $qcRow, $fCol].Merge = $true
            $hdrCell = $wsInfo.Cells[$qcRow, $eCol]
            $hdrCell.Value = ('QC Data – ' + $script:QcReminderB3)
            $hdrCell.Style.Font.Bold = $true
            $hdrCell.Style.Font.Size = 14
            $hdrCell.Style.Font.Name = 'Calibri'
            $hdrCell.Style.Font.Color.SetColor($HeaderFg)
            $hdrCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $hdrCell.Style.Fill.BackgroundColor.SetColor($HeaderBg)
            $hdrCell.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Left
            $hdrCell.Style.VerticalAlignment   = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center
            $wsInfo.Row($qcRow).Height = 22

            # --- Rad 17: "Additional QC-Data?" / "JA" ---
            $wsInfo.Cells[($qcRow+1), $eCol].Value = 'Additional QC-Data?'
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Font.Bold = $true
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Font.Name = 'Calibri'
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Font.Size = 10
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Font.Color.SetColor($SectionFg)
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $wsInfo.Cells[($qcRow+1), $eCol].Style.Fill.BackgroundColor.SetColor($SectionBg)

            $wsInfo.Cells[($qcRow+1), $fCol].Value = 'JA'
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Font.Bold = $true
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Font.Name = 'Calibri'
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Font.Size = 10
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(0, 128, 0))
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $wsInfo.Cells[($qcRow+1), $fCol].Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::White)
            $wsInfo.Cells[($qcRow+1), $fCol].Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Left

            # --- Rad 18: "Lathund QC data" med länk (sammanfogad E18:F18) ---
            $wsInfo.Cells[($qcRow+2), $eCol, ($qcRow+2), $fCol].Merge = $true
            $linkCell = $wsInfo.Cells[($qcRow+2), $eCol]

            $lathundPath = ''
            if ($Config) {
                # Primär nyckel (finns i Config.ps1 i LIVE-zippen)
                if ($Config.Contains('QcDataCheatSheetLink')) {
                    $lathundPath = $Config.QcDataCheatSheetLink
                }
                # Reservnyckel om du någon gång vill använda ett annat namn
                elseif ($Config.Contains('QcReminderLathundPath')) {
                    $lathundPath = $Config.QcReminderLathundPath
                }
            }

            $linkCell.Value = 'Lathund QC data'
            $linkCell.Style.Font.Name = 'Calibri'
            $linkCell.Style.Font.Size = 10
            $linkCell.Style.Font.UnderLine = $true
            $linkCell.Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(5, 99, 193))
            $linkCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $linkCell.Style.Fill.BackgroundColor.SetColor($SectionBg)
            # Centrera sammanfogad E18:F18 (både horisontellt och vertikalt)
            $linkCell.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center
            $linkCell.Style.VerticalAlignment   = [OfficeOpenXml.Style.ExcelVerticalAlignment]::Center

            if ($lathundPath) {
                try {
                    # Bygg stabil URI:
                    $uriText = $lathundPath
                    if ($uriText -match '^(?i)https?://') {
                        $linkCell.Hyperlink = New-Object System.Uri($uriText)
                   }
                    elseif ($uriText -match '^[A-Za-z]:\\') {
                        # ex: N:\Folder\File.docx -> file:///N:/Folder/File.docx
                        $fileUri = 'file:///' + ($uriText -replace '\\','/')
                        $fileUri = [System.Uri]::EscapeUriString($fileUri)
                        $linkCell.Hyperlink = New-Object System.Uri($fileUri)
                    }
                    elseif ($uriText -match '^\\\\') {
                        # UNC-sökväg: System.Uri hanterar \\server\share nativt och bevarar Unicode
                        $linkCell.Hyperlink = New-Object System.Uri($uriText)
                    }
                    else {
                        # Sista försök (om du ger en redan korrekt URI)
                        $linkCell.Hyperlink = New-Object System.Uri($uriText)
                    }
                 } catch {
                     Gui-Log ("⚠️ QC Data: Kunde inte skapa hyperlänk till '{0}': {1}" -f $lathundPath, $_.Exception.Message) 'Warn'
                 }
             }

            # Ramar runt hela QC-påminnelseblocket
            $rng = $wsInfo.Cells[$qcRow, $eCol, ($qcRow+2), $fCol]
            $rng.Style.Border.Top.Style    = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Left.Style   = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Right.Style  = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $rng.Style.Border.Top.Color.SetColor($BorderClr)
            $rng.Style.Border.Bottom.Color.SetColor($BorderClr)
            $rng.Style.Border.Left.Color.SetColor($BorderClr)
            $rng.Style.Border.Right.Color.SetColor($BorderClr)
        }
    }
} catch {
}

# ============================
# === Rubrik-vattenstämpel ===
# ============================
try {
    foreach ($ws in $pkgOut.Workbook.Worksheets) {
        try {
            $ws.HeaderFooter.OddHeader.CenteredText   = '&"Arial,Bold"&14 UNCONTROLLED'
            $ws.HeaderFooter.EvenHeader.CenteredText  = '&"Arial,Bold"&14 UNCONTROLLED'
            $ws.HeaderFooter.FirstHeader.CenteredText = '&"Arial,Bold"&14 UNCONTROLLED'
        } catch {
            Gui-Log ("⚠️ Kunde inte sätta header på blad: " + $ws.Name) 'Warn'
        }
    }
} catch {
    Gui-Log "⚠️ Fel vid vattenstämpling av rapporten." 'Warn'
}

        # ============================
        # === Flikfärger (före sparning)
        # ============================
        try {
            $wsT = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo];     if ($wsT) { $wsT.TabColor = [System.Drawing.Color]::FromArgb(255, 52, 152, 219) }
            $wsT = $pkgOut.Workbook.Worksheets[$Layout.SheetUtrustning];     if ($wsT) { $wsT.TabColor = [System.Drawing.Color]::FromArgb(255, 33, 115, 70) }
        } catch {
        Gui-Log "⚠️ Kunde inte sätta tab-färg: $($_.Exception.Message)" 'Warn'
    }

        #endregion Build: Output-flikar

        #region Build: Spara rapport och revision
        # ============================
        # === Spara & revision     ===
        # ============================

        $nowTs    = Get-Date -Format "yyyyMMdd_HHmmss"
        $baseName = "$($env:USERNAME)_output_${lsp}_$nowTs.xlsx"
        $saveDir  = $env:TEMP
        $SavePath = Join-Path $saveDir $baseName
        Gui-Log ("💾 Sparar rapport: {0}" -f $baseName) 'Info' 'USER'
        try {
            $pkgOut.Workbook.View.ActiveTab = 0
            $wsInitial = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
            if ($wsInitial) { $wsInitial.View.TabSelected = $true }

            # ============================
            # === RuleEngine felsökningsblad ==
            # ============================
            try {
                if ((Get-ConfigFlag -Name 'EnableRuleEngine' -Default $false -ConfigOverride $Config) -and
                    (Get-ConfigFlag -Name 'EnableRuleEngineDebugSheet' -Default $false -ConfigOverride $Config) -and
                    (($selCsv -and (Test-Path -LiteralPath $selCsv)) -or ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)))) {

                    if (-not $script:RuleEngineShadow -or -not $script:RuleEngineShadow.Rows -or $script:RuleEngineShadow.Rows.Count -eq 0) {

                        Gui-Log "🧠 Regelmotor: saknas vid Save → bygger nu..." 'Warn'

                        $rb2 = $script:RuleBankCache
                        if (-not $rb2) {
                            $rb2 = Load-RuleBank -RuleBankDir $Config.RuleBankDir
                            try {
                                $rb2 = Compile-RuleBank -RuleBank $rb2
                            } catch {
                                Gui-Log ("⚠️ Regelmotor: kunde inte kompilera RuleBank vid Save: " + $_.Exception.Message) 'Warn' 'DEBUG'
                            }
                        }

                        # Primär
                        $csvObjs2 = @()
                        if ($selCsv -and (Test-Path -LiteralPath $selCsv)) {
                            $csvObjs2 = $script:RuleEngineCsvObjs
                            if (-not $csvObjs2 -or $csvObjs2.Count -eq 0) {
                                if ($csvRows -and $csvRows.Count -gt 0) {
                                    $csvObjs2 = @($csvRows)
                                } else {
                                    try {
                                        $all = $script:CsvLinesPrimary
                                        if ($all -and $all.Count -gt 9) {
                                            $hdr = ConvertTo-CsvFields $all[7]
                                            $dl  = $all[9..($all.Count-1)] | Where-Object { $_ -and $_.Trim() }
                                            $del = Get-CsvDelimiter -Path $selCsv
                                            $csvObjs2 = @(ConvertFrom-Csv -InputObject ($dl -join "`n") -Delimiter $del -Header $hdr)
                                        }
                                    } catch {
                                        Gui-Log ("⚠️ Regelmotor: fallback-raw för CSV vid Save misslyckades: " + $_.Exception.Message) 'Warn' 'DEBUG'
                                        $csvObjs2 = @()
                                    }
                                }
                            }
                            if ($csvObjs2 -and $csvObjs2.Count -gt 0) {
                                $script:RuleEngineShadow = Invoke-RuleEngine -CsvObjects $csvObjs2 -RuleBank $rb2 -CsvPath $selCsv
                            }
                        }

                        # Resample-del
                        if ($selCsvRes -and (Test-Path -LiteralPath $selCsvRes)) {
                            $csvObjsR2 = $script:RuleEngineCsvObjsRes
                            if (-not $csvObjsR2 -or $csvObjsR2.Count -eq 0) {
                                if ($csvRowsRes -and $csvRowsRes.Count -gt 0) {
                                    $csvObjsR2 = @($csvRowsRes)
                                } else {
                                    try {
                                        $allR = $script:CsvLinesResample
                                        if ($allR -and $allR.Count -gt 9) {
                                            $hdrR = ConvertTo-CsvFields $allR[7]
                                            $dlR  = $allR[9..($allR.Count-1)] | Where-Object { $_ -and $_.Trim() }
                                            $delR = Get-CsvDelimiter -Path $selCsvRes
                                            $csvObjsR2 = @(ConvertFrom-Csv -InputObject ($dlR -join "`n") -Delimiter $delR -Header $hdrR)
                                        }
                                    } catch {
                                        Gui-Log ("⚠️ Regelmotor: fallback-raw för Resample-CSV vid Save misslyckades: " + $_.Exception.Message) 'Warn' 'DEBUG'
                                        $csvObjsR2 = @()
                                    }
                                }
                            }
                            if ($csvObjsR2 -and $csvObjsR2.Count -gt 0) {
                                $reR2 = Invoke-RuleEngine -CsvObjects $csvObjsR2 -RuleBank $rb2 -CsvPath $selCsvRes
                                if ($script:RuleEngineShadow -and $reR2) {
                                    # Sammanfogning (nytt objekt för PS 5.1-kompatibilitet)
                                    $script:RuleEngineShadow = [pscustomobject]@{
                                        Rows          = @($script:RuleEngineShadow.Rows) + @($reR2.Rows)
                                        Summary       = $script:RuleEngineShadow.Summary
                                        TopDeviations = @($script:RuleEngineShadow.TopDeviations) + @($reR2.TopDeviations)
                                        QC            = $script:RuleEngineShadow.QC
                                    }
                                } elseif ($reR2) {
                                    $script:RuleEngineShadow = $reR2
                                }
                            }
                        }

                        if (-not $script:RuleEngineShadow -or -not $script:RuleEngineShadow.Rows -or @($script:RuleEngineShadow.Rows).Count -eq 0) {
                            Gui-Log "⚠️ Regelmotor: kunde inte bygga vid Save (0 rader)." 'Warn'
                        }
                    }

                    if ($script:RuleEngineShadow -and $script:RuleEngineShadow.Rows -and $script:RuleEngineShadow.Rows.Count -gt 0) {
                        Gui-Log "🧠 Skriver CSV-Sammanfattning..." 'Info' 'PROGRESS'
                        $includeAll = Get-ConfigFlag -Name 'RuleEngineDebugIncludeAllRows' -Default $false -ConfigOverride $Config
                        $dsf = @()
                        if ($script:DataSummaryFindings) { $dsf = @($script:DataSummaryFindings) }
                        $stf = 0
                        if ($script:StfCount) { $stf = [int]$script:StfCount }
                        [void](Write-RuleEngineDebugSheet -Pkg $pkgOut -RuleEngineResult $script:RuleEngineShadow -IncludeAllRows $includeAll -DataSummaryFindings $dsf -StfCount $stf)

                        # --- Skriv använda INF/GX i QC Summary (under befintlig data) ---
                        try {
                            $wsQcs = $pkgOut.Workbook.Worksheets[$Layout.SheetQcSummary]
                            if ($wsQcs) {
                                $usedSystems = [ordered]@{}
                                if ($csvStats -and $csvStats.InstrumentByType) {
                                    foreach ($k in $csvStats.InstrumentByType.Keys) {
                                        if ($k -and $k -ne 'Unknown') { $usedSystems[$k] = $true }
                                    }
                                }
                                if ($csvStatsRes -and $csvStatsRes.InstrumentByType) {
                                    foreach ($k in $csvStatsRes.InstrumentByType.Keys) {
                                        if ($k -and $k -ne 'Unknown') { $usedSystems[$k] = $true }
                                    }
                                }
                                $names = @($usedSystems.Keys | Sort-Object)
                                if ($names.Count -gt 0) {
                                    # Hitta sista använda raden
                                    $lastRow = 3
                                    if ($wsQcs.Dimension) {
                                        for ($ri = $wsQcs.Dimension.End.Row; $ri -ge 1; $ri--) {
                                            $cv = ($wsQcs.Cells[$ri, 1].Text + '').Trim()
                                            if ($cv) { $lastRow = $ri; break }
                                        }
                                    }
                                    $hdrRow = $lastRow + 2  # 2 raders mellanrum

                                    # Rubrik (kolumn A, spänner antal system)
                                    $wsQcs.Cells[$hdrRow, 1].Value = 'Använda INF/GX'
                                    $wsQcs.Cells[$hdrRow, 1].Style.Font.Bold = $true
                                    $wsQcs.Cells[$hdrRow, 1].Style.Font.Size = 10
                                    $hdrRng = $wsQcs.Cells[$hdrRow, 1, $hdrRow, $names.Count]
                                    $hdrRng.Merge = $true
                                    $hdrRng.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                    $hdrRng.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::FromArgb(217, 225, 242))
                                    $hdrRng.Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(0, 32, 96))
                                    $hdrRng.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center

                                    $calMap = $script:CalDueMap
                                    for ($ci = 0; $ci -lt $names.Count; $ci++) {
                                        $col = 1 + $ci
                                        $sysName = $names[$ci]

                                        # Systemnamn
                                        $cName = $wsQcs.Cells[($hdrRow + 1), $col]
                                        $cName.Value = $sysName
                                        $cName.Style.Font.Bold = $true
                                        $cName.Style.Font.Size = 9
                                        $cName.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center
                                        $cName.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                        $cName.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::FromArgb(242, 242, 242))

                                        # Cal Due Date
                                        $cCal = $wsQcs.Cells[($hdrRow + 2), $col]
                                        $calVal = ''
                                        if ($calMap -and $calMap.ContainsKey($sysName)) { $calVal = $calMap[$sysName] }
                                        $cCal.Value = $calVal
                                        $cCal.Style.Font.Size = 9
                                        $cCal.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center
                                        $cCal.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                                        $cCal.Style.Fill.BackgroundColor.SetColor([System.Drawing.Color]::FromArgb(198, 239, 206))

                                        try { $wsQcs.Column($col).AutoFit() } catch {}
                                        try { $wsQcs.Column($col).Width = [Math]::Max($wsQcs.Column($col).Width, 14) } catch {}
                                    }
                                }
                            }
                        } catch {
                            Gui-Log ("⚠️ QC Summary INF/GX fel: " + $_.Exception.Message) 'Warn'
                        }

                        # Visa vilken CSV som klassades som primär/resample direkt i CSV Sammanfattning (rad 2)
                        try {
                            $wsDbg = $pkgOut.Workbook.Worksheets['CSV Sammanfattning']
                            if ($wsDbg) {
                                $pPath = if ($selCsvOrig) { $selCsvOrig } elseif ($selCsv) { $selCsv } else { '' }
                                $rPath = if ($selCsvResOrig) { $selCsvResOrig } elseif ($selCsvRes) { $selCsvRes } else { '' }
                                $pLeaf = Get-CleanLeaf $pPath
                                $rLeaf = Get-CleanLeaf $rPath
                                $lbl = if ($pLeaf -and $rLeaf) {
                                    "CSV: {0} | RES CSV: {1}" -f $pLeaf, $rLeaf
                                } elseif ($pLeaf) {
                                    "CSV: {0}" -f $pLeaf
                                } elseif ($rLeaf) {
                                    "Resample CSV: {0}" -f $rLeaf
                                } else { '' }
                                if ($lbl) {
                                    $rng = $wsDbg.Cells[2, 1, 2, 8]
                                    $rng.Merge = $true
                                    $rng.Style.Numberformat.Format = '@'
                                    $rng.Style.Font.Italic = $true
                                    $wsDbg.Cells[2, 1].Value = $lbl
                                }
                            }
                        } catch {
                            Gui-Log ("⚠️ Kunde inte märka CSV-Sammanfattning med vald CSV/Resample: " + $_.Exception.Message) 'Warn' 'DEBUG'
                        }
                    } else {
                        Gui-Log "⚠️ Kunde inte skriva CSV-Sammanfattning." 'Warn'
                    }
                }
            } catch {
                Gui-Log ("⚠️ Kunde inte skriva CSV-Sammanfattning: " + $_.Exception.Message) 'Warn'
            }
try {
    $wsRunInfoFinal = $pkgOut.Workbook.Worksheets[$Layout.SheetRunInfo]
    if ($wsRunInfoFinal -and $script:RunInfoTemplateColumnWidths -and $script:RunInfoTemplateColumnWidths.Count -gt 0) {
        Restore-RunInformationColumnWidths -Ws $wsRunInfoFinal -Widths $script:RunInfoTemplateColumnWidths
    }
} catch {}
Set-UiStep 90 'Sparar rapport…'
Mark-Phase 'RunInfo'
# UX: Om rapportfilen redan finns och är öppen (Excel), be användaren stänga innan SaveAs
            try {
                if ($SavePath -and (Test-Path -LiteralPath $SavePath)) {
                    if (-not (Ensure-FilesClosedOrCancel -Paths @($SavePath) -Hint 'Stäng rapporten i Excel (eller stäng Preview i Explorer) och klicka Försök igen.')) {
                        Gui-Log "🛑 Avbrutet: output-filen är låst/öppen." 'Warn'
                        return
                    }
                }
            } catch {
                Gui-Log ("⚠️ Fil-låskontroll för output misslyckades: " + $_.Exception.Message) 'Warn' 'DEBUG'
            }
            try {
                $pkgOut.SaveAs($SavePath)
            } catch {
                $auditStatusText = 'Error'
                $saveErr = $_.Exception.Message
                if ($saveErr -match 'being used by another process|access.*denied|permission') {
                    Gui-Log ("❌ Kunde inte spara: filen är låst av ett annat program. Stäng Excel/Preview och försök igen.") 'Error'
                } else {
                    Gui-Log ("❌ Kunde inte spara rapporten: $saveErr") 'Error'
                }
                return
            }
            Mark-Phase 'Save'
            $buildTimer.Stop()
            $totalMs = $buildTimer.ElapsedMilliseconds
            $doneMsg = 'Klar ✅  ({0:N1}s)' -f ($totalMs / 1000)
            Set-UiStep 100 $doneMsg
            Gui-Log -Text ("Rapport sparad: {0} ({1:N1}s)" -f $SavePath, ($totalMs / 1000)) -Severity Info -Category RESULT
            # Signeringssammanfattning
            $signParts = @()
            if ($doSealTest) { $signParts += "Seal Test: NEG+POS" }
            if ($doWsSamm)   { $signParts += "WS Sammanst." }
            if ($doWsGransk) { $signParts += "WS Granskning" }
            if ($signParts.Count -gt 0) {
                Gui-Log ("🔏 Verifierad signering: " + ($signParts -join ', ')) 'Info'
            }
            $global:LastReportPath = $SavePath
            try { $form.Text = "IPTCompile – $ScriptVersion — $(Split-Path $SavePath -Leaf)" } catch {}
            try {
                $auditDir = Join-Path $PSScriptRoot 'audit'
                if (-not (Test-Path -LiteralPath $auditDir)) { New-Item -ItemType Directory -Path $auditDir -Force | Out-Null }

            # Fasdetaljerad tidsmätning (ms)
            $phaseJson = ''
            try { $phaseJson = ($phaseTimings | ConvertTo-Json -Compress) } 
            catch { $phaseJson = '' }


                $auditObj = [pscustomobject]@{
                    DatumTid        = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
                    Användare       = $env:USERNAME
                    LSP             = $lsp
                    ValdCSV         = if ($selCsv -or $selCsvRes) { (@($(if($selCsv){Get-CleanLeaf $selCsv}), $(if($selCsvRes){'(Res) '+(Get-CleanLeaf $selCsvRes)})) | Where-Object {$_}) -join ' + ' } else { '' }
                    ValdSealNEG     = Get-CleanLeaf $selNeg
                    ValdSealPOS     = Get-CleanLeaf $selPos
                    Assay           = $runAssay
                    AntalTester     = $(try { if ($csvStats) { 
                    [int]$csvStats.TestCount } else { 0 } } catch { 0 })
                    SignaturSkriven = if ($doSealTest) { 'Ja (verifierad)' } else { 'Nej' }
                    WsSammSkriven   = if ($doWsSamm) { 'Ja (verifierad)' } else { 'Nej' }
                    WsGranskSkriven = if ($doWsGransk) { 'Ja (verifierad)' } else { 'Nej' }
                    SigMismatch     = if ($sigMismatch) { 'Ja' } else { 'Nej' }
                    MismatchSheets  = if ($mismatchSheets -and $mismatchSheets.Count -gt 0) { ($mismatchSheets -join ';') } else { '' }
                    ViolationsNEG   = $violationsNeg.Count
                    ViolationsPOS   = $violationsPos.Count
                    Violations      = ($violationsNeg.Count + $violationsPos.Count)
                    TotalTid_ms     = $totalMs
                    TotalTid_s      = [math]::Round($totalMs / 1000, 1)
                    FasTider_json   = $phaseJson
                    Sparläge        = 'Temporärt'
                    OutputFile      = $SavePath
                    Kommentar       = 'UNCONTROLLED rapport, ingen källfil ändrades automatiskt.'
                    ScriptVersion   = $ScriptVersion
                }

                $auditFile = Join-Path $auditDir ("$($env:USERNAME)_audit_${nowTs}.csv")
                $auditObj | Export-Csv -Path $auditFile -NoTypeInformation -Encoding UTF8

                try {
                    $statusText = 'OK'
                    if (($violationsNeg.Count + $violationsPos.Count) -gt 0 -or $sigMismatch -or ($mismatchSheets -and $mismatchSheets.Count -gt 0)) {
                        $statusText = 'Warnings'
                    }
                    $auditStatusText = $statusText
                    $auditTests = $null
                    try {
                        if ($csvStats) { $auditTests = [int]$csvStats.TestCount }
                        if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) { $auditTests = ($auditTests + 0) + [int]$csvStatsRes.TestCount }
                    } catch {}
                    Add-AuditEntry -Lsp $lsp -Assay $runAssay -BatchNumber $batch -TestCount $auditTests -Status $statusText -ReportPath $SavePath -TotalMs $totalMs -PhaseJson $phaseJson
                    $auditWritten = $true
                } catch {
                    Gui-Log "⚠️ Kunde inte skriva audit-CSV: $($_.Exception.Message)" 'Warn'
                }
            } catch {
                Gui-Log "⚠️ Kunde inte skriva revisionsfil: $($_.Exception.Message)" 'Warn'
            }

            # ---- Sessionsspårning + tidsbesparningsuppskattning ----
            try {
                $script:SessionStats.ReportCount++
                $script:SessionStats.TotalBuildMs += $totalMs
                $buildTests = 0
                try { if ($csvStats) { $buildTests = [int]$csvStats.TestCount } } catch {}
                try { if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) { $buildTests += [int]$csvStatsRes.TestCount } } catch {}
                $script:SessionStats.TotalTestsBuilt += $buildTests

                # Uppskattad manuell tid: ~20 min per rapport (konservativt)
                $manualMinEstimate = 10
                $savedMin = $manualMinEstimate - [math]::Round($totalMs / 60000, 1)
                if ($savedMin -lt 5) { $savedMin = 5 }
                $sessionSavedMin = [math]::Round($script:SessionStats.ReportCount * $manualMinEstimate - $script:SessionStats.TotalBuildMs / 60000, 0)
                if ($sessionSavedMin -lt $script:SessionStats.ReportCount) { $sessionSavedMin = $script:SessionStats.ReportCount * 5 }

                Gui-Log ("   Uppskattad tidsbesparning: ~{0} min (manuellt ~{1} min, IPTCompile {2:N1}s)" -f [int]$savedMin, $manualMinEstimate, ($totalMs / 1000)) 'Info' 'RESULT'

                # Uppdatera statusfältets sessionsindikator
                $sessText = if ($script:SessionStats.ReportCount -eq 1) {
                    "1 rapport | ~{0} min sparad" -f [int]$savedMin
                } else {
                    "{0} rapporter | ~{1} min sparade" -f $script:SessionStats.ReportCount, [int]$sessionSavedMin
                }
                $script:slSession.Text = $sessText
                $script:slSession.Visible = $true
            } catch {}

            # Kort visuell blink på Build-knappen
            $origBack = $btnBuild.BackColor
            try {
                $btnBuild.BackColor = [System.Drawing.Color]::FromArgb(46, 125, 50)
                $btnBuild.Refresh()
                Start-Sleep -Milliseconds 600
                $btnBuild.BackColor = $origBack
                $btnBuild.Refresh()
            } catch { try { $btnBuild.BackColor = $origBack } catch {} }

            try { Start-Process -FilePath $SavePath } catch {

            # Kort ljud-notis vid klar rapport
            try { [System.Media.SystemSounds]::Exclamation.Play() } catch {}
                Gui-Log "ℹ️ Rapporten sparades men kunde inte öppnas automatiskt: $($_.Exception.Message)" 'Info' 'USER'
            }
        }
        catch {
            $auditStatusText = 'Error'
            Gui-Log "❌ Kunde inte spara rapporten: $($_.Exception.Message)" 'Error'
        }

    } finally {
        # Stoppa elapsed-timer
        try { if ($script:buildElapsedTimer) { $script:buildElapsedTimer.Stop(); $script:buildElapsedTimer.Dispose(); $script:buildElapsedTimer = $null } } catch {}
        try {
            if ($buildTimer -and $buildTimer.IsRunning) { $buildTimer.Stop() }
        } catch {}
        if (($totalMs -le 0) -and $buildTimer) {
            try { $totalMs = [int]$buildTimer.ElapsedMilliseconds } catch { $totalMs = 0 }
        }
        if (-not $phaseJson) {
            try { $phaseJson = ($phaseTimings | ConvertTo-Json -Compress) } catch { $phaseJson = '' }
        }
        if (-not $auditWritten) {
            try {
                $auditTests = $null
                if ($csvStats) { $auditTests = [int]$csvStats.TestCount }
                if ($csvStatsRes -and $csvStatsRes.TestCount -gt 0) { $auditTests = ($auditTests + 0) + [int]$csvStatsRes.TestCount }
                Add-AuditEntry -Lsp $lsp -Assay $runAssay -BatchNumber $batch -TestCount $auditTests -Status $auditStatusText -ReportPath $SavePath -TotalMs $totalMs -PhaseJson $phaseJson
                $auditWritten = $true
            } catch {
                Gui-Log "⚠️ Kunde inte skriva fallback-audit: $($_.Exception.Message)" 'Warn'
            }
        }
        try { if ($pkgNeg) { $pkgNeg.Dispose() } } catch {}
        try { if ($pkgPos) { $pkgPos.Dispose() } } catch {}
        try { if ($pkgOut) { $pkgOut.Dispose() } } catch {}
        try { if ($script:WsPkg) { $script:WsPkg.Dispose(); $script:WsPkg = $null } } catch {}
        try {
            if ($stageDir -and (Test-Path -LiteralPath $stageDir)) {
                # Säkerhet: radera bara om den ligger under TEMP-root
                $root = Get-ConfigValue -Name 'TempSnapshotRoot' -Default 'C:\IPTCompile_TEMP' -ConfigOverride $Config
                if (-not $root) { $root = 'C:\IPTCompile_TEMP' }
                $stageFull = (Resolve-Path -LiteralPath $stageDir -ErrorAction SilentlyContinue).Path
                $rootFull  = (Resolve-Path -LiteralPath $root -ErrorAction SilentlyContinue).Path
                if ($stageFull -and $rootFull -and $stageFull.StartsWith($rootFull, [System.StringComparison]::OrdinalIgnoreCase)) {
                    Remove-Item -LiteralPath $stageDir -Recurse -Force -ErrorAction SilentlyContinue
                }
            }
        } catch {}
        Set-UiBusy -Busy $false
        $script:BuildInProgress = $false
    }
    #endregion Build: Spara rapport och revision
    #endregion Build: Rapportgenerering (huvudloop)
})

#endregion Händelsehanterare (meny, knappar, tema, scan, build)

# === Verktygstips ===
$toolTip = New-Object System.Windows.Forms.ToolTip
$toolTip.SetToolTip($chkSignOverwrite, $chkSignOverwrite.Tag)
$toolTip.SetToolTip($chkGranskOverwrite, $chkGranskOverwrite.Tag)
$toolTip.AutoPopDelay = 8000
$toolTip.InitialDelay = 500
$toolTip.ReshowDelay  = 500
$toolTip.ShowAlways   = $true
$toolTip.SetToolTip($txtLSP, 'Ange LSP-numret utan och klicka på Sök filer.')
$toolTip.SetToolTip($btnScan, 'Sök efter LSP och lista tillgängliga filer.')
$toolTip.SetToolTip($clbCsv,  'Välj 1 eller 2 CSV-filer (CSV + Resampling-CSV).')
$toolTip.SetToolTip($clbNeg,  'Välj Seal Test Neg-fil.')
$toolTip.SetToolTip($clbPos,  'Välj Seal Test Pos-fil.')
$toolTip.SetToolTip($btnCsvBrowse, 'Bläddra efter en CSV-fil.')
$toolTip.SetToolTip($btnNegBrowse, 'Bläddra efter Seal Test Neg-fil.')
$toolTip.SetToolTip($btnPosBrowse, 'Bläddra efter Seal Test Pos-fil.')
$toolTip.SetToolTip($txtSammName, 'Sammanställning: Förnamn Efternamn (t.ex. Jesper Fredriksson).')
$toolTip.SetToolTip($txtSammDate, 'Sammanställning: Datum.')
$toolTip.SetToolTip($txtSealTestSign, 'Seal Test: SIGN (t.ex. JESP).')
$toolTip.SetToolTip($chkSealTest, 'Signatur appliceras på Seal Test-flikar.')
$toolTip.SetToolTip($chkWsSamm, 'Signerar Worksheet (Recorded By / Performed By-fält).')
$tipOverwriteSammDefault = 'Aktiverar signaturer skrivs till (Sammanställning).'
$tipOverwriteGranskDefault = 'Aktiverar signaturer skrivs till (Granskning).'
$toolTip.SetToolTip($chkSignOverwrite, $tipOverwriteSammDefault)
$toolTip.SetToolTip($chkGranskOverwrite, $tipOverwriteGranskDefault)
$toolTip.SetToolTip($txtGranskName, 'Granskning: Förnamn Efternamn (t.ex. Jesper Fredriksson).')
$toolTip.SetToolTip($txtGranskDate, 'Granskning: Datum.')
$toolTip.SetToolTip($chkWsGransk, 'Signerar Worksheet (PQC Reviewed By i Test Summary).')
$miToggleSignSamm.ToolTipText = 'Visa eller dölj signering (Sammanställning): Seal Test + Worksheet.'
$miToggleSignGransk.ToolTipText = 'Visa eller dölj signering (Granskning): Worksheet PQC Review.'
$toolTip.SetToolTip($btnBuild, 'Skapa och öppna rapporten baserat på de valda filerna.')
$toolTip.SetToolTip($clbLsp,  'Välj LSP Worksheet.')
$toolTip.SetToolTip($btnMove3, 'Flytta matchade filer från Downloads till TEST-mapp.')
$toolTip.SetToolTip($btnMove4, 'Flytta matchade filer från Downloads till mappen i KLART FÖR GRANSKNING.')

$script:OverwriteUiState = @{
    Sign = @{
        BackColor = $chkSignOverwrite.BackColor
        ForeColor = $chkSignOverwrite.ForeColor
        Font      = $chkSignOverwrite.Font
        Tooltip   = $tipOverwriteSammDefault
    }
    Gransk = @{
        BackColor = $chkGranskOverwrite.BackColor
        ForeColor = $chkGranskOverwrite.ForeColor
        Font      = $chkGranskOverwrite.Font
        Tooltip   = $tipOverwriteGranskDefault
    }
    WarnBackColor = [System.Drawing.Color]::FromArgb(255, 249, 196)
    BoldFont      = New-Object System.Drawing.Font($chkSignOverwrite.Font, ([System.Drawing.FontStyle]::Bold))
}

$chkSealTest.add_CheckedChanged({ Update-OverwriteVerificationUI })
$chkWsSamm.add_CheckedChanged({ Update-OverwriteVerificationUI })
$chkWsGransk.add_CheckedChanged({ Update-OverwriteVerificationUI })
$chkSignOverwrite.add_CheckedChanged({ Update-OverwriteVerificationUI })
$chkGranskOverwrite.add_CheckedChanged({ Update-OverwriteVerificationUI })
Update-OverwriteVerificationUI

# P3: Debounce – kör Update-BatchLink 400ms efter senaste tangenttryck (undviker Excel-IO vid varje tangent)
$script:batchLinkTimer = New-Object System.Windows.Forms.Timer
$script:batchLinkTimer.Interval = 400
$script:batchLinkTimer.add_Tick({
    $script:batchLinkTimer.Stop()
    try { Update-BatchLink } catch {}
})
$txtLSP.add_TextChanged({
    $script:batchLinkTimer.Stop()
    $script:batchLinkTimer.Start()
})

#region Huvudkörning / Orkestrering
# =============== SLUT ===============
try { Set-Theme 'light' } catch {}
try { Update-OverwriteVerificationUI } catch {}
Enable-DoubleBuffer
Update-BatchLink
[System.Windows.Forms.Application]::Run($form)

# Städa SPClient-runspace vid avslut
try { Stop-SPClient } catch {}

try{ Stop-Transcript | Out-Null }catch{}
#endregion Huvudkörning / Orkestrering
