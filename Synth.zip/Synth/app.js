"use strict";

const NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"];
const NOTE_COUNT = 25;
const WHITE_PITCHES = new Set([0, 2, 4, 5, 7, 9, 11]);
const BLACK_PITCHES = new Set([1, 3, 6, 8, 10]);
const WHITE_NOTES = Array.from({ length: NOTE_COUNT }, (_, index) => index)
  .filter((index) => WHITE_PITCHES.has(index % 12));
const BLACK_NOTES = Array.from({ length: NOTE_COUNT }, (_, index) => index)
  .filter((index) => BLACK_PITCHES.has(index % 12));

// Two familiar computer-keyboard rows, one octave on each row.
const DEFAULT_MAPPING = [
  "z", "s", "x", "d", "c", "v", "g", "b", "h", "n", "j", "m",
  "q", "2", "w", "3", "e", "r", "5", "t", "6", "y", "7", "u", "i"
];

const DRUM_KEY_TO_TYPE = new Map([
  ["1", "kick"],
  ["4", "snare"],
  ["8", "hat"],
  ["0", "clap"]
]);

const SYNTH_PRESETS = {
  custom: {
    oscillators: null,
    q: 0.4
  },
  warm: {
    waveform: "triangle",
    attack: 0.04,
    release: 0.65,
    tone: 0.5,
    q: 0.7,
    oscillators: [
      { type: "triangle", level: 0.8 },
      { type: "sine", ratio: 0.5, level: 0.22 }
    ]
  },
  lead: {
    waveform: "sawtooth",
    attack: 0.01,
    release: 0.22,
    tone: 0.78,
    q: 1.2,
    oscillators: [
      { type: "sawtooth", detune: -7, level: 0.45 },
      { type: "sawtooth", detune: 7, level: 0.45 },
      { type: "square", ratio: 0.5, level: 0.12 }
    ]
  },
  pad: {
    waveform: "sawtooth",
    attack: 0.65,
    release: 1.7,
    tone: 0.4,
    q: 0.5,
    oscillators: [
      { type: "sawtooth", detune: -9, level: 0.34 },
      { type: "sawtooth", detune: 9, level: 0.34 },
      { type: "triangle", level: 0.34 }
    ]
  },
  organ: {
    waveform: "sine",
    attack: 0.01,
    release: 0.28,
    tone: 0.72,
    q: 0.3,
    oscillators: [
      { type: "sine", level: 0.65 },
      { type: "sine", ratio: 2, level: 0.24 },
      { type: "sine", ratio: 3, level: 0.11 }
    ]
  },
  bass: {
    waveform: "square",
    attack: 0.01,
    release: 0.3,
    tone: 0.28,
    q: 1.4,
    oscillators: [
      { type: "sawtooth", level: 0.52 },
      { type: "square", ratio: 0.5, level: 0.38 }
    ]
  }
};

const elements = {
  piano: document.querySelector("#piano"),
  status: document.querySelector("#statusText"),
  mappingHelp: document.querySelector("#mappingHelp"),
  preset: document.querySelector("#preset"),
  waveform: document.querySelector("#waveform"),
  volume: document.querySelector("#volume"),
  volumeValue: document.querySelector("#volumeValue"),
  attack: document.querySelector("#attack"),
  attackValue: document.querySelector("#attackValue"),
  release: document.querySelector("#release"),
  releaseValue: document.querySelector("#releaseValue"),
  tone: document.querySelector("#tone"),
  toneValue: document.querySelector("#toneValue"),
  octaveDisplay: document.querySelector("#octaveDisplay"),
  octaveDown: document.querySelector("#octaveDown"),
  octaveUp: document.querySelector("#octaveUp"),
  sustain: document.querySelector("#sustainButton"),
  drumPads: document.querySelector("#drumPads"),
  editMapping: document.querySelector("#editMappingButton"),
  resetMapping: document.querySelector("#resetMappingButton"),
  record: document.querySelector("#recButton"),
  play: document.querySelector("#playButton"),
  stop: document.querySelector("#stopButton"),
  loop: document.querySelector("#loopToggle")
};

let keyMapping = [...DEFAULT_MAPPING];
let keyToNote = new Map();
let baseOctave = 4;

let audioContext = null;
let masterGain = null;
let noiseBuffer = null;
const voices = new Map();
const drumVoices = new Map();
const visualNoteCounts = new Map();
const drumPadTimers = new Map();

const liveNotes = new Map();
const heldSources = new Set();
const pressedKeys = new Map();
const pressedDrumKeys = new Set();
const activePointers = new Map();
let liveSoundCounter = 0;
let drumSoundCounter = 0;
let sustainOn = false;

let editMappingMode = false;
let selectedNoteForMapping = null;

let isRecording = false;
let recordStartTime = 0;
let recordingDuration = 0;
let recordedEvents = [];
let recordEventId = 0;

let isPlaying = false;
let playbackCycle = 0;
const playbackTimers = new Set();

// ---------- Audio ----------

function ensureAudio() {
  if (audioContext) return true;

  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextClass) {
    setStatus("This browser does not support the Web Audio API.");
    return false;
  }

  try {
    audioContext = new AudioContextClass();
    masterGain = audioContext.createGain();
    const limiter = audioContext.createDynamicsCompressor();

    masterGain.gain.value = Number(elements.volume.value);
    limiter.threshold.value = -12;
    limiter.knee.value = 10;
    limiter.ratio.value = 4;
    limiter.attack.value = 0.003;
    limiter.release.value = 0.2;

    masterGain.connect(limiter);
    limiter.connect(audioContext.destination);
    return true;
  } catch (error) {
    console.error(error);
    setStatus("Audio could not be started in this browser.");
    return false;
  }
}

function resumeAudio() {
  if (audioContext.state === "suspended") {
    audioContext.resume().catch(() => setStatus("Click the page once to enable audio."));
  }
}

function midiToFrequency(midiNumber) {
  return 440 * 2 ** ((midiNumber - 69) / 12);
}

function noteIndexToMidi(noteIndex) {
  return (baseOctave + 1) * 12 + noteIndex;
}

function getSoundSettings() {
  const preset = SYNTH_PRESETS[elements.preset.value];
  const tone = Number(elements.tone.value);

  return {
    attack: Number(elements.attack.value),
    release: Number(elements.release.value),
    cutoff: 180 + tone ** 2 * 14000,
    q: preset.q,
    oscillators: preset.oscillators
      ? preset.oscillators.map((oscillator) => ({ ...oscillator }))
      : [{ type: elements.waveform.value, level: 1 }]
  };
}

function startVoice(id, noteIndex, midiNumber, sound = getSoundSettings()) {
  if (!ensureAudio()) return false;
  resumeAudio();
  stopVoiceImmediately(id);

  // Keep accidental long sessions from creating unbounded polyphony.
  if (voices.size >= 32) stopVoiceImmediately(voices.keys().next().value);

  const now = audioContext.currentTime;
  const frequency = midiToFrequency(midiNumber);
  const filter = audioContext.createBiquadFilter();
  const outputGain = audioContext.createGain();
  const oscillators = [];
  const oscillatorGains = [];

  filter.type = "lowpass";
  filter.frequency.value = sound.cutoff;
  filter.Q.value = sound.q;
  outputGain.gain.setValueAtTime(0, now);
  if (sound.attack === 0) outputGain.gain.setValueAtTime(1, now);
  else outputGain.gain.linearRampToValueAtTime(1, now + sound.attack);

  for (const setting of sound.oscillators) {
    const oscillator = audioContext.createOscillator();
    const oscillatorGain = audioContext.createGain();
    oscillator.type = setting.type;
    oscillator.frequency.value = frequency * (setting.ratio || 1);
    oscillator.detune.value = setting.detune || 0;
    oscillatorGain.gain.value = setting.level;
    oscillator.connect(oscillatorGain);
    oscillatorGain.connect(filter);
    oscillator.start(now);
    oscillators.push(oscillator);
    oscillatorGains.push(oscillatorGain);
  }

  filter.connect(outputGain);
  outputGain.connect(masterGain);

  const voice = {
    id,
    oscillators,
    oscillatorGains,
    filter,
    gainNode: outputGain,
    release: sound.release,
    noteIndex,
    releasing: false,
    highlighted: true
  };

  oscillators[0].addEventListener("ended", () => removeVoice(voice), { once: true });
  voices.set(id, voice);
  addVisualHighlight(noteIndex);
  return true;
}

function releaseVoice(id) {
  const voice = voices.get(id);
  if (!voice || voice.releasing || !audioContext) return;

  voice.releasing = true;
  clearVoiceHighlight(voice);
  const now = audioContext.currentTime;

  holdAudioParam(voice.gainNode.gain, now);
  voice.gainNode.gain.linearRampToValueAtTime(0, now + voice.release);
  for (const oscillator of voice.oscillators) oscillator.stop(now + voice.release + 0.02);
}

function holdAudioParam(param, time) {
  if (typeof param.cancelAndHoldAtTime === "function") {
    param.cancelAndHoldAtTime(time);
  } else {
    const value = param.value;
    param.cancelScheduledValues(time);
    param.setValueAtTime(value, time);
  }
}

function stopVoiceImmediately(id) {
  const voice = voices.get(id);
  if (!voice) return;

  clearVoiceHighlight(voice);
  voices.delete(id);
  for (const oscillator of voice.oscillators) {
    try {
      oscillator.stop();
    } catch (error) {
      // It may already have reached its scheduled stop time.
    }
  }
  disconnectVoice(voice);
}

function removeVoice(voice) {
  if (voices.get(voice.id) === voice) voices.delete(voice.id);
  clearVoiceHighlight(voice);
  disconnectVoice(voice);
}

function disconnectVoice(voice) {
  for (const oscillator of voice.oscillators) safeDisconnect(oscillator);
  for (const gain of voice.oscillatorGains) safeDisconnect(gain);
  safeDisconnect(voice.filter);
  safeDisconnect(voice.gainNode);
}

function safeDisconnect(node) {
  try {
    node.disconnect();
  } catch (error) {
    // A node can already be disconnected during immediate STOP cleanup.
  }
}

function clearVoiceHighlight(voice) {
  if (!voice.highlighted) return;
  voice.highlighted = false;
  removeVisualHighlight(voice.noteIndex);
}

// ---------- Synthesized drums ----------

function triggerDrum(type, options = {}) {
  if (!ensureAudio()) return;
  resumeAudio();

  const id = options.id || `drum-${++drumSoundCounter}`;
  stopDrumImmediately(id);
  const drum = createDrum(type);
  if (!drum) return;

  drum.timer = window.setTimeout(() => removeDrum(id, drum), drum.duration * 1000 + 80);
  drumVoices.set(id, drum);
  showDrumHit(type);

  if (options.record !== false && isRecording) {
    addRecordedEvent({ type: "drum", id: ++recordEventId, drumType: type });
  }
}

function createDrum(type) {
  const now = audioContext.currentTime;
  if (type === "kick") return createKick(now);
  if (type === "snare") return createSnare(now);
  if (type === "hat") return createHat(now);
  if (type === "clap") return createClap(now);
  return null;
}

function createKick(now) {
  const oscillator = audioContext.createOscillator();
  const gain = audioContext.createGain();
  oscillator.type = "sine";
  oscillator.frequency.setValueAtTime(145, now);
  oscillator.frequency.exponentialRampToValueAtTime(45, now + 0.45);
  gain.gain.setValueAtTime(0.95, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.48);
  oscillator.connect(gain);
  gain.connect(masterGain);
  oscillator.start(now);
  oscillator.stop(now + 0.5);
  return { sources: [oscillator], nodes: [gain], duration: 0.5, timer: null };
}

function createSnare(now) {
  const noise = createNoiseSource();
  const noiseFilter = audioContext.createBiquadFilter();
  const noiseGain = audioContext.createGain();
  const tone = audioContext.createOscillator();
  const toneGain = audioContext.createGain();

  noiseFilter.type = "highpass";
  noiseFilter.frequency.value = 1700;
  noiseGain.gain.setValueAtTime(0.65, now);
  noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
  noise.connect(noiseFilter);
  noiseFilter.connect(noiseGain);
  noiseGain.connect(masterGain);

  tone.type = "triangle";
  tone.frequency.value = 185;
  toneGain.gain.setValueAtTime(0.28, now);
  toneGain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
  tone.connect(toneGain);
  toneGain.connect(masterGain);

  noise.start(now);
  noise.stop(now + 0.21);
  tone.start(now);
  tone.stop(now + 0.13);
  return {
    sources: [noise, tone],
    nodes: [noiseFilter, noiseGain, toneGain],
    duration: 0.21,
    timer: null
  };
}

function createHat(now) {
  const noise = createNoiseSource();
  const filter = audioContext.createBiquadFilter();
  const gain = audioContext.createGain();
  filter.type = "highpass";
  filter.frequency.value = 6500;
  gain.gain.setValueAtTime(0.35, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.085);
  noise.connect(filter);
  filter.connect(gain);
  gain.connect(masterGain);
  noise.start(now);
  noise.stop(now + 0.09);
  return { sources: [noise], nodes: [filter, gain], duration: 0.09, timer: null };
}

function createClap(now) {
  const noise = createNoiseSource();
  const filter = audioContext.createBiquadFilter();
  const gain = audioContext.createGain();
  filter.type = "bandpass";
  filter.frequency.value = 1400;
  filter.Q.value = 0.7;
  gain.gain.setValueAtTime(0.58, now);
  gain.gain.exponentialRampToValueAtTime(0.01, now + 0.035);
  gain.gain.setValueAtTime(0.48, now + 0.055);
  gain.gain.exponentialRampToValueAtTime(0.01, now + 0.09);
  gain.gain.setValueAtTime(0.34, now + 0.11);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.27);
  noise.connect(filter);
  filter.connect(gain);
  gain.connect(masterGain);
  noise.start(now);
  noise.stop(now + 0.28);
  return { sources: [noise], nodes: [filter, gain], duration: 0.28, timer: null };
}

function createNoiseSource() {
  if (!noiseBuffer) {
    noiseBuffer = audioContext.createBuffer(1, audioContext.sampleRate, audioContext.sampleRate);
    const samples = noiseBuffer.getChannelData(0);
    for (let index = 0; index < samples.length; index += 1) samples[index] = Math.random() * 2 - 1;
  }
  const source = audioContext.createBufferSource();
  source.buffer = noiseBuffer;
  return source;
}

function stopDrumImmediately(id) {
  const drum = drumVoices.get(id);
  if (!drum) return;
  drumVoices.delete(id);
  clearTimeout(drum.timer);
  for (const source of drum.sources) {
    try {
      source.stop();
    } catch (error) {
      // The short drum sound may already be over.
    }
  }
  disconnectDrum(drum);
}

function removeDrum(id, drum) {
  if (drumVoices.get(id) === drum) drumVoices.delete(id);
  disconnectDrum(drum);
}

function disconnectDrum(drum) {
  for (const source of drum.sources) safeDisconnect(source);
  for (const node of drum.nodes) safeDisconnect(node);
}

function showDrumHit(type) {
  const pad = elements.drumPads.querySelector(`[data-drum="${type}"]`);
  if (!pad) return;
  clearTimeout(drumPadTimers.get(type));
  pad.classList.add("active");
  drumPadTimers.set(type, window.setTimeout(() => pad.classList.remove("active"), 90));
}

// ---------- Piano ----------

function buildPiano() {
  elements.piano.replaceChildren();

  for (const noteIndex of WHITE_NOTES) {
    elements.piano.appendChild(createPianoKey(noteIndex, "white"));
  }

  const blackKeyWidth = (100 / WHITE_NOTES.length) * 0.62;
  for (const noteIndex of BLACK_NOTES) {
    const precedingWhiteKeys = WHITE_NOTES.filter((whiteNote) => whiteNote < noteIndex).length;
    const key = createPianoKey(noteIndex, "black");
    key.style.left = `${(precedingWhiteKeys / WHITE_NOTES.length) * 100}%`;
    key.style.width = `${blackKeyWidth}%`;
    key.style.transform = "translateX(-50%)";
    elements.piano.appendChild(key);
  }

  updatePianoLabels();
}

function createPianoKey(noteIndex, color) {
  const key = document.createElement("button");
  key.type = "button";
  key.className = `piano-key ${color}`;
  key.dataset.note = String(noteIndex);
  key.innerHTML = '<span class="note-name"></span><span class="key-name"></span>';

  key.addEventListener("pointerdown", (event) => {
    if (editMappingMode || (event.pointerType === "mouse" && event.button !== 0)) return;
    event.preventDefault();
    const sourceId = `pointer-${event.pointerId}`;
    activePointers.set(event.pointerId, sourceId);
    key.setPointerCapture(event.pointerId);
    startLiveNote(noteIndex, sourceId);
  });

  const releasePointer = (event) => {
    const sourceId = activePointers.get(event.pointerId);
    if (!sourceId) return;
    activePointers.delete(event.pointerId);
    releaseLiveNote(sourceId);
  };

  key.addEventListener("pointerup", releasePointer);
  key.addEventListener("pointercancel", releasePointer);
  key.addEventListener("lostpointercapture", releasePointer);

  key.addEventListener("click", (event) => {
    if (editMappingMode) {
      selectedNoteForMapping = noteIndex;
      updateSelectedMappingKey();
      elements.mappingHelp.textContent =
        `Press a printable key for ${displayedNoteName(noteIndex)}. Space and drum keys are reserved.`;
    } else if (event.detail === 0) {
      // Enter on a focused piano key plays a short accessible note.
      const sourceId = `accessible-${++liveSoundCounter}`;
      startLiveNote(noteIndex, sourceId);
      window.setTimeout(() => releaseLiveNote(sourceId), 180);
    }
  });

  return key;
}

function displayedNoteName(noteIndex) {
  const name = NOTE_NAMES[noteIndex % 12];
  const octave = baseOctave + Math.floor(noteIndex / 12);
  return `${name}${octave}`;
}

function updatePianoLabels() {
  for (const key of elements.piano.querySelectorAll(".piano-key")) {
    const noteIndex = Number(key.dataset.note);
    const mappedKey = keyMapping[noteIndex];
    key.querySelector(".note-name").textContent = displayedNoteName(noteIndex);
    key.querySelector(".key-name").textContent = mappedKey ? mappedKey.toUpperCase() : "—";
    key.setAttribute(
      "aria-label",
      `${displayedNoteName(noteIndex)}, computer key ${mappedKey ? mappedKey.toUpperCase() : "not assigned"}`
    );
  }
}

function addVisualHighlight(noteIndex) {
  visualNoteCounts.set(noteIndex, (visualNoteCounts.get(noteIndex) || 0) + 1);
  updateVisualHighlight(noteIndex);
}

function removeVisualHighlight(noteIndex) {
  const count = (visualNoteCounts.get(noteIndex) || 0) - 1;
  if (count > 0) visualNoteCounts.set(noteIndex, count);
  else visualNoteCounts.delete(noteIndex);
  updateVisualHighlight(noteIndex);
}

function updateVisualHighlight(noteIndex) {
  const key = elements.piano.querySelector(`[data-note="${noteIndex}"]`);
  if (key) key.classList.toggle("active", visualNoteCounts.has(noteIndex));
}

function updateSelectedMappingKey() {
  for (const key of elements.piano.querySelectorAll(".piano-key")) {
    key.classList.toggle("selected", Number(key.dataset.note) === selectedNoteForMapping);
  }
}

// ---------- Keyboard mapping ----------

function rebuildKeyMap() {
  keyToNote = new Map();
  keyMapping.forEach((key, noteIndex) => {
    if (key) keyToNote.set(key, noteIndex);
  });
}

function assignKeyToNote(computerKey, noteIndex) {
  keyMapping = keyMapping.map((key) => (key === computerKey ? "" : key));
  keyMapping[noteIndex] = computerKey;
  rebuildKeyMap();
  updatePianoLabels();
  selectedNoteForMapping = null;
  updateSelectedMappingKey();
  elements.mappingHelp.textContent =
    `Mapped ${computerKey.toUpperCase()} to ${displayedNoteName(noteIndex)}. Select another piano key to continue.`;
}

function resetMapping() {
  keyMapping = [...DEFAULT_MAPPING];
  rebuildKeyMap();
  updatePianoLabels();
  selectedNoteForMapping = null;
  updateSelectedMappingKey();
  elements.mappingHelp.innerHTML =
    "Lower: Z S X D C V G B H N J M &nbsp; Upper: Q 2 W 3 E R 5 T 6 Y 7 U I";
}

// ---------- Live notes and sustain ----------

function startLiveNote(noteIndex, sourceId) {
  if (liveNotes.has(sourceId)) finishLiveNote(sourceId);

  const soundId = `live-${++liveSoundCounter}`;
  const midiNumber = noteIndexToMidi(noteIndex);
  const sound = getSoundSettings();
  if (!startVoice(soundId, noteIndex, midiNumber, sound)) return;

  heldSources.add(sourceId);
  const liveNote = { soundId, noteIndex, recordId: null };
  if (isRecording) {
    liveNote.recordId = ++recordEventId;
    addRecordedEvent({ type: "on", id: liveNote.recordId, noteIndex, midiNumber, sound });
  }
  liveNotes.set(sourceId, liveNote);
}

function releaseLiveNote(sourceId) {
  heldSources.delete(sourceId);
  if (!sustainOn) finishLiveNote(sourceId);
}

function finishLiveNote(sourceId, immediate = false) {
  const liveNote = liveNotes.get(sourceId);
  if (!liveNote) return;
  if (immediate) stopVoiceImmediately(liveNote.soundId);
  else releaseVoice(liveNote.soundId);

  if (isRecording && liveNote.recordId !== null) {
    addRecordedEvent({ type: "off", id: liveNote.recordId, noteIndex: liveNote.noteIndex });
  }
  liveNotes.delete(sourceId);
  heldSources.delete(sourceId);
}

function setSustain(enabled) {
  sustainOn = enabled;
  elements.sustain.textContent = enabled ? "Sustain: ON" : "Sustain: OFF";
  elements.sustain.classList.toggle("active", enabled);
  elements.sustain.setAttribute("aria-pressed", String(enabled));

  if (!enabled) {
    for (const sourceId of [...liveNotes.keys()]) {
      if (!heldSources.has(sourceId)) finishLiveNote(sourceId);
    }
  }
}

function releaseAllLiveInputs(immediate = false) {
  pressedKeys.clear();
  pressedDrumKeys.clear();
  activePointers.clear();
  heldSources.clear();
  for (const sourceId of [...liveNotes.keys()]) finishLiveNote(sourceId, immediate);
}

function stopAllSoundsImmediately() {
  releaseAllLiveInputs(true);
  for (const id of [...voices.keys()]) stopVoiceImmediately(id);
  for (const id of [...drumVoices.keys()]) stopDrumImmediately(id);
  visualNoteCounts.clear();
  for (const key of elements.piano.querySelectorAll(".piano-key")) key.classList.remove("active");
}

// ---------- Recording and playback ----------

function startRecording() {
  stopPlayback(true);
  recordedEvents = [];
  recordEventId = 0;
  recordingDuration = 0;
  isRecording = true;
  recordStartTime = performance.now();
  elements.record.classList.add("recording");
  elements.record.setAttribute("aria-pressed", "true");
  setStatus("Recording…");
}

function stopRecording() {
  if (!isRecording) return;

  for (const liveNote of liveNotes.values()) {
    if (liveNote.recordId !== null) {
      addRecordedEvent({ type: "off", id: liveNote.recordId, noteIndex: liveNote.noteIndex });
      liveNote.recordId = null;
    }
  }

  recordingDuration = performance.now() - recordStartTime;
  isRecording = false;
  elements.record.classList.remove("recording");
  elements.record.setAttribute("aria-pressed", "false");
  const eventCount = recordedEvents.filter((event) => event.type === "on" || event.type === "drum").length;
  setStatus(eventCount ? `Recorded ${eventCount} ${eventCount === 1 ? "hit" : "hits"}.` : "No notes or drums recorded.");
}

function addRecordedEvent(event) {
  recordedEvents.push({ ...event, time: performance.now() - recordStartTime });
}

function startPlayback() {
  if (isRecording) stopRecording();
  if (!recordedEvents.some((event) => event.type === "on" || event.type === "drum")) {
    setStatus("Nothing recorded yet.");
    return;
  }

  stopPlayback(true);
  isPlaying = true;
  playbackCycle = 0;
  elements.play.classList.add("active");
  elements.play.setAttribute("aria-pressed", "true");
  setStatus("Playing…");
  schedulePlaybackCycle();
}

function scheduleTimer(callback, delay) {
  const timer = window.setTimeout(() => {
    playbackTimers.delete(timer);
    callback();
  }, delay);
  playbackTimers.add(timer);
}

function schedulePlaybackCycle() {
  if (!isPlaying) return;
  const cycleId = ++playbackCycle;

  for (const event of recordedEvents) {
    scheduleTimer(() => {
      if (!isPlaying) return;
      const soundId = `play-${cycleId}-${event.id}`;
      if (event.type === "on") startVoice(soundId, event.noteIndex, event.midiNumber, event.sound);
      else if (event.type === "off") releaseVoice(soundId);
      else if (event.type === "drum") triggerDrum(event.drumType, { id: soundId, record: false });
    }, event.time);
  }

  scheduleTimer(() => {
    if (!isPlaying) return;
    if (elements.loop.checked) schedulePlaybackCycle();
    else {
      stopPlayback(false);
      setStatus("Playback finished.");
    }
  }, getRecordingLength());
}

function getRecordingLength() {
  const finalEventTime = Math.max(...recordedEvents.map((event) => event.time));
  return Math.max(100, recordingDuration, finalEventTime + 30);
}

function stopPlayback(silenceVoices = true) {
  isPlaying = false;
  for (const timer of playbackTimers) clearTimeout(timer);
  playbackTimers.clear();
  elements.play.classList.remove("active");
  elements.play.setAttribute("aria-pressed", "false");

  if (silenceVoices) {
    for (const id of [...voices.keys()]) {
      if (id.startsWith("play-")) stopVoiceImmediately(id);
    }
    for (const id of [...drumVoices.keys()]) {
      if (id.startsWith("play-")) stopDrumImmediately(id);
    }
  }
}

// ---------- Controls ----------

elements.record.addEventListener("click", () => (isRecording ? stopRecording() : startRecording()));
elements.play.addEventListener("click", startPlayback);
elements.stop.addEventListener("click", () => {
  stopRecording();
  stopPlayback(true);
  stopAllSoundsImmediately();
  setStatus("Stopped.");
});

elements.sustain.addEventListener("click", () => setSustain(!sustainOn));

elements.drumPads.addEventListener("click", (event) => {
  const pad = event.target.closest("[data-drum]");
  if (pad) triggerDrum(pad.dataset.drum);
});

elements.editMapping.addEventListener("click", () => {
  editMappingMode = !editMappingMode;
  selectedNoteForMapping = null;
  releaseAllLiveInputs();
  elements.editMapping.textContent = `Edit mapping: ${editMappingMode ? "ON" : "OFF"}`;
  elements.editMapping.classList.toggle("active", editMappingMode);
  elements.editMapping.setAttribute("aria-pressed", String(editMappingMode));
  updateSelectedMappingKey();
  elements.mappingHelp.textContent = editMappingMode
    ? "Select a piano key, then press a printable key. Space and 1, 4, 8, 0 are reserved."
    : "Play with the two keyboard rows shown on the piano.";
});

elements.resetMapping.addEventListener("click", resetMapping);
elements.octaveDown.addEventListener("click", () => changeOctave(-1));
elements.octaveUp.addEventListener("click", () => changeOctave(1));

function changeOctave(change) {
  baseOctave = Math.max(1, Math.min(6, baseOctave + change));
  elements.octaveDisplay.textContent = `Range: C${baseOctave}–C${baseOctave + 2}`;
  elements.octaveDown.disabled = baseOctave === 1;
  elements.octaveUp.disabled = baseOctave === 6;
  updatePianoLabels();
}

elements.preset.addEventListener("change", () => {
  const preset = SYNTH_PRESETS[elements.preset.value];
  if (preset.waveform) elements.waveform.value = preset.waveform;
  if (preset.attack !== undefined) elements.attack.value = preset.attack;
  if (preset.release !== undefined) elements.release.value = preset.release;
  if (preset.tone !== undefined) elements.tone.value = preset.tone;
  updateSoundOutputs();
});

elements.waveform.addEventListener("change", () => {
  elements.preset.value = "custom";
});

elements.volume.addEventListener("input", () => {
  const volume = Number(elements.volume.value);
  elements.volumeValue.textContent = volume.toFixed(2);
  if (masterGain && audioContext) masterGain.gain.setTargetAtTime(volume, audioContext.currentTime, 0.01);
});

elements.attack.addEventListener("input", updateSoundOutputs);
elements.release.addEventListener("input", updateSoundOutputs);
elements.tone.addEventListener("input", updateSoundOutputs);

function updateSoundOutputs() {
  elements.attackValue.textContent = `${Number(elements.attack.value).toFixed(2)}s`;
  elements.releaseValue.textContent = `${Number(elements.release.value).toFixed(2)}s`;
  elements.toneValue.textContent = `${Math.round(Number(elements.tone.value) * 100)}%`;
}

// ---------- Computer keyboard ----------

document.addEventListener("keydown", (event) => {
  const computerKey = event.key.toLowerCase();

  if (editMappingMode) {
    if (event.code === "Space") {
      event.preventDefault();
      elements.mappingHelp.textContent = "Spacebar is reserved for sustain.";
      return;
    }

    if (selectedNoteForMapping !== null && !event.ctrlKey && !event.metaKey && !event.altKey) {
      event.preventDefault();
      if (computerKey.length !== 1) {
        elements.mappingHelp.textContent = "Please choose one printable key.";
      } else if (DRUM_KEY_TO_TYPE.has(computerKey)) {
        elements.mappingHelp.textContent = "Keys 1, 4, 8, and 0 are reserved for drums.";
      } else {
        assignKeyToNote(computerKey, selectedNoteForMapping);
      }
    }
    return;
  }

  if (shortcutIsBlockedBy(event.target)) return;
  if (event.code === "Space") {
    event.preventDefault();
    if (!event.repeat) setSustain(!sustainOn);
    return;
  }
  if (event.ctrlKey || event.metaKey || event.altKey || event.repeat) return;

  const drumType = DRUM_KEY_TO_TYPE.get(computerKey);
  if (drumType) {
    event.preventDefault();
    if (!pressedDrumKeys.has(computerKey)) {
      pressedDrumKeys.add(computerKey);
      triggerDrum(drumType);
    }
    return;
  }

  if (pressedKeys.has(computerKey)) return;
  const noteIndex = keyToNote.get(computerKey);
  if (noteIndex === undefined) return;

  event.preventDefault();
  const sourceId = `key-${computerKey}`;
  pressedKeys.set(computerKey, sourceId);
  startLiveNote(noteIndex, sourceId);
});

document.addEventListener("keyup", (event) => {
  const computerKey = event.key.toLowerCase();
  if (pressedDrumKeys.delete(computerKey)) {
    event.preventDefault();
    return;
  }

  const sourceId = pressedKeys.get(computerKey);
  if (!sourceId) return;
  event.preventDefault();
  pressedKeys.delete(computerKey);
  releaseLiveNote(sourceId);
});

function shortcutIsBlockedBy(target) {
  return target instanceof Element && Boolean(target.closest("input, select, textarea, button:not(.piano-key)"));
}

window.addEventListener("blur", () => releaseAllLiveInputs());

function setStatus(message) {
  elements.status.textContent = message;
}

// ---------- Start ----------

rebuildKeyMap();
buildPiano();
changeOctave(0);
updateSoundOutputs();
