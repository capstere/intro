﻿# Get-MatVariables.ps1 — Datadriven ersättning för get-matvariables switch
# Läser från ProductCatalog.psd1 istället för hårdkodad switch.
# Dot-sourca denna fil från AutoMappScript.ps1

$script:_ProductCatalog = $null
$script:_ProductCatalogPath = $null

function _EnsureCatalogLoaded {
    if ($script:_ProductCatalog) { return }
    $candidates = @(
        (Join-Path $PSScriptRoot 'ProductCatalog.psd1'),
        (Join-Path $PSScriptRoot 'SharedData\ProductCatalog.psd1')
    )
    foreach ($cp in $candidates) {
        if (Test-Path -LiteralPath $cp) {
            $script:_ProductCatalog = Import-PowerShellDataFile -Path $cp
            $script:_ProductCatalogPath = $cp
            Write-Host "ProductCatalog laddad: $cp ($(@($script:_ProductCatalog.Products).Count) produkter)" -ForegroundColor DarkYellow
            return
        }
    }
    throw "ProductCatalog.psd1 hittades inte. Sökta platser: $($candidates -join ', ')"
}

function get-matvariables ($material) {
    _EnsureCatalogLoaded

    [hashtable]$return = @{}

    # Sök matchande produkt
    $match = $null
    foreach ($p in $script:_ProductCatalog.Products) {
        if ($p.MaterialCodes -contains $material) {
            $match = $p
            break
        }
    }

    if (-not $match) {
        # Default: okänd produkt
        $return.assay = 0
        $return.matrev = 'N/A'
        $return.path = '\\SE.CEPHEID.PRI\Cepheid Sweden\QC\QC-1\IPT\Skiftspecifika dokument\Skift 1\Mahdi\powerpoint\AutoMappscript\NotYet'
        return $return
    }

    # Basväg för mallar
    $mappscriptRoot = '\\SE.CEPHEID.PRI\Cepheid Sweden\QC\QC-1\IPT\1. IPT - KOMMANDE TESTER\Mappscript'

    $return.assay          = $match.Assay
    $return.matrev         = $match.MatRev
    $return.highpos        = $match.HighPos
    $return.ultra          = $match.Ultra
    $return.doublesampling = $match.DoubleSampling
    $return.hpv            = $match.Hpv
    $return.carba          = $match.Carba
    $return.product        = $match.Product
    $return.assayfam       = $match.AssayFam
    $return.sealassay      = $match.SealAssay
    $return.partnr         = $match.PartNr
    $return.na             = $match.Na
    $return.japan          = $match.Japan
    $return.path           = Join-Path $mappscriptRoot $match.TemplatePath

    # Legacy-kompatibilitet (dessa returnerades men sattes aldrig konsekvent)
    $return.assaymtb  = $null
    $return.assayctng = $null
    $return.assayhiv  = $null
    $return.mail      = $null

    return $return
}
