﻿# ProductCatalog.psd1 -- Delad produktdatafil
# Extraherad fran AutoMappScript.ps1 get-matvariables (2026-03-14)
# Anvands av: AutoMappScript.ps1, IPTCompile (valfritt)
@{
    Products = @(
        @{
            MaterialCodes  = @('XPRSARS-COV2-10', 'D39525')
            Assay          = 'XPRSARS COV2'
            PartNr         = '700-9246'
            MatRev         = 'D39525'
            SealAssay      = 'SARS CoV2'
            Product        = 'XPRSARSCOV210'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'XPRSARS-COV2-10'
        }
        @{
            MaterialCodes  = @('XP3SARS-COV2-10', 'D48538')
            Assay          = 'XP3 SARS COV2'
            PartNr         = '700-7425'
            MatRev         = 'D48538'
            SealAssay      = 'Xpress CoV-2 plus'
            Product        = 'XP3SARSCOV210'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'XP3 SARS COV2'
        }
        @{
            MaterialCodes  = @('XPRS-COV2-10', 'D48538')
            Assay          = 'XPRS COV2'
            PartNr         = '700-8085'
            MatRev         = 'D48538'
            SealAssay      = 'Xpress CoV-2 plus'
            Product        = 'XPRSCOV210'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'XP3 SARS COV2'
        }
        @{
            MaterialCodes  = @('XPRS-COV2-CE-10', 'D48538')
            Assay          = 'XPRS COV2'
            PartNr         = '700-8086'
            MatRev         = 'D48538'
            SealAssay      = 'Xpress CoV-2 plus'
            Product        = 'XPRSCOV2CE10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'XP3 SARS COV2'
        }
        @{
            MaterialCodes  = @('XPCOV2/FLU/RSV-10 deaad', 'D41929')
            Assay          = 'XPCOV2 FLU RSV'
            PartNr         = '700-6990'
            MatRev         = 'D41929'
            SealAssay      = 'SARS CoV2 Flu/RSV'
            Product        = 'XPCOV2FLURSV10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'XPRSARS-COV2 FLU RSV'
        }
        @{
            MaterialCodes  = @('XP3COV2/FLU/RSV-10', 'D47377')
            Assay          = 'XP3 COV2 FLU RSV'
            PartNr         = '700-7493'
            MatRev         = 'D47377'
            SealAssay      = 'Xpress CoV-2/Flu/RSV plus'
            Product        = 'XP3COV2FLURSV10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'XP3 SARS-COV2 FLU RSV plus'
        }
        @{
            MaterialCodes  = @('XPRS4PLEX-10', 'D47377')
            Assay          = 'XPRS COV2 PLEX'
            PartNr         = '700-7906'
            MatRev         = 'D47377'
            SealAssay      = 'Xpress CoV-2/Flu/RSV plus'
            Product        = 'XPRS4PLEX10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'XP3 SARS-COV2 FLU RSV plus'
        }
        @{
            MaterialCodes  = @('XPRS4PLEX-CE-10', 'D47377')
            Assay          = 'XPRS COV2 PLEX'
            PartNr         = '700-7903'
            MatRev         = 'D47377'
            SealAssay      = 'Xpress CoV-2/Flu/RSV plus'
            Product        = 'XPRS4PLEXCE10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'XP3 SARS-COV2 FLU RSV plus'
        }
        @{
            MaterialCodes  = @('GXMTB/RIF-ULTRA-50', 'D25862')
            Assay          = 'GXMTB RIF ULTRA'
            PartNr         = '700-5702'
            MatRev         = 'D25862'
            SealAssay      = 'MTB'
            Product        = 'GXMTBRIFULTRA50'
            AssayFam       = 'MTB'
            HighPos        = $true
            Ultra          = $true
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'GXMTB RIF-ULTRA'
        }
        @{
            MaterialCodes  = @('GXMTB/RIF-ULTRA-10', 'D25862')
            Assay          = 'GXMTB RIF ULTRA'
            PartNr         = '700-5702'
            MatRev         = 'D25862'
            SealAssay      = 'MTB'
            Product        = 'GXMTBRIFULTRA10'
            AssayFam       = 'MTB'
            HighPos        = $true
            Ultra          = $true
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'GXMTB RIF-ULTRA'
        }
        @{
            MaterialCodes  = @('GXMTBRIF-ULT-CN-10', 'D25862')
            Assay          = 'GXMTB RIF ULTRA CN'
            PartNr         = '700-8749'
            MatRev         = 'D25862'
            SealAssay      = 'MTB'
            Product        = 'GXMTBRIF-ULT-CN-10'
            AssayFam       = 'MTB'
            HighPos        = $true
            Ultra          = $true
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'GXMTB RIF-ULTRA'
        }
        @{
            MaterialCodes  = @('GXMTBRIF-ULT-CN-50', 'D25862')
            Assay          = 'GXMTB RIF ULTRA CN'
            PartNr         = '700-8749'
            MatRev         = 'D25862'
            SealAssay      = 'MTB'
            Product        = 'GXMTBRIF-ULT-CN-50'
            AssayFam       = 'MTB'
            HighPos        = $true
            Ultra          = $true
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'GXMTB RIF-ULTRA'
        }
        @{
            MaterialCodes  = @('GXMTB/XDR-10', 'D37339')
            Assay          = 'MTB XDR'
            PartNr         = '700-6737'
            MatRev         = 'D37339'
            SealAssay      = 'MTB'
            Product        = 'GXMTBXDR10'
            AssayFam       = 'MTB'
            HighPos        = $false
            Ultra          = $true
            DoubleSampling = $true
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'MTB XDR'
        }
        @{
            MaterialCodes  = @('CGXMTB/RIF-50', 'D31503')
            Assay          = 'MTB RIF'
            PartNr         = '700-4006'
            MatRev         = 'D31503'
            SealAssay      = 'MTB'
            Product        = 'CGXMTBRIF50'
            AssayFam       = 'MTB'
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'MTB RIF'
        }
        @{
            MaterialCodes  = @('GXMTB/RIF-50', 'D31503')
            Assay          = 'MTB RIF'
            PartNr         = '700-4006'
            MatRev         = 'D31503'
            SealAssay      = 'MTB'
            Product        = 'GXMTBRIF50'
            AssayFam       = 'MTB'
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'MTB RIF'
        }
        @{
            MaterialCodes  = @('700-6082 ASSY,10 CART POUCH,MTB/RIF,HB, INDIA', 'D31503')
            Assay          = 'MTB MII'
            PartNr         = '700-4006'
            MatRev         = 'D31503'
            SealAssay      = 'MTB'
            Product        = '700-6082'
            AssayFam       = 'MTB'
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'MTB RIF'
        }
        @{
            MaterialCodes  = @('GXMTB/RIF-10', 'D31503')
            Assay          = 'MTB RIF'
            PartNr         = '700-4006'
            MatRev         = 'D31503'
            SealAssay      = 'MTB'
            Product        = 'GXMTBRIF10'
            AssayFam       = 'MTB'
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'MTB RIF'
        }
        @{
            MaterialCodes  = @('CGXMTB/RIF-10', 'D31503')
            Assay          = 'MTB RIF'
            PartNr         = '700-4006'
            MatRev         = 'D31503'
            SealAssay      = 'MTB'
            Product        = 'CGXMTBRIF10'
            AssayFam       = 'MTB'
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'MTB RIF'
        }
        @{
            MaterialCodes  = @('GXMTB/RIF-CN-50', 'D31503')
            Assay          = 'MTB RIF CN'
            PartNr         = '700-9074'
            MatRev         = 'D31503'
            SealAssay      = 'MTB'
            Product        = 'GXMTBRIFCN50'
            AssayFam       = 'MTB'
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'MTB RIF'
        }
        @{
            MaterialCodes  = @('GXMTB/RIF-CN-10', 'D31503')
            Assay          = 'MTB RIF CN'
            PartNr         = '700-9074'
            MatRev         = 'D31503'
            SealAssay      = 'MTB'
            Product        = 'GXMTBRIFCN10'
            AssayFam       = 'MTB'
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'MTB RIF'
        }
        @{
            MaterialCodes  = @('700-7773', 'D31503')
            Assay          = 'MTB RIF'
            PartNr         = '700-4006'
            MatRev         = 'D31503'
            SealAssay      = 'MTB'
            Product        = '700-7773'
            AssayFam       = 'MTB'
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'MTB RIF'
        }
        @{
            MaterialCodes  = @('GXCT/NG-10', 'D16904')
            Assay          = 'CT NG'
            PartNr         = '700-5097'
            MatRev         = 'D16904'
            SealAssay      = 'CTNG and Xpress CT/NG'
            Product        = 'GXCTNG10'
            AssayFam       = 'CTNG'
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'CT NG'
        }
        @{
            MaterialCodes  = @('GXCT/NG-CE-10', 'D16904')
            Assay          = 'CT NG'
            PartNr         = '700-5097'
            MatRev         = 'D16904'
            SealAssay      = 'CTNG and Xpress CT/NG'
            Product        = 'GXCTNGCE10'
            AssayFam       = 'CTNG'
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'CT NG'
        }
        @{
            MaterialCodes  = @('GXCT/NGX-CE-10', 'D16904')
            Assay          = 'CT NGX'
            PartNr         = '700-5097'
            MatRev         = 'D16904'
            SealAssay      = 'CTNG and Xpress CT/NG'
            Product        = 'GXCTNGXCE10'
            AssayFam       = 'CTNG'
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'CT NG'
        }
        @{
            MaterialCodes  = @('GXCT/NG-CN-10', 'D16904')
            Assay          = 'CTNG CN'
            PartNr         = '700-9076'
            MatRev         = 'D16904'
            SealAssay      = 'CTNG and Xpress CT/NG'
            Product        = 'GXCTNGCN10'
            AssayFam       = 'CTNG'
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'CT NG'
        }
        @{
            MaterialCodes  = @('GXCT/NG-CE-120', 'D16904')
            Assay          = 'CTNG'
            PartNr         = '700-5097'
            MatRev         = 'D16904'
            SealAssay      = 'CTNG and Xpress CT/NG'
            Product        = 'GXCTNGCE120'
            AssayFam       = 'CTNG'
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'CT NG'
        }
        @{
            MaterialCodes  = @('GXMRSA-NXG-CE-10', 'D23916')
            Assay          = 'MRSA NXG'
            PartNr         = '700-4881'
            MatRev         = 'D23916'
            SealAssay      = 'MRSA'
            Product        = 'GXMRSANXGCE10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'GXMRSA NXG'
        }
        @{
            MaterialCodes  = @('GXSACOMP-CN-10', 'D36872')
            Assay          = 'SA COMP CN'
            PartNr         = '700-9132'
            MatRev         = 'D36872'
            SealAssay      = 'SA Comp'
            Product        = 'GXSACOMP-CN-10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'MRSA SA'
        }
        @{
            MaterialCodes  = @('GXSACOMP-CE-10', 'D36872')
            Assay          = 'SA COMP'
            PartNr         = '700-4023'
            MatRev         = 'D36872'
            SealAssay      = 'SA Comp'
            Product        = 'GXSACOMP-CE-10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'MRSA SA'
        }
        @{
            MaterialCodes  = @('GXMRSA/SA-SSTI-CE', 'D36872')
            Assay          = 'MRSA SA SSTI'
            PartNr         = '700-3874'
            MatRev         = 'D36872'
            SealAssay      = 'MRSA'
            Product        = 'GXMRSA/SA-SSTI-CE'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'MRSA SA'
        }
        @{
            MaterialCodes  = @('GXMRSA/SA-BC-CE-10', 'D36872')
            Assay          = 'MRSA SA BC'
            PartNr         = '700-3875'
            MatRev         = 'D36872'
            SealAssay      = 'MRSA'
            Product        = 'GXMRSA/SA-BC-CE-10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'MRSA SA'
        }
        @{
            MaterialCodes  = @('GXCDIFFBT-CE-10', 'D37468')
            Assay          = 'C. DIFF BT'
            PartNr         = '700-5178'
            MatRev         = 'D37468'
            SealAssay      = 'C. Diff'
            Product        = 'GXCDIFFBTCE10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'C. Difficile'
        }
        @{
            MaterialCodes  = @('GXCDIFFICILE-CE-10', 'D37468')
            Assay          = 'C. DIFF'
            PartNr         = '700-5102'
            MatRev         = 'D37468'
            SealAssay      = 'C. Diff'
            Product        = 'GXCDIFFICILECE10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'C. Difficile'
        }
        @{
            MaterialCodes  = @('GXCDIFFICILE-CN-10', 'D37468')
            Assay          = 'C. DIFF'
            PartNr         = '700-5102'
            MatRev         = 'D37468'
            SealAssay      = 'C. Diff'
            Product        = 'GXCDIFFICILECN10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'C. Difficile'
        }
        @{
            MaterialCodes  = @('GXHIV-VL-CE-10', 'D51110')
            Assay          = 'HIV VL'
            PartNr         = '700-4370'
            MatRev         = 'D51110'
            SealAssay      = 'HIV'
            Product        = 'GXHIV-VL-CE-10'
            AssayFam       = 'HIV'
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'HIV VL'
        }
        @{
            MaterialCodes  = @('GXHIV-VL-CN-10', 'D51110')
            Assay          = 'HIV VL CN'
            PartNr         = '700-4370'
            MatRev         = 'D51110'
            SealAssay      = 'HIV'
            Product        = 'GXHIV-VL-CN-10'
            AssayFam       = 'HIV'
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'HIV VL'
        }
        @{
            MaterialCodes  = @('GXHIV-VL-IN-10', 'D51110')
            Assay          = 'HIV VL IN'
            PartNr         = '700-4370'
            MatRev         = 'D51110'
            SealAssay      = 'HIV'
            Product        = 'GXHIV-VL-IN-10'
            AssayFam       = 'HIV'
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'HIV VL'
        }
        @{
            MaterialCodes  = @('GXHIV-VL-XC-CE-10', 'D51111')
            Assay          = 'HIV VL XC'
            PartNr         = '700-6646'
            MatRev         = 'D51111'
            SealAssay      = 'HIV'
            Product        = 'GXHIV-VL-XC-CE-10'
            AssayFam       = 'HIV'
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'HIV VL XC'
        }
        @{
            MaterialCodes  = @('GXHIV-VL-XC-CN-10', 'D84316')
            Assay          = 'HIV VL XC CN'
            PartNr         = '700-9704'
            MatRev         = 'D84316'
            SealAssay      = 'HIV'
            Product        = 'GXHIV-VL-XC-CN-10'
            AssayFam       = 'HIV'
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'HIV VL XC CN'
        }
        @{
            MaterialCodes  = @('GXHIV-VL-XC-CA-10', 'D79377')
            Assay          = 'HIV VL XC CA'
            PartNr         = '700-6646'
            MatRev         = 'D79377'
            SealAssay      = 'HIV'
            Product        = 'GXHIV-VL-XC-CA-10'
            AssayFam       = 'HIV'
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'HIV VL XC CA'
        }
        @{
            MaterialCodes  = @('GXHIV-QA-CE-10', 'D61353')
            Assay          = 'HIV QA'
            PartNr         = '700-4369'
            MatRev         = 'D61353'
            SealAssay      = 'HIV'
            Product        = 'GXHIV-QA-CE-10'
            AssayFam       = 'HIV'
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'HIV QA'
        }
        @{
            MaterialCodes  = @('GXHIV-QA-XC-CE-10', 'D36985')
            Assay          = 'HIV QA XC'
            PartNr         = '700-6793'
            MatRev         = 'D36985'
            SealAssay      = 'HIV'
            Product        = '700-6793/ HIV-1 QUAL XC, CE-IVD'
            AssayFam       = 'HIV'
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'HIV QA XC'
        }
        @{
            MaterialCodes  = @('GXHIV-QA-XC-CN-10', 'D83056')
            Assay          = 'HIV QA XC CN'
            PartNr         = '700-9658'
            MatRev         = 'D83056'
            SealAssay      = 'HIV'
            Product        = '700-9658/ HIV-1 QUAL XC, CN'
            AssayFam       = 'HIV'
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'HIV QA XC CN'
        }
        @{
            MaterialCodes  = @('GXHBV-VL-CE-10', 'D51114')
            Assay          = 'HBV VL'
            PartNr         = '700-5720'
            MatRev         = 'D51114'
            SealAssay      = 'HBV'
            Product        = 'GXHBV-VL-CE-10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'HBV VL'
        }
        @{
            MaterialCodes  = @('GXHBV-VL-CN-10', 'D51114')
            Assay          = 'HBV VL'
            PartNr         = '700-9093'
            MatRev         = 'D51114'
            SealAssay      = 'HBV'
            Product        = 'GXHBV-VL-CN-10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'HBV VL'
        }
        @{
            MaterialCodes  = @('GXHPV-CE-10', 'D16546')
            Assay          = 'HPV'
            PartNr         = '700-4148'
            MatRev         = 'D16546'
            SealAssay      = 'HPV'
            Product        = 'GXHPV-CE-10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $true
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'HPV'
        }
        @{
            MaterialCodes  = @('CGXHPV-CE-10', 'D16546')
            Assay          = 'HPV'
            PartNr         = '700-4148'
            MatRev         = 'D16546'
            SealAssay      = 'HPV'
            Product        = 'CGXHPV-CE-10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $true
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'HPV'
        }
        @{
            MaterialCodes  = @('GXHPV2-CE-10', 'D16546')
            Assay          = 'HPV v2'
            PartNr         = '700-8500'
            MatRev         = 'D16546'
            SealAssay      = 'HPV'
            Product        = 'GXHPV2-CE-10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $true
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'HPV'
        }
        @{
            MaterialCodes  = @('GXHCV-VL-CE-10', 'D51112')
            Assay          = 'HCV VL'
            PartNr         = '700-4581'
            MatRev         = 'D51112'
            SealAssay      = 'HCV'
            Product        = 'GXHCV-VL-CE-10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'HCV VL'
        }
        @{
            MaterialCodes  = @('GXHCV-VL-CN-10', 'D51112')
            Assay          = 'HCV VL'
            PartNr         = '700-9113'
            MatRev         = 'D51112'
            SealAssay      = 'HCV'
            Product        = 'GXHCV-VL-CN-10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'HCV VL'
        }
        @{
            MaterialCodes  = @('GXHCV-VL-IN-10', 'D51112')
            Assay          = 'HCV VL'
            PartNr         = '700-4581'
            MatRev         = 'D51112'
            SealAssay      = 'HCV'
            Product        = 'GXHCV-VL-IN-10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'HCV VL'
        }
        @{
            MaterialCodes  = @('GXHCV-FS-CE-10', 'D51113')
            Assay          = 'HCV FS'
            PartNr         = '700-5634'
            MatRev         = 'D51113'
            SealAssay      = 'HCV'
            Product        = 'GXHCV-FS-CE-10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'HCV FS'
        }
        @{
            MaterialCodes  = @('GXCARBARP-CE-10', 'D18272')
            Assay          = 'CARBA'
            PartNr         = '700-5014'
            MatRev         = 'D18272'
            SealAssay      = 'Carba-R'
            Product        = 'GXCARBARPCE10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $true
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'CARBA-R'
        }
        @{
            MaterialCodes  = @('GXCARBARP-CE-120', 'D18272')
            Assay          = 'CARBA'
            PartNr         = '700-5014'
            MatRev         = 'D18272'
            SealAssay      = 'Carba-R'
            Product        = 'GXCARBARPCE120'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $true
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'CARBA-R'
        }
        @{
            MaterialCodes  = @('GXCARBAR-CE-10', 'D18272')
            Assay          = 'CARBA'
            PartNr         = '700-4186'
            MatRev         = 'D18272'
            SealAssay      = 'Carba-R'
            Product        = 'GXCARBARCE10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $true
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'CARBA-R'
        }
        @{
            MaterialCodes  = @('GXVANA/B-CE-10', 'D55782')
            Assay          = 'VAN AB'
            PartNr         = '700-3882'
            MatRev         = 'D55782'
            SealAssay      = 'Van A'
            Product        = 'GXVANA/B-CE-10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'VANA-VANB'
        }
        @{
            MaterialCodes  = @('XPRSTREPA-CE-10', 'D27089')
            Assay          = 'STREP A'
            PartNr         = '700-5360'
            MatRev         = 'D27089'
            SealAssay      = 'Strep A'
            Product        = 'XPRSTREPA-CE-10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'STREP A'
        }
        @{
            MaterialCodes  = @('XPRSTREPA-10', 'D27089')
            Assay          = 'STREP A'
            PartNr         = '700-5420'
            MatRev         = 'D27089'
            SealAssay      = 'Strep A'
            Product        = 'XPRSTREPA-10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'STREP A'
        }
        @{
            MaterialCodes  = @('XPRSFLU/RSV-CE-10', 'D26120')
            Assay          = 'FLURSV'
            PartNr         = '700-5164'
            MatRev         = 'D26120'
            SealAssay      = 'Flu'
            Product        = 'XPRSFLURSVCE10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'FLU'
        }
        @{
            MaterialCodes  = @('XPRSFLU-10', 'D26120')
            Assay          = 'FLU'
            PartNr         = '700-5260'
            MatRev         = 'D26120'
            SealAssay      = 'Flu'
            Product        = 'XPRSFLU10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'FLU'
        }
        @{
            MaterialCodes  = @('XPRSFLU/RSV-10', 'D26120')
            Assay          = 'FLURSV'
            PartNr         = '700-5252'
            MatRev         = 'D26120'
            SealAssay      = 'Flu'
            Product        = 'XPRSFLURSV10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'FLU'
        }
        @{
            MaterialCodes  = @('GXNOV-CE-10', 'D17716')
            Assay          = 'NORO'
            PartNr         = '700-4147'
            MatRev         = 'D17716'
            SealAssay      = 'Norovirus'
            Product        = 'GXNOV-CE-10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'Xpert Norovirus'
        }
        @{
            MaterialCodes  = @('GXNOV-10', 'D17716')
            Assay          = 'NORO'
            PartNr         = '700-4147'
            MatRev         = 'D17716'
            SealAssay      = 'Norovirus'
            Product        = 'GXNOV-10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'Xpert Norovirus'
        }
        @{
            MaterialCodes  = @('GXNOV-GB-10', 'D17716')
            Assay          = 'NORO'
            PartNr         = '700-9547'
            MatRev         = 'D17716'
            SealAssay      = 'Norovirus'
            Product        = 'GXNOV-GB-10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'Xpert Norovirus'
        }
        @{
            MaterialCodes  = @('GXEBOLA-CE-10', 'D21938')
            Assay          = 'EBOLA'
            PartNr         = '700-4731'
            MatRev         = 'D21938'
            SealAssay      = 'Ebola'
            Product        = 'GXEBOLA-CE-10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'Ebola'
        }
        @{
            MaterialCodes  = @('GXEBOLA-CE-50', 'D21938')
            Assay          = 'EBOLA'
            PartNr         = '700-4731'
            MatRev         = 'D21938'
            SealAssay      = 'Ebola'
            Product        = 'GXEBOLA-CE-50'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'Ebola'
        }
        @{
            MaterialCodes  = @('GXEBOLA-10', 'D21938')
            Assay          = 'EBOLA'
            PartNr         = '700-4671'
            MatRev         = 'D21938'
            SealAssay      = 'Ebola'
            Product        = 'GXEBOLA-10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'Ebola'
        }
        @{
            MaterialCodes  = @('XPRSGBS-10', 'D68620')
            Assay          = 'GBS US'
            PartNr         = '700-7296'
            MatRev         = 'D68620'
            SealAssay      = 'GBS'
            Product        = 'XPRSGBS-10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $true
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'GBS US IVD'
        }
        @{
            MaterialCodes  = @('XPRSGBS-CE-10', 'D37988')
            Assay          = 'GBS CE'
            PartNr         = '700-7295'
            MatRev         = 'D37988'
            SealAssay      = 'GBS'
            Product        = 'XPRSGBS-CE-10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $true
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'GBS CE'
        }
        @{
            MaterialCodes  = @('GXGBSLBXC-10', 'D68621')
            Assay          = 'GBS LB XC'
            PartNr         = '700-7275'
            MatRev         = 'D68621'
            SealAssay      = 'GBS'
            Product        = 'GXGBSLBXC-10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'GBS CE'
        }
        @{
            MaterialCodes  = @('GXGBSLBXC-120', 'D68621')
            Assay          = 'GBS LB XC'
            PartNr         = '700-7275'
            MatRev         = 'D68621'
            SealAssay      = 'GBS'
            Product        = 'GXGBSLBXC-120'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'GBS LB XC'
        }
        @{
            MaterialCodes  = @('EDGETAP-10', 'D69129')
            Assay          = 'TAP Panel'
            PartNr         = 'N/A NOT RELEASED YET'
            MatRev         = 'D69129'
            SealAssay      = 'Xpert TAP Panel'
            Product        = 'EDGETAP-10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $true
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = $null
            TemplatePath   = 'TAP Panel'
        }
        @{
            MaterialCodes  = @('GXGI-10', 'D55989')
            Assay          = 'GI PANEL'
            PartNr         = '700-9454'
            MatRev         = 'D55989'
            SealAssay      = 'Xpert GI Panel'
            Product        = 'GXGI-10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $false
            DoubleSampling = $true
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'GI PANEL'
        }
        @{
            MaterialCodes  = @('GXGI-CE-10', 'D55989')
            Assay          = 'GI PANEL'
            PartNr         = '700-9467'
            MatRev         = 'D55989'
            SealAssay      = 'Xpert GI Panel'
            Product        = 'GXGI-CE-10'
            AssayFam       = ''
            HighPos        = $false
            Ultra          = $true
            DoubleSampling = $true
            Hpv            = $false
            Carba          = $false
            Na             = 'NA'
            Japan          = $null
            TemplatePath   = 'GI PANEL'
        }
        @{
            MaterialCodes  = @('GXMTB/RIF-JP-10', 'D66612')
            Assay          = 'MTB RIF JP'
            PartNr         = '700-4676'
            MatRev         = 'D66612'
            SealAssay      = 'MTB'
            Product        = 'GXMTB/RIF-JP-10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = 'MTB'
            TemplatePath   = 'MTB JP'
        }
        @{
            MaterialCodes  = @('GXCDIFF-JP-10', 'D66613')
            Assay          = 'C.DIFF JP'
            PartNr         = '700-5102'
            MatRev         = 'D66613'
            SealAssay      = 'C. Diff'
            Product        = 'GXCDIFF-JP-10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = 'CDIFF'
            TemplatePath   = 'C.Diff JP'
        }
        @{
            MaterialCodes  = @('GXSACOMP-JP-10', 'D66614')
            Assay          = 'SA COMP JP'
            PartNr         = '700-4023'
            MatRev         = 'D66614'
            SealAssay      = 'SA Comp'
            Product        = 'GXSACOMP-JP-10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = 'MRSA'
            TemplatePath   = 'MRSA JP'
        }
        @{
            MaterialCodes  = @('GXCT/NG-JP-10', 'D66615')
            Assay          = 'CTNG JP'
            PartNr         = '700-5097'
            MatRev         = 'D66615'
            SealAssay      = 'CTNG and Xpress CT/NG'
            Product        = 'GXCT/NG-JP-10'
            AssayFam       = ''
            HighPos        = $true
            Ultra          = $false
            DoubleSampling = $false
            Hpv            = $false
            Carba          = $false
            Na             = 'N/A'
            Japan          = 'CTNG'
            TemplatePath   = 'CTNG JP'
        }
    )
}