Corrected screen files for your app.

What I fixed:

scrHome
- Search now tries exact match first and goes directly to scrLots when possible.
- If no exact match is found, it goes to scrSearchResults.

scrSearchResults
- IsActive filter now matches your SharePoint text values: "Yes" / "No"
- Back button now always goes to scrHome
- Empty-state label text corrected

scrLots
- Gallery now shows ThisItem.LotNumber instead of ThisItem.Title
- lblNoLots moved outside the gallery
- All edit-panel labels/captions are only visible when ctxShowEdit = true
- All delete-dialog labels/captions are only visible when ctxShowDelete = true
- Edit panel height adjusted so the buttons fit inside
- Safe duplicate-check pattern kept with _currentID:
  LookUp(CM_Lots, LotKey = _lotKey && ID <> _currentID)

Still important:
- Your App.OnStart should initialize these variables:
  Set(varSource, Blank());
  Set(varSearchText, Blank());
  Set(varCurrentMaterial, Blank());
  Set(varSelectedLot, Blank());
  Set(varMode, Blank())
