﻿# Safe refactor: extracted function definitions from Main.ps1

function New-ListRow {
    param([string]$labelText,[ref]$lbl,[ref]$clb,[ref]$btn)
    $lbl.Value = New-Object System.Windows.Forms.Label
    $lbl.Value.Text=$labelText
    $lbl.Value.Anchor='Left'
    $lbl.Value.AutoSize=$true
    $lbl.Value.Margin=New-Object System.Windows.Forms.Padding(0,12,6,0)
    $clb.Value = New-Object System.Windows.Forms.CheckedListBox
    $clb.Value.Dock='Fill'
    $clb.Value.Margin=New-Object System.Windows.Forms.Padding(0,6,8,6)
    $clb.Value.Height=70
    $clb.Value.IntegralHeight=$false
    $clb.Value.CheckOnClick = $true
    $clb.Value.DisplayMember = 'Name'

    $btn.Value = New-Object System.Windows.Forms.Button
    $btn.Value.Text='Bläddra…'
    $btn.Value.Dock='Fill'
    $btn.Value.Margin=New-Object System.Windows.Forms.Padding(0,6,0,6)
    Set-AccentButton $btn.Value
}

function Set-ClbWatermark {
    param([System.Windows.Forms.CheckedListBox]$clb, [string]$Text)
    $tag = @{ Watermark = $Text }
    $clb.Tag = $tag
    if ($clb.Items.Count -eq 0) { Show-ClbWatermark $clb }
}

function Show-ClbWatermark {
    param([System.Windows.Forms.CheckedListBox]$clb)
    if (-not $clb.Tag -or -not $clb.Tag.Watermark) { return }
    $clb.ForeColor = [System.Drawing.Color]::Silver
    $clb.Items.Clear()
    [void]$clb.Items.Add($clb.Tag.Watermark)
}

function Hide-ClbWatermark {
    param([System.Windows.Forms.CheckedListBox]$clb)
    if (-not $clb.Tag -or -not $clb.Tag.Watermark) { return }
    $wm = $clb.Tag.Watermark
    for ($wi = $clb.Items.Count - 1; $wi -ge 0; $wi--) {
        try { if (([string]$clb.Items[$wi]) -eq $wm) { $clb.Items.RemoveAt($wi) } } catch {}
    }
    $clb.ForeColor = [System.Drawing.SystemColors]::WindowText
}

function Add-CLBItems {
    param([System.Windows.Forms.CheckedListBox]$clb,[System.IO.FileInfo[]]$files,[switch]$AutoCheckFirst,[switch]$Append)
    Hide-ClbWatermark $clb
    $clb.BeginUpdate()
    if (-not $Append) { $clb.Items.Clear() }
    foreach($f in $files){
        if ($f -isnot [System.IO.FileInfo]) { try { $f = Get-Item -LiteralPath $f } catch { continue } }
        # Undvik dubbletter vid Append
        $alreadyExists = $false
        if ($Append) {
            for ($di = 0; $di -lt $clb.Items.Count; $di++) {
                try { if ([string]$clb.Items[$di].FullName -eq [string]$f.FullName) { $alreadyExists = $true; break } } catch {}
            }
        }
        if (-not $alreadyExists) { [void]$clb.Items.Add($f, $false) }
    }
    $clb.EndUpdate()
    if ($AutoCheckFirst -and $clb.Items.Count -gt 0) { $clb.SetItemChecked(0,$true) }
    if ($clb.Items.Count -eq 0) { Show-ClbWatermark $clb }
    Update-StatusBar
}

function Get-CheckedFilePath { param([System.Windows.Forms.CheckedListBox]$clb)
    if (-not $clb) { return $null }
    for($i=0;$i -lt $clb.Items.Count;$i++){
        if ($clb.GetItemChecked($i)) {
            $fi = [System.IO.FileInfo]$clb.Items[$i]
            return $fi.FullName
        }
    }
    return $null
}

function Get-AllCheckedFilePaths { param([System.Windows.Forms.CheckedListBox]$clb)
    if (-not $clb) { return @() }
    $paths = New-Object 'System.Collections.Generic.List[string]'
    for($i=0;$i -lt $clb.Items.Count;$i++){
        if ($clb.GetItemChecked($i)) {
            $fi = [System.IO.FileInfo]$clb.Items[$i]
            [void]$paths.Add($fi.FullName)
        }
    }
    return @($paths.ToArray())
}

function Clear-GUI {
    $txtLSP.Text = ''
    $txtSammName.Text = ''; $txtSammDate.Text = ''; $txtSealTestSign.Text = ''
    $chkSealTest.Checked = $false; $chkWsSamm.Checked = $false; $chkSignOverwrite.Checked = $false
    $txtGranskName.Text = ''; $txtGranskDate.Text = ''
    $chkWsGransk.Checked = $false; $chkGranskOverwrite.Checked = $false

    # Nollställ ALLA build-relaterade cacher (förhindra cross-kontaminering mellan körningar)
    $script:RobalDateShort          = $null
    $script:RuleEngineShadow        = $null
    $script:RuleEngineShadowRes     = $null
    $script:RuleEngineCsvObjs       = $null
    $script:RuleEngineCsvObjsRes    = $null
    $script:RuleBankCache           = $null
    $script:CsvLinesPrimary         = $null
    $script:CsvLinesResample        = $null
    $script:QcReminderB3            = $null

    Add-CLBItems -clb $clbCsv -files @()
    Add-CLBItems -clb $clbNeg -files @()
    Add-CLBItems -clb $clbPos -files @()
    Add-CLBItems -clb $clbLsp -files @()
    $outputBox.Clear()
    Update-BuildEnabled
    Gui-Log "🧹 Fönstret rensat." 'Info'
    Update-BatchLink
    try { Apply-UserDefaults } catch {}
}

function Get-SelectedFileCount {
    $n = 0

    # CSV kan vara 1–2 filer vid resample
    try {
        if ($clbCsv -and $clbCsv.CheckedItems) { $n += [int]$clbCsv.CheckedItems.Count }
        elseif (Get-CheckedFilePath $clbCsv) { $n++ }
    } catch {
        if (Get-CheckedFilePath $clbCsv) { $n++ }
    }

    if (Get-CheckedFilePath $clbNeg) { $n++ }
    if (Get-CheckedFilePath $clbPos) { $n++ }
    if (Get-CheckedFilePath $clbLsp) { $n++ }
    return $n
}

function Update-StatusBar { $slCount.Text = "$(Get-SelectedFileCount) filer valda" }

function Invoke-UiPump {
    try { [System.Windows.Forms.Application]::DoEvents() } catch {}
}

function Set-UiBusy {
    param(
        [Parameter(Mandatory)][bool]$Busy,
        [string]$Message = ''
    )
    try {
        if ($Busy) {
            $slWork.Text = $Message
            $pbWork.Visible = $true
            $pbWork.Style   = 'Marquee'
            $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
            $btnScan.Enabled  = $false
            $btnBuild.Enabled = $false
        } else {
            $pbWork.Visible = $false
            $pbWork.Style   = 'Blocks'
            $pbWork.Value   = 0
            $slWork.Text = ''
            $form.Cursor = [System.Windows.Forms.Cursors]::Default
            $btnScan.Enabled = $true
            Update-BuildEnabled
        }
        $status.Refresh()
        $form.Refresh()
        Invoke-UiPump
    } catch {}
}

function Set-UiStep {
    param(
        [Parameter(Mandatory)][int]$Percent,
        [string]$Message = ''
    )
    try {
        if ($Percent -lt 0) { $Percent = 0 }
        if ($Percent -gt 100) { $Percent = 100 }
        $slWork.Text = $Message
        $pbWork.Visible = $true
        $pbWork.Style   = 'Blocks'
        $pbWork.Minimum = 0
        $pbWork.Maximum = 100
        if ($pbWork.Value -ne $Percent) { $pbWork.Value = $Percent }
        $status.Refresh()
        $form.Refresh()
        Invoke-UiPump
    } catch {}
}

function Update-BuildEnabled {
    $btnBuild.Enabled = ((Get-CheckedFilePath $clbNeg) -and (Get-CheckedFilePath $clbPos))
    Update-StatusBar
}

