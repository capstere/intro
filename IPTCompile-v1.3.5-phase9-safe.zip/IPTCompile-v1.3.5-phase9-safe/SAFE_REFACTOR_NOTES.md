# SAFE_REFACTOR_NOTES — v1.3.5-phase9-safe

Utgångspunkt: `IPTCompile-v1.3.4-phase8b-hotfix1`

Detta steg gör en **konservativ slimning av `Main.ps1`** utan att flytta top-level runtime-kod.

## Faktiskt gjort

Följande **hela funktionsdefinitioner** har flyttats ut ur `Main.ps1` till nya `App/*`-filer:

### `App/UiHelpers.ps1`
- `New-ListRow`
- `Set-ClbWatermark`
- `Show-ClbWatermark`
- `Hide-ClbWatermark`
- `Add-CLBItems`
- `Get-CheckedFilePath`
- `Get-AllCheckedFilePaths`
- `Clear-GUI`
- `Get-SelectedFileCount`
- `Update-StatusBar`
- `Invoke-UiPump`
- `Set-UiBusy`
- `Set-UiStep`
- `Update-BuildEnabled`

### `App/Bootstrap.ps1`
- `Get-UserProfileFromConfig`
- `Apply-UserDefaults`
- `Assert-StartupReady`
- `Assert-DevUnlocked`

### `App/BuildController.ps1`
- `Get-BatchLinkInfo`
- `Find-LspFolder`
- `Get-DefaultDownloadsPath`
- `Get-DownloadsPathEffective`
- `Get-LspDigitsFromString`
- `Get-UniqueDestinationPath`
- `Get-ProjectStatusData`
- `Move-DownloadedLspFiles`
- `Invoke-ExternalScript`

### `App/UiDialogs.ps1`
- `Show-StyledInfoDialog`
- `Show-ListSelectionDialog`
- `Show-ProjectStatusDialog`
- `Show-FileMoveSelectionDialog`
- `Show-CloseFileToContinueDialog`
- `Ensure-FilesClosedOrCancel`

### `App/UiTheme.ps1`
- `Set-Theme`

## Medvetet ej gjort

- Ingen flytt av top-level WinForms-kod
- Inga `.Add_Click(...)`-block flyttade
- Ingen `Application.Run(...)`-förändring
- Inga ändringar av shim-strukturen från tidigare faser
- `Test-IsBlockedUser`, `_IsActiveSealSheet`, `_GetPerSheetValueObjects`, `_AggregateStatus`, `Update-OverwriteVerificationUI` och `Enable-DoubleBuffer` lämnades kvar i `Main.ps1`

## Konsekvens

`Main.ps1` är nu tunnare men behåller samma runtime-komposition.
