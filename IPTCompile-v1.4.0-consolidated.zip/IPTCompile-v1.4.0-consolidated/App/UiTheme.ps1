﻿# Safe refactor: extracted function definitions from Main.ps1

function Set-Theme {
    param([string]$Theme)
    $global:CurrentTheme = $Theme

    # Datadriven temadefinition – lägg till kontroller här, inte dubbla if/else-block
    $isDark = ($Theme -eq 'dark')
    $bg      = if ($isDark) { [System.Drawing.Color]::FromArgb(35,35,35) }   else { [System.Drawing.Color]::WhiteSmoke }
    $header  = if ($isDark) { [System.Drawing.Color]::DarkSlateBlue }        else { [System.Drawing.Color]::SteelBlue }
    $logBg   = if ($isDark) { [System.Drawing.Color]::FromArgb(45,45,45) }   else { [System.Drawing.Color]::White }
    $boxBg   = if ($isDark) { [System.Drawing.Color]::FromArgb(55,55,55) }   else { [System.Drawing.Color]::White }
    $fg      = if ($isDark) { [System.Drawing.Color]::White }                else { [System.Drawing.Color]::Black }

    # Bakgrundsfärg (ärver $bg)
    foreach ($c in @($form, $content, $grpPick, $grpSignSamm, $grpSignGransk, $flpSammChk, $flpGranskChk, $grpDl, $tlSearch)) {
        if ($c) { $c.BackColor = $bg }
    }
    # Specialfärger
    $panelHeader.BackColor = $header
    $pLog.BackColor        = $logBg
    $outputBox.BackColor   = $boxBg
    $outputBox.ForeColor   = $fg

    # Textfärg (ärver $fg)
    foreach ($c in @($lblLSP, $lblCsv, $lblNeg, $lblPos, $lblLsp, $grpPick, $grpSignSamm, $grpSignGransk, $grpDl, $pLog, $tlSearch)) {
        if ($c) { $c.ForeColor = $fg }
    }
}

