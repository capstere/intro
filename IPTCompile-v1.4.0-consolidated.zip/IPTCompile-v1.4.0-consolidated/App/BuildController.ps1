﻿# Safe refactor: extracted function definitions from Main.ps1

function Get-BatchLinkInfo {
    param(
        [string]$SealPosPath,
        [string]$SealNegPath,
        [string]$Lsp
    )

    $batch = $null
    try { if ($SealPosPath) { $batch = Get-BatchNumberFromSealFile $SealPosPath } } catch {}
    if (-not $batch) {
        try { if ($SealNegPath) { $batch = Get-BatchNumberFromSealFile $SealNegPath } } catch {}
    }

    $batchEsc = if ($batch) { [uri]::EscapeDataString($batch) } else { '' }
    $lspEsc   = if ($Lsp)   { [uri]::EscapeDataString($Lsp) }   else { '' }

    $url = if ($SharePointBatchLinkTemplate) {
        ($SharePointBatchLinkTemplate -replace '\{BatchNumber\}', $batchEsc) -replace '\{LSP\}', $lspEsc
    } else {
        "https://danaher.sharepoint.com/sites/CEP-Sweden-Production-Management/Lists/Cepheid%20%20Production%20orders/AllItems.aspx?view=7&q=$batchEsc"
    }
    $linkText = if ($batch) { "Öppna $batch" } else { 'Ingen batch funnen' }

    return [pscustomobject]@{
        Batch    = $batch
        Url      = $url
        LinkText = $linkText
    }
}

function Find-LspFolder {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)] [string]$Lsp,
        [Parameter(Mandatory)] [string[]]$Roots
    )

    $lspRaw = ($Lsp + '').Trim()
    if (-not $lspRaw) { return $null }

    # Tillåt att användaren skriver t.ex. "#38401" eller "38401" eller "LSP 38401".
    $lspDigits = ($lspRaw -replace '\D', '')
    if (-not $lspDigits) { return $null }

    # Matcha som "eget tal": undvik att 3840 matchar 38401 osv.
    $rxToken = "(?<!\d)#?\s*$lspDigits(?!\d)"

    # Snabb väg: använd -Filter först (fil-systemet kan optimera) + matcha med rxToken för att undvika falska träffar.
    $filters = @("*$lspDigits*", "*#$lspDigits*")

    foreach ($root in $Roots) {
        if (-not $root) { continue }
        if (-not (Test-Path -LiteralPath $root)) { continue }

        # 1) Försök hitta i översta nivån (vanligaste fallet)
        foreach ($f in $filters) {
            try {
                $hit = Get-ChildItem -LiteralPath $root -Directory -Filter $f -ErrorAction SilentlyContinue |
                       Where-Object { $_.Name -match $rxToken } |
                       Select-Object -First 1
                if ($hit) { return $hit }
            } catch {}
        }

        # 2) Försök med -Recurse + -Filter
        foreach ($f in $filters) {
            try {
                $hit = Get-ChildItem -LiteralPath $root -Directory -Recurse -Filter $f -ErrorAction SilentlyContinue |
                       Where-Object { $_.Name -match $rxToken } |
                       Select-Object -First 1
                if ($hit) { return $hit }
            } catch {}
        }

        # 3) Reservväg
        try {
            $hit = Get-ChildItem -LiteralPath $root -Directory -Recurse -ErrorAction SilentlyContinue |
                   Where-Object { $_.Name -match $rxToken } |
                   Select-Object -First 1
            if ($hit) { return $hit }
        } catch {}
    }

    return $null
}

function Get-DefaultDownloadsPath {
    try {
        # Försök använda känd mapp (Shell)
        $d = [Environment]::GetFolderPath('UserProfile')
        if ($d) {
            $cand = Join-Path $d 'Downloads'
            if (Test-Path -LiteralPath $cand) { return $cand }
        }
    } catch {}
    try {
        $cand = Join-Path $env:USERPROFILE 'Downloads'
        if (Test-Path -LiteralPath $cand) { return $cand }
    } catch {}
    return $null
}

function Get-DownloadsPathEffective {
    $cfg = Get-ConfigValue -Name 'DownloadsDir' -Default '' -ConfigOverride $Config
    $cfg = ($cfg + '').Trim()
    if ($cfg) {
        try { if (Test-Path -LiteralPath $cfg) { return $cfg } } catch {}
    }
    return (Get-DefaultDownloadsPath)
}

function Get-LspDigitsFromString {
    param([Parameter(Mandatory=$true)][string]$Text)

    $s = ($Text + '')
    if (-not $s) { return $null }

    # Primär: LSP + exakt 5 siffror
    if ($s -match '(?i)(?<!\d)LSP\D*(\d{5})(?!\d)') { return $matches[1] }

    # Sekundär: bara en fristående 5-siffrig token (t.ex. "#38401" eller " 38401 ")
    if ($s -match '(?i)(?<!\d)#?\s*(\d{5})(?!\d)') { return $matches[1] }

    return $null
}

function Get-UniqueDestinationPath {
    param(
        [Parameter(Mandatory=$true)][string]$DestinationDir,
        [Parameter(Mandatory=$true)][string]$FileName
    )

    $base = [System.IO.Path]::GetFileNameWithoutExtension($FileName)
    $ext  = [System.IO.Path]::GetExtension($FileName)
    $cand = Join-Path $DestinationDir ($base + $ext)
    if (-not (Test-Path -LiteralPath $cand)) { return $cand }

    for ($i=1; $i -le 50; $i++) {
        $cand = Join-Path $DestinationDir ("{0} ({1}){2}" -f $base, $i, $ext)
        if (-not (Test-Path -LiteralPath $cand)) { return $cand }
    }

    $stamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
    return (Join-Path $DestinationDir ("{0} ({1}){2}" -f $base, $stamp, $ext))
}

function Get-ProjectStatusData {
    $statusPath = Join-Path $PSScriptRoot 'StatusBoard.psd1'

    if (Test-Path -LiteralPath $statusPath) {
        try {
            return Import-PowerShellDataFile -Path $statusPath
        } catch {
            Gui-Log "⚠️ Kunde inte läsa StatusBoard.psd1: $($_.Exception.Message)" 'Warn'
        }
    }

    return @{
        LastUpdated = (Get-Date).ToString('yyyy-MM-dd')
        Done        = @('Inga statuspunkter har lagts in ännu.')
        Ongoing     = @()
        Todo        = @()
        Notes       = @('N/A')
    }
}

function Move-DownloadedLspFiles {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][ValidateSet('3','4')][string]$TargetStage
    )

    if (-not (Assert-StartupReady)) { return }
    if ($script:BuildInProgress -or $script:ScanInProgress) {
        Gui-Log "⚠️ Vänta tills pågående operation är klar." 'Warn'
        return
    }

    $downloads = Get-DownloadsPathEffective
    if (-not $downloads -or -not (Test-Path -LiteralPath $downloads)) {
        Gui-Log "❌ Kunde inte hitta Downloads-mappen. (Konfig: DownloadsDir)" 'Error'
        return
    }

    $stageRoot = if ($TargetStage -eq '3') {
        Get-ConfigValue -Name 'Stage3RootPath' -Default (Resolve-IptPath (Join-Path $script:DefaultIptRoot '3. IPT - KLART FÖR SAMMANSTÄLLNING')) -ConfigOverride $Config
    } else {
        Get-ConfigValue -Name 'Stage4RootPath' -Default (Resolve-IptPath (Join-Path $script:DefaultIptRoot '4. IPT - KLART FÖR GRANSKNING')) -ConfigOverride $Config
    }

    if (-not $stageRoot -or -not (Test-Path -LiteralPath $stageRoot)) {
        Gui-Log "❌ Stage-rotmappen saknas: $stageRoot" 'Error'
        return
    }

    # Hämta alla filer i Downloads
    $all = @()
    try { $all = @(Get-ChildItem -LiteralPath $downloads -File -ErrorAction SilentlyContinue) } catch {}
    if (-not $all -or $all.Count -eq 0) {
        Gui-Log "ℹ️ Inga filer i Downloads." 'Info'
        return
    }

    # Gruppera efter LSP-nummer i filnamn
    $groups = @{}
    foreach ($f in $all) {
        $lsp = $null
        try { $lsp = Get-LspDigitsFromString -Text $f.Name } catch { $lsp = $null }
        if (-not $lsp) { continue }
        if (-not $groups.ContainsKey($lsp)) { $groups[$lsp] = New-Object System.Collections.ArrayList }
        [void]$groups[$lsp].Add($f)
    }

    # Filtrera bort "D-prefix" (dokument, inte LSP-filer: D12547, D29447 etc.)
    $dKeys = @($groups.Keys | Where-Object { $_ -and ($_ -match '^\d+$') })
    $toRemove = New-Object 'System.Collections.Generic.List[string]'
    foreach ($gk in $dKeys) {
        $hasOnlyDocs = $true
        foreach ($gf in $groups[$gk]) {
            if ($gf.Name -notmatch ('(?i)^D' + [regex]::Escape($gk))) { $hasOnlyDocs = $false; break }
        }
        if ($hasOnlyDocs) { [void]$toRemove.Add($gk) }
    }
    foreach ($rk in $toRemove) {
        $groups.Remove($rk)
        Gui-Log ("Filtrerade bort D$rk (dokument, inte LSP).") 'Info'
    }

    if ($groups.Keys.Count -eq 0) {
        Gui-Log "ℹ️ Hittade inga filer i Downloads med LSP##### i filnamn." 'Info'
        return
    }

    # Välj LSP: prioritera textfältets värde, sedan automatisk om bara en grupp
    $typed = ($txtLSP.Text + '').Trim()
    $typedDigits = if ($typed) { ($typed -replace '\D','') } else { '' }

    $selectedLsp = $null
    if ($typedDigits -and $groups.ContainsKey($typedDigits)) {
        $selectedLsp = $typedDigits
    } elseif ($groups.Keys.Count -eq 1) {
        $selectedLsp = @($groups.Keys)[0]
    } else {
        $opts = @($groups.Keys | Sort-Object)
        $picked = Show-ListSelectionDialog -Title 'Välj LSP' -Prompt 'Flera LSP hittades i Downloads. Välj vilket som ska flyttas:' -Items $opts
        if (-not $picked) { Gui-Log 'ℹ️ Avbrutet.' 'Info'; return }
        $selectedLsp = $picked
    }

    $files = @(foreach ($item in $groups[$selectedLsp]) { $item })
    if (-not $files -or $files.Count -eq 0) {
        Gui-Log "ℹ️ Inga filer att flytta för LSP$selectedLsp." 'Info'
        return
    }

    # Utöka kandidatlistan: inkludera PDF:er i Downloads som innehåller vissa nyckelord i filnamnet
    # (oavsett om de råkar innehålla LSP-numret eller inte). Detta påverkar ENDAST listning/val i dialogen.
    try {
        $pdfKeywords = @('Additional','QC','Data','SE','LFI')
        $pdfKeywordsLower = @($pdfKeywords | ForEach-Object { (''+$_).ToLowerInvariant() })

        $pdfExtra = New-Object System.Collections.Generic.List[object]
        $pdfAll = Get-ChildItem -LiteralPath $downloads -Filter '*.pdf' -File -ErrorAction SilentlyContinue
        foreach ($p in $pdfAll) {
            $n = ''
            try { $n = ('' + $p.Name).ToLowerInvariant() } catch { $n = '' }
            if (-not $n) { continue }
            $hit = $false
            foreach ($kw in $pdfKeywordsLower) {
                if ($n.Contains($kw)) { $hit = $true; break }
            }
            if ($hit) { [void]$pdfExtra.Add($p) }
        }

        if ($pdfExtra -and $pdfExtra.Count -gt 0) {
            # Merge + dedupe på FullName
            $map = @{}
            foreach ($f in @($files + @($pdfExtra.ToArray()))) {
                try { if ($f -and $f.FullName) { $map[$f.FullName] = $f } } catch {}
            }
            $files = @($map.Values)
        }
    } catch {}

    # Säkerhet: be användaren bekräfta exakt vilka filer som ska flyttas.
    # Default: markera bara typiska Camstar/IPT-filer (csv/xlsx/xlsm/xls). Allt annat kräver aktivt val.
    $pickTitle = if ($TargetStage -eq '3') { 'Flytta till mappen JESP-TEST' } else { 'Flytta till din LSP-mapp i KLART FÖR GRANSKNING' }
    $pickPrompt = "Filer hittades i Downloads för LSP: $selectedLsp. Markera filer som du vill ska flyttas till LSP: $selectedLsp.`n(Auto-markerar matchande filer.)"
    $pickedFiles = Show-FileMoveSelectionDialog -Title $pickTitle -Prompt $pickPrompt -Files $files
    if (-not $pickedFiles -or $pickedFiles.Count -eq 0) {
        Gui-Log "ℹ️ Inga filer valdes – avbryter flytt." 'Info'
        return
   }

    # Spara vilka som inte valdes (för logg)
    $notSelected = New-Object System.Collections.Generic.List[string]
    try {
        $selSet = @{}
        foreach ($pf in $pickedFiles) { try { $selSet[$pf.FullName] = $true } catch {} }
        foreach ($ff in $files) { try { if (-not $selSet.ContainsKey($ff.FullName)) { [void]$notSelected.Add($ff.Name) } } catch {} }
    } catch {}

    $files = @($pickedFiles)

    # Immediate GUI-logg: visa direkt att flytt påbörjas (innan IO börjar)
    try {
        Gui-Log ("⏳ Filer flyttas nu... avvakta. (Valda: {0})" -f $files.Count) 'Info' 'USER'
    } catch {}

    $destFolder = Find-LspFolder -Lsp $selectedLsp -Roots @($stageRoot)
    if (-not $destFolder) {
        Gui-Log "❌ Hittade ingen LSP-mapp för $selectedLsp under: $stageRoot" 'Error'
        return
    }

    Gui-Log ("📥 Downloads: {0}" -f $downloads) 'Info' 'PROGRESS'
    Gui-Log ("📂 Destination: {0}" -f $destFolder.FullName) 'Info' 'PROGRESS'

    $moved   = New-Object System.Collections.Generic.List[string]
    $failed  = New-Object System.Collections.Generic.List[string]
    $skipped = New-Object System.Collections.Generic.List[string]

    foreach ($f in $files | Sort-Object LastWriteTime -Descending) {
        # Kontrollera om filen är låst (öppen i Excel/Preview etc.)
        $lockedAbort = $false
        while ($true) {
            $isLocked = $false
            try { $isLocked = Test-FileLocked $f.FullName } catch {}
            if (-not $isLocked) { break }

            $res = Show-CloseFileToContinueDialog -Path $f.FullName -ExtraHint 'Stäng filen i Excel, OneDrive-preview eller Utforskaren.'
            if ($res -ne [System.Windows.Forms.DialogResult]::Retry) {
                $skipped.Add($f.Name)
                $lockedAbort = $true
                break
            }
            Start-Sleep -Milliseconds 200
        }
        if ($lockedAbort) { continue }

        try {
            $target = Get-UniqueDestinationPath -DestinationDir $destFolder.FullName -FileName $f.Name
            Move-Item -LiteralPath $f.FullName -Destination $target -Force
            $moved.Add((Split-Path -Leaf $target))
        } catch {
            $failed.Add(("{0} -> {1}" -f $f.Name, $_.Exception.Message))
        }
    }

    # Skriv loggfil i destinationen
    try {
        $logName = "MoveLog_LSP{0}_{1}.txt" -f $selectedLsp, (Get-Date).ToString('yyyyMMdd_HHmmss')
        # $logPath = Join-Path $destFolder.FullName $logName
        $logPath = Join-Path $global:LogPath $logName
        $lines = New-Object System.Collections.Generic.List[string]
        $lines.Add(("Timestamp: {0}" -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')))
        $lines.Add(("User: {0}" -f $env:USERNAME))
        $lines.Add(("From: {0}" -f $downloads))
        $lines.Add(("To: {0}" -f $destFolder.FullName))
        $lines.Add('')
        $lines.Add('Moved:')
        foreach ($n in $moved) { $lines.Add("  - $n") }
        if ($skipped.Count -gt 0) {
            $lines.Add('')
            $lines.Add('Skipped (locked):')
            foreach ($s in $skipped) { $lines.Add("  - $s") }
        }
        if ($failed.Count -gt 0) {
            $lines.Add('')
            $lines.Add('Failed:')
            foreach ($e in $failed) { $lines.Add("  - $e") }
        }
        [System.IO.File]::WriteAllLines($logPath, $lines.ToArray(), [System.Text.Encoding]::UTF8)
    } catch {}

    # Summering i GUI-loggen
    if ($moved.Count -gt 0) {
        Gui-Log ("✅ Flyttade {0} fil(er) för LSP{1} till stage {2}." -f $moved.Count, $selectedLsp, $TargetStage) 'Info' 'USER'
    } else {
        Gui-Log ("⚠️ Inga filer flyttades för LSP{0}." -f $selectedLsp) 'Warn' 'USER'
    }
    if ($skipped.Count -gt 0) {
        Gui-Log ("ℹ️ {0} fil(er) hoppades över (låsta)." -f $skipped.Count) 'Info' 'USER'
    }
    if ($failed.Count -gt 0) {
        Gui-Log ("⚠️ {0} fil(er) kunde inte flyttas. Se MoveLog i destinationen." -f $failed.Count) 'Warn' 'USER'
    }

    if ($notSelected -and $notSelected.Count -gt 0) {
        Gui-Log ("ℹ️ {0} fil(er) var matchade på LSP men valdes inte: {1}" -f $notSelected.Count, (($notSelected | Select-Object -First 5) -join ', ')) 'Info' 'USER'
    }

    # Fyll LSP-fältet om det var tomt och trigga rescan så listorna visar de nya filerna
    if ($moved.Count -gt 0) {
        if (-not ($txtLSP.Text + '').Trim()) {
            $txtLSP.Text = $selectedLsp
        }
        $script:LastScanResult = $null
        try { $btnScan.PerformClick() } catch {}
    }
}

function Invoke-ExternalScript {
    param([string]$Path, [string]$Label)
    if ([string]::IsNullOrWhiteSpace($Path)) {
        [System.Windows.Forms.MessageBox]::Show("Ange sökvägen till $Label i konfigurationen.", $Label) | Out-Null; return
    }
    if (-not (Test-Path -LiteralPath $Path)) {
        [System.Windows.Forms.MessageBox]::Show("Filen hittades inte:`n$Path", $Label) | Out-Null; return
    }
    $ext = [System.IO.Path]::GetExtension($Path).ToLowerInvariant()
    switch ($ext) {
        '.ps1' { Start-Process -FilePath powershell.exe -ArgumentList "-ExecutionPolicy Bypass -File `"$Path`"" }
        '.bat' { Start-Process -FilePath cmd.exe -ArgumentList "/c `"$Path`"" }
        '.lnk' { Start-Process -FilePath $Path }
        default { try { Start-Process -FilePath $Path } catch { [System.Windows.Forms.MessageBox]::Show("Kunde inte öppna filen:`n$Path", $Label) | Out-Null } }
    }
}

