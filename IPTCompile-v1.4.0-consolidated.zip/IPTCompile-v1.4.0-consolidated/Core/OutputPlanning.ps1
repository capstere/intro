﻿
$AssayMap = @(
    @{ Tab='MTB ULTRA';            Aliases=@('Xpert MTB-RIF Ultra', 'MTB-RIF Ultra v2 RUO') }
    @{ Tab='MTB RIF';              Aliases=@('Xpert MTB-RIF Assay G4', 'Xpert MTB-RIF US IVD') }
    @{ Tab='MTB JP';               Aliases=@('Xpert MTB-RIF JP IVD') }
    @{ Tab='MTB XDR';              Aliases=@('Xpert MTB-XDR', 'MTB-XDR RUO', 'MTB-XDR IUO') }
    @{ Tab='FLUVID | FLUVID+';     Aliases=@('Xpress SARS-CoV-2_Flu_RSV plus','Xpert Xpress_SARS-CoV-2_Flu_RSV') }
    @{ Tab='SARS-COV-2 Plus';      Aliases=@('Xpert Xpress CoV-2 plus', 'LCE009 Xpress SARS-CoV-2 plus','Xpert Xpress CoV-2 plus IVD', 'Xpress CoV-2 plus RUO', 'Xpress CoV-2 plus IUO') }
    @{ Tab='CTNG | CTNG JP';       Aliases=@('Xpert CT_NG','Xpert CT_CE') }
    @{ Tab='C.DIFF | C.DIFF JP';   Aliases=@('Xpert C.difficile G3','Xpert C.difficile BT', 'Xpert-C. difficile G2', 'Xpert C.diff-Epi') }
    @{ Tab='HPV';                  Aliases=@('Xpert HPV HR','Xpert HPV v2 HR') }
    @{ Tab='HBV VL';               Aliases=@('Xpert HBV Viral Load') }
    @{ Tab='HCV VL';               Aliases=@('Xpert HCV Viral Load','Xpert_HCV Viral Load') }
    @{ Tab='HCV VL FS';            Aliases=@('Xpert HCV VL Fingerstick') }
    @{ Tab='HIV VL';               Aliases=@('Xpert HIV-1 Viral Load','Xpert_HIV-1 Viral Load') }
    @{ Tab='HIV VL XC';            Aliases=@('Xpert HIV-1 Viral Load XC') }
    @{ Tab='HIV QA';               Aliases=@('Xpert HIV-1 Qual','Xpert_HIV-1 Qual') }
    @{ Tab='HIV QA XC';            Aliases=@('Xpert HIV-1 Qual XC PQC','Xpert HIV-1 Qual XC') }
    @{ Tab='SARS-COV-2';           Aliases=@('Xpert Xpress SARS-CoV-2 CE-IVD','Xpert Xpress SARS-CoV-2') }
    @{ Tab='FLU RSV';              Aliases=@('Xpert Xpress Flu-RSV','Xpress Flu IPT_EAT off') }
    @{ Tab='MRSA SA';              Aliases=@('Xpert SA Nasal Complete G3','Xpert MRSA-SA SSTI G3') }
    @{ Tab='MRSA NxG';             Aliases=@('Xpert MRSA NxG') }
    @{ Tab='NORO';                 Aliases=@('Xpert Norovirus') }
    @{ Tab='VAN AB';               Aliases=@('Xpert vanA vanB') }
    @{ Tab='GBS';                  Aliases=@('Xpert GBS LB XC','Xpert Xpress GBS','Xpert Xpress GBS US-IVD') }
    @{ Tab='STREP A';              Aliases=@('Xpert Xpress Strep A', 'Xpert Xpress_Strep A') }
    @{ Tab='CARBA R';              Aliases=@('Xpert Carba-R','Xpert_Carba-R', 'CARBA-R IUO','Carba-R BEU IUO', 'CARBA-R RUO', 'Carba-R BEU RUO') }
    @{ Tab='EBOLA';                Aliases=@('Xpert Ebola EUA','Xpert Ebola CE-IVD', 'Ebola RUO') }
    @{ Tab='Respiratory Panel';    Aliases=@('Respiratory panel', 'Respiratory panel CE-IVD', 'Respiratory panel UKCA-IVD', 'Respiratory Panel RUO', 'Respiratory Panel IUO') }
    @{ Tab='TAP Panel';            Aliases=@('Xpert TAP Panel', 'TAP Panel IUO', 'TAP Panel RUO') }
    @{ Tab='GI Panel';             Aliases=@('GI Panel', 'Xpert GI Panel CE-IVD', 'Xpert GI Panel', 'GI Panel IUO', 'GI Panel RUO') }
)
$AssayIndex = @{}
foreach($row in $AssayMap){ foreach($a in $row.Aliases){ $k=Normalize-Assay $a; if($k -and -not $AssayIndex.ContainsKey($k)){ $AssayIndex[$k]=$row.Tab } } }

$MinitabMap = @(
    @{ Aliases=@('Xpert MTB-RIF Ultra');                           Macro='%D12547-MTBU-SWE' }
    @{ Aliases=@('Xpert MTB-RIF Assay G4');                        Macro='%D12547-MTB-SWE' }
    @{ Aliases=@('Xpress SARS-CoV-2_Flu_RSV plus','Xpert Xpress_SARS-CoV-2_Flu_RSV'); Macro='%D12547-XP3COV2FLURSV-SWE' }
    @{ Aliases=@('Xpert Xpress CoV-2 plus');                        Macro='%D12547-XP3SARSCOV2-SWE' }
    @{ Aliases=@('CT_NG','Xpert CT_CE');                            Macro='%D12547-CTNG-SWE' }
    @{ Aliases=@('Xpert C.difficile G3','Xpert C.difficile BT');    Macro='%D12547-CDCE-SWE' }
    @{ Aliases=@('Xpert HPV HR','Xpert HPV v2 HR');                 Macro='%D12547-HPV-SWE' }
    @{ Aliases=@('Xpert HBV Viral Load');                           Macro='%D12547-HBVVL-SWE' }
    @{ Aliases=@('Xpert HCV Viral Load','Xpert_HCV Viral Load');    Macro='%D12547-HCVVL-SWE' }
    @{ Aliases=@('Xpert HCV VL Fingerstick');                       Macro='%D12547-FSHCV-SWE' }
    @{ Aliases=@('Xpert HIV-1 Viral Load','Xpert_HIV-1 Viral Load'); Macro='%D12547-HIVVL-SWE' }
    @{ Aliases=@('Xpert HIV-1 Qual','Xpert_HIV-1 Qual');            Macro='%D12547-HIVQA-SWE' }
    @{ Aliases=@('Xpert Xpress SARS-CoV-2 CE-IVD','Xpert Xpress SARS-CoV-2'); Macro='%D12547-XPRSARSCOV2-SWE' }
    @{ Aliases=@('Xpert Xpress Flu-RSV');                           Macro='%D12547-XPFLURSV-SWE' }
    @{ Aliases=@('Xpress Flu IPT_EAT off');                         Macro='%D12547-FLUNG-SWE' }
    @{ Aliases=@('Xpert Norovirus');                                Macro='%D12547-NORO-SWE' }
    @{ Aliases=@('Xpert vanA vanB');                                Macro='%D12547-VAB-SWE' }
    @{ Aliases=@('Xpert Xpress Strep A');                           Macro='%D12547-STREPA-SWE' }
    @{ Aliases=@('Xpert Carba-R','Xpert_Carba-R');                  Macro='%D12547-CARBAR-SWE' }
    @{ Aliases=@('Xpert Ebola EUA','Xpert Ebola CE-IVD');           Macro='%D12547-EBOLA-SWE' }
    @{ Aliases=@('Xpert SA Nasal Complete G3','Xpert MRSA-SA SSTI G3'); Macro='%D12547-SACOMP-SWE' }
    @{ Aliases=@('Xpert GBS LB XC','Xpert Xpress GBS','Xpert Xpress GBS US-IVD'); Macro=$null }
    @{ Aliases=@('Xpert HIV-1 Qual XC PQC','Xpert HIV-1 Qual XC');  Macro=$null }
    @{ Aliases=@('Xpert HIV-1 Viral Load XC');                      Macro=$null }
    @{ Aliases=@('Xpert MTB-RIF JP IVD');                           Macro=$null }
    @{ Aliases=@('Xpert MTB-XDR');                                  Macro=$null }
    @{ Aliases=@('Xpert MRSA NxG');                                 Macro=$null }
)
$MinitabIndex = @{}
foreach ($row in $MinitabMap) { foreach ($a in $row.Aliases) { $k = Normalize-Assay $a; if ($k -and -not $MinitabIndex.ContainsKey($k)) { $MinitabIndex[$k] = $row.Macro } } }

﻿function Format-SpPresenceGrandTotalStrict {
    param([hashtable]$Counts) 
    if (-not $Counts -or $Counts.Count -eq 0) { return '—' }
    $present = @(
        $Counts.GetEnumerator() |
        Where-Object { $_.Value -gt 0 } |
        ForEach-Object { [int]$_.Key } |
        Sort-Object
    )
    if ($present.Count -eq 0) { return '—' }
    $parts = New-Object System.Collections.Generic.List[string]
    $i = 0
    while ($i -lt $present.Count) {
        $start = $present[$i]; $end = $start
        $j = $i + 1
        while ($j -lt $present.Count -and $present[$j] -eq $end + 1) {
            $end = $present[$j]; $j++
        }
        if ($start -eq $end) { $parts.Add( ('#{0:00}' -f $start) ) }
        else { $parts.Add( ('#{0:00}-{1:00}' -f $start, $end) ) }
        $i = $j
    }
    $total = (
        $Counts.GetEnumerator() |
        Where-Object { $_.Value -gt 0 } |
        Measure-Object -Property Value -Sum
    ).Sum
    return ( ($parts -join '+') + (' x{0}' -f $total) )
}

function Get-InfinitySpFromCsvStrict {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Path,
        [Alias('InfinitySerials')][string[]]$InstrumentSerials,
        [string[]]$Lines
    )
    if (-not $Lines -and -not (Test-Path -LiteralPath $Path)) { return '—' }
    $useConvertFn = $false
    try { $useConvertFn = [bool](Get-Command ConvertTo-CsvFields -ErrorAction Stop) } catch {}
    function Split-CsvSmart([string]$ln) {
        if ($ln -like '*;*' -and $ln -notlike '*,*') {
            return [regex]::Split($ln, ';(?=(?:[^"]*"[^"]*")*[^"]*$)')
        } else {
            return [regex]::Split($ln, ',(?=(?:[^"]*"[^"]*")*[^"]*$)')
        }
    }

    $serSet = New-Object System.Collections.Generic.HashSet[string]([StringComparer]::OrdinalIgnoreCase)
    foreach ($s in ($InstrumentSerials | Where-Object { $_ })) { $null = $serSet.Add( ($s + '').Trim().Trim('"') ) }
    if ($serSet.Count -eq 0) { return '—' } 

    $lines = $Lines
    if (-not $lines) {
        try { $lines = Get-Content -LiteralPath $Path } catch { Gui-Log "⚠️ Kunde inte läsa Infinity SP från CSV: $($_.Exception.Message)" 'Warn'; return '—' }
    }
    if (-not $lines -or $lines.Count -lt 10) { return '—' }

    $headerIndex = 7
    $dataStart   = 9

    $hdr = if ($useConvertFn) { ConvertTo-CsvFields $lines[$headerIndex] } else { Split-CsvSmart $lines[$headerIndex] }
    $colCount = $hdr.Count

    $idxInstr = -1
    for ($i=0; $i -lt $colCount; $i++) {
        $h = (($hdr[$i] + '') -replace '[\uFEFF\u200B]','').Trim().ToLowerInvariant()
        if ($h -match 'instrument' -and ($h -match 's/?n' -or $h -match 'serial')) { $idxInstr = $i; break }
    }
    if ($idxInstr -lt 0) { $idxInstr = 6 }  # G
    $idxSample = 2
    $counts = @{}

    for ($r = $dataStart; $r -lt $lines.Count; $r++) {
        $ln = $lines[$r]; if (-not $ln -or -not $ln.Trim()) { continue }
        $f = if ($useConvertFn) { ConvertTo-CsvFields $ln } else { Split-CsvSmart $ln }
        if ($f.Count -le [Math]::Max($idxInstr,$idxSample)) { continue }

        $instr  = ($f[$idxInstr] + '').Trim().Trim('"')
        if (-not $serSet.Contains($instr)) { continue }  # inte Infinity → skippa

        $sample = ($f[$idxSample] + '').Trim().Trim('"')
        if (-not $sample) { continue }

        $m = [regex]::Match($sample, '_(\d{2})_')
         if ($m.Success) {
             $nRaw = 0
             if ([int]::TryParse($m.Groups[1].Value, [ref]$nRaw)) {

                $sp = $nRaw 
                if ($sp -ge 0 -and $sp -le 10) {
                     if (-not $counts.ContainsKey($sp)) { $counts[$sp] = 0 }
                     $counts[$sp] = [int]$counts[$sp] + 1
                 }
             }
         }
    }

    if ($counts.Count -eq 0) { return '—' }
    return (Format-SpPresenceGrandTotalStrict -Counts $counts)
 }

function Get-ControlTabName {
    param([string]$AssayName)
    $k = Normalize-Assay $AssayName
    if ($k -and $AssayIndex -and $AssayIndex.ContainsKey($k)) { return $AssayIndex[$k] }

    if (-not [string]::IsNullOrWhiteSpace($SlangAssayPath) -and (Test-Path -LiteralPath $SlangAssayPath)) {
        $mapPkg = $null
        try {
            $mapPkg = New-Object OfficeOpenXml.ExcelPackage (New-Object IO.FileInfo($SlangAssayPath))
            $ws = $mapPkg.Workbook.Worksheets['Slang till Assay']; if (-not $ws) { $ws = $mapPkg.Workbook.Worksheets[1] }
            if ($ws -and $ws.Dimension) {
                for ($r=2; $r -le $ws.Dimension.End.Row; $r++){
                    $sheet=$ws.Cells[$r,1].Text.Trim()
                    $aliases=@($ws.Cells[$r,2].Text,$ws.Cells[$r,3].Text,$ws.Cells[$r,4].Text) | Where-Object { $_ -and $_.Trim() }
                    foreach($al in $aliases){ if ($k -and $k -eq (Normalize-Assay $al)) { return $sheet } }
                }
            }
        } catch {
            Gui-Log "Get-ControlTabName: $($_.Exception.Message)" 'Warn'
        } finally {
            if ($mapPkg) {
                try { $mapPkg.Dispose() } catch {}
            }
        }
    }
    return $null
}

function Get-MinitabMacro { param([string]$AssayName)
    if ([string]::IsNullOrWhiteSpace($AssayName)) { return $null }
    $k = Normalize-Assay $AssayName
    if ($k -and $MinitabIndex -and $MinitabIndex.ContainsKey($k)) { return $MinitabIndex[$k] }
    return $null
}

function Get-OutSheetName {
    <# Returnerar fliknamn från centrala konstanter. Reservvärde är $Default. #>
    param([Parameter(Mandatory)][string]$Key, [string]$Default = '')
    try {
        if ($global:IPTConstants -and $global:IPTConstants.OutSheetNames.ContainsKey($Key)) {
            return $global:IPTConstants.OutSheetNames[$Key]
        }
    } catch {}
    return $Default
}

function Get-Threshold {
    <# Returnerar tröskelvärde från centrala konstanter. Reservvärde är $Default. #>
    param([Parameter(Mandatory)][string]$Key, $Default = $null)
    try {
        if ($global:IPTConstants -and $global:IPTConstants.Thresholds.ContainsKey($Key)) {
            return $global:IPTConstants.Thresholds[$Key]
        }
    } catch {}
    return $Default
}

function Is-FeatureEnabled {
    <# Kollar funktionsflagga: $Config först, annars IPTConstants, annars $Default. #>
    param([Parameter(Mandatory)][string]$Name, [bool]$Default = $false, [object]$ConfigOverride = $null)
    # Prioritet 1: Config (körning)
    try {
        $val = Get-ConfigFlag -Name $Name -Default $null -ConfigOverride $ConfigOverride
        if ($val -ne $null) { return [bool]$val }
    } catch {}
    # Prioritet 2: IPTConstants (standard vid uppstart)
    try {
        if ($global:IPTConstants -and $global:IPTConstants.FeatureFlags.ContainsKey($Name)) {
            return [bool]$global:IPTConstants.FeatureFlags[$Name]
        }
    } catch {}
    return $Default
}

# Phase 10 safe refactor: moved from Main.ps1

function _IsActiveSealSheet($ws) {
    try {
        if (-not $ws) { return $false }
        if ($ws.Index -eq 1) { return $false }  # Skippa alltid första bladet (används ej)
        if ($ws.Name -eq "Worksheet Instructions") { return $false }

        $h3 = Get-CellText $ws $Layout.SealActiveCheckCell
        if (-not $h3) { return $false }

        $h3n = (Normalize-HeaderText $h3).Trim().ToUpper()
        if ($h3n -eq 'NA' -or $h3n -eq 'N/A') { return $false }

        return $true
    } catch {
        return $false
    }
}

function _GetPerSheetValueObjects($pkg, [string]$addr) {
    # Returnerar objektlista: Sheet, Addr, Value (en per "aktiv" flik)
    $out = New-Object System.Collections.Generic.List[object]
    foreach ($ws in $pkg.Workbook.Worksheets) {
        if (-not (_IsActiveSealSheet $ws)) { continue }
        try {
            $cell = $ws.Cells[$addr]
            $v = ''
            if ($cell -and $cell.Value -ne $null) {
                if ($cell.Value -is [datetime]) { $v = $cell.Value.ToString('MMM-yy') } else { $v = $cell.Text }
            }
            [void]$out.Add([pscustomobject]@{ Sheet = $ws.Name; Addr = $addr; Value = ('' + $v) })
        } catch {
            [void]$out.Add([pscustomobject]@{ Sheet = $ws.Name; Addr = $addr; Value = '' })
        }
    }
     return @($out.ToArray())
}

function _AggregateStatus([string[]]$statuses) {
    # Summerar: Mismatch > Saknas > Delvis > Match
    if (-not $statuses -or $statuses.Count -eq 0) { return 'NoRef' }
    if ($statuses -contains 'Mismatch') { return 'Mismatch' }
    if ($statuses -contains 'Saknas')   { return 'Saknas' }
    if ($statuses -contains 'Delvis')   { return 'Delvis' }
    if ($statuses -contains 'Match')    { return 'Match' }
    return 'NoRef'
}
