Kontrollprovsfil v2.7 - enkel, cool och praktisk

Bygger direkt på fungerande v2.6/originalbaserad version.

Ändringar:
- Snyggare huvudmeny med färger.
- Snyggare inventeringsrapport med rubrik, metadata, filter, frysta headers och fler praktiska kolumner.
- Snyggare rapport för kort utgångsdatum med dagar till exp och enkel färgmarkering.
- Qty är fortsatt fri text. Ingen heltalsvalidering.
- En enda loggfil används: UpdateLog_Kontrollprovsfil.csv.
- Feedback-funktionen är borttagen eftersom den skapade en separat CSV.
- Inga spool-/emergency-loggar används.

Testa först mot kopia av raw_data.xlsx.
