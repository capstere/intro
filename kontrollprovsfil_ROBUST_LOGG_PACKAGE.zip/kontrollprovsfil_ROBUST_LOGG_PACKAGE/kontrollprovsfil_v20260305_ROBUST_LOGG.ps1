﻿param(
    [string]$RawDataPath  = "N:\QC\QC-1\IPT\8. IPT - WR + Rework\1. PQC - Kontrollprovsfil - RÖR EJ -\Script Raw Data\raw_data.xlsx",
    [string]$OutputDir    = "N:\QC\QC-1\IPT\8. IPT - WR + Rework\1. PQC - Kontrollprovsfil - RÖR EJ -\Inventeringsrapport",
    [string]$UpdateLogCsvPath = "",
    [bool]$AutoRepairUpdateLog = $true
)

# =====================[ Kolumnschema för rådata ]=====================
$InventoryColumns = @{
    PN              = 1
    Lot             = 2
    Exp             = 3
    Qty             = 4
    LastUpdate      = 5
    Signature       = 6
    ProductStartCol = 7
    ProductEndCol   = 13
    Description     = 14
    LabbDescription = 15
    LabbCode        = 16
}

# =====================[ Minimal update-logg (CSV) ]=====================
$script:RawDataBackedUp = $false

if ([string]::IsNullOrWhiteSpace($UpdateLogCsvPath)) {
    $rawDir = Split-Path $RawDataPath -Parent
    $UpdateLogCsvPath = Join-Path $rawDir "UpdateLog_Kontrollprovsfil.csv"
}
$script:UpdateLogCsvPath = $UpdateLogCsvPath

# =====================[ Excel COM: öppna + spara raw_data.xlsx ]=====================
$script:ExcelOpenSave_Enabled = $true
$script:ExcelOpenSave_TimeoutSec = 90

# =====================[ EPPlus bootstrap (minimal) ]=====================

function Ensure-EPPlus {
    param(
        [string] $SourceDllPath = "N:\QC\QC-1\IPT\Skiftspecifika dokument\PQC analyst\JESPER\Scripts\Modules\EPPlus\EPPlus.4.5.3.3\lib\net35\EPPlus.dll"
    )

    $candidatePaths = @()
    if (-not [string]::IsNullOrWhiteSpace($SourceDllPath)) { $candidatePaths += $SourceDllPath }
    $candidatePaths += (Join-Path $PSScriptRoot 'EPPlus.dll')

    foreach ($cand in $candidatePaths) {
        if (-not [string]::IsNullOrWhiteSpace($cand) -and (Test-Path -LiteralPath $cand)) {
            return $cand
        }
    }

    Write-Warning "❌ EPPlus.dll hittades inte. Lägg EPPlus.dll bredvid skriptet eller uppdatera SourceDllPath i Ensure-EPPlus."
    return $null
}

function Load-EPPlus {
    if ([System.AppDomain]::CurrentDomain.GetAssemblies() | Where-Object { $_.GetName().Name -eq 'EPPlus' }) {
        return $true
    }

    $dllPath = Ensure-EPPlus
    if (-not $dllPath) { return $false }

    try {
        $bytes = [System.IO.File]::ReadAllBytes($dllPath)
        [System.Reflection.Assembly]::Load($bytes) | Out-Null
        return $true
    }
    catch {
        Write-Warning "❌ EPPlus-fel vid inläsning från '$dllPath': $($_.Exception.Message)"
        return $false
    }
}

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force -ErrorAction SilentlyContinue

if (-not (Load-EPPlus)) {
    Write-Host "Kritisk komponent (EPPlus) kunde inte laddas. Skriptet avbryts." -ForegroundColor Red
    exit 1
}

# =====================[ Utilities ]=====================

function Backup-RawDataFile {
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [string]$BackupDir = "$PSScriptRoot\Backups"
    )
    try {
        if (-not (Test-Path -LiteralPath $BackupDir)) {
            New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
        }
        $timestamp  = (Get-Date).ToString("yyyyMMdd_HHmmss")
        $filename   = Split-Path $FilePath -Leaf
        $backupPath = Join-Path $BackupDir "$($filename)_$timestamp.bak"
        Copy-Item -LiteralPath $FilePath -Destination $backupPath -Force
        Write-Host "Säkerhetskopia skapad: $backupPath" -ForegroundColor Green
    } catch {
        Write-Host "⚠ Kunde inte skapa backup: $($_.Exception.Message)" -ForegroundColor Yellow
    }
}

function Pause-AnyKey {
    param([string]$Prompt = "Tryck Enter för att återgå till huvudmenyn...")

    try { $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown") }
    catch { $null = Read-Host $Prompt }
}

function Invoke-WithRetry {
    param(
        [Parameter(Mandatory=$true)][scriptblock]$Action,
        [int]$MaxAttempts = 6,
        [int]$BaseDelayMs = 200
    )
    for ($i=1; $i -le $MaxAttempts; $i++) {
        try { return & $Action }
        catch {
            if ($i -eq $MaxAttempts) { throw }
            $delay = [int]($BaseDelayMs * [Math]::Pow(1.7, ($i-1)) + (Get-Random -Minimum 0 -Maximum 120))
            Start-Sleep -Milliseconds $delay
        }
    }
}

function Invoke-ExcelOpenSave {
    <#
      Minimal “Excel-magi”:
      Öppnar arbetsboken headless, väntar lite på kalkyl/async och sparar.
      Målet är att efterlikna att någon öppnar filen i Excel och trycker Ctrl+S.
    #>
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [int]$TimeoutSec = 90
    )

    if (-not (Test-Path -LiteralPath $Path)) { throw "Saknar fil: $Path" }

    $excel = $null
    $wb = $null
    try {
        $excel = New-Object -ComObject Excel.Application
        $excel.Visible = $false
        $excel.DisplayAlerts = $false
        try { $excel.EnableEvents = $false } catch {}
        try { $excel.AskToUpdateLinks = $false } catch {}

        # Visa “avvakta” så användaren inte stänger appen
        Write-Host "⏳ Avvakta: Excel måste öppna och spara raw_data.xlsx p.g.a att det ska fungera med appen... Så det tar några sekunder extra. Sorry" -ForegroundColor Yellow
        # UpdateLinks=3 => Excel försöker uppdatera externa länkar vid öppning
        $wb = $excel.Workbooks.Open($Path, 3, $false)

        # Visa “avvakta” så användaren inte stänger appen
        Write-Host "⏳ Avvakta: Excel måste öppna och spara raw_data.xlsx p.g.a att det ska fungera med appen... Så det tar några sekunder extra. Sorry" -ForegroundColor Yellow

        # Vänta en kort stund på kalkyl/async (utan att anta refresh-typ)
        $sw = [Diagnostics.Stopwatch]::StartNew()
        $tick = 0
        while ($sw.Elapsed.TotalSeconds -lt $TimeoutSec) {
            $state = 0
            try { $state = [int]$excel.CalculationState } catch { $state = 0 }
            if ($state -eq 0) { break } # 0 = xlDone
            $tick++
            if (($tick % 10) -eq 0) { Write-Host "   ... fortfarande igång ..." -ForegroundColor DarkYellow }
            Start-Sleep -Milliseconds 200
        }
        $sw.Stop() | Out-Null

        # Spara (det är detta du behöver för att “uppdateringen” ska bli verklig på disk)
        $wb.Save()
        return $true
    } finally {
        try { if ($wb) { $wb.Close($true) | Out-Null } } catch {}
        try { if ($excel) { $excel.Quit() | Out-Null } } catch {}
        try { if ($wb) { [Runtime.InteropServices.Marshal]::ReleaseComObject($wb) | Out-Null } } catch {}
        try { if ($excel) { [Runtime.InteropServices.Marshal]::ReleaseComObject($excel) | Out-Null } } catch {}
        [GC]::Collect()
        [GC]::WaitForPendingFinalizers()
    }
}


# =====================[ Robust CSV update-logg / audit trail ]=====================
# Viktigt:
# - Den gamla loggningen blev korrupt p.g.a. PowerShell-syntaxen "CsvCell $ts, CsvCell $user".
#   PowerShell tolkade det inte som separata funktionsanrop. Därför blev raderna t.ex.
#   "2026-03-05 18:18:03 CsvCell" i stället för 13 CSV-fält.
# - Denna version bygger varje rad via en objektlista + ForEach-Object, låser loggfilen
#   med en .lock-fil och använder spool/emergency-logg om huvudloggfilen är låst.

$script:UpdateLogHeaderColumns = @(
    'Timestamp','User','Signature','Action','PN','Row',
    'OldLot','OldExp','OldQty','NewLot','NewExp','NewQty','Machine'
)
$script:UpdateLogExpectedHeader = ($script:UpdateLogHeaderColumns -join ';')
$script:UpdateLogExpectedSemicolonCount = $script:UpdateLogHeaderColumns.Count - 1

function ConvertTo-LogCsvCell {
    param([AllowNull()][object]$Value)

    if ($null -eq $Value) { $text = '' }
    else { $text = [string]$Value }

    # En loggrad ska alltid vara exakt en fysisk rad.
    $text = $text -replace "(\r\n|\n|\r|\t)", ' '
    $text = $text.Trim()
    $text = $text.Replace('"','""')
    return ('"{0}"' -f $text)
}

function New-UpdateLogCsvLine {
    param([Parameter(Mandatory=$true)][object[]]$Values)

    if ($Values.Count -ne $script:UpdateLogHeaderColumns.Count) {
        throw "Internt loggfel: förväntade $($script:UpdateLogHeaderColumns.Count) fält men fick $($Values.Count)."
    }

    return (($Values | ForEach-Object { ConvertTo-LogCsvCell -Value $_ }) -join ';')
}

function Get-SafeFileNamePart {
    param([AllowNull()][string]$Text)
    if ([string]::IsNullOrWhiteSpace($Text)) { return 'unknown' }
    return ($Text -replace '[^a-zA-Z0-9_\.-]', '_')
}

function Acquire-LockFile {
    param(
        [Parameter(Mandatory=$true)][string]$LockPath,
        [string]$Purpose = 'filoperation',
        [int]$TimeoutSec = 60,
        [int]$DelayMs = 250
    )

    $dir = Split-Path $LockPath -Parent
    if (-not [string]::IsNullOrWhiteSpace($dir) -and -not (Test-Path -LiteralPath $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }

    $sw = [Diagnostics.Stopwatch]::StartNew()
    $lastError = $null
    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSec) {
        try {
            $fs = [System.IO.File]::Open($LockPath, [System.IO.FileMode]::OpenOrCreate, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
            try {
                $bytes = [System.Text.Encoding]::UTF8.GetBytes(("Locked by {0}\{1} PID {2} at {3} for {4}" -f $env:COMPUTERNAME, [Environment]::UserName, $PID, (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'), $Purpose))
                $fs.SetLength(0)
                $fs.Write($bytes, 0, $bytes.Length)
                $fs.Flush()
            } catch {}
            return $fs
        }
        catch {
            $lastError = $_.Exception.Message
            Start-Sleep -Milliseconds $DelayMs
        }
    }

    throw "Kunde inte få lås för $Purpose inom $TimeoutSec sekunder. Låsfil: $LockPath. Senaste fel: $lastError"
}

function Release-LockFile {
    param(
        [Parameter(Mandatory=$true)]$LockHandle,
        [string]$LockPath
    )

    try { if ($LockHandle) { $LockHandle.Close() } } catch {}
    try { if ($LockHandle) { $LockHandle.Dispose() } } catch {}
    if (-not [string]::IsNullOrWhiteSpace($LockPath)) {
        try { Remove-Item -LiteralPath $LockPath -Force -ErrorAction SilentlyContinue } catch {}
    }
}

function Invoke-WithFileLock {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][scriptblock]$Action,
        [string]$Purpose = 'loggskrivning',
        [int]$TimeoutSec = 60
    )

    $lockPath = "$Path.lock"
    $lock = $null
    try {
        $lock = Acquire-LockFile -LockPath $lockPath -Purpose $Purpose -TimeoutSec $TimeoutSec
        return (& $Action)
    }
    finally {
        if ($lock) { Release-LockFile -LockHandle $lock -LockPath $lockPath }
    }
}

function Write-TextLineUtf8Unlocked {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$Line,
        [bool]$Append = $true,
        [bool]$Bom = $false
    )

    $dir = Split-Path $Path -Parent
    if (-not [string]::IsNullOrWhiteSpace($dir) -and -not (Test-Path -LiteralPath $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }

    $encoding = New-Object System.Text.UTF8Encoding($Bom)
    $sw = New-Object System.IO.StreamWriter($Path, $Append, $encoding)
    try {
        $sw.WriteLine($Line)
        $sw.Flush()
    }
    finally {
        $sw.Close()
        $sw.Dispose()
    }
}

function Get-UpdateLogHealth {
    param([Parameter(Mandatory=$true)][string]$Path)

    $result = [pscustomobject]@{
        Exists       = (Test-Path -LiteralPath $Path)
        IsHealthy    = $true
        Reason       = ''
        BadLineCount = 0
        LineCount    = 0
    }

    if (-not $result.Exists) { return $result }

    try {
        $reader = [System.IO.File]::OpenText($Path)
        try {
            while (($line = $reader.ReadLine()) -ne $null) {
                $result.LineCount++
                $cleanLine = $line.TrimStart([char]0xFEFF)

                if ($result.LineCount -eq 1) {
                    if ($cleanLine -ne $script:UpdateLogExpectedHeader) {
                        $result.IsHealthy = $false
                        $result.Reason = "Fel CSV-header. Förväntade: $($script:UpdateLogExpectedHeader)"
                        return $result
                    }
                    continue
                }

                if ([string]::IsNullOrWhiteSpace($cleanLine)) {
                    $result.BadLineCount++
                    continue
                }

                # Eftersom våra loggceller alltid saneras till en fysisk rad och skrivs med fast antal fält
                # ska varje datarad ha exakt 12 semikolon. Detta fångar den gamla "CsvCell"-korruptionen.
                $semiCount = ([regex]::Matches($cleanLine, ';')).Count
                if ($semiCount -ne $script:UpdateLogExpectedSemicolonCount -or $cleanLine -match '\sCsvCell"?$') {
                    $result.BadLineCount++
                }
            }
        }
        finally {
            $reader.Close()
            $reader.Dispose()
        }

        if ($result.BadLineCount -gt 0) {
            $result.IsHealthy = $false
            $result.Reason = "Hittade $($result.BadLineCount) korrupta loggrader av $($result.LineCount) rader."
        }
    }
    catch {
        $result.IsHealthy = $false
        $result.Reason = "Kunde inte läsa loggen: $($_.Exception.Message)"
    }

    return $result
}

function Initialize-UpdateLogCsv {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [bool]$AutoRepair = $true
    )

    Invoke-WithFileLock -Path $Path -Purpose 'initiering/reparation av uppdateringslogg' -TimeoutSec 60 -Action {
        $dir = Split-Path $Path -Parent
        if (-not [string]::IsNullOrWhiteSpace($dir) -and -not (Test-Path -LiteralPath $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
        }

        if (Test-Path -LiteralPath $Path) {
            $health = Get-UpdateLogHealth -Path $Path
            if (-not $health.IsHealthy) {
                if (-not $AutoRepair) {
                    throw "Update-loggen är inte frisk: $($health.Reason)"
                }

                $timestamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
                $base = [System.IO.Path]::GetFileNameWithoutExtension($Path)
                $ext  = [System.IO.Path]::GetExtension($Path)
                $backupPath = Join-Path $dir ("{0}.CORRUPT_BACKUP_{1}{2}" -f $base, $timestamp, $ext)
                Move-Item -LiteralPath $Path -Destination $backupPath -Force
                Write-Host "⚠ Befintlig CSV-logg var korrupt och har sparats som backup:" -ForegroundColor Yellow
                Write-Host "   $backupPath" -ForegroundColor DarkYellow
            }
        }

        if (-not (Test-Path -LiteralPath $Path)) {
            Write-TextLineUtf8Unlocked -Path $Path -Line $script:UpdateLogExpectedHeader -Append:$false -Bom:$true
        }
    } | Out-Null
}

function Ensure-UpdateLogCsv {
    param([Parameter(Mandatory=$true)][string]$Path)
    Initialize-UpdateLogCsv -Path $Path -AutoRepair:$AutoRepairUpdateLog
}

function Append-CsvLineWithRetry {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][string]$Line
    )

    Invoke-WithRetry -MaxAttempts 8 -BaseDelayMs 250 -Action {
        Invoke-WithFileLock -Path $Path -Purpose 'append till uppdateringslogg' -TimeoutSec 30 -Action {
            Write-TextLineUtf8Unlocked -Path $Path -Line $Line -Append:$true -Bom:$false
        } | Out-Null
    } | Out-Null
}

function Get-UpdateLogSpoolPath {
    param([Parameter(Mandatory=$true)][string]$MainCsvPath)
    $dir = Split-Path $MainCsvPath -Parent
    $name = [System.IO.Path]::GetFileNameWithoutExtension($MainCsvPath)
    $pc = Get-SafeFileNamePart -Text $env:COMPUTERNAME
    $spoolName = "{0}.SPOOL.{1}.csv" -f $name, $pc
    return (Join-Path $dir $spoolName)
}

function Write-UpdateLogSpoolLine {
    param(
        [Parameter(Mandatory=$true)][string]$MainCsvPath,
        [Parameter(Mandatory=$true)][string]$Line
    )

    $spool = Get-UpdateLogSpoolPath -MainCsvPath $MainCsvPath
    Invoke-WithFileLock -Path $spool -Purpose 'spoolad uppdateringslogg' -TimeoutSec 30 -Action {
        if (-not (Test-Path -LiteralPath $spool)) {
            Write-TextLineUtf8Unlocked -Path $spool -Line $script:UpdateLogExpectedHeader -Append:$false -Bom:$true
        }
        Write-TextLineUtf8Unlocked -Path $spool -Line $Line -Append:$true -Bom:$false
    } | Out-Null

    return $spool
}

function Write-UpdateLogEmergencyLine {
    param(
        [Parameter(Mandatory=$true)][string]$Line,
        [Parameter(Mandatory=$true)][string]$Reason
    )

    $emergencyDir = Join-Path $PSScriptRoot 'EmergencyLogs'
    if (-not (Test-Path -LiteralPath $emergencyDir)) {
        New-Item -ItemType Directory -Path $emergencyDir -Force | Out-Null
    }

    $pc = Get-SafeFileNamePart -Text $env:COMPUTERNAME
    $emergencyPath = Join-Path $emergencyDir ("UpdateLog_Kontrollprovsfil.EMERGENCY.{0}.csv" -f $pc)

    Invoke-WithFileLock -Path $emergencyPath -Purpose 'emergency-logg' -TimeoutSec 20 -Action {
        if (-not (Test-Path -LiteralPath $emergencyPath)) {
            Write-TextLineUtf8Unlocked -Path $emergencyPath -Line $script:UpdateLogExpectedHeader -Append:$false -Bom:$true
        }
        Write-TextLineUtf8Unlocked -Path $emergencyPath -Line $Line -Append:$true -Bom:$false
        Write-TextLineUtf8Unlocked -Path ($emergencyPath + '.reason.txt') -Line ((Get-Date).ToString('yyyy-MM-dd HH:mm:ss') + ' - ' + $Reason) -Append:$true -Bom:$false
    } | Out-Null

    return $emergencyPath
}

function Flush-UpdateLogSpool {
    param([Parameter(Mandatory=$true)][string]$MainCsvPath)

    $dir  = Split-Path $MainCsvPath -Parent
    $name = [System.IO.Path]::GetFileNameWithoutExtension($MainCsvPath)

    if (-not (Test-Path -LiteralPath $dir)) { return }

    $spools = Get-ChildItem -LiteralPath $dir -Filter ("{0}.SPOOL.*.csv" -f $name) -ErrorAction SilentlyContinue
    if (-not $spools) { return }

    foreach ($spoolFile in $spools) {
        $claimPath = $spoolFile.FullName + ('.flushing.{0}.{1}' -f $env:COMPUTERNAME, $PID)
        try {
            Move-Item -LiteralPath $spoolFile.FullName -Destination $claimPath -ErrorAction Stop
        }
        catch {
            continue
        }

        try {
            $lines = Get-Content -LiteralPath $claimPath -ErrorAction Stop
            if ($lines.Count -le 1) {
                Remove-Item -LiteralPath $claimPath -Force -ErrorAction SilentlyContinue
                continue
            }

            Invoke-WithFileLock -Path $MainCsvPath -Purpose 'flush av spoolad uppdateringslogg' -TimeoutSec 60 -Action {
                for ($i=1; $i -lt $lines.Count; $i++) {
                    if (-not [string]::IsNullOrWhiteSpace($lines[$i])) {
                        Write-TextLineUtf8Unlocked -Path $MainCsvPath -Line $lines[$i] -Append:$true -Bom:$false
                    }
                }
            } | Out-Null

            Remove-Item -LiteralPath $claimPath -Force -ErrorAction SilentlyContinue
        }
        catch {
            try {
                if (Test-Path -LiteralPath $claimPath) {
                    Move-Item -LiteralPath $claimPath -Destination $spoolFile.FullName -Force -ErrorAction SilentlyContinue
                }
            } catch {}
            continue
        }
    }
}

function Write-UpdateLogRow {
    param(
        [Parameter(Mandatory=$true)][string]$PN,
        [Parameter(Mandatory=$true)][string]$Signature,
        [Parameter(Mandatory=$true)][ValidateSet('ADD','REMOVE','QTY','OVERWRITE')][string]$Action,
        [int]$RowNumber = 0,
        [string]$OldLot, [string]$OldExp, [string]$OldQty,
        [string]$NewLot, [string]$NewExp, [string]$NewQty
    )

    $path = $script:UpdateLogCsvPath
    $ts   = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    $user = [Environment]::UserName
    $pc   = $env:COMPUTERNAME

    $line = New-UpdateLogCsvLine -Values @(
        $ts,
        $user,
        $Signature,
        $Action,
        $PN,
        [string]$RowNumber,
        $OldLot,
        $OldExp,
        $OldQty,
        $NewLot,
        $NewExp,
        $NewQty,
        $pc
    )

    try {
        Ensure-UpdateLogCsv -Path $path
        Flush-UpdateLogSpool -MainCsvPath $path
        Append-CsvLineWithRetry -Path $path -Line $line
        return 'MAIN'
    }
    catch {
        $mainError = $_.Exception.Message
        try {
            $spoolPath = Write-UpdateLogSpoolLine -MainCsvPath $path -Line $line
            return ('SPOOL:{0}' -f $spoolPath)
        }
        catch {
            $spoolError = $_.Exception.Message
            $emergencyPath = Write-UpdateLogEmergencyLine -Line $line -Reason ("Main log failed: $mainError | Spool failed: $spoolError")
            return ('EMERGENCY:{0}' -f $emergencyPath)
        }
    }
}


# =====================[ Auth + Signature ]=====================

function Request-Password {
    $autoUsers = @("vivian.dao", "elin.sidstedt", "jesper.fredriksson", "afnan.vijitraphongs")
    $currentUser = [Environment]::UserName.ToLower()
    if ($autoUsers -contains $currentUser) {
         Write-Host "Automatiskt godkänd för $currentUser utan lösenord." -ForegroundColor Green
         return $true
    }
    do {
         $securePwd = Read-Host "Ange lösenord eller tryck Enter för PQC-konto" -AsSecureString
         $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePwd)
         $unsecurePassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
         [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
         if ($unsecurePassword -eq 'labbkontroll') { return $true }
         Write-Host "Fel lösenord. Tryck (1) för att återgå till huvudmenyn." -ForegroundColor Red -BackgroundColor DarkYellow
         $choice = Read-Host "Ange ditt val"
         if ($choice -eq '1') { return $false }
    } while ($true)
}

function Get-UserSignature {
    param([string]$Prompt = "Ange din signatur för att bekräfta ändringarna")

    $userSignature = @{
        "jesper.fredriksson"   = "JESP"
        "elin.sidstedt"        = "ELS"
        "vivian.dao"           = "vdao"
        "afnan.vijitraphongs"  = "AFVI"
    }

    $currentUser = [Environment]::UserName.ToLower()

    if ($userSignature.ContainsKey($currentUser)) {
        Write-Host "Automatisk signatur för $currentUser $($userSignature[$currentUser])" -ForegroundColor Green
        return $userSignature[$currentUser]
    }

    do {
        $signature = Read-Host $Prompt
        if ($signature.Length -ge 3 -and $signature.Length -le 4) { return $signature }
        Write-Host "Ogiltig signatur – måste vara exakt 3-4 tecken." -ForegroundColor Red
    } while ($true)
}

# =====================[ Date parsing ]=====================

function Try-ParseInventoryDate {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text) -or $Text -eq 'N/A') { return $null }

    try {
        if ($Text -match '^\d{4}-\d{2}-\d{2}$') {
            return [datetime]$Text
        }
        elseif ($Text -match '^\d{4}-\d{2}$') {
            $year  = [int]$Text.Substring(0,4)
            $month = [int]$Text.Substring(5,2)
            $first = New-Object datetime($year, $month, 1)
            return $first.AddMonths(1).AddDays(-1)
        }
        return $null
    } catch { return $null }
}

function Read-ValidExpiryDate {
    param([string]$Prompt = "Ange utgångsdatum (YYYY-MM-DD eller YYYY-MM)")

    while ($true) {
        $input = Read-Host $Prompt
        if ([string]::IsNullOrWhiteSpace($input)) {
            Write-Host "Utgångsdatum får inte vara tomt." -ForegroundColor Red
            continue
        }
        if ($input -notmatch '^\d{4}-\d{2}-\d{2}$' -and $input -notmatch '^\d{4}-\d{2}$') {
            Write-Host "Ogiltigt format. Använd 'YYYY-MM-DD' eller 'YYYY-MM'." -ForegroundColor Red
            continue
        }
        $parsed = Try-ParseInventoryDate -Text $input
        if (-not $parsed) {
            Write-Host "Ogiltigt datum (t.ex. fel månad/dag). Försök igen." -ForegroundColor Red
            continue
        }
        return $input
    }
}

# =====================[ EPPlus helpers ]=====================

function Open-ExcelPackageWithRetry {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [int]$MaxAttempts = 5,
        [int]$DelaySeconds = 2
    )

    for ($attempt=1; $attempt -le $MaxAttempts; $attempt++) {
        try {
            $file = New-Object System.IO.FileInfo($Path)
            return (New-Object OfficeOpenXml.ExcelPackage($file))
        }
        catch {
            Write-Host "Kunde inte öppna '$Path' (försök $attempt/$MaxAttempts). Fel: $($_.Exception.Message)" -ForegroundColor Yellow
            Start-Sleep -Seconds $DelaySeconds
        }
    }

    Write-Host "❌ Gav upp efter $MaxAttempts försök att öppna '$Path'." -ForegroundColor Red
    return $null
}

# =====================[ Core: Update inventory ]=====================

function Update-ExcelInventory {
    param([Parameter(Mandatory=$true)][string]$FilePath)

    $package = $null
    $updateLockHandle = $null
    $updateLockPath = "$FilePath.update.lock"
    try {
        # En användare i taget får uppdatera rådatafilen. Annars kan två EPPlus-sessioner skriva över varandra.
        $updateLockHandle = Acquire-LockFile -LockPath $updateLockPath -Purpose 'uppdatering av raw_data.xlsx' -TimeoutSec 120
        $package = Open-ExcelPackageWithRetry -Path $FilePath
        if (-not $package) { return }

        $sheet = $package.Workbook.Worksheets[1]
        if (-not $sheet) {
            Write-Host "Blad 1 saknas i filen. Avbryter..." -ForegroundColor Red
            return
        }

        $rowCount = $sheet.Dimension.End.Row
        while ($true) {
            Clear-Host
            Write-Host "================ Uppdatera Kontrollprovsfil =================" -ForegroundColor Cyan
            Write-Host "CSV-logg: $($script:UpdateLogCsvPath)" -ForegroundColor DarkGray
            Write-Host "`nAnge P/N eller skriv [Q] för att avbryta"
            $pnToUpdate = Read-Host
            if ($pnToUpdate -eq 'Q') { return }
            if ([string]::IsNullOrWhiteSpace($pnToUpdate)) {
                Write-Host "P/N får inte vara tomt. Försök igen!" -ForegroundColor DarkYellow
                Pause-AnyKey
                continue
            }

            $foundRows = @()
            for ($i = 2; $i -le $rowCount; $i++) {
                if ($sheet.Cells[$i,$InventoryColumns.PN].Text -eq $pnToUpdate) {
                    $foundRows += $i
                    if ($foundRows.Count -eq 4) { break }
                }
            }
            if ($foundRows.Count -eq 0) {
                Write-Host "Inget P/N hittades som matchar '$pnToUpdate'." -ForegroundColor Red
                Pause-AnyKey
                continue
            }

            $index = 1
            foreach ($row in $foundRows) {
                $lotNum     = $sheet.Cells[$row,$InventoryColumns.Lot].Text
                $expiryDate = $sheet.Cells[$row,$InventoryColumns.Exp].Text
                $quantity   = $sheet.Cells[$row,$InventoryColumns.Qty].Text
                Write-Host "`n${index}: Lot: ${lotNum}, Exp: ${expiryDate}, Qty: ${quantity}" -ForegroundColor Green
                $index++
            }

            while ($true) {
                Write-Host "`nVälj en rad att uppdatera (1-$($foundRows.Count)) eller tryck 'B' för att backa"
                $choice = Read-Host
                if ($choice -eq 'Q') { return }
                if ($choice -eq 'B') { break }

                if (($choice -as [int]) -and ($choice -gt 0) -and ($choice -le $foundRows.Count)) {
                    $selectedRow = $foundRows[$choice - 1]
                }
                else {
                    Write-Host "Ogiltigt val, försök igen." -ForegroundColor Red
                    continue
                }

                $oldLot = $sheet.Cells[$selectedRow,$InventoryColumns.Lot].Text
                $oldExp = $sheet.Cells[$selectedRow,$InventoryColumns.Exp].Text
                $oldQty = $sheet.Cells[$selectedRow,$InventoryColumns.Qty].Text

                Write-Host "=============================================" -ForegroundColor Cyan
                Write-Host "Vad vill du uppdatera?"
                Write-Host "1: Nytt Lotnummer, Exp och Qty" -ForegroundColor Magenta
                Write-Host "2: Endast kvantitet"           -ForegroundColor Magenta
                Write-Host "3: Ta bort post (markeras som N/A)" -ForegroundColor Magenta
                Write-Host "B: Back"
                $updateChoice = Read-Host "Välj"
                if ($updateChoice -eq 'B') { continue }

                $newLot = $oldLot; $newExp = $oldExp; $newQty = $oldQty

                switch ($updateChoice) {
                    '1' {
                        $newLot = Read-Host "Ange Lotnummer"
                        $newExp = Read-ValidExpiryDate
                        $newQty = Read-Host "Ange antal"
                    }
                    '2' { $newQty = Read-Host "Ange nytt antal" }
                    '3' { $newLot = "N/A"; $newExp = "N/A"; $newQty = "N/A" }
                    default {
                        Write-Host "Ogiltigt val." -ForegroundColor Red
                        continue
                    }
                }

                if ($oldLot -eq $newLot -and $oldExp -eq $newExp -and $oldQty -eq $newQty) {
                    Write-Host "Inga ändringar jämfört med befintligt värde. Ingen uppdatering/loggning görs." -ForegroundColor Yellow
                    continue
                }

                if ($updateChoice -ne '3') {
                    Write-Host "`nBekräfta uppdateringen:" -ForegroundColor Cyan
                    Write-Host "Lotnummer: $newLot" -ForegroundColor DarkYellow
                    Write-Host "Utgångsdatum: $newExp" -ForegroundColor DarkYellow
                    Write-Host "Antal: $newQty" -ForegroundColor DarkYellow
                    $confirm = Read-Host "`nÄr detta korrekt? (1) Ja / (2) Nej"
                    if ($confirm -ne '1') {
                        Write-Host "Inga ändringar sparades."
                        continue
                    }
                }

                $userSignature = Get-UserSignature -Prompt ($(if ($updateChoice -eq '3') { "Ange signatur för borttagning" } else { "Ange din signatur" }))
                $today = (Get-Date).ToString("yyyy-MM-dd")

                $sheet.Cells[$selectedRow,$InventoryColumns.Lot].Value        = $newLot
                $sheet.Cells[$selectedRow,$InventoryColumns.Exp].Value        = $newExp
                $sheet.Cells[$selectedRow,$InventoryColumns.Qty].Value        = $newQty
                $sheet.Cells[$selectedRow,$InventoryColumns.LastUpdate].Value = ($(if ($updateChoice -eq '3') { "N/A" } else { $today }))
                $sheet.Cells[$selectedRow,$InventoryColumns.Signature].Value  = ($(if ($updateChoice -eq '3') { "N/A" } else { $userSignature }))

                if (-not $script:RawDataBackedUp) {
                    Backup-RawDataFile -FilePath $FilePath
                    $script:RawDataBackedUp = $true
                }

                $action = "OVERWRITE"
                if ($newLot -eq "N/A" -and $newExp -eq "N/A" -and $newQty -eq "N/A") {
                    $action = "REMOVE"
                }
                elseif ($oldLot -eq "N/A" -and $oldExp -eq "N/A" -and $oldQty -eq "N/A" -and
                        ($newLot -ne "N/A" -or $newExp -ne "N/A" -or $newQty -ne "N/A")) {
                    $action = "ADD"
                }
                elseif ($oldLot -eq $newLot -and $oldExp -eq $newExp -and $oldQty -ne $newQty) {
                    $action = "QTY"
                }

                $saved = $false
                try {
                    $package.Save()
                    $saved = $true
                }
                catch {
                    Write-Host "❌ Kunde inte spara ändringen i raw_data.xlsx. CSV-logg skrivs inte. Fel: $($_.Exception.Message)" -ForegroundColor Red
                }

                if ($saved -and $script:ExcelOpenSave_Enabled) {
                    try {
                        Invoke-WithRetry -MaxAttempts 3 -BaseDelayMs 350 -Action {
                            Invoke-ExcelOpenSave -Path $FilePath -TimeoutSec $script:ExcelOpenSave_TimeoutSec | Out-Null
                        }
                        Write-Host "✅ raw_data.xlsx öppnad + sparad via Excel." -ForegroundColor Green
                    } catch {
                        Write-Host "⚠ Kunde inte öppna+spara raw_data.xlsx via Excel. Filen är sparad av EPPlus men kan kräva manuell öppning i Excel. Fel: $($_.Exception.Message)" -ForegroundColor Yellow
                    }
                }

                if ($saved) {
                    try {
                        $logResult = Write-UpdateLogRow -PN $pnToUpdate -Signature $userSignature -Action $action -RowNumber $selectedRow `
                            -OldLot $oldLot -OldExp $oldExp -OldQty $oldQty `
                            -NewLot $newLot -NewExp $newExp -NewQty $newQty

                        if ($logResult -eq 'MAIN') {
                            Write-Host "`n✅ Uppdatering sparad + loggad i CSV ($action)." -ForegroundColor Green
                        }
                        elseif ($logResult -like 'SPOOL:*') {
                            Write-Host "`n⚠ Uppdatering sparad. Huvudloggen var låst/otillgänglig, men loggraden sparades i spool och flushas automatiskt nästa gång." -ForegroundColor Yellow
                            Write-Host ("   {0}" -f ($logResult -replace '^SPOOL:', '')) -ForegroundColor DarkYellow
                        }
                        elseif ($logResult -like 'EMERGENCY:*') {
                            Write-Host "`n⚠ Uppdatering sparad. Huvudlogg och spool misslyckades, men raden finns i emergency-logg bredvid skriptet." -ForegroundColor Yellow
                            Write-Host ("   {0}" -f ($logResult -replace '^EMERGENCY:', '')) -ForegroundColor DarkYellow
                        }
                        else {
                            Write-Host "`n✅ Uppdatering sparad. Loggresultat: $logResult" -ForegroundColor Green
                        }
                    }
                    catch {
                        Write-Host "⚠ Uppdatering sparad, men kunde inte skriva någon loggrad. Fel: $($_.Exception.Message)" -ForegroundColor Yellow
                    }
                }

$nextAction = Read-Host "`nUppdatera (1) nytt P/N, (2) avsluta, (Enter) fortsätt med samma P/N"
                if ($nextAction -eq '1') { break }
                if ($nextAction -eq '2') { return }

                Clear-Host
                Write-Host "================ Uppdatera Kontrollprovsfil =================" -ForegroundColor Cyan
                Write-Host "`nP/N: $pnToUpdate"
                $index = 1
                foreach ($row in $foundRows) {
                    $lotNum     = $sheet.Cells[$row,$InventoryColumns.Lot].Text
                    $expiryDate = $sheet.Cells[$row,$InventoryColumns.Exp].Text
                    $quantity   = $sheet.Cells[$row,$InventoryColumns.Qty].Text
                    Write-Host "`n${index}: Lot: ${lotNum}, Exp: ${expiryDate}, Qty: ${quantity}" -ForegroundColor Green
                    $index++
                }
            }
        }
    }
    finally {
        if ($package) { $package.Dispose() }
        if ($updateLockHandle) { Release-LockFile -LockHandle $updateLockHandle -LockPath $updateLockPath }
    }
}

# =====================[ Reports (kept, no logging) ]=====================

function Generate-InventoryReport {
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [Parameter(Mandatory=$true)][string]$OutputDir
    )

    $package = $null
    try {
        $package = Open-ExcelPackageWithRetry -Path $FilePath
        if (-not $package) { return }

        $sheet = $package.Workbook.Worksheets[1]
        if (-not $sheet) { Write-Host "Blad 1 saknas, avbryter..." -ForegroundColor Red; return }

        $rowCount = $sheet.Dimension.End.Row
        $data = @()
        for ($i=2; $i -le $rowCount; $i++) {
            $data += [pscustomobject]@{
                PN              = $sheet.Cells[$i,$InventoryColumns.PN].Text
                LotNr           = $sheet.Cells[$i,$InventoryColumns.Lot].Text
                Exp             = $sheet.Cells[$i,$InventoryColumns.Exp].Text
                Qty             = $sheet.Cells[$i,$InventoryColumns.Qty].Text
                LabbCode        = $sheet.Cells[$i,$InventoryColumns.LabbCode].Text
                LabbDescription = $sheet.Cells[$i,$InventoryColumns.LabbDescription].Text
            }
        }

        if (-not (Test-Path -LiteralPath $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }

        $dateStamp = (Get-Date -Format "yyyyMMdd")
        $xlsxPath  = Join-Path $OutputDir ("InventoryReport_{0}.xlsx" -f $dateStamp)
        if (Test-Path -LiteralPath $xlsxPath) { Remove-Item -LiteralPath $xlsxPath -Force }

        $invPkg = New-Object OfficeOpenXml.ExcelPackage
        try {
            $ws = $invPkg.Workbook.Worksheets.Add("Inventory")

            $ws.Cells["A1"].Value = "PN"
            $ws.Cells["B1"].Value = "LotNr"
            $ws.Cells["C1"].Value = "Exp"
            $ws.Cells["D1"].Value = "Qty"
            $ws.Cells["E1"].Value = "LabbCode"
            $ws.Cells["F1"].Value = "LabbDescription"

            $r=2
            foreach ($it in $data) {
                $ws.Cells["A$r"].Value = $it.PN
                $ws.Cells["B$r"].Value = $it.LotNr
                $ws.Cells["C$r"].Value = $it.Exp
                $ws.Cells["D$r"].Value = $it.Qty
                $ws.Cells["E$r"].Value = $it.LabbCode
                $ws.Cells["F$r"].Value = $it.LabbDescription
                $r++
            }

            if ($r -gt 2) {
                $lastRow = $r-1
                $used = $ws.Cells["A1:F$lastRow"]
                $hdr = $ws.Cells["A1:F1"]
                $hdr.Style.Font.Bold = $true
                $ws.View.FreezePanes(2,1)
                $used.AutoFitColumns()
            }

            $invPkg.SaveAs((New-Object System.IO.FileInfo($xlsxPath)))
            Write-Host "✅ XLSX-rapport genererad: $xlsxPath" -ForegroundColor Green
        } finally { if ($invPkg) { $invPkg.Dispose() } }
    }
    catch {
        Write-Host "Fel vid inventeringsrapport: $($_.Exception.Message)" -ForegroundColor Red
    }
    finally { if ($package) { $package.Dispose() } }
}

function Generate-ExpiringPNsReport {
    param(
        [Parameter(Mandatory=$true)][string]$FilePath,
        [Parameter(Mandatory=$true)][string]$OutputDir
    )

    $package = $null
    try {
        Clear-Host
        Write-Host "==== Material med kort utgångsdatum ====" -ForegroundColor Cyan

        if (-not (Test-Path -LiteralPath $OutputDir)) { New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null }

        $package = Open-ExcelPackageWithRetry -Path $FilePath
        if (-not $package) { return }

        $sheet = $package.Workbook.Worksheets[1]
        if (-not $sheet) { Write-Host "Blad saknas, avbryter..." -ForegroundColor Red; return }

        $rowCount  = $sheet.Dimension.End.Row
        $now       = Get-Date
        $lowerDate = $now.AddDays(-15)
        $upperDate = $now.AddDays(30)

        $dateStamp = (Get-Date -Format "yyyyMMdd")
        $xlsxPath  = Join-Path $OutputDir ("ExpiringPNsReport_{0}.xlsx" -f $dateStamp)
        if (Test-Path -LiteralPath $xlsxPath) { Remove-Item -LiteralPath $xlsxPath -Force }

        $repPkg = New-Object OfficeOpenXml.ExcelPackage
        try {
            $ws = $repPkg.Workbook.Worksheets.Add("Expiring")
            $ws.Cells["A1"].Value = "PN"
            $ws.Cells["B1"].Value = "Lotnummer"
            $ws.Cells["C1"].Value = "Exp. Date"
            $ws.Cells["D1"].Value = "Beskrivning"

            $outRow=2
            for ($i=2; $i -le $rowCount; $i++) {
                $expText = $sheet.Cells[$i,$InventoryColumns.Exp].Text
                $expDate = Try-ParseInventoryDate -Text $expText
                if ($expDate -and $expDate -ge $lowerDate -and $expDate -le $upperDate) {
                    $ws.Cells["A$outRow"].Value = $sheet.Cells[$i,$InventoryColumns.PN].Text
                    $ws.Cells["B$outRow"].Value = $sheet.Cells[$i,$InventoryColumns.Lot].Text
                    $ws.Cells["C$outRow"].Value = $expText
                    $ws.Cells["D$outRow"].Value = $sheet.Cells[$i,$InventoryColumns.Description].Text
                    $outRow++
                }
            }

            if ($outRow -gt 2) {
                $lastRow = $outRow-1
                $ws.View.FreezePanes(2,1)
                $ws.Cells["A1:D$lastRow"].AutoFitColumns()
                $repPkg.SaveAs((New-Object System.IO.FileInfo($xlsxPath)))
                Write-Host "✅ Rapport genererad: $xlsxPath" -ForegroundColor Green
                Invoke-Item $xlsxPath
            } else {
                Write-Host "Inga poster hittades inom datumintervallet." -ForegroundColor Yellow
            }
        } finally { if ($repPkg) { $repPkg.Dispose() } }
    }
    catch {
        Write-Host "Fel vid generering: $($_.Exception.Message)" -ForegroundColor Red
    }
    finally { if ($package) { $package.Dispose() } }
}

function ShowProductInfo {
    param([Parameter(Mandatory=$true)][string]$FilePath)

    Clear-Host
    Write-Host "================ Sök på Produkt för material =================" -ForegroundColor Cyan
    $productName = Read-Host "`nAnge produktnamn"
    if ([string]::IsNullOrWhiteSpace($productName)) { return }

    $package = $null
    try {
        $package = Open-ExcelPackageWithRetry -Path $FilePath
        if (-not $package) { return }

        $sheet = $package.Workbook.Worksheets[1]
        if (-not $sheet) { Write-Host "Inget blad hittades." -ForegroundColor Red; return }

        $rowCount = $sheet.Dimension.End.Row
        $productInfo = @()

        for ($i=2; $i -le $rowCount; $i++) {
            for ($j=$InventoryColumns.ProductStartCol; $j -le $InventoryColumns.ProductEndCol; $j++) {
                if ($sheet.Cells[$i,$j].Text -eq $productName) {
                    $lot = $sheet.Cells[$i,$InventoryColumns.Lot].Text
                    $exp = $sheet.Cells[$i,$InventoryColumns.Exp].Text
                    if ($lot -ne "N/A" -and $exp -ne "N/A") {
                        $productInfo += [pscustomobject]@{
                            PN          = $sheet.Cells[$i,$InventoryColumns.PN].Text
                            LotNr       = $lot
                            Exp         = $exp
                            Description = $sheet.Cells[$i,$InventoryColumns.Description].Text
                        }
                    }
                }
            }
        }

        if ($productInfo.Count -gt 0) {
            Write-Host "`nProduktinformation hittades:" -ForegroundColor Green
            $productInfo | Format-Table -AutoSize
        } else {
            Write-Host "`nIngen information hittades för '$productName'." -ForegroundColor Yellow
        }
    }
    finally { if ($package) { $package.Dispose() } }
}

function Collect-Feedback {
    Clear-Host
    Write-Host "========== Feedback ==========" -ForegroundColor Cyan
    Write-Host "OBS: Feedback loggas inte i denna slim-version." -ForegroundColor DarkGray
    $null = Read-Host "`nAnge din feedback (tryck Enter för att avsluta)"
}

# =====================[ Main menu ]=====================

function Main-Menu {
    do {
        Clear-Host
        Write-Host "Rådatafil : $RawDataPath" -ForegroundColor DarkGray
        Write-Host "CSV-logg  : $($script:UpdateLogCsvPath)" -ForegroundColor DarkGray

        Write-Host "`nKontrollprovsfil - Slim (CSV log only)" -ForegroundColor Cyan
        Write-Host "==============================================================" -ForegroundColor Cyan
        Write-Host "1: Uppdatera Kontrollprovsfil (lösenord krävs)" -ForegroundColor Magenta
        Write-Host "2: Generera inventeringsrapport (lösenord krävs)" -ForegroundColor Magenta
        Write-Host "3: Visa material med kort utgångsdatum"
        Write-Host "4: Visa materialinformation för produkt"
        Write-Host "5: Feedback (ingen loggning)"
        Write-Host "6: Avsluta"
        Write-Host "==============================================================" -ForegroundColor Cyan

        $choice = Read-Host "Välj"
        switch ($choice) {
            '1' { if (Request-Password) { Update-ExcelInventory -FilePath $RawDataPath } }
            '2' { if (Request-Password) { Generate-InventoryReport -FilePath $RawDataPath -OutputDir $OutputDir } }
            '3' { Generate-ExpiringPNsReport -FilePath $RawDataPath -OutputDir $OutputDir }
            '4' { ShowProductInfo -FilePath $RawDataPath }
            '5' { Collect-Feedback }
            '6' { return }
            default { Write-Host "Ogiltigt val." -ForegroundColor Red }
        }

        Pause-AnyKey
    } while ($true)
}

# =====================[ Startup ]=====================

if (-not (Test-Path -LiteralPath $RawDataPath)) {
    Write-Host "❌ Hittar inte rådatafilen:" -ForegroundColor Red
    Write-Host "   $RawDataPath" -ForegroundColor Yellow
    exit 1
}

Ensure-UpdateLogCsv -Path $script:UpdateLogCsvPath
Flush-UpdateLogSpool -MainCsvPath $script:UpdateLogCsvPath
Main-Menu