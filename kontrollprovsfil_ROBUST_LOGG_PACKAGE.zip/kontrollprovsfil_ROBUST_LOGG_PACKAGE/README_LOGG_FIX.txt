Kontrollprovsfil - robust loggfix
=================================

Fil att använda:
- kontrollprovsfil_v20260305_ROBUST_LOGG.ps1

Vad som var fel i originalet
----------------------------
Loggraden byggdes med syntaxen ungefär:

    CsvCell $ts,
    CsvCell $user,
    ...

I PowerShell 5.1 blir det inte separata funktionsanrop på det sättet. Resultatet i bifogad UpdateLog_Kontrollprovsfil.csv blev därför rader som:

    "2026-03-05 18:18:03 CsvCell"

Det betyder att gamla loggrader inte längre innehåller PN, signatur, före/efter-värden osv. De kan tyvärr inte rekonstrueras från CSV-loggen eftersom informationen aldrig skrevs korrekt till filen.

Vad den uppdaterade versionen gör
---------------------------------
1. Bygger varje loggrad kontrollerat via New-UpdateLogCsvLine.
2. Validerar att varje loggrad har exakt 13 fält:
   Timestamp;User;Signature;Action;PN;Row;OldLot;OldExp;OldQty;NewLot;NewExp;NewQty;Machine
3. Låser CSV-loggen med en .lock-fil före skrivning.
4. Låser raw_data.xlsx under uppdatering så två användare inte samtidigt kan spara över varandras ändringar.
5. Om huvudloggen är låst används spool-fil i samma mapp:
   UpdateLog_Kontrollprovsfil.SPOOL.<DATORNAMN>.csv
   Den flushas automatiskt till huvudloggen nästa gång loggen går att skriva till.
6. Om även spool misslyckas skrivs en emergency-logg bredvid skriptet i:
   .\EmergencyLogs\
7. Vid start kontrolleras befintlig logg. Om den är korrupt flyttas den automatiskt till:
   UpdateLog_Kontrollprovsfil.CORRUPT_BACKUP_yyyyMMdd_HHmmss.csv
   Därefter skapas en ny ren logg med korrekt header.

Så testar du säkert
-------------------
1. Lägg denna PS1 i en testmapp.
2. Kopiera raw_data.xlsx till samma testmapp eller använd en testkopia på N:.
3. Starta med explicita test-paths, exempel:

   powershell.exe -ExecutionPolicy Bypass -File .\kontrollprovsfil_v20260305_ROBUST_LOGG.ps1 `
     -RawDataPath "C:\Temp\KontrollprovTest\raw_data.xlsx" `
     -OutputDir "C:\Temp\KontrollprovTest\Rapporter" `
     -UpdateLogCsvPath "C:\Temp\KontrollprovTest\UpdateLog_Kontrollprovsfil.csv"

4. Gör en teständring.
5. Öppna CSV-loggen i Notepad först och kontrollera att ny rad har 13 semikolonseparerade fält.
6. Öppna därefter i Excel.

Viktigt inför skarp drift
-------------------------
- Byt inte ut raw_data.xlsx med filen från zippen. Den uppdaterade leveransen innehåller bara scriptet och denna instruktion.
- Behåll den gamla korrupta loggbackupen för historik/tidsstämplar, men räkna inte med att den går att använda för full spårbarhet.
- Om ni absolut inte vill att scriptet ska flytta undan korrupt logg automatiskt kan ni starta med:

   -AutoRepairUpdateLog $false

  Då stoppar scriptet i stället när loggen är korrupt.
