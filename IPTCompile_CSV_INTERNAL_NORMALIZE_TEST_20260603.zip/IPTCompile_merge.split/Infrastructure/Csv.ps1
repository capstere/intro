﻿function Get-CsvDelimiter { param([string]$Path)
    try {
        $first = Get-Content -LiteralPath $Path -Encoding Default -TotalCount 30 | Where-Object { $_ -and $_.Trim() } | Select-Object -First 1
        if (-not $first) { return ';' }
        $sc = ($first -split ';').Count; $cc = ($first -split ',').Count
        if ($cc -gt $sc -and $cc -ge 2) { return ',' } else { return ';' }
    } catch {
        Gui-Log "⚠️ Get-CsvDelimiter misslyckades: $($_.Exception.Message)" 'Warn'
        return ';'
    }
}

function Test-IsResampleCsv {
    <# Returnerar $true om CSV:n innehåller _RES_ i Sample ID-kolumnen (>= MinHits träffar).
       Hanterar både klassisk Test Summary-CSV och ny export som behöver Text-to-Columns (Tab + Comma). #>
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$MinHits = 3
    )

    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    $threshold = [Math]::Max(1, [int]$MinHits)

    try {
        $lines = @(Read-TestSummaryCsvTextLines -Path $Path)
        if (-not $lines -or $lines.Count -lt 10) { return $false }

        $profile = Get-TestSummaryCsvInternalProfile -Lines $lines
        if (-not $profile.HasHeader) { return $false }

        $sampleIdIdx = 2
        $hdr = @($profile.HeaderFields)
        if ($hdr) {
            for ($i = 0; $i -lt $hdr.Count; $i++) {
                $h = ($hdr[$i] + '').Trim()
                if ($h -imatch '^Sample\s*ID$' -or $h -ieq 'SampleID' -or $h -imatch '^Sample\s*Id$') {
                    $sampleIdIdx = $i
                    break
                }
            }
        }

        $resCount = 0
        for ($r = $profile.DataStartIndex; $r -lt $lines.Count; $r++) {
            $line = $lines[$r]
            if (-not $line -or $line.Trim().Length -eq 0) { continue }

            $fields = @(ConvertTo-TestSummaryTextToColumnsFields -Line $line)
            if (-not $fields -or $fields.Count -le $sampleIdIdx) { continue }

            $sid = ($fields[$sampleIdIdx] + '')
            if ($sid -imatch '_RES_') { $resCount++ }
        }

        return ($resCount -ge $threshold)
    } catch {
        try {
            Gui-Log ("⚠️ Test-IsResampleCsv misslyckades för '{0}': {1}" -f (Split-Path $Path -Leaf), $_.Exception.Message) 'Warn' 'DEBUG'
        } catch {}
        return $false
    }
}

function Resolve-CsvPrimaryAndResample {
    <# Klassificerar 0-2 CSV-filer till Primary + ev. Resample med samma regel som i buildflödet. #>
    param([string[]]$CsvPaths)

    $result = [pscustomobject]@{
        Ok             = $true
        PrimaryCsv     = $null
        ResampleCsv    = $null
        HasResample    = $false
        ErrorMessage   = $null
        WarningMessage = $null
    }

    $paths = @($CsvPaths | Where-Object { $_ -and (($_ + '').Trim().Length -gt 0) })

    if ($paths.Count -eq 0) { return $result }

    if ($paths.Count -eq 1) {
        if (Test-IsResampleCsv -Path $paths[0]) {
            $result.Ok = $false
            $result.ResampleCsv = $paths[0]
            $result.ErrorMessage = '❌ Enbart Resampling-CSV vald. Välj även Primary CSV innan rapport kan skapas.'
            return $result
        }
        $result.PrimaryCsv = $paths[0]
        return $result
    }

    if ($paths.Count -eq 2) {
        $isRes0 = Test-IsResampleCsv -Path $paths[0]
        $isRes1 = Test-IsResampleCsv -Path $paths[1]

        if ($isRes0 -and -not $isRes1) {
            $result.ResampleCsv = $paths[0]
            $result.PrimaryCsv = $paths[1]
        } elseif ($isRes1 -and -not $isRes0) {
            $result.PrimaryCsv = $paths[0]
            $result.ResampleCsv = $paths[1]
        } elseif (-not $isRes0 -and -not $isRes1) {
            $result.Ok = $false
            $result.ErrorMessage = '❌ Du har valt 2 CSV-filer men ingen Resampling CSV-fil. Avmarkera en fil eller välj korrekt Resampling CSV-fil.'
            return $result
        } else {
            $result.PrimaryCsv = $paths[0]
            $result.ResampleCsv = $paths[1]
            $result.WarningMessage = '⚠️ Båda CSV har _RES_ i Sample ID – autoväljer Resampling + Original.'
        }

        $result.HasResample = [bool]$result.ResampleCsv
        return $result
    }

    $result.Ok = $false
    $result.ErrorMessage = ("❌ Du har valt {0} CSV-filer. Välj max 2 (Primary + ev. Resample)." -f $paths.Count)
    return $result
}

function Get-AssayFromCsv { param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    $delim = Get-CsvDelimiter $Path
    try {
        $lines = Get-Content -LiteralPath $Path -Encoding Default
        if (-not $lines -or $lines.Count -lt $StartRow) { return $null }
        for ($i = ($StartRow-1); $i -lt $lines.Count; $i++) {
            $ln = $lines[$i]
            if (-not $ln -or $ln.Trim().Length -eq 0) { continue }
            $f = ConvertTo-CsvFields -Line $ln -Delimiter $delim
            if (-not $f -or $f.Length -lt 1) { continue }
            $a = ([string]$f[0]).Trim()
            if ($a -and $a -notmatch '^(?i)\s*assay\s*$') { return $a }
        }
    } catch {
        Gui-Log "⚠️ Kunde inte läsa Assay från CSV: $($_.Exception.Message)" 'Warn'
    }
    return $null
}

function Import-CsvRows { param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    $delim = Get-CsvDelimiter $Path
    $list  = New-Object System.Collections.Generic.List[object]
    try {
        $lines = Get-Content -LiteralPath $Path -Encoding Default
        if (-not $lines -or $lines.Count -lt $StartRow) { return @() }
        for ($i = ($StartRow-1); $i -lt $lines.Count; $i++) {
            $ln = $lines[$i]
            if (-not $ln -or $ln.Trim().Length -eq 0) { continue }
            $f = ConvertTo-CsvFields -Line $ln -Delimiter $delim
            if (-not $f -or ($f -join '').Trim().Length -eq 0) { continue }
            [void]$list.Add($f)
        }
    } catch {
        Gui-Log "⚠️ Kunde inte läsa rader från CSV: $($_.Exception.Message)" 'Warn'
    }
    return @($list.ToArray())
}

function ConvertTo-CsvFields {
    param(
        [Parameter(Mandatory=$true)][string]$Line,
        [string]$Delimiter
    )
    if ($null -eq $Line) { return @() }

    $del = $Delimiter
    if ([string]::IsNullOrWhiteSpace($del)) {
        # Upptäck avgränsare automatiskt (';' i svensk Excel-export, annars ',')
        $cSemi  = ([regex]::Matches($Line, ';')).Count
        $cComma = ([regex]::Matches($Line, ',')).Count
        $del = $(if ($cSemi -gt $cComma) { ';' } else { ',' })
    }

    $d  = [regex]::Escape($del)
    $rx = $d + '(?=(?:(?:[^"]*"){2})*[^"]*$)'
    $arr = [regex]::Split($Line, $rx)
    return ,@($arr | ForEach-Object { (($_ + '') -replace '^"|"$','').Trim() })
}



function Read-TestSummaryCsvTextLines {
    <#
      BOM-säker läsning av Test Summary CSV.
      Används endast för formatdetektion/normalisering så att resten av skriptet kan fortsätta läsa klassiskt format.
    #>
    param([Parameter(Mandatory)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path)) { return @() }

    $bytes = [System.IO.File]::ReadAllBytes($Path)
    if (-not $bytes -or $bytes.Length -eq 0) { return @() }

    $enc = [System.Text.Encoding]::Default
    $offset = 0

    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        $enc = New-Object System.Text.UTF8Encoding -ArgumentList $false, $true
        $offset = 3
    } elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
        $enc = [System.Text.Encoding]::Unicode
        $offset = 2
    } elseif ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF) {
        $enc = [System.Text.Encoding]::BigEndianUnicode
        $offset = 2
    }

    $text = $enc.GetString($bytes, $offset, $bytes.Length - $offset)
    if ($null -eq $text) { return @() }
    $text = ($text + '').Replace(([string][char]0xFEFF), '')
    return ,@($text -split "`r`n|`n|`r")
}

function ConvertTo-TestSummaryTextToColumnsFields {
    <#
      Motsvarar Excel: Text to Columns -> Delimited -> Tab + Comma -> General.
      Hanterar även nya exporten där hela logiska raden är omsluten av ett enda par citationstecken.
    #>
    param([AllowNull()][string]$Line)

    if ($null -eq $Line) { return @() }
    $s = ($Line + '').Replace(([string][char]0xFEFF), '').Replace(([string][char]0x200B), '')
    $sTrim = $s.Trim()

    # Ny export: hela raden kan vara en enda citerad textsträng: "Assay,Assay Version,Sample ID,..."
    if ($sTrim.Length -ge 2 -and $sTrim.StartsWith('"') -and $sTrim.EndsWith('"')) {
        $inner = $sTrim.Substring(1, $sTrim.Length - 2)
        if ($inner -match '[,\t]') {
            $s = $inner.Replace('""','"')
        }
    }

    if ([string]::IsNullOrWhiteSpace($s)) { return @() }

    # Split på comma eller tab, men inte inne i balanserade citationstecken.
    $arr = [regex]::Split($s, '[,\t](?=(?:(?:[^\"]*\"){2})*[^\"]*$)')
    $out = New-Object System.Collections.Generic.List[string]
    foreach ($item in @($arr)) {
        $v = ($item + '').Trim()
        if ($v.Length -ge 2 -and $v.StartsWith('"') -and $v.EndsWith('"')) {
            $v = $v.Substring(1, $v.Length - 2).Replace('""','"')
        }
        [void]$out.Add($v)
    }
    return ,@($out.ToArray())
}

function ConvertFrom-TestSummaryFieldsToCsvLine {
    param([object[]]$Fields)

    $parts = New-Object System.Collections.Generic.List[string]
    foreach ($field in @($Fields)) {
        $v = ($field + '')
        if ($v.Contains(',') -or $v.Contains('"') -or $v.Contains("`r") -or $v.Contains("`n")) {
            $v = '"' + $v.Replace('"','""') + '"'
        }
        [void]$parts.Add($v)
    }
    return ($parts.ToArray() -join ',')
}

function Get-TestSummaryCsvInternalProfile {
    param([Parameter(Mandatory)][string[]]$Lines)

    $result = [ordered]@{
        HasHeader          = $false
        HeaderIndex        = -1
        DataStartIndex     = -1
        IsLegacyShape      = $false
        NeedsNormalization = $false
        HeaderFields       = @()
    }

    if (-not $Lines -or $Lines.Count -eq 0) { return [pscustomobject]$result }

    $max = [Math]::Min($Lines.Count - 1, 30)
    for ($i = 0; $i -le $max; $i++) {
        $fields = @(ConvertTo-TestSummaryTextToColumnsFields -Line $Lines[$i])
        if (-not $fields -or $fields.Count -lt 3) { continue }

        $first = ($fields[0] + '').Trim()
        $hasSampleId = $false
        foreach ($f in $fields) {
            if ((($f + '').Trim()) -ieq 'Sample ID') { $hasSampleId = $true; break }
        }

        if ($first -ieq 'Assay' -and $hasSampleId) {
            $result.HasHeader = $true
            $result.HeaderIndex = $i
            $result.HeaderFields = @($fields)
            break
        }
    }

    if (-not $result.HasHeader) { return [pscustomobject]$result }

    $dataStart = $result.HeaderIndex + 1
    while ($dataStart -lt $Lines.Count) {
        $f = @(ConvertTo-TestSummaryTextToColumnsFields -Line $Lines[$dataStart])
        if ($f -and (($f -join '').Trim().Length -gt 0)) { break }
        $dataStart++
    }
    $result.DataStartIndex = $dataStart

    # Klassisk intern layout: header på rad 8 (index 7), tom rad 9, data från rad 10 (index 9).
    $result.IsLegacyShape = ($result.HeaderIndex -eq 7 -and $result.DataStartIndex -eq 9)

    # Normalisera om layouten är förskjuten, eller om header/data är packad som en enda citerad rad.
    $packedHeader = $false
    try {
        $rawHeader = ($Lines[$result.HeaderIndex] + '').Trim()
        $packedHeader = ($rawHeader.Length -ge 2 -and $rawHeader.StartsWith('"') -and $rawHeader.EndsWith('"') -and $rawHeader -match ',')
    } catch { $packedHeader = $false }

    $result.NeedsNormalization = (-not $result.IsLegacyShape) -or $packedHeader
    return [pscustomobject]$result
}

function Convert-TestSummaryCsvToLegacyInternalFormat {
    <#
      Skapar klassisk intern CSV-layout på TEMP-kopian:
        - header på rad 8 (index 7)
        - tom rad 9 (index 8)
        - data från rad 10 (index 9)
      Originalfilen på nätverket ska inte ändras; efter staging skrivs TEMP-kopian om.
    #>
    param(
        [Parameter(Mandatory)][string]$Path,
        [string]$StageDir,
        [string]$Label = 'CSV'
    )

    $lines = @(Read-TestSummaryCsvTextLines -Path $Path)
    $profile = Get-TestSummaryCsvInternalProfile -Lines $lines

    if (-not $profile.HasHeader) {
        return [pscustomobject]@{ Path=$Path; Changed=$false; Reason='No Test Summary header detected'; Profile=$profile }
    }

    if (-not $profile.NeedsNormalization) {
        return [pscustomobject]@{ Path=$Path; Changed=$false; Reason='Already legacy internal layout'; Profile=$profile }
    }

    $outPath = $Path
    $canWriteInPlace = $false
    if ($StageDir -and (Test-Path -LiteralPath $StageDir)) {
        try {
            $stageFull = [System.IO.Path]::GetFullPath($StageDir).TrimEnd([char]92)
            $pathFull  = [System.IO.Path]::GetFullPath($Path)
            if ($pathFull.StartsWith($stageFull, [System.StringComparison]::OrdinalIgnoreCase)) { $canWriteInPlace = $true }
        } catch { $canWriteInPlace = $false }
    }
    if (-not $canWriteInPlace) {
        $tmpRoot = if ($StageDir -and (Test-Path -LiteralPath $StageDir)) { $StageDir } else { [System.IO.Path]::GetTempPath() }
        $leaf = [System.IO.Path]::GetFileNameWithoutExtension($Path) + '.normalized.csv'
        $outPath = Join-Path $tmpRoot $leaf
    }

    $out = New-Object System.Collections.Generic.List[string]

    # Behåll metadata upp till rad 7 så gott det går, men i normaliserad comma-form.
    for ($i = 0; $i -lt 7; $i++) {
        if ($i -lt $lines.Count) {
            $mf = @(ConvertTo-TestSummaryTextToColumnsFields -Line $lines[$i])
            if ($mf -and $mf.Count -gt 0) { [void]$out.Add((ConvertFrom-TestSummaryFieldsToCsvLine -Fields $mf)) }
            else { [void]$out.Add('') }
        } else {
            [void]$out.Add('')
        }
    }

    [void]$out.Add((ConvertFrom-TestSummaryFieldsToCsvLine -Fields @($profile.HeaderFields)))
    [void]$out.Add('')

    for ($r = $profile.DataStartIndex; $r -lt $lines.Count; $r++) {
        $fields = @(ConvertTo-TestSummaryTextToColumnsFields -Line $lines[$r])
        if (-not $fields -or (($fields -join '').Trim().Length -eq 0)) { continue }
        [void]$out.Add((ConvertFrom-TestSummaryFieldsToCsvLine -Fields $fields))
    }

    [System.IO.File]::WriteAllLines($outPath, [string[]]$out.ToArray(), [System.Text.Encoding]::Default)

    return [pscustomobject]@{
        Path=$outPath
        Changed=$true
        Reason=('Normalized {0}: header index {1}, data index {2} -> legacy index 7/9' -f $Label, $profile.HeaderIndex, $profile.DataStartIndex)
        Profile=$profile
    }
}

function Get-CsvStats {
    param(
        [string]$Path,
        [string[]]$Lines
    )
    $out = [ordered]@{
        TestCount       = 0
        DupCount        = 0
        Duplicates      = @()
        LspValues       = @()
        LspOK           = $null
        InstrumentByType= [ordered]@{}
    }
    $lines = @($Lines)
    if ($lines.Count -eq 1 -and -not $lines[0]) { $lines = @() }
    if ($lines.Count -eq 0) {
        if (-not (Test-Path -LiteralPath $Path)) { return [pscustomobject]$out }
        try { $lines = @(Get-Content -LiteralPath $Path) } catch { Gui-Log "⚠️ Kunde inte läsa CSV-statistik: $($_.Exception.Message)" 'Warn'; return [pscustomobject]$out }
    }
    if ($lines.Count -lt 8) { return [pscustomobject]$out }
    $header = ConvertTo-CsvFields $lines[7]
    $dataLines = @()
    if ($lines.Count -gt 9) { $dataLines = $lines[9..($lines.Count-1)] }
    $csv = $null
    try {
        if ($dataLines.Count -gt 0) {
            $csv = ConvertFrom-Csv -InputObject ($dataLines -join "`n") -Header $header
        }
    } catch { $csv = $null }

    $cartSnList = New-Object System.Collections.Generic.List[string]
    $lspList    = New-Object System.Collections.Generic.List[string]
    $instrList  = New-Object System.Collections.Generic.List[string] 
    if ($csv) {
        foreach ($row in $csv) {
            $cart = $row.'Cartridge S/N'
            $lsp  = $row.'Reagent Lot ID'
            $ins  = $row.'Instrument S/N'
            if (-not $cart) { try { $cart = $row.Item(3) } catch {} }
            if (-not $ins)  { try { $ins  = $row.Item(6) } catch {} }
            if ($cart) { $cartSnList.Add( ($cart + '').Trim() ) }
            if ($lsp)  { $lspList.Add(  ($lsp  + '').Trim() ) }
            if ($ins)  { $instrList.Add(($ins  + '').Trim() ) }
        }
    } else {
        foreach ($ln in $dataLines) {
            if (-not $ln -or -not $ln.Trim()) { continue }
            $f = ConvertTo-CsvFields $ln
            if ($f.Count -lt 7) { continue }
            $cartSnList.Add( ($f[3] + '').Trim() )
            $lspList.Add(    ($f[4] + '').Trim() )
            $instrList.Add(  ($f[6] + '').Trim() )
        }
    }
    $cartSn = $cartSnList | Where-Object { $_ -and $_ -ne '' }
    $out.TestCount = @($cartSn).Count
    $dups = $cartSn | Group-Object | Where-Object { $_.Count -gt 1 }
    if ($dups) {
        # @() gör det robust när endast 1 grupp returneras (annars tolkas .Count som gruppens storlek)
        $out.DupCount   = @($dups).Count
        $out.Duplicates = @($dups) | ForEach-Object { "$($_.Name) x$($_.Count)" }
    }
    $lspClean = $lspList | ForEach-Object {
        $m = [regex]::Match($_, '(?<!\d)(\d{5})(?!\d)')
        if ($m.Success) { $m.Groups[1].Value } else { $null }
    } | Where-Object { $_ } | Select-Object -Unique
    $out.LspValues = @($lspClean)
    if (@($lspClean).Count -gt 0) {
        $out.LspOK = (@($lspClean).Count -eq 1)
    }
    $lut = @{}
    foreach ($k in $script:GXINF_Map.Keys) {
        $codes = $script:GXINF_Map[$k].Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ }
        foreach ($code in $codes) { $lut[$code] = $k }
    }
    foreach ($ins in ($instrList | Where-Object { $_ })) {
        $t = $null
        if ($lut.ContainsKey($ins)) { $t = $lut[$ins] } else { $t = 'Unknown' }
        if (-not $out.InstrumentByType.Contains($t)) { $out.InstrumentByType[$t] = 0 }
        $out.InstrumentByType[$t] = [int]$out.InstrumentByType[$t] + 1
    }
    return [pscustomobject]$out
}

function Import-CsvRowsStreaming {
    param(
        [Parameter(Mandatory)][string]$Path,
        [int]$StartRow = 10,
        [Parameter(Mandatory)][scriptblock]$ProcessRow
    )
    $delim = Get-CsvDelimiter -Path $Path
    $sr = $null
    try {
        $sr = [System.IO.StreamReader]::new($Path, [System.Text.Encoding]::UTF8, $true)
        $r = 0
        while (($line = $sr.ReadLine()) -ne $null) {
            $r++
            if ($r -lt $StartRow) { continue }
            if (-not $line -or $line.Trim().Length -eq 0) { continue }
            $fields = ConvertTo-CsvFields -Line $line -Delimiter $delim
            if ($fields -and (($fields -join '').Trim().Length -gt 0)) {
                & $ProcessRow -Fields $fields -RowIndex $r
            }
        }
    } finally {
        try { if ($sr) { $sr.Close() } } catch {}
        try { if ($sr) { $sr.Dispose() } } catch {}
    }
}
