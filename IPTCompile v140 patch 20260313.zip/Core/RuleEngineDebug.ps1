﻿function Write-RuleEngineDebugSheet {
param(
    [Parameter(Mandatory)][object]$Pkg,
    [Parameter(Mandatory)][pscustomobject]$RuleEngineResult,
    [Parameter(Mandatory=$false)][bool]$IncludeAllRows = $false,
    [Parameter(Mandatory=$false)][object[]]$DataSummaryFindings = @(),
    [Parameter(Mandatory=$false)][int]$StfCount = 0
)

# ============================================================================
# FÄRGDEFINITIONER (EPPlus-kompatibla)
# ============================================================================
$Colors = @{
    # Rubriker och sektioner
    HeaderBg       = [System.Drawing.Color]::FromArgb(68, 84, 106)    # Mörkblå
    HeaderFg       = [System.Drawing.Color]::White
    SectionBg      = [System.Drawing.Color]::FromArgb(217, 225, 242)  # Ljusblå
    SectionFg      = [System.Drawing.Color]::FromArgb(0, 32, 96)      # Mörkblå text
    
    # Status-färger
    OkBg           = [System.Drawing.Color]::FromArgb(198, 239, 206)  # Ljusgrön
    OkFg           = [System.Drawing.Color]::FromArgb(0, 97, 0)       # Mörkgrön
    
    # Major Functional (FP/FN) - MÖRKRÖD
    MajorBg        = [System.Drawing.Color]::FromArgb(255, 199, 206)  # Ljusröd
    MajorFg        = [System.Drawing.Color]::FromArgb(156, 0, 6)      # Mörkröd
    
    # Minor Functional / Max Pressure ≥90 - Ljusgul
    MinorBg        = [System.Drawing.Color]::FromArgb(255, 235, 156)  # Ljusgul
    MinorFg        = [System.Drawing.Color]::FromArgb(156, 101, 0)    # Brunish
    
    # Varningar (Instrument Error, övriga) - GRÅ
    WarningBg      = [System.Drawing.Color]::FromArgb(255, 235, 156)  # Ljusgul
    WarningFg      = [System.Drawing.Color]::FromArgb(156, 101, 0)    # Brunish
    
    # Tabell
    # Sätt tabellhuvudets bakgrund till samma mörkblå färg som huvudrubriken för att harmonisera med flikens färg
    TableHeaderBg  = [System.Drawing.Color]::FromArgb(68, 84, 106)    # Mörkblå (samma som HeaderBg)
    TableHeaderFg  = [System.Drawing.Color]::White
    TableAltRow    = [System.Drawing.Color]::FromArgb(232, 232, 232)  # Ljusgrå
    
    # Summering
    SummaryGoodBg  = [System.Drawing.Color]::FromArgb(198, 239, 206)  # Ljusgrön 0, 32, 96
}

# ============================================================================
# RADERA GAMMALT BLAD OCH SKAPA NYTT
# ============================================================================
try {
    $old = $Pkg.Workbook.Worksheets['QC Summary']
    if ($old) { $Pkg.Workbook.Worksheets.Delete($old) }
} catch {}

$ws = $Pkg.Workbook.Worksheets.Add('QC Summary')

# Sätt standardfont
try { 
    $ws.Cells.Style.Font.Name = 'Calibri'
    $ws.Cells.Style.Font.Size = 10
} catch {}

# ============================================================================
# KOLUMNDEFINITIONER (14 kolumner)
# ============================================================================
$headers = @(
    'Sample ID',
    'Error Code',
    'Avvikelse',
    'Notering',
    'Förväntat X/+',
    'Cartridge S/N',
    'Module S/N',
    'Förväntad Test Type',
    'Status',
    'Error Type',
    'Ersätts?',
    'Max Pressure (PSI)',
    'Test Result',
    'Error'
)

# ============================================================================
# HJÄLPFUNKTIONER
# ============================================================================

# Svensk översättning av RuleFlags

function _SvRuleFlags([string]$s) {
    $t = (($s + '')).Trim()
    if (-not $t) { return '' }

    $map = @{
        'TESTTYPE_MISMATCH'   = 'Fel Test Type'
        'SUFFIX_BAD'          = 'Fel suffix'
        'DQ_DUP_SAMPLEID'     = 'Dubblett Sample ID'
        'DQ_DUP_CARTSN'       = 'Dubblett Cart S/N'
        'DQ_ASSAYVER_OUTLIER' = 'Assay Version (outlier)'
        'DQ_ASSAY_OUTLIER'    = 'Assay (outlier)'
        'RUNNO_BAD'           = 'Fel Rep-Nr'
        'DELAM_PRESENT'       = 'Delam'
        'REPL_A1'             = 'Ers. A'
        'REPL_A2'             = 'Ers. AA'
        'REPL_A3'             = 'Ers. AA'
        'PREFIX_BAD'          = 'Fel prefix'
    }

    $tokens = @($t -split '[|,;]+' | ForEach-Object { ($_.Trim()) } | Where-Object { $_ })
    if (-not $tokens -or $tokens.Count -eq 0) { return $t }

    $out = foreach ($tok in $tokens) {
        if ($map.ContainsKey($tok)) { $map[$tok] } else { $tok }
    }
    return ($out -join ', ')
}

function Test-IsQcSummaryFailureRow {
    param([Parameter(Mandatory)][pscustomobject]$Row)

    $dev = (($Row.Deviation + '')).Trim()
    if ($dev.Length -gt 0 -and $dev -ne 'OK') { return $true }

    $obs = (($Row.ObservedCall + '')).Trim().ToUpperInvariant()
    if ($obs -eq 'ERROR') { return $true }

    $pressureFlag = $false
    try { $pressureFlag = [bool]$Row.PressureFlag } catch { $pressureFlag = $false }
    if ($pressureFlag) { return $true }

    if (((($Row.ErrorCode + '')).Trim()).Length -gt 0) { return $true }

    $status = (($Row.Status + '')).Trim()
    if ($status.Length -gt 0 -and $status -ne 'Done') { return $true }

    $rt = (($Row.GeneratesRetest + '')).Trim().ToUpperInvariant()
    if ($rt -in @('YES','Y','TRUE','1')) { return $true }

    return $false
}

function Test-ShouldWriteQcSummaryRow {
    param([Parameter(Mandatory)][pscustomobject]$Row)

    if (Test-IsQcSummaryFailureRow -Row $Row) { return $true }

    $rf = (($Row.RuleFlags + '')).Trim()
    return ($rf.Length -gt 0)
}

function Get-QcSummarySampleKeys {
    param([string]$SampleId)

    $keys = New-Object System.Collections.Generic.List[string]
    $exact = (($SampleId + '')).Trim().ToUpperInvariant()
    if (-not $exact) { return @() }

    [void]$keys.Add($exact)

    $firstUnderscore = $exact.IndexOf('_')
    if ($firstUnderscore -ge 0 -and $firstUnderscore -lt ($exact.Length - 1)) {
        $tail = $exact.Substring($firstUnderscore + 1).Trim()
        if ($tail -and $tail -ne $exact) {
            [void]$keys.Add($tail)
        }
    }

    return @($keys.ToArray() | Select-Object -Unique)
}

function Get-QcSummaryMatchingFindings {
    param(
        [Parameter(Mandatory)][string]$SampleId,
        [Parameter(Mandatory)][hashtable]$FindingsByKey
    )

    $matches = New-Object System.Collections.Generic.List[object]
    $seen = @{}
    foreach ($key in @(Get-QcSummarySampleKeys -SampleId $SampleId)) {
        if (-not $key -or -not $FindingsByKey.ContainsKey($key)) { continue }
        foreach ($finding in @($FindingsByKey[$key])) {
            $sig = ((($finding.Source + '') + '|' + ($finding.SampleId + '') + '|' + ($finding.Type + '')).Trim()).ToUpperInvariant()
            if (-not $seen.ContainsKey($sig)) {
                $seen[$sig] = $true
                [void]$matches.Add($finding)
            }
        }
    }
    return @($matches.ToArray())
}


# Skriv sektionsrubrik med styling

function Write-SectionHeader {
    param([int]$Row, [string]$Text, [int]$ColSpan = 4)
    
    $ws.Cells.Item($Row, 1).Value = $Text
    $rng = $ws.Cells[$Row, 1, $Row, $ColSpan]
    $rng.Merge = $true
    $rng.Style.Font.Bold = $true
    $rng.Style.Font.Size = 11
    $rng.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
    $rng.Style.Fill.BackgroundColor.SetColor($Colors.SectionBg)
    $rng.Style.Font.Color.SetColor($Colors.SectionFg)
    $rng.Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Medium
    $rng.Style.Border.Bottom.Color.SetColor($Colors.SectionFg)
}

# Skriv nyckel-värde par med valfri formatering

function Write-KV {
    param(
        [int]$Row, 
        [string]$Key, 
        $Value, 
        [int]$Col = 1,
        [switch]$Highlight,
        [switch]$Warning,
        [switch]$Good,
        [switch]$Major,
        [switch]$Minor,
        [switch]$Neutral
    )
    
    $ws.Cells.Item($Row, $Col).Value = $Key
    $ws.Cells.Item($Row, $Col).Style.Font.Bold = $true
    $ws.Cells.Item($Row, $Col + 1).Value = $Value
    
    if ($Major) {
        # Major Functional (FP/FN) - Ljusröd bakgrund
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.BackgroundColor.SetColor($Colors.MajorBg)
        $ws.Cells.Item($Row, $Col + 1).Style.Font.Color.SetColor($Colors.MajorFg)
        $ws.Cells.Item($Row, $Col + 1).Style.Font.Bold = $true
    }
    elseif ($Minor) {
        # Minor Functional - Gul bakgrund
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.BackgroundColor.SetColor($Colors.MinorBg)
        $ws.Cells.Item($Row, $Col + 1).Style.Font.Color.SetColor($Colors.MinorFg)
        $ws.Cells.Item($Row, $Col + 1).Style.Font.Bold = $true
    }
    elseif ($Neutral) {
        # Neutral grå bakgrund används t.ex. i Fel och varningar
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.BackgroundColor.SetColor($Colors.TableAltRow)
        $ws.Cells.Item($Row, $Col + 1).Style.Font.Bold = $true
    }
    elseif ($Highlight -or $Warning) {
        # Gul bakgrund (Instrument Error, övriga)
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.BackgroundColor.SetColor($Colors.WarningBg)
        $ws.Cells.Item($Row, $Col + 1).Style.Font.Bold = $true
    }
    elseif ($Good) {
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
        $ws.Cells.Item($Row, $Col + 1).Style.Fill.BackgroundColor.SetColor($Colors.SummaryGoodBg)
    }
}

# ============================================================================
# HUVUDRUBRIK
# ============================================================================
$row = 1
$ws.Cells.Item($row, 1).Value = 'QC Summary - Summering av din batch'
$titleRng = $ws.Cells[$row, 1, $row, 8]
$titleRng.Merge = $true
$titleRng.Style.Font.Bold = $true
$titleRng.Style.Font.Size = 14
$titleRng.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
$titleRng.Style.Fill.BackgroundColor.SetColor($Colors.HeaderBg)
$titleRng.Style.Font.Color.SetColor($Colors.HeaderFg)
$ws.Row($row).Height = 25
$row += 2

# ============================================================================
# HÄMTA DATA
# ============================================================================

$sum = $RuleEngineResult.Summary
$qc  = $RuleEngineResult.QC
$allRows = @($RuleEngineResult.Rows)
$failureRows = @($allRows | Where-Object { Test-IsQcSummaryFailureRow -Row $_ })
$effectiveDataSummaryFindings = @($DataSummaryFindings)
$coveredDataSummaryFindings = @()
$coveredDataSummaryFindingsByKey = @{}
if ($effectiveDataSummaryFindings.Count -gt 0 -and $failureRows.Count -gt 0) {
    $failureSampleKeySet = @{}
    foreach ($rowItem in $failureRows) {
        foreach ($key in @(Get-QcSummarySampleKeys -SampleId ($rowItem.SampleId + ''))) {
            if ($key) { $failureSampleKeySet[$key] = $true }
        }
    }

    $filteredDataSummaryFindings = New-Object System.Collections.Generic.List[object]
    foreach ($finding in $effectiveDataSummaryFindings) {
        $isCoveredByRuleEngine = $false
        foreach ($key in @(Get-QcSummarySampleKeys -SampleId ($finding.SampleId + ''))) {
            if ($key -and $failureSampleKeySet.ContainsKey($key)) {
                $isCoveredByRuleEngine = $true
                break
            }
        }
        if (-not $isCoveredByRuleEngine) {
            [void]$filteredDataSummaryFindings.Add($finding)
        } else {
            $coveredDataSummaryFindings += $finding
            foreach ($key in @(Get-QcSummarySampleKeys -SampleId ($finding.SampleId + ''))) {
                if (-not $key) { continue }
                if (-not $coveredDataSummaryFindingsByKey.ContainsKey($key)) { $coveredDataSummaryFindingsByKey[$key] = @() }
                $coveredDataSummaryFindingsByKey[$key] = @($coveredDataSummaryFindingsByKey[$key]) + @($finding)
            }
        }
    }
    $effectiveDataSummaryFindings = @($filteredDataSummaryFindings.ToArray())
}
$summaryDataSummaryFindings = @($effectiveDataSummaryFindings)
$coveredDelamFindings = @($coveredDataSummaryFindings | Where-Object { (($_.Type + '') -imatch 'Delamination') })
if ($coveredDelamFindings.Count -gt 0) {
    $summaryDataSummaryFindings = @($summaryDataSummaryFindings) + @($coveredDelamFindings)
}

# ============================================================================
# SEKTION 1: ÖVERGRIPANDE STATISTIK
# ============================================================================
Write-SectionHeader -Row $row -Text 'Övergripande data' -ColSpan 8
$row++

# Rad 1: Totalt, Assay, Version, Lot
$assayTxt = ''
if ($qc -and $qc.DistinctAssays -and $qc.DistinctAssays.Count -eq 1) { 
    $assayTxt = $qc.DistinctAssays[0] 
}
elseif ($qc -and $qc.DistinctAssays -and $qc.DistinctAssays.Count -gt 1) { 
    $assayTxt = "⚠ Flera ($($qc.DistinctAssays.Count))" 
}

$verTxt = ''
if ($qc -and $qc.DistinctAssayVersions -and $qc.DistinctAssayVersions.Count -eq 1) { 
    $verTxt = $qc.DistinctAssayVersions[0] 
}
elseif ($qc -and $qc.DistinctAssayVersions -and $qc.DistinctAssayVersions.Count -gt 1) { 
    $verTxt = "⚠ Flera ($($qc.DistinctAssayVersions.Count))" 
}

$lotTxt = ''
if ($qc -and $qc.DistinctReagentLots -and $qc.DistinctReagentLots.Count -eq 1) { 
    $lotTxt = $qc.DistinctReagentLots[0] 
}
elseif ($qc -and $qc.DistinctReagentLots -and $qc.DistinctReagentLots.Count -gt 1) { 
    $lotTxt = "⚠ Flera ($($qc.DistinctReagentLots.Count))" 
}

Write-KV -Row $row -Key 'Totalt tester' -Value $sum.Total -Col 1
Write-KV -Row $row -Key 'Assay' -Value $assayTxt -Col 3 -Warning:($assayTxt -like '*Flera*')
Write-KV -Row $row -Key 'Assay Version' -Value $verTxt -Col 5 -Warning:($verTxt -like '*Flera*')
Write-KV -Row $row -Key 'Reagent Lot' -Value $lotTxt -Col 7 -Warning:($lotTxt -like '*Flera*')
$row += 2

# ============================================================================
# SEKTION 2: AVVIKELSER (DEVIATION)
# ============================================================================
Write-SectionHeader -Row $row -Text 'Resultat Avvikelser' -ColSpan 8
$row++

# Beräkna OK-antal (utan procent)
$okCount = 0
if ($sum.DeviationCounts.ContainsKey('OK')) { $okCount = $sum.DeviationCounts['OK'] }
$fpCount = 0
if ($sum.DeviationCounts.ContainsKey('FP')) { $fpCount = $sum.DeviationCounts['FP'] }
$fnCount = 0
if ($sum.DeviationCounts.ContainsKey('FN')) { $fnCount = $sum.DeviationCounts['FN'] }

# Data Summary-fynd räknas in i totalsummorna här, men skrivs inte som egna subtype-rader
# i sektionen "Resultat Avvikelser". Detaljerna hör hemma i avvikelselistan längre ned.
$dsfMajorTotal = 0; $dsfMinorTotal = 0
$dsfByType = @{}
if ($summaryDataSummaryFindings -and $summaryDataSummaryFindings.Count -gt 0) {
    foreach ($dsf in $summaryDataSummaryFindings) {
        $label = ($dsf.Type + '').Trim()
        $sev   = ($dsf.Severity + '').Trim()
        if (-not $label) { continue }
        if (-not $dsfByType.ContainsKey($label)) {
            $dsfByType[$label] = @{ Count = 0; Severity = $sev }
        }
        $dsfByType[$label].Count++
        if ($sev -ieq 'Major') { $dsfMajorTotal++ } else { $dsfMinorTotal++ }
    }
}
$majorFunctionalDisplayCount = $fpCount + $fnCount + $dsfMajorTotal
$minorFunctionalDisplayCount = 0
if ($sum -and $sum.MinorFunctionalError -ne $null -and $sum.MinorFunctionalError -gt 0) {
    $minorFunctionalDisplayCount = [int]$sum.MinorFunctionalError
}
if ($effectiveDataSummaryFindings.Count -gt 0) {
    $minorFunctionalDisplayCount += @($effectiveDataSummaryFindings | Where-Object { (($_.Severity + '') -ieq 'Minor') }).Count
}

Write-KV -Row $row -Key '✓ Godkända (OK)' -Value $okCount -Col 1 -Good
$row++
if ($majorFunctionalDisplayCount -gt 0) {
    Write-KV -Row $row -Key '❌ Major Functional' -Value $majorFunctionalDisplayCount -Col 1 -Major
    $row++
}
if ($minorFunctionalDisplayCount -gt 0) {
    Write-KV -Row $row -Key '⚠ Minor Functional' -Value $minorFunctionalDisplayCount -Col 1 -Minor
    $row++
}

# Visa om inga avvikelser (om OK = Total och inga FP/FN/Minor/DataSummary)
if ($fpCount -eq 0 -and $fnCount -eq 0 -and $dsfMajorTotal -eq 0 -and $dsfMinorTotal -eq 0 -and $minorFunctionalDisplayCount -eq 0) {
    $ws.Cells.Item($row, 1).Value = '✓ Inga resultatavvikelser hittades'
    $ws.Cells.Item($row, 1).Style.Font.Italic = $true
    $ws.Cells.Item($row, 1).Style.Font.Color.SetColor($Colors.OkFg)
    $row++
}
$row++

# ============================================================================
# SEKTION 3: FEL OCH VARNINGAR
# ============================================================================
Write-SectionHeader -Row $row -Text 'STF + Övrigt' -ColSpan 8
$row++

# Instrument Error - GUL bakgrund
if ($sum -and $sum.InstrumentError -ne $null -and $sum.InstrumentError -gt 0) {
    Write-KV -Row $row -Key 'Instrument Error' -Value $sum.InstrumentError -Neutral
    $row++
}

# STF (Seal Test Failure)
if ($StfCount -gt 0) {
    Write-KV -Row $row -Key 'Seal Test Failure (STF)' -Value $StfCount -Warning
    $row++
}

# Delam och ersättningar
if ($sum -and $sum.DelamCount -ne $null -and $sum.DelamCount -gt 0) { 
    Write-KV -Row $row -Key 'Delamineringar' -Value $sum.DelamCount -Neutral
    $row++ 
}
if ($sum -and $sum.ReplacementCount -ne $null -and $sum.ReplacementCount -gt 0) { 
    Write-KV -Row $row -Key 'Ersättningar (A/AA/AAA)' -Value $sum.ReplacementCount -Neutral
    $row++ 
}

# Omkörning
if ($sum.RetestYes -gt 0) {
    Write-KV -Row $row -Key 'Behöver omkörning (YES)' -Value $sum.RetestYes -Neutral
    $row++
}

# Dubbletter
if ($qc) {
    if ($qc.DuplicateSampleIdCount -gt 0) {
        Write-KV -Row $row -Key 'Dubbletter Sample ID' -Value $qc.DuplicateSampleIdCount -Neutral
        $row++
    }
    if ($qc.DuplicateCartridgeSnCount -gt 0) {
        Write-KV -Row $row -Key 'Dubbletter Cartridge S/N' -Value $qc.DuplicateCartridgeSnCount -Neutral
        $row++
    }
    if ($qc.HotModuleCount -gt 0) {
        Write-KV -Row $row -Key 'Moduler med ≥3 fel' -Value $qc.HotModuleCount -Neutral
        $row++
    }
}

# Max Pressure ≥ 90 PSI - Ljusröd bakgrund
$pressureGE90 = @($allRows | Where-Object {
    $p = $null
    try { $p = [double]$_.MaxPressure } catch { $p = $null }
    return ($null -ne $p -and $p -ge 90)
}).Count
if ($pressureGE90 -gt 0) {
    Write-KV -Row $row -Key 'Max Pressure ≥ 90 PSI' -Value $pressureGE90 -Neutral
    $row++
}

# Max Pressure Failure utan Error Code - lägg till i Fel och varningar
$pressureFailNoError = @($allRows | Where-Object {
    $p = $null
    try { $p = [double]$_.MaxPressure } catch { $p = $null }
    $hasError = ((($_.ErrorCode + '')).Trim().Length -gt 0)
    return ($null -ne $p -and $p -ge 90 -and -not $hasError)
}).Count
if ($pressureFailNoError -gt 0) {
    Write-KV -Row $row -Key 'Max Pressure Failure (utan Error Code)' -Value $pressureFailNoError -Neutral
    $row++
}

$row++

<#
# ----------------------------------------------------------------------------
# Etiketter för visning
# ----------------------------------------------------------------------------
$labels = @{
    'POS'     = 'POS'
    'NEG'     = 'NEG'
    'UNKNOWN' = 'Okända fel'
}


# ============================================================================
# SEKTION 4: OBSERVERADE RESULTAT
# ============================================================================
Write-SectionHeader -Row $row -Text 'Fördelning av Negativa och Positiva resultat' -ColSpan 8
$row++
foreach ($k in @('POS','NEG','UNKNOWN')) {
    if ($sum.ObservedCounts.ContainsKey($k) -and $sum.ObservedCounts[$k] -gt 0) {

        $icon = switch ($k) {
            'POS'     { '✓' }
            'NEG'     { '✓' }
            'UNKNOWN' { '❓' }
            default   { '' }
        }
        $good = ($k -in @('POS','NEG'))
        # Hämta visningsnamn (fallback till nyckeln om saknas i mappningen)
        $label = if ($labels.ContainsKey($k)) { $labels[$k] } else { $k }
        Write-KV -Row $row `
                 -Key "$icon Antal $label" `
                 -Value $sum.ObservedCounts[$k] `
                 -Good:$good `
                 -Warning:(-not $good -and $sum.ObservedCounts[$k] -gt 0)
        $row++
    }
}

$row += 2

#>

# ============================================================================
# DETALJTABELL
# ============================================================================

# Filtrera rader
$rowsToWrite = $allRows
if (-not $IncludeAllRows) {
    $rowsToWrite = @($allRows | Where-Object { Test-ShouldWriteQcSummaryRow -Row $_ })
}

# Tabell-rubrik
$tableInfoRow = $row
$colCount = $headers.Count
$deviationCount = $rowsToWrite.Count
$hasResampleCsvRows = (@($allRows | Where-Object { (($_.SampleId + '') -imatch '_RES_') }).Count -gt 0)
$resampleDeviationCount = 0
$primaryDeviationCount = $deviationCount
if ($hasResampleCsvRows -and $deviationCount -gt 0) {
    $resampleDeviationCount = @($rowsToWrite | Where-Object { (($_.SampleId + '') -imatch '_RES_') }).Count
    $primaryDeviationCount = [Math]::Max(0, ($deviationCount - $resampleDeviationCount))
}
$tableInfoText = if ($deviationCount -eq 0) {
    if ($hasResampleCsvRows) {
        "CSV avvikelser - Inga CSV-avvikelser att visa (Primary: 0, Resample: 0)"
    } else {
        "CSV avvikelser - Inga CSV-avvikelser att visa"
    }
} elseif ($hasResampleCsvRows) {
    "CSV avvikelselista - {0} rader (Primary: {1}, Resample: {2})" -f $deviationCount, $primaryDeviationCount, $resampleDeviationCount
} else {
    "CSV avvikelselista - $deviationCount rader"
}

$ws.Cells.Item($row, 1).Value = $tableInfoText
$infoRng = $ws.Cells[$row, 1, $row, 6]
$infoRng.Merge = $true
$infoRng.Style.Font.Bold = $true
$infoRng.Style.Font.Size = 11
$row++

$tableHeaderRow = $row

# Skriv headers
for ($c = 1; $c -le $headers.Count; $c++) {
    $ws.Cells.Item($tableHeaderRow, $c).Value = $headers[$c - 1]
}

# Styla rubrikrad
$headerRange = $ws.Cells[$tableHeaderRow, 1, $tableHeaderRow, $headers.Count]
$headerRange.Style.Font.Bold = $true
$headerRange.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
$headerRange.Style.Fill.BackgroundColor.SetColor($Colors.TableHeaderBg)
$headerRange.Style.Font.Color.SetColor($Colors.TableHeaderFg)
$headerRange.Style.HorizontalAlignment = [OfficeOpenXml.Style.ExcelHorizontalAlignment]::Center

# AutoFilter och FreezePanes
try { $ws.Cells[$tableHeaderRow, 1, $tableHeaderRow, $headers.Count].AutoFilter = $true } catch {}
try { $ws.View.FreezePanes($tableHeaderRow + 1, 1) } catch {}

# Om inga rader
if (-not $rowsToWrite -or $rowsToWrite.Count -eq 0) {
    $noDevRow = $tableHeaderRow + 1
    $ws.Cells.Item($tableHeaderRow + 1, 1).Value = '✓ Inga CSV-avvikelser hittades i CSV-fil(erna) - alla tester OK!'
    $ws.Cells.Item($tableHeaderRow + 1, 1).Style.Font.Italic = $true
    $ws.Cells.Item($tableHeaderRow + 1, 1).Style.Font.Color.SetColor($Colors.OkFg)
    $noDevRng = $ws.Cells[$noDevRow, 1, $noDevRow, 6]
    $noDevRng.Merge = $true
    $endRow = $noDevRow
} else {
    # ============================================================================
    # SKRIV DATA MED BULK-OPERATION
    # ============================================================================
    $rowCount = $rowsToWrite.Count
    $data = New-Object 'object[,]' $rowCount, $colCount

    for ($i = 0; $i -lt $rowCount; $i++) {
        $r = $rowsToWrite[$i]

        # Kolumn 1: Sample ID
        $data[$i, 0] = ($r.SampleId + '')

        # Kolumn 2: Error Code och Kolumn 3: Avvikelse
        $rawDev = (($r.Deviation + '')).Trim().ToUpperInvariant()
        $errCode = (($r.ErrorCode + '')).Trim()
        $isKnown = $false
        $isMtbInd = $false
        $isExactMtbIndeterminateMinor = $false
        $matchingCoveredFindings = @()
        if ($coveredDataSummaryFindingsByKey.Count -gt 0) {
            $matchingCoveredFindings = @(Get-QcSummaryMatchingFindings -SampleId ($r.SampleId + '') -FindingsByKey $coveredDataSummaryFindingsByKey)
        }
        $hasCoveredDelamFinding = @($matchingCoveredFindings | Where-Object { (($_.Type + '') -imatch 'Delamination') }).Count -gt 0
        try { $isExactMtbIndeterminateMinor = (Test-IsMtbIndeterminateMinorFunctionalCase -Row $r) } catch { $isExactMtbIndeterminateMinor = $false }
        # Kontrollera om felkoden finns i regelbanken (numerisk kod)
        if ($rawDev -eq 'ERROR' -and $errCode -match '^\d{4,5}$') {
            try { $isKnown = $errLut.Codes.ContainsKey($errCode) } catch { $isKnown = $false }
        }
        # Exakt MTB-indeterminate-regel får egen etikett; äldre MTB-fallback behålls bakom den.
        try {
            if ((($r.Assay + '') -match '(?i)MTB') -and ((($r.TestResult + '') -match '(?i)INDETERMINATE'))) { $isMtbInd = $true }
        } catch {}
        switch ($rawDev) {
                'ERROR' {
            $isKnown = $false
            try { $isKnown = [bool]$r.IsKnownCode } catch { $isKnown = $false }
            if ($isExactMtbIndeterminateMinor) {
                $data[$i, 2] = 'Minor Functional (Indeterminate)'
            } elseif ($isMtbInd) {
                $data[$i, 2] = 'Minor Functional'
            } elseif ($isKnown -and $hasCoveredDelamFinding) {
                $data[$i, 2] = 'Minor Functional (Delamination)'
            } elseif ($isKnown) {
                $data[$i, 2] = 'Minor Functional'
            } else {
                $data[$i, 2] = 'Instrument Error'
            }
            $data[$i, 1] = ($r.ErrorCode + '')
        }
            'FP' {
                $data[$i, 2] = 'Major Functional'
                $data[$i, 1] = 'Falsk Positiv'
            }
            'FN' {
                $data[$i, 2] = 'Major Functional'
                $fnLabel = 'Falsk Negativ'
                try {
                    if ((Test-IsStrictMtbUltraAssay -Assay ($r.Assay + '')) -and (((($r.ExpectedCall + '')).Trim().ToUpperInvariant()) -eq 'POS_RIF_NOT_DETECTED')) {
                        $trU = (($r.TestResult + '')).ToUpperInvariant()
                        if ($trU -match 'RIF\s*RESISTANCE\s*DETECTED') {
                            $fnLabel = 'RIF Resistance DETECTED'
                        }
                        elseif ($trU -match 'MTB\s+TRACE\s+DETECTED') {
                            $fnLabel = 'MTB Trace DETECTED'
                        }
                    }
                } catch {}
                $data[$i, 1] = $fnLabel
            }
            'MISMATCH' {
                $data[$i, 2] = 'Instrument Error'
                $data[$i, 1] = 'Mismatch'
            }
            'UNKNOWN' {
                $data[$i, 2] = 'Instrument Error'
                $data[$i, 1] = 'Okänt'
            }
            'OK' {
                $data[$i, 2] = 'OK'
                $data[$i, 1] = ($r.ErrorCode + '')
            }
            default {
                $data[$i, 2] = 'OK'
                $data[$i, 1] = ($r.ErrorCode + '')
            }
        }

        # Kolumn 4: Notering (RuleFlags)
        $data[$i, 3] = (_SvRuleFlags ($r.RuleFlags + ''))

        # Kolumn 5: Förväntat X/+
        $sc = (($r.SuffixCheck + '')).Trim().ToUpperInvariant()
        if ($sc -and $sc -ne 'OK') {
            $expectedSuffix = ($r.ExpectedSuffix + '')
            if (-not $expectedSuffix) { $expectedSuffix = '' }
            $data[$i, 4] = $expectedSuffix
        } else {
            $data[$i, 4] = 'OK'
        }

        # Kolumn 6: Cartridge S/N
        $data[$i, 5] = ($r.CartridgeSN + '')

        # Kolumn 7: Module S/N
        $data[$i, 6] = ($r.ModuleSN + '')

        # Kolumn 8: Förväntad Test Type
        $expTestType = ($r.ExpectedTestType + '')
        $obsTestType = (($r.TestType + '')).Trim()
        if ($expTestType -and $obsTestType -and ($expTestType -ne $obsTestType)) {
            $data[$i, 7] = $expTestType
        } else {
            $data[$i, 7] = 'OK'
        }

        # Kolumn 9: Status
        $data[$i, 8] = ($r.Status + '')

        # Kolumn 10: Error Type
        $data[$i, 9] = ($r.ErrorName + '')
      
        # Kolumn 11: Ersätts?
        # Om avvikelsen är Major Functional => ersätts inte (override)
        $devLabel = ($data[$i, 2] + '')
        if ($devLabel -eq 'Major Functional') {
        $data[$i, 10] = 'Nej'   # eller 'Nej' om du föredrar
        }
        else {
        $rt = (($r.GeneratesRetest + '')).Trim().ToUpperInvariant()
        if ($rt -in @('YES','Y','TRUE','1')) {
            $data[$i, 10] = 'Ja'
        } elseif ($rt) {
            $data[$i, 10] = 'Nej'
        } else {
            $data[$i, 10] = ''
        }
        }
        
        # Kolumn 12: Max Pressure (PSI)
        if ($null -ne $r.MaxPressure) {
            $data[$i, 11] = $r.MaxPressure
        } else {
            $data[$i, 11] = ''
        }

        # Kolumn 13: Test Result
        $data[$i, 12] = ($r.TestResult + '')

        # Kolumn 14: Error (feltext)
        $data[$i, 13] = ($r.ErrorText + '')
    }

    $startRow = $tableHeaderRow + 1
    $endRow = $startRow + $rowCount - 1
    $rng = $ws.Cells[$startRow, 1, $endRow, $colCount]
    $rng.Value = $data

    # ============================================================================
    # FÄRGKODNING AV DATA-RADER (baserat på Deviation)
    # ============================================================================
    for ($i = 0; $i -lt $rowCount; $i++) {
        $dataRow = $startRow + $i
        $r = $rowsToWrite[$i]
        $dev = (($r.Deviation + '')).Trim().ToUpperInvariant()
        
        $rowRange = $ws.Cells[$dataRow, 1, $dataRow, $colCount]
        
        # Avvikelse-kolumnen (kolumn C, index 3)
        $devCell = $ws.Cells.Item($dataRow, 3)
        
        # Error Code-kolumnen (kolumn B, index 2) - för Major Functional
        $errorCodeCell = $ws.Cells.Item($dataRow, 2)
        
        switch ($dev) {
            'FP' {
                # Major Functional - Mörkröd bakgrund, vit text
                $devCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $devCell.Style.Fill.BackgroundColor.SetColor($Colors.MajorBg)
                $devCell.Style.Font.Color.SetColor($Colors.MajorFg)
                $devCell.Style.Font.Bold = $true
                # Färgmarkera även Error Code-kolumnen
                $errorCodeCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $errorCodeCell.Style.Fill.BackgroundColor.SetColor($Colors.MajorBg)
                $errorCodeCell.Style.Font.Color.SetColor($Colors.MajorFg)
                $errorCodeCell.Style.Font.Bold = $true
            }
            'FN' {
                # Major Functional - Mörkröd bakgrund, vit text
                $devCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $devCell.Style.Fill.BackgroundColor.SetColor($Colors.MajorBg)
                $devCell.Style.Font.Color.SetColor($Colors.MajorFg)
                $devCell.Style.Font.Bold = $true
                # Färgmarkera även Error Code-kolumnen
                $errorCodeCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $errorCodeCell.Style.Fill.BackgroundColor.SetColor($Colors.MajorBg)
                $errorCodeCell.Style.Font.Color.SetColor($Colors.MajorFg)
                $errorCodeCell.Style.Font.Bold = $true
            }
            'ERROR' {
                # Differentiera mellan Minor Functional och Instrument Error
                $disp = ($data[$i, 2] + '')
                if ($disp -eq 'Instrument Error') {
                    # Instrument Error - använd varningsfärg (gul)
                    $devCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                    $devCell.Style.Fill.BackgroundColor.SetColor($Colors.WarningBg)
                    $devCell.Style.Font.Color.SetColor($Colors.WarningFg)
                    # Error Code-kolumn: samma varningsfärg
                    $errorCodeCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                    $errorCodeCell.Style.Fill.BackgroundColor.SetColor($Colors.WarningBg)
                    $errorCodeCell.Style.Font.Color.SetColor($Colors.WarningFg)
                } else {
                    # Minor Functional - ljusgul bakgrund
                    $devCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                    $devCell.Style.Fill.BackgroundColor.SetColor($Colors.MinorBg)
                    $devCell.Style.Font.Color.SetColor($Colors.MinorFg)
                    # Error Code-kolumn: samma Minor-färg
                    $errorCodeCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                    $errorCodeCell.Style.Fill.BackgroundColor.SetColor($Colors.MinorBg)
                    $errorCodeCell.Style.Font.Color.SetColor($Colors.MinorFg)
                }
                $devCell.Style.Font.Bold = $true
                $errorCodeCell.Style.Font.Bold = $true
            }
            'MISMATCH' {
                # Varning - Gul bakgrund
                $devCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $devCell.Style.Fill.BackgroundColor.SetColor($Colors.WarningBg)
                $devCell.Style.Font.Color.SetColor($Colors.WarningFg)
                $devCell.Style.Font.Bold = $true
                # Error Code-kolumn: samma varningsfärg
                $errorCodeCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $errorCodeCell.Style.Fill.BackgroundColor.SetColor($Colors.WarningBg)
                $errorCodeCell.Style.Font.Color.SetColor($Colors.WarningFg)
                $errorCodeCell.Style.Font.Bold = $true
            }
            'UNKNOWN' {
                # Okänt/Instrument Error - Gul bakgrund
                $devCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $devCell.Style.Fill.BackgroundColor.SetColor($Colors.WarningBg)
                $devCell.Style.Font.Color.SetColor($Colors.WarningFg)
                $devCell.Style.Font.Bold = $true
                # Error Code-kolumn: samma varningsfärg
                $errorCodeCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $errorCodeCell.Style.Fill.BackgroundColor.SetColor($Colors.WarningBg)
                $errorCodeCell.Style.Font.Color.SetColor($Colors.WarningFg)
                $errorCodeCell.Style.Font.Bold = $true
            }
        }
        
        # Markera "Ersätts? = Ja" med gul bakgrund (kolumn 11)
        $ersattsVal = ($data[$i, 10] + '').Trim()
        if ($ersattsVal -eq 'Ja') {
            $ersattsCell = $ws.Cells.Item($dataRow, 11)
            $ersattsCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $ersattsCell.Style.Fill.BackgroundColor.SetColor($Colors.WarningBg)
            $ersattsCell.Style.Font.Bold = $true
        }

        # Markera högt tryck (≥90 PSI) med ljusröd (Minor-nivå) på kolumn 12
        try {
            $pressure = $null
            if ($r.MaxPressure -ne $null) { $pressure = [double]$r.MaxPressure }
            if ($pressure -ne $null -and $pressure -ge 90) {
                $pressCell = $ws.Cells.Item($dataRow, 12)
                $pressCell.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $pressCell.Style.Fill.BackgroundColor.SetColor($Colors.MinorBg)
                $pressCell.Style.Font.Color.SetColor($Colors.MinorFg)
                $pressCell.Style.Font.Bold = $true
            }
        } catch {}
        
        # Varannan rad med ljusgrå bakgrund (zebra-ränder) för rader utan avvikelse-färg
        if ($i % 2 -eq 1 -and $dev -eq 'OK') {
            $rowRange.Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $rowRange.Style.Fill.BackgroundColor.SetColor($Colors.TableAltRow)
        }
    }
}


# ============================================================================
# DATA SUMMARY (grupperat per källa: 'Data Summary' och 'Resample Data Summary')
# ============================================================================
$visualRow = $endRow + 2
if ($effectiveDataSummaryFindings -and $effectiveDataSummaryFindings.Count -gt 0) {
    # Gruppera findings per Source-bladnamn (bevara ordning: Primary först)
    $dsfGroups = [ordered]@{}
    foreach ($dsf in $effectiveDataSummaryFindings) {
        $src = ($dsf.Source + '').Trim()
        if (-not $src) { $src = 'Data Summary' }
        if (-not $dsfGroups.Contains($src)) { $dsfGroups[$src] = @() }
        # PS 5.1: undvik '+=' direkt på hashtable-index (kan kasta op_Addition på System.Object[])
        $dsfGroups[$src] = @($dsfGroups[$src]) + @($dsf)
    }

    foreach ($srcName in $dsfGroups.Keys) {
        $srcFindings = @($dsfGroups[$srcName])

        # Deduplicera (samma SampleId+Type → behåll första)
        $dsfSeen = @{}
        $dsfDeduped = @()
        foreach ($dsf in $srcFindings) {
            $dsfKey = (($dsf.SampleId + '').Trim() + '|' + ($dsf.Type + '').Trim()).ToUpperInvariant()
            if (-not $dsfSeen.ContainsKey($dsfKey)) {
                $dsfSeen[$dsfKey] = $true
                $dsfDeduped += $dsf
            }
        }
        if ($dsfDeduped.Count -eq 0) { continue }

        # Sortera: Major först, sedan Minor, inom varje grupp: Type → SampleId
        $dsfSorted = @($dsfDeduped | Sort-Object @{Expression={if(($_.Severity+'') -ieq 'Major'){0}else{1}}}, @{Expression={$_.Type}}, @{Expression={$_.SampleId}})

        # Sektionsrubrik: t.ex. "Data Summary" eller "Resample Data Summary"
        Write-SectionHeader -Row $visualRow -Text $srcName -ColSpan 8
        $visualRow++

        # Underrubrik
        $ws.Cells.Item($visualRow, 1).Value = 'Sample ID'
        $ws.Cells.Item($visualRow, 2).Value = 'Failure Check'
        $ws.Cells.Item($visualRow, 3).Value = 'Comment (drop-down menu available)'
        for ($vc = 1; $vc -le 3; $vc++) {
            $ws.Cells.Item($visualRow, $vc).Style.Font.Bold = $true
            $ws.Cells.Item($visualRow, $vc).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
            $ws.Cells.Item($visualRow, $vc).Style.Fill.BackgroundColor.SetColor($Colors.HeaderBg)
            $ws.Cells.Item($visualRow, $vc).Style.Font.Color.SetColor($Colors.HeaderFg)
        }
        $grpHeaderRow = $visualRow
        $visualRow++

        foreach ($dsf in $dsfSorted) {
            $ws.Cells.Item($visualRow, 1).Value = ($dsf.SampleId + '')
            $ws.Cells.Item($visualRow, 2).Value = ($dsf.Type + '')
            $ws.Cells.Item($visualRow, 3).Value = ($dsf.Comment + '')

            $dsfSev = ($dsf.Severity + '')
            if ($dsfSev -ieq 'Major') {
                $ws.Cells.Item($visualRow, 2).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $ws.Cells.Item($visualRow, 2).Style.Fill.BackgroundColor.SetColor($Colors.MajorBg)
                $ws.Cells.Item($visualRow, 2).Style.Font.Color.SetColor($Colors.MajorFg)
                $ws.Cells.Item($visualRow, 2).Style.Font.Bold = $true
            } elseif ($dsfSev -ieq 'Minor') {
                $ws.Cells.Item($visualRow, 2).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                $ws.Cells.Item($visualRow, 2).Style.Fill.BackgroundColor.SetColor($Colors.MinorBg)
                $ws.Cells.Item($visualRow, 2).Style.Font.Color.SetColor($Colors.MinorFg)
                $ws.Cells.Item($visualRow, 2).Style.Font.Bold = $true
            }

            # Zebra-ränder
            $vIdx = $visualRow - ($grpHeaderRow + 1)
            if ($vIdx % 2 -eq 1) {
                for ($vc = 1; $vc -le 3; $vc++) {
                    $ws.Cells.Item($visualRow, $vc).Style.Fill.PatternType = [OfficeOpenXml.Style.ExcelFillStyle]::Solid
                    if ($vc -ne 2) { $ws.Cells.Item($visualRow, $vc).Style.Fill.BackgroundColor.SetColor($Colors.TableAltRow) }
                }
            }
            $visualRow++
        }

        # Ramar per grupp
        try {
            $dsfTableRange = $ws.Cells[($grpHeaderRow), 1, ($visualRow - 1), 3]
            $dsfTableRange.Style.Border.Top.Style    = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $dsfTableRange.Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $dsfTableRange.Style.Border.Left.Style   = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $dsfTableRange.Style.Border.Right.Style  = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
            $dsfTableRange.Style.Border.Top.Color.SetColor([System.Drawing.Color]::LightGray)
            $dsfTableRange.Style.Border.Bottom.Color.SetColor([System.Drawing.Color]::LightGray)
            $dsfTableRange.Style.Border.Left.Color.SetColor([System.Drawing.Color]::LightGray)
            $dsfTableRange.Style.Border.Right.Color.SetColor([System.Drawing.Color]::LightGray)
        } catch {}

        $visualRow++  # Tom rad mellan grupper
    }

    $endRow = $visualRow - 1
}

# ============================================================================
# RAMAR OCH FORMATERING
# ============================================================================

# Lägg till tunna ramar runt alla dataceller
try {
    $tableRange = $ws.Cells[$tableHeaderRow, 1, $endRow, $colCount]
    $tableRange.Style.Border.Top.Style    = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
    $tableRange.Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
    $tableRange.Style.Border.Left.Style   = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
    $tableRange.Style.Border.Right.Style  = [OfficeOpenXml.Style.ExcelBorderStyle]::Thin
    $tableRange.Style.Border.Top.Color.SetColor([System.Drawing.Color]::LightGray)
    $tableRange.Style.Border.Bottom.Color.SetColor([System.Drawing.Color]::LightGray)
    $tableRange.Style.Border.Left.Color.SetColor([System.Drawing.Color]::LightGray)
    $tableRange.Style.Border.Right.Color.SetColor([System.Drawing.Color]::LightGray)
} catch {}

# Tjockare ram runt rubrikrad
try {
    $headerRange.Style.Border.Bottom.Style = [OfficeOpenXml.Style.ExcelBorderStyle]::Medium
    $headerRange.Style.Border.Bottom.Color.SetColor([System.Drawing.Color]::FromArgb(68, 84, 106))
} catch {}

# ============================================================================
# KOLUMNBREDDER
# ============================================================================
try {
    $rAll = $ws.Cells[1, 1, $endRow, $colCount]
    if (Get-Command Safe-AutoFitColumns -ErrorAction SilentlyContinue) {
        Safe-AutoFitColumns -Ws $ws -Range $rAll -Context 'QC Summary'
    } else {
        $rAll.AutoFitColumns() | Out-Null
    }
} catch {}

# Sätt minbredd för vissa kolumner
try {
    $ws.Column(1).Width = [Math]::Max($ws.Column(1).Width, 15)   # Sample ID
    $ws.Column(3).Width = [Math]::Max($ws.Column(3).Width, 14)   # Avvikelse
    $ws.Column(7).Width = [Math]::Max($ws.Column(7).Width, 14)   # Cartridge S/N
    # Justera bredder efter att kolumner tagits bort: feltextkolumnen finns nu på kolumn 14
    $ws.Column(14).Width = [Math]::Max($ws.Column(14).Width, 30) # Error (kan vara lång)
} catch {}

# ============================================================================
# FLIK-FÄRG
# ============================================================================
# Grön om inga avvikelser, annars orange
if ($deviationCount -eq 0) {
    $ws.TabColor = [System.Drawing.Color]::Green
} elseif ($deviationCount -le 5) {
    $ws.TabColor = [System.Drawing.Color]::Orange
} else {
    $ws.TabColor = [System.Drawing.Color]::Red
}

return $ws
}
