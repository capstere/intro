﻿# Extracted from Main.ps1. Dot-sourced by Main.ps1; intentionally uses caller scope.
#region GUI 

Update-Splash "Startar…"
Close-Splash

# ---- Sessionsspårning ----
$script:SessionStats = @{
    ReportCount     = 0
    TotalBuildMs    = 0
    TotalTestsBuilt = 0
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "IPTCompile – $ScriptVersion"
$form.AutoScaleMode = 'Dpi'

# Layout-fix 2026-05-21:
# Använd inte fast MinimumSize 980x930. På lägre skärmar gör det att formuläret
# hamnar utanför WorkingArea och att nederdelen kapas. Formuläret får önskad
# storlek på stora skärmar, men begränsas automatiskt till aktuell skärm.
$script:IptPreferredFormWidth  = 980
$script:IptPreferredFormHeight = 930
$script:IptMinimumFormWidth    = 900
$script:IptMinimumFormHeight   = 640
$script:IptScreenMarginX       = 12
$script:IptScreenMarginY       = 8
$script:IptSignatureExtraHeight = 40
try {
    $script:IptWorkingArea = [System.Windows.Forms.Screen]::FromPoint([System.Windows.Forms.Cursor]::Position).WorkingArea
} catch {
    $script:IptWorkingArea = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
}
try {
    $targetWidth  = [Math]::Min($script:IptPreferredFormWidth,  [Math]::Max(720, $script:IptWorkingArea.Width  - $script:IptScreenMarginX))
    $targetHeight = [Math]::Min($script:IptPreferredFormHeight, [Math]::Max(620, $script:IptWorkingArea.Height - $script:IptScreenMarginY))
    $minWidth     = [Math]::Min($script:IptMinimumFormWidth,    [Math]::Max(720, $script:IptWorkingArea.Width  - $script:IptScreenMarginX))
    $minHeight    = [Math]::Min($script:IptMinimumFormHeight,   [Math]::Max(600, $script:IptWorkingArea.Height - $script:IptScreenMarginY))
    $form.Size        = New-Object System.Drawing.Size($targetWidth, $targetHeight)
    $form.MinimumSize = New-Object System.Drawing.Size($minWidth, $minHeight)
} catch {
    $form.Size        = New-Object System.Drawing.Size(980,720)
    $form.MinimumSize = New-Object System.Drawing.Size(900,680)
}
$form.StartPosition = 'Manual'
$form.BackColor = [System.Drawing.Color]::WhiteSmoke
$form.AutoScroll  = $false
$form.MaximizeBox = $false
$form.Padding     = New-Object System.Windows.Forms.Padding(8)
$form.Font        = New-Object System.Drawing.Font('Segoe UI',10)

function Ensure-MainWindowFitsWorkingArea {
    try {
        if (-not $form) { return }
        $wa = [System.Windows.Forms.Screen]::FromControl($form).WorkingArea
        $maxW = [Math]::Max(720, $wa.Width  - $script:IptScreenMarginX)
        $maxH = [Math]::Max(600, $wa.Height - $script:IptScreenMarginY)
        if ($form.Width  -gt $maxW) { $form.Width  = $maxW }
        if ($form.Height -gt $maxH) { $form.Height = $maxH }
        $x = $wa.Left + [int](($wa.Width  - $form.Width)  / 2)
        $y = $wa.Top  + [int](($wa.Height - $form.Height) / 2)
        if ($x -lt $wa.Left) { $x = $wa.Left }
        if ($y -lt $wa.Top)  { $y = $wa.Top }
        if (($x + $form.Width)  -gt $wa.Right)  { $x = $wa.Right  - $form.Width }
        if (($y + $form.Height) -gt $wa.Bottom) { $y = $wa.Bottom - $form.Height }
        $form.Location = New-Object System.Drawing.Point($x, $y)
        # $script:BaseFormHeight = $form.Height
    } catch {}
}

$form.Add_Shown({
    try {
        Show-ReleaseNotesIfNewVersion -Version $ScriptVersion -RootPath $ScriptRootPath
    } catch {}
})
$form.KeyPreview = $true
$form.add_KeyDown({
    # F5 → Skapa rapport (samma som att klicka Build-knappen)
    if ($_.KeyCode -eq [System.Windows.Forms.Keys]::F5) {
        $_.Handled = $true
        if ($btnBuild.Enabled -and -not $script:BuildInProgress) {
            $btnBuild.PerformClick()
        }
        return
    }
    # Ctrl+L → Rensa logg
    if ($_.Control -and $_.KeyCode -eq [System.Windows.Forms.Keys]::L) {
        $_.Handled = $true
        try { $outputBox.Text = ''; $outputBox.ForeColor = [System.Drawing.SystemColors]::WindowText; $script:_logPlaceholderActive = $false } catch {}
        return
    }
    # Ctrl+N → Nytt (rensa alla filer)
    if ($_.Control -and $_.KeyCode -eq [System.Windows.Forms.Keys]::N) {
        $_.Handled = $true
        if (-not $script:BuildInProgress) { try { Clear-GUI } catch {} }
        return
    }
    # Ctrl+O → Öppna senaste rapport
    if ($_.Control -and $_.KeyCode -eq [System.Windows.Forms.Keys]::O) {
        $_.Handled = $true
        if ($global:LastReportPath -and (Test-Path -LiteralPath $global:LastReportPath)) {
            try { Start-Process -FilePath $global:LastReportPath } catch {}
        }
        return
    }
    if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Escape) {
        if ($script:BuildInProgress) {
            $_.Handled = $true
            Gui-Log '⚠️ Rapportgenerering pågår – avbryt inte.' 'Warn'
            return
        }
        $form.Close(); return
    }
    # Hemlig dev-toggle: Ctrl + Alt + T
    try {
        if ($_.Control -and $_.Alt -and ($_.KeyCode -eq [System.Windows.Forms.Keys]::T)) {
            if ($script:btnMove3) {
                $script:btnMove3.Visible = -not $script:btnMove3.Visible
                try {
                    if ($script:btnMove3.Visible) { Gui-Log "TEST-knapp synlig." 'Info' }
                    else                          { Gui-Log "TEST-knapp dold." 'Info' }
                } catch {}
            }
            $_.Handled = $true
        }
    } catch {}
})

# ---------- Menyrad ----------
$menuStrip = New-Object System.Windows.Forms.MenuStrip
$menuStrip.Dock='Top'; $menuStrip.GripStyle='Hidden'
$menuStrip.ImageScalingSize = New-Object System.Drawing.Size(20,20)
$menuStrip.Padding = New-Object System.Windows.Forms.Padding(8,6,0,6)
$menuStrip.Font = New-Object System.Drawing.Font('Segoe UI',10)
$miArkiv   = New-Object System.Windows.Forms.ToolStripMenuItem('🗂️ Arkiv')
$miVerktyg = New-Object System.Windows.Forms.ToolStripMenuItem('🛠️ Verktyg')
$miHelp    = New-Object System.Windows.Forms.ToolStripMenuItem('📖 Instruktioner')
$miAbout   = New-Object System.Windows.Forms.ToolStripMenuItem('ℹ️ Om')
$miCopyLog = New-Object System.Windows.Forms.ToolStripMenuItem('📋 Kopiera logg')
$miCopyLog.ShortcutKeyDisplayString = 'Ctrl+L rensa'
$miScan  = New-Object System.Windows.Forms.ToolStripMenuItem('🔍 Sök filer')
$miBuild = New-Object System.Windows.Forms.ToolStripMenuItem('✅ Skapa rapport')
$miBuild.ShortcutKeyDisplayString = 'F5'
$miExit  = New-Object System.Windows.Forms.ToolStripMenuItem('❌ Avsluta')

# Rensa ev. gamla undermenyer
$miArkiv.DropDownItems.Clear()
$miVerktyg.DropDownItems.Clear()
$miHelp.DropDownItems.Clear()

# ----- Arkiv -----
$miNew         = New-Object System.Windows.Forms.ToolStripMenuItem('🆕 Nytt')
$miNew.ShortcutKeyDisplayString = 'Ctrl+N'
$miOpenRecent  = New-Object System.Windows.Forms.ToolStripMenuItem('📂 Öppna senaste rapport')
$miOpenRecent.ShortcutKeyDisplayString = 'Ctrl+O'
$miArkiv.DropDownItems.AddRange(@(
    $miNew,
    $miOpenRecent,
    (New-Object System.Windows.Forms.ToolStripSeparator),
    $miExit
))

$miCopyLog.add_Click({
    try {
        $logText = ''
        foreach ($item in $logBox.Items) { $logText += "$item`r`n" }
        if ($logText) {
            [System.Windows.Forms.Clipboard]::SetText($logText)
            Gui-Log "📋 Logg kopierad till urklipp ($($logBox.Items.Count) rader)." 'Info'
        }
    } catch { Gui-Log "⚠️ Kunde inte kopiera logg: $($_.Exception.Message)" 'Warn' }
})

# ----- Verktyg -----
$miScript1   = New-Object System.Windows.Forms.ToolStripMenuItem('📜 Kontrollprovsfil-skript')
$miScript2   = New-Object System.Windows.Forms.ToolStripMenuItem('📜 Aktivera Kontrollprovsfil')
$miScript3   = New-Object System.Windows.Forms.ToolStripMenuItem('📅 Ändra datum på filer')
$miScript4   = New-Object System.Windows.Forms.ToolStripMenuItem('🗂️ AutoMappscript Control')
$miScript5   = New-Object System.Windows.Forms.ToolStripMenuItem('📄 AutoMappscript Dashboard')
$miToggleSignSamm   = New-Object System.Windows.Forms.ToolStripMenuItem($(if (Test-SealTestMergedMode) { '✅ Aktivera signering (Seal Test-fil)' } else { '✅ Aktivera signering (Seal Test NEG+POS)' }))
$miToggleSignGransk = New-Object System.Windows.Forms.ToolStripMenuItem('✅ Aktivera signering (Granskning)')
$miVerktyg.DropDownItems.AddRange(@(
    $miScript1,
    $miScript2,
    $miScript3,
    $miScript4,
    $miScript5,
    (New-Object System.Windows.Forms.ToolStripSeparator),
    $miToggleSignSamm,
    $miToggleSignGransk
))

# Config-gated: dölj signeringsmenyval om avstängt i Config
$miToggleSignSamm.Visible   = (Get-ConfigFlag -Name 'EnableSignSammanstallning' -Default $true)
$miToggleSignGransk.Visible = $false  # 2026-05-18: Worksheet/Granskning-signering avstängd i LIVE

# Config-gated: dölj avancerade skript (Kontrollprovsfil + AutoMappscript)
$showAdvScripts = (Get-ConfigFlag -Name 'ShowAdvancedScripts' -Default $false)
$miScript1.Visible = $showAdvScripts
$miScript2.Visible = $showAdvScripts
$miScript4.Visible = $showAdvScripts
$miScript5.Visible = $showAdvScripts

# ----- Instruktioner -----
$miShowInstr   = New-Object System.Windows.Forms.ToolStripMenuItem('📖 Visa instruktioner')
$miFAQ         = New-Object System.Windows.Forms.ToolStripMenuItem('❓ FAQ')
$miHelpDlg     = New-Object System.Windows.Forms.ToolStripMenuItem('🆘 Hjälp')
$miStatus      = New-Object System.Windows.Forms.ToolStripMenuItem('📌 Status (Done / Todo)')
$miHelp.DropDownItems.AddRange(@($miShowInstr,$miFAQ,$miHelpDlg,$miStatus))

$miGenvagar = New-Object System.Windows.Forms.ToolStripMenuItem('🔗 Genvägar')
$ShortcutGroups = Get-ConfigValue -Name 'ShortcutGroups' -Default $null -ConfigOverride $Config
if (-not $ShortcutGroups) {
    # Reservväg om config saknar genvägar
    $ShortcutGroups = @{
        '🗂️ IPT-mappar' = @(
            @{ Text='📂 IPT - PÅGÅENDE KÖRNINGAR';        Target='N:\QC\QC-1\IPT\2. IPT - PÅGÅENDE KÖRNINGAR' },
            @{ Text='📂 IPT - KLART FÖR SAMMANSTÄLLNING'; Target='N:\QC\QC-1\IPT\3. IPT - KLART FÖR SAMMANSTÄLLNING' },
            @{ Text='📂 IPT - KLART FÖR GRANSKNING';      Target='N:\QC\QC-1\IPT\4. IPT - KLART FÖR GRANSKNING' },
            @{ Text='📂 SPT Macro Assay';                 Target='N:\QC\QC-0\SPT\SPT macros\Assay' }
        )
        '📄 Dokument' = @(
            @{ Text='🧰 Utrustningslista';    Target=$UtrustningListPath },
            @{ Text='🧪 Kontrollprovsfil';    Target=$RawDataPath }
        )
        '🌐 Länkar' = @(
            @{ Text='⚡ IPT App';              Target='https://apps.powerapps.com/play/e/default-771c9c47-7f24-44dc-958e-34f8713a8394/a/fd340dbd-bbbf-470b-b043-d2af4cb62c83' },
            @{ Text='🌐 MES';                  Target='http://mes.cepheid.pri/camstarportal/?domain=CEPHEID.COM' },
            @{ Text='🌐 CSV Uploader';         Target='http://auw2wgxtpap01.cepaws.com/Welcome.aspx' },
            @{ Text='🌐 BMRAM';                Target='https://cepheid62468.coolbluecloud.com/' },
            @{ Text='🌐 Agile';                Target='https://agileprod.cepheid.com/Agile/default/login-cms.jsp' }
        )
    }
}

foreach ($grp in $ShortcutGroups.GetEnumerator()) {

    $grpMenu = New-Object System.Windows.Forms.ToolStripMenuItem($grp.Key)
    foreach ($entry in $grp.Value) { Add-ShortcutItem -Parent $grpMenu -Text $entry.Text -Target $entry.Target }
    [void]$miGenvagar.DropDownItems.Add($grpMenu)

}

$miOm = New-Object System.Windows.Forms.ToolStripMenuItem('ℹ️ Om det här verktyget'); [void]$miAbout.DropDownItems.Add($miOm)
$menuStrip.Items.AddRange(@($miArkiv,$miVerktyg,$miGenvagar,$miHelp,$miAbout))
$form.MainMenuStrip=$menuStrip

# ---------- Rubrik ----------
$panelHeader = New-Object System.Windows.Forms.Panel
$panelHeader.Dock='Top'; $panelHeader.Height=82
$panelHeader.BackColor=[System.Drawing.Color]::SteelBlue
$panelHeader.Padding = New-Object System.Windows.Forms.Padding(10,8,10,8)

$picLogo = New-Object System.Windows.Forms.PictureBox
$picLogo.Dock = 'Left'
$picLogo.Width = 50
$picLogo.BorderStyle = 'FixedSingle'
$picLogo.SizeMode = 'Zoom'
if (Test-Path -LiteralPath $ikonSokvag) { $picLogo.Image = [System.Drawing.Image]::FromFile($ikonSokvag) }

$panelText = New-Object System.Windows.Forms.Panel
$panelText.Dock = 'Fill'
$panelText.BackColor = $panelHeader.BackColor

$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = "IPTCompile – $ScriptVersion"
$lblTitle.ForeColor = [System.Drawing.Color]::White
$lblTitle.Font = New-Object System.Drawing.Font('Segoe UI Semibold',13)
$lblTitle.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$lblTitle.Dock = 'Top'
$lblTitle.Height = 30
$lblTitle.Padding = New-Object System.Windows.Forms.Padding(8,0,0,0)

$lblUpdate = New-Object System.Windows.Forms.Label
$lblUpdate.Text      = 'Hjälpmedel vid IPT dokumentation'
$lblUpdate.ForeColor = [System.Drawing.Color]::White
$lblUpdate.Font      = New-Object System.Drawing.Font('Segoe UI Semibold',10)
$lblUpdate.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$lblUpdate.Dock      = 'Top'
$lblUpdate.Height    = 16
$lblUpdate.Padding   = New-Object System.Windows.Forms.Padding(8,0,0,0)

$lblExtra = New-Object System.Windows.Forms.Label
$lblExtra.Text = 'Läs "Instruktioner"'
$lblExtra.ForeColor = [System.Drawing.Color]::White
$lblExtra.Font = New-Object System.Drawing.Font('Segoe UI Semibold',10)
$lblExtra.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$lblExtra.Dock = 'Top'
$lblExtra.Height = 14
$lblExtra.Padding = New-Object System.Windows.Forms.Padding(8,1,0,0)

$panelText.Controls.Add($lblExtra)
$panelText.Controls.Add($lblUpdate)
$panelText.Controls.Add($lblTitle)

$panelHeader.Controls.Add($panelText)
$panelHeader.Controls.Add($picLogo)

$panelHeader.Add_Resize({
    $innerH = $panelHeader.Height - $panelHeader.Padding.Top - $panelHeader.Padding.Bottom
    $picLogo.Height = $innerH
    $picLogo.Width  = $innerH 
})

$form.add_FormClosed({ try { if ($picLogo.Image) { $picLogo.Image.Dispose() } } catch {} })
$form.add_Shown({
    try {
        if ($script:btnMove3) { $script:btnMove3.Visible = $false }
        Ensure-MainWindowFitsWorkingArea
    } catch {}
    try { Apply-UserDefaults } catch {}
})

# ---------- Sök-rad ----------
$tlSearch = New-Object System.Windows.Forms.TableLayoutPanel
$tlSearch.Dock='Top'; $tlSearch.AutoSize=$true; $tlSearch.AutoSizeMode='GrowAndShrink'
$tlSearch.Padding = New-Object System.Windows.Forms.Padding(0,10,0,8)
$tlSearch.ColumnCount=3
[void]$tlSearch.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$tlSearch.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
[void]$tlSearch.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute,130)))

$lblLSP = New-Object System.Windows.Forms.Label
$lblLSP.Text='LSP:'; $lblLSP.Anchor='Left'; $lblLSP.AutoSize=$true
$lblLSP.Margin = New-Object System.Windows.Forms.Padding(0,6,8,0)
$txtLSP = New-Object System.Windows.Forms.TextBox
$txtLSP.Dock='Fill'
$txtLSP.Margin = New-Object System.Windows.Forms.Padding(0,2,10,2)
# G2: Placeholder/cue-banner så användaren ser förväntat format
try {
    $null = Add-Type -Name 'WinUser_CueBanner' -Namespace 'IPT' -PassThru -MemberDefinition '
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, string lParam);
    '
    $txtLSP.add_HandleCreated({
        [IPT.WinUser_CueBanner]::SendMessage($this.Handle, 0x1501, [IntPtr]::Zero, 'T.ex. 38401') | Out-Null
    })
} catch {}
$btnScan = New-Object System.Windows.Forms.Button
$btnScan.Text='Sök filer'; $btnScan.Dock='Fill'; Set-AccentButton $btnScan -Primary
$btnScan.Margin= New-Object System.Windows.Forms.Padding(0,2,0,2)

$tlSearch.Controls.Add($lblLSP,0,0)
$tlSearch.Controls.Add($txtLSP,1,0)

# ---------- Flytta nedladdade filer (Camstar -> Downloads -> N:) ----------
$grpDl = New-Object System.Windows.Forms.GroupBox
$grpDl.Text = 'Flytta nedladdade filer från "Downloads" vid granskning'
$grpDl.Dock = 'Top'
$grpDl.Padding = New-Object System.Windows.Forms.Padding(10,8,10,10)
$grpDl.AutoSize = $true
$grpDl.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink

$tlDl = New-Object System.Windows.Forms.TableLayoutPanel
$tlDl.Dock = 'Top'
$tlDl.AutoSize = $true
$tlDl.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
$tlDl.ColumnCount = 3
$tlDl.RowCount = 1
$tlDl.Margin = New-Object System.Windows.Forms.Padding(0,0,0,0)
$tlDl.Padding = New-Object System.Windows.Forms.Padding(0,0,0,0)

# Kolumner: [Text tar allt] [KLART normal] [TEST liten]
[void]$tlDl.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
[void]$tlDl.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 240)))
[void]$tlDl.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute, 90)))
[void]$tlDl.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))

$lblDl = New-Object System.Windows.Forms.Label
$lblDl.Text = 'Matchar LSP i filnamn och flyttar från Downloads till rätt granskningsmapp.'
$lblDl.Dock = 'Fill'
$lblDl.AutoSize = $false
$lblDl.AutoEllipsis = $true
$lblDl.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$lblDl.Margin = New-Object System.Windows.Forms.Padding(0,0,10,0)

# KLART först (närmast texten)
$btnMove4 = New-Object System.Windows.Forms.Button
$btnMove4.Text = 'KLART FÖR GRANSKNING'
$btnMove4.Width = 240
$btnMove4.Height = 30
$btnMove4.Anchor = [System.Windows.Forms.AnchorStyles]::Right
$btnMove4.Margin = New-Object System.Windows.Forms.Padding(0,0,6,0)
Set-AccentButton $btnMove4

# TEST längst till höger (liten + dold)
$btnMove3 = New-Object System.Windows.Forms.Button
$btnMove3.Text = 'TEST'
$btnMove3.Width = 90
$btnMove3.Height = 30
$btnMove3.Anchor = [System.Windows.Forms.AnchorStyles]::Right
$btnMove3.Margin = New-Object System.Windows.Forms.Padding(0,0,0,0)
$btnMove3.Visible = $false
Set-AccentButton $btnMove3
$script:btnMove3 = $btnMove3

$tlDl.Controls.Add($lblDl, 0, 0)
$tlDl.Controls.Add($btnMove4, 1, 0)
$tlDl.Controls.Add($btnMove3, 2, 0)

$grpDl.Controls.Add($tlDl)
$tlSearch.Controls.Add($btnScan,2,0)

$pLog = New-Object System.Windows.Forms.Panel
$pLog.Dock='Top'; $pLog.Height=100; $pLog.Padding=New-Object System.Windows.Forms.Padding(0,0,0,8)

$outputBox = New-Object System.Windows.Forms.TextBox
$outputBox.Multiline=$true; $outputBox.ScrollBars='Vertical'; $outputBox.ReadOnly=$true
$outputBox.BackColor='White'; $outputBox.Dock='Fill'
$outputBox.Font = New-Object System.Drawing.Font('Segoe UI',9)
$pLog.Controls.Add($outputBox)
try { Set-LogOutputControl -Control $outputBox } catch {}
$outputBox.ForeColor = [System.Drawing.Color]::Silver
$outputBox.Text = ""
$script:_logPlaceholderActive = $true

$grpPick = New-Object System.Windows.Forms.GroupBox
$grpPick.Text='Välj filer för rapport'
$grpPick.Dock='Top'
$grpPick.Padding = New-Object System.Windows.Forms.Padding(10,12,10,14)
$grpPick.AutoSize=$false
$grpPick.Height = 36 + (78*4) + $grpPick.Padding.Top + $grpPick.Padding.Bottom + 15

$tlPick = New-Object System.Windows.Forms.TableLayoutPanel
$tlPick.Dock='Fill'; $tlPick.ColumnCount=3; $tlPick.RowCount=5
$tlPick.GrowStyle=[System.Windows.Forms.TableLayoutPanelGrowStyle]::FixedSize
[void]$tlPick.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$tlPick.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
[void]$tlPick.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Absolute,100)))
# Första raden är bara mode-raden. Den ska inte vara lika hög som filraderna,
# annars hamnar labeln visuellt för långt ned jämfört med comboboxen.
$script:PickSealModeRowHeight = 32
$script:PickFileRowHeight     = 78
[void]$tlPick.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,$script:PickSealModeRowHeight)))
for($i=1;$i -lt 5;$i++){ [void]$tlPick.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,$script:PickFileRowHeight))) }

$lblSealMode = New-Object System.Windows.Forms.Label
$lblSealMode.Text = 'Seal Test mode:'
$lblSealMode.AutoSize = $false
$lblSealMode.Width = 115
$lblSealMode.Dock = 'Fill'
$lblSealMode.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$lblSealMode.Margin = New-Object System.Windows.Forms.Padding(0,0,6,0)

$cmbSealMode = New-Object System.Windows.Forms.ComboBox
$cmbSealMode.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$cmbSealMode.Dock = 'Fill'
$cmbSealMode.Margin = New-Object System.Windows.Forms.Padding(0,3,8,3)
[void]$cmbSealMode.Items.Add('Split: Seal Test NEG + POS')
[void]$cmbSealMode.Items.Add('Merge: en Seal Test-fil (POS-labb)')
$script:SealTestMode = 'Split'
try {
    $cfgSealMode = (Get-ConfigValue -Name 'SealTestInputMode' -Default 'Split' -ConfigOverride $Config)
    if (($cfgSealMode + '') -match '(?i)^merged?$') { $cmbSealMode.SelectedIndex = 1 }
    else { $cmbSealMode.SelectedIndex = 0 }
} catch { $cmbSealMode.SelectedIndex = 0 }

$lblCsv=$null;$clbCsv=$null;$btnCsvBrowse=$null
New-ListRow -labelText 'CSV-fil:' -lbl ([ref]$lblCsv) -clb ([ref]$clbCsv) -btn ([ref]$btnCsvBrowse)
$lblNeg=$null;$clbNeg=$null;$btnNegBrowse=$null
New-ListRow -labelText 'Seal Test Neg:' -lbl ([ref]$lblNeg) -clb ([ref]$clbNeg) -btn ([ref]$btnNegBrowse)
$lblPos=$null;$clbPos=$null;$btnPosBrowse=$null
New-ListRow -labelText 'Seal Test Pos:' -lbl ([ref]$lblPos) -clb ([ref]$clbPos) -btn ([ref]$btnPosBrowse)

try {
    if ($tlPick.RowCount -lt 5) {
        $tlPick.RowCount = 5
        for ($i=$tlPick.RowStyles.Count; $i -lt 5; $i++) {
            $null = $tlPick.RowStyles.Add( (New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute, $script:PickFileRowHeight)) )
        }
        $grpPick.Height = $script:PickSealModeRowHeight + ($script:PickFileRowHeight*4) + $grpPick.Padding.Top + $grpPick.Padding.Bottom + 15
    }
} catch {}

$lblLsp = $null; $clbLsp = $null; $btnLspBrowse = $null
New-ListRow -labelText 'Worksheet:' -lbl ([ref]$lblLsp) -clb ([ref]$clbLsp) -btn ([ref]$btnLspBrowse)

$tlPick.Controls.Add($lblLsp,  0, 4)
$tlPick.Controls.Add($clbLsp,  1, 4)
$tlPick.Controls.Add($btnLspBrowse, 2, 4)

$clbLsp.add_ItemCheck({
    param($s,$e)
    if ($e.NewValue -eq [System.Windows.Forms.CheckState]::Checked) {
        for ($i=0; $i -lt $s.Items.Count; $i++) {
            if ($i -ne $e.Index) { $s.SetItemChecked($i, $false) }
        }
    }
})

$btnLspBrowse.Add_Click({
    try {
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = "Excel|*.xlsx;*.xlsm|Alla filer|*.*"
        $dlg.Title  = "Välj LSP Worksheet"
        if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $f = Get-Item -LiteralPath $dlg.FileName
            Add-CLBItems -clb $clbLsp -files @($f) -AutoCheckFirst
            if (Get-Command Update-StatusBar -ErrorAction SilentlyContinue) { Update-StatusBar }
        }
    } catch {
        Gui-Log ("⚠️ LSP-browse fel: " + $_.Exception.Message) 'Warn'
    }
})

# Lägg in i tabellen
$tlPick.Controls.Add($lblSealMode,0,0); $tlPick.Controls.Add($cmbSealMode,1,0); $tlPick.SetColumnSpan($cmbSealMode,2)
$tlPick.Controls.Add($lblCsv,0,1); $tlPick.Controls.Add($clbCsv,1,1); $tlPick.Controls.Add($btnCsvBrowse,2,1)
$tlPick.Controls.Add($lblNeg,0,2); $tlPick.Controls.Add($clbNeg,1,2); $tlPick.Controls.Add($btnNegBrowse,2,2)
$tlPick.Controls.Add($lblPos,0,3); $tlPick.Controls.Add($clbPos,1,3); $tlPick.Controls.Add($btnPosBrowse,2,3)
$grpPick.Controls.Add($tlPick)

# ── Watermark/placeholder för tomma listor ──

<# Watermarks för tomma listor
Set-ClbWatermark -clb $clbCsv -Text 'Använd Bläddra för att välja CSV-fil...'
Set-ClbWatermark -clb $clbNeg -Text 'Använd Bläddra för Seal Test NEG...'
Set-ClbWatermark -clb $clbPos -Text 'Använd Bläddra för Seal Test POS...'
Set-ClbWatermark -clb $clbLsp -Text 'Använd Bläddra för Worksheet...
#>

# ---------- Signering: Sammanställning ----------
$grpSignSamm = New-Object System.Windows.Forms.GroupBox
$grpSignSamm.Text = 'Signering — Seal Test NEG+POS'
$grpSignSamm.Dock = 'Top'
$grpSignSamm.Padding = New-Object System.Windows.Forms.Padding(10,10,10,12)
$grpSignSamm.AutoSize = $false
$grpSignSamm.Height = 154

$tlSignSamm = New-Object System.Windows.Forms.TableLayoutPanel
$tlSignSamm.Dock = 'Fill'; $tlSignSamm.ColumnCount = 2; $tlSignSamm.RowCount = 4
[void]$tlSignSamm.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$tlSignSamm.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
for ($i = 0; $i -lt 3; $i++) {
    [void]$tlSignSamm.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,28)))
}
[void]$tlSignSamm.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,34)))

$lblSammName = New-Object System.Windows.Forms.Label
$lblSammName.Text = 'Full Name:'; $lblSammName.Anchor = 'Left'; $lblSammName.AutoSize = $true
$txtSammName = New-Object System.Windows.Forms.TextBox
$txtSammName.Dock = 'Fill'; $txtSammName.Margin = New-Object System.Windows.Forms.Padding(6,2,0,2)

$lblSammDate = New-Object System.Windows.Forms.Label
$lblSammDate.Text = 'Date:'; $lblSammDate.Anchor = 'Left'; $lblSammDate.AutoSize = $true
$txtSammDate = New-Object System.Windows.Forms.TextBox
$txtSammDate.Dock = 'Fill'; $txtSammDate.Margin = New-Object System.Windows.Forms.Padding(6,2,0,2)

$lblSealTestSign = New-Object System.Windows.Forms.Label
$lblSealTestSign.Text = 'SIGN:'; $lblSealTestSign.Anchor = 'Left'; $lblSealTestSign.AutoSize = $true
$txtSealTestSign = New-Object System.Windows.Forms.TextBox
$txtSealTestSign.Dock = 'Fill'; $txtSealTestSign.Margin = New-Object System.Windows.Forms.Padding(6,2,0,2)

$chkSealTest = New-Object System.Windows.Forms.CheckBox
$chkSealTest.Text = ' Seal Test (NEG+POS)'; $chkSealTest.AutoSize = $true; $chkSealTest.Margin = New-Object System.Windows.Forms.Padding(0,2,12,2)
$chkWsSamm = New-Object System.Windows.Forms.CheckBox
$chkWsSamm.Text = ' Worksheet (Sammanst.)'; $chkWsSamm.AutoSize = $true; $chkWsSamm.Margin = New-Object System.Windows.Forms.Padding(0,2,12,2); $chkWsSamm.Visible = $false; $chkWsSamm.Enabled = $false; $chkWsSamm.Checked = $false
$chkSignOverwrite = New-Object System.Windows.Forms.CheckBox
$chkSignOverwrite.Text = ' Aktivera Signering'; $chkSignOverwrite.AutoSize = $true; $chkSignOverwrite.Margin = New-Object System.Windows.Forms.Padding(0,2,0,2)
$chkSignOverwrite.ForeColor = [System.Drawing.Color]::FromArgb(180,80,80)
$chkSignOverwrite.Tag = 'Skriv signatur i Seal Test POS/NEG. Worksheet-signering är avstängd i denna version.'

$flpSammChk = New-Object System.Windows.Forms.FlowLayoutPanel
$flpSammChk.Dock = 'Fill'; $flpSammChk.FlowDirection = 'LeftToRight'; $flpSammChk.WrapContents = $false
$flpSammChk.AutoSize = $true; $flpSammChk.Margin = New-Object System.Windows.Forms.Padding(0)
$flpSammChk.Controls.Add($chkSealTest)
$flpSammChk.Controls.Add($chkWsSamm)
$flpSammChk.Controls.Add($chkSignOverwrite)

$tlSignSamm.Controls.Add($lblSammName,0,0);    $tlSignSamm.Controls.Add($txtSammName,1,0)
$tlSignSamm.Controls.Add($lblSammDate,0,1);    $tlSignSamm.Controls.Add($txtSammDate,1,1)
$tlSignSamm.Controls.Add($lblSealTestSign,0,2);$tlSignSamm.Controls.Add($txtSealTestSign,1,2)
$tlSignSamm.Controls.Add($flpSammChk,0,3);     $tlSignSamm.SetColumnSpan($flpSammChk,2)
$grpSignSamm.Controls.Add($tlSignSamm)
$grpSignSamm.Visible = $false

# ---------- Signering: Granskning ----------
$grpSignGransk = New-Object System.Windows.Forms.GroupBox
$grpSignGransk.Text = 'Signering — Granskning'
$grpSignGransk.Dock = 'Top'
$grpSignGransk.Padding = New-Object System.Windows.Forms.Padding(10,8,10,10)
$grpSignGransk.AutoSize = $false
$grpSignGransk.Height = 126

$tlSignGransk = New-Object System.Windows.Forms.TableLayoutPanel
$tlSignGransk.Dock = 'Fill'; $tlSignGransk.ColumnCount = 2; $tlSignGransk.RowCount = 3
[void]$tlSignGransk.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize)))
[void]$tlSignGransk.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
for ($i = 0; $i -lt 3; $i++) {
    [void]$tlSignGransk.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,26)))
}

$lblGranskName = New-Object System.Windows.Forms.Label
$lblGranskName.Text = 'Full Name:'; $lblGranskName.Anchor = 'Left'; $lblGranskName.AutoSize = $true
$txtGranskName = New-Object System.Windows.Forms.TextBox
$txtGranskName.Dock = 'Fill'; $txtGranskName.Margin = New-Object System.Windows.Forms.Padding(6,2,0,2)

$lblGranskDate = New-Object System.Windows.Forms.Label
$lblGranskDate.Text = 'Date:'; $lblGranskDate.Anchor = 'Left'; $lblGranskDate.AutoSize = $true
$txtGranskDate = New-Object System.Windows.Forms.TextBox
$txtGranskDate.Dock = 'Fill'; $txtGranskDate.Margin = New-Object System.Windows.Forms.Padding(6,2,0,2)

$chkWsGransk = New-Object System.Windows.Forms.CheckBox
$chkWsGransk.Text = ' Worksheet (Granskning)'; $chkWsGransk.AutoSize = $true; $chkWsGransk.Margin = New-Object System.Windows.Forms.Padding(0,2,12,2); $chkWsGransk.Visible = $false; $chkWsGransk.Enabled = $false; $chkWsGransk.Checked = $false
$chkGranskOverwrite = New-Object System.Windows.Forms.CheckBox
$chkGranskOverwrite.Text = ' Aktivera överskrivning'; $chkGranskOverwrite.AutoSize = $true; $chkGranskOverwrite.Margin = New-Object System.Windows.Forms.Padding(0,2,0,2)
$chkGranskOverwrite.Tag = 'Worksheet Granskning-signering är avstängd i denna version.'
$chkGranskOverwrite.ForeColor = [System.Drawing.Color]::FromArgb(180,80,80)

$flpGranskChk = New-Object System.Windows.Forms.FlowLayoutPanel
$flpGranskChk.Dock = 'Fill'; $flpGranskChk.FlowDirection = 'LeftToRight'; $flpGranskChk.WrapContents = $false
$flpGranskChk.AutoSize = $true; $flpGranskChk.Margin = New-Object System.Windows.Forms.Padding(0)
$flpGranskChk.Controls.Add($chkWsGransk)
$flpGranskChk.Controls.Add($chkGranskOverwrite)

$tlSignGransk.Controls.Add($lblGranskName,0,0); $tlSignGransk.Controls.Add($txtGranskName,1,0)
$tlSignGransk.Controls.Add($lblGranskDate,0,1); $tlSignGransk.Controls.Add($txtGranskDate,1,1)
$tlSignGransk.Controls.Add($flpGranskChk,0,2);  $tlSignGransk.SetColumnSpan($flpGranskChk,2)
$grpSignGransk.Controls.Add($tlSignGransk)
$grpSignGransk.Visible = $false

$baseHeight = $form.Height
$script:BaseFormHeight = $form.Height
$script:BaseLogHeight  = $pLog.Height

function Update-MainContentScrollSize {
    # AutoScroll tillsammans med Dock=Top är inte alltid tillräckligt stabilt i WinForms.
    # Därför sätter vi AutoScrollMinSize explicit efter att signeringspanelen visas/döljs.
    try {
        if (-not $content) { return }
        $h = 0
        foreach ($ctrl in @($panelHeader, $tlSearch, $pLog, $grpDl, $grpPick, $grpSignSamm, $grpSignGransk)) {
            try {
                if ($ctrl -and $ctrl.Visible) {
                    $h += [int]$ctrl.Height + [int]$ctrl.Margin.Top + [int]$ctrl.Margin.Bottom
                }
            } catch {}
        }
        $content.AutoScroll = $true
        $content.AutoScrollMinSize = New-Object System.Drawing.Size(0, ($h + 24))
    } catch {}
}

function Update-SignatureLayout {
    # Signeringspanelen får aldrig expandera formuläret eller trycka bort
    # Skapa rapport-knappen. Den fasta bottenpanelen ligger utanför scroll-ytan;
    # här justerar vi bara scroll/logg och ser till att fönstret håller sig inom skärmen.
    try {
        $signVisible = $false
        try { $signVisible = (($grpSignSamm -and $grpSignSamm.Visible) -or ($grpSignGransk -and $grpSignGransk.Visible)) } catch {}

        try { $form.SuspendLayout() } catch {}
        try { if ($content) { $content.SuspendLayout() } } catch {}

        try { if ($content) { $content.AutoScroll = $true } } catch {}
        if ($signVisible) {
            # Lägre logg när signering är aktiv så att signeringspanelen får mer synlig yta.
            try { $pLog.Height = 48 } catch {}
        } else {
            try { $pLog.Height = $script:BaseLogHeight } catch {}
        }

    # När signering visas: gör fönstret lite högre, men aldrig högre än skärmen.
    try {
    $wa = [System.Windows.Forms.Screen]::FromControl($form).WorkingArea
    $maxH = [Math]::Max(600, $wa.Height - 2)

    if ($signVisible) {
        $wantedH = [Math]::Min(($script:BaseFormHeight + $script:IptSignatureExtraHeight), $maxH)
        if ($wantedH -gt $form.Height) {
            $form.Height = $wantedH
        }

    } else {
        if ($script:BaseFormHeight -gt 0) {
            $form.Height = [Math]::Min($script:BaseFormHeight, $maxH)
        }
    }

    } catch {}

        try { Ensure-MainWindowFitsWorkingArea } catch {}
        try { Update-MainContentScrollSize } catch {}

        try { if ($content) { $content.ResumeLayout($true) } } catch {}
        try { $form.ResumeLayout($true) } catch {}

        # När användaren aktiverar signering ska panelen också hamna i synfältet.
        # Annars finns den tekniskt i scroll-ytan, men användaren upplever att den saknas.
        if ($signVisible -and $content) {
            $targetSignPanel = $null
            try { if ($grpSignSamm.Visible) { $targetSignPanel = $grpSignSamm } elseif ($grpSignGransk.Visible) { $targetSignPanel = $grpSignGransk } } catch {}
            if ($targetSignPanel) {
                try {
                    $null = $content.BeginInvoke([Action]{
                        try {
                            Update-MainContentScrollSize
                            $content.ScrollControlIntoView($targetSignPanel)
                        } catch {}
                    })
                } catch {
                    try { $content.ScrollControlIntoView($targetSignPanel) } catch {}
                }
            }
        }
    } catch {
        try { Ensure-MainWindowFitsWorkingArea } catch {}
    }
}

# ---------- Primärknapp ----------

$btnBuild = New-Object System.Windows.Forms.Button
$btnBuild.Text='Skapa rapport (F5)'; $btnBuild.Dock='Fill'; $btnBuild.Height=40
$btnBuild.Margin = New-Object System.Windows.Forms.Padding(0,4,0,4)
$btnBuild.Enabled=$false; Set-AccentButton $btnBuild -Primary

# ---------- Redo/Nästan redo-banner ----------
$script:pReadinessBanner = New-Object System.Windows.Forms.Panel
$script:pReadinessBanner.Dock = 'Fill'
$script:pReadinessBanner.Height = 34
$script:pReadinessBanner.Padding = New-Object System.Windows.Forms.Padding(10,6,10,6)
$script:pReadinessBanner.Margin = New-Object System.Windows.Forms.Padding(0,0,0,0)
$script:pReadinessBanner.BackColor = [System.Drawing.Color]::FromArgb(255,248,225)

$script:lblReadiness = New-Object System.Windows.Forms.Label
$script:lblReadiness.Dock = 'Fill'
$script:lblReadiness.AutoEllipsis = $true
$script:lblReadiness.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$script:lblReadiness.Font = New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold)
$script:lblReadiness.Text = '🟡 Nästan redo — välj Seal Test-filer'
$script:pReadinessBanner.Controls.Add($script:lblReadiness)

# ---------- Statusrad ----------
$status = New-Object System.Windows.Forms.StatusStrip
$status.SizingGrip=$false; $status.Dock='Bottom'; $status.Font=New-Object System.Drawing.Font('Segoe UI',9)
$status.ShowItemToolTips = $true
$slCount = New-Object System.Windows.Forms.ToolStripStatusLabel; $slCount.Text='0 filer valda'; $slCount.Spring=$false
$slWork  = New-Object System.Windows.Forms.ToolStripStatusLabel
$slWork.Text   = ''
$slWork.Spring = $true

$pbWork = New-Object System.Windows.Forms.ToolStripProgressBar
$pbWork.Visible = $false
$pbWork.Style   = 'Marquee'
$pbWork.MarqueeAnimationSpeed = 30
$pbWork.AutoSize = $false
$pbWork.Width    = 140

$slSpacer= New-Object System.Windows.Forms.ToolStripStatusLabel; $slSpacer.Spring=$true

# --- Rapportantal ---
$script:slSession = New-Object System.Windows.Forms.ToolStripStatusLabel
$script:slSession.Text = ''
$script:slSession.Visible = $false
$script:slSession.ForeColor = [System.Drawing.Color]::FromArgb(0, 100, 0)
$script:slSession.Font = New-Object System.Drawing.Font('Segoe UI', 8.5, [System.Drawing.FontStyle]::Bold)
$script:slSession.BorderSides = 'Left'
$script:slSession.BorderStyle = 'Raised'
$script:slSession.Padding = New-Object System.Windows.Forms.Padding(6, 0, 4, 0)

# --- Snabblänkar efter skapad rapport ---
$script:slOpenReport = New-Object System.Windows.Forms.ToolStripStatusLabel
$script:slOpenReport.Text = 'Öppna rapport'
$script:slOpenReport.IsLink = $true
$script:slOpenReport.Visible = $false
$script:slOpenReport.ToolTipText = 'Öppna senaste skapade rapporten'
$script:slOpenReport.add_Click({
    try {
        if ($global:LastReportPath -and (Test-Path -LiteralPath $global:LastReportPath)) { Start-Process -FilePath $global:LastReportPath }
    } catch { Gui-Log "ℹ️ Kunde inte öppna rapporten: $($_.Exception.Message)" 'Info' 'USER' }
})

$script:slOpenFolder = New-Object System.Windows.Forms.ToolStripStatusLabel
$script:slOpenFolder.Text = 'Öppna mapp'
$script:slOpenFolder.IsLink = $true
$script:slOpenFolder.Visible = $false
$script:slOpenFolder.ToolTipText = 'Öppna mappen där senaste rapporten sparades'
$script:slOpenFolder.add_Click({
    try {
        if ($global:LastReportPath -and (Test-Path -LiteralPath $global:LastReportPath)) {
            Start-Process -FilePath (Split-Path -Parent $global:LastReportPath)
        }
    } catch { Gui-Log "ℹ️ Kunde inte öppna rapportmappen: $($_.Exception.Message)" 'Info' 'USER' }
})

# --- Klickbar SharePoint-länk ---
$slBatchLink = New-Object System.Windows.Forms.ToolStripStatusLabel
$slBatchLink.IsLink   = $true
$slBatchLink.Text     = 'SharePoint: —'
$slBatchLink.Enabled  = $false
$slBatchLink.Tag      = $null
$slBatchLink.ToolTipText = 'Direktlänk aktiveras när entydigt Order# hittas i Seal Test B10.'
$slBatchLink.add_Click({
    if ($this.Enabled -and $this.Tag) {
        try { Start-Process -FilePath ([string]$this.Tag) } catch {
            [System.Windows.Forms.MessageBox]::Show("Kunde inte öppna:`n$($this.Tag)`n$($_.Exception.Message)","Länk") | Out-Null
        }
    }
})

# --- SharePoint On-Demand Connect-knapp ---
$script:btnSpConnect = New-Object System.Windows.Forms.ToolStripButton
$script:btnSpConnect.DisplayStyle = 'Text'
$script:btnSpConnect.Font = New-Object System.Drawing.Font('Segoe UI',9,[System.Drawing.FontStyle]::Bold)

if ($global:SpConnected) {
    $script:btnSpConnect.Text = '✅ SP'
    $script:btnSpConnect.ToolTipText = 'SharePoint är anslutet.'
    $script:btnSpConnect.Enabled = $false
} elseif ($global:SpEnabled) {
    $script:btnSpConnect.Text = '🔌 Anslut SP'
    $script:btnSpConnect.ToolTipText = 'Klicka för att ansluta till SharePoint (tar ~10–15 sek).'
    $script:btnSpConnect.Enabled = $true
} else {
    $script:btnSpConnect.Text = '⛔ SP av'
    $script:btnSpConnect.ToolTipText = 'SharePoint är avstängt i konfigurationen.'
    $script:btnSpConnect.Enabled = $false
}

$script:btnSpConnect.add_Click({
    if (-not $global:SpEnabled) { return }
    if ($global:SpConnected) { return }
    if ($global:SpConnecting) { return }

    # Uppdatera knappen
    $this.Text        = '⏳ Ansluter…'
    $this.Enabled     = $false
    $this.ToolTipText = 'Ansluter till SharePoint – vänta…'

    Show-Splash 'Förbereder SharePoint…'

    # Steg 1: Starta SPClient-runspace synkront (snabbt, ~1-2 sek)
    #         PnP import sker här; om det misslyckas avbryt direkt.
    $startOk = Start-SPClient -ProgressCallback { param($m) Update-Splash $m }
    if (-not $startOk) {
        Close-Splash
        $script:btnSpConnect.Text        = '❌ SP – retry?'
        $script:btnSpConnect.ToolTipText = "Misslyckades: $($global:SpError)`nKlicka för att försöka igen."
        $script:btnSpConnect.Enabled     = $true
        Gui-Log ("⚠️ SharePoint-förberedelse misslyckades: " + $global:SpError) 'Warn'
        return
    }

    # Steg 2: Starta Connect-PnPOnline asynkront (kör i SPClient-runspacen)
    Update-Splash 'Loggar in…'
    $asyncOk = Connect-SPClientAsync
    if (-not $asyncOk) {
        Close-Splash
        $script:btnSpConnect.Text        = '❌ SP – retry?'
        $script:btnSpConnect.ToolTipText = "Misslyckades: $($global:SpError)`nKlicka för att försöka igen."
        $script:btnSpConnect.Enabled     = $true
        Gui-Log ("⚠️ Kunde inte starta SP-anslutning: " + $global:SpError) 'Warn'
        return
    }

    # Steg 3: Timer som pollar var 200 ms tills async är klart
    $script:spPollTimer = New-Object System.Windows.Forms.Timer
    $script:spPollTimer.Interval = 200
    $script:spPollTimer.add_Tick({
        $result = Poll-SPClientAsync
        if ($null -eq $result) { return }   # Fortfarande igång

        # Klart — stoppa timer och splash
        $script:spPollTimer.Stop()
        $script:spPollTimer.Dispose()
        $script:spPollTimer = $null
        Close-Splash

        if ($result.Ok) {
            $script:btnSpConnect.Text        = '✅ SP'
            $script:btnSpConnect.ToolTipText = 'SharePoint anslutet.'
            $script:btnSpConnect.Enabled     = $false
            Gui-Log '✅ SharePoint anslutet.' 'Info'
        } else {
            $script:btnSpConnect.Text        = '❌ SP – retry?'
            $script:btnSpConnect.ToolTipText = "Misslyckades: $($global:SpError)`nKlicka för att försöka igen."
            $script:btnSpConnect.Enabled     = $true
            Gui-Log ("⚠️ SharePoint-anslutning misslyckades: " + $global:SpError) 'Warn'
        }
    })
    $script:spPollTimer.Start()
})

$status.Items.AddRange(@($slCount,$slWork,$pbWork,$script:slOpenReport,$script:slOpenFolder,$script:slSession,$script:btnSpConnect,$slBatchLink))
$tsc = New-Object System.Windows.Forms.ToolStripContainer
$tsc.Dock = 'Fill'
$tsc.LeftToolStripPanelVisible  = $false
$tsc.RightToolStripPanelVisible = $false

$form.SuspendLayout()
$form.Controls.Clear()
$form.Controls.Add($tsc)

# Meny högst upp
$tsc.TopToolStripPanel.Controls.Add($menuStrip)
$form.MainMenuStrip = $menuStrip

# Status längst ner
$tsc.BottomToolStripPanel.Controls.Add($status)

# Content i mitten + fast bottenpanel.
# Viktigt: Skapa rapport-knappen och readiness-bannern ligger inte i scrollflödet.
# Då syns de alltid även när signeringspanelen visas på lägre skärmar.
$rootLayout = New-Object System.Windows.Forms.TableLayoutPanel
$rootLayout.Dock = 'Fill'
$rootLayout.ColumnCount = 1
$rootLayout.RowCount = 2
$rootLayout.Margin = New-Object System.Windows.Forms.Padding(0)
$rootLayout.Padding = New-Object System.Windows.Forms.Padding(0)
[void]$rootLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent,100)))
[void]$rootLayout.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,78)))
[void]$rootLayout.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
$tsc.ContentPanel.Controls.Add($rootLayout)

$content = New-Object System.Windows.Forms.Panel
$content.Dock='Fill'
$content.BackColor = $form.BackColor
$content.AutoScroll = $true
$content.Margin = New-Object System.Windows.Forms.Padding(0)

$footerPanel = New-Object System.Windows.Forms.Panel
$footerPanel.Dock = 'Fill'
$footerPanel.BackColor = $form.BackColor
$footerPanel.Margin = New-Object System.Windows.Forms.Padding(0)
$footerPanel.Padding = New-Object System.Windows.Forms.Padding(0,2,0,2)

$tlFooter = New-Object System.Windows.Forms.TableLayoutPanel
$tlFooter.Dock = 'Fill'
$tlFooter.ColumnCount = 1
$tlFooter.RowCount = 2
$tlFooter.Margin = New-Object System.Windows.Forms.Padding(0)
$tlFooter.Padding = New-Object System.Windows.Forms.Padding(0)
[void]$tlFooter.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent,100)))
[void]$tlFooter.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Absolute,34)))
[void]$tlFooter.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent,100)))
$tlFooter.Controls.Add($script:pReadinessBanner,0,0)
$tlFooter.Controls.Add($btnBuild,0,1)
$footerPanel.Controls.Add($tlFooter)

$rootLayout.Controls.Add($content,0,0)
$rootLayout.Controls.Add($footerPanel,0,1)

# Dock=Top: nedersta först
$content.SuspendLayout()
$content.Controls.Add($grpSignGransk)
$content.Controls.Add($grpSignSamm)
$content.Controls.Add($grpPick)
$content.Controls.Add($grpDl)
$content.Controls.Add($pLog)
$content.Controls.Add($tlSearch)
$content.Controls.Add($panelHeader)
$content.ResumeLayout()
$form.ResumeLayout()
$form.PerformLayout()
try { Ensure-MainWindowFitsWorkingArea } catch {}
try { Update-MainContentScrollSize } catch {}
try { Update-SignatureLayout } catch {}
$form.AcceptButton = $btnScan

#endregion GUI-bygge

#region Hjälpfunktioner (UI-logik, filval, validering)

$onExclusive = {
    $clb = $this
    if ($_.NewValue -eq [System.Windows.Forms.CheckState]::Checked) {
        for ($i=0; $i -lt $clb.Items.Count; $i++) {
            if ($i -ne $_.Index -and $clb.GetItemChecked($i)) { $clb.SetItemChecked($i, $false) }
        }
    }
    $clb.BeginInvoke([Action]{ Update-BuildEnabled }) | Out-Null
}

# CSV: tillåt max 2 valda (primär + resample)
$onCsvMax2 = {
    $clb = $this
    if ($_.NewValue -eq [System.Windows.Forms.CheckState]::Checked) {
        $checkedCount = 0
        for ($i=0; $i -lt $clb.Items.Count; $i++) {
            if ($i -ne $_.Index -and $clb.GetItemChecked($i)) { $checkedCount++ }
        }
        if ($checkedCount -ge 2) {
            # Redan 2 valda → avmarkera äldsta (första hittade)
            for ($i=0; $i -lt $clb.Items.Count; $i++) {
                if ($i -ne $_.Index -and $clb.GetItemChecked($i)) { $clb.SetItemChecked($i, $false); break }
            }
        }
    }
    $clb.BeginInvoke([Action]{ Update-BuildEnabled }) | Out-Null
}
$clbCsv.add_ItemCheck($onCsvMax2)
$clbNeg.add_ItemCheck($onExclusive)
$clbPos.add_ItemCheck($onExclusive)
$cmbSealMode.add_SelectedIndexChanged({
    try {
        $script:SealTestMode = if ($cmbSealMode.SelectedIndex -eq 1) { 'Merged' } else { 'Split' }
        Update-SealTestModeUI
        Update-BuildEnabled
        Update-BatchLink
    } catch { try { Gui-Log ("⚠️ Kunde inte byta Seal Test mode: " + $_.Exception.Message) 'Warn' } catch {} }
})
try { Update-SealTestModeUI } catch {}
try { Update-ReadinessBanner } catch {}
try { Update-ReportCountIndicator } catch {}

$script:LastScanResult = $null
$script:RobalDateShort = $null   # Auto-populated from SP 'ROBAL - Actual start date/time' during build

# Skydd mot återinträde (DoEvents kan annars ge nästlade klick)
$script:ScanInProgress  = $false
$script:BuildInProgress = $false

#endregion Hjälpfunktioner

#region Händelsehanterare (meny, knappar, tema, scan, build)
$miScan.add_Click({ $btnScan.PerformClick() })
$miBuild.add_Click({ if ($btnBuild.Enabled) { $btnBuild.PerformClick() } })
$miExit.add_Click({ $form.Close() })
$miNew.add_Click({ Clear-GUI })

$miOpenRecent.add_Click({
    if ($global:LastReportPath -and (Test-Path -LiteralPath $global:LastReportPath)) {
        try { Start-Process -FilePath $global:LastReportPath } catch {
            [System.Windows.Forms.MessageBox]::Show("Kunde inte öppna rapporten:\n$($_.Exception.Message)","Öppna senaste rapport") | Out-Null
        }
    } else {
        [System.Windows.Forms.MessageBox]::Show("Ingen rapport har genererats i denna session.","Öppna senaste rapport") | Out-Null
    }
})

# Skript1..5 – gemensam startfunktion
$miScript1.add_Click({ Invoke-ExternalScript -Path $Script1Path -Label 'Skript 1' })
$miScript2.add_Click({ Invoke-ExternalScript -Path $Script2Path -Label 'Skript 2' })
$miScript3.add_Click({ Invoke-ExternalScript -Path $Script3Path -Label 'Skript 3' })
$miScript4.add_Click({ Invoke-ExternalScript -Path $Script4Path -Label 'Skript 4' })
$miScript5.add_Click({ Invoke-ExternalScript -Path $Script5Path -Label 'Skript 5' })

$miToggleSignSamm.add_Click({
    $lsp = $txtLSP.Text.Trim()
    if (-not $lsp) {
        Gui-Log "⚠️ Ange och sök ett LSP först innan du aktiverar signering." 'Warn'
        return
    }
    $grpSignSamm.Visible = -not $grpSignSamm.Visible
    if ($grpSignSamm.Visible) {
        $miToggleSignSamm.Text = $(if (Test-SealTestMergedMode) { '❌ Dölj signering (Seal Test-fil)' } else { '❌ Dölj signering (Seal Test NEG+POS)' })
        # Dölj Granskning automatiskt
        if ($grpSignGransk.Visible) {
            $grpSignGransk.Visible = $false
            $chkWsGransk.Checked = $false; $chkGranskOverwrite.Checked = $false
            $miToggleSignGransk.Text = '✅ Aktivera signering (Granskning)'
        }
        # Auto-populate Date från ROBAL om tillgänglig och fältet är tomt
        if (-not $txtSammDate.Text.Trim() -and $script:RobalDateShort) {
            $txtSammDate.Text = $script:RobalDateShort
        }
    } else {
        # Nollställ allt för att förhindra oavsiktlig signering vid nästa build
        $chkSealTest.Checked = $false; $chkWsSamm.Checked = $false; $chkSignOverwrite.Checked = $false
        $miToggleSignSamm.Text = $(if (Test-SealTestMergedMode) { '✅ Aktivera signering (Seal Test-fil)' } else { '✅ Aktivera signering (Seal Test NEG+POS)' })
    }
    Update-SignatureLayout
})

$miToggleSignGransk.add_Click({
    Gui-Log "ℹ️ Worksheet/Granskning-signering är avstängd i denna version. Endast Seal Test POS/NEG signeras." 'Info'
    return
    $lsp = $txtLSP.Text.Trim()
    if (-not $lsp) {
        Gui-Log "⚠️ Ange och sök ett LSP först innan du aktiverar signering." 'Warn'
        return
    }
    $grpSignGransk.Visible = -not $grpSignGransk.Visible
    if ($grpSignGransk.Visible) {
        $miToggleSignGransk.Text = '❌ Dölj signering (Granskning)'
        # Dölj Sammanställning automatiskt
        if ($grpSignSamm.Visible) {
            $grpSignSamm.Visible = $false
            $chkSealTest.Checked = $false; $chkWsSamm.Checked = $false; $chkSignOverwrite.Checked = $false
            $miToggleSignSamm.Text = $(if (Test-SealTestMergedMode) { '✅ Aktivera signering (Seal Test-fil)' } else { '✅ Aktivera signering (Seal Test NEG+POS)' })
        }
    } else {
        $chkWsGransk.Checked = $false; $chkGranskOverwrite.Checked = $false
        $miToggleSignGransk.Text = '✅ Aktivera signering (Granskning)'
    }
    Update-SignatureLayout
})

# Enter-tangent i signeringsfält → trigga "Skapa rapport"
$_enterHandler = {
    if ($_.KeyCode -eq 'Return') {
        $_.SuppressKeyPress = $true
        $btnBuild.PerformClick()
    }
}
$txtSammName.add_KeyDown($_enterHandler)
$txtSammDate.add_KeyDown($_enterHandler)
$txtSealTestSign.add_KeyDown($_enterHandler)
$txtGranskName.add_KeyDown($_enterHandler)
$txtGranskDate.add_KeyDown($_enterHandler)


# Instruktioner
$miShowInstr.add_Click({
    $msg = @"
SNABBGUIDE

SAMMANSTÄLLNING

Förberedelse: skapa "Stort Test Summary".

1) Ange LSP och klicka på "Sök filer" eller använd "Bläddra...".
   OBS: LSP-mappen ska ligga i: 3. IPT – KLART FÖR SAMMANSTÄLLNING

2) Klicka på "Skapa rapport".

GRANSKNING

Förberedelse: ladda ned dokument från MES.

1) Klicka på "KLART FÖR GRANSKNING". Filerna flyttas och läses in automatiskt.
   OBS: LSP-mappen ska ligga i: 4. IPT – KLART FÖR GRANSKNING

2) Klicka på "Skapa rapport".

"@
    Show-StyledInfoDialog -Title 'Instruktioner' -HeaderText ([char]0x2139 + '  Instruktioner') -Body $msg -Width 560 -Height 440
})

$miFAQ.Add_Click({
    $faq = @"
VANLIGA FRÅGOR (FAQ)

Vanliga fel och åtgärder
• "Hittar inte LSP" / "Inga filer funna" → Kontrollera att mappen finns i:
    2. IPT - KLART FÖR SAMMANSTÄLLNING
    3. IPT - KLART FÖR GRANSKNING

• Använd "Bläddra..." om du vill ladda filer manuellt.


Vad gör skriptet?
• Skapar en Excel‑rapport för det LSP du söker.

Vilka indata krävs?
• LSP och korrekt placering av mappar.

Vilka flikar finns i Excel‑rapporten?
• Run Information
    - Kort info om batch
    - Jämförelse av excelfilers "header"
    - SharePoint info

• Seal Test‑info
    - Jämförelse av data mellan POS och NEG

• STF Summary
    - Listar alla eventuella STF

• Utrustningslista

• Kontrollmaterial

• QC Summary
    - Summering av fel från alla filer

Var sparas rapporten?
• Endast temporärt i din:
$env:TEMP
Du kan stänga utan att spara efteråt.

Version: $ScriptVersion
"@
    Show-StyledInfoDialog -Title ('Vanliga fr' + [char]0x00E5 + 'gor') -HeaderText ([char]0x2753 + '  Vanliga fr' + [char]0x00E5 + 'gor') -Body $faq -Width 620 -Height 520
})

$miHelpDlg.add_Click({
    $helpForm = New-Object System.Windows.Forms.Form
    $helpForm.Text            = 'Skicka meddelande'
    $helpForm.Size            = New-Object System.Drawing.Size(480, 340)
    $helpForm.StartPosition   = 'CenterParent'
    $helpForm.FormBorderStyle = 'FixedDialog'
    $helpForm.MaximizeBox     = $false
    $helpForm.MinimizeBox     = $false
    $helpForm.Font            = New-Object System.Drawing.Font('Segoe UI', 10)

    $pHead = New-Object System.Windows.Forms.Panel
    $pHead.Dock      = 'Top'
    $pHead.Height    = 52
    $pHead.BackColor = [System.Drawing.Color]::SteelBlue
    $lblH = New-Object System.Windows.Forms.Label
    $lblH.Text      = [char]0x2709 + '  Skicka meddelande'
    $lblH.ForeColor = [System.Drawing.Color]::White
    $lblH.Font      = New-Object System.Drawing.Font('Segoe UI Semibold', 13)
    $lblH.AutoSize  = $false
    $lblH.Dock      = 'Fill'
    $lblH.Padding   = New-Object System.Windows.Forms.Padding(16, 0, 0, 0)
    $lblH.TextAlign = 'MiddleLeft'
    $pHead.Controls.Add($lblH)

    $helpBox = New-Object System.Windows.Forms.TextBox
    $helpBox.Multiline  = $true
    $helpBox.ScrollBars = 'Vertical'
    $helpBox.Dock       = 'Fill'
    $helpBox.Font       = New-Object System.Drawing.Font('Segoe UI', 10)

    $panelButtons = New-Object System.Windows.Forms.FlowLayoutPanel
    $panelButtons.Dock          = 'Bottom'
    $panelButtons.Height        = 52
    $panelButtons.FlowDirection = 'RightToLeft'
    $panelButtons.Padding       = New-Object System.Windows.Forms.Padding(16, 8, 16, 8)
    $panelButtons.WrapContents  = $false

    $btnCancel = New-Object System.Windows.Forms.Button
    $btnCancel.Text   = 'Avbryt'
    $btnCancel.Width  = 100
    $btnCancel.Height = 34
    $btnCancel.Margin = New-Object System.Windows.Forms.Padding(0)

    $btnSend = New-Object System.Windows.Forms.Button
    $btnSend.Text   = 'Skicka'
    $btnSend.Width  = 100
    $btnSend.Height = 34
    $btnSend.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
    try { Set-AccentButton $btnSend -Primary } catch {}

    $panelButtons.Controls.Add($btnCancel)
    $panelButtons.Controls.Add($btnSend)
    $helpForm.Controls.Add($helpBox)
    $helpForm.Controls.Add($panelButtons)
    $helpForm.Controls.Add($pHead)
    $btnSend.Add_Click({
        $msg = $helpBox.Text.Trim()
        if (-not $msg) { [System.Windows.Forms.MessageBox]::Show('Skriv ett meddelande innan du skickar.','Hjälp') | Out-Null; return }
        try {
            $helpDir = (Get-ConfigValue -Name 'HelpFeedbackDir' -Default (Join-Path $ScriptRootPath 'help') -ConfigOverride $null)
            if (-not (Test-Path -LiteralPath $helpDir)) { New-Item -ItemType Directory -Path $helpDir -Force | Out-Null }
            $ts   = (Get-Date).ToString('yyyyMMdd_HHmmss')
            $user = ($env:USERNAME + '').Trim()
            if (-not $user) { $user = 'unknown' }
            $file = Join-Path $helpDir ("help_{0}_{1}.txt" -f $user, $ts)

            $body = @(
                "User: $user"
                "Computer: $($env:COMPUTERNAME)"
                "Time: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"
                ''
                $msg
            ) -join "`r`n"
             Set-Content -Path $file -Value $body -Encoding UTF8
             [System.Windows.Forms.MessageBox]::Show('Meddelandet skickades. Tack!','Hjälp') | Out-Null
             $helpForm.Close()
         } catch {
            [System.Windows.Forms.MessageBox]::Show("Kunde inte skicka meddelandet:\n$($_.Exception.Message)",'Hjälp') | Out-Null
        }
    })
    $btnCancel.Add_Click({ $helpForm.Close() })
    $helpForm.ShowDialog() | Out-Null
})

$miStatus.add_Click({
    Show-ProjectStatusDialog
})

# Om
$miOm.add_Click({
    $nl = [Environment]::NewLine
    $omBody = "IPTCompile $ScriptVersion" + $nl + $nl +
              "Rapportgenerator för IPT-dokumentation." + $nl +
              "Detta är endast ett hjälpmedel och" + $nl +
              "ersätter inte någon IPT-process." + $nl + $nl +
              "Av: JESP"
    Show-StyledInfoDialog -Title 'Om IPTCompile' -HeaderText ([char]0x2139 + '  Om IPTCompile') -Body $omBody -Width 460 -Height 300
})

# Flytta nedladdade filer (LSP##### i filnamn)
$script:DevUnlocked = $false
$script:DevUnlockPassword = 'jesper'


$btnMove3.Add_Click({
    if (-not (Assert-DevUnlocked)) { return }
    Move-DownloadedLspFiles -TargetStage '3'
})
$btnMove4.Add_Click({ Move-DownloadedLspFiles -TargetStage '4' })

$btnScan.Add_Click({
    if ($script:_logPlaceholderActive) { $outputBox.Text = ''; $outputBox.ForeColor = [System.Drawing.SystemColors]::WindowText; $script:_logPlaceholderActive = $false }
    if (-not (Assert-StartupReady)) { return }

    $lspInput = ($txtLSP.Text + '').Trim()
    if (-not $lspInput) { Gui-Log "⚠️ Ange ett LSP-nummer" 'Warn'; return }

    # Normalisera: använd endast siffrorna som nyckel (tillåt '#38401', 'LSP 38401' osv.)
    $lsp = ($lspInput -replace '\D', '')
    if (-not $lsp) { Gui-Log "⚠️ Ange ett giltigt LSP-nummer (siffror)" 'Warn'; return }

    if ($script:BuildInProgress) { Gui-Log "⚠️ Rapportgenerering pågår – vänta tills den är klar." 'Warn'; return }
    if ($script:ScanInProgress)  { Gui-Log "⚠️ Sökning pågår redan – vänta." 'Warn'; return }
    $script:ScanInProgress = $true

    Gui-Log -Text ("🔎 Söker filer för {0}…" -f $lsp) -Severity Info -Category USER -Immediate

    try {
        # File lists must always be refreshed on every Search click.
        # Users may move missing files into the LSP folder during the same GUI session.
        # Therefore the previous scan result is not reused here.
        $script:LastScanResult = $null
        Gui-Log -Text ("Uppdaterar filinventering for {0} - cache ignorerad." -f $lsp) -Severity Info -Category DEBUG

        $folder = Find-LspFolder -Lsp $lsp -Roots $RootPaths
        if (-not $folder) {
            Gui-Log "❌ Ingen LSP-mapp hittad för $lsp" 'Warn'
            if ($env:IPT_ROOT) { Gui-Log "ℹ️ IPT_ROOT=$($env:IPT_ROOT)" 'Info' 'DEBUG' }
            $rootInfo = $RootPaths | ForEach-Object { "{0} ({1})" -f $_, $(if (Test-Path -LiteralPath $_) { "OK" } else { "MISSING" }) }
            Gui-Log -Text ("Sökvägar som provats: " + ($rootInfo -join " | ")) -Severity Info -Category USER
            return
        }

        if (-not (Test-Path -LiteralPath $folder.FullName)) {
            Gui-Log "❌ LSP-mappen hittades men finns inte längre: $($folder.FullName)" 'Warn'
            $rootInfo = $RootPaths | ForEach-Object { "{0} ({1})" -f $_, $(if (Test-Path -LiteralPath $_) { "OK" } else { "MISSING" }) }
            Gui-Log -Text ("Sökvägar som provats: " + ($rootInfo -join " | ")) -Severity Info -Category USER
            return
        }
        Gui-Log -Text ("📂 Mapp: {0}" -f $folder.Name) -Severity Info -Category USER

        # Plocka filer direkt fran aktuell mapp varje gang sokknappen klickas.
        $files = Get-ChildItem -LiteralPath $folder.FullName -File -ErrorAction SilentlyContinue

        $candCsv = @($files | Where-Object { $_.Extension -ieq '.csv' -and ( $_.Name -match [regex]::Escape($lsp) -or $_.Length -gt 100kb ) } | Sort-Object LastWriteTime -Descending)
        $candNeg = @($files | Where-Object { $_.Name -match '(?i)Neg.*\.xls[xm]$' -and $_.Name -match [regex]::Escape($lsp) } | Sort-Object LastWriteTime -Descending)
        $candPos = @($files | Where-Object { $_.Name -match '(?i)Pos.*\.xls[xm]$' -and $_.Name -match [regex]::Escape($lsp) } | Sort-Object LastWriteTime -Descending)
        $candMergedSeal = @($files | Where-Object {
            ($_.Extension -match '(?i)^\.xls[xm]$') -and
            ($_.Name -notmatch '(?i)worksheet') -and
            ($_.Name -notmatch '(?i)^~\$') -and
            (($_.Name -match [regex]::Escape($lsp)) -or ($_.Name -match '(?i)seal'))
        } | Sort-Object @{Expression={
                # I Merged-läge är bästa träff oftast en neutral Seal Test-fil, inte en gammal Split NEG/POS.
                if ($_.Name -notmatch '(?i)(^|[ _-])(neg|pos)([ _.-]|$)') { 0 }
                elseif ($_.Name -match '(?i)(^|[ _-])pos([ _.-]|$)') { 1 }
                else { 2 }
            }; Ascending=$true}, @{Expression={$_.LastWriteTime}; Descending=$true})
        $candLsp = @($files | Where-Object {
            ($_.Name -match '(?i)worksheet') -and ($_.Name -match [regex]::Escape($lsp)) -and ($_.Extension -match '^(\.xlsx|\.xlsm|\.xls)$')
        } | Sort-Object LastWriteTime -Descending)

        try {
            $ignoredCount = @($files | Where-Object { $_.Name -match '^(~\$|_)' -or $_.Extension -match '(?i)^\.(tmp|bak|old)$' }).Count
            $known = @($candCsv + $candNeg + $candPos + $candMergedSeal + $candLsp) | Where-Object { $_ }
            $knownPaths = @{}
            foreach ($k in $known) { try { $knownPaths[$k.FullName.ToLowerInvariant()] = $true } catch {} }
            $otherCount = @($files | Where-Object {
                $key = ''
                try { $key = $_.FullName.ToLowerInvariant() } catch {}
                -not $knownPaths.ContainsKey($key)
            }).Count
            Gui-Log -Text ("File inventory: total={0}, ignored={1}, csv={2}, sealNeg={3}, sealPos={4}, sealMerged={5}, worksheet={6}, other={7}" -f @($files.Count,$ignoredCount,$candCsv.Count,$candNeg.Count,$candPos.Count,$candMergedSeal.Count,$candLsp.Count,$otherCount)) -Severity Info -Category DEBUG
        } catch {}

        try { Invoke-SmartSealModeDetection -Neg $candNeg -Pos $candPos -Merged $candMergedSeal | Out-Null } catch {}

        Add-CLBItems -clb $clbCsv -files $candCsv -AutoCheckFirst
        if (Test-SealTestMergedMode) {
            Add-CLBItems -clb $clbNeg -files @()
            Add-CLBItems -clb $clbPos -files $candMergedSeal -AutoCheckFirst
        } else {
            Add-CLBItems -clb $clbNeg -files $candNeg -AutoCheckFirst
            Add-CLBItems -clb $clbPos -files $candPos -AutoCheckFirst
        }
        Add-CLBItems -clb $clbLsp -files $candLsp -AutoCheckFirst

        if ($candCsv.Count -eq 0) { Gui-Log "ℹ️ Ingen CSV hittad (endast .csv visas)." 'Info' }
        if (Test-SealTestMergedMode) {
            if ($candMergedSeal.Count -eq 0) { Gui-Log "⚠️ Ingen Seal Test-fil hittad för Merged-läge." 'Warn' }
        } else {
            if ($candNeg.Count -eq 0) { Gui-Log "⚠️ Ingen Seal NEG hittad." 'Warn' }
            if ($candPos.Count -eq 0) { Gui-Log "⚠️ Ingen Seal POS hittad." 'Warn' }
        }
        if ($candLsp.Count -eq 0) { Gui-Log "ℹ️ Ingen LSP Worksheet hittad." 'Info' }

        Update-BuildEnabled
        Update-BatchLink

        # Cachea FileInfo-objekt
        $script:LastScanResult = [pscustomobject]@{
            Lsp      = $lsp
            Folder   = $folder.FullName
            Csv      = @($candCsv)
            Neg        = @($candNeg)
            Pos        = @($candPos)
            SealMerged = @($candMergedSeal)
            LspFiles   = @($candLsp)
        }

        Gui-Log -Text "✅ Filer laddade." -Severity Info -Category USER
    }
    catch {
        Gui-Log ("❌ Filsökning misslyckades: " + $_.Exception.Message) 'Error'
    }
    finally {
        $script:ScanInProgress = $false
    }
})

$btnCsvBrowse.Add_Click({
    $dlg = $null
    try {
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = "CSV|*.csv|Alla filer|*.*"
        $dlg.Multiselect = $true
        if ($dlg.ShowDialog() -eq 'OK') {
            $paths = @($dlg.FileNames)  # kan vara 1 eller flera
            if ($paths.Count -gt 2) {
                Gui-Log "⚠️ Du valde $($paths.Count) CSV-filer. Endast de 2 första används (CSV + ev. Resample)." 'Warn'
                $paths = $paths[0..1]
            }

            $files = New-Object 'System.Collections.Generic.List[System.IO.FileInfo]'
            foreach ($p in $paths) {
                if (-not [string]::IsNullOrWhiteSpace($p)) {
                    [void]$files.Add((Get-Item -LiteralPath $p))
                }
            }

            if ($files.Count -gt 0) {
                Add-CLBItems -clb $clbCsv -files @($files.ToArray()) -AutoCheckFirst
            }
            Update-BuildEnabled
            Update-BatchLink
        }
    } finally { if ($dlg) { try { $dlg.Dispose() } catch {} } }
})

$btnNegBrowse.Add_Click({
    $dlg = $null
    try {
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = "Excel|*.xlsx;*.xlsm|Alla filer|*.*"
        try { $dlg.Title = if (Test-SealTestMergedMode) { 'Välj Seal Test-fil (Merged)' } else { 'Välj Seal Test NEG-fil' } } catch {}
        if ($dlg.ShowDialog() -eq 'OK') {
            $f = Get-Item -LiteralPath $dlg.FileName
            Add-CLBItems -clb $clbNeg -files @($f) -AutoCheckFirst
            Update-BuildEnabled
            Update-BatchLink
        }
    } finally { if ($dlg) { try { $dlg.Dispose() } catch {} } }
})

$btnPosBrowse.Add_Click({
    $dlg = $null
    try {
        $dlg = New-Object System.Windows.Forms.OpenFileDialog
        $dlg.Filter = "Excel|*.xlsx;*.xlsm|Alla filer|*.*"
        try { $dlg.Title = if (Test-SealTestMergedMode) { 'Välj Seal Test-fil (Merged)' } else { 'Välj Seal Test POS-fil' } } catch {}
        if ($dlg.ShowDialog() -eq 'OK') {
            $f = Get-Item -LiteralPath $dlg.FileName
            Add-CLBItems -clb $clbPos -files @($f) -AutoCheckFirst
            Update-BuildEnabled
            Update-BatchLink
        }
    } finally { if ($dlg) { try { $dlg.Dispose() } catch {} } }
})

# --- Hjälp: Konvertera A1-adress (t.ex. 'E1') till rad/kolumn (EPPlus-säkert) ---

# --- Hjälp: Skanna Data Summary-blad efter alla konfigurerade statusmönster ---
