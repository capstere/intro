﻿# --------------------------------------------------------------------
# Excel Data Mapping Functions
# --------------------------------------------------------------------

function Get-ExcelDataMapping {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$TemplatePath,

        [Parameter(Mandatory = $true)]
        [string]$ReferencePath,

        [Parameter(Mandatory = $true)]
        [string]$OutputJsonPath
    )

    Import-Module ImportExcel -ErrorAction Stop

    try {
        $referencePkg = Open-ExcelPackage -Path $ReferencePath
        $templatePkg  = Open-ExcelPackage -Path $TemplatePath

        $dataMapping = [System.Collections.Generic.List[PSCustomObject]]::new()

        # Loop through each sheet and collect all deviations in $dataMapping
        foreach ($templateSheet in $templatePkg.Workbook.Worksheets) {

            $referenceSheet = $referencePkg.Workbook.Worksheets[$templateSheet.Name]

            # Get header deviations
            $headerDeviations = Get-DocumentHeaderDifferences -TemplateSheet $templateSheet -ReferenceSheet $referenceSheet

            # If sheet does not exist in reference, skip
            if (-not $referenceSheet) {
                Write-Warning "Sheet $($templateSheet.Name) missing in reference document"
                continue
            }

            # If sheet contents are identical, sheet deviations
            if (-not (Test-SheetsIdentical -TemplateSheet $templateSheet -ReferenceSheet $referenceSheet)) {
                $deviations = Get-SheetDeviations -TemplateSheet $templateSheet -ReferenceSheet $referenceSheet
            } else {
                $deviations = $null
            }

            if (-not $deviations -and -not $headerDeviations) {
                continue
            }

            $dataMapping.Add([PSCustomObject]@{
                Sheet = $templateSheet.Name
                Header = $headerDeviations
                Data  = $deviations
            })
        }

        $dataMapping | ConvertTo-Json -Depth 10 | Set-Content -Path $OutputJsonPath -Encoding UTF8
    }
    finally {
        if ($referencePkg) { $referencePkg.Dispose() }
        if ($templatePkg)  { $templatePkg.Dispose() }
    }
}

function Get-DocumentHeaderDifferences {
    param(
        $TemplateSheet,
        $ReferenceSheet
    )

    $templateHeader  = Get-DocumentHeader -Worksheet $TemplateSheet
    $referenceHeader = Get-DocumentHeader -Worksheet $ReferenceSheet

    $diff = @()

    foreach ($section in @("Left","Center","Right")) {

        $templateValue = $templateHeader[$section]
        $referenceValue = $referenceHeader[$section]

        if ($templateValue -ne $referenceValue) {

            $diff += @{
                Position = $section
                Value    = $templateValue
            }
        }
    }

    if ($diff.Count -gt 0) { $diff } else { $null }
}

function Get-SheetDeviations {
    <#
    .SYNOPSIS
        Iterates through an entire worksheet to find all anchored deviations.
    #>
    param($TemplateSheet, $ReferenceSheet)

    $deviations = [System.Collections.Generic.List[PSCustomObject]]::new()
    $processedCells = [System.Collections.Generic.HashSet[string]]::new()

    
    $maxRows = $TemplateSheet.Dimension.Rows
    $maxCols = $TemplateSheet.Dimension.Columns


    for ($rowIndex = 1; $rowIndex -le $maxRows; $rowIndex++) {
        $columnIndex = 1
        while ($columnIndex -le $maxCols) {

            $templateCell = $TemplateSheet.Cells[$rowIndex, $columnIndex]
            $referenceCell = $ReferenceSheet.Cells[$rowIndex, $columnIndex]
            $hasFormula = -not [string]::IsNullOrWhiteSpace($referenceCell.Formula)
            
            # Skip if cell has been processed
            if ($processedCells.Contains($templateCell.Address)) {
                $columnIndex += Get-MergeOffset -Cell $templateCell -Direction "Column"
                continue
            }

            # Check for deviations between the template and the reference
            if ($templateCell.Text -ne $referenceCell.Text -and -not $hasFormula) {

                $anchor = Get-ExcelAnchor -Sheet $ReferenceSheet -Row $rowIndex -Col $columnIndex
                
                # If an anchor is found, save all consecutive deviations in the same object
                if ($anchor) {
                    $AnchoredDeviations = Get-AnchoredDeviations -TemplateSheet $TemplateSheet -ReferenceSheet $ReferenceSheet `
                                                    -StartRow $rowIndex -StartCol $columnIndex -Direction $anchor.Direction -ProcessedCells $processedCells
                    
                    $deviations.Add([PSCustomObject]@{
                        Anchor      = $anchor.Anchor
                        Direction   = $anchor.Direction
                        Values      = $AnchoredDeviations.Values
                        Colors      = $AnchoredDeviations.Colors
                        StartRow    = $AnchoredDeviations.StartRow
                        StartCol    = $AnchoredDeviations.StartCol
                    })

                    # If anchored deviations were collected column-wise, skip to next unprocessed column
                    if ($anchor.Direction -eq "Column") { 
                        $columnIndex += $AnchoredDeviations.Values.Count
                        continue 
                    }
                } else { # If no anchor is found, save deviation without anchor or direction
                    $deviations.Add([PSCustomObject]@{
                        Anchor    = $null
                        Direction = $null
                        Values    = $templateCell.Text
                        Colors    = Get-Color $templateCell
                        StartRow  = $templateCell.Start.Row
                        StartCol  = $templateCell.Start.Column
                    })
                }
            }

            $columnIndex += Get-MergeOffset -Cell $templateCell -Direction "Column"
        }
    }

    if ($deviations.Count -gt 0) { $deviations } else { $null }
}

function Get-ExcelAnchor {
    <#
    .SYNOPSIS
        Searches for a descriptive text label (anchor) near a specific cell.
    .DESCRIPTION
        Checks the cell to the left first, then the cell above. An anchor is 
        defined as any cell containing alphabetic characters ([a-z]).
    .PARAMETER Sheet
        The Worksheet object to search within.
    #>
    param ($Sheet, $Row, $Column)

    $anchor = $null
    $direction = $null

    # 1. Look for anchor LEFT
    if ($Column -gt 1) {
        $leftCell = $Sheet.Cells[$Row, ($Column - 1)]
        $info = Get-MergeStartPoint -Cell $leftCell
        $text = $Sheet.Cells[$info.Address].Text
        if ($text -match "\p{L}") { $anchor = $text; $direction = "Column" }
    }

    # 2. Look for anchor ABOVE (if no left anchor found)
    if (-not $anchor -and $Row -gt 1) {
        $aboveCell = $Sheet.Cells[($Row - 1), $Column]
        $info = Get-MergeStartPoint -Cell $aboveCell
        $text = $Sheet.Cells[$info.Address].Text
        if ($text -match "\p{L}") { $anchor = $text; $direction = "Row" }
    }

    if ($anchor) { [PSCustomObject]@{ Anchor = $anchor; Direction = $direction } } else { $null }
}

function Get-AnchoredDeviations {
    <#
    .SYNOPSIS
        Collects a sequence of deviating cells starting from a specific point.
    .DESCRIPTION
        The function iterates through subsequent cells in the anchor's direction 
        until values match the reference or a formula is encountered.
    .PARAMETER ProcessedCells
        A HashSet used to track and skip already analyzed cells.
    #>
    param($TemplateSheet, $ReferenceSheet, $StartRow, $StartCol, $Direction, $ProcessedCells)

    $values = [System.Collections.Generic.List[string]]::new()
    $colors = [System.Collections.Generic.List[string]]::new()
    
    $currentRow = $StartRow
    $currentCol = $StartCol

    $maxRows = $TemplateSheet.Dimension.Rows
    $maxCols = $TemplateSheet.Dimension.Columns

    while ($currentRow -le $maxRows -and $currentCol -le $maxCols) {
        $templateCell = $TemplateSheet.Cells[$currentRow, $currentCol]
        $referenceCell = $ReferenceSheet.Cells[$currentRow, $currentCol]

        # Stop if formula or matching values are found
        if ($templateCell.Text -eq $referenceCell.Text -or $referenceCell.Formula) { break }

        # Save data
        $null = $ProcessedCells.Add($templateCell.Address)
        $values.Add($templateCell.Text)
        $colors.Add((Get-Color $templateCell))

        # verify that the merged block matches 
        if (-not ($templateCell.Merge -eq $referenceCell.Merge)) {
            Write-Warning "Merged property mismatch found for cell $($templateCell.Address) in $($TemplateSheet.Name)"
            break 
        }

        # Go to next cell
        $jump = Get-MergeOffset -Cell $templateCell -Direction $Direction
        if ($Direction -eq "Column") { $currentCol += $jump } else { $currentRow += $jump }
    }

    [PSCustomObject]@{ 
        Values = $values.ToArray()
        Colors = $colors.ToArray()
        StartRow = $StartRow
        StartCol = $StartCol
    }
}

# --------------------------------------------------------------------
# Excel Fill Functions
# --------------------------------------------------------------------

function Fill-ExcelWorksheet {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$TargetPath,

        [Parameter(Mandatory)]
        [string]$MappingJsonPath,

        [Parameter(Mandatory)]
        [hashtable]$Keywords
    )

    Import-Module ImportExcel -ErrorAction Stop

    $mapping = Get-Content $MappingJsonPath -Raw -Encoding UTF8 | ConvertFrom-Json

    $documentWrites = Collect-DocumentWrites -TargetPath $TargetPath -Mapping $mapping

    Apply-DocumentWritesViaCom -TargetPath $TargetPath -DocumentWrites $documentWrites -Keywords $Keywords
}

function Collect-DocumentWrites {
    param(
        [string]$TargetPath,
        $Mapping
    )

    Import-Module ImportExcel -ErrorAction Stop

    $targetPkg = Open-ExcelPackage -Path $TargetPath

    $documentWrites = @()

    try {
        foreach ($sheetMapping in $Mapping) {
            
            $bodyWrites = Collect-SheetWrites -Worksheet $targetPkg.Workbook.Worksheets[$sheetMapping.Sheet] -BodyMapping $sheetMapping.Data

            if (-not $bodyWrites -and -not $sheetMapping.Header) {
                continue
            }

            $documentWrites += @{
                Sheet  = $sheetMapping.Sheet
                Writes = $bodyWrites
                Header = $sheetMapping.Header
            }
        }
    }
    finally {
        $targetPkg.Dispose()
    }

    $documentWrites
}

function Apply-DocumentWritesViaCom {
    param(
        [string]$TargetPath,
        $DocumentWrites,
        [hashtable]$Keywords
    )

    if (-not $DocumentWrites -or $DocumentWrites.Count -eq 0) {
        return
    }

    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $wb = $excel.Workbooks.Open($TargetPath)

    try {
        foreach ($sheetWrite in $DocumentWrites) {
            $sheet = $wb.Worksheets.Item($sheetWrite.Sheet)

            if ($sheet.ProtectContents) {
                $sheet.Unprotect()
            }

            # Write header
            foreach ($section in $sheetWrite.Header) {

                $headerText = Replace-Keyword -Value $section.Value -Keywords $Keywords

                switch ($section.Position) {
                    "Left"   { $sheet.PageSetup.LeftHeader   = $headerText }
                    "Center" { $sheet.PageSetup.CenterHeader = $headerText }
                    "Right"  { $sheet.PageSetup.RightHeader  = $headerText }
                }
            }

            foreach ($write in $sheetWrite.Writes) {

                $cell = $sheet.Cells.Item($write.Row, $write.Col)

                # Determine if value contrains a keyword
                if ($write.Value -match "%.+%") {
                     $writeValue = Replace-Keyword -Value $write.Value -Keywords $Keywords
                } else {
                    $writeValue = $write.Value
                }

                # Determine if cell has restriced values, if so, choose closest value
                if (Test-IsRestrictionEnforced -Cell $cell) {

                    $allowedValues = Get-AllowedValues -Cell $cell

                    $writeValue = Get-BestMatch -InputString $writeValue -AllowedValues $allowedValues
                }

                $sheet.Cells.Item($write.Row, $write.Col).Value2 = $writeValue
            }

            $sheet.Protect()
        }

        $wb.Save()
    }
    finally {
        $wb.Close()
        $excel.Quit()
    }
}

function Collect-SheetWrites {
    param(
        $Worksheet,
        $BodyMapping
    )

    $writes = @()

    if (-not $Worksheet) {
        Write-Warning "Missing worksheet '$($SheetMapping.Sheet)'"
        return $null
    }

    if (-not $BodyMapping) {
        return $null
    }

    foreach ($entry in $BodyMapping) {
        if (-not $entry.Anchor) {
            $writes += Resolve-NoAnchorEntry -Worksheet $Worksheet -Entry $entry
        }
        else {
            $writes += Resolve-AnchoredEntry -Worksheet $Worksheet -Entry $entry
        }
    }

    if ($writes.Count -gt 0) { $writes } else { $null }
}

function Resolve-NoAnchorEntry {
    param(
        [Parameter(Mandatory)]
        $Worksheet,
        [Parameter(Mandatory)]
        $Entry
    )

    $cell = $Worksheet.Cells[$Entry.StartRow, $Entry.StartCol]
    $cellHasFormula = -not [string]::IsNullOrWhiteSpace($cell.Formula)
    $colorMismatch = $Entry.Colors -ne (Get-Color -Cell $cell)

    if ($cell.Text -ne "" -or $cellHasFormula -or $colorMismatch) {
        $write = @()
    } else {
        $write = (@{
            Sheet = $Worksheet.Name
            Row   = $cell.Start.Row
            Col   = $cell.Start.Column
            Value = $Entry.Values
        })
    }

    $write
}

function Resolve-AnchoredEntry {
    param(
        $Worksheet, 
        $Entry
    )

    $anchorCells = Find-AnchorCells `
        -Worksheet $Worksheet `
        -AnchorText $Entry.Anchor

    if (-not $anchorCells) { return @() }

    $closestAnchor = Resolve-ClosestAnchor `
        -AnchorCells $anchorCells `
        -Entry $Entry

    if (-not $closestAnchor) { return @() }

    return Generate-AnchoredWrites `
        -Worksheet $Worksheet `
        -AnchorCell $closestAnchor `
        -Entry $Entry
}

function Find-AnchorCells {
    param($Worksheet, [string]$AnchorText)

    $results = $Worksheet.Cells | Where-Object { $_.Text -eq $AnchorText }

    if ($results.Count -eq 0) {
        Write-Warning "Anchor '$anchorText' not found on sheet '$Worksheet'"
    }

    $results
}

function Resolve-ClosestAnchor {
    param($AnchorCells, $Entry)

    $row = $Entry.StartRow
    $col = $Entry.StartCol

    $AnchorCells |
        Sort-Object {
            [math]::Abs($_.Start.Row - $row) +
            [math]::Abs($_.Start.Column - $col)
        } | Select-Object -First 1
}

function Generate-AnchoredWrites {
    param($Worksheet, $AnchorCell, $Entry)

    $writes = @()

    $offset = Get-MergeOffset -Cell $AnchorCell -Direction $Entry.Direction
    if ($offset -lt 1) { $offset = 1 }

    $row = if ($Entry.Direction -eq "Row") { $AnchorCell.Start.Row + $offset } else { $AnchorCell.Start.Row }
    $col = if ($Entry.Direction -eq "Column") { $AnchorCell.Start.Column + $offset } else { $AnchorCell.Start.Column }

    for ($i = 0; $i -lt $Entry.Values.Length; $i++) {

        $value = $Entry.Values[$i]

        $cell = $Worksheet.Cells[$row, $col]
        $cellHasFormula = -not [string]::IsNullOrWhiteSpace($cell.Formula)
        $colorMismatch = $Entry.Colors[$i] -ne (Get-Color -Cell $cell)

        if ($cell.Text -ne "" -or $cellHasFormula -or $colorMismatch) {
            break
        }

        $writes += (@{
            Sheet = $Worksheet.Name
            Row   = $cell.Start.Row
            Col   = $cell.Start.Column
            Value = $value
        })

        $jump = Get-MergeOffset -Cell $cell -Direction $Entry.Direction
        if ($jump -lt 1) { $jump = 1 }

        if ($Entry.Direction -eq "Column") { $col += $jump }
        else { $row += $jump }
    }

    $writes
}

# --------------------------------------------------------------------
# Help Functions
# --------------------------------------------------------------------

function Get-Color {
    param (
        [Parameter(Mandatory = $true)]
        [OfficeOpenXml.ExcelRange]$Cell
    )
    
    #Write-Host $Cell
    if ($Cell.Style.Fill.BackgroundColor.Rgb) { 
        $color = $Cell.Style.Fill.BackgroundColor.Rgb 
    }
    elseif ($Cell.Style.Fill.BackgroundColor.Theme) {
        $color = $Cell.Style.Fill.BackgroundColor.Theme 
    }
    else {
        $color = $Cell.Style.Fill.BackgroundColor.LookupColor().Substring(1)
    }

    $color
}

function Get-MergeStartPoint {
    <#
    .SYNOPSIS
        Retrieves the start cell for a specific merged Excel cell.

    .DESCRIPTION
        This function identifies if a cell is part of a merged range. 
        It returns the coordinates of the top-left starting cell of 
        the merged area.

    .PARAMETER Cell
        The ExcelRange object to inspect.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        $Cell
    )

    # Initialize default result cell itself, and change if cell is merged
    $result = [PSCustomObject]@{
        Row     = $Cell.Start.Row
        Column  = $Cell.Start.Column
        Address = $Cell.Address
    }

    if ($Cell.Merge) {
        $worksheet = $Cell.Worksheet
        $mergeId = $worksheet.GetMergeCellId($Cell.Start.Row, $Cell.Start.Column)

        # Retrieve the full range of the cell, e.g. "A1:C2"
        $address = $worksheet.MergedCells[$mergeId - 1]
        $range = $worksheet.Cells[$address]

        # Return coordinates of the top-left cell in the merge
        $result = [PSCustomObject]@{
            Row     = $range.Start.Row
            Column  = $range.Start.Column
            Address = $range.Start.Address
        }
    }
    $result
}

function Get-MergeOffset {
    <#
    .SYNOPSIS
        Retrieves merge information for a specific Excel cell.

    .DESCRIPTION
        This function identifies if a cell is part of a merged range. 
        It returns the step count to skip the merge.

    .PARAMETER Cell
        The ExcelRange object to inspect.

    .PARAMETER Direction
        When requesting an Offset, defines if the jump should be calculated 
        horizontally and to the right (Column) or vertically and down (Row).
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        $Cell,

        [ValidateSet("Row", "Column")]
        [string]$Direction = "Column"
    )

    # Initialize default result as 1 (standard single-cell step)
    $result = 1

    if ($Cell.Merge) {
        $worksheet = $Cell.Worksheet
        $mergeId = $worksheet.GetMergeCellId($Cell.Start.Row, $Cell.Start.Column)

        # Retrieve the full range of the cell, e.g. "A1:C2"
        $address = $worksheet.MergedCells[$mergeId - 1]
        $range = $worksheet.Cells[$address]

        # Calculate skip distance in defined direction
        if ($Direction -eq "Column") {
            $result = ($range.End.Column - $Cell.Start.Column) + 1
        }
        else {
            $result = ($range.End.Row - $Cell.Start.Row) + 1
        }
    }
    $result
}

function Get-SheetValueHash {
    param($Sheet)

    $hasher = [System.Security.Cryptography.SHA256]::Create()

    foreach ($cell in $Sheet.Cells[$Sheet.Dimension.Address]) {
        $value = if ($null -eq $cell.Value) { "" } else { $cell.Value.ToString() }
        $bytes = [Text.Encoding]::UTF8.GetBytes($value)
        $hasher.TransformBlock($bytes, 0, $bytes.Length, $null, 0) | Out-Null
    }

    $hasher.TransformFinalBlock([byte[]]::new(0), 0, 0) | Out-Null
    ($hasher.Hash -join '')
}

function Get-LevenshteinDistance {
    <#
        .SYNOPSIS
            Get the Levenshtein distance between two strings.
        .DESCRIPTION
            The Levenshtein Distance is a way of quantifying how dissimilar two strings (e.g., words) are to one another by counting the minimum number of operations required to transform one string into the other.
        .EXAMPLE
            Get-LevenshteinDistance 'kitten' 'sitting'
        .LINK
            http://en.wikibooks.org/wiki/Algorithm_Implementation/Strings/Levenshtein_distance#C.23
            http://en.wikipedia.org/wiki/Edit_distance
            https://communary.wordpress.com/
            https://github.com/gravejester/Communary.PASM
        .NOTES
            Author: Øyvind Kallstad
            Date: 07.11.2014
            Version: 1.0
    #>
    [CmdletBinding()]
    param(
        [Parameter(Position = 0)]
        [string]$String1,

        [Parameter(Position = 1)]
        [string]$String2,

        # Makes matches case-sensitive. By default, matches are not case-sensitive.
        [Parameter()]
        [switch] $CaseSensitive,

        # A normalized output will fall in the range 0 (perfect match) to 1 (no match).
        [Parameter()]
        [switch] $NormalizeOutput
    )

    if (-not($CaseSensitive)) {
        $String1 = $String1.ToLowerInvariant()
        $String2 = $String2.ToLowerInvariant()
    }

    $d = New-Object 'Int[,]' ($String1.Length + 1), ($String2.Length + 1)

    try {
        for ($i = 0; $i -le $d.GetUpperBound(0); $i++) {
            $d[$i,0] = $i
        }

        for ($i = 0; $i -le $d.GetUpperBound(1); $i++) {
            $d[0,$i] = $i
        }

        for ($i = 1; $i -le $d.GetUpperBound(0); $i++) {
            for ($j = 1; $j -le $d.GetUpperBound(1); $j++) {
                $cost = [Convert]::ToInt32((-not($String1[$i-1] -ceq $String2[$j-1])))
                $min1 = $d[($i-1),$j] + 1
                $min2 = $d[$i,($j-1)] + 1
                $min3 = $d[($i-1),($j-1)] + $cost
                $d[$i,$j] = [Math]::Min([Math]::Min($min1,$min2),$min3)
            }
        }

        $distance = ($d[$d.GetUpperBound(0),$d.GetUpperBound(1)])

        if ($NormalizeOutput) {
            Write-Output (1 - ($distance) / ([Math]::Max($String1.Length,$String2.Length)))
        }

        else {
            Write-Output $distance
        }
    }

    catch {
        Write-Warning $_.Exception.Message
    }
}

function Get-BestMatch {
    param(
        [string]$InputString,
        [string[]]$AllowedValues
    )

    $bestMatch = $null
    $minScore = [int]::MaxValue

    foreach ($value in $AllowedValues) {
        $currentScore = Get-LevenshteinDistance -String1 $InputString -String2 $value
        
        # If we find a perfect match (0), stop and return it immediately
        if ($currentScore -eq 0) { $bestMatch = $value; break }

        if ($currentScore -lt $minScore) {
            $minScore = $currentScore
            $bestMatch = $value
        }
    }
    $bestMatch
}

function Replace-Keyword {
    param(
        [Parameter(Mandatory)]
        [string]$Value,

        [Parameter(Mandatory)]
        [hashtable]$Keywords
    )

    [regex]::Replace(
        $Value,
        '%([^%]+)%',
        {
            param($match)

            # Leave unknown placeholders untouched
            $result = $match.Value

            $key = $match.Groups[1].Value

            if ($Keywords.ContainsKey($key)) {
                $result = $Keywords[$key]
            }

            # Leave unknown placeholders untouched
            $result
        }
    )
}

function Test-IsRestrictionEnforced {
    param([Parameter(Mandatory=$true)] 
        $Cell
    )

    try {
        $validation = $Cell.Validation

        $isEnforced = ($validation.Type -eq 3) -and ($validation.AlertStyle -eq 1)
    } catch {
        $isEnforced = $false
    }

    $isEnforced
}

function Get-AllowedValues {
    param(
        [Parameter(Mandatory=$true)] 
        $Cell
    )

    $formula = $Cell.Validation.Formula1

    if ($formula.StartsWith("=")) {
        # Strip the '=' to get the reference (e.g., "Sheet2!$A$1:$A$10")
        $rangeRef = $formula.TrimStart("=")
        
        # Use the Application object to find the range anywhere in the workbook
        $listRange = $Cell.Application.Evaluate($rangeRef)
        
        $values = @()
        # Handle the 2D array returned by Excel ranges
        foreach ($item in $listRange.Value2) {
            if ($null -ne $item) { 
                $values += [string]$item 
            }
        }
    } else {
        # Handle simple comma-separated lists
        $values = $formula -split ","
    }

    $values
}

function Test-SheetsIdentical {
    param(
        $TemplateSheet,
        $ReferenceSheet
    )

    # 1. Prepare the MD5 provider
    $md5 = [System.Security.Cryptography.MD5]::Create()

    # 2. Convert sheets to a single string (joining cell values with a pipe)
    $string1 = $TemplateSheet | ForEach-Object { $_.psobject.properties.Value -join "|" } | Out-String
    $string2 = $ReferenceSheet | ForEach-Object { $_.psobject.properties.Value -join "|" } | Out-String

    # 3. Compute the hashes
    $hash1 = [System.BitConverter]::ToString($md5.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($string1)))
    $hash2 = [System.BitConverter]::ToString($md5.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($string2)))

    # 4. Final Boolean check
    $isIdentical = $hash1 -eq $hash2
    $isIdentical
}

function Get-DocumentHeader {
    param($Worksheet)

    $header = $Worksheet.HeaderFooter.OddHeader

    @{
        Left   = $header.LeftAlignedText
        Center = $header.CenteredText
        Right  = $header.RightAlignedText
    }
}

Remove-Item "Target - Copy.xlsx"
Copy-Item "Target.xlsx" "Target - Copy.xlsx"

$referencePath = "D25862 Attachment 1 MTB Ultra V2 Product QC Testing Worksheet Rev BA.xlsx"
$templatePath = "Filled.xlsx"
$targetPath = "N:\QC\QC-1\IPT\Skiftspecifika dokument\Skift 4\Niklas\Mappscript PA\Template Generator\Target - Copy.xlsx"

$dataMappingStart = Get-Date

Get-ExcelDataMapping -TemplatePath $templatePath -ReferencePath $referencePath -OutputJsonPath "Deviations.json"

$dataMappingEnd = Get-Date

Write-Host "Mapping execution time: $([math]::Round(($dataMappingEnd - $dataMappingStart).TotalSeconds,2)) seconds"

$WorksheetFillStart = Get-Date

$keywords =@{
    "LSP" = "96104"
    "BATCH" = "1001525941"
    "KITPN" = "GXMTB/RIF-ULTRA-10"
    "PN" = "700-5702"
    "EXPDATE" = "2027 09 12"
    "DATE" = "2026 03 28"
}
Fill-ExcelWorksheet -TargetPath $targetPath -MappingJsonPath "Deviations.json" -Keywords $keywords

$WorksheetFillEnd = Get-Date

Write-Host "Filling execution time: $([math]::Round(($WorksheetFillEnd - $WorksheetFillStart).TotalSeconds,2)) seconds"