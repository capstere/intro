﻿<#
    Demo for DocumentMapping module
#>

# Ensure correct location
cd "N:\QC\QC-1\IPT\Skiftspecifika dokument\Skift 4\Niklas\Mappscript PA\Template Generator"

Import-Module (Get-Item "DocumentMapping.psm1").FullName -Force

<#
# Install the module if needed
$moduleName = 'DocumentMapping'
if (-not (Get-Module -ListAvailable -Name 'DocumentMapping'))
{
    Write-Host "Installing module: $moduleName"

    $moduleSource = 'DocumentMapping.psm1'
    $moduleTarget = Join-Path $HOME 'Documents\WindowsPowerShell\Modules'

    $destination = Join-Path $moduleTarget $moduleName

    if (-not (Test-Path $destination)) {
        New-Item -ItemType Directory -Path $destination | Out-Null
        Copy-Item $moduleSource $destination -Force
    }
}

Import-Module DocumentMapping -Force
#>

# Create target copy to allow for multiple runs
if (Test-Path "TargetFilled.xlsx") {
    Remove-Item "TargetFilled.xlsx"
}
Copy-Item "Demo Files\Target.docx" "TargetFilled.docx"

$referencePath = "Demo Files\Reference.docx"
$templatePath = "Demo Files\Template.docx"
$targetPath = "TargetFilled.docx"

# -----------------------------------------------------------------------------------------
# Generate mapping file from reference and user filled file. Execution time is recorded
# -----------------------------------------------------------------------------------------

# Define input parameters
$getMappingParams = @{
    TemplatePath   = $templatePath 
    ReferencePath  = $referencePath 
    OutputJsonPath = "Demo Files\Deviations_Word.json"
}

$dataMappingStart = Get-Date
Get-WordDocumentMapping @getMappingParams
$dataMappingEnd = Get-Date

Write-Host "Mapping execution time: $([math]::Round(($dataMappingEnd - $dataMappingStart).TotalSeconds,2)) seconds"

# -----------------------------------------------------------------------------------------
# Apply mapping file from reference and user filled file. Execution time is recorded
# -----------------------------------------------------------------------------------------

# Provide definitions for the keywords used in the filled document
$keywords =@{
    "LSP" = "96104"
    "BATCH" = "1001525941"
    "ORDER" = "1115682"
    "KITPN" = "GXMTB/RIF-ULTRA-10"
    "PN" = "700-5702"
    "EXPDATE" = "2027 09 12"
    "DATE" = "2026 03 28"
    "DOCN" = "D25862"
}

# Define input parameters
$getMappingParams = @{
    TemplatePath   = $templatePath 
    ReferencePath  = $referencePath 
    OutputJsonPath = "Demo Files\Deviations.json"
}

$WorksheetFillStart = Get-Date
Invoke-WordDocumentMapping -TargetPath $targetPath -MappingJsonPath "Demo Files\Deviations.json" -Keywords $keywords
$WorksheetFillEnd = Get-Date

Write-Host "Filling execution time: $([math]::Round(($WorksheetFillEnd - $WorksheetFillStart).TotalSeconds,2)) seconds"