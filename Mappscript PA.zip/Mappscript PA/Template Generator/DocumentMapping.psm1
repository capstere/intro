﻿
# --------------------------------------------------------------------
# Excel Data Mapping Functions
# --------------------------------------------------------------------

function Get-ExcelDocumentMapping {
    <#
    .SYNOPSIS
        Generates a JSON mapping that describes all deviations introduced
        by a template Excel workbook compared to a reference workbook.

    .DESCRIPTION
        This function treats the reference workbook as a baseline and the
        template workbook as authoritative.

        For each worksheet in the template:
        - If the sheet does not exist in the reference, it is skipped
        - Document header differences are detected independently
        - Cell-level deviations are recorded only when they differ
        - Cells containg formulas are skipped entirely
        - Sheets with no differences are omitted from the output entirely

        The resulting mapping is serialized to JSON for later reuse
        during fill operations.

    .PARAMETER TemplatePath
        Path to the filled template workbook.

    .PARAMETER ReferencePath
        Path to the reference workbook.

    .PARAMETER OutputJsonPath
        Path where the generated JSON mapping will be written.

    .OUTPUTS
        None. Writes a JSON file to disk.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateScript({ Test-Path -Path $_ })]
        [string]$TemplatePath,

        [Parameter(Mandatory = $true)]
        [ValidateScript({ Test-Path -Path $_ })]
        [string]$ReferencePath,

        [Parameter(Mandatory = $true)]
        [string]$OutputJsonPath
    )

    Import-Module ImportExcel -ErrorAction Stop


    try {
        $referencePackage = Open-ExcelPackage -Path $ReferencePath
        $templatePackage  = Open-ExcelPackage -Path $TemplatePath

        $dataMapping = [System.Collections.Generic.List[pscustomobject]]::new()

        foreach ($templateSheet in $templatePackage.Workbook.Worksheets) {

            $referenceSheet = $referencePackage.Workbook.Worksheets[$templateSheet.Name]

            if (-not $referenceSheet) {
                Write-Warning "Sheet '$($templateSheet.Name)' missing in reference workbook"
                continue
            }

            # Detect document header deviations independently from cell content.
            $headerParams = @{
                TemplateSheet  = $templateSheet
                ReferenceSheet = $referenceSheet
            }
            $headerDeviations = Get-DocumentHeaderDifferences @headerParams

            # Cell-level deviation detection is expensive, so it is only
            # performed when the sheets are not identical.
            $sheetDeviations = $null

            $sheetParams = @{
                TemplateSheet  = $templateSheet
                ReferenceSheet = $referenceSheet
            }
            if (-not (Test-SheetsIdentical @sheetParams)) {
                $sheetDeviations = Get-SheetDeviations @sheetParams
            }

            # If neither header nor body content differs, the sheet is omitted
            if (-not $sheetDeviations -and -not $headerDeviations) {
                continue
            }

            $dataMapping.Add(
                [pscustomobject] @{
                    Sheet  = $templateSheet.Name
                    Header = $headerDeviations
                    Data   = $sheetDeviations
                }
            )
        }

        $dataMapping |
            ConvertTo-Json -Depth 10 |
            Set-Content -Path $OutputJsonPath -Encoding UTF8
    }
    finally {
        # Ensure Excel packages are disposed even if an exception occurs.
        if ($referencePackage) {
            $referencePackage.Dispose()
        }

        if ($templatePackage) {
            $templatePackage.Dispose()
        }
    }
}

function Get-DocumentHeaderDifferences {
    <#
    .SYNOPSIS
        Identifies document header differences introduced by the template worksheet.

    .DESCRIPTION
        Compares the document header between a template worksheet and a
        reference worksheet.

        The reference worksheet is treated as the baseline, and the template
        worksheet is treated as authoritative. Any header positions (Left, Center,
        Right) where the template differs from the reference are captured and
        returned as deviations.

        Only header content added or modified by the template is returned.
        If no differences are detected, the function returns $null.

    .PARAMETER TemplateSheet
        The worksheet containing the authoritative document header.

    .PARAMETER ReferenceSheet
        The worksheet representing the baseline document header.

    .OUTPUTS
        An array of hashtables describing header deviations, or $null if
        no differences are found.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $TemplateSheet,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $ReferenceSheet
    )

    $templateHeader  = Get-DocumentHeader -Worksheet $TemplateSheet
    $referenceHeader = Get-DocumentHeader -Worksheet $ReferenceSheet

    $differences = @()

    foreach ($position in 'Left', 'Center', 'Right')
    {
        $templateValue  = $templateHeader[$position]
        $referenceValue = $referenceHeader[$position]

        # A difference is recorded only when the template introduces
        # new or modified header content relative to the reference.
        if ($templateValue -ne $referenceValue) {
            if (-not [string]::IsNullOrWhiteSpace($templateValue)) {
                $differences += @{
                    Position = $position
                    Value    = $templateValue
                }
            }
        }
    }

    if ($differences.Count -eq 0) {
        return $null
    }

    $differences
}

function Get-SheetDeviations {
    <#
    .SYNOPSIS
        Detects all cell-level deviations introduced by a template worksheet.

    .DESCRIPTION
        Compares a template worksheet against a reference worksheet on a
        cell-by-cell basis to identify deviations introduced by the template.

        Deviations are grouped using contextual anchors when available,
        allowing sequences of related cells to be captured together.
        Cells containing formulas in the reference worksheet are excluded
        from deviation detection.

        Merged cells are respected and skipped as atomic units to preserve
        structural correctness.

    .PARAMETER TemplateSheet
        The worksheet containing authoritative changes.

    .PARAMETER ReferenceSheet
        The worksheet representing the baseline state.

    .OUTPUTS
        A list of anchored deviation objects, or $null if no deviations exist.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $TemplateSheet,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $ReferenceSheet
    )

    $deviations = [System.Collections.Generic.List[pscustomobject]]::new()
    $processedCells = [System.Collections.Generic.HashSet[string]]::new()

    $maxRows = $TemplateSheet.Dimension.Rows
    $maxCols = $TemplateSheet.Dimension.Columns

    for ($rowIndex = 1; $rowIndex -le $maxRows; $rowIndex++) {
        $columnIndex = 1

        while ($columnIndex -le $maxCols) {
            $templateCell = $TemplateSheet.Cells[$rowIndex, $columnIndex]
            $referenceCell = $ReferenceSheet.Cells[$rowIndex, $columnIndex]

            # Find cell properties
            $hasFormula = -not [string]::IsNullOrWhiteSpace($referenceCell.Formula)
            $cellsEqual = $templateCell.Text -eq $referenceCell.Text
            $alreadyProcessed = $processedCells.Contains($templateCell.Address)


            # Skip cells that cannot should produce a deviation
            $shouldSkip = 
                $alreadyProcessed -or
                $cellsEqual -or
                $hasFormula

            if ($shouldSkip) {
                $columnIndex += Get-MergeOffset -Cell $templateCell -Direction Column
                continue
            }

            # If and achor exist, group any consecutive deviation to that anchor
            $getAnchorParams = @{
                Sheet  = $ReferenceSheet
                Row    = $rowIndex 
                Column = $columnIndex
            }
            $anchor = Get-ExcelAnchor @getAnchorParams

            if ($anchor) {
                # Collect all consecutive deviations tied to the same anchor.
                $anchorParams = @{
                    TemplateSheet  = $TemplateSheet
                    ReferenceSheet = $ReferenceSheet
                    StartRow       = $rowIndex
                    StartCol       = $columnIndex
                    Direction      = $anchor.Direction
                    ProcessedCells = $processedCells
                }
                $anchoredDeviations = Get-AnchoredDeviations @anchorParams

                $deviations.Add(
                    [pscustomobject] @{
                        Anchor    = $anchor.Anchor
                        Direction = $anchor.Direction
                        Values    = $anchoredDeviations.Values
                        Colors    = $anchoredDeviations.Colors
                        StartRow  = $anchoredDeviations.StartRow
                        StartCol  = $anchoredDeviations.StartCol
                    }
                )

                # Advance past the collected block to avoid reprocessing
                if ($anchor.Direction -eq 'Column') {
                    $columnIndex += $anchoredDeviations.Values.Count
                    continue
                }
            }
            else {
                # Isolated deviations without an anchor are recorded
                # as standalone entries.
                $deviations.Add(
                    [pscustomobject] @{
                        Anchor    = $null
                        Direction = $null
                        Values    = $templateCell.Text
                        Colors    = Get-Color -Cell $templateCell
                        StartRow  = $templateCell.Start.Row
                        StartCol  = $templateCell.Start.Column
                    }
                )
            }

            # Advance to the next logical cell, accounting for merged regions.
            $columnIndex += Get-MergeOffset -Cell $templateCell -Direction Column
        }
    }

    if ($deviations.Count -eq 0) {
        return $null
    }

    $deviations
}

function Get-ExcelAnchor {
    <#
    .SYNOPSIS
        Locates a descriptive anchor label adjacent to a given cell.

    .DESCRIPTION
        Attempts to identify a nearby textual anchor that can be used to
        contextualize a deviation. The search is performed in a deterministic
        order:

        1. Cell immediately to the left
        2. Cell immediately above

        An anchor is defined as any cell containing at least one letter
        (Unicode letter category). If the cell is part of a merged range,
        the merge start cell is evaluated.

    .PARAMETER Sheet
        The worksheet to search within.

    .PARAMETER Row
        The row index of the cell being evaluated.

    .PARAMETER Column
        The column index of the cell being evaluated.

    .OUTPUTS
        A PSCustomObject containing Anchor and Direction properties,
        or $null if no anchor is found.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $Sheet,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [int] $Row,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [int] $Column
    )

    $anchor    = $null
    $direction = $null

    # Attempt to find an anchor to the left of the target cell
    if ($Column -gt 1) {
        $leftCell   = $Sheet.Cells.Item($Row, $Column - 1)
        $mergeStart = Get-MergeStartPoint -Cell $leftCell
        $anchorText = $Sheet.Cells[$mergeStart.Address].Text

        if ($anchorText -match '\p{L}') {
            $anchor    = $anchorText
            $direction = 'Column'
        }
    }

    # Attempt to find an anchor above the target cell if none was found to the left
    if (-not $anchor -and $Row -gt 1) {
        $aboveCell  = $Sheet.Cells.Item($Row - 1, $Column)
        $mergeStart = Get-MergeStartPoint -Cell $aboveCell
        $anchorText = $Sheet.Cells[$mergeStart.Address].Text

        if ($anchorText -match '\p{L}') {
            $anchor    = $anchorText
            $direction = 'Row'
        }
    }

    if (-not $anchor) {
        return $null
    }

    [pscustomobject] @{
        Anchor    = $anchor
        Direction = $direction
    }
}

function Get-AnchoredDeviations {
    <#
    .SYNOPSIS
        Collects a contiguous sequence of deviating cells associated with an anchor.

    .DESCRIPTION
        Starting from a given cell, this function traverses adjacent cells in the
        specified direction (row or column) and collects consecutive deviations
        introduced by the template worksheet.

        Collection stops when:
        - The template and reference cell values match
        - A formula is encountered in the reference worksheet
        - A structural merge mismatch is detected

        All processed cells are recorded to prevent duplicate analysis.

    .PARAMETER TemplateSheet
        The worksheet containing authoritative values.

    .PARAMETER ReferenceSheet
        The worksheet representing the baseline state.

    .PARAMETER StartRow
        The starting row of the deviation sequence.

    .PARAMETER StartCol
        The starting column of the deviation sequence.

    .PARAMETER Direction
        The direction to traverse ('Row' or 'Column').

    .PARAMETER ProcessedCells
        A HashSet used to track cells that have already been analyzed.

    .OUTPUTS
        A PSCustomObject containing collected values, colors, and start coordinates.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $TemplateSheet,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $ReferenceSheet,

        [Parameter(Mandatory)]
        [ValidateRange(1, [int]::MaxValue)]
        [int] $StartRow,

        [Parameter(Mandatory)]
        [ValidateRange(1, [int]::MaxValue)]
        [int] $StartCol,

        [Parameter(Mandatory)]
        [ValidateSet('Row', 'Column')]
        [string] $Direction,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $ProcessedCells
    )

    $values = [System.Collections.Generic.List[string]]::new()
    $colors = [System.Collections.Generic.List[string]]::new()

    $currentRow = $StartRow
    $currentCol = $StartCol

    $maxRows = $TemplateSheet.Dimension.Rows
    $maxCols = $TemplateSheet.Dimension.Columns

    while ($currentRow -le $maxRows -and $currentCol -le $maxCols) {
        $templateCell  = $TemplateSheet.Cells[$currentRow, $currentCol]
        $referenceCell = $ReferenceSheet.Cells[$currentRow, $currentCol]

        $cellsMatch = $templateCell.Text -eq $referenceCell.Text
        $hasFormula = -not [string]::IsNullOrWhiteSpace($referenceCell.Formula)

        # Stop traversal when the deviation sequence ends
        if ($cellsMatch -or $hasFormula) {
            break
        }

        # Track processed cells to avoid re-analysis
        $null = $ProcessedCells.Add($templateCell.Address)

        $values.Add($templateCell.Text)
        $colors.Add((Get-Color -Cell $templateCell))

        # A merge mismatch indicates structural divergence and terminates collection
        if ($templateCell.Merge -ne $referenceCell.Merge) {
            Write-Warning (
                "Merged property mismatch found for cell {0} in sheet {1}" -f
                $templateCell.Address,
                $TemplateSheet.Name
            )
            break
        }

        # Advance to the next logical cell, respecting merged blocks
        $jump = Get-MergeOffset -Cell $templateCell -Direction $Direction

        if ($Direction -eq 'Column') {
            $currentCol += $jump
        }
        else {
            $currentRow += $jump
        }
    }

    if ($values.Count -eq 0 -and $colors.Count -eq 0) {
        return $null
    }

    return [pscustomobject] @{
        Values   = $values.ToArray()
        Colors   = $colors.ToArray()
        StartRow = $StartRow
        StartCol = $StartCol
    }
}

# --------------------------------------------------------------------
# Word Data Mapping Functions
# --------------------------------------------------------------------

function Get-WordDocumentMapping {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string]$TemplatePath,

        [Parameter(Mandatory)]
        [string]$ReferencePath
    )

    Add-Type -AssemblyName DocumentFormat.OpenXml

    $tplDoc = [DocumentFormat.OpenXml.Packaging.WordprocessingDocument]::
        Open($TemplatePath, $false)

    $refDoc = [DocumentFormat.OpenXml.Packaging.WordprocessingDocument]::
        Open($ReferencePath, $false)

    try {
        $tplParas = $tplDoc.MainDocumentPart.Document.Body.Elements[[DocumentFormat.OpenXml.Wordprocessing.Paragraph]]

        $refParas = $refDoc.MainDocumentPart.Document.Body.Elements[[DocumentFormat.OpenXml.Wordprocessing.Paragraph]]

        if ($tplParas.Count -ne $refParas.Count) {
            throw "Document structure differs — cannot create positional mapping."
        }

        $mapping = @{
            Format   = 'Word'
            Metadata = @{ParagraphCount = $tplParas.Count}
            Body     = @()
        }

        for ($i = 0; $i -lt $tplParas.Count; $i++) {
            $tplText = Get-ParagraphText $tplParas[$i]
            $refText = Get-ParagraphText $refParas[$i]

            if ($tplText -eq $refText) { continue }

            $diff = Get-MinimalTextDifference `
                -Reference $refText `
                -Template  $tplText

            $mapping.Body += @{
                ParagraphIndex = $i + 1
                Start          = $diff.Start
                Length         = $diff.Length
                Value          = $diff.Value
            }
        }

        return $mapping
    }
    finally {
        $tplDoc.Dispose()
        $refDoc.Dispose()
    }
}

function Get-ParagraphText {
    param (
        [DocumentFormat.OpenXml.Wordprocessing.Paragraph]$Paragraph
    )

    ($Paragraph.Descendants[
        [DocumentFormat.OpenXml.Wordprocessing.Text]
    ] | ForEach-Object { $_.Text }) -join ''
}

function Get-MinimalTextDifference {
    param (
        [string]$Reference,
        [string]$Template
    )

    $start = 0
    while ($start -lt $Reference.Length -and
           $start -lt $Template.Length -and
           $Reference[$start] -eq $Template[$start])
    {
        $start++
    }

    $endRef = $Reference.Length - 1
    $endTpl = $Template.Length - 1

    while ($endRef -ge $start -and
           $endTpl -ge $start -and
           $Reference[$endRef] -eq $Template[$endTpl])
    {
        $endRef--
        $endTpl--
    }

    return @{
        Start  = $start
        Length = ($endRef - $start + 1)
        Value  = $Template.Substring($start, $endTpl - $start + 1)
    }
}

# --------------------------------------------------------------------
# Excel Fill Functions
# --------------------------------------------------------------------

function Invoke-ExcelDocumentMapping {
    <#
    .SYNOPSIS
        Applies a previously generated mapping to an Excel workbook.

    .DESCRIPTION
        This function performs the "fill" phase of the workflow. It:

        - Loads a JSON mapping generated from a template/reference comparison
        - Analyzes the target workbook using EPPlus
        - Applies all document header and cell-level writes using Excel COM

        Keyword placeholders (e.g. %PN%, %BATCH%) are resolved during the
        write phase using the provided keyword table.

        The function acts purely as an orchestrator and delegates all
        worksheet analysis and write logic to helper functions.

    .PARAMETER TargetPath
        Path to the Excel workbook that will receive the filled values.

    .PARAMETER MappingJsonPath
        Path to the JSON mapping file generated previously.

    .PARAMETER Keywords
        Hashtable of keyword substitutions used to resolve placeholders
        during the fill operation.

    .OUTPUTS
        None. Modifies the target Excel workbook in place.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string] $TargetPath,

        [Parameter(Mandatory)]
        [string] $MappingJsonPath,

        [Parameter(Mandatory)]
        [hashtable] $Keywords
    )

    Import-Module ImportExcel -ErrorAction Stop

    # Load the mapping definition generated during the analysis phase
    $mappingDefinition = Get-Content $MappingJsonPath -Raw -Encoding UTF8 |
        ConvertFrom-Json

    # Prepare the set of write instructions based on the mapping
    $writesParams = @{
        TargetPath = $TargetPath
        Mapping    = $mappingDefinition
    }
    $documentWrites = Get-DocumentWrites @writesParams

    # Apply all prepared writes using Excel COM
    $applyParams = @{
        TargetPath     = $TargetPath
        DocumentWrites = $DocumentWrites
        Keywords       = $Keywords
    }
    Invoke-DocumentWritesViaCom @applyParams
}

function Get-DocumentWrites {
    <#
    .SYNOPSIS
        Prepares all worksheet-level write instructions for a target workbook.

    .DESCRIPTION
        Iterates over a mapping definition and constructs a collection of
        write instructions describing:
        - Cell-level writes
        - Document header writes

        Each instruction set corresponds to a single worksheet.
        Sheets with no writes are omitted.

        This function analyzes the workbook using EPPlus only and does not
        perform any write operations itself.

    .PARAMETER TargetPath
        Path to the workbook that will receive the writes.

    .PARAMETER Mapping
        Mapping definition generated during the analysis phase.

    .OUTPUTS
        A collection of document write instruction objects.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $TargetPath,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $Mapping
    )

    Import-Module ImportExcel -ErrorAction Stop

    $documentWriteInstructions = @()

    $targetPackage = Open-ExcelPackage -Path $TargetPath

    try {
        foreach ($sheetMapping in $Mapping) {
            $worksheet = $targetPackage.Workbook.Worksheets[$sheetMapping.Sheet]

            $bodyWrites = $null

            if ($sheetMapping.Data) {
                $bodyWritesParams = @{
                    Worksheet   = $worksheet
                    BodyMapping = $sheetMapping.Data
                }
                $bodyWrites = Get-SheetWrites @bodyWritesParams
            }

            if (-not $bodyWrites -and -not $sheetMapping.Header) {
                continue
            }

            $documentWriteInstructions += @{
                Sheet  = $sheetMapping.Sheet
                Writes = $bodyWrites
                Header = $sheetMapping.Header
            }
        }
    }
    finally {
        if ($targetPackage) {
            $targetPackage.Dispose()
        }
    }

    return $documentWriteInstructions
}

function Invoke-DocumentWritesViaCom {
    <#
    .SYNOPSIS
        Applies prepared document write instructions to an Excel workbook using COM.

    .DESCRIPTION
        This function performs the final write phase of the workflow. It receives
        precomputed write instructions describing header and cell-level updates and
        applies them to the target workbook using Excel COM automation.

        The function:
        - Applies document headers
        - Resolves keyword placeholders
        - Honors data-validation restrictions
        - Preserves worksheet protection state

        If no write instructions are provided, no action is performed.

    .PARAMETER TargetPath
        Path to the Excel workbook that will be modified.

    .PARAMETER DocumentWrites
        Collection of worksheet-level write instructions.

    .PARAMETER Keywords
        Hashtable mapping placeholder tokens to replacement values.

    .OUTPUTS
        None. Modifies the target workbook in place.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $TargetPath,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $DocumentWrites,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [hashtable] $Keywords
    )

    if (-not $DocumentWrites -or $DocumentWrites.Count -eq 0) {
        return
    }

    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false

    # Ensure target path is complete
    $fullTargetPath = (Get-Item $TargetPath).FullName

    $workbook = $excel.Workbooks.Open($fullTargetPath)

    try {
        foreach ($sheetWrite in $DocumentWrites) {
            $worksheet = $workbook.Worksheets.Item($sheetWrite.Sheet)

            if ($worksheet.ProtectContents) {
                $worksheet.Unprotect()
            }

            # Apply document headers
            foreach ($section in $sheetWrite.Header) {
                
                $resolveHeaderParams = @{
                    Value    = $section.Value
                    Keywords = $Keywords
                }
                $resolvedHeader = Set-Keyword @resolveHeaderParams

                switch ($section.Position) {
                    'Left' {
                        $worksheet.PageSetup.LeftHeader = $resolvedHeader
                    }
                    'Center' {
                        $worksheet.PageSetup.CenterHeader = $resolvedHeader
                    }
                    'Right' {
                        $worksheet.PageSetup.RightHeader = $resolvedHeader
                    }
                }
            }

            # Apply cell-level writes
            foreach ($write in $sheetWrite.Writes) {
                $cell = $worksheet.Cells.Item($write.Row, $write.Col)

                $writeValue = $write.Value

                # Resolve keyword placeholders if present
                if ($writeValue -match '%[^%]+%') {
                    $replaceKeywordParams = @{
                        Value    = $writeValue
                        Keywords = $Keywords
                    }
                    $writeValue = Set-Keyword @replaceKeywordParams
                }

                # Respect data validation restrictions if enforced
                if (Test-IsRestrictionEnforced -Cell $cell) {

                    $allowedValues = Get-AllowedValues -Cell $cell

                    $getBestMatchParams = @{
                        InputString   = $writeValue
                        AllowedValues = $allowedValues
                    }
                    $writeValue = Get-BestMatch @getBestMatchParams
                }

                $cell.Value2 = $writeValue
            }

            $worksheet.Protect()
        }

        $workbook.Save()
    }
    finally {
        $workbook.Close()
        $excel.Quit()
    }
}

function Get-SheetWrites {
    <#
    .SYNOPSIS
        Generates all cell-level write instructions for a single worksheet.

    .DESCRIPTION
        Evaluates a cell-level mapping definition against a worksheet and produces
        a collection of write instructions describing which cells should be
        updated during the fill phase.

        Both anchored and unanchored entries are supported. If no writes are
        required, the function returns $null.

    .PARAMETER Worksheet
        The worksheet to which the mapping applies.

    .PARAMETER BodyMapping
        The body-mapping entries describing intended deviations.

    .OUTPUTS
        A collection of write instruction objects, or $null if no writes exist.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $Worksheet,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $BodyMapping
    )

    $writes = @()

    foreach ($entry in $BodyMapping) {
        if (-not $entry.Anchor) {
            $noAnchorParams = @{
                Worksheet = $Worksheet
                Entry     = $entry
            }
            $writes += Get-NoAnchorEntry @noAnchorParams
        }
        else {
            $anchorParams = @{
                Worksheet = $Worksheet
                Entry     = $entry
            }
            $writes += Get-AnchoredEntry @anchorParams

        }
    }

    if ($writes.Count -eq 0) {
        return $null
    }

    $writes
}

function Get-NoAnchorEntry {
    <#
    .SYNOPSIS
        Generates a write instruction for a deviation that is not associated with an anchor.

    .DESCRIPTION
        Evaluates a single, isolated deviation entry against the target worksheet.
        A write instruction is produced only if the target cell is empty, does not
        contain a formula, and matches the expected color state.

    .PARAMETER Worksheet
        The worksheet being evaluated.

    .PARAMETER Entry
        The deviation entry describing the intended value.

    .OUTPUTS
        A write instruction object, or empty array if no write should occur.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $Worksheet,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $Entry
    )

    $cell = $Worksheet.Cells[$Entry.StartRow, $Entry.StartCol]

    $cellHasFormula = -not [string]::IsNullOrWhiteSpace($cell.Formula)
    $colorMismatch  = $Entry.Colors -ne (Get-Color -Cell $cell)
    $cellOccupied   = $cell.Text -ne ''

    # Abort if the target cell cannot be safely written
    if ($cellOccupied -or $cellHasFormula -or $colorMismatch) {
        return @()
    }

    @{
        Row   = $cell.Start.Row
        Col   = $cell.Start.Column
        Value = $Entry.Values
    }
}

function Get-AnchoredEntry {
    <#
    .SYNOPSIS
        Generates write instructions for a deviation associated with an anchor.

    .DESCRIPTION
        Resolves an anchored deviation entry by:
        - Locating all matching anchor cells in the worksheet
        - Selecting the closest anchor relative to the original deviation
        - Generating the corresponding anchored write instructions

        If no suitable anchor can be found, the function returns an empty 
        array.

    .PARAMETER Worksheet
        The worksheet against which the entry is being resolved.

    .PARAMETER Entry
        The deviation entry containing anchor information.

    .OUTPUTS
        A collection of write instruction objects, or $null if no writes apply.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $Worksheet,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $Entry
    )

    $anchorCellsParams = @{
        Worksheet  = $Worksheet
        AnchorText = $Entry.Anchor
    }
    $anchorCells = Get-AnchorCells @anchorCellsParams

    if (-not $anchorCells) {
        return @()
    }

    $closestAnchorParams = @{
        AnchorCells = $anchorCells
        Entry       = $Entry
    }
    $closestAnchor = Get-ClosestAnchor @closestAnchorParams

    if (-not $closestAnchor) {
        return @()
    }

    $generateWritesParams = @{
        Worksheet  = $Worksheet
        AnchorCell = $closestAnchor
        Entry      = $Entry
    }
    Get-AnchoredWrites @generateWritesParams
}

function Get-AnchorCells {
    <#
    .SYNOPSIS
        Locates all cells in a worksheet matching a given anchor text.

    .DESCRIPTION
        Searches the worksheet for cells whose displayed text matches the
        specified anchor text exactly.

        If no matching cells are found, a warning is emitted.
        The function returns a collection of matching cells or $null.

    .PARAMETER Worksheet
        The worksheet to search.

    .PARAMETER AnchorText
        The exact text used to identify anchor cells.

    .OUTPUTS
        A collection of Excel cell objects, or $null if none are found.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $Worksheet,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $AnchorText
    )

    $matches = @()

    foreach ($cell in $Worksheet.Cells) {
        if ($cell.Text -eq $AnchorText) {
            $matches += $cell
        }
    }

    if ($matches.Count -eq 0) {
        Write-Warning (
            "Anchor '{0}' not found on worksheet '{1}'" -f
            $AnchorText,
            $Worksheet.Name
        )

        return $null
    }

    $matches
}

function Get-ClosestAnchor {
    <#
    .SYNOPSIS
        Selects the anchor cell closest to a deviation entry.

    .DESCRIPTION
        Given a set of candidate anchor cells and a deviation entry,
        this function identifies the anchor whose position is closest
        to the entry’s original location, using Manhattan distance
        (row + column distance).

        If no anchor cells are provided, the function returns $null.

    .PARAMETER AnchorCells
        A collection of candidate anchor cells.

    .PARAMETER Entry
        The deviation entry containing the original row and column.

    .OUTPUTS
        The closest anchor cell, or $null if no candidates exist.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $AnchorCells,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $Entry
    )

    if (-not $AnchorCells) {
        return $null
    }

    $targetRow = $Entry.StartRow
    $targetCol = $Entry.StartCol

    $closestAnchor = $null
    $shortestDistance = [int]::MaxValue

    foreach ($anchorCell in $AnchorCells) {
        $distance =
            [math]::Abs($anchorCell.Start.Row - $targetRow) +
            [math]::Abs($anchorCell.Start.Column - $targetCol)

        if ($distance -lt $shortestDistance) {
            $shortestDistance = $distance
            $closestAnchor    = $anchorCell
        }
    }

    $closestAnchor
}

function Get-AnchoredWrites {
    <#
    .SYNOPSIS
        Generates write instructions for a deviation associated with an anchor.

    .DESCRIPTION
        Starting from a resolved anchor cell, this function generates a sequence
        of cell write instructions corresponding to the deviation values defined
        in the entry.

        Write generation stops when:
        - A target cell already contains data
        - A formula is encountered
        - The cell color does not match the expected state

        Merge offsets are respected to ensure correct traversal of merged regions.

    .PARAMETER Worksheet
        The worksheet being written to.

    .PARAMETER AnchorCell
        The resolved anchor cell used as the starting reference.

    .PARAMETER Entry
        The anchored deviation entry describing values and direction.

    .OUTPUTS
        A collection of write instruction objects.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $Worksheet,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $AnchorCell,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $Entry
    )

    $writes = @()

    $offset = Get-MergeOffset -Cell $AnchorCell -Direction $Entry.Direction
    if ($offset -lt 1) {
        $offset = 1
    }

    # Initialize starting position relative to the anchor
    if ($Entry.Direction -eq 'Row') {
        $currentRow = $AnchorCell.Start.Row + $offset
        $currentCol = $AnchorCell.Start.Column
    }
    else {
        $currentRow = $AnchorCell.Start.Row
        $currentCol = $AnchorCell.Start.Column + $offset
    }

    for ($index = 0; $index -lt $Entry.Values.Length; $index++) {
        $value = $Entry.Values[$index]
        $cell  = $Worksheet.Cells[$currentRow, $currentCol]

        $cellOccupied  = $cell.Text -ne ''
        $cellHasFormula = -not [string]::IsNullOrWhiteSpace($cell.Formula)
        $colorMismatch  = $Entry.Colors[$index] -ne (Get-Color -Cell $cell)

        # Abort write generation if the target cell cannot be safely written
        if ($cellOccupied -or $cellHasFormula -or $colorMismatch) {
            break
        }

        $writes += @{
            Sheet = $Worksheet.Name
            Row   = $cell.Start.Row
            Col   = $cell.Start.Column
            Value = $value
        }

        # Advance to the next logical cell, respecting merged regions
        $jump = Get-MergeOffset -Cell $cell -Direction $Entry.Direction
        if ($jump -lt 1) {
            $jump = 1
        }

        if ($Entry.Direction -eq 'Column') {
            $currentCol += $jump
        }
        else {
            $currentRow += $jump
        }
    }

    $writes
}

# --------------------------------------------------------------------
# Word Fill Functions
# --------------------------------------------------------------------

function Invoke-WordDocumentMapping {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string]$TargetPath,

        [Parameter(Mandatory)]
        $Mapping,

        [Parameter(Mandatory)]
        [hashtable]$Keywords
    )

    Add-Type -AssemblyName DocumentFormat.OpenXml

    $doc = [DocumentFormat.OpenXml.Packaging.WordprocessingDocument]::
        Open($TargetPath, $true)

    try {
        $paras = $doc.MainDocumentPart.Document.Body
            .Elements[[DocumentFormat.OpenXml.Wordprocessing.Paragraph]]

        if ($paras.Count -ne $Mapping.Metadata.ParagraphCount) {
            throw "Document structure changed — cannot apply positional mapping."
        }

        foreach ($entry in $Mapping.Body) {
            $para = $paras[$entry.ParagraphIndex - 1]

            $value = Replace-Keyword `
                -Value    $entry.Value `
                -Keywords $Keywords

            Set-ParagraphTextRange `
                -Paragraph $para `
                -Start     $entry.Start `
                -Length    $entry.Length `
                -NewText   $value
        }

        $doc.MainDocumentPart.Document.Save()
    }
    finally {
        $doc.Dispose()
    }
}

function Set-ParagraphTextRange {
    param (
        [DocumentFormat.OpenXml.Wordprocessing.Paragraph]$Paragraph,
        [int]$Start,
        [int]$Length,
        [string]$NewText
    )

    $runs = $Paragraph.Descendants[
        [DocumentFormat.OpenXml.Wordprocessing.Run]
    ]

    $pos = 0
    foreach ($run in $runs) {
        $textNode = $run.GetFirstChild(
            [DocumentFormat.OpenXml.Wordprocessing.Text]
        )
        if (-not $textNode) { continue }

        $runText = $textNode.Text
        $runLen  = $runText.Length

        if ($pos + $runLen -le $Start) {
            $pos += $runLen
            continue
        }

        $localStart = [Math]::Max(0, $Start - $pos)
        $localEnd   = [Math]::Min($runLen, $Start + $Length - $pos)

        $textNode.Text =
            $runText.Substring(0, $localStart) +
            $NewText +
            $runText.Substring($localEnd)

        break
    }
}

# --------------------------------------------------------------------
# Help Functions
# --------------------------------------------------------------------

function Get-Color {
    <#
    .SYNOPSIS
        Retrieves the background fill color of an Excel cell.

    .DESCRIPTION
        Determines the background color of a cell by inspecting its fill
        properties. The returned value represents the background color used 
        by the cell.

    .PARAMETER Cell
        The Excel cell whose background color should be inspected.

    .OUTPUTS
        A string representing the cell's background color.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $Cell
    )

    $fillColor = $Cell.Style.Fill.BackgroundColor

    if ($fillColor.Rgb) {
        return $fillColor.Rgb
    }

    if ($fillColor.Theme) {
        return $fillColor.Theme
    }

    $fillColor.LookupColor().Substring(1)
}

function Get-MergeStartPoint {
    <#
    .SYNOPSIS
        Retrieves the starting cell of a merged Excel range.

    .DESCRIPTION
        Determines whether the specified cell is part of a merged range and,
        if so, returns the coordinates of the top-left starting cell of that
        merged region. If the cell is not merged, the cell itself is returned.

    .PARAMETER Cell
        The Excel cell to inspect.

    .OUTPUTS
        A PSCustomObject containing Row, Column, and Address properties.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $Cell
    )

    # Non-merged cells report themselves as the merge start
    if (-not $Cell.Merge) {
        return [pscustomobject] @{
            Row     = $Cell.Start.Row
            Column  = $Cell.Start.Column
            Address = $Cell.Address
        }
    }

    $worksheet = $Cell.Worksheet
    $mergeIndex = $worksheet.GetMergeCellId($Cell.Start.Row, $Cell.Start.Column)

    # Retrieve the full merged range (e.g. "A1:C2")
    $mergeAddress = $worksheet.MergedCells[$mergeIndex - 1]
    $mergedRange  = $worksheet.Cells[$mergeAddress]

    [pscustomobject] @{
        Row     = $mergedRange.Start.Row
        Column  = $mergedRange.Start.Column
        Address = $mergedRange.Start.Address
    }
}

function Get-MergeOffset {
    <#
    .SYNOPSIS
        Determines how many cells a merged Excel range occupies.

    .DESCRIPTION
        Returns the number of cells to skip when traversing a worksheet
        that contains merged cells. If the specified cell is not part of 
        a merged range, the function returns 1.

        Traversal is assumed to proceed either to the right (by column) or downward
        (by row). The specified direction determines whether the skip distance is
        calculated horizontally (Column) or vertically (Row).

    .PARAMETER Cell
        The Excel cell to inspect.

    .PARAMETER Direction
        Specifies whether the offset should be calculated by column or by row.

    .OUTPUTS
        An integer representing the number of cells to skip.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $Cell,

        [ValidateSet('Row', 'Column')]
        [string] $Direction = 'Column'
    )

    # Non-merged cells always advance by a single logical cell
    if (-not $Cell.Merge) {
        return 1
    }

    $worksheet  = $Cell.Worksheet
    $mergeIndex = $worksheet.GetMergeCellId($Cell.Start.Row, $Cell.Start.Column)

    # Retrieve the full merged range (e.g. "A1:C2")
    $mergeAddress = $worksheet.MergedCells[$mergeIndex - 1]
    $mergedRange  = $worksheet.Cells[$mergeAddress]

    # Calculate how many logical cells the merge occupies
    if ($Direction -eq 'Column') {
        return ($mergedRange.End.Column - $Cell.Start.Column) + 1
    }

    ($mergedRange.End.Row - $Cell.Start.Row) + 1
}

function Get-SheetValueHash {
    <#
    .SYNOPSIS
        Computes a stable hash representing the values of a worksheet.

    .DESCRIPTION
        Generates a SHA-256 hash based on the textual values of all cells
        within the worksheet's used range.

        The hash is computed incrementally by streaming cell values in
        row-major order. The resulting hash can be used to efficiently 
        determine whether two worksheets contain identical data values.

    .PARAMETER Sheet
        The worksheet whose values should be hashed.

    .OUTPUTS
        A hexadecimal string representing the worksheet value hash.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $Sheet
    )

    $hasher = [System.Security.Cryptography.SHA256]::Create()

    try {
        foreach ($cell in $Sheet.Cells[$Sheet.Dimension.Address]) {
            if ($null -eq $cell.Value) {
                $textValue = ''
            }
            else {
                $textValue = $cell.Value.ToString()
            }

            $bytes = [System.Text.Encoding]::UTF8.GetBytes($textValue)

            $null = $hasher.TransformBlock(
                $bytes,
                0,
                $bytes.Length,
                $null,
                0
            )
        }

        $null = $hasher.TransformFinalBlock(
            [byte[]]::new(0),
            0,
            0
        )

        return ($hasher.Hash -join '')
    }
    finally {
        $hasher.Dispose()
    }
}

function Get-LevenshteinDistance {
    <#
        .SYNOPSIS
            Get the Levenshtein distance between two strings.
        .DESCRIPTION
            The Levenshtein Distance is a way of quantifying how dissimilar two strings (e.g., words) are to one another by counting the minimum number of operations required to transform one string into the other.
        .EXAMPLE
            Get-LevenshteinDistance 'kitten' 'sitting'
        .LINK
            http://en.wikibooks.org/wiki/Algorithm_Implementation/Strings/Levenshtein_distance#C.23
            http://en.wikipedia.org/wiki/Edit_distance
            https://communary.wordpress.com/
            https://github.com/gravejester/Communary.PASM
        .NOTES
            Author: Øyvind Kallstad
            Date: 07.11.2014
            Version: 1.0
    #>
    [CmdletBinding()]
    param(
        [Parameter(Position = 0)]
        [string]$String1,

        [Parameter(Position = 1)]
        [string]$String2,

        # Makes matches case-sensitive. By default, matches are not case-sensitive.
        [Parameter()]
        [switch] $CaseSensitive,

        # A normalized output will fall in the range 0 (perfect match) to 1 (no match).
        [Parameter()]
        [switch] $NormalizeOutput
    )

    if (-not($CaseSensitive)) {
        $String1 = $String1.ToLowerInvariant()
        $String2 = $String2.ToLowerInvariant()
    }

    $d = New-Object 'Int[,]' ($String1.Length + 1), ($String2.Length + 1)

    try {
        for ($i = 0; $i -le $d.GetUpperBound(0); $i++) {
            $d[$i,0] = $i
        }

        for ($i = 0; $i -le $d.GetUpperBound(1); $i++) {
            $d[0,$i] = $i
        }

        for ($i = 1; $i -le $d.GetUpperBound(0); $i++) {
            for ($j = 1; $j -le $d.GetUpperBound(1); $j++) {
                $cost = [Convert]::ToInt32((-not($String1[$i-1] -ceq $String2[$j-1])))
                $min1 = $d[($i-1),$j] + 1
                $min2 = $d[$i,($j-1)] + 1
                $min3 = $d[($i-1),($j-1)] + $cost
                $d[$i,$j] = [Math]::Min([Math]::Min($min1,$min2),$min3)
            }
        }

        $distance = ($d[$d.GetUpperBound(0),$d.GetUpperBound(1)])

        if ($NormalizeOutput) {
            Write-Output (1 - ($distance) / ([Math]::Max($String1.Length,$String2.Length)))
        }

        else {
            Write-Output $distance
        }
    }

    catch {
        Write-Warning $_.Exception.Message
    }
}

function Get-BestMatch {
    <#
    .SYNOPSIS
        Selects the closest matching value from a set of allowed values.

    .DESCRIPTION
        Compares an input string against a list of allowed values using
        Levenshtein distance and returns the closest match.

    .PARAMETER InputString
        The string to be matched.

    .PARAMETER AllowedValues
        The set of permissible values to compare against.

    .OUTPUTS
        The closest matching string from the allowed values, or $null
        if no candidates are provided.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $InputString,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [string[]] $AllowedValues
    )

    $bestMatch    = $null
    $lowestScore  = [int]::MaxValue

    foreach ($value in $AllowedValues) {
        $currentScore = Get-LevenshteinDistance -String1 $InputString -String2 $value

        # A perfect match cannot be improved upon
        if ($currentScore -eq 0) {
            return $value
        }

        if ($currentScore -lt $lowestScore) {
            $lowestScore = $currentScore
            $bestMatch   = $value
        }
    }

    return $bestMatch
}

function Set-Keyword {
    <#
    .SYNOPSIS
        Replaces placeholder keywords in a string with mapped values.

    .DESCRIPTION
        Scans the input string for placeholders in the form %KEY% and replaces
        them using values from the provided keyword table.

    .PARAMETER Value
        The input string containing one or more %KEY% placeholders.

    .PARAMETER Keywords
        A hashtable mapping keyword names to replacement values.

    .OUTPUTS
        A string with resolved placeholders.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Value,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [hashtable] $Keywords
    )

    return [regex]::Replace(
        $Value,
        '%([^%]+)%',
        {
            param ($match)

            $keyword = $match.Groups[1].Value

            if ($Keywords.ContainsKey($keyword)) {
                return $Keywords[$keyword]
            }

            # Preserve unknown placeholders
            return $match.Value
        }
    )
}

function Test-IsRestrictionEnforced {
    <#
    .SYNOPSIS
        Determines whether an Excel cell enforces a restricted value set.

    .DESCRIPTION
        Inspects a cell’s data validation settings to determine whether
        value restriction is actively enforced.

        The function returns $true only when:
        - Data validation exists
        - The validation type corresponds to a list restriction

        If validation metadata is unavailable or inaccessible, the function
        returns $false.

    .PARAMETER Cell
        The Excel cell to inspect.

    .OUTPUTS
        Boolean indicating whether value restrictions are enforced.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $Cell
    )

    try {
        $validation = $Cell.Validation

        # Validation.Type == 3 means list validation
        # Validation.AlertStyle == 1 means enforced
        return ($validation.Type -eq 3) -and
               ($validation.AlertStyle -eq 1)
    }
    catch {
        # Accessing validation metadata may throw if none is defined
        return $false
    }
}

function Get-AllowedValues {
    <#
    .SYNOPSIS
        Retrieves the set of allowed values enforced by cell validation.

    .DESCRIPTION
        Extracts the list of permitted values from an Excel cell’s data
        validation definition.

    .PARAMETER Cell
        The Excel cell whose data validation should be inspected.

    .OUTPUTS
        An array of allowed string values.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $Cell
    )

    $validationFormula = $Cell.Validation.Formula1

    # Range-based validation (e.g. "=Sheet!A1:A10")
    if ($validationFormula.StartsWith('=')) {
        $rangeReference = $validationFormula.TrimStart('=')

        $evaluatedRange = $Cell.Application.Evaluate($rangeReference)

        $values = @()

        # Excel ranges return a 2D array via Value2
        foreach ($item in $evaluatedRange.Value2) {
            if ($null -ne $item) {
                $values += [string] $item
            }
        }

        return $values
    }

    # Inline comma-separated list validation
    return $validationFormula -split ','
}

function Test-SheetsIdentical {
    <#
    .SYNOPSIS
        Determines whether two worksheets contain identical cell values.

    .DESCRIPTION
        Compares the value content of two worksheets by computing a stable,
        value-based hash for each sheet.

    .PARAMETER TemplateSheet
        The worksheet representing the template state.

    .PARAMETER ReferenceSheet
        The worksheet representing the baseline state.

    .OUTPUTS
        Boolean indicating whether the worksheets contain identical values.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $TemplateSheet,

        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $ReferenceSheet
    )

    $templateHash  = Get-SheetValueHash -Sheet $TemplateSheet
    $referenceHash = Get-SheetValueHash -Sheet $ReferenceSheet

    return $templateHash -eq $referenceHash
}

function Get-DocumentHeader {
    <#
    .SYNOPSIS
        Retrieves the document header content for a worksheet.

    .DESCRIPTION
        Extracts the left, center, and right sections of the worksheet's
        document header from the OddHeader definition.

        This function intentionally reads only the OddHeader, as Excel
        commonly uses it as the default print header for all pages unless
        explicitly overridden.

    .PARAMETER Worksheet
        The worksheet whose document header should be retrieved.

    .OUTPUTS
        A hashtable containing Left, Center, and Right header text values.
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNull()]
        [object] $Worksheet
    )

    $header = $Worksheet.HeaderFooter.OddHeader

    return @{
        Left   = $header.LeftAlignedText
        Center = $header.CenteredText
        Right  = $header.RightAlignedText
    }
}

Export-ModuleMember -Function `
    Get-ExcelDocumentMapping, `
    Invoke-ExcelDocumentMapping, `
    Get-WordDocumentMapping, `
    Invoke-WordDocumentMapping