﻿function Get-CsvFileLines {
    <#
        BOM-aware CSV reader for GeneXpert Test Summary exports.
        Important for newer exports saved as UTF-16LE with BOM.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [int]$TotalCount = 0
    )

    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    $sr = $null
    try {
        $sr = New-Object System.IO.StreamReader -ArgumentList @($Path, [System.Text.Encoding]::UTF8, $true)
        $list = New-Object System.Collections.Generic.List[string]
        while (($line = $sr.ReadLine()) -ne $null) {
            [void]$list.Add((Repair-CsvLineText $line))
            if ($TotalCount -gt 0 -and $list.Count -ge $TotalCount) { break }
        }
        return @($list.ToArray())
    } catch {
        try { Gui-Log "⚠️ Kunde inte läsa CSV: $($_.Exception.Message)" 'Warn' } catch {}
        return @()
    } finally {
        try { if ($sr) { $sr.Close() } } catch {}
        try { if ($sr) { $sr.Dispose() } } catch {}
    }
}

function Repair-CsvLineText {
    param([AllowNull()][string]$Text)
    if ($null -eq $Text) { return '' }
    # If UTF-16 was accidentally read as ANSI elsewhere, NUL bytes may remain.
    return (($Text + '') -replace "`0", '' -replace [char]0xFEFF, '').TrimEnd("`r")
}

function ConvertTo-CsvFields {
    param(
        [Parameter(Mandatory=$true)][AllowEmptyString()][string]$Line,
        [string]$Delimiter
    )
    if ($null -eq $Line) { return @() }

    $line2 = Repair-CsvLineText $Line
    $del = $Delimiter
    if ([string]::IsNullOrWhiteSpace($del)) {
        $cSemi  = ([regex]::Matches($line2, ';')).Count
        $cComma = ([regex]::Matches($line2, ',')).Count
        $cTab   = ([regex]::Matches($line2, "`t")).Count
        if ($cSemi -gt $cComma -and $cSemi -ge $cTab) { $del = ';' }
        elseif ($cTab -gt 0 -and $cComma -gt 0) { $del = 'tabcomma' }
        elseif ($cTab -gt $cComma) { $del = "`t" }
        else { $del = ',' }
    }

    $dn = (($del + '').Trim()).ToLowerInvariant()
    if ($dn -eq 'tabcomma' -or $dn -eq 'tab+comma' -or $dn -eq 'tab,comma') {
        $rx = '[,\t](?=(?:(?:[^\"]*\"){2})*[^\"]*$)'
    } else {
        $d  = [regex]::Escape($del)
        $rx = $d + '(?=(?:(?:[^\"]*\"){2})*[^\"]*$)'
    }
    $arr = [regex]::Split($line2, $rx)
    return ,@($arr | ForEach-Object { ((($_ + '') -replace '^"|"$','') -replace '""','"').Trim() })
}

function Normalize-CsvHeaderName {
    param([AllowNull()][string]$Text)
    $s = Repair-CsvLineText ($Text + '')
    $s = (($s -replace '[\uFEFF\u200B]', '').Trim().Trim('"'))
    $s = [regex]::Replace($s, '\s+', ' ')
    return $s.ToLowerInvariant()
}

function Get-CsvHeaderIndex {
    param(
        [Parameter(Mandatory=$true)][object[]]$Headers,
        [Parameter(Mandatory=$true)][string[]]$Names,
        [int]$Default = -1
    )
    if (-not $Headers) { return $Default }
    $wanted = @($Names | ForEach-Object { Normalize-CsvHeaderName ($_ + '') })
    for ($i=0; $i -lt $Headers.Count; $i++) {
        $h = Normalize-CsvHeaderName ($Headers[$i] + '')
        if ($wanted -contains $h) { return $i }
    }
    return $Default
}

function Test-CsvHeaderCandidate {
    param([object[]]$Fields)
    if (-not $Fields -or $Fields.Count -lt 5) { return 0 }
    $norm = @($Fields | ForEach-Object { Normalize-CsvHeaderName ($_ + '') })
    $score = 0
    if ($norm -contains 'assay') { $score += 4 }
    if ($norm -contains 'assay version') { $score += 2 }
    if ($norm -contains 'sample id') { $score += 6 }
    if ($norm -contains 'cartridge s/n') { $score += 5 }
    if ($norm -contains 'cartridge sn') { $score += 4 }
    if ($norm -contains 'reagent lot id') { $score += 4 }
    if ($norm -contains 'test type') { $score += 2 }
    if ($norm -contains 'instrument s/n') { $score += 4 }
    if ($norm -contains 'instrument sn') { $score += 3 }
    if ($norm -contains 'test result') { $score += 2 }
    try {
        if ($norm.Count -gt 4 -and $norm[0] -eq 'assay' -and $norm[2] -eq 'sample id') { $score += 8 }
    } catch {}
    return $score
}

function Get-TestSummaryCsvProfile {
    [CmdletBinding()]
    param(
        [string]$Path,
        [string[]]$Lines
    )

    $lines = @($Lines)
    if ($lines.Count -eq 1 -and -not $lines[0]) { $lines = @() }
    if ($lines.Count -eq 0 -and $Path) { $lines = @(Get-CsvFileLines -Path $Path) }
    if (-not $lines -or $lines.Count -eq 0) { return $null }

    $best = $null
    $delims = @(',', ';', "`t", 'tabcomma')
    $max = [Math]::Min([int]$lines.Count, 120)

    for ($i=0; $i -lt $max; $i++) {
        $line = Repair-CsvLineText $lines[$i]
        if (-not $line -or -not $line.Trim()) { continue }
        foreach ($d in $delims) {
            $fields = @()
            try { $fields = @(ConvertTo-CsvFields -Line $line -Delimiter $d) } catch { $fields = @() }
            if (-not $fields -or $fields.Count -lt 5) { continue }
            $score = Test-CsvHeaderCandidate -Fields $fields
            if ($score -lt 10) { continue }
            if ($null -eq $best -or $score -gt $best.Score -or ($score -eq $best.Score -and $fields.Count -gt $best.HeaderFields.Count)) {
                $best = [pscustomobject]@{
                    Score        = [int]$score
                    HeaderIndex  = [int]$i
                    Delimiter    = $d
                    HeaderFields = [object[]]$fields
                }
            }
        }
    }

    if (-not $best) { return $null }

    $dataIndex = [int]$best.HeaderIndex + 1
    while ($dataIndex -lt $lines.Count) {
        $ln = Repair-CsvLineText $lines[$dataIndex]
        if ($ln -and $ln.Trim().Length -gt 0) { break }
        $dataIndex++
    }

    $format = 'GeneXpert_Detected'
    if ([int]$best.HeaderIndex -eq 7 -and [int]$dataIndex -eq 9) { $format = 'GeneXpert_Legacy_Row10' }
    elseif ([int]$best.HeaderIndex -eq 8 -and [int]$dataIndex -eq 10) { $format = 'GeneXpert_UTF16_Row11' }

    return [pscustomobject]@{
        Path           = $Path
        Delimiter      = $best.Delimiter
        HeaderIndex    = [int]$best.HeaderIndex
        HeaderRow      = [int]$best.HeaderIndex + 1
        DataStartIndex = [int]$dataIndex
        DataStartRow   = [int]$dataIndex + 1
        HeaderFields   = [object[]]$best.HeaderFields
        FormatName     = $format
    }
}

function Get-CsvDelimiter { param([string]$Path)
    try {
        $profile = Get-TestSummaryCsvProfile -Path $Path
        if ($profile -and $profile.Delimiter) { return $profile.Delimiter }

        $lines = @(Get-CsvFileLines -Path $Path -TotalCount 30)
        $best = $null
        foreach ($lineRaw in $lines) {
            $line = Repair-CsvLineText $lineRaw
            if (-not $line -or -not $line.Trim()) { continue }
            $cSemi  = ([regex]::Matches($line, ';')).Count
            $cComma = ([regex]::Matches($line, ',')).Count
            $cTab   = ([regex]::Matches($line, "`t")).Count
            $max = [Math]::Max($cSemi, [Math]::Max($cComma, $cTab))
            $d = ','
            if ($cSemi -gt $cComma -and $cSemi -ge $cTab) { $d = ';' }
            elseif ($cTab -gt $cComma) { $d = "`t" }
            if ($null -eq $best -or $max -gt $best.Count) { $best = [pscustomobject]@{ Count=$max; Delimiter=$d } }
        }
        if ($best -and $best.Delimiter) { return $best.Delimiter }
        return ';'
    } catch {
        try { Gui-Log "⚠️ Get-CsvDelimiter misslyckades: $($_.Exception.Message)" 'Warn' } catch {}
        return ';'
    }
}

function Test-IsResampleCsv {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [int]$MinHits = 3
    )

    if (-not (Test-Path -LiteralPath $Path)) { return $false }
    $threshold = [Math]::Max(1, [int]$MinHits)

    try {
        $lines = @(Get-CsvFileLines -Path $Path)
        $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
        if (-not $profile) { return $false }
        $sampleIdIdx = Get-CsvHeaderIndex -Headers $profile.HeaderFields -Names @('Sample ID','SampleID','Sample Id') -Default 2

        $resCount = 0
        for ($r=[int]$profile.DataStartIndex; $r -lt $lines.Count; $r++) {
            $line = Repair-CsvLineText $lines[$r]
            if (-not $line -or $line.Trim().Length -eq 0) { continue }
            $fields = @(ConvertTo-CsvFields -Line $line -Delimiter $profile.Delimiter)
            if ($fields.Count -le $sampleIdIdx) { continue }
            $sid = ($fields[$sampleIdIdx] + '')
            if ($sid -imatch '_RES_') { $resCount++ }
        }
        return ($resCount -ge $threshold)
    } catch {
        try { Gui-Log ("⚠️ Test-IsResampleCsv misslyckades för '{0}': {1}" -f (Split-Path $Path -Leaf), $_.Exception.Message) 'Warn' 'DEBUG' } catch {}
        return $false
    }
}

function Resolve-CsvPrimaryAndResample {
    param([string[]]$CsvPaths)

    $result = [pscustomobject]@{
        Ok             = $true
        PrimaryCsv     = $null
        ResampleCsv    = $null
        HasResample    = $false
        ErrorMessage   = $null
        WarningMessage = $null
    }

    $paths = @($CsvPaths | Where-Object { $_ -and (($_ + '').Trim().Length -gt 0) })

    if ($paths.Count -eq 0) { return $result }

    if ($paths.Count -eq 1) {
        if (Test-IsResampleCsv -Path $paths[0]) {
            $result.Ok = $false
            $result.ResampleCsv = $paths[0]
            $result.ErrorMessage = '❌ Enbart Resampling-CSV vald. Välj även Primary CSV innan rapport kan skapas.'
            return $result
        }
        $result.PrimaryCsv = $paths[0]
        return $result
    }

    if ($paths.Count -eq 2) {
        $isRes0 = Test-IsResampleCsv -Path $paths[0]
        $isRes1 = Test-IsResampleCsv -Path $paths[1]

        if ($isRes0 -and -not $isRes1) {
            $result.ResampleCsv = $paths[0]
            $result.PrimaryCsv = $paths[1]
        } elseif ($isRes1 -and -not $isRes0) {
            $result.PrimaryCsv = $paths[0]
            $result.ResampleCsv = $paths[1]
        } elseif (-not $isRes0 -and -not $isRes1) {
            $result.Ok = $false
            $result.ErrorMessage = '❌ Du har valt 2 CSV-filer men ingen Resampling CSV-fil. Avmarkera en fil eller välj korrekt Resampling CSV-fil.'
            return $result
        } else {
            $result.PrimaryCsv = $paths[0]
            $result.ResampleCsv = $paths[1]
            $result.WarningMessage = '⚠️ Båda CSV har _RES_ i Sample ID – autoväljer Resampling + Original.'
        }

        $result.HasResample = [bool]$result.ResampleCsv
        return $result
    }

    $result.Ok = $false
    $result.ErrorMessage = ("❌ Du har valt {0} CSV-filer. Välj max 2 (Primary + ev. Resample)." -f $paths.Count)
    return $result
}

function Get-AssayFromCsv { param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return $null }
    try {
        $lines = @(Get-CsvFileLines -Path $Path)
        $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
        if (-not $profile) { return $null }
        $assayIdx = Get-CsvHeaderIndex -Headers $profile.HeaderFields -Names @('Assay') -Default 0
        for ($i=[int]$profile.DataStartIndex; $i -lt $lines.Count; $i++) {
            $ln = Repair-CsvLineText $lines[$i]
            if (-not $ln -or $ln.Trim().Length -eq 0) { continue }
            $f = @(ConvertTo-CsvFields -Line $ln -Delimiter $profile.Delimiter)
            if ($f.Count -le $assayIdx) { continue }
            $a = ([string]$f[$assayIdx]).Trim()
            if ($a -and $a -notmatch '^(?i)\s*assay\s*$') { return $a }
        }
    } catch {
        try { Gui-Log "⚠️ Kunde inte läsa Assay från CSV: $($_.Exception.Message)" 'Warn' } catch {}
    }
    return $null
}

function Import-CsvRows { param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    $list  = New-Object System.Collections.Generic.List[object]
    try {
        $lines = @(Get-CsvFileLines -Path $Path)
        if (-not $lines -or $lines.Count -eq 0) { return @() }
        $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
        $delim = $null
        $startIndex = [Math]::Max(0, [int]$StartRow - 1)
        if ($profile) {
            $delim = $profile.Delimiter
            $startIndex = [int]$profile.DataStartIndex
        } else {
            $delim = Get-CsvDelimiter -Path $Path
        }

        for ($i=$startIndex; $i -lt $lines.Count; $i++) {
            $ln = Repair-CsvLineText $lines[$i]
            if (-not $ln -or $ln.Trim().Length -eq 0) { continue }
            $f = @(ConvertTo-CsvFields -Line $ln -Delimiter $delim)
            if (-not $f -or ($f -join '').Trim().Length -eq 0) { continue }
            [void]$list.Add([object[]]$f)
        }
    } catch {
        try { Gui-Log "⚠️ Kunde inte läsa rader från CSV: $($_.Exception.Message)" 'Warn' } catch {}
    }
    return @($list.ToArray())
}

function Convert-CsvFieldsToObject {
    param(
        [Parameter(Mandatory=$true)][object[]]$Fields,
        [Parameter(Mandatory=$true)][object[]]$Headers
    )
    $o = [ordered]@{}
    $seen = @{}
    $max = [Math]::Min([int]$Fields.Count, [int]$Headers.Count)
    for ($i=0; $i -lt $max; $i++) {
        $h = (($Headers[$i] + '').Trim())
        if (-not $h) { $h = ('Column{0}' -f ($i + 1)) }
        $base = $h
        if ($seen.ContainsKey($base)) {
            $seen[$base] = [int]$seen[$base] + 1
            $h = ('{0}#{1}' -f $base, $seen[$base])
        } else {
            $seen[$base] = 1
        }
        $o[$h] = $Fields[$i]
    }
    return [pscustomobject]$o
}

function Import-CsvObjects { param([string]$Path,[int]$StartRow=10)
    if (-not (Test-Path -LiteralPath $Path)) { return @() }
    $out = New-Object System.Collections.Generic.List[object]
    try {
        $lines = @(Get-CsvFileLines -Path $Path)
        if (-not $lines -or $lines.Count -eq 0) { return @() }
        $profile = Get-TestSummaryCsvProfile -Path $Path -Lines $lines
        if (-not $profile) {
            # Fallback: preserve old behavior when no GeneXpert header is detected.
            $rows = @(Import-CsvRows -Path $Path -StartRow $StartRow)
            return @($rows)
        }
        $headers = [object[]]$profile.HeaderFields
        for ($i=[int]$profile.DataStartIndex; $i -lt $lines.Count; $i++) {
            $ln = Repair-CsvLineText $lines[$i]
            if (-not $ln -or $ln.Trim().Length -eq 0) { continue }
            $fields = @(ConvertTo-CsvFields -Line $ln -Delimiter $profile.Delimiter)
            if (-not $fields -or ($fields -join '').Trim().Length -eq 0) { continue }
            [void]$out.Add((Convert-CsvFieldsToObject -Fields $fields -Headers $headers))
        }
    } catch {
        try { Gui-Log "⚠️ Kunde inte läsa CSV-objekt: $($_.Exception.Message)" 'Warn' } catch {}
    }
    return @($out.ToArray())
}

function Get-CsvStats {
    param(
        [string]$Path,
        [string[]]$Lines
    )
    $out = [ordered]@{
        TestCount       = 0
        DupCount        = 0
        Duplicates      = @()
        LspValues       = @()
        LspOK           = $null
        InstrumentByType= [ordered]@{}
    }
    if (-not (Test-Path -LiteralPath $Path)) { return [pscustomobject]$out }

    $rows = @(Import-CsvObjects -Path $Path)
    if (-not $rows -or $rows.Count -eq 0) { return [pscustomobject]$out }

    $cartSnList = New-Object System.Collections.Generic.List[string]
    $lspList    = New-Object System.Collections.Generic.List[string]
    $instrList  = New-Object System.Collections.Generic.List[string]

    foreach ($row in $rows) {
        $cart = $row.'Cartridge S/N'; if (-not $cart) { $cart = $row.'Cartridge SN' }
        $lsp  = $row.'Reagent Lot ID'; if (-not $lsp) { $lsp = $row.'Reagent Lot' }
        $ins  = $row.'Instrument S/N'; if (-not $ins) { $ins = $row.'Instrument SN' }
        if ($cart) { [void]$cartSnList.Add( ($cart + '').Trim() ) }
        if ($lsp)  { [void]$lspList.Add(  ($lsp  + '').Trim() ) }
        if ($ins)  { [void]$instrList.Add(($ins  + '').Trim() ) }
    }

    $cartSn = $cartSnList | Where-Object { $_ -and $_ -ne '' }
    $out.TestCount = @($cartSn).Count
    $dups = $cartSn | Group-Object | Where-Object { $_.Count -gt 1 }
    if ($dups) {
        $out.DupCount   = @($dups).Count
        $out.Duplicates = @($dups) | ForEach-Object { "$($_.Name) x$($_.Count)" }
    }
    $lspClean = $lspList | ForEach-Object {
        $m = [regex]::Match($_, '(?<!\d)(\d{5})(?!\d)')
        if ($m.Success) { $m.Groups[1].Value } else { $null }
    } | Where-Object { $_ } | Select-Object -Unique
    $out.LspValues = @($lspClean)
    if (@($lspClean).Count -gt 0) { $out.LspOK = (@($lspClean).Count -eq 1) }

    $lut = @{}
    try {
        if ($script:GXINF_Map) {
            foreach ($k in $script:GXINF_Map.Keys) {
                $codes = $script:GXINF_Map[$k].Split(',') | ForEach-Object { ($_ + '').Trim() } | Where-Object { $_ }
                foreach ($code in $codes) { $lut[$code] = $k }
            }
        }
    } catch {}
    foreach ($ins in ($instrList | Where-Object { $_ })) {
        $t = $null
        if ($lut.ContainsKey($ins)) { $t = $lut[$ins] } else { $t = 'Unknown' }
        if (-not $out.InstrumentByType.Contains($t)) { $out.InstrumentByType[$t] = 0 }
        $out.InstrumentByType[$t] = [int]$out.InstrumentByType[$t] + 1
    }
    return [pscustomobject]$out
}

function Import-CsvRowsStreaming {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [int]$StartRow = 10,
        [Parameter(Mandatory=$true)][scriptblock]$ProcessRow
    )
    $rows = @(Import-CsvRows -Path $Path -StartRow $StartRow)
    $r = [int]$StartRow
    foreach ($fields in $rows) {
        & $ProcessRow -Fields $fields -RowIndex $r
        $r++
    }
}
