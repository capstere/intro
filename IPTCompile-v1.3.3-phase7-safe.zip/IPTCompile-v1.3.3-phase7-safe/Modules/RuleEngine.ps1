# Shim created in phase 7 safe refactor.
# Preserves original module load path and public function names.
. (Join-Path $PSScriptRoot '..\Core\RuleEngineCore.ps1')
. (Join-Path $PSScriptRoot '..\Core\RuleEngineDebug.ps1')
