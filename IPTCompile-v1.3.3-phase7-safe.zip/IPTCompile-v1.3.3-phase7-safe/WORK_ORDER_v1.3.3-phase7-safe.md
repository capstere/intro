# WORK_ORDER_v1.3.3-phase7-safe.md

## Mål
Genomför fas 7 som en låg-risk refactor där endast rena funktionsdefinitioner från `Modules/RuleEngine.ps1` delas upp, utan att förändra startup eller WinForms runtime-beteende.

## Genomfört
1. Behöll fas 6-strukturen oförändrad.
2. Skapade:
   - `Core/RuleEngineCore.ps1`
   - `Core/RuleEngineDebug.ps1`
3. Flyttade endast hela verifierade funktionsdefinitioner från `Modules/RuleEngine.ps1`.
4. Lade kärnfunktioner för regelmotor i `Core/RuleEngineCore.ps1`.
5. Lade debug-/hjälpfunktioner för regelmotor i `Core/RuleEngineDebug.ps1`.
6. Ersatte `Modules/RuleEngine.ps1` med shim som dot-sourcar de två filerna ovan.
7. Uppdaterade `Version.txt` till `1.3.3-phase7-safe`.

## Smoke test att köra i riktig miljö
1. Starta `Main.ps1`
2. Verifiera att appen öppnas
3. Verifiera att GUI-loggning fungerar
4. Verifiera att RuleBank laddas
5. Verifiera att `Invoke-RuleEngine` fortfarande fungerar
6. Verifiera att debug sheet fortfarande kan skapas där den används
7. Verifiera att QC Summary / regelutfall fortfarande byggs som tidigare

## Riskprofil
Låg.

Skäl:
- inga block klipptes ur top-level runtime i `Main.ps1`
- inga event handlers flyttades
- alla publika funktionsnamn behölls
- ursprungligt modulnamn behölls genom shim-fil
- `Modules/RuleEngine.ps1` innehöll endast funktionsdefinitioner, ingen top-level runtime-kod
