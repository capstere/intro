# SAFE_REFACTOR_NOTES.md

Version: 1.3.3-phase7-safe

Detta är fas 7 som en säker refactor ovanpå originalets runtime-struktur.

Vad som faktiskt gjordes:
- Fas 6 behölls oförändrad:
  - `Modules/Logging.ps1` är fortsatt shim till `Infrastructure/LoggingCore.ps1` och `App/UiLogging.ps1`
  - `Modules/SignatureHelpers.ps1` är fortsatt shim till `Core/SignatureWorkflow.ps1`, `App/UiSignatureDialogs.ps1` och `Infrastructure/Forensics.ps1`
  - `Modules/OpenXmlHelpers.ps1` är fortsatt shim till `Infrastructure/ExcelOpenXml.ps1` och `Core/OpenXmlSignatureWorkflow.ps1`
- `Modules/RuleEngine.ps1` delades säkert till:
  - `Core/RuleEngineCore.ps1`
  - `Core/RuleEngineDebug.ps1`
- `Modules/RuleEngine.ps1` ersattes med shim som dot-sourcar de två filerna ovan
- `Version.txt` uppdaterades till `1.3.3-phase7-safe`

Hur delningen gjordes:
- Endast hela verifierade funktionsdefinitioner flyttades
- Ingen top-level runtime-kod flyttades ut
- Alla publika funktionsnamn behölls oförändrade
- Ursprungsmodulens laddningsväg behölls via shim-modulen

Funktionsfördelning i fas 7:

## Core/RuleEngineCore.ps1
- `Import-RuleCsv`
- `_RuleEngine_Log`
- `Test-RuleBankIntegrity`
- `_EnsureArray`
- `_NormalizeColumns`
- `_RequireColumns`
- `Load-RuleBank`
- `_HasKey`
- `Compile-RuleBank`
- `Get-ResultCallPatternsForAssay`
- `Get-ExpectationRulesForAssay`
- `Match-TextFast`
- `Get-TestTypePolicyForAssayCached`
- `Get-SampleNumberRuleForRowCached`
- `Get-RowField`
- `Test-RuleEnabled`
- `Test-AssayMatch`
- `Get-TestTypePolicyForAssay`
- `Test-IsStrictMtbUltraAssay`
- `Get-MtbUltraObservedCall`
- `Get-ObservedCallDetailed`
- `Get-ExpectedCallDetailed`
- `Get-ExpectedTestTypeDerived`
- `Build-ErrorCodeLookup`
- `Get-ErrorInfo`
- `Classify-Deviation`
- `Split-CsvLineQuoted`
- `Get-HeaderFromTestSummaryFile`
- `Convert-FieldRowsToObjects`
- `Get-MarkerValue`
- `Get-IntMarkerValue`
- `Get-ParityConfigForAssay`
- `Get-ControlCodeFromRow`
- `Get-SampleTokenAndBase`
- `Parse-SampleIdBasic`
- `Get-SampleNumberRuleForRow`
- `Invoke-RuleEngine`
- `_Append-RuleFlag`

## Core/RuleEngineDebug.ps1
- `Write-RuleEngineDebugSheet`
- `_SvRuleFlags`
- `Write-SectionHeader`
- `Write-KV`

Vad som medvetet inte ändrades:
- `Main.ps1` runtime-flöde
- modulernas laddningsordning i `Main.ps1`
- top-level WinForms-kod
- `.Add_Click(...)`, `.Controls.Add(...)`, `Application.Run(...)`
- `DataHelpers.ps1`

Syftet med fas 7:
- fortsätta refactorera utan att röra startup-kritisk runtime-kod
- separera kärnlogik för regelmotor från debug/diagnostik
- behålla exakt samma publik yta via shim-modulen
